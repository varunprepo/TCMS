﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Configuration;

namespace MDI_ParenrForm
{
    class clsStaffUpdate
    {
        string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();
        public void Update_AssignedQsValues_In_ProjectsTable()
        {
            int prjID_Qs = 0;
            List<int> prjColl = new List<int>();
            string strQuery = "SELECT proj_id FROM Projects ORDER BY proj_id DESC";

            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    sqlConn.Open();

                    SqlCommand sqlCmd = new SqlCommand(strQuery, sqlConn);
                    using (SqlDataReader sqlDtRead = sqlCmd.ExecuteReader())
                    {
                        if (sqlDtRead.HasRows)
                        {
                            while (sqlDtRead.Read())
                            {
                                prjColl.Add(Convert.ToInt16(sqlDtRead[0]));
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            foreach (int prjIDQs in prjColl)
            {
                Get_AssignedQs(prjIDQs);
            }
        }

        private void Get_AssignedQs(int prjIDQs)
        {
            string strAssignedQs = string.Empty;
            string strQuery = "SELECT TOP (1) date_id, proj_id, stage_id, ptd_assign_qs " +
            " FROM TenderDatesInfo WHERE (stage_id = 1) AND (proj_id = " + prjIDQs + ") AND (ptd_assign_qs is not NUll)" +
                " ORDER BY date_id DESC";

            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    sqlConn.Open();

                    SqlCommand sqlCmd = new SqlCommand(strQuery, sqlConn);
                    using (SqlDataReader sqlDtRead = sqlCmd.ExecuteReader())
                    {
                        if (sqlDtRead.HasRows)
                        {
                            while (sqlDtRead.Read())
                            {
                                strAssignedQs = sqlDtRead[3].ToString();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            if (strAssignedQs != "")
                update_AssignedQs(strAssignedQs, prjIDQs);
        }
        int updCnt = 0;
        public void update_AssignedQs(string updateQs, int prjID)
        {
            updCnt = updCnt + 1;
            string strQuery = "Update Projects Set ptd_assign_qs = @QsName where proj_id = @prjID";
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    sqlConn.Open();
                    SqlCommand sqlCmd = new SqlCommand(strQuery, sqlConn);
                    sqlCmd.Parameters.AddWithValue("@QsName", updateQs);
                    sqlCmd.Parameters.AddWithValue("@prjID", prjID);
                    sqlCmd.ExecuteNonQuery();
                    sqlConn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //====================================================================================

        public void Update_TenderHandlingBy_In_ProjectsTable()
        {
            int prjID_Qs = 0;
            List<int> prjColl = new List<int>();
            string strQuery = "SELECT proj_id FROM Projects ORDER BY proj_id DESC";

            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    sqlConn.Open();

                    SqlCommand sqlCmd = new SqlCommand(strQuery, sqlConn);
                    using (SqlDataReader sqlDtRead = sqlCmd.ExecuteReader())
                    {
                        if (sqlDtRead.HasRows)
                        {
                            while (sqlDtRead.Read())
                            {
                                prjColl.Add(Convert.ToInt16(sqlDtRead[0]));
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            foreach (int prjIDQs in prjColl)
            {
                Get_TenderHandlingBy(prjIDQs);
            }
        }

        private void Get_TenderHandlingBy(int prjIDHndl)
        {
            string strTenderHandled = string.Empty;
            string strQuery = "SELECT TOP (1) date_id, proj_id, stage_id, ts_issue_handling " +
            " FROM TenderDatesInfo WHERE (stage_id = 2) AND (proj_id = " + prjIDHndl + ") AND (ts_tender_issue is null) AND (ts_issue_handling is not NUll)" +
                " ORDER BY date_id DESC";

            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    sqlConn.Open();

                    SqlCommand sqlCmd = new SqlCommand(strQuery, sqlConn);
                    using (SqlDataReader sqlDtRead = sqlCmd.ExecuteReader())
                    {
                        if (sqlDtRead.HasRows)
                        {
                            while (sqlDtRead.Read())
                            {
                                strTenderHandled = sqlDtRead[3].ToString();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            if (strTenderHandled != "")
                update_TenderHandled(strTenderHandled, prjIDHndl);
        }

        int updCntTndr = 0;
        public void update_TenderHandled(string updateHndl, int prjID)
        {
            updCntTndr = updCntTndr + 1;
            string strQuery = "Update Projects Set ts_issue_handling = @TndrHndlName where proj_id = @prjID";
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    sqlConn.Open();
                    SqlCommand sqlCmd = new SqlCommand(strQuery, sqlConn);
                    sqlCmd.Parameters.AddWithValue("@TndrHndlName", updateHndl);
                    sqlCmd.Parameters.AddWithValue("@prjID", prjID);
                    sqlCmd.ExecuteNonQuery();
                    sqlConn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while updating the data, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // =============================================================================

        public void Update_Staff_In_ProjectsTable()
        {
            int prjID_Qs = 0;
            List<int> prjColl = new List<int>();
            string strQuery = "SELECT proj_id FROM Projects ORDER BY proj_id DESC";

            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    sqlConn.Open();

                    SqlCommand sqlCmd = new SqlCommand(strQuery, sqlConn);
                    using (SqlDataReader sqlDtRead = sqlCmd.ExecuteReader())
                    {
                        if (sqlDtRead.HasRows)
                        {
                            while (sqlDtRead.Read())
                            {
                                prjColl.Add(Convert.ToInt16(sqlDtRead[0]));
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            foreach (int prjIDStaff in prjColl)
            {
                Get_StaffIncharge(prjIDStaff);
            }
        }

        private void Get_StaffIncharge(int prjIDStaff)
        {
            string strStaff = string.Empty;
            //string strQuery = "SELECT TOP (1) date_id, proj_id, stage_id, StaffInCharge " +
            //" FROM CONTRAC WHERE (stage_id = 4) AND (proj_id = " + prjIDStaff + ") AND (Staff_In_Charge is not NUll)" +
            //    " ORDER BY date_id DESC";

            string strQuery = "SELECT TOP (1) bidder_id, contract_no, proj_id, StaffInCharge " +
            " FROM CONTRACTORS WHERE (StaffInCharge IS NOT NULL) AND (proj_id = " + prjIDStaff + ")";

            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    sqlConn.Open();

                    SqlCommand sqlCmd = new SqlCommand(strQuery, sqlConn);
                    using (SqlDataReader sqlDtRead = sqlCmd.ExecuteReader())
                    {
                        if (sqlDtRead.HasRows)
                        {
                            while (sqlDtRead.Read())
                            {
                                strStaff = sqlDtRead[3].ToString();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            if (strStaff != "")
                update_Staff(strStaff, prjIDStaff);
        }

        int updCntStaff = 0;
        public void update_Staff(string updateStaff, int prjID)
        {
            updCntStaff = updCntStaff + 1;
            string strQuery = "Update Projects Set StaffInCharge = @staffName where proj_id = @prjID";
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    sqlConn.Open();
                    SqlCommand sqlCmd = new SqlCommand(strQuery, sqlConn);
                    sqlCmd.Parameters.AddWithValue("@staffName", updateStaff);
                    sqlCmd.Parameters.AddWithValue("@prjID", prjID);
                    sqlCmd.ExecuteNonQuery();
                    sqlConn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // =============================================================================



    }
}
