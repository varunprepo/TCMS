﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TenderTrackingSystem;
using System.Configuration;
using System.Data.SqlClient;

namespace MDI_ParenrForm.Reports
{
    public partial class frmStaffJobTrackingDetails : Form
    {
        DAL dalObj = null;
        CommonClass comCls = null;
        IList<string> mUserRightsCollComm = null;
        public frmStaffJobTrackingDetails(IList<string> userRightsCollComm)
        {
            InitializeComponent();
            dalObj = new DAL();
            comCls = new CommonClass("");
            mUserRightsCollComm = userRightsCollComm;
        }

        private void frmStaffJobTrackingDetails_Load(object sender, EventArgs e)
        {

            dalObj.populateCmbBox("Select distinct ptd_assign_qs From TenderDatesInfo where ptd_assign_qs is not NULL and ptd_assign_qs <>' ' order by ptd_assign_qs", cmbAssignedQS);
            cmbAssignedQS.SelectedIndex = -1;

            dalObj.populateCmbBox("Select distinct ts_issue_handling From TenderDatesInfo where ts_issue_handling is not NULL and ts_issue_handling <>' ' order by ts_issue_handling", cmbTenderIssue);
            cmbTenderIssue.SelectedIndex = -1;

            dalObj.populateCmbBox("Select distinct StaffInCharge From CONTRACTORS where StaffInCharge is not NULL and StaffInCharge <>' ' order by StaffInCharge", cmbContractProcess);
            cmbContractProcess.SelectedIndex = -1;

            dtStartReportDate.Value = DateTime.Now;
            dtEndReportDate.Value = DateTime.Now;
        }
               

        private void btnGenerateReport_Click(object sender, EventArgs e)
        {
            if (dtBeginReportDate == null)
            {
                MessageBox.Show("Please select a Start Report Date");                 
                return;
            }
            string assignedQS = null, tenderIssuePersonName = null, contractProcessPersonName = null;
            if(cmbAssignedQS.SelectedIndex != -1)
                assignedQS = ((DataRowView)cmbAssignedQS.SelectedItem).Row.ItemArray[0].ToString();

            if (cmbTenderIssue.SelectedIndex != -1)
                tenderIssuePersonName = ((DataRowView)cmbTenderIssue.SelectedItem).Row.ItemArray[0].ToString();

            if(cmbContractProcess.SelectedIndex != -1)
                contractProcessPersonName = ((DataRowView)cmbContractProcess.SelectedItem).Row.ItemArray[0].ToString();


            DataTable dtFinal = new DataTable("FinalReport");
            dtFinal.Columns.Add("SNo.");
            dtFinal.Columns.Add("ProjectCode");
            dtFinal.Columns.Add("ProjectTitle");
            dtFinal.Columns.Add("QSName");
            dtFinal.Columns.Add("DateReceivedOn");
            dtFinal.Columns.Add("QsWorkingStatus");
            dtFinal.Columns.Add("QSCompletedDate");
            dtFinal.Columns.Add("DocStatus");
            dtFinal.Columns.Add("CurrentStatus");
            dtFinal.Columns.Add("DepartmentName");
            dtFinal.AcceptChanges();

            Int16 rowCounter = 1;
            string sqlStaffReportsQuery = null;
            if (assignedQS != null)
            {
                sqlStaffReportsQuery = "select distinct PROJECTS.project_code, PROJECTS.project_newname_en,TenderDatesInfo.ptd_assign_qs, TenderDatesInfo.ptd_receive_on, TenderDatesInfo.ptd_qs_working_status,TenderDatesInfo.ptd_forwarded_to_dep,TenderDatesInfo.ptd_tendec_doc_cur_status,TenderStatus.Status_Name,d2.Department from TenderDatesInfo join " +
                "PROJECTS on TenderDatesInfo.proj_id=PROJECTS.proj_id join STAGES on TenderDatesInfo.stage_id=STAGES.stage_id join TenderStatus on PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id inner join Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id where TenderDatesInfo.ptd_receive_on " +
                "between '" + dtBeginReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtEndReportDate.Value.ToString("dd/MMM/yyyy") + "' and TenderDatesInfo.ptd_assign_qs ='" + assignedQS.Trim() + "' and TenderStatus.Tender_Status_id not in(8,9,10) and TenderDatesInfo.stage_id=1 ORDER BY TenderDatesInfo.ptd_forwarded_to_dep DESC";
                //" and ptd_assign_qs is NOT NULL and ts_issue_handling='" + tenderIssue + "' and ts_issue_handling <>'' and  StaffInCharge='" + contractProcess + "'";

                DataTable dtPTDReports = dalObj.GetDataFromDB("PTDReports", sqlStaffReportsQuery);
                //DataView view = new DataView(dtPTDReports);
                ////DataTable distinctValues = new DataTable();
                //DataTable dtFilteredRecords = view.ToTable(true, "project_code"); // "ptd_forwarded_to_dep", "ptd_tendec_doc_cur_status", "Status_Name""project_newname_en","ptd_assign_qs","ptd_receive_on","ptd_qs_working_status",

                //var distinctIds = dtFilteredRecords.AsEnumerable()
                //    .Select(s => new
                //    {
                //        id = s.Field<string>("project_code"),
                //    })
                //    .Distinct().ToList();
                if (dtPTDReports.Rows.Count != 0)
                {
                    foreach (DataRow drFilteredRecords in dtPTDReports.Rows)
                    {
                        //DataRow[] drs = dtPTDReports.Select("project_code='" + m.id + "'");
                        DataRow dr = dtFinal.NewRow();
                        dr[0] = rowCounter;
                        dr[1] = drFilteredRecords[0];
                        dr[2] = drFilteredRecords[1];
                        dr[3] = drFilteredRecords[2];
                        if (drFilteredRecords[3] != DBNull.Value)
                            dr[4] = Convert.ToDateTime(drFilteredRecords[3]).ToString("dd-MMM-yyyy");
                        else
                            dr[4] = "";
                        dr[5] = drFilteredRecords[4];
                        if (drFilteredRecords[5] != DBNull.Value)
                            dr[6] = Convert.ToDateTime(drFilteredRecords[5]).ToString("dd-MMM-yyyy");
                        else
                            dr[6] = "";
                        dr[7] = drFilteredRecords[6];
                        dr[8] = drFilteredRecords[7];
                        dr[9] = drFilteredRecords[8];                         
                        dtFinal.Rows.Add(dr);
                        dtFinal.AcceptChanges();
                        rowCounter++;
                    }
                }

                //if (dtPTDReports.Rows.Count != 0)
                //{
                //    foreach (DataRow drPTDReports in dtPTDReports.Rows)
                //    {

                //    }
                //}
            }

            else if (tenderIssuePersonName != null)
            {
                sqlStaffReportsQuery = "SELECT distinct PROJECTS.project_code, PROJECTS.project_newname_en, TenderDatesInfo.ts_issue_handling, TenderDatesInfo.ts_receive_on, TenderStatus.Status_Name,d2.Department from TenderDatesInfo join PROJECTS on TenderDatesInfo.proj_id=" +
                "PROJECTS.proj_id join STAGES on TenderDatesInfo.stage_id=STAGES.stage_id join TenderStatus on PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id inner join Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id where TenderDatesInfo.ts_receive_on between '" + dtBeginReportDate.Value.ToString("dd/MMM/yyyy") + "'" +
                " and '" + dtEndReportDate.Value.ToString("dd/MMM/yyyy") + "' and TenderDatesInfo.ts_issue_handling = '" + tenderIssuePersonName.Trim() + "' and TenderStatus.Tender_Status_id not in(8,9,10) and TenderDatesInfo.stage_id=2";

                DataTable dtTSReports = dalObj.GetDataFromDB("TSReports", sqlStaffReportsQuery);
                //DataView view = new DataView(dtTSReports);
                ////DataTable distinctValues = new DataTable();
                //dtTSReports = view.ToTable(true, "project_code");

                if (dtTSReports.Rows.Count != 0)
                {
                    foreach (DataRow drTSReports in dtTSReports.Rows)
                    {
                        DataRow dr = dtFinal.NewRow();
                        dr[0] = rowCounter;
                        dr[1] = drTSReports[0];
                        dr[2] = drTSReports[1];
                        dr[3] = drTSReports[2];
                        if (drTSReports[3] != DBNull.Value)
                            dr[4] = Convert.ToDateTime(drTSReports[3]).ToString("dd-MMM-yyyy");
                        else
                            dr[4] = "";
                        dr[5] = "";
                        dr[6] = "";
                        dr[7] = "";
                        dr[8] = drTSReports[4];
                        dr[9] = drTSReports[5];                         
                        dtFinal.Rows.Add(dr);
                        dtFinal.AcceptChanges();
                        rowCounter++;
                    }
                }
            }

            else if (contractProcessPersonName != null)
            {

                sqlStaffReportsQuery = "SELECT distinct PROJECTS.project_code, PROJECTS.project_newname_en, CONTRACTORS.StaffInCharge, CONTRACTORS.cp_received_of_doc, TenderStatus.Status_Name,d2.Department from CONTRACTORS JOIN PROJECTS ON CONTRACTORS.proj_id = PROJECTS.proj_id INNER JOIN " +
                "TenderDatesInfo ON CONTRACTORS.proj_id = TenderDatesInfo.proj_id JOIN TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id inner join Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id WHERE (CONTRACTORS.cp_received_of_doc BETWEEN '" + dtBeginReportDate.Value.ToString("dd/MMM/yyyy") + "' and " +
                "'" + dtEndReportDate.Value.ToString("dd/MMM/yyyy") + "') and CONTRACTORS.StaffInCharge ='" + contractProcessPersonName.Trim() + "' and TenderStatus.Tender_Status_id not in(8,9,10) ORDER BY CONTRACTORS.cp_received_of_doc DESC";

                DataTable dtCPReports = dalObj.GetDataFromDB("CPReports", sqlStaffReportsQuery);
                //DataView view = new DataView(dtCPReports);
                ////DataTable distinctValues = new DataTable();
                //DataTable dtFilteredRecords = view.ToTable(true, "project_code");

                //var distinctIds = dtFilteredRecords.AsEnumerable()
                //.Select(s => new
                //{
                //    id = s.Field<string>("project_code"),
                //})
                //.Distinct().ToList();

                if (dtCPReports.Rows.Count != 0)
                {
                    foreach (DataRow drf in dtCPReports.Rows)
                    {
                    //DataRow[] drs = dtCPReports.Select("project_code='" + m.id + "'");
                    DataRow dr = dtFinal.NewRow();
                    dr[0] = rowCounter;
                    dr[1] = drf[0];
                    dr[2] = drf[1];
                    dr[3] = drf[2];
                    if (drf[3] != DBNull.Value)
                        dr[4] = Convert.ToDateTime(drf[3]).ToString("dd-MMM-yyyy");
                    else
                        dr[4] = "";
                    dr[5] = "";
                    dr[6] = "";
                    dr[7] = "";
                    if (drf[4] != DBNull.Value)
                        dr[8] = drf[4];
                    else
                        dr[8] = "";
                    dr[9] = drf[5];                         
                    dtFinal.Rows.Add(dr);
                    dtFinal.AcceptChanges();
                    rowCounter++;
                }
             }
            

            }

            else
            {

                sqlStaffReportsQuery = "SELECT distinct PROJECTS.project_code, PROJECTS.project_newname_en, CONTRACTORS.StaffInCharge, CONTRACTORS.cp_received_of_doc, TenderStatus.Status_Name,d2.Department from CONTRACTORS JOIN PROJECTS ON CONTRACTORS.proj_id = PROJECTS.proj_id INNER JOIN " +
                "TenderDatesInfo ON CONTRACTORS.proj_id = TenderDatesInfo.proj_id JOIN TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id inner join Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id WHERE (CONTRACTORS.cp_received_of_doc BETWEEN '" + dtBeginReportDate.Value.ToString("dd/MMM/yyyy") + "' and " +
                "'" + dtEndReportDate.Value.ToString("dd/MMM/yyyy") + "') and TenderStatus.Tender_Status_id not in(8,9,10) ORDER BY CONTRACTORS.cp_received_of_doc DESC";

                DataTable dtCPReports = dalObj.GetDataFromDB("CPReports", sqlStaffReportsQuery);
                //DataView view = new DataView(dtCPReports);
                ////DataTable distinctValues = new DataTable();
                //DataTable dtFilteredRecords = view.ToTable(true, "project_code");

                //var distinctIds = dtFilteredRecords.AsEnumerable()
                //.Select(s => new
                //{
                //    id = s.Field<string>("project_code"),
                //})
                //.Distinct().ToList();

                if (dtCPReports.Rows.Count != 0)
                {
                    foreach (DataRow drf in dtCPReports.Rows)
                    {
                        //DataRow[] drs = dtCPReports.Select("project_code='" + m.id + "'");
                        DataRow dr = dtFinal.NewRow();
                        dr[0] = rowCounter;
                        dr[1] = drf[0];
                        dr[2] = drf[1];
                        dr[3] = drf[2];
                        if (drf[3] != DBNull.Value)
                            dr[4] = Convert.ToDateTime(drf[3]).ToString("dd-MMM-yyyy");
                        else
                            dr[4] = "";
                        dr[5] = "";
                        dr[6] = "";
                        dr[7] = "";
                        if (drf[4] != DBNull.Value)
                            dr[8] = drf[4];
                        else
                            dr[8] = "";
                        dr[9] = drf[5];
                        dtFinal.Rows.Add(dr);
                        dtFinal.AcceptChanges();
                        rowCounter++;
                    }
                }


            }

            StringBuilder strBuilder = new StringBuilder();
            if (dtFinal.Rows.Count == 0)
                lblTotRecCount.Text = "Total Records Count=0";
            else
                lblTotRecCount.Text = "Total Records Count=" + dtFinal.Rows.Count;

            strBuilder = CreateStaffJobTrackingReport(strBuilder, dtFinal);
            webReport.DocumentText = strBuilder.ToString();
            webReport.ScrollBarsEnabled = true;             
           
        }

        

        private StringBuilder CreateStaffJobTrackingReport(StringBuilder strBuilder, DataTable dtReports)
        {
            strBuilder.Append("<table style='border: solid 1px #506E87; width:100%'><tr>");

            strBuilder.Append("<td colspan='10' style='text-align:center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;'><b>PWA - STAFF JOB TRACKING DETAILS</b></td></tr>");
            //strBuilder.Append("<tr><td colspan='10' style='text-align: center;font-size: 12pt;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;'><b>Awarded Contracts for Fiscal Year: " + dtProjectIds.Rows[0][1] + "</b></td></tr>");
            //strBuilder.Append("<tr><td colspan='10' style='text-align: center;font-size: 12pt;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;' >Name of the Contractor/Vendor: <b>" + dtView.Row.ItemArray[1].ToString() + "</b></td></tr>");

            strBuilder.Append("<tr>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>SNo.</b></td>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Project Code</b></td>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Project Title</b></td>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>QS-Staff Name</b></td>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Received Date</b></td>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Prepare TenderDocument Working Status</b></td>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>TenderDocument Completion Date</b></td>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Document Status</b></td>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Current Tender Status</b></td>"+
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Department Name</b></td></tr>");

            //foreach (DataRow projIds in dtReports.Rows)
            //{

            //string sqlContractDetailsQuery = "SELECT DISTINCT CONTRACTORS.contract_no, PROJECTS.project_code, CONTRACTORS.ContractTitle, TenderDatesInfo.ts_tender_invitation, CONTRACTORS.cp_tender_award, CONTRACTORS.cp_contractor_sign, " +
            //"CONTRACTORS.ContractAmount, CONTRACTORS.StartDate, CONTRACTORS.FinishDate, ContractStatus.ContractStatus FROM CONTRACTORS INNER JOIN " +
            //"COMPANY ON COMPANY.co_id = CONTRACTORS.co_id INNER JOIN ContractStatus ON ContractStatus.contract_status_id = CONTRACTORS.contract_status_id INNER JOIN PROJECTS ON CONTRACTORS.proj_id = PROJECTS.proj_id " +
            //"INNER JOIN TenderDatesInfo ON CONTRACTORS.proj_id = TenderDatesInfo.proj_id WHERE (CONTRACTORS.co_id =" + coId + ") AND (CONTRACTORS.proj_id =" + projIds[0] + ") AND (CONTRACTORS.contract_no IS NOT NULL) AND (CONTRACTORS.contract_no <> ' ') " +
            //"GROUP BY CONTRACTORS.contract_no, PROJECTS.project_code, CONTRACTORS.ContractTitle, TenderDatesInfo.ts_tender_invitation, CONTRACTORS.ContractAmount, CONTRACTORS.StartDate, CONTRACTORS.FinishDate, CONTRACTORS.cp_tender_award, ContractStatus.ContractStatus, " +
            //"CONTRACTORS.cp_contractor_sign";

            //DataTable dtContractorDetails = dalObj.GetDataFromDB("ContractDetails", sqlContractDetailsQuery);

            if (dtReports.Rows.Count != 0)
            {
                foreach (DataRow colData in dtReports.Rows)
                {
                    strBuilder.Append("<tr>");
                    strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b>" + colData[0] + "</b></td>");
                    strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b>" + colData[1] + "</b></td>");
                    if (colData[2] != DBNull.Value)
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b>" + colData[2] + "</b></td>");
                    else
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    if (colData[3] != DBNull.Value)
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color:Yellow'><b>" + colData[3] + "</b></td>");
                    else
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    if (colData[4] != DBNull.Value)
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b >" + colData[4] + "</b></td>");
                    else
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    if (colData[5] != DBNull.Value)
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b>" + colData[5] + "</b></td>");
                    else
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    if (colData[6] != DBNull.Value)
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b>" + colData[6] + "</b></td>");
                    else
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    if (colData[7] != DBNull.Value)
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b>" + colData[7] + "</b></td>");
                    else
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    if (colData[8] != DBNull.Value)
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b>" + colData[8] + "</b></td>");
                    else
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    if (colData[9] != DBNull.Value)
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b>" + colData[9] + "</b></td>");
                    else
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");

                    strBuilder.Append("</tr>");
                }
                strBuilder.Append("<tr><td colspan='10' style=\"width:auto;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b style=\"font-style: italic\">This report is generated by TCMS dated :</b><b>" + DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss") + "</b></td></tr>");
                strBuilder.Append("</table>");
            }
            else
            {
                MessageBox.Show("No data exist for selected options", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                strBuilder.Append("</table>");
            }
            //dtContractorDetails.Rows.Clear();
            return strBuilder;
        }                   
            
        

        string ptdAssignQs = "";
        private void cmbAssignedQS_SelectionChangeCommitted(object sender, EventArgs e)
        {            
            if (cmbAssignedQS.SelectedIndex != -1)
                ptdAssignQs = cmbAssignedQS.SelectedItem.ToString();                 
        }

        string tsIssueHandling = "";
        private void cmbTenderIssue_SelectionChangeCommitted(object sender, EventArgs e)
        {
            //if (cmbQSWorkingStatus.SelectedIndex != -1)
            //    tsIssueHandling = cmbQSWorkingStatus.SelectedItem.ToString();                              
        }

        string staffInCharge = "";
        private void cmbContractProcess_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (cmbContractProcess.SelectedIndex != -1)
                staffInCharge = cmbContractProcess.SelectedItem.ToString();  
        }

        DateTime? dtBeginReportDate = null;
        private void dtStartReportDate_ValueChanged(object sender, EventArgs e)
        {
            dtBeginReportDate = dtStartReportDate.Value;
        }

        private void btnExportToExcel_Click(object sender, EventArgs e)
        {
            comCls.ExportToExcel(webReport);
        }
    }
}
