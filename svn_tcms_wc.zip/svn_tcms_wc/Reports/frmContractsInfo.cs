﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TenderTrackingSystem;

namespace MDI_ParenrForm.Reports
{
    public partial class frmContractsInfo : Form
    {
        private string strCon = ConfigurationManager.AppSettings["TCMSConnString"].ToString();
        private string mAffairShortName = "";
        string whereClause = null;
        IList<string> mUserRightsColl = new List<string>();
        CommonClass comCls = null;
        public frmContractsInfo(IList<string> userRightsCollComm,string affairShortName)
        {
            InitializeComponent();
            comCls = new CommonClass("");
            mUserRightsColl = userRightsCollComm;
            mAffairShortName = affairShortName;
            whereClause = comCls.CheckAccessRightsForTenderNoYear(userRightsCollComm);
            getAllAffairs();
            getCalendarYears();
            getCmpCategories();
        }



        private void getAllAffairs()
        {                             
            SqlConnection sqlConn = new SqlConnection(strCon);
            try
            {
                //cmbAffairs.Items.Clear();
                sqlConn.Open();
                DAL dalObj = new DAL();
                string sqlAffairsQuery = "";
                // Added by Varun on 17/02/14 for populating the affairs based on user access rights, Riyas request                     
                if (mAffairShortName == "All" || mAffairShortName == "")
                    sqlAffairsQuery = "SELECT AFFAIRS.[Affairs_Name],Affair_id FROM AFFAIRS ORDER BY AFFAIRS.[Affairs_Name] ASC";
                else if (mAffairShortName != "")
                    sqlAffairsQuery = "SELECT AFFAIRS.[Affairs_Name],Affair_id FROM AFFAIRS where Affairs_Short_name in(" + mAffairShortName + ") ORDER BY AFFAIRS.[Affairs_Name] ASC";
                DataTable dtAffairs = dalObj.GetDataFromDB("ProjectsInfo", sqlAffairsQuery);                
                if (mAffairShortName == "All" || mAffairShortName == "")
                {
                    DataRow row = dtAffairs.NewRow();
                    row["Affairs_Name"] = "All";
                    row["Affair_id"] = 0;
                    dtAffairs.Rows.Add(row);
                }               
                         
                cmbAffairs.DataSource = dtAffairs;
                cmbAffairs.DisplayMember = "Affairs_Name";
                cmbAffairs.ValueMember = "Affair_id";
                cmbAffairs.SelectedIndex = cmbAffairs.FindStringExact("All");
                 
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }            
        }

        /// <summary>
        /// 
        /// </summary>
        private void getCalendarYears()
        {
            SqlConnection sqlConn = new SqlConnection(strCon);
            try
            {
                DataTable dtCalendarYear = null;
                sqlConn.Open();
                DAL dalObj = new DAL();
                string sqlQuery = "SELECT FYID,[FiscalYear] FROM [FiscalYear] ORDER BY [FiscalYear] ASC";
                dtCalendarYear = dalObj.GetDataFromDB("CalendarYears", sqlQuery);
                DataRow row = dtCalendarYear.NewRow();
                row["FiscalYear"] = "All";
                row["FYID"] = 0;
                dtCalendarYear.Rows.Add(row);
                cmbFiscalYear.DataSource = dtCalendarYear;
                cmbFiscalYear.DisplayMember = "FiscalYear";
                cmbFiscalYear.ValueMember = "FYID";
                cmbFiscalYear.SelectedIndex = cmbFiscalYear.FindStringExact("All");
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }
        }

        private void getCmpCategories()
        {
            SqlConnection sqlConn = new SqlConnection(strCon);
            try
            {
                DataTable dtCmpCategory = null;
                sqlConn.Open();
                DAL dalObj = new DAL();
                string sqlQuery = "SELECT co_category_id,co_category_name FROM COMPANY_CAT";
                dtCmpCategory = dalObj.GetDataFromDB("CmpCategory", sqlQuery);
                DataRow row = dtCmpCategory.NewRow();
                row["co_category_name"] = "All";
                row["co_category_id"] = 0;
                dtCmpCategory.Rows.Add(row);
                cmbCmpCategory.DataSource = dtCmpCategory;
                cmbCmpCategory.DisplayMember = "co_category_name";
                cmbCmpCategory.ValueMember = "co_category_id";
                cmbCmpCategory.SelectedIndex = cmbCmpCategory.FindStringExact("All");
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }
        }

        static short startReportDateChanged = 0;
        static short endReportDateChanged = 0;
        static short fiscalYearSelection = 0;
        
        private void button1_Click(object sender, EventArgs e)
        {
            StringBuilder sblTenderTracking = new StringBuilder();
            DataRowView dtView = (DataRowView)cmbAffairs.SelectedItem;
            getCompaniesContractsInfo(sblTenderTracking, Convert.ToInt16(dtView.Row.ItemArray[1].ToString()), Convert.ToInt16(cmbFiscalYear.SelectedValue)); //sblTenderTracking, dtAffairs

        }

        /// <summary>
        /// Created by Varun on 07 Dec 2016 for Companies Contracts Information report
        /// </summary>
        /// <param name="?"></param>
        /// <returns></returns>
        private StringBuilder getCompaniesContractsInfo(StringBuilder strBuildContractorDetails, Int16 affairID, Int16 fyId)
        {
            try
            {

                DAL dalObj = new DAL();

                DataRowView dtView = (DataRowView)cmbFiscalYear.SelectedItem;
                strBuildContractorDetails.Append("<table style='border: solid 1px #506E87; width:100%'><tr>");

                strBuildContractorDetails.Append("<td colspan='13' style='text-align:center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;'><b>PWA - CONTRACTS DEPARTMENT</b></td></tr>");
                strBuildContractorDetails.Append("<td colspan='13' style='text-align:center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;'><b>" + lblCurrentReportName.Text + "</b></td></tr>");
                if (fyId != 0 && startReportDateChanged == 0 && endReportDateChanged == 0)
                {
                    strBuildContractorDetails.Append("<td colspan='13' style='text-align:center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;'><b>Fiscal Year: -" + dtView.Row.ItemArray[1].ToString() + "</b></td></tr>");
                }


                strBuildContractorDetails.Append("<tr><td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>SNo.</b></td>" +
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Contract No</b></td>" +
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Project Code</b></td>" +
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Project Title</b></td>" +
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Affairs Name</b></td>" +
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Department Name</b></td>" +
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Company Name</b></td>" +
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Company Nationality</b></td>" +
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Company Telephone</b></td>" +
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Company Fax No.</b></td>" +
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Company EmailID</b></td>" +
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Fiscal Year</b></td>");


                int rowCounter = 0;
                string sqlCompaniesContractsInfoQuery = null;


                if (cmbFiscalYear.Text.Equals("All") && (!cmbAffairs.Text.Equals("All")) && (!cmbCmpCategory.Text.Equals("All")) && (startReportDateChanged == 1 || endReportDateChanged == 1) && fiscalYearSelection == 0)  //affairID == 7 means All
                {
                    sqlCompaniesContractsInfoQuery = "SELECT DISTINCT CONTRACTORS.contract_no,p.project_code, p.project_newname_en,AFFAIRS.Affairs_Name, d2.Department, COMPANY.co_name, COMPANY.co_tel, COMPANY.co_fax, COMPANY.co_email_address, FiscalYear.FiscalYear, COMPANY.nationality FROM PROJECTS p INNER JOIN" +
                    " Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id INNER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON p.FYID = FiscalYear.FYID INNER JOIN AFFAIRS ON p.Affair_id = AFFAIRS.Affair_id" +
                    " INNER JOIN COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id WHERE (CONTRACTORS.contract_no <> '') AND (CONTRACTORS.contract_no IS NOT NULL) and p.Affair_id=" + cmbAffairs.SelectedValue + " and COMPANY_CAT.co_category_id=" + cmbCmpCategory.SelectedValue +
                    " and CONTRACTORS.cp_tender_award between '" + dtpStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpEndReportDate.Value.ToString("dd/MMM/yyyy") + "'";

                    if (whereClause != null)
                    {
                        if (whereClause != "")
                        {
                            sqlCompaniesContractsInfoQuery = sqlCompaniesContractsInfoQuery+" and " + whereClause;
                        }                        
                    }                     
                }
                else if ((!cmbFiscalYear.Text.Equals("All")) && (!cmbAffairs.Text.Equals("All")) && (!cmbCmpCategory.Text.Equals("All")) && (startReportDateChanged == 1 || endReportDateChanged == 1) && fiscalYearSelection == 0)  //affairID == 7 means All
                {
                    sqlCompaniesContractsInfoQuery = "SELECT DISTINCT CONTRACTORS.contract_no,p.project_code, p.project_newname_en,AFFAIRS.Affairs_Name, d2.Department, COMPANY.co_name, COMPANY.nationality, COMPANY.co_tel, COMPANY.co_fax, COMPANY.co_email_address, FiscalYear.FiscalYear, COMPANY.nationality FROM PROJECTS p INNER JOIN" +
                    " Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id INNER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON p.FYID = FiscalYear.FYID INNER JOIN AFFAIRS ON p.Affair_id = AFFAIRS.Affair_id" +
                    " INNER JOIN COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id WHERE (CONTRACTORS.contract_no <> '') AND (CONTRACTORS.contract_no IS NOT NULL) and p.Affair_id=" + cmbAffairs.SelectedValue + " and COMPANY_CAT.co_category_id=" + cmbCmpCategory.SelectedValue +
                    " and CONTRACTORS.cp_tender_award between '" + dtpStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpEndReportDate.Value.ToString("dd/MMM/yyyy") + "' and p.Affair_id=" + affairID + " and COMPANY_CAT.co_category_id=" + cmbCmpCategory.SelectedValue;

                    if (whereClause != null)
                    {
                        if (whereClause != "")
                        {
                            sqlCompaniesContractsInfoQuery = sqlCompaniesContractsInfoQuery + " and " + whereClause;
                        }   
                    }                     
                }
                else  if ((!cmbFiscalYear.Text.Equals("All")) && cmbAffairs.Text.Equals("All") && (!cmbCmpCategory.Text.Equals("All")) && (startReportDateChanged == 1 || endReportDateChanged == 1) && fiscalYearSelection == 0)  //affairID == 7 means All
                {
                    sqlCompaniesContractsInfoQuery = "SELECT DISTINCT CONTRACTORS.contract_no,p.project_code, p.project_newname_en,AFFAIRS.Affairs_Name, d2.Department, COMPANY.co_name, COMPANY.co_tel, COMPANY.co_fax, COMPANY.co_email_address, FiscalYear.FiscalYear, COMPANY.nationality FROM PROJECTS p INNER JOIN" +
                        " Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id INNER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON p.FYID = FiscalYear.FYID INNER JOIN AFFAIRS ON p.Affair_id = AFFAIRS.Affair_id" +
                        " INNER JOIN COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id WHERE (CONTRACTORS.contract_no <> '') AND (CONTRACTORS.contract_no IS NOT NULL) and p.Affair_id=" + cmbAffairs.SelectedValue +
                        " and CONTRACTORS.cp_tender_award between '" + dtpStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpEndReportDate.Value.ToString("dd/MMM/yyyy") + "' and COMPANY_CAT.co_category_id=" + cmbCmpCategory.SelectedValue;
                    if (whereClause != null)
                    {
                        if (whereClause != "")
                        {
                            sqlCompaniesContractsInfoQuery = sqlCompaniesContractsInfoQuery + " and " + whereClause;
                        } 
                    }                     
                }
                else if (cmbFiscalYear.Text.Equals("All") && cmbAffairs.Text.Equals("All") && cmbCmpCategory.Text.Equals("All") && (startReportDateChanged == 1 || endReportDateChanged == 1))
                {
                    sqlCompaniesContractsInfoQuery = "SELECT DISTINCT CONTRACTORS.contract_no,p.project_code, p.project_newname_en,AFFAIRS.Affairs_Name, d2.Department, COMPANY.co_name, COMPANY.co_tel, COMPANY.co_fax, COMPANY.co_email_address, FiscalYear.FiscalYear, COMPANY.nationality FROM PROJECTS p INNER JOIN" +
                        " Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id INNER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON p.FYID = FiscalYear.FYID INNER JOIN AFFAIRS ON p.Affair_id = AFFAIRS.Affair_id" +
                        " INNER JOIN COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id WHERE (CONTRACTORS.contract_no <> '') AND (CONTRACTORS.contract_no IS NOT NULL) and CONTRACTORS.cp_tender_award between '" + dtpStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpEndReportDate.Value.ToString("dd/MMM/yyyy") + "'";

                    if (whereClause != null)
                    {
                        if (whereClause != "")
                        {
                            sqlCompaniesContractsInfoQuery = sqlCompaniesContractsInfoQuery + " and " + whereClause;
                        } 
                    }                     
                }
                else if ((!cmbFiscalYear.Text.Equals("All")) && cmbAffairs.Text.Equals("All") && cmbCmpCategory.Text.Equals("All") && (startReportDateChanged == 1 || endReportDateChanged == 1) && fiscalYearSelection==0)
                {
                    sqlCompaniesContractsInfoQuery = "SELECT DISTINCT CONTRACTORS.contract_no,p.project_code, p.project_newname_en,AFFAIRS.Affairs_Name, d2.Department, COMPANY.co_name, COMPANY.co_tel, COMPANY.co_fax, COMPANY.co_email_address, FiscalYear.FiscalYear, COMPANY.nationality FROM PROJECTS p INNER JOIN" +
                        " Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id INNER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON p.FYID = FiscalYear.FYID INNER JOIN AFFAIRS ON p.Affair_id = AFFAIRS.Affair_id" +
                        " INNER JOIN COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id WHERE (CONTRACTORS.contract_no <> '') AND (CONTRACTORS.contract_no IS NOT NULL) and CONTRACTORS.cp_tender_award between '" + dtpStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpEndReportDate.Value.ToString("dd/MMM/yyyy") + "'";
                    if (whereClause != null)
                    {
                        if (whereClause != "")
                        {
                            sqlCompaniesContractsInfoQuery = sqlCompaniesContractsInfoQuery + " and " + whereClause;
                        } 
                    }                     
                }
                else if ((cmbFiscalYear.Text.Equals("All")) && !cmbAffairs.Text.Equals("All") && cmbCmpCategory.Text.Equals("All") && (startReportDateChanged == 1 && endReportDateChanged == 0) && fiscalYearSelection == 0)
                {
                    sqlCompaniesContractsInfoQuery = "SELECT DISTINCT CONTRACTORS.contract_no,p.project_code, p.project_newname_en,AFFAIRS.Affairs_Name, d2.Department, COMPANY.co_name, COMPANY.co_tel, COMPANY.co_fax, COMPANY.co_email_address, FiscalYear.FiscalYear, COMPANY.nationality FROM PROJECTS p INNER JOIN" +
                        " Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id INNER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON p.FYID = FiscalYear.FYID INNER JOIN AFFAIRS ON p.Affair_id = AFFAIRS.Affair_id" +
                        " INNER JOIN COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id WHERE (CONTRACTORS.contract_no <> '') AND (CONTRACTORS.contract_no IS NOT NULL) and p.Affair_id=" + affairID +" and CONTRACTORS.cp_tender_award between '" + dtpStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpEndReportDate.Value.ToString("dd/MMM/yyyy") + "'";
                    if (whereClause != null)
                    {
                        if (whereClause != "")
                        {
                            sqlCompaniesContractsInfoQuery = sqlCompaniesContractsInfoQuery + " and " + whereClause;
                        }
                    }
                }
                else if (cmbFiscalYear.Text.Equals("All") && (!cmbAffairs.Text.Equals("All")) && cmbCmpCategory.Text.Equals("All") && (startReportDateChanged == 0 || endReportDateChanged == 0) && fiscalYearSelection == 1)
                {
                    sqlCompaniesContractsInfoQuery = "SELECT DISTINCT CONTRACTORS.contract_no,p.project_code, p.project_newname_en,AFFAIRS.Affairs_Name, d2.Department, COMPANY.co_name, COMPANY.co_tel, COMPANY.co_fax, COMPANY.co_email_address, FiscalYear.FiscalYear, COMPANY.nationality FROM PROJECTS p INNER JOIN" +
                        " Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id INNER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON p.FYID = FiscalYear.FYID INNER JOIN AFFAIRS ON p.Affair_id = AFFAIRS.Affair_id" +
                        " INNER JOIN COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id WHERE (CONTRACTORS.contract_no <> '') AND (CONTRACTORS.contract_no IS NOT NULL) and p.Affair_id=" + affairID;

                    if (whereClause != null)
                    {
                        if (whereClause != "")
                        {
                            sqlCompaniesContractsInfoQuery = sqlCompaniesContractsInfoQuery + " and " + whereClause;
                        } 
                    }                     
                }
                else if (cmbFiscalYear.Text.Equals("All") && (!cmbAffairs.Text.Equals("All")) && (!cmbCmpCategory.Text.Equals("All")) && (startReportDateChanged == 0 || endReportDateChanged == 0) && fiscalYearSelection == 1)
                {
                    sqlCompaniesContractsInfoQuery = "SELECT DISTINCT CONTRACTORS.contract_no,p.project_code, p.project_newname_en,AFFAIRS.Affairs_Name, d2.Department, COMPANY.co_name, COMPANY.co_tel, COMPANY.co_fax, COMPANY.co_email_address, FiscalYear.FiscalYear, COMPANY.nationality FROM PROJECTS p INNER JOIN" +
                        " Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id INNER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON p.FYID = FiscalYear.FYID INNER JOIN AFFAIRS ON p.Affair_id = AFFAIRS.Affair_id" +
                        " INNER JOIN COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id WHERE (CONTRACTORS.contract_no <> '') AND (CONTRACTORS.contract_no IS NOT NULL) and p.Affair_id=" + affairID + " and COMPANY_CAT.co_category_id=" + cmbCmpCategory.SelectedValue;
                    if (whereClause != null)
                    {
                        if (whereClause != "")
                        {
                            sqlCompaniesContractsInfoQuery = sqlCompaniesContractsInfoQuery + " and " + whereClause;
                        } 
                    }                     
                }
                else if ((!cmbFiscalYear.Text.Equals("All")) && (!cmbAffairs.Text.Equals("All")) && (!cmbCmpCategory.Text.Equals("All")) && (startReportDateChanged == 0 || endReportDateChanged == 0) && fiscalYearSelection == 1)
                {
                    sqlCompaniesContractsInfoQuery = "SELECT DISTINCT CONTRACTORS.contract_no,p.project_code, p.project_newname_en,AFFAIRS.Affairs_Name, d2.Department, COMPANY.co_name, COMPANY.co_tel, COMPANY.co_fax, COMPANY.co_email_address, FiscalYear.FiscalYear, COMPANY.nationality FROM PROJECTS p INNER JOIN" +
                        " Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id INNER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON p.FYID = FiscalYear.FYID INNER JOIN AFFAIRS ON p.Affair_id = AFFAIRS.Affair_id" +
                        " INNER JOIN COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id WHERE (CONTRACTORS.contract_no <> '') AND (CONTRACTORS.contract_no IS NOT NULL) and p.Affair_id=" + affairID + " and COMPANY_CAT.co_category_id=" + cmbCmpCategory.SelectedValue + " and p.FYID=" + fyId;
                    if (whereClause != null)
                    {
                        if (whereClause != "")
                        {
                            sqlCompaniesContractsInfoQuery = sqlCompaniesContractsInfoQuery + " and " + whereClause;
                        } 
                    }                    

                }
                else if ((!cmbFiscalYear.Text.Equals("All")) && (!cmbAffairs.Text.Equals("All")) && (cmbCmpCategory.Text.Equals("All")) && (startReportDateChanged == 0 || endReportDateChanged == 0) && fiscalYearSelection == 1)
                {
                    sqlCompaniesContractsInfoQuery = "SELECT DISTINCT CONTRACTORS.contract_no,p.project_code, p.project_newname_en,AFFAIRS.Affairs_Name, d2.Department, COMPANY.co_name, COMPANY.co_tel, COMPANY.co_fax, COMPANY.co_email_address, FiscalYear.FiscalYear, COMPANY.nationality FROM PROJECTS p INNER JOIN" +
                        " Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id INNER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON p.FYID = FiscalYear.FYID INNER JOIN AFFAIRS ON p.Affair_id = AFFAIRS.Affair_id" +
                        " INNER JOIN COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id WHERE (CONTRACTORS.contract_no <> '') AND (CONTRACTORS.contract_no IS NOT NULL) and p.Affair_id=" + affairID + " and p.FYID=" + fyId;
                    if (whereClause != null)
                    {
                        if (whereClause != "")
                        {
                            sqlCompaniesContractsInfoQuery = sqlCompaniesContractsInfoQuery + " and " + whereClause;
                        }
                    }
                }
                else if (cmbFiscalYear.Text.Equals("All") && (!cmbAffairs.Text.Equals("All")) && (!cmbCmpCategory.Text.Equals("All")) && (startReportDateChanged == 0 || endReportDateChanged == 0) && fiscalYearSelection == 1)
                {
                    sqlCompaniesContractsInfoQuery = "SELECT DISTINCT CONTRACTORS.contract_no,p.project_code, p.project_newname_en,AFFAIRS.Affairs_Name, d2.Department, COMPANY.co_name, COMPANY.co_tel, COMPANY.co_fax, COMPANY.co_email_address, FiscalYear.FiscalYear, COMPANY.nationality FROM PROJECTS p INNER JOIN" +
                        " Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id INNER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON p.FYID = FiscalYear.FYID INNER JOIN AFFAIRS ON p.Affair_id = AFFAIRS.Affair_id" +
                        " INNER JOIN COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id WHERE (CONTRACTORS.contract_no <> '') AND (CONTRACTORS.contract_no IS NOT NULL) and p.Affair_id=" + affairID + " and COMPANY_CAT.co_category_id=" + cmbCmpCategory.SelectedValue;
                    if (whereClause != null)
                    {
                        if (whereClause != "")
                        {
                            sqlCompaniesContractsInfoQuery = sqlCompaniesContractsInfoQuery + " and " + whereClause;
                        } 
                    }                     
                }
                else if ((!cmbFiscalYear.Text.Equals("All")) && cmbAffairs.Text.Equals("All") && cmbCmpCategory.Text.Equals("All") && (startReportDateChanged == 0 || endReportDateChanged == 0) && fiscalYearSelection == 1)
                {
                    sqlCompaniesContractsInfoQuery = "SELECT DISTINCT CONTRACTORS.contract_no,p.project_code, p.project_newname_en,AFFAIRS.Affairs_Name, d2.Department, COMPANY.co_name, COMPANY.co_tel, COMPANY.co_fax, COMPANY.co_email_address, FiscalYear.FiscalYear, COMPANY.nationality FROM PROJECTS p INNER JOIN" +
                        " Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id INNER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON p.FYID = FiscalYear.FYID INNER JOIN AFFAIRS ON p.Affair_id = AFFAIRS.Affair_id" +
                        " INNER JOIN COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id WHERE (CONTRACTORS.contract_no <> '') AND (CONTRACTORS.contract_no IS NOT NULL) and p.FYID=" + fyId;
                    if (whereClause != null)
                    {
                        if (whereClause != "")
                        {
                            sqlCompaniesContractsInfoQuery = sqlCompaniesContractsInfoQuery + " and " + whereClause;
                        } 
                    }                     
                }
                else if ((!cmbFiscalYear.Text.Equals("All")) && !cmbAffairs.Text.Equals("All") && cmbCmpCategory.Text.Equals("All") && (startReportDateChanged == 0 || endReportDateChanged == 0) && fiscalYearSelection == 1)
                {
                    sqlCompaniesContractsInfoQuery = "SELECT DISTINCT CONTRACTORS.contract_no,p.project_code, p.project_newname_en,AFFAIRS.Affairs_Name, d2.Department, COMPANY.co_name, COMPANY.co_tel, COMPANY.co_fax, COMPANY.co_email_address, FiscalYear.FiscalYear, COMPANY.nationality FROM PROJECTS p INNER JOIN" +
                        " Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id INNER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON p.FYID = FiscalYear.FYID INNER JOIN AFFAIRS ON p.Affair_id = AFFAIRS.Affair_id" +
                        " INNER JOIN COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id WHERE (CONTRACTORS.contract_no <> '') AND (CONTRACTORS.contract_no IS NOT NULL) and p.FYID=" + fyId;
                    if (whereClause != null)
                    {
                        if (whereClause != "")
                        {
                            sqlCompaniesContractsInfoQuery = sqlCompaniesContractsInfoQuery + " and " + whereClause;
                        }
                    }
                }
                else if (cmbFiscalYear.Text.Equals("All") && cmbAffairs.Text.Equals("All") && cmbCmpCategory.Text.Equals("All") && (startReportDateChanged == 0 || endReportDateChanged == 0) && fiscalYearSelection == 0)
                {
                    sqlCompaniesContractsInfoQuery = "SELECT DISTINCT CONTRACTORS.contract_no,p.project_code, p.project_newname_en,AFFAIRS.Affairs_Name, d2.Department, COMPANY.co_name, COMPANY.co_tel, COMPANY.co_fax, COMPANY.co_email_address, FiscalYear.FiscalYear, COMPANY.nationality FROM PROJECTS p INNER JOIN" +
                        " Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id INNER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON p.FYID = FiscalYear.FYID INNER JOIN AFFAIRS ON p.Affair_id = AFFAIRS.Affair_id" +
                        " INNER JOIN COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id WHERE (CONTRACTORS.contract_no <> '') AND (CONTRACTORS.contract_no IS NOT NULL)";
                    if (whereClause != null)
                    {
                        if (whereClause != "")
                        {
                            sqlCompaniesContractsInfoQuery = sqlCompaniesContractsInfoQuery + " and " + whereClause;
                        } 
                    }                     
                }
                else if (!cmbFiscalYear.Text.Equals("All") && !cmbAffairs.Text.Equals("All") && cmbCmpCategory.Text.Equals("All") && (startReportDateChanged == 0 || endReportDateChanged == 0) && fiscalYearSelection == 1)
                {
                    sqlCompaniesContractsInfoQuery = "SELECT DISTINCT CONTRACTORS.contract_no,p.project_code, p.project_newname_en,AFFAIRS.Affairs_Name, d2.Department, COMPANY.co_name, COMPANY.co_tel, COMPANY.co_fax, COMPANY.co_email_address, FiscalYear.FiscalYear, COMPANY.nationality FROM PROJECTS p INNER JOIN" +
                            " Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id INNER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON p.FYID = FiscalYear.FYID INNER JOIN AFFAIRS ON p.Affair_id = AFFAIRS.Affair_id" +
                            " INNER JOIN COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id WHERE (CONTRACTORS.contract_no <> '') AND (CONTRACTORS.contract_no IS NOT NULL) and p.Affair_id=" + affairID + " and p.FYID=" + fyId;
                    if (whereClause != null)
                    {
                        if (whereClause != "")
                        {
                            sqlCompaniesContractsInfoQuery = sqlCompaniesContractsInfoQuery + " and " + whereClause;
                        } 
                    }                     
                }
                else if (!cmbFiscalYear.Text.Equals("All") && !cmbAffairs.Text.Equals("All") && !cmbCmpCategory.Text.Equals("All") && (startReportDateChanged == 0 || endReportDateChanged == 0) && fiscalYearSelection == 1)
                {
                    sqlCompaniesContractsInfoQuery = "SELECT DISTINCT CONTRACTORS.contract_no,p.project_code, p.project_newname_en,AFFAIRS.Affairs_Name, d2.Department, COMPANY.co_name, COMPANY.co_tel, COMPANY.co_fax, COMPANY.co_email_address, FiscalYear.FiscalYear, COMPANY.nationality FROM PROJECTS p INNER JOIN" +
                            " Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id INNER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON p.FYID = FiscalYear.FYID INNER JOIN AFFAIRS ON p.Affair_id = AFFAIRS.Affair_id" +
                            " INNER JOIN COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id WHERE (CONTRACTORS.contract_no <> '') AND (CONTRACTORS.contract_no IS NOT NULL) and p.Affair_id=" + affairID + " and p.FYID=" + fyId + " and COMPANY_CAT.co_category_id=" + cmbCmpCategory.SelectedValue;
                    if (whereClause != null)
                    {
                        if (whereClause != "")
                        {
                            sqlCompaniesContractsInfoQuery = sqlCompaniesContractsInfoQuery + " and " + whereClause;
                        }
                    }
                }
                else if (cmbFiscalYear.Text.Equals("All") && cmbAffairs.Text.Equals("All") && (!cmbCmpCategory.Text.Equals("All")) && (startReportDateChanged == 0 || endReportDateChanged == 0) && fiscalYearSelection == 1)  //affairID == 7 means All
                {
                    sqlCompaniesContractsInfoQuery = "SELECT DISTINCT CONTRACTORS.contract_no,p.project_code, p.project_newname_en,AFFAIRS.Affairs_Name, d2.Department, COMPANY.co_name, COMPANY.co_tel, COMPANY.co_fax, COMPANY.co_email_address, FiscalYear.FiscalYear, COMPANY.nationality FROM PROJECTS p INNER JOIN" +
                        " Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id INNER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON p.FYID = FiscalYear.FYID INNER JOIN AFFAIRS ON p.Affair_id = AFFAIRS.Affair_id" +
                        " INNER JOIN COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id WHERE (CONTRACTORS.contract_no <> '') AND (CONTRACTORS.contract_no IS NOT NULL) and COMPANY_CAT.co_category_id=" + cmbCmpCategory.SelectedValue;
                    if (whereClause != null)
                    {
                        if (whereClause != "")
                        {
                            sqlCompaniesContractsInfoQuery = sqlCompaniesContractsInfoQuery + " and " + whereClause;
                        } 
                    }
                     
                }
                else if ((!cmbFiscalYear.Text.Equals("All")) && !cmbAffairs.Text.Equals("All") && cmbCmpCategory.Text.Equals("All") && (startReportDateChanged == 1 && endReportDateChanged == 0) && fiscalYearSelection == 0)
                {
                    sqlCompaniesContractsInfoQuery = "SELECT DISTINCT CONTRACTORS.contract_no,p.project_code, p.project_newname_en,AFFAIRS.Affairs_Name, d2.Department, COMPANY.co_name, COMPANY.co_tel, COMPANY.co_fax, COMPANY.co_email_address, FiscalYear.FiscalYear, COMPANY.nationality FROM PROJECTS p INNER JOIN" +
                        " Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id INNER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON p.FYID = FiscalYear.FYID INNER JOIN AFFAIRS ON p.Affair_id = AFFAIRS.Affair_id" +
                        " INNER JOIN COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id WHERE (CONTRACTORS.contract_no <> '') AND (CONTRACTORS.contract_no IS NOT NULL) and p.Affair_id=" + affairID + " and CONTRACTORS.cp_tender_award between '" + dtpStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpEndReportDate.Value.ToString("dd/MMM/yyyy") + "'";
                    if (whereClause != null)
                    {
                        if (whereClause != "")
                        {
                            sqlCompaniesContractsInfoQuery = sqlCompaniesContractsInfoQuery + " and " + whereClause;
                        }
                    }
                }
                else if ((!cmbFiscalYear.Text.Equals("All")) && (!cmbAffairs.Text.Equals("All")) && (cmbCmpCategory.Text.Equals("All")) && (startReportDateChanged == 1 || endReportDateChanged == 1) && fiscalYearSelection == 0)
                {
                    sqlCompaniesContractsInfoQuery = "SELECT DISTINCT CONTRACTORS.contract_no,p.project_code, p.project_newname_en,AFFAIRS.Affairs_Name, d2.Department, COMPANY.co_name, COMPANY.co_tel, COMPANY.co_fax, COMPANY.co_email_address, FiscalYear.FiscalYear, COMPANY.nationality FROM PROJECTS p INNER JOIN" +
                        " Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id INNER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON p.FYID = FiscalYear.FYID INNER JOIN AFFAIRS ON p.Affair_id = AFFAIRS.Affair_id" +
                        " INNER JOIN COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id WHERE (CONTRACTORS.contract_no <> '') AND (CONTRACTORS.contract_no IS NOT NULL) and p.Affair_id=" + affairID + " and CONTRACTORS.cp_tender_award between '" + dtpStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpEndReportDate.Value.ToString("dd/MMM/yyyy") + "'";
                    if (whereClause != null)
                    {
                        if (whereClause != "")
                        {
                            sqlCompaniesContractsInfoQuery = sqlCompaniesContractsInfoQuery + " and " + whereClause;
                        }
                    }

                }
                else if ((!cmbFiscalYear.Text.Equals("All")) && (!cmbAffairs.Text.Equals("All")) && (!cmbCmpCategory.Text.Equals("All")) && (startReportDateChanged == 0 || endReportDateChanged == 0) && fiscalYearSelection == 1)
                {
                    sqlCompaniesContractsInfoQuery = "SELECT DISTINCT CONTRACTORS.contract_no,p.project_code, p.project_newname_en,AFFAIRS.Affairs_Name, d2.Department, COMPANY.co_name, COMPANY.co_tel, COMPANY.co_fax, COMPANY.co_email_address, FiscalYear.FiscalYear, COMPANY.nationality FROM PROJECTS p INNER JOIN" +
                        " Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id INNER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON p.FYID = FiscalYear.FYID INNER JOIN AFFAIRS ON p.Affair_id = AFFAIRS.Affair_id" +
                        " INNER JOIN COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id WHERE (CONTRACTORS.contract_no <> '') AND (CONTRACTORS.contract_no IS NOT NULL) and p.Affair_id=" + affairID + " and COMPANY_CAT.co_category_id=" + cmbCmpCategory.SelectedValue + " and p.FYID=" + fyId;
                    if (whereClause != null)
                    {
                        if (whereClause != "")
                        {
                            sqlCompaniesContractsInfoQuery = sqlCompaniesContractsInfoQuery + " and " + whereClause;
                        }
                    }

                }
                else
                {
                    sqlCompaniesContractsInfoQuery = "SELECT DISTINCT CONTRACTORS.contract_no,p.project_code, p.project_newname_en,AFFAIRS.Affairs_Name, d2.Department, COMPANY.co_name, COMPANY.co_tel, COMPANY.co_fax, COMPANY.co_email_address, FiscalYear.FiscalYear, COMPANY.nationality FROM PROJECTS p INNER JOIN" +
                       " Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id INNER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON p.FYID = FiscalYear.FYID INNER JOIN AFFAIRS ON p.Affair_id = AFFAIRS.Affair_id" +
                       " INNER JOIN COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id WHERE (CONTRACTORS.contract_no <> '') AND (CONTRACTORS.contract_no IS NOT NULL) and CONTRACTORS.cp_tender_award between '" + dtpStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpEndReportDate.Value.ToString("dd/MMM/yyyy") + "'";
                    if (whereClause != null)
                    {
                        if (whereClause != "")
                        {
                            sqlCompaniesContractsInfoQuery = sqlCompaniesContractsInfoQuery + " and " + whereClause;
                        }
                    }
                }

                DataTable dtContractorDetails = dalObj.GetDataFromDB("CmpContractsInfo", sqlCompaniesContractsInfoQuery);

                if (dtContractorDetails.Rows.Count != 0)
                {

                    foreach (DataRow colData in dtContractorDetails.Rows)
                    {
                        strBuildContractorDetails.Append("<tr><td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + ++rowCounter + "</b></td>");
                        strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + colData[0] + "</b></td>");

                        strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + colData[1] + "</b></td>");

                        strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + colData[2] + "</b></td>");

                        strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + colData[3].ToString() + "</b></td>");
                        strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + colData[4].ToString() + "</b></td>");
                        strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + colData[5].ToString() + "</b></td>");
                        strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + colData[10].ToString() + "</b></td>");
                        if (colData[6] != DBNull.Value)
                        {
                            strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + colData[6].ToString() + "</b></td>");
                        }
                        else
                        {
                            strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                        }
                        if (colData[7] != DBNull.Value)
                        {
                            strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + colData[7].ToString() + "</b></td>");
                        }
                        else
                        {
                            strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                        }
                        if (colData[8] != DBNull.Value)
                        {
                            strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + colData[8].ToString() + "</b></td>");
                        }
                        else
                        {
                            strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                        }
                        strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + colData[9].ToString() + "</b></td>");
                        strBuildContractorDetails.Append("</tr>");
                    }
                }



                if (dtContractorDetails.Rows.Count != 0)
                {
                    strBuildContractorDetails.Append("<tr><td colspan='13' style=\"width:auto;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b style=\"font-style: italic\">This report is generated by TCMS dated :</b><b>" + DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss") + "</b></td></tr>");
                    strBuildContractorDetails.Append("</table>");
                    lblTotalNoOfRecords.Text = "Total Records Count=" + rowCounter;
                }
                else
                {
                    strBuildContractorDetails.Append("</table>");
                    lblTotalNoOfRecords.Text = "Total Records Count=0";
                    MessageBox.Show("No data exist for selected options", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                webReport.DocumentText = strBuildContractorDetails.ToString();
                webReport.ScrollBarsEnabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while retrieving the information of the contractor");
            }

            return strBuildContractorDetails;
        }

        private void dtpStartReportDate_ValueChanged(object sender, EventArgs e)
        {
            startReportDateChanged = 1;
            fiscalYearSelection = 0;
        }

        private void dtpEndReportDate_ValueChanged(object sender, EventArgs e)
        {
            endReportDateChanged = 1;
            fiscalYearSelection = 0;
        }

        private void cmbFiscalYear_SelectedIndexChanged(object sender, EventArgs e)
        {
            startReportDateChanged = 0;
            endReportDateChanged = 0;
            fiscalYearSelection = 1;
        }

        private void btnExportToExcel_Click(object sender, EventArgs e)
        {
            comCls.ExportToExcel(webReport);
        }

       
    }
}
