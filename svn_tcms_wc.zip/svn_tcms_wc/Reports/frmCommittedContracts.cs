﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TenderTrackingSystem;

namespace MDI_ParenrForm.Reports
{
    public partial class frmCommittedContracts : Form
    {
        DAL dalObj = null;
        CommonClass comCls = null;         
        IList<string> userRightsColl = null;
        static short startReportDateChanged = 0;
        static short endReportDateChanged = 0;

        public frmCommittedContracts(IList<string> userRightsCollComm)
        {
            InitializeComponent();
            //userRightsColl = new List<string>();
            userRightsColl = userRightsCollComm;
            comCls = new CommonClass("");
            dalObj = new DAL();

            DataTable dtCommitteeNames = dalObj.GetDataFromDB("CommitteeNames", "select committee_id,committee_name from Committee");
            DataRow row = dtCommitteeNames.NewRow();
            row["committee_name"] = "All";
            row["committee_id"] = 0;
            dtCommitteeNames.Rows.Add(row);
            cmbCommitteeNames.DataSource = dtCommitteeNames;
            cmbCommitteeNames.DisplayMember = "committee_name";
            cmbCommitteeNames.ValueMember = "committee_id";
            cmbCommitteeNames.SelectedIndex = cmbCommitteeNames.FindStringExact("All");

            DataTable dtDepartments = dalObj.GetDataFromDB("Departments", "select department_id,department_short_name from Department");
            row = dtDepartments.NewRow();
            row["department_short_name"] = "All";
            row["department_id"] = 0;
            dtDepartments.Rows.Add(row);
            cmbDepartments.DataSource = dtDepartments;
            cmbDepartments.DisplayMember = "department_short_name";
            cmbDepartments.ValueMember = "department_id";
            cmbDepartments.SelectedIndex = cmbDepartments.FindStringExact("All");

            dalObj.populateCmbBox("select cyID,commitmentYear from CommittedYear order by commitmentYear desc", cmbCommittedYear);                     

        }

        
        private void btnSubmitReport_Click(object sender, EventArgs e)
        {             
            GenerateReport();
        }
          

        private void GenerateReport()
        {
            DataTable dtAwardedContracts = new DataTable();
            dtAwardedContracts.Columns.Add("SNo");
            dtAwardedContracts.Columns.Add("TenderNo.");
            dtAwardedContracts.Columns.Add("TenderTitle");
            dtAwardedContracts.Columns.Add("ProjectCode");
            dtAwardedContracts.Columns.Add("Department");
            dtAwardedContracts.Columns.Add("TenderPublishDate");
            dtAwardedContracts.Columns.Add("TypeOfTender");
            dtAwardedContracts.Columns.Add("TenderAwardDate");
            dtAwardedContracts.Columns.Add("SuccessfulTenderer");
            dtAwardedContracts.Columns.Add("NationalityofCompany");
            dtAwardedContracts.Columns.Add("AwardingValue");
            dtAwardedContracts.Columns.Add("SignDate");
            dtAwardedContracts.Columns.Add("DistributedDate");
            dtAwardedContracts.Columns.Add("ContractStatus");
            dtAwardedContracts.Columns.Add("ContractNo");             
            dtAwardedContracts.AcceptChanges();
            

            string sqlCommReport = null;
            CommonClass comCls = new CommonClass("");
            //MessageBox.Show(comCls.ToString());    
            string whereClause = comCls.CheckAccessRightsForTenderNoYear(userRightsColl);
            //MessageBox.Show("whereClause" + whereClause);    
            if (cmbCommitteeNames == null)
            {
                //MessageBox.Show("Combobox cmbCommitteeNames is null");
                if (cmbDepartments == null)
                {
                    MessageBox.Show("Combobox cmbDepartments is null");
                }
            }
            else
            {
                //MessageBox.Show("Before If :");
                //MessageBox.Show("cmbCommitteeNames :" + cmbCommitteeNames.SelectedValue);
                //MessageBox.Show("cmbDepartments :" + cmbDepartments.SelectedValue);

                if (cmbCommitteeNames.SelectedValue.ToString().Equals("0") && cmbDepartments.SelectedValue.ToString().Equals("0"))
                {
                    sqlCommReport = "SELECT distinct p.tender_no, p.project_newname_en, p.project_code, d2.department_short_name, TenderTypes.tender_type_name,Replace(CONVERT(nvarchar,CONTRACTORS.cp_tender_award,106),' ','-') as cp_tender_award," +
                    "COMPANY.co_name,COMPANY.nationality,CONTRACTORS.ContractAmount,Replace(CONVERT(nvarchar,CONTRACTORS.cp_contractor_sign,106),' ','-') as cp_contractor_sign,Replace(CONVERT(nvarchar,CONTRACTORS.cp_distribution,106),' ','-') as cp_distribution,ContractStatus.ContractStatus," +
                    "CONTRACTORS.contract_no,p.proj_id FROM PROJECTS p left outer JOIN Committee c ON p.committee_id = c.committee_id left outer JOIN TenderTypes ON p.tender_type_id = TenderTypes.tender_type_id left outer JOIN TenderStatus ON p.Tender_Status_id = TenderStatus.Tender_Status_id " +
                    "left outer JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id left outer JOIN FiscalYear ON p.FYID = FiscalYear.FYID inner join Department2 as d1 on p.department_id=d1.department_id" +
                    " inner join Department2 as d2 on d1.newDepID=d2.department_id left outer JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id " +
                    "left outer join ContractStatus on CONTRACTORS.contract_status_id = ContractStatus.contract_status_id where (TenderStatus.Tender_Status_id<>8 and TenderStatus.Tender_Status_id<>17) "; // Tender_Status_id==8 (Cancelled) && Tender_Status_id==17(Archive)
                    //MessageBox.Show("Query:" + sqlCommReport);
                    //MessageBox.Show("cmbCommittedYear.SelectedItem" + cmbCommittedYear.SelectedValue);
                    //"left outer join ContractStatus on CONTRACTORS.contract_status_id = ContractStatus.contract_status_id where CONTRACTORS.cp_tender_award is not NULL and (TenderStatus.Tender_Status_id<>8 and TenderStatus.Tender_Status_id<>17) and p.FYID=" + cmbFiscalYear.SelectedValue + " and p.tender_no is not NULL " +
                }
                else if (cmbCommitteeNames.SelectedValue.ToString().Equals("0") && (!cmbDepartments.SelectedValue.ToString().Equals("0")))
                {
                    sqlCommReport = "SELECT distinct p.tender_no, p.project_newname_en, p.project_code, Department.department_short_name, TenderTypes.tender_type_name,Replace(CONVERT(nvarchar,CONTRACTORS.cp_tender_award,106),' ','-') as cp_tender_award," +
                    "COMPANY.co_name,COMPANY.nationality,CONTRACTORS.ContractAmount,Replace(CONVERT(nvarchar,CONTRACTORS.cp_contractor_sign,106),' ','-') as cp_contractor_sign,Replace(CONVERT(nvarchar,CONTRACTORS.cp_distribution,106),' ','-') as cp_distribution,ContractStatus.ContractStatus," +
                    "CONTRACTORS.contract_no,p.proj_id FROM PROJECTS p left outer JOIN Committee c ON p.committee_id = c.committee_id left outer JOIN TenderTypes ON p.tender_type_id = TenderTypes.tender_type_id left outer JOIN TenderStatus ON p.Tender_Status_id = TenderStatus.Tender_Status_id " +
                    "left outer JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id left outer JOIN FiscalYear ON p.FYID = FiscalYear.FYID left outer JOIN Department ON p.department_id = Department.department_id left outer JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id " +
                    "left outer join ContractStatus on CONTRACTORS.contract_status_id = ContractStatus.contract_status_id where (TenderStatus.Tender_Status_id<>8 and TenderStatus.Tender_Status_id<>17) and p.department_id=" + cmbDepartments.SelectedValue; // Tender_Status_id==8 (Cancelled) && Tender_Status_id==17(Archive)
                    //"left outer join ContractStatus on CONTRACTORS.contract_status_id = ContractStatus.contract_status_id where CONTRACTORS.cp_tender_award is not NULL and (TenderStatus.Tender_Status_id<>8 and TenderStatus.Tender_Status_id<>17) and p.FYID=" + cmbFiscalYear.SelectedValue + " and p.tender_no is not NULL " +
                }
                else if ((!cmbCommitteeNames.SelectedValue.ToString().Equals("0")) && cmbDepartments.SelectedValue.ToString().Equals("0"))
                {
                    sqlCommReport = "SELECT distinct p.tender_no, p.project_newname_en, p.project_code, Department.department_short_name, TenderTypes.tender_type_name,Replace(CONVERT(nvarchar,CONTRACTORS.cp_tender_award,106),' ','-') as cp_tender_award," +
                    "COMPANY.co_name,COMPANY.nationality,CONTRACTORS.ContractAmount,Replace(CONVERT(nvarchar,CONTRACTORS.cp_contractor_sign,106),' ','-') as cp_contractor_sign,Replace(CONVERT(nvarchar,CONTRACTORS.cp_distribution,106),' ','-') as cp_distribution,ContractStatus.ContractStatus," +
                    "CONTRACTORS.contract_no,p.proj_id FROM PROJECTS p left outer JOIN Committee c ON p.committee_id = c.committee_id left outer JOIN TenderTypes ON p.tender_type_id = TenderTypes.tender_type_id left outer JOIN TenderStatus ON p.Tender_Status_id = TenderStatus.Tender_Status_id " +
                    "left outer JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id left outer JOIN FiscalYear ON p.FYID = FiscalYear.FYID left outer JOIN Department ON p.department_id = Department.department_id left outer JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id " +
                    "left outer join ContractStatus on CONTRACTORS.contract_status_id = ContractStatus.contract_status_id where p.committee_id=" + cmbCommitteeNames.SelectedValue + " and (TenderStatus.Tender_Status_id<>8 and TenderStatus.Tender_Status_id<>17) ";
                    // Tender_Status_id==8 (Cancelled) && Tender_Status_id==17(Archive)
                    //CONTRACTORS.cp_tender_award is not NULL AND p.committee_id=" + cmbCommitteeNames.SelectedValue + " and (TenderStatus.Tender_Status_id<>8 and TenderStatus.Tender_Status_id<>17) and " +
                }
                else if ((!cmbCommitteeNames.SelectedValue.ToString().Equals("0")) && (!cmbDepartments.SelectedValue.ToString().Equals("0")))
                {
                    sqlCommReport = "SELECT distinct p.tender_no, p.project_newname_en, p.project_code, Department.department_short_name, TenderTypes.tender_type_name,Replace(CONVERT(nvarchar,CONTRACTORS.cp_tender_award,106),' ','-') as cp_tender_award," +
                    "COMPANY.co_name,COMPANY.nationality,CONTRACTORS.ContractAmount,Replace(CONVERT(nvarchar,CONTRACTORS.cp_contractor_sign,106),' ','-') as cp_contractor_sign,Replace(CONVERT(nvarchar,CONTRACTORS.cp_distribution,106),' ','-') as cp_distribution,ContractStatus.ContractStatus," +
                    "CONTRACTORS.contract_no,p.proj_id FROM PROJECTS p left outer JOIN Committee c ON p.committee_id = c.committee_id left outer JOIN TenderTypes ON p.tender_type_id = TenderTypes.tender_type_id left outer JOIN TenderStatus ON p.Tender_Status_id = TenderStatus.Tender_Status_id " +
                    "left outer JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id left outer JOIN FiscalYear ON p.FYID = FiscalYear.FYID left outer JOIN Department ON p.department_id = Department.department_id left outer JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id " +
                    "left outer join ContractStatus on CONTRACTORS.contract_status_id = ContractStatus.contract_status_id where p.committee_id=" + cmbCommitteeNames.SelectedValue + " and p.department_id=" + cmbDepartments.SelectedValue + " and (TenderStatus.Tender_Status_id<>8 and TenderStatus.Tender_Status_id<>17) ";
                    // Tender_Status_id==8 (Cancelled) && Tender_Status_id==17(Archive)
                    //CONTRACTORS.cp_tender_award is not NULL AND p.committee_id=" + cmbCommitteeNames.SelectedValue + " and (TenderStatus.Tender_Status_id<>8 and TenderStatus.Tender_Status_id<>17) and " +
                }

                if (startReportDateChanged == 0 && endReportDateChanged == 0)
                {
                    if (whereClause != null)
                    {
                        if (whereClause != "")
                        {
                            sqlCommReport = sqlCommReport + " and (CONTRACTORS.contract_no LIKE '%" + ((DataRowView)cmbCommittedYear.SelectedItem).Row.ItemArray[1].ToString() + "%') and" + whereClause + " Order by CONTRACTORS.contract_no"; //Only Committed                                                
                        }
                        else
                        {
                            sqlCommReport = sqlCommReport + " and (CONTRACTORS.contract_no LIKE '%" + ((DataRowView)cmbCommittedYear.SelectedItem).Row.ItemArray[1].ToString() + "%') Order by CONTRACTORS.contract_no"; //Only Committed                                                
                        }                         
                    }
                    else
                    {
                        sqlCommReport = sqlCommReport + " and (CONTRACTORS.contract_no LIKE '%" + ((DataRowView)cmbCommittedYear.SelectedItem).Row.ItemArray[1].ToString() + "%') Order by CONTRACTORS.contract_no"; //Only Committed                                                
                    }
                }
                else
                {
                    //sqlCommReport = "SELECT distinct PROJECTS.proj_id,PROJECTS.tender_no, PROJECTS.project_newname_en, PROJECTS.project_code, Department.department_short_name, TenderTypes.tender_type_name, " +
                    //"TenderStatus.Status_Name, CONTRACTORS.ContractAmount, CONTRACTORS.contract_no, COMPANY.co_name FROM Committee left outer JOIN PROJECTS ON Committee.committee_id = PROJECTS.committee_id left outer JOIN " +
                    //"TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id left outer JOIN TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id left outer JOIN CONTRACTORS ON PROJECTS.proj_id = CONTRACTORS.proj_id left outer JOIN " +
                    //"FiscalYear ON PROJECTS.FYID = FiscalYear.FYID left outer JOIN Department ON PROJECTS.department_id = Department.department_id left outer JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id " +
                    //" where PROJECTS.committee_id=" + cmbCommitteeNames.SelectedValue + " and PROJECTS.FYID=" + cmbFiscalYear.SelectedValue + " and PROJECTS.tender_no is not NULL Order by PROJECTS.tender_no";
                    if (whereClause != null)
                    {
                        if (whereClause != "")
                        {
                            sqlCommReport = sqlCommReport + " AND (CONTRACTORS.cp_tender_award between '" + dtpAwardStartDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpAwardEndDate.Value.ToString("dd/MMM/yyyy") + "') and" + whereClause + " Order by CONTRACTORS.contract_no";  //Only Awarded
                        }
                        else
                        {
                            sqlCommReport = sqlCommReport + " AND (CONTRACTORS.cp_tender_award between '" + dtpAwardStartDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpAwardEndDate.Value.ToString("dd/MMM/yyyy") + "') Order by CONTRACTORS.contract_no";  //Only Awarded
                        }                         
                    }
                    else
                    {
                        sqlCommReport = sqlCommReport + " AND (CONTRACTORS.cp_tender_award between '" + dtpAwardStartDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpAwardEndDate.Value.ToString("dd/MMM/yyyy") + "') Order by CONTRACTORS.contract_no";  //Only Awarded
                    }
                }

                //MessageBox.Show("Before Query Execution :" + sqlCommReport);

                dtAwardedContracts = AwardedContracts(dtAwardedContracts, sqlCommReport);
                if (dtAwardedContracts == null)
                    MessageBox.Show("DataTable is Null");
                else
                {
                    StringBuilder strBuildObj = new StringBuilder();
                    strBuildObj.Append("<table width='100%' cellpadding='0' cellspacing='0' style='border: solid 1px;'> <tr><td colspan='15' style='font-family:Century Gothic;text-align:center;height: 35px;font-size: 11pt ;");
                    strBuildObj.Append(" vertical-align:middle;border: solid 1px;background-color:#C0D9AF'><b>CONTRACTS DEPARTMENT - CONTRACTS CONTROL SECTION REPORT</b></td></tr><tr><td colspan='15' style='font-family:Century Gothic;border-style: solid; border-color: inherit; border-width: 1px; text-align:center;");

                    if (cmbCommitteeNames.SelectedValue.ToString().Equals("0") && cmbDepartments.SelectedValue.ToString().Equals("0"))
                    {
                        strBuildObj.Append("font-size: 11pt;  vertical-align:middle; background-color:#808080'><b>ALL COMMITTEES AND ALL DEPARTMENTS</b></td></tr>");
                    }
                    else if (cmbCommitteeNames.SelectedValue.ToString().Equals("0") && (!cmbDepartments.SelectedValue.ToString().Equals("0")))
                    {
                        strBuildObj.Append("font-size: 11pt;  vertical-align:middle; background-color:#808080'><b>ALL COMMITTEES AND " + ((DataRowView)cmbDepartments.SelectedItem).Row.ItemArray[1].ToString() + " DEPARTMENT</b></td></tr>");
                    }
                    else if ((!cmbCommitteeNames.SelectedValue.ToString().Equals("0")) && cmbDepartments.SelectedValue.ToString().Equals("0"))
                    {
                        strBuildObj.Append("font-size: 11pt;  vertical-align:middle; background-color:#808080'><b>" + ((DataRowView)cmbCommitteeNames.SelectedItem).Row.ItemArray[1].ToString() + " AND ALL DEPARTMENTS</b></td></tr>");
                    }
                    else if ((!cmbCommitteeNames.SelectedValue.ToString().Equals("0")) && (!cmbDepartments.SelectedValue.ToString().Equals("0")))
                    {
                        strBuildObj.Append("font-size: 11pt;  vertical-align:middle; background-color:#808080'><b>" + ((DataRowView)cmbCommitteeNames.SelectedItem).Row.ItemArray[1].ToString() + " AND " + ((DataRowView)cmbDepartments.SelectedItem).Row.ItemArray[1].ToString() + " Department</b></td></tr>");
                    }
                    strBuildObj.Append("<tr><td colspan='15' style='font-family:Century Gothic;border-style: solid; border-color: inherit; border-width: 1px; text-align:center;");

                    if (startReportDateChanged == 0 && endReportDateChanged == 0)
                    {
                        strBuildObj.Append("font-size: 11pt;  vertical-align:middle; background-color:#808080'><b>Tenders for FY " + ((DataRowView)cmbCommittedYear.SelectedItem).Row.ItemArray[1].ToString() + "</b></td></tr>");
                    }
                    else
                    {
                        strBuildObj.Append("font-size: 11pt;  vertical-align:middle; background-color:#808080'><b>Tenders between " + dtpAwardStartDate.Value.ToString("dd/MMM/yyyy") + " and " + dtpAwardEndDate.Value.ToString("dd/MMM/yyyy") + "</b></td></tr>");
                    }

                    strBuildObj.Append("<tr><td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px; overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>SI.</b></td>");
                    strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Tender No.</b></td>");
                    strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Tender Title</b></td>");
                    strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Project Code</b></td>");
                    strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Department</b></td>");
                    strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Type of Tender</b></td>");
                    strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Tender Publish Date</b></td>");
                    strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px; background-color:#E6B8B7; overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Tender Award Date</b></td>");
                    strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px; background-color:#B8CCE4; overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Successful Tenderer</b></td>");
                    strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px; background-color:#EBF1DE; overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Nationality of Company</b></td>");
                    strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px; background-color:#EBF1DE; overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Awarding Value</b></td>");
                    strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px; background-color:#EBF1DE; overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Sign Date</b></td>");
                    strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px; background-color:#EBF1DE; overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Distributed Date</b></td>");
                    strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px; background-color:#EBF1DE; overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Contract Status</b></td>");
                    strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px; background-color:#EBF1DE; overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Contract No.</b></td></tr>");

                    if (dtAwardedContracts.Rows.Count != 0)
                    {
                        foreach (DataRow rowData in dtAwardedContracts.Rows)
                        {
                            strBuildObj.Append("<tr><td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[0] + "</td>");

                            strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[1] + "</td>");

                            strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[2] + "</td>");

                            strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[3] + "</td>");

                            strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[4] + "</td>");

                            strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[5] + "</td>");

                            strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[6] + "</td>");

                            strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[7] + "</td>");

                            strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[8] + "</td>");

                            strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[9] + "</td>");

                            strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[10] + "</td>");

                            strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[11] + "</td>");

                            strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[12] + "</td>");

                            strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[13] + "</td>");

                            strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[14] + "</td>");

                            strBuildObj.Append("</tr>");

                        }

                        strBuildObj.Append("<tr><td colspan='15' style=\"width:auto;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b style=\"font-style: italic\">This report is generated by TCMS dated :</b><b>" + DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss") + "</b></td></tr>");
                        lblTotRecCount.Text = "Total Records Count=" + dtAwardedContracts.Rows.Count;
                    }
                    else
                    {
                        lblTotRecCount.Text = "Total Records Count=0";
                        MessageBox.Show("No data exist for selected options", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    strBuildObj.Append("</table>");

                    webReport.DocumentText = strBuildObj.ToString();
                }
            }
                    
            webReport.ScrollBarsEnabled = true;
        }

        DataTable dtOrderedContracts = null;
        private DataTable AwardedContracts(DataTable dtAwardedContracts, string sqlCommReport)
        {
            DataTable dtAwardedContractsCommittee = dalObj.GetDataFromDB("AwardedContractsCommittee", sqlCommReport);
            if(dtAwardedContractsCommittee == null)
            {
                MessageBox.Show("dtAwardedContractsCommittee table is null");
                MessageBox.Show("Query :" + sqlCommReport);
            }
            //dtOrderedContracts = new DataTable("OrderedContracts");
            //dtOrderedContracts.Columns.Add("ProjID");
            //dtOrderedContracts.Columns.Add("ContractNo");
            //dtOrderedContracts.AcceptChanges();

            int rowCounter = 0;
            int sNoCounter = 0;
            while (rowCounter < dtAwardedContractsCommittee.Rows.Count)
            {                
                DataRow dr = dtAwardedContracts.NewRow();                 
                dr[0] = ++sNoCounter; //Sl.
                dr[1] = dtAwardedContractsCommittee.Rows[rowCounter][0]; //Tender No.
                dr[2] = dtAwardedContractsCommittee.Rows[rowCounter][1]; //Tender Title
                dr[3] = dtAwardedContractsCommittee.Rows[rowCounter][2]; //Project Code
                dr[4] = dtAwardedContractsCommittee.Rows[rowCounter][3]; //Department
                dr[5] = dtAwardedContractsCommittee.Rows[rowCounter][4]; //Type of Tender

                string sqlGetTenderPublishDateFromProjId = "SELECT REPLACE(CONVERT(nvarchar, TenderDatesInfo.ts_tender_invitation, 106), ' ', '-') AS TenderPublishDate from TenderDatesInfo inner join PROJECTS on PROJECTS.proj_id = TenderDatesInfo.proj_id " +
                "where (TenderDatesInfo.proj_id=" + dtAwardedContractsCommittee.Rows[rowCounter][13].ToString() + ") and TenderDatesInfo.ts_tender_invitation is not NULL";
                DataTable dtTenderInvitationDate = dalObj.GetDataFromDB("TenderInvitationDate", sqlGetTenderPublishDateFromProjId);
                if (dtTenderInvitationDate == null)
                {
                    MessageBox.Show("dtTenderInvitationDate table is null");
                    MessageBox.Show("Query :" + sqlGetTenderPublishDateFromProjId);
                }
                if (dtTenderInvitationDate.Rows.Count != 0)
                {
                    dr[6] = dtTenderInvitationDate.Rows[0][0]; //Tender Publish Date 
                }
                else
                {
                    dr[6] = "";
                }
                dr[7] = dtAwardedContractsCommittee.Rows[rowCounter][5]; //Tender Award Date              
                dr[8] = dtAwardedContractsCommittee.Rows[rowCounter][6]; //Successful Tenderer                
                dr[9] = dtAwardedContractsCommittee.Rows[rowCounter][7]; //Nationality of Company                  

                if (dtAwardedContractsCommittee.Rows[rowCounter][8].ToString() != "") // Awarding Value
                {
                    dr[10] = string.Format("{0:#,##0.00}", double.Parse(dtAwardedContractsCommittee.Rows[rowCounter][8].ToString()));  
                }
                else
                {
                    dr[10] = "";
                }
                dr[11] = dtAwardedContractsCommittee.Rows[rowCounter][9]; //Sign Date
                dr[12] = dtAwardedContractsCommittee.Rows[rowCounter][10]; //Distributed Date
                dr[13] = dtAwardedContractsCommittee.Rows[rowCounter][11]; //Contract Status
                dr[14] = dtAwardedContractsCommittee.Rows[rowCounter][12]; //Contract No.                              

                dtAwardedContracts.Rows.Add(dr);
                dtAwardedContracts.AcceptChanges();
                rowCounter++;                 
            }
            return dtAwardedContracts;

        }

        private string FindTotal(string sqlFindTotInvitees)
        {

            DataTable dtFindTotInvitees = dalObj.GetDataFromDB("FindTotal", sqlFindTotInvitees);
            string count = null;
            if (dtFindTotInvitees.Rows.Count != 0)
            {
                count = dtFindTotInvitees.Rows[0][0].ToString();
            }
            else
            {
                count = "0";
            }
            return count;
        }

        private string GetTendererList(string sqlFindTotInvitees)
        {

            DataTable dtTendererList = dalObj.GetDataFromDB("TendererList", sqlFindTotInvitees);

            string tendererNames = null;
            if (dtTendererList.Rows.Count != 0)
            {
                tendererNames = string.Join(",", dtTendererList.AsEnumerable()
                                .Select(x => x["co_name"].ToString())
                                .ToArray());
            }
            else
            {
                tendererNames = "";
            }
            return tendererNames;
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            comCls.ExportToExcel(webReport);
        }

        private void cmbCommittedYear_SelectedIndexChanged(object sender, EventArgs e)
        {
            startReportDateChanged = 0;
            endReportDateChanged = 0;                         
        }

        private void dtpAwardStartDate_ValueChanged(object sender, EventArgs e)
        {
            startReportDateChanged = 1;
        }

        private void dtpAwardEndDate_ValueChanged(object sender, EventArgs e)
        {
            endReportDateChanged = 1;
        }

        private void cmbCommittedYear_Enter(object sender, EventArgs e)
        {
            startReportDateChanged = 0;
            endReportDateChanged = 0;    
        }           
 
    }
}
