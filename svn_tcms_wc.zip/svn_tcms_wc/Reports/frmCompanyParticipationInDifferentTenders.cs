﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TenderTrackingSystem;
using System.Configuration;
using System.Data.SqlClient;

namespace MDI_ParenrForm.Reports
{
    public partial class frmCompanyParticipationInDifferentTenders : Form
    {
        DAL dalObj = null;
        CommonClass comCls = null;
        IList<string> mUserRightsCollComm = null;
        private string strCon = ConfigurationManager.AppSettings["TCMSConnString"].ToString();

        public frmCompanyParticipationInDifferentTenders(IList<string> userRightsCollComm)
        {
            InitializeComponent();
            dalObj = new DAL();
            comCls = new CommonClass("");
            mUserRightsCollComm = userRightsCollComm;
            GetCompanies();
        }

        /// <summary>
        /// Created by Varun on 19/02/14, for Retrieving All Contractors
        /// </summary>
        private void GetCompanies()
        {
            SqlConnection sqlConn = new SqlConnection(strCon);
            DataTable dtContractors = null;
            try
            {
                sqlConn.Open();
                DAL dalObj = new DAL();
                string sqlContractorQuery = "";
                sqlContractorQuery = "SELECT DISTINCT COMPANY.co_id, COMPANY.co_name FROM COMPANY ORDER BY COMPANY.co_name";
                dtContractors = dalObj.GetDataFromDB("Companies", sqlContractorQuery);
              
                cmbCompanyName.DataSource = dtContractors;
                cmbCompanyName.DisplayMember = "co_name";
                cmbCompanyName.ValueMember = "co_id";
                cmbCompanyName.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }

        }

        private void frmCompanyParticipationInDifferentTenders_Load(object sender, EventArgs e)
        {
                         
        }

        private void GenerateReport()
        {
            //if (txtCompanyName.Text != "")
            //{
                DataTable dtFinal = new DataTable("FinalReport");
                dtFinal.Columns.Add("SNo.");
                dtFinal.Columns.Add("TenderNo");
                dtFinal.Columns.Add("ProjectCode");
                dtFinal.Columns.Add("ProjectTitle");
                dtFinal.Columns.Add("TendrersName");                
                dtFinal.Columns.Add("TenderStatus");     
                dtFinal.Columns.Add("IssueDate");
                dtFinal.Columns.Add("FinalClosingDate");
                dtFinal.Columns.Add("SuccessfulBidder");
                dtFinal.Columns.Add("ContractNo");
                dtFinal.Columns.Add("DepartmentName");
                dtFinal.AcceptChanges();

                Int16 rowCounter = 1;
                string sqlCompanyParticipationQuery = null;

                //sqlCompanyParticipationQuery = "SELECT PROJECTS.proj_id, PROJECTS.tender_no, PROJECTS.project_code, PROJECTS.project_newname_en, COMPANY.co_name, PROJECTS.EligibleTenderTypes, TenderStatus.Status_Name, TenderDatesInfo.ptd_tendec_doc_cur_status, COMPANY_CAT.co_category_name, TenderDatesInfo.ts_tender_issue, " +
                //"Committee.committee_short_name, Department.Department FROM TenderDatesInfo INNER JOIN PROJECTS ON TenderDatesInfo.proj_id = PROJECTS.proj_id INNER JOIN STAGES ON TenderDatesInfo.stage_id = STAGES.stage_id INNER JOIN TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id INNER JOIN " +
                //"Department ON Department.department_id = PROJECTS.department_id INNER JOIN COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id INNER JOIN COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id INNER JOIN Committee ON PROJECTS.committee_id = Committee.committee_id WHERE (COMPANY.co_id = " +
                //cmbCompanyName.SelectedValue + ")";

                sqlCompanyParticipationQuery = "SELECT PROJECTS.proj_id, PROJECTS.tender_no, PROJECTS.project_code, PROJECTS.project_newname_en, COMPANY.co_name, CONTRACTORS.contract_no,TenderStatus.Status_Name, d2.Department, COMPANY.co_id " +
                "FROM CONTRACTORS INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN PROJECTS ON PROJECTS.proj_id = CONTRACTORS.proj_id INNER JOIN TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id INNER JOIN " +
                "Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id where CONTRACTORS.proj_id in (select proj_id from TenderDatesInfo WHERE (TenderDatesInfo.co_id = " + cmbCompanyName.SelectedValue + "))";

                DataTable dtCompanyParticipationReports = dalObj.GetDataFromDB("CompanyParticipationReports", sqlCompanyParticipationQuery);

                if (dtCompanyParticipationReports.Rows.Count != 0)
                {
                    SqlConnection sqlCn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString());
                    sqlCn.Open();
                    foreach (DataRow drFilteredRecords in dtCompanyParticipationReports.Rows)
                    {
                        //DataRow[] drs = dtPTDReports.Select("project_code='" + m.id + "'");
                        DataRow dr = dtFinal.NewRow();
                        dr[0] = rowCounter;             
                        dr[1] = drFilteredRecords[1];
                        dr[2] = drFilteredRecords[2];
                        dr[3] = drFilteredRecords[3];
                        dr[4] = cmbCompanyName.Text;
                        dr[5] = drFilteredRecords[6];
                        dr[6] = GetDates(dr, "select Replace(Convert(nvarchar,ts_tender_issue,106),' ','-') as IssueDate from TenderDatesInfo where proj_id=" + drFilteredRecords[0] + " and stage_id=2 and ts_tender_issue is not Null and co_id=" +
                        drFilteredRecords[8], sqlCn, "IssueDate", null, 6);
                        dr[7] = GetDates(dr, "select Replace(Convert(nvarchar,TenderDatesInfo.ts_closing_s1,106),' ','-') AS ts_closing_s1,Replace(Convert(nvarchar,TenderDatesInfo.ts_modified_closing,106) ,' ','-') AS ts_modified_closing " +
                        "from TenderDatesInfo where proj_id=" + drFilteredRecords[0] + " and stage_id=2 and ts_tender_issue is Null", sqlCn, "ts_modified_closing", "ts_closing_s1", 7);
                        dr[8] = drFilteredRecords[4]; //Successful Bidder Name
                        dr[9] = drFilteredRecords[5]; // Contract No.
                      

                        dr[10] = drFilteredRecords[7];                        
                        dtFinal.Rows.Add(dr);
                        dtFinal.AcceptChanges();
                        rowCounter++;
                    }
                    sqlCn.Close();
                }

                StringBuilder strBuilder = new StringBuilder();
                if (dtFinal.Rows.Count == 0)
                {
                    lblTotRecCount.Text = "Total Records Count=0";
                    MessageBox.Show("No Records Found");
                }
                else
                    lblTotRecCount.Text = "Total Records Count=" + dtFinal.Rows.Count;

                strBuilder = CreateStaffJobTrackingReport(strBuilder, dtFinal);
                webReport.DocumentText = strBuilder.ToString();
                webReport.ScrollBarsEnabled = true;
             
        }


        private string GetDates(DataRow dr,string sqlQuery, SqlConnection sqlCn, string colName1, string colName2,int idx)
        {
            string value = null;
            SqlCommand sqlCommand = new SqlCommand(sqlQuery, sqlCn);
            SqlDataReader sqlDtReader = sqlCommand.ExecuteReader();
            if (sqlDtReader.Read())
            {
                if (colName2 != null)
                {
                    if (sqlDtReader[colName2].ToString() != "")
                        value = sqlDtReader[colName2].ToString();
                    else
                        value = sqlDtReader[colName1].ToString();
                }
                else
                {
                    value = sqlDtReader[colName1].ToString();
                }                
            }
            sqlCommand.Dispose();
            sqlDtReader.Close();
            return value;
        }

        private void btnGenerateReport_Click(object sender, EventArgs e)
        {
            GenerateReport();          
        }        

        private StringBuilder CreateStaffJobTrackingReport(StringBuilder strBuilder, DataTable dtReports)
        {
            strBuilder.Append("<table style='border: solid 1px #506E87; width:100%'><tr>");

            strBuilder.Append("<td colspan='11' style='text-align:center;height: 35px;font-size: 18pt !important;text-decoration: underline;font-weight:bold;background-color:#C0D9AF;vertical-align:middle;border: solid 1px #4E4949;'><b><u>Reports of Company Participating in Different Tenders</u></b></td></tr>");
            //strBuilder.Append("<tr><td colspan='10' style='text-align: center;font-size: 12pt;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;'><b>Awarded Contracts for Fiscal Year: " + dtProjectIds.Rows[0][1] + "</b></td></tr>");
            //strBuilder.Append("<tr><td colspan='10' style='text-align: center;font-size: 12pt;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;' >Name of the Contractor/Vendor: <b>" + dtView.Row.ItemArray[1].ToString() + "</b></td></tr>");

            strBuilder.Append("<tr>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>SNo.</b></td>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>Tender Number</b></td>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>Project Code</b></td>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>Project/Tender Title</b></td>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>Tenderer's Name</b></td>" +             
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>Tender Status</b></td>" +            
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>Issuing Date</b></td>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>Final Closing Date</b></td>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>Successful Bidder</b></td>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>Contract No.</b></td>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>Department</b></td></tr>");

            //foreach (DataRow projIds in dtReports.Rows)
            //{

            //string sqlContractDetailsQuery = "SELECT DISTINCT CONTRACTORS.contract_no, PROJECTS.project_code, CONTRACTORS.ContractTitle, TenderDatesInfo.ts_tender_invitation, CONTRACTORS.cp_tender_award, CONTRACTORS.cp_contractor_sign, " +
            //"CONTRACTORS.ContractAmount, CONTRACTORS.StartDate, CONTRACTORS.FinishDate, ContractStatus.ContractStatus FROM CONTRACTORS INNER JOIN " +
            //"COMPANY ON COMPANY.co_id = CONTRACTORS.co_id INNER JOIN ContractStatus ON ContractStatus.contract_status_id = CONTRACTORS.contract_status_id INNER JOIN PROJECTS ON CONTRACTORS.proj_id = PROJECTS.proj_id " +
            //"INNER JOIN TenderDatesInfo ON CONTRACTORS.proj_id = TenderDatesInfo.proj_id WHERE (CONTRACTORS.co_id =" + coId + ") AND (CONTRACTORS.proj_id =" + projIds[0] + ") AND (CONTRACTORS.contract_no IS NOT NULL) AND (CONTRACTORS.contract_no <> ' ') " +
            //"GROUP BY CONTRACTORS.contract_no, PROJECTS.project_code, CONTRACTORS.ContractTitle, TenderDatesInfo.ts_tender_invitation, CONTRACTORS.ContractAmount, CONTRACTORS.StartDate, CONTRACTORS.FinishDate, CONTRACTORS.cp_tender_award, ContractStatus.ContractStatus, " +
            //"CONTRACTORS.cp_contractor_sign";

            //DataTable dtContractorDetails = dalObj.GetDataFromDB("ContractDetails", sqlContractDetailsQuery);

            if (dtReports.Rows.Count != 0)
            {
                foreach (DataRow colData in dtReports.Rows)
                {
                    strBuilder.Append("<tr>");
                    strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'>" + colData[0] + "</td>");
                    strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'>" + colData[1] + "</td>");
                    //if (colData[2] != DBNull.Value)
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'>" + colData[2].ToString() + "</td>");
                    //else
                    //    strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'></td>");
                    //if (colData[3] != DBNull.Value)
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'>" + colData[3].ToString() + "</td>");
                    //else
                    //    strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'></td>");
                    //if (colData[4] != DBNull.Value)
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'>" + colData[4].ToString() + "</td>");
                    //else
                    //    strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'></td>");
                    //if (colData[5] != DBNull.Value)
                    //    strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'>" + colData[5] + "</td>");
                    //else
                    //    strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'></td>");
                    //if (colData[5] != DBNull.Value)
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'>" + colData[5].ToString() + "</td>");
                    //else
                    //    strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'></td>");
                    //if (colData[7] != DBNull.Value)
                    //    strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'>" + colData[7] + "</td>");
                    //else
                    //    strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'></td>");
                    //if (colData[8] != DBNull.Value)
                    //    strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'>" + colData[8] + "</td>");
                    //else
                    //    strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'></td>");
                    //if (colData[6] != DBNull.Value)
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'>" + colData[6].ToString() + "</td>");
                    //else
                    //    strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'></td>");
                    //if (colData[7] != DBNull.Value)
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'>" + colData[7].ToString() + "</td>");
                    //else
                    //    strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'></td>");
                    //if (colData[11] != DBNull.Value)
                    //    strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'>" + colData[11] + "</td>");
                    //else
                    //    strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'></td>");
                    //if (colData[8] != DBNull.Value)
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'>" + colData[8].ToString() + "</td>");
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'>" + colData[9].ToString() + "</td>");
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'>" + colData[10].ToString() + "</td>");
                    //else
                    //    strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'></td>");

                    strBuilder.Append("</tr>");
                }
                strBuilder.Append("<tr><td colspan='11' style=\"width:auto;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b style=\"font-style: italic\">This report is generated by TCMS dated :</b><b>" + DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss") + "</b></td></tr>");
                strBuilder.Append("</table>");
            }
            else
            {
                MessageBox.Show("No data exist for selected options", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                strBuilder.Append("</table>");
            }
            //dtContractorDetails.Rows.Clear();
            return strBuilder;
        }
        
        private void btnExportToExcel_Click(object sender, EventArgs e)
        {
            comCls.ExportToExcel(webReport);
        }    
    }
}
