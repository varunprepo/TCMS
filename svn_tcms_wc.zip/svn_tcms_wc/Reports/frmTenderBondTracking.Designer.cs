﻿namespace MDI_ParenrForm.Reports
{
    partial class frmTenderBondTracking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbCommitteeNames = new System.Windows.Forms.ComboBox();
            this.cmbFiscalYear = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSubmitReport = new System.Windows.Forms.Button();
            this.btnExport = new System.Windows.Forms.Button();
            this.webReport = new System.Windows.Forms.WebBrowser();
            this.lblTotRecCount = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cmbCommitteeNames
            // 
            this.cmbCommitteeNames.FormattingEnabled = true;
            this.cmbCommitteeNames.Location = new System.Drawing.Point(12, 41);
            this.cmbCommitteeNames.Name = "cmbCommitteeNames";
            this.cmbCommitteeNames.Size = new System.Drawing.Size(196, 21);
            this.cmbCommitteeNames.TabIndex = 0;
            // 
            // cmbFiscalYear
            // 
            this.cmbFiscalYear.FormattingEnabled = true;
            this.cmbFiscalYear.Location = new System.Drawing.Point(265, 41);
            this.cmbFiscalYear.Name = "cmbFiscalYear";
            this.cmbFiscalYear.Size = new System.Drawing.Size(121, 21);
            this.cmbFiscalYear.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Committee Names";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(268, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Fiscal Year";
            // 
            // btnSubmitReport
            // 
            this.btnSubmitReport.Location = new System.Drawing.Point(106, 97);
            this.btnSubmitReport.Name = "btnSubmitReport";
            this.btnSubmitReport.Size = new System.Drawing.Size(100, 23);
            this.btnSubmitReport.TabIndex = 32;
            this.btnSubmitReport.Text = "Generate Report";
            this.btnSubmitReport.UseVisualStyleBackColor = true;
            this.btnSubmitReport.Click += new System.EventHandler(this.btnSubmitReport_Click);
            // 
            // btnExport
            // 
            this.btnExport.BackColor = System.Drawing.Color.Coral;
            this.btnExport.Location = new System.Drawing.Point(212, 97);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(103, 23);
            this.btnExport.TabIndex = 31;
            this.btnExport.Text = "Export To Excel";
            this.btnExport.UseVisualStyleBackColor = false;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // webReport
            // 
            this.webReport.Location = new System.Drawing.Point(18, 141);
            this.webReport.MinimumSize = new System.Drawing.Size(20, 20);
            this.webReport.Name = "webReport";
            this.webReport.Size = new System.Drawing.Size(1091, 451);
            this.webReport.TabIndex = 33;
            // 
            // lblTotRecCount
            // 
            this.lblTotRecCount.AutoSize = true;
            this.lblTotRecCount.Location = new System.Drawing.Point(18, 611);
            this.lblTotRecCount.Name = "lblTotRecCount";
            this.lblTotRecCount.Size = new System.Drawing.Size(0, 13);
            this.lblTotRecCount.TabIndex = 34;
            // 
            // frmTenderBondTracking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1121, 636);
            this.Controls.Add(this.lblTotRecCount);
            this.Controls.Add(this.webReport);
            this.Controls.Add(this.btnSubmitReport);
            this.Controls.Add(this.btnExport);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbFiscalYear);
            this.Controls.Add(this.cmbCommitteeNames);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmTenderBondTracking";
            this.Text = "Tender Bond Tracking Report";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbCommitteeNames;
        private System.Windows.Forms.ComboBox cmbFiscalYear;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnSubmitReport;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.WebBrowser webReport;
        private System.Windows.Forms.Label lblTotRecCount;
    }
}