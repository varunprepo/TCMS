﻿namespace MDI_ParenrForm.Reports
{
    partial class frmContractorQatariShareReports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.btnExportToExcel = new System.Windows.Forms.Button();
            this.lblContractorOrCompany = new System.Windows.Forms.Label();
            this.wbReport = new System.Windows.Forms.WebBrowser();
            this.cmbContractorOrCompanyName = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btnExportToExcel
            // 
            this.btnExportToExcel.BackColor = System.Drawing.Color.Goldenrod;
            this.btnExportToExcel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExportToExcel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnExportToExcel.Location = new System.Drawing.Point(588, 12);
            this.btnExportToExcel.Name = "btnExportToExcel";
            this.btnExportToExcel.Size = new System.Drawing.Size(112, 32);
            this.btnExportToExcel.TabIndex = 4;
            this.btnExportToExcel.Text = "Export To Excel";
            this.btnExportToExcel.UseVisualStyleBackColor = false;
            this.btnExportToExcel.Click += new System.EventHandler(this.btnExportToExcel_Click);
            // 
            // lblContractorOrCompany
            // 
            this.lblContractorOrCompany.AutoSize = true;
            this.lblContractorOrCompany.Location = new System.Drawing.Point(22, 22);
            this.lblContractorOrCompany.Name = "lblContractorOrCompany";
            this.lblContractorOrCompany.Size = new System.Drawing.Size(133, 13);
            this.lblContractorOrCompany.TabIndex = 34;
            this.lblContractorOrCompany.Text = "Enter Contractor/Company";
            // 
            // wbReport
            // 
            this.wbReport.Location = new System.Drawing.Point(12, 50);
            this.wbReport.MinimumSize = new System.Drawing.Size(23, 20);
            this.wbReport.Name = "wbReport";
            this.wbReport.Size = new System.Drawing.Size(696, 408);
            this.wbReport.TabIndex = 36;
            // 
            // cmbContractorOrCompanyName
            // 
            this.cmbContractorOrCompanyName.FormattingEnabled = true;
            this.cmbContractorOrCompanyName.Location = new System.Drawing.Point(161, 19);
            this.cmbContractorOrCompanyName.Name = "cmbContractorOrCompanyName";
            this.cmbContractorOrCompanyName.Size = new System.Drawing.Size(251, 21);
            this.cmbContractorOrCompanyName.TabIndex = 37;
            this.cmbContractorOrCompanyName.SelectionChangeCommitted += new System.EventHandler(this.cmbContractorOrCompanyName_SelectionChangeCommitted);
            this.cmbContractorOrCompanyName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbContractorOrCompanyName_KeyPress);
            // 
            // frmContractorQatariShareReports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(712, 470);
            this.Controls.Add(this.cmbContractorOrCompanyName);
            this.Controls.Add(this.wbReport);
            this.Controls.Add(this.lblContractorOrCompany);
            this.Controls.Add(this.btnExportToExcel);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmContractorQatariShareReports";
            this.Text = "Contractors Qatari/Non Qatari/JV Share";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Button btnExportToExcel;
        private System.Windows.Forms.Label lblContractorOrCompany;
        private System.Windows.Forms.WebBrowser wbReport;
        private System.Windows.Forms.ComboBox cmbContractorOrCompanyName;
    }
}