﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TenderTrackingSystem;

namespace MDI_ParenrForm.Reports
{
    public partial class frmTenderCommAward : Form
    {
        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();
        private DAL dalObj = null;
        string whereClause = null;
        string fiscalYear = null;
        string tenderYear = null;
        public frmTenderCommAward()
        {
            InitializeComponent();
            try
            {
                //dalObj = new DAL();
                //dalObj.populateCmbBox("select committee_id,committee_name from Committee", cmbCommitteeNames);
                dalObj = new DAL();
                DataTable dtCommitteeNames = dalObj.GetDataFromDB("CommitteeNames", "select committee_id,committee_name from Committee");
                DataRow row = dtCommitteeNames.NewRow();
                row["committee_name"] = "All Committees";
                row["committee_id"] = 0;
                dtCommitteeNames.Rows.Add(row);
                cmbCommitteeNames.DataSource = dtCommitteeNames;
                cmbCommitteeNames.DisplayMember = "committee_name";
                cmbCommitteeNames.ValueMember = "committee_id";
                cmbCommitteeNames.SelectedIndex = cmbCommitteeNames.FindStringExact("All Committees");

                dalObj.populateCmbBox("select FYID,FiscalYear from FiscalYear order by FiscalYear desc", cmbFiscalYear, true);
                dalObj.populateCmbBox("select FYID,FiscalYear from FiscalYear order by FiscalYear desc", cmbTenderYear, true);
            }
            catch (Exception)
            {
                MessageBox.Show("Error Occurred while populating the combobox", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                 
            }
           
        }        

        private void btnSubmitReport_Click(object sender, EventArgs e)
        {
            DataRowView dtViewFY = null;
            DataRowView dtViewTY = null;
            if (cmbFiscalYear.SelectedItem == null)
            {
                fiscalYear = "";
            }
            else
            {
                dtViewFY = (DataRowView)cmbFiscalYear.SelectedItem;
                fiscalYear = dtViewFY.Row.ItemArray[1].ToString();
            }

            if (cmbTenderYear.SelectedItem == null)
            {
                tenderYear = "";
            }
            else
            {
                dtViewTY = (DataRowView)cmbTenderYear.SelectedItem;
                tenderYear = dtViewTY.Row.ItemArray[1].ToString();
            }
            if(fiscalYear.Equals("") && tenderYear.Equals(""))
            {
                MessageBox.Show("Select at least one combobox FiscalYear or TenderYear", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cmbFiscalYear.Focus();
                return;
            }
            StringBuilder sblTenderTracking = new StringBuilder();
            webReport.DocumentText = getTenderCommitteeHeader(sblTenderTracking).ToString();
            webReport.ScrollBarsEnabled = true;           
        }


        private StringBuilder getTenderCommitteeHeader(StringBuilder sblTenderTracking)
        {
            try
            {
                //string strTenderCommitteeQuery = "select p.proj_id,p.project_newname_en,p.tender_no,d.Department,td.stage_id,td.ptd_receive_on,p.tender_type_id,t.tender_type_name,td.ts_receive_on,td.ts_closing_s1,td.ts_closing_s2,td.eval_tech_sent1,td.eval_tech_receive1,td.eval_com_sent1,td.eval_com_receive1,td.eval_tender_award_approval,td.eval_no_of_meetings,c.co_name,c.co_id,contr.ContractAmount,contr.contract_no,pcost.budgeted_cost,pcost.estimated_cost,tstatus.[TenderStatusShortName],td.remarks" +
                //" from	PROJECTS p" +
                //" left outer JOIN TenderDatesInfo as td on p.proj_id=td.proj_id" +
                //" inner join Department as d on p.department_id=d.department_id" +
                //" inner join [TenderTypes] as t on p.tender_type_id = t.tender_type_id" +
                //" left outer join CONTRACTORS as contr on p.proj_id=contr.proj_id" +
                //" left outer join COMPANY as c on contr.co_id=c.co_id" +
                //" inner join [TenderStatus] as tstatus on p.Tender_Status_id=tstatus.Tender_Status_id" +
                //" left outer join ProjectCost as pcost on p.proj_id=pcost.proj_id where p.tender_no <>'' and td.eval_tender_opening " +
                //"between '" + dtpStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpEndReportDate.Value.ToString("dd/MMM/yyyy") + "'";
                string strTenderCommitteeQuery = null;
                

                strTenderCommitteeQuery = "select p.proj_id,p.project_newname_en,p.tender_no,p.project_code,d2.Department,td.stage_id,td.ptd_receive_on,p.tender_type_id,t.tender_type_name,td.ts_tender_issue," +
                "td.eval_tender_doc_receive_from_cd,td.ts_closing_s1,td.ts_closing_s2,td.eval_tech_sent1,td.TPWD1,td.eval_tech_receive1,td.eval_com_sent1,td.FPWD1,td.eval_com_receive1,td.eval_tender_award_approval," +
                "td.eval_no_of_meetings,c.co_name,c.co_id,contr.ContractAmount,contr.contract_no,pcost.estimated_cost,tstatus.[TenderStatusShortName],td.remarks" +
                " from PROJECTS p inner JOIN TenderDatesInfo as td on p.proj_id=td.proj_id" +
                " inner join Department2 as d1 on p.department_id=d1.department_id" +
                " inner join Department2 as d2 on d1.newDepID=d2.department_id" +
                " inner join [TenderTypes] as t on p.tender_type_id = t.tender_type_id" +
                " inner join CONTRACTORS as contr on p.proj_id=contr.proj_id" +
                " inner join COMPANY as c on contr.co_id=c.co_id" +
                " inner join [TenderStatus] as tstatus on p.Tender_Status_id=tstatus.Tender_Status_id INNER JOIN Committee ON p.committee_id = Committee.committee_id" +
                " inner join ProjectCost as pcost on p.proj_id=pcost.proj_id";

                if (fiscalYear != "" && tenderYear.Equals(""))
                {
                    if (!cmbCommitteeNames.SelectedValue.ToString().Equals("0"))
                    {
                        if (fiscalYear.Contains("-"))
                        {
                            strTenderCommitteeQuery = strTenderCommitteeQuery + " where Year(contr.cp_tender_award)= '" + fiscalYear.Split('-')[0] + "' or Year(contr.cp_tender_award)= '" + fiscalYear.Split('-')[1] + "' and p.committee_id=" + cmbCommitteeNames.SelectedValue;  //and td.eval_tender_opening " +
                        }
                        else
                        {
                            strTenderCommitteeQuery = strTenderCommitteeQuery + " where Year(contr.cp_tender_award)= '" + fiscalYear + "' and p.committee_id=" + cmbCommitteeNames.SelectedValue;  //and td.eval_tender_opening " +
                        }
                    }
                    else
                    {
                        if (fiscalYear.Contains("-"))
                        {
                            strTenderCommitteeQuery = strTenderCommitteeQuery + " where (Year(contr.cp_tender_award)= '" + fiscalYear.Split('-')[0] + "' or Year(contr.cp_tender_award)= '" + fiscalYear.Split('-')[1] + "')";  //and td.eval_tender_opening " +
                        }
                        else
                        {
                            strTenderCommitteeQuery = strTenderCommitteeQuery + " where Year(contr.cp_tender_award)= '" + fiscalYear + "'";  //and td.eval_tender_opening " +
                        }
                    }
                }
                else if (fiscalYear != "" && tenderYear != "")
                {
                    if (!cmbCommitteeNames.SelectedValue.ToString().Equals("0"))
                    {
                        if (fiscalYear.Contains("-"))
                        {
                            strTenderCommitteeQuery = strTenderCommitteeQuery + " where (Year(contr.cp_tender_award)= '" + fiscalYear.Split('-')[0] + "' or Year(contr.cp_tender_award)= '" + fiscalYear.Split('-')[1] + "') and p.committee_id=" + cmbCommitteeNames.SelectedValue + " and p.tender_no is not Null " +
                            "and p.FYID= " + cmbTenderYear.SelectedValue;
                        }
                        else
                        {
                            strTenderCommitteeQuery = strTenderCommitteeQuery + " where Year(contr.cp_tender_award)= '" + fiscalYear + "' and p.committee_id=" + cmbCommitteeNames.SelectedValue + " and p.tender_no is not Null " +
                            "and p.FYID= " + cmbTenderYear.SelectedValue;
                        }
                    }
                    else
                    {
                        if (fiscalYear.Contains("-"))
                        {
                            strTenderCommitteeQuery = strTenderCommitteeQuery + " where (Year(contr.cp_tender_award)= '" + fiscalYear.Split('-')[0] + "' or Year(contr.cp_tender_award)= '" + fiscalYear.Split('-')[1] + "') "+
                            "and p.tender_no is not Null and p.FYID= " + cmbTenderYear.SelectedValue;
                        }
                        else
                        {
                            strTenderCommitteeQuery = strTenderCommitteeQuery + " where Year(contr.cp_tender_award)= '" + fiscalYear + "' and p.tender_no is not Null " +
                            "and p.FYID= " + cmbTenderYear.SelectedValue;
                        }
                    }
                }
                else if (fiscalYear.Equals("") && tenderYear != "")
                {
                    if (!cmbCommitteeNames.SelectedValue.ToString().Equals("0"))
                    {
                        strTenderCommitteeQuery = strTenderCommitteeQuery + " where p.committee_id=" + cmbCommitteeNames.SelectedValue + " and p.tender_no is not Null " +
                        "and p.FYID= " + cmbTenderYear.SelectedValue;
                    }
                    else
                    {
                        strTenderCommitteeQuery = strTenderCommitteeQuery + " where p.tender_no is not Null and p.FYID= " + cmbTenderYear.SelectedValue;
                    }
                }

                SqlConnection sqlConn = new SqlConnection(strCon);
                DataTable dtTenderCommittee = null;
                sqlConn.Open();
                DAL dalObj = new DAL();
                //dtTenderCommittee = dalObj.GetDataFromDB("TenderCommitteeInfo", strTenderCommitteeQuery);
                dtTenderCommittee = dalObj.GetDataFromDB("TenderCommitteeInfo", strTenderCommitteeQuery + " Order By p.tender_no");

                //if (dtTenderCommittee.Rows.Count != 0)
                //{
                //    sblTenderTracking.Append("<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"border: solid 1px #506E87;\">");// border=\"0\"");// 
                //    sblTenderTracking.Append("<tr><td colspan=\"22\" style=\"text-align: center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;\"><b>TENDER COMMITTEE AWARD</b></td></tr>");
                //    //sblTenderTracking.Append("<tr><td colspan=\"18\" style=\"text-align: left;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #FFFF99;\"><b>Tenders Tracking Information</b></td></tr>");
                //    //sblTenderTracking.Append("<tr><td colspan=\"9\" style=\"text-align: left;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;\"><b>PREPARATION OF TENDER DOCUMENTS</b></td><td colspan=\"9\" style=\"text-align: left;height: 35px;font-size: 12pt !important;background-color: #C4D79B;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;\"><b>TENDERING OF PROJECTS</b></td></tr>");

                //    //To generate the Tender Tracking Report Header
                //    sblTenderTracking.Append("<tr>");
                //    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                //    sblTenderTracking.Append("<table border=\"0\">");
                //    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>SR</b></td></tr>");
                //    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"></td></tr>");
                //    sblTenderTracking.Append("</table>");
                //    sblTenderTracking.Append("</td>");
                //    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                //    sblTenderTracking.Append("<table border=\"0\">");
                //    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Tender</b></td></tr>");
                //    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>No.</b></td></tr>");
                //    sblTenderTracking.Append("</table>");
                //    sblTenderTracking.Append("</td>");
                //    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                //    sblTenderTracking.Append("<table border=\"0\">");
                //    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Project</b></td></tr>");
                //    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Code</b></td></tr>");
                //    sblTenderTracking.Append("</table>");
                //    sblTenderTracking.Append("</td>");
                //    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                //    sblTenderTracking.Append("<table border=\"0\">");
                //    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Tender&nbsp;Title</b></td></tr>");
                //    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b></b></td></tr>");
                //    sblTenderTracking.Append("</table>");
                //    sblTenderTracking.Append("</td>");
                //    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                //    sblTenderTracking.Append("<table border=\"0\">");
                //    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>User</b></td></tr>");
                //    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Dept.</b></td></tr>");
                //    sblTenderTracking.Append("</table>");
                //    sblTenderTracking.Append("</td>");
                //    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                //    sblTenderTracking.Append("<table border=\"0\">");
                //    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Tender No. Request</b></td></tr>");
                //    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Received</b></td></tr>");
                //    sblTenderTracking.Append("</table>");
                //    sblTenderTracking.Append("</td>");
                //    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                //    sblTenderTracking.Append("<table border=\"0\">");
                //    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Tender No. Issued</b></td></tr>");
                //    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Sent Date</b></td></tr>");
                //    sblTenderTracking.Append("</table>");
                //    sblTenderTracking.Append("</td>");
                //    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                //    sblTenderTracking.Append("<table border=\"0\">");
                //    sblTenderTracking.Append("<tr><td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Type Of Tender</b></td></tr>");
                //    sblTenderTracking.Append("<tr><td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>D.O/SH.L/P.T</b></td></tr>");
                //    sblTenderTracking.Append("</table>");
                //    sblTenderTracking.Append("</td>");
                //    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                //    sblTenderTracking.Append("<table border=\"0\">");
                //    sblTenderTracking.Append("<tr><td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Tender Doc.</b></td></tr>");
                //    sblTenderTracking.Append("<tr><td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Received</b></td></tr>");
                //    sblTenderTracking.Append("</table>");
                //    sblTenderTracking.Append("</td>");

                //    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #003366;\">");
                //    sblTenderTracking.Append("<table border=\"0\">");
                //    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #003366;color: #FFFF00;\"><b>Closing</b></td></tr>");
                //    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #003366;color: #FFFF00;\"><b>Date</b></td></tr>");
                //    sblTenderTracking.Append("</table>");
                //    sblTenderTracking.Append("</td>");

                //    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #003366;\">");
                //    sblTenderTracking.Append("<table border=\"0\">");
                //    sblTenderTracking.Append("<tr><td colspan=\"3\" style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #003366;color: #00FFFF;\"><b>Tech. Evaluation</b></td></tr>");
                //    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #003366;color: #00FFFF;\"><b>Sent</b></td>");
                //    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #003366;color: #00FFFF;\"><b>Propsosed W D</b></td>");
                //    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #003366;color: #00FFFF;\"><b>Received</b></td>");
                //    sblTenderTracking.Append("</tr></table>");
                //    sblTenderTracking.Append("</td>");

                //    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #666699;\">");
                //    sblTenderTracking.Append("<table border=\"0\">");
                //    sblTenderTracking.Append("<tr><td colspan=\"3\" style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #666699;color: #FFCC00;\"><b>Commercial  Evaluation</b></td></tr>");
                //    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #666699;color: #FFCC00;\"><b>Sent</b></td>");
                //    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #666699;color: #FFCC00;\"><b>Propsosed W D</b></td>");
                //    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #666699;color: #FFCC00;\"><b>Received</b></td>");
                //    sblTenderTracking.Append("</tr></table>");
                //    sblTenderTracking.Append("</td>");

                //    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                //    sblTenderTracking.Append("<table border=\"0\">");
                //    sblTenderTracking.Append("<tr><td colspan=\"2\" style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top:0px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Awarded</b></td></tr>");
                //    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Approval Date</b></td>");
                //    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>No. of Meeting</b></td>");
                //    sblTenderTracking.Append("</tr></table>");
                //    sblTenderTracking.Append("</td>");

                //    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #000080;\">");
                //    sblTenderTracking.Append("<table border=\"0\">");
                //    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color:#000080; color:#00FF00;\"><b>Successful</b></td></tr>");
                //    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color:#000080; color:#00FF00;\"><b>Bidder</b></td>");
                //    sblTenderTracking.Append("</tr></table>");
                //    sblTenderTracking.Append("</td>");

                //    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #CCFFFF;\">");
                //    sblTenderTracking.Append("<table border=\"0\">");
                //    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #CCFFFF;color:#000080\"><b>Award</b></td></tr>");
                //    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #CCFFFF;color:#000080\"><b>Value(QR)</b></td>");
                //    sblTenderTracking.Append("</tr></table>");
                //    sblTenderTracking.Append("</td>");

                //    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #CCFFFF;\">");
                //    sblTenderTracking.Append("<table border=\"0\">");
                //    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #CCFFFF;color:#000080\"><b>Estimate</b></td></tr>");
                //    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #CCFFFF;color:#000080\"><b>Value(QR)</b></td>");
                //    sblTenderTracking.Append("</tr></table>");
                //    sblTenderTracking.Append("</td>");

                //    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #CC99FF;\">");
                //    sblTenderTracking.Append("<table border=\"0\">");
                //    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #CC99FF;color:#FFFF00\"><b>Tender</b></td></tr>");
                //    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #CC99FF;color:#FFFF00\"><b>Status</b></td>");
                //    sblTenderTracking.Append("</tr></table>");
                //    sblTenderTracking.Append("</td>");

                //    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #CC99FF;\">");
                //    sblTenderTracking.Append("<table border=\"0\">");
                //    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #CC99FF;color:#FFFF00\"><b>Contract</b></td></tr>");
                //    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #CC99FF;color:#FFFF00\"><b>No.</b></td>");
                //    sblTenderTracking.Append("</tr></table>");
                //    sblTenderTracking.Append("</td>");

                //    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #C0C0C0;\">");
                //    sblTenderTracking.Append("<table border=\"0\">");
                //    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #C0C0C0;color:#000080\"><b>Remarks</b></td></tr>");
                //    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #C0C0C0;\"><b></b></td>");
                //    sblTenderTracking.Append("</tr></table>");
                //    sblTenderTracking.Append("</td>");

                //    sblTenderTracking.Append("</tr>");

                if (dtTenderCommittee.Rows.Count != 0)
                {
                    sblTenderTracking.Append("<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"border: solid 1px #506E87;\">");// border=\"0\"");// 
                    sblTenderTracking.Append("<tr><td colspan=\"22\" style=\"text-align: center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;\"><b>TENDER COMMITTEE AWARD</b></td></tr>");
                    //sblTenderTracking.Append("<tr><td colspan=\"18\" style=\"text-align: left;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #FFFF99;\"><b>Tenders Tracking Information</b></td></tr>");
                    //sblTenderTracking.Append("<tr><td colspan=\"9\" style=\"text-align: left;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;\"><b>PREPARATION OF TENDER DOCUMENTS</b></td><td colspan=\"9\" style=\"text-align: left;height: 35px;font-size: 12pt !important;background-color: #C4D79B;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;\"><b>TENDERING OF PROJECTS</b></td></tr>");

                    //To generate the Tender Tracking Report Header
                    sblTenderTracking.Append("<tr>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;font-weight:bold; \"><b>SR</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"></td></tr>");
                    sblTenderTracking.Append("</table>");
                    sblTenderTracking.Append("</td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;font-weight:bold; \"><b>Tender</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;font-weight:bold; \"><b>No.</b></td></tr>");
                    sblTenderTracking.Append("</table>");
                    sblTenderTracking.Append("</td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;font-weight:bold; \"><b>Project</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;font-weight:bold; \"><b>Code</b></td></tr>");
                    sblTenderTracking.Append("</table>");
                    sblTenderTracking.Append("</td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;font-weight:bold; \"><b>Tender&nbsp;Title</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px; \"><b></b></td></tr>");
                    sblTenderTracking.Append("</table>");
                    sblTenderTracking.Append("</td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;font-weight:bold; \"><b>User</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;font-weight:bold; \"><b>Dept.</b></td></tr>");
                    sblTenderTracking.Append("</table>");
                    sblTenderTracking.Append("</td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;font-weight:bold; \"><b>Tender No. Request</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;font-weight:bold; \"><b>Received</b></td></tr>");
                    sblTenderTracking.Append("</table>");
                    sblTenderTracking.Append("</td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;font-weight:bold; \"><b>Tender No. Issued</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;font-weight:bold; \"><b>Sent Date</b></td></tr>");
                    sblTenderTracking.Append("</table>");
                    sblTenderTracking.Append("</td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;font-weight:bold; \"><b>Type Of Tender</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;font-weight:bold; \"><b>D.O/SH.L/P.T</b></td></tr>");
                    sblTenderTracking.Append("</table>");
                    sblTenderTracking.Append("</td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;font-weight:bold; \"><b>Tender Doc.</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;font-weight:bold; \"><b>Received</b></td></tr>");
                    sblTenderTracking.Append("</table>");
                    sblTenderTracking.Append("</td>");

                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;font-weight:bold;\"><b>Closing</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;font-weight:bold;\"><b>Date</b></td></tr>");
                    sblTenderTracking.Append("</table>");
                    sblTenderTracking.Append("</td>");

                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td colspan=\"3\" style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;font-weight:bold;\"><b>Tech. Evaluation</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;font-weight:bold;\"><b>Sent</b></td>");
                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;font-weight:bold;\"><b>Propsosed W D</b></td>");
                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;font-weight:bold;\"><b>Received</b></td>");
                    sblTenderTracking.Append("</tr></table>");
                    sblTenderTracking.Append("</td>");

                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td colspan=\"3\" style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;font-weight:bold;\"><b>Commercial  Evaluation</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;font-weight:bold;\"><b>Sent</b></td>");
                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;font-weight:bold;\"><b>Propsosed W D</b></td>");
                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;font-weight:bold;\"><b>Received</b></td>");
                    sblTenderTracking.Append("</tr></table>");
                    sblTenderTracking.Append("</td>");

                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td colspan=\"2\" style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top:0px;height: 35px;font-weight:bold; \"><b>Awarded</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;font-weight:bold; \"><b>Approval Date</b></td>");
                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;font-weight:bold; \"><b>No. of Meeting</b></td>");
                    sblTenderTracking.Append("</tr></table>");
                    sblTenderTracking.Append("</td>");

                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;font-weight:bold;\"><b>Successful</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;font-weight:bold;\"><b>Bidder</b></td>");
                    sblTenderTracking.Append("</tr></table>");
                    sblTenderTracking.Append("</td>");

                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;font-weight:bold;\"><b>Award</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;font-weight:bold;\"><b>Value(QR)</b></td>");
                    sblTenderTracking.Append("</tr></table>");
                    sblTenderTracking.Append("</td>");

                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;font-weight:bold;\"><b>Estimate</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;font-weight:bold;\"><b>Value(QR)</b></td>");
                    sblTenderTracking.Append("</tr></table>");
                    sblTenderTracking.Append("</td>");

                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;font-weight:bold;\"><b>Tender</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;font-weight:bold;\"><b>Status</b></td>");
                    sblTenderTracking.Append("</tr></table>");
                    sblTenderTracking.Append("</td>");

                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;font-weight:bold;\"><b>Contract</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;font-weight:bold;\"><b>No.</b></td>");
                    sblTenderTracking.Append("</tr></table>");
                    sblTenderTracking.Append("</td>");

                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;font-weight:bold;\"><b>Remarks</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;\"><b></b></td>");
                    sblTenderTracking.Append("</tr></table>");
                    sblTenderTracking.Append("</td>");

                    sblTenderTracking.Append("</tr>");


                    //string strTenderCommitteeQuery = "select p.proj_id,p.project_newname_en,p.tender_no,d.Department,td.stage_id,td.eval_tender_no_request,p.tender_type_id,t.tender_type_name,td.eval_tender_doc_receive_from_cd,td.ts_closing_s1,td.ts_closing_s2,td.eval_tech_sent1,td.eval_tech_receive1,td.eval_com_sent1,td.eval_com_receive1,td.eval_tender_award_approval,td.eval_no_of_meetings,c.co_name,c.co_id,contr.ContractAmount,contr.contract_no,pcost.budgeted_cost,pcost.estimated_cost,tstatus.[Tender Statsus Short Name],td.remarks" +
                    //" from PROJECTS p,TenderDatesInfo td,Department d,[Type of Tender] t,COMPANY c,[Status of Tender] tstatus,CONTRACTORS contr,ProjectCost pcost"+
                    //" where p.proj_id=td.proj_id and p.department_id=d.department_id and p.tender_type_id=t.tender_type_id and p.proj_id=contr.proj_id and contr.co_id=c.co_id and p.Tender_Status_id=tstatus.Tender_Status_id and p.proj_id=pcost.proj_id";


                    // commented by Varun on 17/02/14 because it is written twice
                    //dtTenderCommittee = dalObj.GetDataFromDB("TenderCommitteeInfo", strTenderCommitteeQuery);

                    //DataTable dtSortedTable = dtTenderCommittee.AsEnumerable().OrderByDescending(row => row.Field<string>("tender_no")).CopyToDataTable();
                    //dtTenderCommittee = dtTenderCommittee.AsEnumerable().OrderBy(row => row.Field<string>("tender_no")).CopyToDataTable();
                    int rowCounter = 0;
                    if (dtTenderCommittee != null && dtTenderCommittee.Rows.Count > 0)
                    {
                        DataTable uniqueProjects = dtTenderCommittee.DefaultView.ToTable(true, "proj_id");
                        for (int intIndexProj = 0; intIndexProj < uniqueProjects.Rows.Count; intIndexProj++)
                        {
                            DataRow[] resultStage2 = dtTenderCommittee.Select("proj_id=" + Convert.ToInt32(uniqueProjects.Rows[intIndexProj]["proj_id"].ToString()) + " AND stage_id=2");
                            DataRow[] projectResult = dtTenderCommittee.Select("proj_id=" + Convert.ToInt32(uniqueProjects.Rows[intIndexProj]["proj_id"].ToString()) + "", "tender_no desc");
                            //DataRow[] resultStage4 = dtTenderCommittee.Select("proj_id=" + Convert.ToInt32(uniqueProjects.Rows[intIndexProj]["proj_id"].ToString()) + " AND stage_id=4");
                            DataRow[] resultStage3 = dtTenderCommittee.Select("proj_id=" + Convert.ToInt32(uniqueProjects.Rows[intIndexProj]["proj_id"].ToString()) + " AND stage_id=3");

                            if (projectResult != null && projectResult.Length > 0)
                            {
                                sblTenderTracking.Append("<tr>");
                                sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + ++rowCounter + "</td>");
                                if (projectResult[0]["tender_no"] != null)
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["tender_no"].ToString() + "</td>");
                                else
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                if (projectResult[0]["project_code"] != null)
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["project_code"].ToString() + "</td>");
                                else
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");


                                if (projectResult[0]["project_newname_en"] != null)
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["project_newname_en"].ToString() + "</td>");
                                else
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                if (projectResult[0]["Department"] != null)
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["Department"].ToString() + "</td>");
                                else
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                if (resultStage3 != null)
                                {
                                    if (resultStage3.Length > 0)
                                    {
                                        sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                        sblTenderTracking.Append("<table border=\"0\">");
                                        foreach (DataRow row in resultStage3)
                                        {
                                            sblTenderTracking.Append("<tr>");
                                            //As per Sreedhar "Tender Opening Date"
                                            if (row["ptd_receive_on"] != null)
                                            {
                                                if (row["ptd_receive_on"].ToString() != "")
                                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(row["ptd_receive_on"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                                else
                                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                            }
                                            else
                                                sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                            sblTenderTracking.Append("</tr>");
                                            break;
                                        }
                                        sblTenderTracking.Append("</table>");
                                        sblTenderTracking.Append("</td>");
                                    }
                                    else
                                        sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                }
                                else
                                {
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                }

                                //
                                if (resultStage2 != null)
                                {
                                    if (resultStage2.Length > 0)
                                    {
                                        sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                        sblTenderTracking.Append("<table border=\"0\">");
                                        foreach (DataRow row in resultStage3)
                                        {
                                            sblTenderTracking.Append("<tr>");
                                            //As per Sreedhar "Tender Doc. Recivd from CD"
                                            if (row["ts_tender_issue"] != null)
                                                if (row["ts_tender_issue"].ToString() != "")
                                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(row["ts_tender_issue"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                                else
                                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"></td>");
                                            sblTenderTracking.Append("</tr>");
                                            break;
                                        }
                                        sblTenderTracking.Append("</table>");
                                        sblTenderTracking.Append("</td>");
                                    }
                                    else
                                        sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"></td>");
                                }
                                else
                                {
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"></td>");
                                }

                                if (projectResult[0]["tender_type_name"] != null)
                                {
                                    if (projectResult[0]["tender_type_name"].ToString() != "")
                                        sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["tender_type_name"].ToString() + "</td>");
                                    else
                                        sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"></td>");
                                }
                                else
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"></td>");


                                if (resultStage3 != null && resultStage3.Length > 0)
                                {
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                    sblTenderTracking.Append("<table border=\"0\">");
                                    foreach (DataRow row in resultStage3)
                                    {
                                        sblTenderTracking.Append("<tr>");
                                        //As per Sreedhar "Tender Doc. Recivd from CD"
                                        if (row["eval_tender_doc_receive_from_cd"] != null)
                                        {
                                            if (row["eval_tender_doc_receive_from_cd"].ToString() != "")
                                                sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(row["eval_tender_doc_receive_from_cd"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                            else
                                                sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                        }
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                        sblTenderTracking.Append("</tr>");
                                        break;
                                    }
                                    sblTenderTracking.Append("</table>");
                                    sblTenderTracking.Append("</td>");
                                }
                                else
                                {
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                }

                                //
                                if (resultStage2 != null)
                                {
                                    if (resultStage2.Length > 0)
                                    {
                                        sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                        sblTenderTracking.Append("<table border=\"0\">");
                                        foreach (DataRow row in resultStage2)
                                        {
                                            sblTenderTracking.Append("<tr>");

                                            if (row["ts_closing_s1"] != null)
                                            {
                                                if (row["ts_closing_s1"].ToString() != "")
                                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(row["ts_closing_s1"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                                else
                                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"></td>");
                                            }
                                            else
                                                sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"></td>");

                                            sblTenderTracking.Append("</tr>");
                                            break;
                                        }

                                        sblTenderTracking.Append("</table>");
                                        sblTenderTracking.Append("</td>");
                                    }
                                    else
                                        sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                }
                                else
                                {
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                    sblTenderTracking.Append("<table border=\"0\"><tr>");
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                    sblTenderTracking.Append("</tr></table></td>");
                                }

                                //Tech. Evaluation
                                if (resultStage3 != null && resultStage3.Length > 0)
                                {
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                    sblTenderTracking.Append("<table border=\"0\">");
                                    foreach (DataRow row in resultStage3)
                                    {
                                        sblTenderTracking.Append("<tr>");
                                        //As per Sreedhar "Tender Doc. Recivd from CD"
                                        if (row["eval_tech_sent1"] != null && (!string.IsNullOrEmpty(row["eval_tech_sent1"].ToString())))
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(row["eval_tech_sent1"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                        if (row["TPWD1"] != null && (!string.IsNullOrEmpty(row["TPWD1"].ToString())))
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + row["TPWD1"].ToString() + "</td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                        if (row["eval_tech_receive1"] != null && (!string.IsNullOrEmpty(row["eval_tech_receive1"].ToString())))
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(row["eval_tech_receive1"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                        sblTenderTracking.Append("</tr>");
                                        break;
                                    }
                                    sblTenderTracking.Append("</table>");
                                    sblTenderTracking.Append("</td>");
                                }
                                else
                                {
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                    sblTenderTracking.Append("<table border=\"0\"><tr>");
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                    sblTenderTracking.Append("</tr></table></td>");
                                }


                                //Commercial  Evaluation
                                if (resultStage3 != null && resultStage3.Length > 0)
                                {
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                    sblTenderTracking.Append("<table border=\"0\">");
                                    foreach (DataRow row in resultStage3)
                                    {
                                        sblTenderTracking.Append("<tr>");
                                        //As per Sreedhar "Tender Doc. Recivd from CD"
                                        if (row["eval_com_sent1"] != null && (!string.IsNullOrEmpty(row["eval_com_sent1"].ToString())))
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(row["eval_com_sent1"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                        if (row["FPWD1"] != null && (!string.IsNullOrEmpty(row["FPWD1"].ToString())))
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + row["FPWD1"].ToString() + "</td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                        if (row["eval_com_receive1"] != null && (!string.IsNullOrEmpty(row["eval_com_receive1"].ToString())))
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(row["eval_com_receive1"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                        sblTenderTracking.Append("</tr>");
                                        break;
                                    }
                                    sblTenderTracking.Append("</table>");
                                    sblTenderTracking.Append("</td>");
                                }
                                else
                                {
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                    sblTenderTracking.Append("<table border=\"0\"><tr>");
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                    sblTenderTracking.Append("</tr></table></td>");
                                }

                                //Awarded
                                if (resultStage3 != null && resultStage3.Length > 0)
                                {
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                    sblTenderTracking.Append("<table border=\"0\">");
                                    foreach (DataRow row in resultStage3)
                                    {
                                        sblTenderTracking.Append("<tr>");
                                        //As per Sreedhar "Tender Doc. Recivd from CD"
                                        if (row["eval_tender_award_approval"] != null && (!string.IsNullOrEmpty(row["eval_tender_award_approval"].ToString())))
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(row["eval_tender_award_approval"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                        if (row["eval_no_of_meetings"] != null)
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + row["eval_no_of_meetings"].ToString() + "</td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</b></td>");
                                        sblTenderTracking.Append("</tr>");
                                        break;
                                    }
                                    sblTenderTracking.Append("</table>");
                                    sblTenderTracking.Append("</td>");
                                }
                                else
                                {
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                    sblTenderTracking.Append("<table border=\"0\"><tr>");
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                    sblTenderTracking.Append("</tr></table></td>");
                                }

                                if (projectResult[0]["co_name"] != null && (!string.IsNullOrEmpty(projectResult[0]["co_name"].ToString())))
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["co_name"].ToString() + "</td>");
                                else
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                if (projectResult[0]["ContractAmount"] != null && (!string.IsNullOrEmpty(projectResult[0]["ContractAmount"].ToString())))
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + string.Format("{0:#,##0.00}", double.Parse(projectResult[0]["ContractAmount"].ToString())) + "</td>");
                                else
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                //if (projectResult[0]["budgeted_cost"] != null && (!string.IsNullOrEmpty(projectResult[0]["budgeted_cost"].ToString())))
                                //    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["budgeted_cost"].ToString() + "</td>");
                                //else
                                //    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                if (projectResult[0]["estimated_cost"] != null && (!string.IsNullOrEmpty(projectResult[0]["estimated_cost"].ToString())))
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + string.Format("{0:#,##0.00}", double.Parse(projectResult[0]["estimated_cost"].ToString())) + "</td>");
                                else
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                if (projectResult[0]["TenderStatusShortName"] != null && (!string.IsNullOrEmpty(projectResult[0]["TenderStatusShortName"].ToString())))
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["TenderStatusShortName"].ToString() + "</td>");
                                else
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                if (projectResult[0]["contract_no"] != null && (!string.IsNullOrEmpty(projectResult[0]["contract_no"].ToString())))
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["contract_no"].ToString() + "</td>");
                                else
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                //
                                if (resultStage3 != null && resultStage3.Length > 0)
                                {
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                    sblTenderTracking.Append("<table border=\"0\">");
                                    foreach (DataRow row in resultStage3)
                                    {
                                        sblTenderTracking.Append("<tr>");
                                        //As per Sreedhar "remarks"
                                        if (row["remarks"] != null && (!string.IsNullOrEmpty(row["remarks"].ToString())))
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + row["remarks"].ToString() + "</td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                        sblTenderTracking.Append("</tr>");
                                        break;
                                    }
                                    sblTenderTracking.Append("</table>");
                                    sblTenderTracking.Append("</td>");
                                }
                                else
                                {
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                }

                                sblTenderTracking.Append("</tr>");
                            }
                        }
                    }
                    sblTenderTracking.Append("<tr><td colspan=\"22\" style=\"width:auto;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b style=\"font-style: italic\">This report is generated by TCMS dated :</b><b>" + DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss") + "</b></td></tr>");
                    sblTenderTracking.Append("</table>");
                    lblTotalNoOfRecords.Text = "Total Records Count=" + rowCounter.ToString();
                }
                else
                {
                    lblTotalNoOfRecords.Text = "Total Records Count=0";
                    MessageBox.Show("No data exist for selected options", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Occurred while retrieving the information", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return sblTenderTracking;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="strTenderTrackingQuery"></param>
        /// <returns></returns>
        private string generatedynamicSQLQuery(string strTenderTrackingQuery)
        {
            string strCondition = null;
            //string strTenderTrackingQuery = string.Empty;
            try
            {                
                //strTenderTrackingQuery = "select p.proj_id,p.project_newname_en,p.project_code,p.Affair_id,td.ptd_receive_on,td.stage_id,td.ptd_purpose,td.ptd_assign_qs,td.ptd_sent_for_rev,td.ptd_qs_working_status,td.ptd_tendec_doc_cur_status,td.ptd_forwarded_to_dep,td.ts_receive_on,td.ts_issue_handling,td.ts_return_to_dept,td.ts_receive_from_dept,p.tender_no,td.ts_pr_advertise,td.ts_tender_issue,td.ts_closing_s1,td.ts_modified_closing from PROJECTS p,TenderDatesInfo td where p.proj_id=td.proj_id";                 

                if (cmbCommitteeNames.SelectedValue != null)
                {
                    if (!string.IsNullOrEmpty(strCondition))
                    {
                        if (cmbCommitteeNames.SelectedValue.ToString() != "0")
                        {
                            strCondition = strCondition + " AND " + "p.contract_type_id=" + cmbCommitteeNames.SelectedValue + "";
                        }
                    }
                    else
                    {
                        if (cmbCommitteeNames.SelectedValue.ToString() != "0")
                        {
                            strCondition = "p.contract_type_id=" + cmbCommitteeNames.SelectedValue + "";
                        }
                    }
                }
                
                    if (cmbFiscalYear.SelectedValue != null)
                    {
                        if (!string.IsNullOrEmpty(strCondition))
                        {
                            if (cmbFiscalYear.SelectedValue.ToString() != "0")
                            {
                                strCondition = strCondition + " AND " + "p.FYID=" + cmbFiscalYear.SelectedValue + "";
                            }
                        }
                        else
                        {
                            if (cmbFiscalYear.SelectedValue.ToString() != "0")
                            {
                                strCondition = "p.FYID=" + cmbFiscalYear.SelectedValue + "";
                            }
                        }
                    }               

                 

                if (!string.IsNullOrEmpty(strCondition))
                {
                    if (!(strTenderTrackingQuery.Contains("where") || strTenderTrackingQuery.Contains("WHERE")))
                    {
                        strTenderTrackingQuery = strTenderTrackingQuery + " where " + strCondition + whereClause;
                    }
                    else
                    {
                        strTenderTrackingQuery = strTenderTrackingQuery + " and " + strCondition + whereClause;
                    }
                }
                else
                {
                    if (whereClause != "")
                    {
                        strTenderTrackingQuery = strTenderTrackingQuery + " where " + whereClause.Substring(4);
                    }
                }
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            return strTenderTrackingQuery;
        }


        private void btnExport_Click(object sender, EventArgs e)
        {
            CommonClass cls = new CommonClass("");
            cls.ExportToExcel(webReport);
        }
    }
}
