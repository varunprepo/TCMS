﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;
using System.Configuration;
using TenderTrackingSystem;
using System.Web.UI;
//using System.Web.HttpContext.Current.Response;
using System.Xml;

namespace MDI_ParenrForm.Reports
{
    public partial class frmReports : Form
    {
        string ID="Administrator";
        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();
        //private string strCon = @"Data Source=PWACATO\PWACATO;Initial Catalog=TCMS-Test;Integrated Security=True;;";
        private string strReportChoice = string.Empty;
        CommonClass comCls = null;
        IList<string> userRightsColl = new List<string>();
        private string mAffairShortName = "";
        private string mCommitteeShortName = "";


        public frmReports(IList<string> userRightsCollComm, string affairShortName, string committeeShortName, string profileID)
        {
            InitializeComponent();
            userRightsColl = userRightsCollComm;

            if (!userRightsCollComm.Contains("88"))
                lnkTndrTracking.Visible = true;

            if (!userRightsCollComm.Contains("90"))
                lnkTndrCmt.Visible = true;

            if (!userRightsCollComm.Contains("91"))
                linkProjTracking.Visible = true;

            if (!userRightsCollComm.Contains("89")) //Other Types Of Reports
            {
                grpBoxOtherReports.Visible = true;
                if (profileID == "5" || profileID == "7" || profileID == "19" || profileID == "22" || profileID == "36") //7=="Tendering Stage" 5=="EBSD" 36=="TENDER and COMMITTEE" 22=="TENDER COMMITTEE- ITC - STC" 19=="TENDER COMMITTEE - GTC" 
                { 
                    linkLabel1.Visible = false;
                    linkTotTndrApprovalDays.Visible = false;
                    linkContractorDetails.Visible = false;
                    linkStaffJobTrackDetails.Visible = false;
                    linkAwardedTenders.Visible = false;
                    linkContractorQatariNonQatariShare.Visible = false;
                    linkCoParticipationInDiffTenders.Visible = false;
                    linkQSWorkingStatus.Visible = false;
                    linkShowContracts.Visible = false;
                    linkCntrAmnt.Visible = false;
                    linkTenderingRecs.Visible = false;
                    lnkContractsInfo.Visible = false; 
                }

            }
                       
            if (!userRightsCollComm.Contains("106"))
                TenderCommittee.Visible = true;

            if (!userRightsCollComm.Contains("108"))
                CommittedContacts.Visible = true;

            if (!userRightsCollComm.Contains("109"))
                linkWorkOrder.Visible = true;

            if (!userRightsCollComm.Contains("116"))
                lnkTndrCmtAward.Visible = true;

            if (!userRightsCollComm.Contains("117"))
                lnkTdrBondTracking.Visible = true;

            comCls = new CommonClass("");
            mAffairShortName = affairShortName;
            mCommitteeShortName = committeeShortName;         
        }

        /// <summary>
        /// Created by Varun on 19/02/14, for Retrieving All Contractors
        /// </summary>
        private void getAllContractors()
        {
            SqlConnection sqlConn = new SqlConnection(strCon);
            DataTable dtContractors = null;
            try
            {                
                sqlConn.Open();
                DAL dalObj = new DAL();
                string sqlContractorQuery = "";
                sqlContractorQuery = "SELECT DISTINCT COMPANY.co_id, COMPANY.co_name FROM COMPANY INNER JOIN  CONTRACTORS ON COMPANY.co_id = CONTRACTORS.co_id ORDER BY COMPANY.co_name";
                dtContractors = dalObj.GetDataFromDB("Contractors", sqlContractorQuery);
                //DataRow row = dtContractors.NewRow();
                //row["co_name"] = "All";
                //row["co_id"] = 0;
                //dtContractors.Rows.Add(row);                
                cmbDepartment.DataSource = dtContractors;
                cmbDepartment.DisplayMember = "co_name";
                cmbDepartment.ValueMember = "co_id";                 
                cmbDepartment.SelectedIndex = 0;                 
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }
             
        }

        

        /// <summary>
        /// 
        /// </summary>
        static DataTable dtAffairs = null;
        private void getAllAffairs()
        {
            //if (mAffairShortName != "")
            //{                   
                SqlConnection sqlConn = new SqlConnection(strCon);
                try
                {
                    //cmbAffairs.Items.Clear();
                    sqlConn.Open();
                    DAL dalObj = new DAL();
                    string sqlAffairsQuery = "";                     
                    // Added by Varun on 17/02/14 for populating the affairs based on user access rights, Riyas request                     
                    if (mAffairShortName == "All" || mAffairShortName == "")
                        sqlAffairsQuery = "SELECT [Affairs_Name],Affair_id FROM AFFAIRS2 where isActive=1 ORDER BY [Affairs_Name] ASC";
                    else if (mAffairShortName != "")
                        sqlAffairsQuery = "SELECT [Affairs_Name],Affair_id FROM AFFAIRS2 where where isActive=1 and Affairs_Short_name in(" + mAffairShortName + ") ORDER BY [Affairs_Name] ASC";
                     dtAffairs = dalObj.GetDataFromDB("ProjectsInfo", sqlAffairsQuery);
                     if (mAffairShortName == "All" || mAffairShortName == "")
                     {
                         DataRow row = dtAffairs.NewRow();
                         row["Affairs_Name"] = "All";
                         row["Affair_id"] = 0;
                         dtAffairs.Rows.Add(row);
                     }
                    cmbDepartment.DataSource = dtAffairs;
                    cmbDepartment.DisplayMember = "Affairs_Name";
                    cmbDepartment.ValueMember = "Affair_id";
                    if (mAffairShortName == "All" || mAffairShortName == "")
                        cmbDepartment.SelectedIndex = cmbDepartment.FindStringExact("All");
                    else                                             
                        cmbDepartment.SelectedIndex = 0;
                }
                catch (Exception ex)
                {
                    string exMsg = ex.Message;
                }
                finally
                {
                    sqlConn.Close();
                }
            //}
        }
        //cmbContractType

        private void getAllContractTypes()
        {
            SqlConnection sqlConn = new SqlConnection(strCon);
            try
            {
                //SqlCommand sqlCom;
                //SqlDataReader sqlReader;
                DataTable dtContracts = null;
                sqlConn.Open();
                DAL dalObj = new DAL();
                string sqlQuery = "SELECT contract_type_id,[TypeofContract] FROM [ContractTypes] ORDER BY [ContractTypes].[TypeofContract] ASC";
                dtContracts = dalObj.GetDataFromDB("ContractsInfo", sqlQuery);
                DataRow row = dtContracts.NewRow();
                row["TypeofContract"] = "All";
                row["contract_type_id"] = 0;
                dtContracts.Rows.Add(row);
                cmbContractType.DataSource = dtContracts;
                cmbContractType.DisplayMember = "TypeofContract";
                cmbContractType.ValueMember = "contract_type_id";
                cmbContractType.SelectedIndex = cmbContractType.FindStringExact("All");
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// 
        DataTable dtDepartments = null;
        private void getAllDepartments()
        {
            if (dtAffairs != null)
            {
                SqlConnection sqlConn = new SqlConnection(strCon);
                try
                {
                    //SqlCommand sqlCom;
                    //SqlDataReader sqlReader;
                    sqlConn.Open();
                    DAL dalObj = new DAL();
                    string sqlQuery = "";
                    if (mAffairShortName != "All")
                    {
                        short counter = 0;
                        StringBuilder affairIds = new StringBuilder();
                        int totalAffairs = dtAffairs.Rows.Count;
                        while (counter < dtAffairs.Rows.Count)
                        {
                            affairIds.Append(dtAffairs.Rows[counter][1]);
                            if (counter+1 != totalAffairs)
                                affairIds.Append(",");
                            counter++;
                        }
                        sqlQuery = "SELECT department_id,Department FROM Department2 where Affair_id in(" + affairIds.ToString() + ") and isActive=1 ORDER BY Department ASC";
                    }
                    else
                        sqlQuery = "SELECT department_id,Department FROM Department2 where isActive=1 ORDER BY Department ASC";
                    dtDepartments = dalObj.GetDataFromDB("Departments", sqlQuery);
                    if (mAffairShortName == "All")
                    {
                        DataRow row = dtDepartments.NewRow();
                        row["Department"] = "All";
                        row["department_id"] = 0;
                        dtDepartments.Rows.Add(row);
                    }                   

                    cmbAffairs.DataSource = dtDepartments;
                    cmbAffairs.DisplayMember = "Department";
                    cmbAffairs.ValueMember = "department_id";
                    if (mAffairShortName == "All")
                        cmbAffairs.SelectedIndex = cmbAffairs.FindStringExact("All");
                    else
                        cmbAffairs.SelectedIndex = cmbAffairs.FindStringExact(dtDepartments.Rows[0][1].ToString());

                }
                catch (Exception ex)
                {
                    string exMsg = ex.Message;
                }
                finally
                {
                    sqlConn.Close();
                }
            }
        }
        /// <summary>
        /// 
        /// </summary>
        private void getCalendarYears()
        {            
            SqlConnection sqlConn = new SqlConnection(strCon);
            try
            {
                DataTable dtCalendarYear = null;
                sqlConn.Open();
                DAL dalObj = new DAL();
                string sqlQuery = "SELECT FYID,[CalendarYear] FROM [FiscalYear] ORDER BY [FiscalYear] ASC";
                dtCalendarYear = dalObj.GetDataFromDB("CalendarYears", sqlQuery);
                DataRow row = dtCalendarYear.NewRow();
                row["CalendarYear"] = "All";
                row["FYID"] = 0;
                dtCalendarYear.Rows.Add(row);
                cmbFiscalyear.DataSource = dtCalendarYear;
                cmbFiscalyear.DisplayMember = "CalendarYear";
                cmbFiscalyear.ValueMember = "FYID";
                cmbFiscalyear.SelectedIndex = cmbFiscalyear.FindStringExact("All");
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }           
        }


        /// <summary>
        /// 
        /// </summary>
        private void getAllFiscalYears()
        {
            if (dtDepartments != null)
            {
                SqlConnection sqlConn = new SqlConnection(strCon);
                try
                {
                    DataTable dtFiscalYear = null;
                    sqlConn.Open();
                    DAL dalObj = new DAL();
                    string sqlQuery = "SELECT FYID,[FiscalYear] FROM [FiscalYear] ORDER BY [FiscalYear] ASC";
                    dtFiscalYear = dalObj.GetDataFromDB("FiscalYears", sqlQuery);
                    DataRow row = dtFiscalYear.NewRow();
                    row["FiscalYear"] = "All";
                    row["FYID"] = 0;
                    dtFiscalYear.Rows.Add(row);
                    cmbFiscalyear.DataSource = dtFiscalYear;
                    cmbFiscalyear.DisplayMember = "FiscalYear";
                    cmbFiscalyear.ValueMember = "FYID";
                    cmbFiscalyear.SelectedIndex = cmbFiscalyear.FindStringExact("All");
                }
                catch (Exception ex)
                {
                    string exMsg = ex.Message;
                }
                finally
                {
                    sqlConn.Close();
                }
            }
        }
        /// <summary>
        /// 
        /// </summary>
        private void getAllTenderCommittees()
        {             
            SqlConnection sqlConn = new SqlConnection(strCon);
            try
            {
                DataTable dtTenderCommittee = null;
                sqlConn.Open();
                DAL dalObj = new DAL();                 
                string sqlQuery = "";
                // Added by Varun on 17/02/14 for populating the affairs based on user access rights, Riyas request                 
                if(mCommitteeShortName == "All")
                    sqlQuery = "SELECT committee_id,committee_name FROM committee ORDER BY committee_name ASC";
                else
                    sqlQuery = "SELECT committee_id,committee_name FROM committee where committee_short_name in(" + mCommitteeShortName + ") ORDER BY committee_name ASC";
                dtTenderCommittee = dalObj.GetDataFromDB("TenderCommittee", sqlQuery);
                if (mCommitteeShortName == "All")
                {
                    DataRow row = dtTenderCommittee.NewRow();
                    row["committee_name"] = "All";
                    row["committee_id"] = 0;
                    dtTenderCommittee.Rows.Add(row);
                }                 

                cmbTenderCommittee.DataSource = dtTenderCommittee;
                cmbTenderCommittee.DisplayMember = "committee_name";
                cmbTenderCommittee.ValueMember = "committee_id";
                if (mCommitteeShortName == "All")
                    cmbTenderCommittee.SelectedIndex = cmbTenderCommittee.FindStringExact("All");
                else
                    cmbTenderCommittee.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }
        }
        /// <summary>
        /// 
        /// </summary>
        private void getAllTenderStages()
        {
            SqlConnection sqlConn = new SqlConnection(strCon);
            try
            {
                DataTable dtTenderStage = null;
                sqlConn.Open();
                DAL dalObj = new DAL();
                string sqlQuery = "SELECT stage_id,stage_Name FROM stages ORDER BY stage_Name ASC";
                dtTenderStage = dalObj.GetDataFromDB("TenderStage", sqlQuery);
                DataRow row = dtTenderStage.NewRow();
                row["stage_Name"] = "All";
                row["stage_id"] = 0;
                dtTenderStage.Rows.Add(row);
                cmbTenderStage.DataSource = dtTenderStage;
                cmbTenderStage.DisplayMember = "stage_Name";
                cmbTenderStage.ValueMember = "stage_id";
                cmbTenderStage.SelectedIndex = cmbTenderStage.FindStringExact("All");
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }
        }
        /// <summary>
        /// 
        /// </summary>
        private void getAllTenderTypes()
        {
            SqlConnection sqlConn = new SqlConnection(strCon);
            try
            {
                DataTable dtTenderType = null;
                sqlConn.Open();
                DAL dalObj = new DAL();
                string sqlQuery = "SELECT tender_type_id,tender_type_name FROM [TenderTypes] ORDER BY tender_type_name ASC";
                dtTenderType = dalObj.GetDataFromDB("TenderTypes", sqlQuery);

                DataRow row = dtTenderType.NewRow();
                row["tender_type_name"] = "All";
                row["tender_type_id"] = 0;
                dtTenderType.Rows.Add(row);

                cmbTenderType.DataSource = dtTenderType;
                cmbTenderType.DisplayMember = "tender_type_name";
                cmbTenderType.ValueMember = "tender_type_id";
                cmbTenderType.SelectedIndex = cmbTenderType.FindStringExact("All");
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }
        }
        /// <summary>
        /// 
        /// </summary>
        private void getAllTenderStatus()
        {
            SqlConnection sqlConn = new SqlConnection(strCon);
            try
            {
                DataTable dtTenderStatus = null;
                sqlConn.Open();
                DAL dalObj = new DAL();
                string sqlQuery = "SELECT tender_status_id,[Status_Name] FROM [TenderStatus] ORDER BY [Status_Name] ASC";
                dtTenderStatus = dalObj.GetDataFromDB("TenderStatus", sqlQuery);

                DataRow row = dtTenderStatus.NewRow();
                row["Status_Name"] = "All";
                row["tender_status_id"] = 0;
                dtTenderStatus.Rows.Add(row);

                cmbTenderStatus.DataSource = dtTenderStatus;
                cmbTenderStatus.DisplayMember = "Status_Name";
                cmbTenderStatus.ValueMember = "tender_status_id";
                
                cmbTenderStatus.SelectedIndex = cmbTenderStatus.FindStringExact("All");
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }
        }


        /// <summary>
        /// WorkOrder Report
        /// </summary>
        /// <param name="sblTenderTracking"></param>
        /// <returns></returns>
        private StringBuilder getWorkOrderReport()
        {
            StringBuilder sblProjectTracking = null;
            try
            {
                 string strTenderCommitteeQuery = null;
                 if (Convert.ToInt16(cmbFiscalyear.SelectedValue) != 0 && startReportDateChanged == 0 && endReportDateChanged == 0)
                 {
                     strTenderCommitteeQuery = "SELECT p.tender_no, p.project_newname_en, WorkOrders.workOrderNo, WorkOrders.workOrderTitle, REPLACE(CONVERT(nvarchar, WorkOrders.workOrderClosingDate, 106), ' ', '-') AS WorkOrderClosingDate, REPLACE(CONVERT(nvarchar, contr.cp_tender_award, 106), ' ', '-') AS WorkOrderAwardDate, COMPANY.co_name," +
                     "d2.Department, t.tender_type_name, contr.ContractAmount, contr.contract_no, tstatus.TenderStatusShortName from WorkOrders INNER JOIN PROJECTS AS p ON WorkOrders.proj_id = p.proj_id inner join Department2 as d1 on p.department_id=d1.department_id" +
                     " inner join Department2 as d2 on d1.newDepID=d2.department_id INNER JOIN TenderTypes AS t ON p.tender_type_id = t.tender_type_id INNER JOIN " +
                     "CONTRACTORS AS contr ON WorkOrders.bidder_Id = contr.bidder_id INNER JOIN TenderStatus AS tstatus ON p.Tender_Status_id = tstatus.Tender_Status_id INNER JOIN TenderDatesInfo As td ON p.proj_id = td.proj_id INNER JOIN COMPANY ON contr.co_id = COMPANY.co_id AND td.co_id = COMPANY.co_id WHERE " +
                     "(p.tender_no <> '') ";       //AND (CHARINDEX('" + dtView.Row.ItemArray[1].ToString().Split('-')[0] + "', p.tender_no) > 0)            
                     //DataRowView dtView = (DataRowView)cmbFiscalyear.SelectedItem;
                     if (whereClause != null)
                     {
                         if (whereClause != "")
                         {
                             strTenderCommitteeQuery = strTenderCommitteeQuery+" and " + whereClause;       //AND (CHARINDEX('" + dtView.Row.ItemArray[1].ToString().Split('-')[0] + "', p.tender_no) > 0)            
                         }                         
                     }                     
                 }
                 else
                 {
                     strTenderCommitteeQuery = "SELECT p.tender_no, p.project_newname_en, WorkOrders.workOrderNo, WorkOrders.workOrderTitle, REPLACE(CONVERT(nvarchar, WorkOrders.workOrderClosingDate, 106), ' ', '-') AS WorkOrderClosingDate, REPLACE(CONVERT(nvarchar, contr.cp_tender_award, 106), ' ', '-') AS WorkOrderAwardDate, COMPANY.co_name," +
                     "d2.Department, t.tender_type_name, contr.ContractAmount, contr.contract_no, tstatus.TenderStatusShortName from WorkOrders INNER JOIN PROJECTS AS p ON WorkOrders.proj_id = p.proj_id inner join Department2 as d1 on p.department_id=d1.department_id" +
                     " inner join Department2 as d2 on d1.newDepID=d2.department_id INNER JOIN TenderTypes AS t ON p.tender_type_id = t.tender_type_id INNER JOIN " +
                     "CONTRACTORS AS contr ON WorkOrders.bidder_Id = contr.bidder_id INNER JOIN TenderStatus AS tstatus ON p.Tender_Status_id = tstatus.Tender_Status_id INNER JOIN TenderDatesInfo As td ON p.proj_id = td.proj_id INNER JOIN COMPANY ON contr.co_id = COMPANY.co_id AND td.co_id = COMPANY.co_id WHERE (p.tender_no <> '') AND (contr.cp_tender_award BETWEEN '" +
                     dtpStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpEndReportDate.Value.ToString("dd/MMM/yyyy") + "')";

                     if (whereClause != null)
                     {
                         if (whereClause != "")
                         {
                             strTenderCommitteeQuery = strTenderCommitteeQuery + " and " + whereClause;
                         }                              
                     }                     
                     
                 }

                strTenderCommitteeQuery = generatedynamicSQLQuery(strTenderCommitteeQuery,true);
                SqlConnection sqlConn = new SqlConnection(strCon);
                DataTable dtWorkOrderInfo = null;
                sqlConn.Open();
                DAL dalObj = new DAL();
                //dtTenderCommittee = dalObj.GetDataFromDB("TenderCommitteeInfo", strTenderCommitteeQuery);

                dtWorkOrderInfo = dalObj.GetDataFromDB("WorkOrderInfo", strTenderCommitteeQuery);

                if (dtWorkOrderInfo != null)
                { 
                    sblProjectTracking = new StringBuilder();
                    if (dtWorkOrderInfo.Rows.Count != 0)
                    {
                        sblProjectTracking.Append("<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"border: solid 1px #506E87;\">");// border=\"0\"");// 
                        sblProjectTracking.Append("<tr><td colspan=\"14\" style=\"text-align: center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;\"><b>PWA - WORK ORDER AWARD REPORT</b></td></tr>");
                        sblProjectTracking.Append("<tr><td colspan=\"14\" style=\"text-align: center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #FFFF99;\"><b>WorkOrder Award Tracking Information</b></td></tr>");

                        //To generate the Tender Tracking Report Header
                        sblProjectTracking.Append("<tr>");
                        sblProjectTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>SNo.</b></td>");
                        sblProjectTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>Tender&nbsp;No.</b></td>");
                        sblProjectTracking.Append("<td style=\"width:300px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>Project&nbsp;Title</b></td>");
                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>WorkOrder Number</b></td>");
                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>WorkOrder Title</b></td>");
                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>WorkOrder ClosingDate</b></td>");
                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>WorkOrder AwardDate</b></td>");
                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>Company Name</b></td>");
                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>Department Name/Ref</b></td>");
                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>Tender Type</b></td>");
                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>Contract Amount</b></td>");
                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>Contract Number</b></td>");
                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>TenderStatus ShortName</b></td>");
                        sblProjectTracking.Append("</tr>");
                        //sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>Tender Issue Date</b></td>");
                        int rowCounter = 0;
                        while (rowCounter < dtWorkOrderInfo.Rows.Count - 1)
                        {

                            sblProjectTracking.Append("<tr>");
                            sblProjectTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + ++rowCounter + "</td>");
                            if ((!string.IsNullOrEmpty(dtWorkOrderInfo.Rows[rowCounter]["tender_no"].ToString())))
                                sblProjectTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + dtWorkOrderInfo.Rows[rowCounter]["tender_no"].ToString() + "</td>");
                            else
                                sblProjectTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                            if ((!string.IsNullOrEmpty(dtWorkOrderInfo.Rows[rowCounter]["project_newname_en"].ToString())))
                                sblProjectTracking.Append("<td style=\"width:300px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + dtWorkOrderInfo.Rows[rowCounter]["project_newname_en"].ToString() + "</td>");
                            else
                                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                            if ((!string.IsNullOrEmpty(dtWorkOrderInfo.Rows[rowCounter]["workOrderNo"].ToString())))
                                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + dtWorkOrderInfo.Rows[rowCounter]["workOrderNo"].ToString() + "</td>");
                            else
                                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                            if ((!string.IsNullOrEmpty(dtWorkOrderInfo.Rows[rowCounter]["workOrderTitle"].ToString())))
                                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + dtWorkOrderInfo.Rows[rowCounter]["workOrderTitle"].ToString() + "</td>");
                            else
                                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                            if ((!string.IsNullOrEmpty(dtWorkOrderInfo.Rows[rowCounter]["workOrderClosingDate"].ToString())))
                                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + dtWorkOrderInfo.Rows[rowCounter]["workOrderClosingDate"].ToString() + "</td>");
                            else
                                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                            if ((!string.IsNullOrEmpty(dtWorkOrderInfo.Rows[rowCounter]["WorkOrderAwardDate"].ToString())))
                                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + dtWorkOrderInfo.Rows[rowCounter]["WorkOrderAwardDate"].ToString() + "</td>");
                            else
                                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                            if ((!string.IsNullOrEmpty(dtWorkOrderInfo.Rows[rowCounter]["co_name"].ToString())))
                                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + dtWorkOrderInfo.Rows[rowCounter]["co_name"].ToString() + "</td>");
                            else
                                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                            if ((!string.IsNullOrEmpty(dtWorkOrderInfo.Rows[rowCounter]["Department"].ToString())))
                                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + dtWorkOrderInfo.Rows[rowCounter]["Department"].ToString() + "</td>");
                            else
                                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                            if ((!string.IsNullOrEmpty(dtWorkOrderInfo.Rows[rowCounter]["tender_type_name"].ToString())))
                                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + dtWorkOrderInfo.Rows[rowCounter]["tender_type_name"].ToString() + "</td>");
                            else
                                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                            //if ((!string.IsNullOrEmpty(dtWorkOrderInfo.Rows[rowCounter]["ts_tender_issue"].ToString())))
                            //    sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + dtWorkOrderInfo.Rows[rowCounter]["ts_tender_issue"].ToString() + "</td>");
                            //else
                            //    sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                            if ((!string.IsNullOrEmpty(dtWorkOrderInfo.Rows[rowCounter]["ContractAmount"].ToString())))
                                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + dtWorkOrderInfo.Rows[rowCounter]["ContractAmount"].ToString() + "</td>");
                            else
                                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                            if ((!string.IsNullOrEmpty(dtWorkOrderInfo.Rows[rowCounter]["contract_no"].ToString())))
                                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + dtWorkOrderInfo.Rows[rowCounter]["contract_no"].ToString() + "</td>");
                            else
                                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                            if ((!string.IsNullOrEmpty(dtWorkOrderInfo.Rows[rowCounter]["TenderStatusShortName"].ToString())))
                                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + dtWorkOrderInfo.Rows[rowCounter]["TenderStatusShortName"].ToString() + "</td>");
                            else
                                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                            sblProjectTracking.Append("</tr>");
                        }

                        sblProjectTracking.Append("<tr><td colspan=\"14\" style=\"width:auto;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b style=\"font-style: italic\">This report is generated by TCMS dated :</b><b>" + DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss") + "</b></td></tr>");
                        sblProjectTracking.Append("</table>");
                        lblTotalNoOfRecords.Text = "Total Records Count=" + rowCounter.ToString();
                    }
                    else
                    {
                        lblTotalNoOfRecords.Text = "Total Records Count=0";
                        MessageBox.Show("No data exist for selected options", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    lblTotalNoOfRecords.Text = "Total Records Count=0";
                    MessageBox.Show("Database is experiencing heavy access load. In-order to avoid slowness or time-out error while retrieving records from database,\n the difference between the selected dates should be equal to or less than two years.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            return sblProjectTracking;

        }




        /// <summary>
        /// 
        /// </summary>
        /// <param name="sblTenderTracking"></param>
        /// <returns></returns>
        private StringBuilder getTenderCommitteeHeader(StringBuilder sblTenderTracking)
        {
            try
            {
                //string strTenderCommitteeQuery = "select p.proj_id,p.project_newname_en,p.tender_no,d.Department,td.stage_id,td.ptd_receive_on,p.tender_type_id,t.tender_type_name,td.ts_receive_on,td.ts_closing_s1,td.ts_closing_s2,td.eval_tech_sent1,td.eval_tech_receive1,td.eval_com_sent1,td.eval_com_receive1,td.eval_tender_award_approval,td.eval_no_of_meetings,c.co_name,c.co_id,contr.ContractAmount,contr.contract_no,pcost.budgeted_cost,pcost.estimated_cost,tstatus.[TenderStatusShortName],td.remarks" +
                //" from	PROJECTS p" +
                //" left outer JOIN TenderDatesInfo as td on p.proj_id=td.proj_id" +
                //" inner join Department as d on p.department_id=d.department_id" +
                //" inner join [TenderTypes] as t on p.tender_type_id = t.tender_type_id" +
                //" left outer join CONTRACTORS as contr on p.proj_id=contr.proj_id" +
                //" left outer join COMPANY as c on contr.co_id=c.co_id" +
                //" inner join [TenderStatus] as tstatus on p.Tender_Status_id=tstatus.Tender_Status_id" +
                //" left outer join ProjectCost as pcost on p.proj_id=pcost.proj_id where p.tender_no <>'' and td.eval_tender_opening " +
                //"between '" + dtpStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpEndReportDate.Value.ToString("dd/MMM/yyyy") + "'";
                string strTenderCommitteeQuery = null;
                //if (Convert.ToInt16(cmbFiscalyear.SelectedValue) != 0 && startReportDateChanged == 0 && endReportDateChanged == 0)
                //{
                    //DataRowView dtView = (DataRowView)cmbFiscalyear.SelectedItem;                   
                //}
                //else
                strTenderCommitteeQuery = "select p.proj_id,p.project_newname_en,p.tender_no,p.project_code,d2.Department,td.stage_id,td.ptd_receive_on,p.tender_type_id,t.tender_type_name,td.ts_tender_issue,td.eval_tender_doc_receive_from_cd,td.ts_closing_s1,td.ts_closing_s2,td.eval_tech_sent1,td.TPWD1,td.eval_tech_receive1,td.eval_com_sent1,td.FPWD1,td.eval_com_receive1,td.eval_tender_award_approval,td.eval_no_of_meetings,c.co_name,c.co_id,contr.ContractAmount,contr.contract_no,pcost.estimated_cost,tstatus.[TenderStatusShortName],td.remarks" +
                          " from PROJECTS p left outer JOIN TenderDatesInfo as td on p.proj_id=td.proj_id" +
                          " inner join Department2 as d1 on p.department_id=d1.department_id" +
                          " inner join Department2 as d2 on d1.newDepID=d2.department_id" +
                          " inner join [TenderTypes] as t on p.tender_type_id = t.tender_type_id" +
                          " left outer join CONTRACTORS as contr on p.proj_id=contr.proj_id" +
                          " left outer join COMPANY as c on contr.co_id=c.co_id" +
                          " inner join [TenderStatus] as tstatus on p.Tender_Status_id=tstatus.Tender_Status_id" +
                          " left outer join ProjectCost as pcost on p.proj_id=pcost.proj_id where p.tender_no <>''"; 

                    if (whereClause != null)
                    {
                        if (whereClause != "")
                        {
                            strTenderCommitteeQuery = strTenderCommitteeQuery + whereClause;  //and td.eval_tender_opening " +
                            //"between '" + dtpStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpEndReportDate.Value.ToString("dd/MMM/yyyy") + "'"
                        }                         
                    }
                    

                strTenderCommitteeQuery = generatedynamicSQLQuery(strTenderCommitteeQuery,false);


                SqlConnection sqlConn = new SqlConnection(strCon);
                DataTable dtTenderCommittee = null;
                sqlConn.Open();
                DAL dalObj = new DAL();
                //dtTenderCommittee = dalObj.GetDataFromDB("TenderCommitteeInfo", strTenderCommitteeQuery);
                dtTenderCommittee = dalObj.GetDataFromDB("TenderCommitteeInfo", strTenderCommitteeQuery + " Order By p.tender_no");

                if (dtTenderCommittee.Rows.Count != 0)
                {
                    sblTenderTracking.Append("<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"border: solid 1px #506E87;\">");// border=\"0\"");// 
                    sblTenderTracking.Append("<tr><td colspan=\"22\" style=\"text-align: left;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;\"><b>Tender Tracking Sheet : Tender Committee</b></td></tr>");
                    //sblTenderTracking.Append("<tr><td colspan=\"18\" style=\"text-align: left;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #FFFF99;\"><b>Tenders Tracking Information</b></td></tr>");
                    //sblTenderTracking.Append("<tr><td colspan=\"9\" style=\"text-align: left;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;\"><b>PREPARATION OF TENDER DOCUMENTS</b></td><td colspan=\"9\" style=\"text-align: left;height: 35px;font-size: 12pt !important;background-color: #C4D79B;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;\"><b>TENDERING OF PROJECTS</b></td></tr>");

                    //To generate the Tender Tracking Report Header
                    sblTenderTracking.Append("<tr>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>SR</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"></td></tr>");
                    sblTenderTracking.Append("</table>");
                    sblTenderTracking.Append("</td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Tender</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>No.</b></td></tr>");
                    sblTenderTracking.Append("</table>");
                    sblTenderTracking.Append("</td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Project</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Code</b></td></tr>");
                    sblTenderTracking.Append("</table>");
                    sblTenderTracking.Append("</td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Tender&nbsp;Title</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b></b></td></tr>");
                    sblTenderTracking.Append("</table>");
                    sblTenderTracking.Append("</td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>User</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Dept.</b></td></tr>");
                    sblTenderTracking.Append("</table>");
                    sblTenderTracking.Append("</td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Tender No. Request</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Received</b></td></tr>");
                    sblTenderTracking.Append("</table>");
                    sblTenderTracking.Append("</td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Tender No. Issued</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Sent Date</b></td></tr>");
                    sblTenderTracking.Append("</table>");
                    sblTenderTracking.Append("</td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Type Of Tender</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>D.O/SH.L/P.T</b></td></tr>");
                    sblTenderTracking.Append("</table>");
                    sblTenderTracking.Append("</td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Tender Doc.</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Received</b></td></tr>");
                    sblTenderTracking.Append("</table>");
                    sblTenderTracking.Append("</td>");

                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #003366;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #003366;color: #FFFF00;\"><b>Closing</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #003366;color: #FFFF00;\"><b>Date</b></td></tr>");
                    sblTenderTracking.Append("</table>");
                    sblTenderTracking.Append("</td>");

                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #003366;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td colspan=\"3\" style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #003366;color: #00FFFF;\"><b>Tech. Evaluation</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #003366;color: #00FFFF;\"><b>Sent</b></td>");
                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #003366;color: #00FFFF;\"><b>Propsosed W D</b></td>");
                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #003366;color: #00FFFF;\"><b>Received</b></td>");
                    sblTenderTracking.Append("</tr></table>");
                    sblTenderTracking.Append("</td>");

                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #666699;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td colspan=\"3\" style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #666699;color: #FFCC00;\"><b>Commercial  Evaluation</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #666699;color: #FFCC00;\"><b>Sent</b></td>");
                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #666699;color: #FFCC00;\"><b>Propsosed W D</b></td>");
                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #666699;color: #FFCC00;\"><b>Received</b></td>");
                    sblTenderTracking.Append("</tr></table>");
                    sblTenderTracking.Append("</td>");

                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td colspan=\"2\" style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top:0px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Awarded</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Approval Date</b></td>");
                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>No. of Meeting</b></td>");
                    sblTenderTracking.Append("</tr></table>");
                    sblTenderTracking.Append("</td>");

                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #000080;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color:#000080; color:#00FF00;\"><b>Successful</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color:#000080; color:#00FF00;\"><b>Bidder</b></td>");
                    sblTenderTracking.Append("</tr></table>");
                    sblTenderTracking.Append("</td>");

                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #CCFFFF;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #CCFFFF;color:#000080\"><b>Award</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #CCFFFF;color:#000080\"><b>Value(QR)</b></td>");
                    sblTenderTracking.Append("</tr></table>");
                    sblTenderTracking.Append("</td>");

                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #CCFFFF;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #CCFFFF;color:#000080\"><b>Estimate</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #CCFFFF;color:#000080\"><b>Value(QR)</b></td>");
                    sblTenderTracking.Append("</tr></table>");
                    sblTenderTracking.Append("</td>");

                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #CC99FF;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #CC99FF;color:#FFFF00\"><b>Tender</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #CC99FF;color:#FFFF00\"><b>Status</b></td>");
                    sblTenderTracking.Append("</tr></table>");
                    sblTenderTracking.Append("</td>");

                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #CC99FF;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #CC99FF;color:#FFFF00\"><b>Contract</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #CC99FF;color:#FFFF00\"><b>No.</b></td>");
                    sblTenderTracking.Append("</tr></table>");
                    sblTenderTracking.Append("</td>");

                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #C0C0C0;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #C0C0C0;color:#000080\"><b>Remarks</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #C0C0C0;\"><b></b></td>");
                    sblTenderTracking.Append("</tr></table>");
                    sblTenderTracking.Append("</td>");

                    sblTenderTracking.Append("</tr>");


                    //string strTenderCommitteeQuery = "select p.proj_id,p.project_newname_en,p.tender_no,d.Department,td.stage_id,td.eval_tender_no_request,p.tender_type_id,t.tender_type_name,td.eval_tender_doc_receive_from_cd,td.ts_closing_s1,td.ts_closing_s2,td.eval_tech_sent1,td.eval_tech_receive1,td.eval_com_sent1,td.eval_com_receive1,td.eval_tender_award_approval,td.eval_no_of_meetings,c.co_name,c.co_id,contr.ContractAmount,contr.contract_no,pcost.budgeted_cost,pcost.estimated_cost,tstatus.[Tender Statsus Short Name],td.remarks" +
                    //" from PROJECTS p,TenderDatesInfo td,Department d,[Type of Tender] t,COMPANY c,[Status of Tender] tstatus,CONTRACTORS contr,ProjectCost pcost"+
                    //" where p.proj_id=td.proj_id and p.department_id=d.department_id and p.tender_type_id=t.tender_type_id and p.proj_id=contr.proj_id and contr.co_id=c.co_id and p.Tender_Status_id=tstatus.Tender_Status_id and p.proj_id=pcost.proj_id";


                    // commented by Varun on 17/02/14 because it is written twice
                    //dtTenderCommittee = dalObj.GetDataFromDB("TenderCommitteeInfo", strTenderCommitteeQuery);

                    //DataTable dtSortedTable = dtTenderCommittee.AsEnumerable().OrderByDescending(row => row.Field<string>("tender_no")).CopyToDataTable();
                    //dtTenderCommittee = dtTenderCommittee.AsEnumerable().OrderBy(row => row.Field<string>("tender_no")).CopyToDataTable();
                    int rowCounter = 0;
                    if (dtTenderCommittee != null && dtTenderCommittee.Rows.Count > 0)
                    {
                        DataTable uniqueProjects = dtTenderCommittee.DefaultView.ToTable(true, "proj_id");
                        for (int intIndexProj = 0; intIndexProj < uniqueProjects.Rows.Count; intIndexProj++)
                        {
                            DataRow[] resultStage2 = dtTenderCommittee.Select("proj_id='" + uniqueProjects.Rows[intIndexProj]["proj_id"].ToString() + "' AND stage_id='2'");
                            DataRow[] projectResult = dtTenderCommittee.Select("proj_id='" + uniqueProjects.Rows[intIndexProj]["proj_id"].ToString() + "'", "tender_no desc");
                            //DataRow[] resultStage4 = dtTenderCommittee.Select("proj_id=" + Convert.ToInt32(uniqueProjects.Rows[intIndexProj]["proj_id"].ToString()) + " AND stage_id=4");
                            DataRow[] resultStage3 = dtTenderCommittee.Select("proj_id='" + uniqueProjects.Rows[intIndexProj]["proj_id"].ToString() + "' AND stage_id='3'");

                            if (projectResult != null && projectResult.Length > 0)
                            {
                                sblTenderTracking.Append("<tr>");
                                sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + ++rowCounter + "</td>");
                                if (projectResult[0]["tender_no"] != null)
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["tender_no"].ToString() + "</td>");
                                else
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                if (projectResult[0]["project_code"] != null)
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["project_code"].ToString() + "</td>");
                                else
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                               

                                if (projectResult[0]["project_newname_en"] != null)
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["project_newname_en"].ToString() + "</td>");
                                else
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                if (projectResult[0]["Department"] != null)
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["Department"].ToString() + "</td>");
                                else
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                if (resultStage3 != null)
                                {
                                    if (resultStage3.Length > 0)
                                    {
                                        sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                        sblTenderTracking.Append("<table border=\"0\">");
                                        foreach (DataRow row in resultStage3)
                                        {
                                            sblTenderTracking.Append("<tr>");
                                            //As per Sreedhar "Tender Opening Date"
                                            if (row["ptd_receive_on"] != null)
                                            {
                                                if (row["ptd_receive_on"].ToString() != "")
                                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(row["ptd_receive_on"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                                else
                                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                            }
                                            else
                                                sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                            sblTenderTracking.Append("</tr>");
                                            break;
                                        }
                                        sblTenderTracking.Append("</table>");
                                        sblTenderTracking.Append("</td>");
                                    }
                                    else
                                        sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                }
                                else
                                {
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                }

                                //
                                if (resultStage2 != null)
                                {
                                    if (resultStage2.Length > 0)
                                    {
                                        sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                        sblTenderTracking.Append("<table border=\"0\">");
                                        foreach (DataRow row in resultStage3)
                                        {
                                            sblTenderTracking.Append("<tr>");
                                            //As per Sreedhar "Tender Doc. Recivd from CD"
                                            if (row["ts_tender_issue"] != null)
                                                if (row["ts_tender_issue"].ToString() != "")
                                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(row["ts_tender_issue"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                                else
                                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"></td>");
                                            sblTenderTracking.Append("</tr>");
                                            break;
                                        }
                                        sblTenderTracking.Append("</table>");
                                        sblTenderTracking.Append("</td>");
                                    }
                                    else
                                        sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"></td>");
                                }
                                else
                                {
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"></td>");
                                }

                                if (projectResult[0]["tender_type_name"] != null)
                                {
                                    if (projectResult[0]["tender_type_name"].ToString() != "")
                                        sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["tender_type_name"].ToString() + "</td>");
                                    else
                                        sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"></td>");
                                }
                                else
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"></td>");


                                if (resultStage3 != null && resultStage3.Length > 0)
                                {
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                    sblTenderTracking.Append("<table border=\"0\">");
                                    foreach (DataRow row in resultStage3)
                                    {
                                        sblTenderTracking.Append("<tr>");
                                        //As per Sreedhar "Tender Doc. Recivd from CD"
                                        if (row["eval_tender_doc_receive_from_cd"] != null)
                                        {
                                            if (row["eval_tender_doc_receive_from_cd"].ToString() != "")
                                                sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(row["eval_tender_doc_receive_from_cd"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                            else
                                                sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                        }
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                        sblTenderTracking.Append("</tr>");
                                        break;
                                    }
                                    sblTenderTracking.Append("</table>");
                                    sblTenderTracking.Append("</td>");
                                }
                                else
                                {
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                }

                                //
                                if (resultStage2 != null)
                                {
                                    if (resultStage2.Length > 0)
                                    {
                                        sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                        sblTenderTracking.Append("<table border=\"0\">");
                                        foreach (DataRow row in resultStage2)
                                        {
                                            sblTenderTracking.Append("<tr>");

                                            if (row["ts_closing_s1"] != null)
                                            {
                                                if (row["ts_closing_s1"].ToString() != "")
                                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(row["ts_closing_s1"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                                else
                                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"></td>");
                                            }
                                            else
                                                sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"></td>");

                                            sblTenderTracking.Append("</tr>");
                                            break;
                                        }

                                        sblTenderTracking.Append("</table>");
                                        sblTenderTracking.Append("</td>");
                                    }
                                    else
                                        sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                }
                                else
                                {
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                    sblTenderTracking.Append("<table border=\"0\"><tr>");
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                    sblTenderTracking.Append("</tr></table></td>");
                                }

                                //Tech. Evaluation
                                if (resultStage3 != null && resultStage3.Length > 0)
                                {
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                    sblTenderTracking.Append("<table border=\"0\">");
                                    foreach (DataRow row in resultStage3)
                                    {
                                        sblTenderTracking.Append("<tr>");
                                        //As per Sreedhar "Tender Doc. Recivd from CD"
                                        if (row["eval_tech_sent1"] != null && (!string.IsNullOrEmpty(row["eval_tech_sent1"].ToString())))
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(row["eval_tech_sent1"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                        if (row["TPWD1"] != null && (!string.IsNullOrEmpty(row["TPWD1"].ToString())))
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + row["TPWD1"].ToString() + "</td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                        if (row["eval_tech_receive1"] != null && (!string.IsNullOrEmpty(row["eval_tech_receive1"].ToString())))
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(row["eval_tech_receive1"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                        sblTenderTracking.Append("</tr>");
                                        break;
                                    }
                                    sblTenderTracking.Append("</table>");
                                    sblTenderTracking.Append("</td>");
                                }
                                else
                                {
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                    sblTenderTracking.Append("<table border=\"0\"><tr>");
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                    sblTenderTracking.Append("</tr></table></td>");
                                }


                                //Commercial  Evaluation
                                if (resultStage3 != null && resultStage3.Length > 0)
                                {
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                    sblTenderTracking.Append("<table border=\"0\">");
                                    foreach (DataRow row in resultStage3)
                                    {
                                        sblTenderTracking.Append("<tr>");
                                        //As per Sreedhar "Tender Doc. Recivd from CD"
                                        if (row["eval_com_sent1"] != null && (!string.IsNullOrEmpty(row["eval_com_sent1"].ToString())))
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(row["eval_com_sent1"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                        if (row["FPWD1"] != null && (!string.IsNullOrEmpty(row["FPWD1"].ToString())))
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + row["FPWD1"].ToString() + "</td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                        if (row["eval_com_receive1"] != null && (!string.IsNullOrEmpty(row["eval_com_receive1"].ToString())))
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(row["eval_com_receive1"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                        sblTenderTracking.Append("</tr>");
                                        break;
                                    }
                                    sblTenderTracking.Append("</table>");
                                    sblTenderTracking.Append("</td>");
                                }
                                else
                                {
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                    sblTenderTracking.Append("<table border=\"0\"><tr>");
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                    sblTenderTracking.Append("</tr></table></td>");
                                }

                                //Awarded
                                if (resultStage3 != null && resultStage3.Length > 0)
                                {
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                    sblTenderTracking.Append("<table border=\"0\">");
                                    foreach (DataRow row in resultStage3)
                                    {
                                        sblTenderTracking.Append("<tr>");
                                        //As per Sreedhar "Tender Doc. Recivd from CD"
                                        if (row["eval_tender_award_approval"] != null && (!string.IsNullOrEmpty(row["eval_tender_award_approval"].ToString())))
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(row["eval_tender_award_approval"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                        if (row["eval_no_of_meetings"] != null)
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + row["eval_no_of_meetings"].ToString() + "</td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</b></td>");
                                        sblTenderTracking.Append("</tr>");
                                        break;
                                    }
                                    sblTenderTracking.Append("</table>");
                                    sblTenderTracking.Append("</td>");
                                }
                                else
                                {
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                    sblTenderTracking.Append("<table border=\"0\"><tr>");
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                    sblTenderTracking.Append("</tr></table></td>");
                                }

                                if (projectResult[0]["co_name"] != null && (!string.IsNullOrEmpty(projectResult[0]["co_name"].ToString())))
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["co_name"].ToString() + "</td>");
                                else
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                if (projectResult[0]["ContractAmount"] != null && (!string.IsNullOrEmpty(projectResult[0]["ContractAmount"].ToString())))
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + string.Format("{0:#,##0.00}", double.Parse(projectResult[0]["ContractAmount"].ToString())) + "</td>");
                                else
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                //if (projectResult[0]["budgeted_cost"] != null && (!string.IsNullOrEmpty(projectResult[0]["budgeted_cost"].ToString())))
                                //    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["budgeted_cost"].ToString() + "</td>");
                                //else
                                //    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                if (projectResult[0]["estimated_cost"] != null && (!string.IsNullOrEmpty(projectResult[0]["estimated_cost"].ToString())))
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + string.Format("{0:#,##0.00}", double.Parse(projectResult[0]["estimated_cost"].ToString())) + "</td>");
                                else
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                if (projectResult[0]["TenderStatusShortName"] != null && (!string.IsNullOrEmpty(projectResult[0]["TenderStatusShortName"].ToString())))
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["TenderStatusShortName"].ToString() + "</td>");
                                else
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                if (projectResult[0]["contract_no"] != null && (!string.IsNullOrEmpty(projectResult[0]["contract_no"].ToString())))
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["contract_no"].ToString() + "</td>");
                                else
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                //
                                if (resultStage3 != null && resultStage3.Length > 0)
                                {
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                    sblTenderTracking.Append("<table border=\"0\">");
                                    foreach (DataRow row in resultStage3)
                                    {
                                        sblTenderTracking.Append("<tr>");
                                        //As per Sreedhar "remarks"
                                        if (row["remarks"] != null && (!string.IsNullOrEmpty(row["remarks"].ToString())))
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + row["remarks"].ToString() + "</td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                        sblTenderTracking.Append("</tr>");
                                        break;
                                    }
                                    sblTenderTracking.Append("</table>");
                                    sblTenderTracking.Append("</td>");
                                }
                                else
                                {
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                }

                                sblTenderTracking.Append("</tr>");
                            }
                        }
                    }
                    sblTenderTracking.Append("<tr><td colspan=\"22\" style=\"width:auto;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b style=\"font-style: italic\">This report is generated by TCMS dated :</b><b>" + DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss") + "</b></td></tr>");
                    sblTenderTracking.Append("</table>");
                    lblTotalNoOfRecords.Text = "Total Records Count=" + rowCounter.ToString();
                }
                else
                {
                    lblTotalNoOfRecords.Text = "Total Records Count=0";
                    MessageBox.Show("No data exist for selected options", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred "+ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                
            }
            return sblTenderTracking;
        }

        /// <summary>
        /// getTenderCommitteeHeader method
        /// </summary>
        /// 
        /// <param name="sblTenderTracking"></param>
        /// <returns></returns>
        private StringBuilder getAwardedTenders(StringBuilder sblTenderTracking)
        {
            try
            {
                //string strTenderCommitteeQuery = "select p.proj_id,p.project_newname_en,p.tender_no,d.Department,td.stage_id,td.ptd_receive_on,p.tender_type_id,t.tender_type_name,td.ts_receive_on,td.ts_closing_s1,td.ts_closing_s2,td.eval_tech_sent1,td.eval_tech_receive1,td.eval_com_sent1,td.eval_com_receive1,td.eval_tender_award_approval,td.eval_no_of_meetings,c.co_name,c.co_id,contr.ContractAmount,contr.contract_no,pcost.budgeted_cost,pcost.estimated_cost,tstatus.[TenderStatusShortName],td.remarks" +
                //" from	PROJECTS p" +
                //" left outer JOIN TenderDatesInfo as td on p.proj_id=td.proj_id" +
                //" inner join Department as d on p.department_id=d.department_id" +
                //" inner join [TenderTypes] as t on p.tender_type_id = t.tender_type_id" +
                //" left outer join CONTRACTORS as contr on p.proj_id=contr.proj_id" +
                //" left outer join COMPANY as c on contr.co_id=c.co_id" +
                //" inner join [TenderStatus] as tstatus on p.Tender_Status_id=tstatus.Tender_Status_id" +
                //" left outer join ProjectCost as pcost on p.proj_id=pcost.proj_id where p.tender_no <>'' and td.eval_tender_opening " +
                //"between '" + dtpStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpEndReportDate.Value.ToString("dd/MMM/yyyy") + "'";
                string strTenderCommitteeQuery = null;
                //if (Convert.ToInt16(cmbFiscalyear.SelectedValue) != 0 && startReportDateChanged == 0 && endReportDateChanged == 0)
                //{
                //DataRowView dtView = (DataRowView)cmbFiscalyear.SelectedItem;                   
                //}
                //else
                strTenderCommitteeQuery = "select p.proj_id,p.project_newname_en,p.tender_no,p.project_code,d2.Department,td.stage_id,td.ptd_receive_on,p.tender_type_id,t.tender_type_name,td.ts_tender_issue,td.eval_tender_doc_receive_from_cd,td.ts_closing_s1,td.ts_closing_s2,td.eval_tech_sent1,td.TPWD1,td.eval_tech_receive1,td.eval_com_sent1,td.FPWD1,td.eval_com_receive1,td.eval_tender_award_approval," +
                " td.eval_no_of_meetings,contr.cp_tender_award,c.co_name,c.co_id,contr.ContractAmount,contr.contract_no,pcost.estimated_cost,tstatus.[TenderStatusShortName],td.remarks" +
                " from PROJECTS p left outer JOIN TenderDatesInfo as td on p.proj_id=td.proj_id" +
                " inner join Department2 as d1 on p.department_id=d1.department_id" +
                " inner join Department2 as d2 on d1.newDepID=d2.department_id" +
                " inner join [TenderTypes] as t on p.tender_type_id = t.tender_type_id" +
                " left outer join CONTRACTORS as contr on p.proj_id=contr.proj_id" +
                " left outer join COMPANY as c on contr.co_id=c.co_id" +
                " inner join [TenderStatus] as tstatus on p.Tender_Status_id=tstatus.Tender_Status_id" +
                " left outer join ProjectCost as pcost on p.proj_id=pcost.proj_id where p.tender_no <>''";

                if (whereClause != null)
                {
                    if (whereClause != "")
                    {
                        strTenderCommitteeQuery = strTenderCommitteeQuery + whereClause;  //and td.eval_tender_opening " +
                        //"between '" + dtpStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpEndReportDate.Value.ToString("dd/MMM/yyyy") + "'"
                    }
                }


                strTenderCommitteeQuery = generatedynamicSQLQuery(strTenderCommitteeQuery, false);


                SqlConnection sqlConn = new SqlConnection(strCon);
                DataTable dtTenderCommittee = null;
                sqlConn.Open();
                DAL dalObj = new DAL();
                //dtTenderCommittee = dalObj.GetDataFromDB("TenderCommitteeInfo", strTenderCommitteeQuery);
                dtTenderCommittee = dalObj.GetDataFromDB("TenderCommitteeInfo", strTenderCommitteeQuery + " Order By p.tender_no");

                if (dtTenderCommittee.Rows.Count != 0)
                {
                    sblTenderTracking.Append("<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"border: solid 1px #506E87;\">");// border=\"0\"");// 
                    sblTenderTracking.Append("<tr><td colspan=\"8\" style=\"text-align: center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;\"><b>Tender Report 2021</b></td></tr>");
                    //sblTenderTracking.Append("<tr><td colspan=\"18\" style=\"text-align: left;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #FFFF99;\"><b>Tenders Tracking Information</b></td></tr>");
                    //sblTenderTracking.Append("<tr><td colspan=\"9\" style=\"text-align: left;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;\"><b>PREPARATION OF TENDER DOCUMENTS</b></td><td colspan=\"9\" style=\"text-align: left;height: 35px;font-size: 12pt !important;background-color: #C4D79B;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;\"><b>TENDERING OF PROJECTS</b></td></tr>");

                    //To generate the Tender Tracking Report Header
                    sblTenderTracking.Append("<tr>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>SR</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"></td></tr>");
                    sblTenderTracking.Append("</table>");
                    sblTenderTracking.Append("</td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Tender No.</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"></td></tr>");
                    sblTenderTracking.Append("</table>");
                    sblTenderTracking.Append("</td>");
                    //sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                    //sblTenderTracking.Append("<table border=\"0\">");
                    //sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Project</b></td></tr>");
                    //sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Code</b></td></tr>");
                    //sblTenderTracking.Append("</table>");
                    //sblTenderTracking.Append("</td>");
                    //sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                    //sblTenderTracking.Append("<table border=\"0\">");
                    //sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Tender&nbsp;Title</b></td></tr>");
                    //sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b></b></td></tr>");
                    //sblTenderTracking.Append("</table>");
                    //sblTenderTracking.Append("</td>");
                    //sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                    //sblTenderTracking.Append("<table border=\"0\">");
                    //sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>User</b></td></tr>");
                    //sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Dept.</b></td></tr>");
                    //sblTenderTracking.Append("</table>");
                    //sblTenderTracking.Append("</td>");
                    //sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                    //sblTenderTracking.Append("<table border=\"0\">");
                    //sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Tender No. Request</b></td></tr>");
                    //sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Received</b></td></tr>");
                    //sblTenderTracking.Append("</table>");
                    //sblTenderTracking.Append("</td>");
                    //sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                    //sblTenderTracking.Append("<table border=\"0\">");
                    //sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Tender No. Issued</b></td></tr>");
                    //sblTenderTracking.Append("<tr><td style=\"width:200px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Sent Date</b></td></tr>");
                    //sblTenderTracking.Append("</table>");
                    //sblTenderTracking.Append("</td>");
                    //sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                    //sblTenderTracking.Append("<table border=\"0\">");
                    //sblTenderTracking.Append("<tr><td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Type Of Tender</b></td></tr>");
                    //sblTenderTracking.Append("<tr><td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>D.O/SH.L/P.T</b></td></tr>");
                    //sblTenderTracking.Append("</table>");
                    //sblTenderTracking.Append("</td>");
                    //sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                    //sblTenderTracking.Append("<table border=\"0\">");
                    //sblTenderTracking.Append("<tr><td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Tender Doc.</b></td></tr>");
                    //sblTenderTracking.Append("<tr><td style=\"width:100px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Received</b></td></tr>");
                    //sblTenderTracking.Append("</table>");
                    //sblTenderTracking.Append("</td>");

                    //sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #003366;\">");
                    //sblTenderTracking.Append("<table border=\"0\">");
                    //sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #003366;color: #FFFF00;\"><b>Closing</b></td></tr>");
                    //sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #003366;color: #FFFF00;\"><b>Date</b></td></tr>");
                    //sblTenderTracking.Append("</table>");
                    //sblTenderTracking.Append("</td>");

                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #003366;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td colspan=\"2\" style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #003366;color: #00FFFF;\"><b>Technical Evaluation</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #003366;color: #00FFFF;\"><b>Sent Date</b></td>");
                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #003366;color: #00FFFF;\"><b>Received Date</b></td>");
                    sblTenderTracking.Append("</tr></table>");
                    sblTenderTracking.Append("</td>");

                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #666699;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td colspan=\"2\" style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #666699;color: #FFCC00;\"><b>Financial Evaluation</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #666699;color: #FFCC00;\"><b>Sent Date</b></td>");
                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #666699;color: #FFCC00;\"><b>Received Date</b></td>");
                    sblTenderTracking.Append("</tr></table>");
                    sblTenderTracking.Append("</td>");

                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td colspan=\"3\" style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top:0px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Awarded</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Approval Date</b></td>");
                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>No. of Meeting</b></td>");
                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #00FFFF; color:#000080;\"><b>Award Date</b></td>");                    
                    sblTenderTracking.Append("</tr></table>");
                    sblTenderTracking.Append("</td>");

                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #000080;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color:#000080; color:#00FF00;\"><b>Successful Bidder</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color:#000080; color:#00FF00;\"><b></b></td></tr>");                     
                    sblTenderTracking.Append("</tr></table>");
                    sblTenderTracking.Append("</td>");

                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #CCFFFF;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #CCFFFF; color:#000080;\"><b>Award Letter Issue Date</b></td>");
                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #CCFFFF; color:#000080;\"><b></b></td>");                                        
                    sblTenderTracking.Append("</tr></table>");
                    sblTenderTracking.Append("</td>");

                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #CCFFFF;\">");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #CCFFFF;color:#000080\"><b>Award</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:150px;font-family: Verdana;font-size: 9pt;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #CCFFFF;color:#000080\"><b>Value(QR)</b></td>");
                    sblTenderTracking.Append("</tr></table>");
                    sblTenderTracking.Append("</td>");                                                            

                    sblTenderTracking.Append("</tr>");


                    //string strTenderCommitteeQuery = "select p.proj_id,p.project_newname_en,p.tender_no,d.Department,td.stage_id,td.eval_tender_no_request,p.tender_type_id,t.tender_type_name,td.eval_tender_doc_receive_from_cd,td.ts_closing_s1,td.ts_closing_s2,td.eval_tech_sent1,td.eval_tech_receive1,td.eval_com_sent1,td.eval_com_receive1,td.eval_tender_award_approval,td.eval_no_of_meetings,c.co_name,c.co_id,contr.ContractAmount,contr.contract_no,pcost.budgeted_cost,pcost.estimated_cost,tstatus.[Tender Statsus Short Name],td.remarks" +
                    //" from PROJECTS p,TenderDatesInfo td,Department d,[Type of Tender] t,COMPANY c,[Status of Tender] tstatus,CONTRACTORS contr,ProjectCost pcost"+
                    //" where p.proj_id=td.proj_id and p.department_id=d.department_id and p.tender_type_id=t.tender_type_id and p.proj_id=contr.proj_id and contr.co_id=c.co_id and p.Tender_Status_id=tstatus.Tender_Status_id and p.proj_id=pcost.proj_id";


                    // commented by Varun on 17/02/14 because it is written twice
                    //dtTenderCommittee = dalObj.GetDataFromDB("TenderCommitteeInfo", strTenderCommitteeQuery);

                    //DataTable dtSortedTable = dtTenderCommittee.AsEnumerable().OrderByDescending(row => row.Field<string>("tender_no")).CopyToDataTable();
                    //dtTenderCommittee = dtTenderCommittee.AsEnumerable().OrderBy(row => row.Field<string>("tender_no")).CopyToDataTable();
                    int rowCounter = 0;
                    if (dtTenderCommittee != null && dtTenderCommittee.Rows.Count > 0)
                    {
                        DataTable uniqueProjects = dtTenderCommittee.DefaultView.ToTable(true, "proj_id");
                        for (int intIndexProj = 0; intIndexProj < uniqueProjects.Rows.Count; intIndexProj++)
                        {
                            DataRow[] resultStage2 = dtTenderCommittee.Select("proj_id='" + uniqueProjects.Rows[intIndexProj]["proj_id"].ToString() + "' AND stage_id='2'");
                            DataRow[] projectResult = dtTenderCommittee.Select("proj_id='" + uniqueProjects.Rows[intIndexProj]["proj_id"].ToString() + "'", "tender_no desc");
                            //DataRow[] resultStage4 = dtTenderCommittee.Select("proj_id=" + Convert.ToInt32(uniqueProjects.Rows[intIndexProj]["proj_id"].ToString()) + " AND stage_id=4");
                            DataRow[] resultStage3 = dtTenderCommittee.Select("proj_id='" + uniqueProjects.Rows[intIndexProj]["proj_id"].ToString() + "' AND stage_id='3'");

                            if (projectResult != null && projectResult.Length > 0)
                            {
                                sblTenderTracking.Append("<tr>");
                                sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + ++rowCounter + "</td>");
                                if (projectResult[0]["tender_no"] != null)
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["tender_no"].ToString() + "</td>");
                                else
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                //if (projectResult[0]["project_code"] != null)
                                //    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["project_code"].ToString() + "</td>");
                                //else
                                //    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");


                                //if (projectResult[0]["project_newname_en"] != null)
                                //    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["project_newname_en"].ToString() + "</td>");
                                //else
                                //    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                //if (projectResult[0]["Department"] != null)
                                //    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["Department"].ToString() + "</td>");
                                //else
                                //    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                //if (resultStage3 != null)
                                //{
                                //    if (resultStage3.Length > 0)
                                //    {
                                //        sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                //        sblTenderTracking.Append("<table border=\"0\">");
                                //        foreach (DataRow row in resultStage3)
                                //        {
                                //            sblTenderTracking.Append("<tr>");
                                //            //As per Sreedhar "Tender Opening Date"
                                //            if (row["ptd_receive_on"] != null)
                                //            {
                                //                if (row["ptd_receive_on"].ToString() != "")
                                //                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(row["ptd_receive_on"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                //                else
                                //                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                //            }
                                //            else
                                //                sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                //            sblTenderTracking.Append("</tr>");
                                //            break;
                                //        }
                                //        sblTenderTracking.Append("</table>");
                                //        sblTenderTracking.Append("</td>");
                                //    }
                                //    else
                                //        sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                //}
                                //else
                                //{
                                //    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                //}

                                //
                                //if (resultStage2 != null)
                                //{
                                //    if (resultStage2.Length > 0)
                                //    {
                                //        sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                //        sblTenderTracking.Append("<table border=\"0\">");
                                //        foreach (DataRow row in resultStage3)
                                //        {
                                //            sblTenderTracking.Append("<tr>");
                                //            //As per Sreedhar "Tender Doc. Recivd from CD"
                                //            if (row["ts_tender_issue"] != null)
                                //                if (row["ts_tender_issue"].ToString() != "")
                                //                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(row["ts_tender_issue"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                //                else
                                //                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"></td>");
                                //            sblTenderTracking.Append("</tr>");
                                //            break;
                                //        }
                                //        sblTenderTracking.Append("</table>");
                                //        sblTenderTracking.Append("</td>");
                                //    }
                                //    else
                                //        sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"></td>");
                                //}
                                //else
                                //{
                                //    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"></td>");
                                //}

                                //if (projectResult[0]["tender_type_name"] != null)
                                //{
                                //    if (projectResult[0]["tender_type_name"].ToString() != "")
                                //        sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["tender_type_name"].ToString() + "</td>");
                                //    else
                                //        sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"></td>");
                                //}
                                //else
                                //    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"></td>");


                                //if (resultStage3 != null && resultStage3.Length > 0)
                                //{
                                //    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                //    sblTenderTracking.Append("<table border=\"0\">");
                                //    foreach (DataRow row in resultStage3)
                                //    {
                                //        sblTenderTracking.Append("<tr>");
                                //        //As per Sreedhar "Tender Doc. Recivd from CD"
                                //        if (row["eval_tender_doc_receive_from_cd"] != null)
                                //        {
                                //            if (row["eval_tender_doc_receive_from_cd"].ToString() != "")
                                //                sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(row["eval_tender_doc_receive_from_cd"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                //            else
                                //                sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                //        }
                                //        else
                                //            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                //        sblTenderTracking.Append("</tr>");
                                //        break;
                                //    }
                                //    sblTenderTracking.Append("</table>");
                                //    sblTenderTracking.Append("</td>");
                                //}
                                //else
                                //{
                                //    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                //}

                                ////
                                //if (resultStage2 != null)
                                //{
                                //    if (resultStage2.Length > 0)
                                //    {
                                //        sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                //        sblTenderTracking.Append("<table border=\"0\">");
                                //        foreach (DataRow row in resultStage2)
                                //        {
                                //            sblTenderTracking.Append("<tr>");

                                //            if (row["ts_closing_s1"] != null)
                                //            {
                                //                if (row["ts_closing_s1"].ToString() != "")
                                //                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(row["ts_closing_s1"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                //                else
                                //                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"></td>");
                                //            }
                                //            else
                                //                sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"></td>");

                                //            sblTenderTracking.Append("</tr>");
                                //            break;
                                //        }

                                //        sblTenderTracking.Append("</table>");
                                //        sblTenderTracking.Append("</td>");
                                //    }
                                //    else
                                //        sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                //}
                                //else
                                //{
                                //    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                //    sblTenderTracking.Append("<table border=\"0\"><tr>");
                                //    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                //    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                //    sblTenderTracking.Append("</tr></table></td>");
                                //}

                                //Tech. Evaluation
                                if (resultStage3 != null && resultStage3.Length > 0)
                                {
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                    sblTenderTracking.Append("<table border=\"0\">");
                                    foreach (DataRow row in resultStage3)
                                    {
                                        sblTenderTracking.Append("<tr>");
                                        //As per Sreedhar "Tender Doc. Recivd from CD"
                                        if (row["eval_tech_sent1"] != null && (!string.IsNullOrEmpty(row["eval_tech_sent1"].ToString())))
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(row["eval_tech_sent1"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                        //if (row["TPWD1"] != null && (!string.IsNullOrEmpty(row["TPWD1"].ToString())))
                                        //    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + row["TPWD1"].ToString() + "</td>");
                                        //else
                                        //    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                        if (row["eval_tech_receive1"] != null && (!string.IsNullOrEmpty(row["eval_tech_receive1"].ToString())))
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(row["eval_tech_receive1"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                        sblTenderTracking.Append("</tr>");
                                        break;
                                    }
                                    sblTenderTracking.Append("</table>");
                                    sblTenderTracking.Append("</td>");
                                }
                                else
                                {
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                    sblTenderTracking.Append("<table border=\"0\"><tr>");
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                    //sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                    sblTenderTracking.Append("</tr></table></td>");
                                }


                                //Commercial  Evaluation
                                if (resultStage3 != null && resultStage3.Length > 0)
                                {
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                    sblTenderTracking.Append("<table border=\"0\">");
                                    foreach (DataRow row in resultStage3)
                                    {
                                        sblTenderTracking.Append("<tr>");
                                        //As per Sreedhar "Tender Doc. Recivd from CD"
                                        if (row["eval_com_sent1"] != null && (!string.IsNullOrEmpty(row["eval_com_sent1"].ToString())))
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(row["eval_com_sent1"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                        //if (row["FPWD1"] != null && (!string.IsNullOrEmpty(row["FPWD1"].ToString())))
                                        //    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + row["FPWD1"].ToString() + "</td>");
                                        //else
                                        //    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                        if (row["eval_com_receive1"] != null && (!string.IsNullOrEmpty(row["eval_com_receive1"].ToString())))
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(row["eval_com_receive1"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                        sblTenderTracking.Append("</tr>");
                                        break;
                                    }
                                    sblTenderTracking.Append("</table>");
                                    sblTenderTracking.Append("</td>");
                                }
                                else
                                {
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                    sblTenderTracking.Append("<table border=\"0\"><tr>");
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                    //sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                    sblTenderTracking.Append("</tr></table></td>");
                                }

                                //Awarded
                                if (resultStage3 != null && resultStage3.Length > 0)
                                {
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                    sblTenderTracking.Append("<table border=\"0\">");
                                    foreach (DataRow row in resultStage3)
                                    {
                                        sblTenderTracking.Append("<tr>");
                                        //As per Sreedhar "Tender Doc. Recivd from CD"
                                        if (row["eval_tender_award_approval"] != null && (!string.IsNullOrEmpty(row["eval_tender_award_approval"].ToString())))
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(row["eval_tender_award_approval"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                        if (row["eval_no_of_meetings"] != null)
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + row["eval_no_of_meetings"].ToString() + "</td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</b></td>");

                                        if (row["cp_tender_award"].ToString() != "")
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(row["cp_tender_award"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</b></td>");

                                        sblTenderTracking.Append("</tr>");
                                        break;
                                    }
                                    sblTenderTracking.Append("</table>");
                                    sblTenderTracking.Append("</td>");
                                }
                                else
                                {
                                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                    sblTenderTracking.Append("<table border=\"0\"><tr>");
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                    sblTenderTracking.Append("</tr></table></td>");
                                }

                                if (projectResult[0]["co_name"] != null && (!string.IsNullOrEmpty(projectResult[0]["co_name"].ToString())))
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["co_name"].ToString() + "</td>");
                                else
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                if (projectResult[0]["cp_tender_award"] != null && (!string.IsNullOrEmpty(projectResult[0]["cp_tender_award"].ToString())))
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(projectResult[0]["cp_tender_award"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                else
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                if (projectResult[0]["ContractAmount"] != null && (!string.IsNullOrEmpty(projectResult[0]["ContractAmount"].ToString())))
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + string.Format("{0:#,##0.00}", double.Parse(projectResult[0]["ContractAmount"].ToString())) + "</td>");
                                else
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                //if (projectResult[0]["budgeted_cost"] != null && (!string.IsNullOrEmpty(projectResult[0]["budgeted_cost"].ToString())))
                                //    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["budgeted_cost"].ToString() + "</td>");
                                //else
                                //    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                //if (projectResult[0]["estimated_cost"] != null && (!string.IsNullOrEmpty(projectResult[0]["estimated_cost"].ToString())))
                                //    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + string.Format("{0:#,##0.00}", double.Parse(projectResult[0]["estimated_cost"].ToString())) + "</td>");
                                //else
                                //    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                //if (projectResult[0]["TenderStatusShortName"] != null && (!string.IsNullOrEmpty(projectResult[0]["TenderStatusShortName"].ToString())))
                                //    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["TenderStatusShortName"].ToString() + "</td>");
                                //else
                                //    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                //if (projectResult[0]["contract_no"] != null && (!string.IsNullOrEmpty(projectResult[0]["contract_no"].ToString())))
                                //    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["contract_no"].ToString() + "</td>");
                                //else
                                //    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                //
                                //if (resultStage3 != null && resultStage3.Length > 0)
                                //{
                                //    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                //    sblTenderTracking.Append("<table border=\"0\">");
                                //    foreach (DataRow row in resultStage3)
                                //    {
                                //        sblTenderTracking.Append("<tr>");
                                //        //As per Sreedhar "remarks"
                                //        if (row["remarks"] != null && (!string.IsNullOrEmpty(row["remarks"].ToString())))
                                //            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">" + row["remarks"].ToString() + "</td>");
                                //        else
                                //            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                //        sblTenderTracking.Append("</tr>");
                                //        break;
                                //    }
                                //    sblTenderTracking.Append("</table>");
                                //    sblTenderTracking.Append("</td>");
                                //}
                                //else
                                //{
                                //    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                //}

                                sblTenderTracking.Append("</tr>");
                            }
                        }
                    }
                    sblTenderTracking.Append("<tr><td colspan=\"8\" style=\"width:auto;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b style=\"font-style: italic\">This report is generated by TCMS dated :</b><b>" + DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss") + "</b></td></tr>");
                    sblTenderTracking.Append("</table>");
                    lblTotalNoOfRecords.Text = "Total Records Count=" + rowCounter.ToString();
                }
                else
                {
                    lblTotalNoOfRecords.Text = "Total Records Count=0";
                    MessageBox.Show("No data exist for selected options", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return sblTenderTracking;
        }
        /// <summary>
        /// 
        /// </summary>
        /// 
        /// <param name="sblTenderTracking"></param>
        /// <returns></returns>
        private StringBuilder getProjectTrackingHeader(StringBuilder sblProjectTracking, DataTable dtAffairs)
        {
            try
            {
                string strProjectTrackingQuery = "SELECT p.Affair_id,p.proj_id,td.stage_id,p.project_code AS [Project Code],p.project_name_en As [Project Title], " +
                " p.[Ministry_Code]+'/'+p.[Budget_Reference_No] As [Min. Code/Budget RefNo],p.[Provision_Number] As [Provision],p.[tender_no] As [Tender Number], " +
                " td.ts_tender_issue As [Tender Issue],td.ts_closing_s1 As [Tender Closing], " +
                " cots.cp_received_of_doc As [Received of Document], " +
                " cots.cp_tender_award AS [Tender Award], " +
                " cots.StaffInCharge As [Handling by], " +
                " cots.cp_request_start_date As [Req. Dept. to Provide Start Date], " +
                " cots.cp_start_date_receive As [Start Date Receive], " +
                " cots.cp_notice_contractor_to_sign As [Notice sent to Tenderer to Sign Contract], " +
                " cots.cp_due_date_pb As [Due Date of Submission of PB etc. & Sign], " +
                " co.co_name As [Successful Tenderer], " +
                " cots.ContractAmount As [Value of Contract], " +
                " cots.cp_contractor_sign As [Date of Sign Contract], " +
                " cots.cp_sent_dep_sign As [Sent to Dept for sign], " +
                " cots.cp_receive_dep_sent_prsd As [Rcvd. from Dept. and Sent to PRSD. for sign], " +
                " cots.cp_sent_fd_commit AS [Sent to Finance Dept.  for Committment], " +
                " cots.cp_receive_fd_commit As [Rcvd. From Finance Dept], " +
                " cots.cp_distribution As [Distribution], " +
                " cots.contract_no As [Contract No],d2.Department " +
                " FROM projects p left outer join CONTRACTORS as cots on p.proj_id=cots.proj_id" +
                " left outer Join COMPANY as co on co.co_id=cots.co_id" +
                " left outer JOIN TenderDatesinfo as td ON p.proj_id = td.proj_id inner join Department2 as d1 on p.department_id=d1.department_id" +
                " inner join Department2 as d2 on d1.newDepID=d2.department_id where p.proj_id>0 and cots.cp_received_of_doc " +
                "between '" + dtpStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpEndReportDate.Value.ToString("dd/MMM/yyyy") + "'"; // +whereClause;

                if (whereClause != null)
                {
                    if (whereClause != "")
                    {
                        strProjectTrackingQuery = strProjectTrackingQuery + " and" + whereClause;
                    }                    
                }
                 

                strProjectTrackingQuery = generatedynamicSQLQuery(strProjectTrackingQuery,false);

                SqlConnection sqlConn = new SqlConnection(strCon);
                DataTable dtProjectTracking = null;
                sqlConn.Open();
                DAL dalObj = new DAL();


                dtProjectTracking = dalObj.GetDataFromDB("ProjectTrackingInfo", strProjectTrackingQuery);

                if (dtProjectTracking.Rows.Count != 0)
                {
                    sblProjectTracking.Append("<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"border: solid 1px #506E87;\">");// border=\"0\"");// 
                    sblProjectTracking.Append("<tr><td colspan=\"25\" style=\"text-align: center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;\"><b>PWA - CONTRACTS DEPARTMENT</b></td></tr>");
                    sblProjectTracking.Append("<tr><td colspan=\"25\" style=\"text-align: center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #FFFF99;\"><b>Projects Tracking Information</b></td></tr>");

                    //To generate the Tender Tracking Report Header
                    sblProjectTracking.Append("<tr>");
                    sblProjectTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>SNo.</b></td>");
                    sblProjectTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>Project&nbsp;Code</b></td>");
                    sblProjectTracking.Append("<td style=\"width:300px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>Project&nbsp;Title</b></td>");
                    sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>Budget No/Ref</b></td>");
                    sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>Provision</b></td>");
                    sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>Tender Number</b></td>");
                    sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>Tender Issue</b></td>");
                    sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>Tender Closing</b></td>");
                    sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>Tender Award</b></td>");
                    sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>Handling by</b></td>");
                    sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>Successful Tenderer</b></td>");
                    sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>Value of Contract</b></td>");

                    sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>Received of Document</b></td>");
                    sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #33CCCC;\"><b>Req. Dept. to Provide Start Date</b></td>");
                    sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #33CCCC;\"><b>Start Date Receive</b></td>");
                    sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FF99CC;\"><b>Notice sent to Tenderer to Sign Contract</b></td>");
                    sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FF99CC;\"><b>Due Date of Submission of PB etc. & Sign.</b></td>");

                    sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b> Date of Sign Contract</b></td>");
                    sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #99CC00;\"><b>Sent to Dept for sign.</b></td>");
                    sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #99CC00;\"><b>Rcvd. from Dept. and Sent to PRSD. for sign.</b></td>");
                    sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #99CC00;\"><b>Sent to Finance Dept.  for Committment</b></td>");

                    sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>Rcvd. From Finance Dept.</b></td>");
                    sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>Distribution</b></td>");
                    sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>Contract No.</b></td>");
                    sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>Department</b></td>");

                    sblProjectTracking.Append("</tr>");

                    //generate dynamic query               //Sree


                    DataRow[] selectedAffairs = null;
                    if (cmbDepartment.SelectedValue != null && (Convert.ToInt32(cmbDepartment.SelectedValue.ToString()) > 0))
                        selectedAffairs = dtAffairs.Select("Affair_id='" + cmbDepartment.SelectedValue.ToString() + "'");
                    else
                        selectedAffairs = dtAffairs.Select("Affair_id>0");

                    int rowCounter = 0;
                    foreach (DataRow affairsRow in selectedAffairs)
                    {
                        sblProjectTracking.Append("<tr><td colspan=\"25\" style=\"text-align: center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #00CCFF;\">" + affairsRow["Affairs_Name"].ToString() + "</td></tr>");
                        if (dtProjectTracking != null && dtProjectTracking.Rows.Count > 0)
                        {
                            //To Get the unique projects
                            DataTable uniqueProjects = dtProjectTracking.DefaultView.ToTable(true, "proj_id");
                            for (int intIndexProj = 0; intIndexProj < uniqueProjects.Rows.Count; intIndexProj++)
                            {
                                //DataRow[] result = dtProjectTracking.Select("Affair_id=" + Convert.ToInt32(affairsRow["Affair_id"].ToString()) + " AND proj_id=" + Convert.ToInt32(uniqueProjects.Rows[intIndexProj]["proj_id"].ToString()) + " AND stage_id=1");
                                DataRow[] projectResult = dtProjectTracking.Select("Affair_id=" + Convert.ToInt32(affairsRow["Affair_id"].ToString()) + " AND proj_id=" + Convert.ToInt32(uniqueProjects.Rows[intIndexProj]["proj_id"].ToString()) + "");
                                DataRow[] resultHandlingBy = dtProjectTracking.Select("Affair_id=" + Convert.ToInt32(affairsRow["Affair_id"].ToString()) + " AND proj_id=" + Convert.ToInt32(uniqueProjects.Rows[intIndexProj]["proj_id"].ToString()) + " AND stage_id=4");

                                if (projectResult != null && projectResult.Length > 0)
                                {
                                    sblProjectTracking.Append("<tr>");
                                    rowCounter = rowCounter + 1;
                                    sblProjectTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + rowCounter + "</td>");
                                    if (projectResult[0]["Project Code"] != null && (!string.IsNullOrEmpty(projectResult[0]["Project Code"].ToString())))
                                        sblProjectTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["Project Code"].ToString() + "</td>");
                                    else
                                        sblProjectTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                    if (projectResult[0]["Project Title"] != null && (!string.IsNullOrEmpty(projectResult[0]["Project Title"].ToString())))
                                        sblProjectTracking.Append("<td style=\"width:300px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["Project Title"].ToString() + "</td>");
                                    else
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                    if (projectResult[0]["Min. Code/Budget RefNo"] != null && (!string.IsNullOrEmpty(projectResult[0]["Min. Code/Budget RefNo"].ToString())) && (!projectResult[0]["Min. Code/Budget RefNo"].ToString().Equals("/")))
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["Budget No/Ref"].ToString() + "</td>");
                                    else
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                    if (projectResult[0]["Provision"] != null && (!string.IsNullOrEmpty(projectResult[0]["Provision"].ToString())))
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["Provision"].ToString() + "</td>");
                                    else
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                    if (projectResult[0]["Tender Number"] != null && (!string.IsNullOrEmpty(projectResult[0]["Tender Number"].ToString())))
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["Tender Number"].ToString() + "</td>");
                                    else
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                    if (projectResult[0]["Tender Issue"] != null && (!string.IsNullOrEmpty(projectResult[0]["Tender Issue"].ToString())))
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(projectResult[0]["Tender Issue"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                    else
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                    if (projectResult[0]["Tender Closing"] != null && (!string.IsNullOrEmpty(projectResult[0]["Tender Closing"].ToString())))
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(projectResult[0]["Tender Closing"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                    else
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                    if (projectResult[0]["Tender Award"] != null && (!string.IsNullOrEmpty(projectResult[0]["Tender Award"].ToString())))
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(projectResult[0]["Tender Award"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                    else
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                    if (projectResult[0]["Handling by"] != null && (!string.IsNullOrEmpty(projectResult[0]["Handling by"].ToString())))
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["Handling by"].ToString() + "</td>");
                                    else
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                    if (projectResult[0]["Successful Tenderer"] != null && (!string.IsNullOrEmpty(projectResult[0]["Successful Tenderer"].ToString())))
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["Successful Tenderer"].ToString() + "</td>");
                                    else
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                    if (projectResult[0]["Value of Contract"] != null && (!string.IsNullOrEmpty(projectResult[0]["Value of Contract"].ToString())))
                                    {
                                        Double totAmount = Double.Parse(projectResult[0]["Value of Contract"].ToString());
                                        //totAmount.ToString("C");
                                        string strAmount = totAmount.ToString("C");
                                        strAmount = strAmount.Replace("$", "");
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + strAmount + "</td>");
                                    }
                                    else
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                    if (projectResult[0]["Received of Document"] != null && (!string.IsNullOrEmpty(projectResult[0]["Received of Document"].ToString())))
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(projectResult[0]["Received of Document"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                    else
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                    if (projectResult[0]["Req. Dept. to Provide Start Date"] != null && (!string.IsNullOrEmpty(projectResult[0]["Req. Dept. to Provide Start Date"].ToString())))
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(projectResult[0]["Req. Dept. to Provide Start Date"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                    else
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                    if (projectResult[0]["Start Date Receive"] != null && (!string.IsNullOrEmpty(projectResult[0]["Start Date Receive"].ToString())))
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(projectResult[0]["Start Date Receive"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                    else
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                    if (projectResult[0]["Notice sent to Tenderer to Sign Contract"] != null && (!string.IsNullOrEmpty(projectResult[0]["Notice sent to Tenderer to Sign Contract"].ToString())))
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(projectResult[0]["Notice sent to Tenderer to Sign Contract"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                    else
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                    if (projectResult[0]["Due Date of Submission of PB etc. & Sign"] != null && (!string.IsNullOrEmpty(projectResult[0]["Due Date of Submission of PB etc. & Sign"].ToString())))
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(projectResult[0]["Due Date of Submission of PB etc. & Sign"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                    else
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                    if (projectResult[0]["Date of Sign Contract"] != null && (!string.IsNullOrEmpty(projectResult[0]["Date of Sign Contract"].ToString())))
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(projectResult[0]["Date of Sign Contract"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                    else
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                    if (projectResult[0]["Sent to Dept for sign"] != null && (!string.IsNullOrEmpty(projectResult[0]["Sent to Dept for sign"].ToString())))
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(projectResult[0]["Sent to Dept for sign"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                    else
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                    if (projectResult[0]["Rcvd. from Dept. and Sent to PRSD. for sign"] != null && (!string.IsNullOrEmpty(projectResult[0]["Rcvd. from Dept. and Sent to PRSD. for sign"].ToString())))
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(projectResult[0]["Rcvd. from Dept. and Sent to PRSD. for sign"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                    else
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                    if (projectResult[0]["Sent to Finance Dept.  for Committment"] != null && (!string.IsNullOrEmpty(projectResult[0]["Sent to Finance Dept.  for Committment"].ToString())))
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(projectResult[0]["Sent to Finance Dept.  for Committment"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                    else
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                    if (projectResult[0]["Rcvd. From Finance Dept"] != null && (!string.IsNullOrEmpty(projectResult[0]["Rcvd. From Finance Dept"].ToString())))
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(projectResult[0]["Rcvd. From Finance Dept"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                    else
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                    if (projectResult[0]["Distribution"] != null && (!string.IsNullOrEmpty(projectResult[0]["Distribution"].ToString())))
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + Convert.ToDateTime(projectResult[0]["Distribution"].ToString()).ToString("dd-MMM-yyyy") + "</td>");
                                    else
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                    if (projectResult[0]["Contract No"] != null && (!string.IsNullOrEmpty(projectResult[0]["Contract No"].ToString())))
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["Contract No"].ToString() + "</td>");
                                    else
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");

                                    if (projectResult[0]["Department"] != null && (!string.IsNullOrEmpty(projectResult[0]["Department"].ToString())))
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">" + projectResult[0]["Department"].ToString() + "</td>");
                                    else
                                        sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">&nbsp;</td>");
                                    
                                    sblProjectTracking.Append("</tr>");
                                    lblTotalNoOfRecords.Text = "Total Records Count=" + rowCounter.ToString();
                                }

                            }                             
                        }
                         
                    }
                    sblProjectTracking.Append("<tr><td colspan=\"25\" style=\"width:auto;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b style=\"font-style: italic\">This report is generated by TCMS dated :</b><b>" + DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss") + "</b></td></tr>");
                    sblProjectTracking.Append("</table>");
                    
                }
                else
                {
                    lblTotalNoOfRecords.Text = "Total Records Count=0";
                    MessageBox.Show("No data exist for selected options", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            return sblProjectTracking;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sblTenderTracking"></param>
        /// <returns></returns>
        private StringBuilder getTenderCollectionSummaryReport(StringBuilder sblProjectTracking)
        {
            try
            {
                sblProjectTracking.Append("<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"border: solid 1px #506E87;\">");// border=\"0\"");// 
                sblProjectTracking.Append("<tr><td colspan=\"2\" style=\"text-align: center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;\"><b>Tender Collection Summary</b></td></tr>");

                //To generate the Tender Tracking Report Header
                sblProjectTracking.Append("<tr>");
                sblProjectTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>Tender No. :&nbsp;</b></td>");
                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>value</b></td>");
                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>Project ID. :&nbsp;</b></td>");
                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>value</b></td>");
                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>Project Title :&nbsp;</b></td>");
                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>Tender Issue</b></td>");
                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>Tender Closing</b></td>");
                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>Tender Award</b></td>");
                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>Handling by</b></td>");
                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>Successful Tenderer</b></td>");
                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>Value of Contract</b></td>");

                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>Received of Document</b></td>");
                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #33CCCC;\"><b>Req. Dept. to Provide Start Date</b></td>");
                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #33CCCC;\"><b>Start Date Receive</b></td>");
                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FF99CC;\"><b>Notice sent to Tenderer to Sign Contract</b></td>");
                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FF99CC;\"><b>Due Date of Submission of PB etc. & Sign.</b></td>");

                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b> Date of Sign Contract</b></td>");
                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #99CC00;\"><b>Sent to Dept for sign.</b></td>");
                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #99CC00;\"><b>Rcvd. from Dept. and Sent to PRSD. for sign.</b></td>");
                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #99CC00;\"><b>Sent to Finance Dept.  for Committment</b></td>");

                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>Rcvd. From Finance Dept.</b></td>");
                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>Distribution</b></td>");
                sblProjectTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC00;\"><b>Contract No.</b></td>");

                sblProjectTracking.Append("</tr>");
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            return sblProjectTracking;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="strTenderTrackingQuery"></param>
        /// <returns></returns>
        private string generatedynamicSQLQuery(string strTenderTrackingQuery,bool isWorkOrder)
        {
            //string strTenderTrackingQuery = string.Empty;
            try
            {
                //strTenderTrackingQuery = "select p.proj_id,p.project_newname_en,p.project_code,p.Affair_id,td.ptd_receive_on,td.stage_id,td.ptd_purpose,td.ptd_assign_qs,td.ptd_sent_for_rev,td.ptd_qs_working_status,td.ptd_tendec_doc_cur_status,td.ptd_forwarded_to_dep,td.ts_receive_on,td.ts_issue_handling,td.ts_return_to_dept,td.ts_receive_from_dept,p.tender_no,td.ts_pr_advertise,td.ts_tender_issue,td.ts_closing_s1,td.ts_modified_closing from PROJECTS p,TenderDatesInfo td where p.proj_id=td.proj_id";
                
                string strCondition = string.Empty;
                if (cmbDepartment.Visible)
                {
                    if (cmbDepartment.SelectedValue != null)
                    {
                        if (cmbDepartment.SelectedValue.ToString() != "0")
                            strCondition = "p.Affair_id=" + cmbDepartment.SelectedValue + "";
                    }
                }
                if (cmbAffairs.Visible)
                {
                    if (cmbAffairs.SelectedValue != null)
                    {
                        if (!string.IsNullOrEmpty(strCondition))
                        {
                            if (cmbAffairs.SelectedValue.ToString() != "0")
                            {
                                strCondition = strCondition + " AND " + "p.department_id=" + cmbAffairs.SelectedValue + "";
                            }
                        }
                        else
                        {
                            if (cmbAffairs.SelectedValue.ToString() != "0")
                            {
                                strCondition = "p.department_id=" + cmbAffairs.SelectedValue + "";
                            }
                        }
                    }
                }
                if (cmbTenderCommittee.Visible)
                {
                    if (cmbTenderCommittee.SelectedValue != null)
                    {
                        if (!string.IsNullOrEmpty(strCondition))
                        {
                            if (cmbTenderCommittee.SelectedValue.ToString() != "0")
                            {
                                strCondition = strCondition + " AND " + "p.committee_id=" + cmbTenderCommittee.SelectedValue + "";
                            }
                        }
                        else
                        {
                            if (cmbTenderCommittee.SelectedValue.ToString() != "0")
                            {
                                strCondition = "p.committee_id=" + cmbTenderCommittee.SelectedValue + "";
                            }
                        }
                    }
                }
                if (cmbTenderStage.Visible)
                {
                    if (cmbTenderStage.SelectedValue != null)
                    {
                        if (!string.IsNullOrEmpty(strCondition))
                        {
                            if (cmbTenderStage.SelectedValue.ToString() != "0")
                            {
                                strCondition = strCondition + " AND " + "p.stage_id=" + cmbTenderStage.SelectedValue + "";
                            }
                        }
                        else
                        {
                            if (cmbTenderStage.SelectedValue.ToString() != "0")
                            {
                                strCondition = "p.stage_id=" + cmbTenderStage.SelectedValue + "";
                            }
                        }
                    }
                }
                if (cmbTenderType.Visible)
                {
                    if (cmbTenderType.SelectedValue != null)
                    {
                        if (!string.IsNullOrEmpty(strCondition))
                        {
                            if (cmbTenderType.SelectedValue.ToString() != "0")
                            {
                                strCondition = strCondition + " AND " + "p.tender_type_id=" + cmbTenderType.SelectedValue + "";
                            }
                        }
                        else
                        {
                            if (cmbTenderType.SelectedValue.ToString() != "0")
                            {
                                strCondition = "p.tender_type_id=" + cmbTenderType.SelectedValue + "";
                            }
                        }
                    }
                }

                if (cmbTenderStatus.Visible)
                {
                    if (cmbTenderStatus.SelectedValue != null)
                    {
                        if (!string.IsNullOrEmpty(strCondition))
                        {
                            if (cmbTenderStatus.SelectedValue.ToString() != "0")
                            {
                                strCondition = strCondition + " AND " + "p.Tender_Status_id=" + cmbTenderStatus.SelectedValue + "";
                            }
                        }
                        else
                        {
                            if (cmbTenderStatus.SelectedValue.ToString() != "0")
                            {
                                strCondition = "p.Tender_Status_id=" + cmbTenderStatus.SelectedValue + "";
                            }
                        }
                    }
                }

                if (cmbContractType.Visible)
                {
                    if (cmbContractType.SelectedValue != null)
                    {
                        if (!string.IsNullOrEmpty(strCondition))
                        {
                            if (cmbContractType.SelectedValue.ToString() != "0")
                            {
                                strCondition = strCondition + " AND " + "p.contract_type_id=" + cmbContractType.SelectedValue + "";
                            }
                        }
                        else
                        {
                            if (cmbContractType.SelectedValue.ToString() != "0")
                            {
                                strCondition = "p.contract_type_id=" + cmbContractType.SelectedValue + "";
                            }
                        }
                    }
                }
                if (startReportDateChanged == 0 && endReportDateChanged == 0)
                {
                    if (cmbFiscalyear.Visible)
                    {
                        if (cmbFiscalyear.SelectedValue != null)
                        {
                            if (!string.IsNullOrEmpty(strCondition))
                            {
                                if (strReportChoice.Equals("Work Order"))
                                {
                                    if (cmbFiscalyear.SelectedValue.ToString() != "0")
                                    {
                                        if (cmbFiscalyear.Text.Contains("-"))
                                        {
                                            strCondition = strCondition + " AND " + "(Year(contr.cp_tender_award)= '" + cmbFiscalyear.Text.Split('-')[0] + "' or Year(contr.cp_tender_award)= '" + cmbFiscalyear.Text.Split('-')[1] + "')";
                                        }
                                        else
                                        {
                                            strCondition = strCondition + " AND " + "(Year(contr.cp_tender_award)= '" + cmbFiscalyear.Text + "')";
                                        }
                                    }
                                }
                                else if (cmbFiscalyear.SelectedValue.ToString() != "0")
                                {
                                    strCondition = strCondition + " AND " + "p.FYID=" + cmbFiscalyear.SelectedValue + "";
                                }
                            }
                            else
                            {
                                if (strReportChoice.Equals("Work Order"))
                                {
                                    if (cmbFiscalyear.SelectedValue.ToString() != "0")
                                    {
                                        if (cmbFiscalyear.Text.Contains("-"))
                                        {
                                            strCondition = "(Year(contr.cp_tender_award)= '" + cmbFiscalyear.Text.Split('-')[0] + "' or Year(contr.cp_tender_award)= '" + cmbFiscalyear.Text.Split('-')[1] + "')";
                                        }
                                        else
                                        {
                                            strCondition = "(Year(contr.cp_tender_award)= '" + cmbFiscalyear.Text + "')";
                                        }
                                    }
                                }
                                else if (cmbFiscalyear.SelectedValue.ToString() != "0")
                                {
                                    strCondition = "p.FYID=" + cmbFiscalyear.SelectedValue + "";
                                }
                            }
                        }
                    }
                }
                
                if (startReportDateChanged == 1 || endReportDateChanged == 1)
                {
                    if (!string.IsNullOrEmpty(strCondition))
                    {
                        if (strReportChoice.Equals("Tender Tracking"))
                        {
                            strCondition = strCondition + " AND " + "td.ptd_receive_on between '" + dtpStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpEndReportDate.Value.ToString("dd/MMM/yyyy") + "'";
                        }
                        else if (strReportChoice.Equals("Tender Committee"))
                        {
                            strCondition = strCondition + " AND " + "td.eval_tender_opening between '" + dtpStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpEndReportDate.Value.ToString("dd/MMM/yyyy") + "'";
                        }
                    }
                    else
                    {
                        if (strReportChoice.Equals("Tender Tracking"))
                        {
                            strCondition = "td.ptd_receive_on between '" + dtpStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpEndReportDate.Value.ToString("dd/MMM/yyyy") + "'";
                        }
                        if (strReportChoice.Equals("Tender Committee"))
                        {
                            strCondition = "td.eval_tender_opening between '" + dtpStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpEndReportDate.Value.ToString("dd/MMM/yyyy") + "'";
                        }

                    }
                }

                if (!string.IsNullOrEmpty(strCondition))
                {
                    if (!(strTenderTrackingQuery.Contains("where") || strTenderTrackingQuery.Contains("WHERE")))
                    {
                        if (whereClause != "")
                        {
                            strTenderTrackingQuery = strTenderTrackingQuery + " where " + strCondition + " and" + whereClause + " and p.isDeleted=0 and (td.ts_tender_issue IS NULL)";
                        }
                        else
                        {
                            strTenderTrackingQuery = strTenderTrackingQuery + " where " + strCondition + " and p.isDeleted=0 and (td.ts_tender_issue IS NULL)";
                        }
                    }
                    else
                    {
                        if (whereClause != "")
                        {
                            strTenderTrackingQuery = strTenderTrackingQuery + " and " + strCondition + " and" + whereClause + " and p.isDeleted=0 and (td.ts_tender_issue IS NULL)";
                        }
                        else
                        {
                            strTenderTrackingQuery = strTenderTrackingQuery + " and " + strCondition + " and p.isDeleted=0 and (td.ts_tender_issue IS NULL)";
                        }
                    }
                }
                else
                {
                    if (!(strTenderTrackingQuery.Contains("where") || strTenderTrackingQuery.Contains("WHERE")))
                    {
                        if (whereClause != null)
                        {
                            if (whereClause != "")
                            {
                                strTenderTrackingQuery = strTenderTrackingQuery + " where " + whereClause.Substring(4) + " and p.isDeleted=0 and (td.ts_tender_issue IS NULL)";
                            }
                            else
                            {
                                strTenderTrackingQuery = strTenderTrackingQuery + " where p.isDeleted=0 and (td.ts_tender_issue IS NULL)";
                            }
                            
                        }
                    }
                    else
                    {
                        if (whereClause != null)
                        {
                            if (whereClause != "")
                            {
                                strTenderTrackingQuery = strTenderTrackingQuery + " and " + whereClause.Substring(4) + " and p.isDeleted=0 and (td.ts_tender_issue IS NULL)";
                            }
                            else
                            {
                                strTenderTrackingQuery = strTenderTrackingQuery + " and p.isDeleted=0 and (td.ts_tender_issue IS NULL)";
                            }
                            
                        }
                        else
                        {
                            strTenderTrackingQuery = strTenderTrackingQuery + " and p.isDeleted=0 and (td.ts_tender_issue IS NULL)";
                        }
                    }
                }

                if (!(strTenderTrackingQuery.Contains("where") || strTenderTrackingQuery.Contains("WHERE")))
                {
                    strTenderTrackingQuery = strTenderTrackingQuery + " where p.isDeleted=0 and (td.ts_tender_issue IS NULL)";
                }

                if(isWorkOrder)
                {
                    strTenderTrackingQuery = strTenderTrackingQuery.Replace("and (td.ts_tender_issue IS NULL)", "")+" order by contr.cp_tender_award";
                }
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
                
            }
            return strTenderTrackingQuery;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sblTenderTracking"></param>
        /// <returns></returns>
        private StringBuilder getTenderTrackingHeader(StringBuilder sblTenderTracking, DataTable dtAffairs)
        {
            try
            {
                string strTenderTrackingQuery = "select p.proj_id,p.project_newname_en,p.project_code,p.tender_no,aff2.Affair_id,td.ptd_receive_on,td.stage_id," +
                " td.ptd_purpose,td.ptd_assign_qs,td.ptd_sent_for_rev,td.ptd_qs_working_status,td.ptd_tendec_doc_cur_status, " +
                " td.ptd_forwarded_to_dep,dp2.Department from " +
                " PROJECTS p left outer join TenderDatesInfo as td on p.proj_id=td.proj_id INNER JOIN Department2 dp1 ON p.department_id = dp1.department_id INNER JOIN Department2 dp2 ON dp1.newDepID = dp2.department_id INNER JOIN " +
                "FiscalYear ON p.FYID=FiscalYear.FYID INNER JOIN AFFAIRS2 aff1 ON p.Affair_id=aff1.Affair_id INNER JOIN AFFAIRS2 aff2 ON aff1.newAffairID=aff2.Affair_id INNER JOIN Committee ON p.committee_id = Committee.committee_id INNER JOIN " +
                "TenderStatus ON p.Tender_Status_id = TenderStatus.Tender_Status_id INNER JOIN TenderTypes ON p.tender_type_id = TenderTypes.tender_type_id INNER JOIN ContractTypes ON "+
                "p.contract_type_id = ContractTypes.contract_type_id INNER JOIN STAGES ON p.stage_id = STAGES.stage_id";                 

                strTenderTrackingQuery=generatedynamicSQLQuery(strTenderTrackingQuery,false);
                
                SqlConnection sqlConn = new SqlConnection(strCon);

                DataTable dtTenderTracking = null;
                sqlConn.Open();
                DAL dalObj = new DAL();
                dtTenderTracking = dalObj.GetDataFromDB("TenderTrackingInfo", strTenderTrackingQuery);

                if (dtTenderTracking.Rows.Count != 0)
                {
                    sblTenderTracking.Append("<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"border: solid 1px #506E87;\">");// border=\"0\"");// 
                    sblTenderTracking.Append("<tr><td colspan=\"19\" style=\"text-align: center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;\"><b>PWA - CONTRACTS DEPARTMENT</b></td></tr>");
                    sblTenderTracking.Append("<tr><td colspan=\"19\" style=\"text-align: center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #FFFF99;\"><b>Tenders Tracking Information</b></td></tr>");
                    sblTenderTracking.Append("<tr><td colspan=\"10\" style=\"text-align: center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;\"><b>PREPARATION OF TENDER DOCUMENTS</b></td><td colspan=\"9\" style=\"text-align: center;height: 35px;font-size: 12pt !important;background-color: #C4D79B;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;\"><b>TENDERING OF PROJECTS</b></td></tr>");

                    //To generate the Tender Tracking Report Header
                    sblTenderTracking.Append("<tr>");
                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC99;\"><b>SNo.</b></td>");
                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC99;\"><b>Project&nbsp;Title</b></td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC99;\"><b>Project&nbsp;Code</b></td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC99;\"><b>Receive&nbsp;ON</b></td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC99;\"><b>Purpose (Review / Preparation / Amendment / Re-Tender)</b></td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC99;\"><b>QS</b></td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC99;\"><b>Sent to Dept. for Review / with Comments</b></td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC99;\"><b>QS Working Status</b></td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC99;\"><b>Current&nbsp;Status</b></td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC99;\"><b>Forwarded to Dept.</b></td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC99;\"><b>Receive on (For Tendering)</b></td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC99;\"><b>Tender Issues Handling by:</b></td>");

                    sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #FFCC99;\"><b></b>");
                    sblTenderTracking.Append("<table border=\"0\">");
                    sblTenderTracking.Append("<tr><td colspan=\"2\" style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #FFCC99;\"><b>IF Comments</b></td></tr>");
                    sblTenderTracking.Append("<tr><td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #FFCC99;\"><b>Returned to Dept.</b></td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;background-color: #FFCC99;\"><b>Received from Dept.</b></td>");
                    sblTenderTracking.Append("</tr></table>");
                    sblTenderTracking.Append("</td>");

                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC99;\"><b>Tender&nbsp;Number</b></td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC99;\"><b>Sent to Public Relations Dept. for ADVERTISEMENT</b></td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC99;\"><b>Tender Issue Date</b></td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC99;\"><b>Tender Closing Date</b></td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC99;\"><b>Modified Closing Date</b></td>");
                    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC99;\"><b>Department Name</b></td>");
                    sblTenderTracking.Append("</tr>");


                    //string strTenderTrackingQuery = "select p.proj_id,p.project_newname_en,p.project_code,p.Affair_id,td.ptd_receive_on,td.stage_id,td.ptd_purpose,td.ptd_assign_qs,td.ptd_sent_for_rev,td.ptd_qs_working_status,td.ptd_tendec_doc_cur_status,td.ptd_forwarded_to_dep,td.ts_receive_on,td.ts_issue_handling,td.ts_return_to_dept,td.ts_receive_from_dept,p.tender_no,td.ts_pr_advertise,td.ts_tender_issue,td.ts_closing_s1,td.ts_modified_closing from PROJECTS p,TenderDatesInfo td where p.proj_id=td.proj_id";



                    DataRow[] selectedAffairs = null;
                    if (cmbDepartment.SelectedValue != null && (Convert.ToInt32(cmbDepartment.SelectedValue.ToString()) > 0))
                        selectedAffairs = dtAffairs.Select("Affair_id='" + Convert.ToInt32(cmbDepartment.SelectedValue.ToString()) + "'");
                    else
                        selectedAffairs = dtAffairs.Select("Affair_id>0");

                    int rowCounter = 0;
                    //for (int intAffairsIndex = 0; intAffairsIndex < dtAffairs.Rows.Count; intAffairsIndex++)
                    foreach (DataRow affairsRow in selectedAffairs)
                    {
                        //sblTenderTracking.Append("<tr><td colspan=\"17\" style=\"text-align: center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #00CCFF;\"><b>" + dtAffairs.Rows[intAffairsIndex]["PWA Affairs"].ToString() + "</b></td></tr>");
                        sblTenderTracking.Append("<tr><td colspan=\"19\" style=\"text-align: center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #00CCFF;\"><b>" + affairsRow["Affairs_Name"].ToString() + "</b></td></tr>");
                        if (dtTenderTracking != null && dtTenderTracking.Rows.Count > 0)
                        {
                            DataTable uniqueProjects = dtTenderTracking.DefaultView.ToTable(true, "proj_id");

                            for (int intIndexProj = 0; intIndexProj < uniqueProjects.Rows.Count; intIndexProj++)
                            {
                                //DataRow[] result = dtTenderTracking.Select("Affair_id=" + Convert.ToInt32(dtAffairs.Rows[intAffairsIndex]["Affair_id"].ToString()) + " AND proj_id=" + Convert.ToInt32(uniqueProjects.Rows[intIndexProj]["proj_id"].ToString()) + " AND stage_id=1");
                                //DataRow[] projectResult = dtTenderTracking.Select("Affair_id=" + Convert.ToInt32(dtAffairs.Rows[intAffairsIndex]["Affair_id"].ToString()) + " AND proj_id=" + Convert.ToInt32(uniqueProjects.Rows[intIndexProj]["proj_id"].ToString()) + "");
                                //DataRow[] resultStage2 = dtTenderTracking.Select("Affair_id=" + Convert.ToInt32(dtAffairs.Rows[intAffairsIndex]["Affair_id"].ToString()) + " AND proj_id=" + Convert.ToInt32(uniqueProjects.Rows[intIndexProj]["proj_id"].ToString()) + " AND stage_id=2");                                 
                                DataRow[] result = dtTenderTracking.Select("Affair_id='" + Convert.ToInt32(affairsRow["Affair_id"].ToString()) + "' AND proj_id='" + Convert.ToInt32(uniqueProjects.Rows[intIndexProj]["proj_id"].ToString()) + "' AND stage_id='1'");
                                DataRow[] projectResult = dtTenderTracking.Select("Affair_id='" + Convert.ToInt32(affairsRow["Affair_id"].ToString()) + "' AND proj_id='" + Convert.ToInt32(uniqueProjects.Rows[intIndexProj]["proj_id"].ToString()) + "'");
                                //DataRow[] projectResult = dtTenderTracking.Select("proj_id=" + uniqueProjects.Rows[intIndexProj]["proj_id"].ToString());
                                //string sqlTsStage2 = "select td.ts_receive_on,td.ts_issue_handling,td.ts_return_to_dept,td.ts_receive_from_dept,td.ts_pr_advertise,td.ts_tender_invitation,td.ts_closing_s1,td.ts_modified_closing from TenderDatesInfo td where td.proj_id='" + uniqueProjects.Rows[intIndexProj]["proj_id"].ToString() + "' AND td.stage_id=2 and td.ts_tender_issue is Null";
                                //DataRow[] resultStage2 = dtTenderTracking.Select("Affair_id='" + Convert.ToInt32(affairsRow["Affair_id"].ToString()) + "' AND proj_id='" + Convert.ToInt32(uniqueProjects.Rows[intIndexProj]["proj_id"].ToString()) + "' AND stage_id='2'");
                                //DataTable dtTenderDatesStage2 = dalObj.GetDataFromDB("TenderDatesStage2", sqlTsStage2);
                                DataRow[] resultStage2 = null;
                                if (projectResult != null && projectResult.Length > 0)
                                {
                                    string sqlTsStage2 = "select td.ts_receive_on,td.ts_issue_handling,td.ts_return_to_dept,td.ts_receive_from_dept,td.ts_pr_advertise,td.ts_tender_invitation,td.ts_closing_s1,td.ts_modified_closing from TenderDatesInfo td where td.proj_id='" + uniqueProjects.Rows[intIndexProj]["proj_id"].ToString() + "' AND td.stage_id=2 and td.ts_tender_issue is Null";
                                    //DataRow[] resultStage2 = dtTenderTracking.Select("Affair_id='" + Convert.ToInt32(affairsRow["Affair_id"].ToString()) + "' AND proj_id='" + Convert.ToInt32(uniqueProjects.Rows[intIndexProj]["proj_id"].ToString()) + "' AND stage_id='2'");
                                    DataTable dtTenderDatesStage2 = dalObj.GetDataFromDB("TenderDatesStage2", sqlTsStage2);
                                    resultStage2 = dtTenderDatesStage2.Select();
                                    sblTenderTracking.Append("<tr>");
                                    sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>" + ++rowCounter + "</b></td>");
                                    if (projectResult[0]["project_newname_en"] != null)
                                        sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>" + projectResult[0]["project_newname_en"].ToString() + "</b></td>");
                                    else
                                        sblTenderTracking.Append("<td style=\"width:200px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");

                                    if (projectResult[0]["project_code"] != null)
                                        sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>" + projectResult[0]["project_code"].ToString() + "</b></td>");
                                    else
                                        sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");

                                    //To generate the Tender Tracking Report Header

                                    if (result != null && result.Length > 0)
                                    {
                                        sblTenderTracking.Append("<td colspan=\"7\" style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                        sblTenderTracking.Append("<table border=\"0\">");

                                        foreach (DataRow row in result)
                                        {
                                            //
                                            sblTenderTracking.Append("<tr>");
                                            if (row["ptd_receive_on"] != null && (!string.IsNullOrEmpty(row["ptd_receive_on"].ToString())))
                                                sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>" + Convert.ToDateTime(row["ptd_receive_on"].ToString()).ToString("dd-MMM-yyyy") + "</b></td>");
                                            else
                                                sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                            if (row["ptd_purpose"] != null)
                                                sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>" + row["ptd_purpose"].ToString() + "</b></td>");
                                            else
                                                sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                            if (row["ptd_assign_qs"] != null)
                                                sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>" + row["ptd_assign_qs"].ToString() + "</b></td>");
                                            else
                                                sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");

                                            if (row["ptd_sent_for_rev"] != null && (!string.IsNullOrEmpty(row["ptd_sent_for_rev"].ToString())))
                                                sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>" + Convert.ToDateTime(row["ptd_sent_for_rev"].ToString()).ToString("dd-MMM-yyyy") + "</b></td>");
                                            else
                                                sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");

                                            if (row["ptd_qs_working_status"] != null)
                                                sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>" + row["ptd_qs_working_status"].ToString() + "</b></td>");
                                            else
                                                sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                            if (row["ptd_tendec_doc_cur_status"] != null)
                                                sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>" + row["ptd_tendec_doc_cur_status"].ToString() + "</b></td>");
                                            else
                                                sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                            if (row["ptd_forwarded_to_dep"] != null && (!string.IsNullOrEmpty(row["ptd_forwarded_to_dep"].ToString())))
                                                sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>" + Convert.ToDateTime(row["ptd_forwarded_to_dep"].ToString()).ToString("dd-MMM-yyyy") + "</b></td>");
                                            else
                                                sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                         
                                            sblTenderTracking.Append("</tr>");
                                        }
                                        sblTenderTracking.Append("</table>");
                                        sblTenderTracking.Append("</td>");
                                    }
                                    else
                                    {
                                        sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                        sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                        sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                        sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                        sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                        sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                        sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");                                         
                                    }

                                    if (resultStage2 != null && resultStage2.Length > 0)
                                    {
                                        string strTsRecieveON = string.Empty;
                                        string strTsIssueHandling = string.Empty;
                                        string strTsReturnToDept = string.Empty;
                                        string strTsRecieveFrmDept = string.Empty;


                                        foreach (DataRow row in resultStage2)
                                        {
                                            if (row["ts_receive_on"] != null && (!string.IsNullOrEmpty(row["ts_receive_on"].ToString())))
                                            {
                                                if (string.IsNullOrEmpty(strTsRecieveON))
                                                    strTsRecieveON = row["ts_receive_on"].ToString();
                                            }

                                            if (row["ts_issue_handling"] != null && (!string.IsNullOrEmpty(row["ts_issue_handling"].ToString())))
                                            {
                                                if (string.IsNullOrEmpty(strTsIssueHandling))
                                                    strTsIssueHandling = row["ts_issue_handling"].ToString();
                                            }

                                            if (row["ts_return_to_dept"] != null && (!string.IsNullOrEmpty(row["ts_return_to_dept"].ToString())))
                                            {
                                                if (string.IsNullOrEmpty(strTsReturnToDept))
                                                    strTsReturnToDept = row["ts_return_to_dept"].ToString();
                                            }

                                            if (row["ts_receive_from_dept"] != null && (!string.IsNullOrEmpty(row["ts_receive_from_dept"].ToString())))
                                            {
                                                if (string.IsNullOrEmpty(strTsRecieveFrmDept))
                                                    strTsRecieveFrmDept = row["ts_receive_from_dept"].ToString();
                                            }
                                        }
                                        sblTenderTracking.Append("<td colspan=\"3\" style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                        sblTenderTracking.Append("<table border=\"0\">");

                                        sblTenderTracking.Append("<tr>");
                                        if (!string.IsNullOrEmpty(strTsRecieveON))
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>" + Convert.ToDateTime(strTsRecieveON).ToString("dd-MMM-yyyy") + "</b></td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                        if (!string.IsNullOrEmpty(strTsIssueHandling))
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>" + strTsIssueHandling + "</b></td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                        if (!string.IsNullOrEmpty(strTsReturnToDept))
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;\"><b>" + Convert.ToDateTime(strTsReturnToDept).ToString("dd-MMM-yyyy") + "</b></td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;\"><b>&nbsp;</b></td>");
                                        if (!string.IsNullOrEmpty(strTsRecieveFrmDept))
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;\"><b>" + Convert.ToDateTime(strTsRecieveFrmDept).ToString("dd-MMM-yyyy") + "</b></td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;\"><b>&nbsp;</b></td>");
                                        sblTenderTracking.Append("</tr>");

                                        sblTenderTracking.Append("</table>");
                                        sblTenderTracking.Append("</td>");


                                        if (projectResult[0]["tender_no"] != null)
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>" + projectResult[0]["tender_no"].ToString() + "</b></td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");


                                        string strTsAdvertise = string.Empty;
                                        string strTenderInvitation = string.Empty;
                                        string strTsClosings1 = string.Empty;
                                        string strTsModifiedClosing = string.Empty;                                      

                                        foreach (DataRow row in resultStage2)
                                        {
                                            if (row["ts_pr_advertise"] != null && (!string.IsNullOrEmpty(row["ts_pr_advertise"].ToString())))
                                            {
                                                if (string.IsNullOrEmpty(strTsAdvertise))
                                                    strTsAdvertise = row["ts_pr_advertise"].ToString();
                                            }
                                            if (row["ts_tender_invitation"] != null && (!string.IsNullOrEmpty(row["ts_tender_invitation"].ToString())))
                                            {
                                                if (string.IsNullOrEmpty(strTenderInvitation))
                                                    strTenderInvitation = row["ts_tender_invitation"].ToString();
                                            }
                                            if (row["ts_closing_s1"] != null && (!string.IsNullOrEmpty(row["ts_closing_s1"].ToString())))
                                            {
                                                if (string.IsNullOrEmpty(strTsClosings1))
                                                    strTsClosings1 = row["ts_closing_s1"].ToString();
                                            }
                                            if (row["ts_modified_closing"] != null && (!string.IsNullOrEmpty(row["ts_modified_closing"].ToString())))
                                            {
                                                if (string.IsNullOrEmpty(strTsModifiedClosing))
                                                    strTsModifiedClosing = row["ts_modified_closing"].ToString();
                                            }
                                          
                                        }

                                        sblTenderTracking.Append("<td colspan=\"4\" style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\">");
                                        sblTenderTracking.Append("<table border=\"0\">");

                                        sblTenderTracking.Append("<tr>");
                                        if (!string.IsNullOrEmpty(strTsAdvertise))
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>" + Convert.ToDateTime(strTsAdvertise).ToString("dd-MMM-yyyy") + "</b></td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                        if (!string.IsNullOrEmpty(strTenderInvitation))
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>" + Convert.ToDateTime(strTenderInvitation).ToString("dd-MMM-yyyy") + "</b></td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                        if (!string.IsNullOrEmpty(strTsClosings1))
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>" + Convert.ToDateTime(strTsClosings1).ToString("dd-MMM-yyyy") + "</b></td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                        if (!string.IsNullOrEmpty(strTsModifiedClosing))
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>" + Convert.ToDateTime(strTsModifiedClosing).ToString("dd-MMM-yyyy") + "</b></td>");
                                        else
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");                                                                               
                                        sblTenderTracking.Append("</tr>");
                                        sblTenderTracking.Append("</table>");
                                        sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>" + projectResult[0]["Department"] + "</b></td>");
                                    }
                                    else
                                    {
                                        sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                        sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");

                                        sblTenderTracking.Append("<td style=\"width:150px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;\"><b></b>");
                                        sblTenderTracking.Append("<table border=\"0\">");
                                        sblTenderTracking.Append("<tr><td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;\"><b>&nbsp;</b></td>");
                                        sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 0px;padding-top: 0px;height: 35px;\"><b>&nbsp;</b></td>");
                                        sblTenderTracking.Append("</tr></table>");
                                        sblTenderTracking.Append("</td>");

                                        //if (projectResult[0]["tender_no"] != null)
                                        //{
                                        //    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>" + projectResult[0]["tender_no"].ToString() + "</b></td>");
                                        //    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                        //    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                        //    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                        //    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                        //    sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>" + projectResult[0]["Department"] + "</b></td>");
                                        //}
                                        //else
                                        //{
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>&nbsp;</b></td>");
                                            sblTenderTracking.Append("<td style=\"width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b>" + projectResult[0]["Department"] + "</b></td>");
                                       // }

                                       
                                    }
                                    sblTenderTracking.Append("</tr>");
                                }
                            }
                        }
                    }
                    sblTenderTracking.Append("<tr><td colspan=\"19\" style=\"width:auto;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b style=\"font-style: italic\">This report is generated by TCMS dated :</b><b>" + DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss") + "</b></td></tr>");
                    
                    sblTenderTracking.Append("</table>");
                    lblTotalNoOfRecords.Text = "Total Records Count=" + rowCounter.ToString();
                }
                else
                {
                    lblTotalNoOfRecords.Text = "Total Records Count=0";
                    MessageBox.Show("No data exist for selected options", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Occurred while retrieving the information", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return sblTenderTracking;
        }

        private DataTable SqlQueries(int fyId, int monthId, ComboBox contractorCategory, ComboBox fiscalYear, DAL dalObj, DataTable dtAwardedTendersDetails)
        {            
            
            if (fyId != 0 && monthId != 0 && contractorCategory.SelectedIndex == 1)
                dtAwardedTendersDetails = dalObj.GetDataFromDB("ContractDetails", "SELECT p.project_code, p.project_newname_en, p.tender_no, COMPANY.co_name,CONTRACTORS.cp_tender_award, CASE WHEN COMPANY.qatari_share >= 51 THEN 'Qatari' ELSE 'Non-Qatari' END AS Nationality, CONTRACTORS.ContractAmount," +
                "CONTRACTORS.contract_no, d2.Department FROM CONTRACTORS INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id inner join Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id WHERE (p.Tender_Status_id >= 6) AND " +
                "Year(CONTRACTORS.cp_tender_award) = " + ((DataRowView)fiscalYear.SelectedItem).Row.ItemArray[1].ToString() + " and Month(CONTRACTORS.cp_tender_award)=" + monthId + " and COMPANY.qatari_share>=51 and p.isDeleted=0");

            else if (fyId != 0 && monthId != 0 && contractorCategory.SelectedIndex == 2)
                dtAwardedTendersDetails = dalObj.GetDataFromDB("ContractDetails", "SELECT p.project_code, p.project_newname_en, p.tender_no, COMPANY.co_name,CONTRACTORS.cp_tender_award, CASE WHEN COMPANY.qatari_share >= 51 THEN 'Qatari' ELSE 'Non-Qatari' END AS Nationality, CONTRACTORS.ContractAmount," +
                "CONTRACTORS.contract_no, d2.Department FROM CONTRACTORS INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id inner join Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id WHERE (p.Tender_Status_id >= 6) AND Year(CONTRACTORS.cp_tender_award) = " +
                ((DataRowView)fiscalYear.SelectedItem).Row.ItemArray[1].ToString() + " and Month(CONTRACTORS.cp_tender_award)=" + monthId + " and COMPANY.qatari_share=0 and p.isDeleted=0");

            else if (fyId != 0 && monthId != 0 && contractorCategory.SelectedIndex == 0)
                dtAwardedTendersDetails = dalObj.GetDataFromDB("ContractDetails", "SELECT p.project_code, p.project_newname_en, p.tender_no, COMPANY.co_name,CONTRACTORS.cp_tender_award, CASE WHEN COMPANY.qatari_share >= 51 THEN 'Qatari' ELSE 'Non-Qatari' END AS Nationality, CONTRACTORS.ContractAmount," +
                "CONTRACTORS.contract_no, d2.Department FROM CONTRACTORS INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id inner join Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id WHERE (p.Tender_Status_id >= 6) AND Year(CONTRACTORS.cp_tender_award) = " +
                ((DataRowView)fiscalYear.SelectedItem).Row.ItemArray[1].ToString() + " and Month(CONTRACTORS.cp_tender_award)=" + monthId + " and p.isDeleted=0");

            else if (fyId != 0 && monthId == 0 && contractorCategory.SelectedIndex == 0)
                dtAwardedTendersDetails = dalObj.GetDataFromDB("ContractDetails", "SELECT p.project_code, p.project_newname_en, p.tender_no, COMPANY.co_name, CONTRACTORS.cp_tender_award, CASE WHEN COMPANY.qatari_share >= 51 THEN 'Qatari' ELSE 'Non-Qatari' END AS Nationality, CONTRACTORS.ContractAmount," +
                "CONTRACTORS.contract_no, d2.Department FROM CONTRACTORS INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id inner join Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id WHERE (p.Tender_Status_id >= 6) AND Year(CONTRACTORS.cp_tender_award) = " +
                ((DataRowView)fiscalYear.SelectedItem).Row.ItemArray[1].ToString() + " and p.isDeleted=0");

            else if (fyId != 0 && monthId == 0 && contractorCategory.SelectedIndex == 1)
                dtAwardedTendersDetails = dalObj.GetDataFromDB("ContractDetails", "SELECT p.project_code, p.project_newname_en, p.tender_no, COMPANY.co_name, CONTRACTORS.cp_tender_award, CASE WHEN COMPANY.qatari_share >= 51 THEN 'Qatari' ELSE 'Non-Qatari' END AS Nationality, CONTRACTORS.ContractAmount," +
                "CONTRACTORS.contract_no, d2.Department FROM CONTRACTORS INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id inner join Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id WHERE (p.Tender_Status_id >= 6) AND Year(CONTRACTORS.cp_tender_award) = " +
                ((DataRowView)fiscalYear.SelectedItem).Row.ItemArray[1].ToString() + " and COMPANY.qatari_share>=51 and p.isDeleted=0");

            else if (fyId != 0 && monthId == 0 && contractorCategory.SelectedIndex == 2)
                dtAwardedTendersDetails = dalObj.GetDataFromDB("ContractDetails", "SELECT p.project_code, p.project_newname_en, p.tender_no, COMPANY.co_name, CONTRACTORS.cp_tender_award, CASE WHEN COMPANY.qatari_share >= 51 THEN 'Qatari' ELSE 'Non-Qatari' END AS Nationality, CONTRACTORS.ContractAmount," +
                "CONTRACTORS.contract_no, d2.Department FROM CONTRACTORS INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id inner join Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id WHERE (p.Tender_Status_id >= 6) AND Year(CONTRACTORS.cp_tender_award) = " +
                ((DataRowView)fiscalYear.SelectedItem).Row.ItemArray[1].ToString() + " and COMPANY.qatari_share=0 and p.isDeleted=0");

            else if (fyId == 0 && monthId != 0 && contractorCategory.SelectedIndex == 0)
                dtAwardedTendersDetails = dalObj.GetDataFromDB("ContractDetails", "SELECT p.project_code, p.project_newname_en, p.tender_no, COMPANY.co_name, CONTRACTORS.cp_tender_award, CASE WHEN COMPANY.qatari_share >= 51 THEN 'Qatari' ELSE 'Non-Qatari' END AS Nationality, CONTRACTORS.ContractAmount," +
                "CONTRACTORS.contract_no, d2.Department FROM CONTRACTORS INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id inner join Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id WHERE (p.Tender_Status_id >= 6) and Month(CONTRACTORS.cp_tender_award)=" + monthId + " and p.isDeleted=0");

            else if (fyId == 0 && monthId != 0 && contractorCategory.SelectedIndex == 1)
                dtAwardedTendersDetails = dalObj.GetDataFromDB("ContractDetails", "SELECT p.project_code, p.project_newname_en, p.tender_no, COMPANY.co_name, CONTRACTORS.cp_tender_award, CASE WHEN COMPANY.qatari_share >= 51 THEN 'Qatari' ELSE 'Non-Qatari' END AS Nationality, CONTRACTORS.ContractAmount," +
                "CONTRACTORS.contract_no, d2.Department FROM CONTRACTORS INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id inner join Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id WHERE (p.Tender_Status_id >= 6) and Month(CONTRACTORS.cp_tender_award)=" + monthId +
                " and COMPANY.qatari_share>=51 and p.isDeleted=0");

            else if (fyId == 0 && monthId != 0 && contractorCategory.SelectedIndex == 2)
                dtAwardedTendersDetails = dalObj.GetDataFromDB("ContractDetails", "SELECT p.project_code, p.project_newname_en, p.tender_no, COMPANY.co_name, CONTRACTORS.cp_tender_award, CASE WHEN COMPANY.qatari_share >= 51 THEN 'Qatari' ELSE 'Non-Qatari' END AS Nationality, CONTRACTORS.ContractAmount," +
                "CONTRACTORS.contract_no, d2.Department FROM CONTRACTORS INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id inner join Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id WHERE (p.Tender_Status_id >= 6) and Month(CONTRACTORS.cp_tender_award)=" + monthId +
                " and COMPANY.qatari_share=0 and p.isDeleted=0");

            else if (fyId == 0 && monthId == 0 && contractorCategory.SelectedIndex == 0)
                dtAwardedTendersDetails = dalObj.GetDataFromDB("ContractDetails", "SELECT p.project_code, p.project_newname_en, p.tender_no, COMPANY.co_name, CONTRACTORS.cp_tender_award, CASE WHEN COMPANY.qatari_share >= 51 THEN 'Qatari' ELSE 'Non-Qatari' END AS Nationality, CONTRACTORS.ContractAmount," +
                "CONTRACTORS.contract_no, d2.Department FROM CONTRACTORS INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id inner join Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id WHERE (p.Tender_Status_id >= 6) and p.isDeleted=0");

            else if (fyId == 0 && monthId == 0 && contractorCategory.SelectedIndex == 1)
                dtAwardedTendersDetails = dalObj.GetDataFromDB("ContractDetails", "SELECT p.project_code, p.project_newname_en, p.tender_no, COMPANY.co_name, CONTRACTORS.cp_tender_award, CASE WHEN COMPANY.qatari_share >= 51 THEN 'Qatari' ELSE 'Non-Qatari' END AS Nationality, CONTRACTORS.ContractAmount," +
                "CONTRACTORS.contract_no, d2.Department FROM CONTRACTORS INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id inner join Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id WHERE (p.Tender_Status_id >= 6) and COMPANY.qatari_share>=51 and p.isDeleted=0");

            else if (fyId == 0 && monthId == 0 && contractorCategory.SelectedIndex == 2)
                dtAwardedTendersDetails = dalObj.GetDataFromDB("ContractDetails", "SELECT p.project_code, p.project_newname_en, p.tender_no, COMPANY.co_name, CONTRACTORS.cp_tender_award, CASE WHEN COMPANY.qatari_share >= 51 THEN 'Qatari' ELSE 'Non-Qatari' END AS Nationality, CONTRACTORS.ContractAmount," +
                "CONTRACTORS.contract_no, d2.Department FROM CONTRACTORS INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id inner join Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id WHERE (p.Tender_Status_id >= 6) and COMPANY.qatari_share=0 and p.isDeleted=0");

            return dtAwardedTendersDetails;
        }
        /// <summary>
        /// Created by Varun on 12 May 2015 for retrieving contractor details report         
        /// </summary>

        private StringBuilder getAwardedTendersReport(StringBuilder strAwardedTendersDetails, int monthId, string monthName,int fyId, ComboBox fiscalYear, ComboBox contractorCategory)
        {             
            try
            {
                DAL dalObj = new DAL();
                strAwardedTendersDetails.Append("<table style='border: solid 1px #506E87; width:100%'><tr>");
                                
                if (fyId != 0 && monthId !=0)
                {
                    strAwardedTendersDetails.Append("<td colspan='10' style='text-align:center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;'><b>PWA - CONTRACTS DEPARTMENT</b></td></tr>");
                    strAwardedTendersDetails.Append("<tr><td colspan='10' style='text-align: center;font-size: 12pt;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;'><b>Awarded Tenders for the Month:" + monthName + " and Year: " + ((DataRowView)fiscalYear.SelectedItem).Row.ItemArray[1].ToString() + " </b></td></tr>");                     
                }
                else if (fyId != 0 && monthId == 0)
                {
                    strAwardedTendersDetails.Append("<td colspan='10' style='text-align:center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;'><b>PWA - CONTRACTS DEPARTMENT</b></td></tr>");
                    strAwardedTendersDetails.Append("<tr><td colspan='10' style='text-align: center;font-size: 12pt;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;'><b>Awarded Tenders for the Year: " + ((DataRowView)fiscalYear.SelectedItem).Row.ItemArray[1].ToString() + " </b></td></tr>");                     
                }
                else if (fyId == 0 && monthId != 0)
                {
                    strAwardedTendersDetails.Append("<td colspan='10' style='text-align:center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;'><b>PWA - CONTRACTS DEPARTMENT</b></td></tr>");
                    strAwardedTendersDetails.Append("<tr><td colspan='10' style='text-align: center;font-size: 12pt;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;'><b>Awarded Tenders for the Month:" + monthName + " </b></td></tr>");                     
                }
                else if (fyId == 0 && monthId == 0)
                {
                    strAwardedTendersDetails.Append("<td colspan='10' style='text-align:center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;'><b>PWA - CONTRACTS DEPARTMENT</b></td></tr>");
                    strAwardedTendersDetails.Append("<tr><td colspan='10' style='text-align: center;font-size: 12pt;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;'><b>All Awarded Tenders</b></td></tr>");
                }
                
                strAwardedTendersDetails.Append("<tr><td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>SNo.</b></td>"+
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Project Code</b></td>"+
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Project Title</b></td>" +
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Tender Number</b></td>" +
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Contractor Name</b></td>" +
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Tender Award Date</b></td>"+
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Nationality</b></td>" +
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Contract Amount</b></td>" +               
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Contract No</b></td>" +                 
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Department Name</b></td>" +                 
                "</tr>");


                DataTable dtAwardedTendersDetails = null;

                if (whereClause != null)
                {
                    if (whereClause != "")
                    {
                        if (fyId != 0 && monthId != 0 && contractorCategory.SelectedIndex == 1)
                            dtAwardedTendersDetails = dalObj.GetDataFromDB("ContractDetails", "SELECT p.project_code, p.project_newname_en, p.tender_no, COMPANY.co_name,CONTRACTORS.cp_tender_award, CASE WHEN COMPANY.qatari_share >= 51 THEN 'Qatari' ELSE 'Non-Qatari' END AS Nationality, CONTRACTORS.ContractAmount," +
                            "CONTRACTORS.contract_no, Department.Department FROM CONTRACTORS INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN Department ON p.department_id = Department.department_id WHERE (p.Tender_Status_id >= 6) AND " +
                            "Year(CONTRACTORS.cp_tender_award) = " + ((DataRowView)fiscalYear.SelectedItem).Row.ItemArray[1].ToString() + " and Month(CONTRACTORS.cp_tender_award)=" + monthId + " and COMPANY.qatari_share>=51 and" + whereClause + " and p.isDeleted=0");

                        else if (fyId != 0 && monthId != 0 && contractorCategory.SelectedIndex == 2)
                            dtAwardedTendersDetails = dalObj.GetDataFromDB("ContractDetails", "SELECT p.project_code, p.project_newname_en, p.tender_no, COMPANY.co_name,CONTRACTORS.cp_tender_award, CASE WHEN COMPANY.qatari_share >= 51 THEN 'Qatari' ELSE 'Non-Qatari' END AS Nationality, CONTRACTORS.ContractAmount," +
                            "CONTRACTORS.contract_no, Department.Department FROM CONTRACTORS INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN Department ON p.department_id = Department.department_id WHERE (p.Tender_Status_id >= 6) AND Year(CONTRACTORS.cp_tender_award) = " +
                            ((DataRowView)fiscalYear.SelectedItem).Row.ItemArray[1].ToString() + " and Month(CONTRACTORS.cp_tender_award)=" + monthId + " and COMPANY.qatari_share=0 and" + whereClause + " and p.isDeleted=0");

                        else if (fyId != 0 && monthId != 0 && contractorCategory.SelectedIndex == 0)
                            dtAwardedTendersDetails = dalObj.GetDataFromDB("ContractDetails", "SELECT p.project_code, p.project_newname_en, p.tender_no, COMPANY.co_name,CONTRACTORS.cp_tender_award, CASE WHEN COMPANY.qatari_share >= 51 THEN 'Qatari' ELSE 'Non-Qatari' END AS Nationality, CONTRACTORS.ContractAmount," +
                            "CONTRACTORS.contract_no, Department.Department FROM CONTRACTORS INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN Department ON p.department_id = Department.department_id WHERE (p.Tender_Status_id >= 6) AND Year(CONTRACTORS.cp_tender_award) = " +
                            ((DataRowView)fiscalYear.SelectedItem).Row.ItemArray[1].ToString() + " and Month(CONTRACTORS.cp_tender_award)=" + monthId + " and" + whereClause + " and p.isDeleted=0");

                        else if (fyId != 0 && monthId == 0 && contractorCategory.SelectedIndex == 0)
                            dtAwardedTendersDetails = dalObj.GetDataFromDB("ContractDetails", "SELECT p.project_code, p.project_newname_en, p.tender_no, COMPANY.co_name, CONTRACTORS.cp_tender_award, CASE WHEN COMPANY.qatari_share >= 51 THEN 'Qatari' ELSE 'Non-Qatari' END AS Nationality, CONTRACTORS.ContractAmount," +
                            "CONTRACTORS.contract_no, Department.Department FROM CONTRACTORS INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN Department ON p.department_id = Department.department_id WHERE (p.Tender_Status_id >= 6) AND Year(CONTRACTORS.cp_tender_award) = " +
                            ((DataRowView)fiscalYear.SelectedItem).Row.ItemArray[1].ToString() + " and" + whereClause + " and p.isDeleted=0");

                        else if (fyId != 0 && monthId == 0 && contractorCategory.SelectedIndex == 1)
                            dtAwardedTendersDetails = dalObj.GetDataFromDB("ContractDetails", "SELECT p.project_code, p.project_newname_en, p.tender_no, COMPANY.co_name, CONTRACTORS.cp_tender_award, CASE WHEN COMPANY.qatari_share >= 51 THEN 'Qatari' ELSE 'Non-Qatari' END AS Nationality, CONTRACTORS.ContractAmount," +
                            "CONTRACTORS.contract_no, Department.Department FROM CONTRACTORS INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN Department ON p.department_id = Department.department_id WHERE (p.Tender_Status_id >= 6) AND Year(CONTRACTORS.cp_tender_award) = " +
                            ((DataRowView)fiscalYear.SelectedItem).Row.ItemArray[1].ToString() + " and COMPANY.qatari_share>=51 and" + whereClause + " and p.isDeleted=0");

                        else if (fyId != 0 && monthId == 0 && contractorCategory.SelectedIndex == 2)
                            dtAwardedTendersDetails = dalObj.GetDataFromDB("ContractDetails", "SELECT p.project_code, p.project_newname_en, p.tender_no, COMPANY.co_name, CONTRACTORS.cp_tender_award, CASE WHEN COMPANY.qatari_share >= 51 THEN 'Qatari' ELSE 'Non-Qatari' END AS Nationality, CONTRACTORS.ContractAmount," +
                            "CONTRACTORS.contract_no, Department.Department FROM CONTRACTORS INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN Department ON p.department_id = Department.department_id WHERE (p.Tender_Status_id >= 6) AND Year(CONTRACTORS.cp_tender_award) = " +
                            ((DataRowView)fiscalYear.SelectedItem).Row.ItemArray[1].ToString() + " and COMPANY.qatari_share=0 and" + whereClause + " and p.isDeleted=0");

                        else if (fyId == 0 && monthId != 0 && contractorCategory.SelectedIndex == 0)
                            dtAwardedTendersDetails = dalObj.GetDataFromDB("ContractDetails", "SELECT p.project_code, p.project_newname_en, p.tender_no, COMPANY.co_name, CONTRACTORS.cp_tender_award, CASE WHEN COMPANY.qatari_share >= 51 THEN 'Qatari' ELSE 'Non-Qatari' END AS Nationality, CONTRACTORS.ContractAmount," +
                            "CONTRACTORS.contract_no, Department.Department FROM CONTRACTORS INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN Department ON p.department_id = Department.department_id WHERE (p.Tender_Status_id >= 6) and Month(CONTRACTORS.cp_tender_award)=" + monthId + " and" + whereClause + " and p.isDeleted=0");

                        else if (fyId == 0 && monthId != 0 && contractorCategory.SelectedIndex == 1)
                            dtAwardedTendersDetails = dalObj.GetDataFromDB("ContractDetails", "SELECT p.project_code, p.project_newname_en, p.tender_no, COMPANY.co_name, CONTRACTORS.cp_tender_award, CASE WHEN COMPANY.qatari_share >= 51 THEN 'Qatari' ELSE 'Non-Qatari' END AS Nationality, CONTRACTORS.ContractAmount," +
                            "CONTRACTORS.contract_no, Department.Department FROM CONTRACTORS INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN Department ON p.department_id = Department.department_id WHERE (p.Tender_Status_id >= 6) and Month(CONTRACTORS.cp_tender_award)=" + monthId +
                            " and COMPANY.qatari_share>=51 and" + whereClause + " and p.isDeleted=0");

                        else if (fyId == 0 && monthId != 0 && contractorCategory.SelectedIndex == 2)
                            dtAwardedTendersDetails = dalObj.GetDataFromDB("ContractDetails", "SELECT p.project_code, p.project_newname_en, p.tender_no, COMPANY.co_name, CONTRACTORS.cp_tender_award, CASE WHEN COMPANY.qatari_share >= 51 THEN 'Qatari' ELSE 'Non-Qatari' END AS Nationality, CONTRACTORS.ContractAmount," +
                            "CONTRACTORS.contract_no, Department.Department FROM CONTRACTORS INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN Department ON p.department_id = Department.department_id WHERE (p.Tender_Status_id >= 6) and Month(CONTRACTORS.cp_tender_award)=" + monthId +
                            " and COMPANY.qatari_share=0 and" + whereClause + " and p.isDeleted=0");

                        else if (fyId == 0 && monthId == 0 && contractorCategory.SelectedIndex == 0)
                            dtAwardedTendersDetails = dalObj.GetDataFromDB("ContractDetails", "SELECT p.project_code, p.project_newname_en, p.tender_no, COMPANY.co_name, CONTRACTORS.cp_tender_award, CASE WHEN COMPANY.qatari_share >= 51 THEN 'Qatari' ELSE 'Non-Qatari' END AS Nationality, CONTRACTORS.ContractAmount," +
                            "CONTRACTORS.contract_no, Department.Department FROM CONTRACTORS INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN Department ON p.department_id = Department.department_id WHERE (p.Tender_Status_id >= 6) and" + whereClause + " and p.isDeleted=0");

                        else if (fyId == 0 && monthId == 0 && contractorCategory.SelectedIndex == 1)
                            dtAwardedTendersDetails = dalObj.GetDataFromDB("ContractDetails", "SELECT p.project_code, p.project_newname_en, p.tender_no, COMPANY.co_name, CONTRACTORS.cp_tender_award, CASE WHEN COMPANY.qatari_share >= 51 THEN 'Qatari' ELSE 'Non-Qatari' END AS Nationality, CONTRACTORS.ContractAmount," +
                            "CONTRACTORS.contract_no, Department.Department FROM CONTRACTORS INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN Department ON p.department_id = Department.department_id WHERE (p.Tender_Status_id >= 6) and COMPANY.qatari_share>=51 and" + whereClause + " and p.isDeleted=0");

                        else if (fyId == 0 && monthId == 0 && contractorCategory.SelectedIndex == 2)
                            dtAwardedTendersDetails = dalObj.GetDataFromDB("ContractDetails", "SELECT p.project_code, p.project_newname_en, p.tender_no, COMPANY.co_name, CONTRACTORS.cp_tender_award, CASE WHEN COMPANY.qatari_share >= 51 THEN 'Qatari' ELSE 'Non-Qatari' END AS Nationality, CONTRACTORS.ContractAmount," +
                            "CONTRACTORS.contract_no, Department.Department FROM CONTRACTORS INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN Department ON p.department_id = Department.department_id WHERE (p.Tender_Status_id >= 6) and COMPANY.qatari_share=0 and" + whereClause + " and p.isDeleted=0");
                    }
                    else
                    {
                        dtAwardedTendersDetails = SqlQueries(fyId, monthId, contractorCategory, fiscalYear, dalObj, dtAwardedTendersDetails);
                    }
                }
                else
                {
                    dtAwardedTendersDetails = SqlQueries(fyId, monthId, contractorCategory, fiscalYear, dalObj, dtAwardedTendersDetails);
                }
                

                int rowCounter = 0;
                if (dtAwardedTendersDetails.Rows.Count != 0)
                {
                    foreach (DataRow colData in dtAwardedTendersDetails.Rows)
                    {
                        strAwardedTendersDetails.Append("<tr><td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + ++rowCounter + "</b></td>");
                        strAwardedTendersDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + colData[0] + "</b></td>");
                        if (colData[1] != DBNull.Value)
                            strAwardedTendersDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + colData[1] + "</b></td>");
                        else
                            strAwardedTendersDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                        if (colData[2] != DBNull.Value)
                            strAwardedTendersDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + colData[2] + "</b></td>");
                        else
                            strAwardedTendersDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                        if (colData[3] != DBNull.Value)
                            strAwardedTendersDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + colData[3] + "</b></td>");
                        else
                            strAwardedTendersDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b></b></td>");

                        if (colData[4] != DBNull.Value)
                            strAwardedTendersDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + Convert.ToDateTime(colData[4]).ToString("dd/MMM/yyyy") + "</b></td>");
                        else
                            strAwardedTendersDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b></b></td>");                      

                        if (colData[5] != DBNull.Value)
                            strAwardedTendersDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + colData[5] + "</b></td>");
                        else
                            strAwardedTendersDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                        if (colData[6] != DBNull.Value)
                            strAwardedTendersDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + string.Format("{0:#,##0}", double.Parse(colData[6].ToString())) + "</b></td>");
                        else
                            strAwardedTendersDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b></b></td>");                         
                        if (colData[7] != DBNull.Value)
                            strAwardedTendersDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + colData[7] + "</b></td>");
                        else
                            strAwardedTendersDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                        if (colData[8] != DBNull.Value)
                            strAwardedTendersDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + colData[8] + "</b></td>");
                        else
                            strAwardedTendersDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                                                
                        strAwardedTendersDetails.Append("</tr>");
                    }
                    strAwardedTendersDetails.Append("<tr><td colspan='10' style=\"width:auto;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b style=\"font-style: italic\">This report is generated by TCMS dated :</b><b>" + DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss") + "</b></td></tr>");
                    lblTotalNoOfRecords.Text="Total Records Count="+dtAwardedTendersDetails.Rows.Count.ToString();
                }
                else
                {
                    lblTotalNoOfRecords.Text="Total Records Count=0";
                    MessageBox.Show("No data exist for selected options", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while retrieving the information of the contractor");
            }

            return strAwardedTendersDetails;
        }

        int rowCounter = 0;
        int chkDuplicateRows = 0;
        /// <summary>
        /// Created by Varun on 19 Feb 2014 for retrieving contractor details report
        /// </summary>
        /// <param name="?"></param>
        /// <returns></returns>
        private StringBuilder getContractorDetailsReport(StringBuilder strBuildContractorDetails, int coId, Int16 fyId, ComboBox cmbContractor)
        {            
            try
            {
                //DataTable dtContractorDetails = new DataTable("ContractorDetails");
                //dtContractorDetails.Columns.Add("contract_no");
                //dtContractorDetails.Columns.Add("ContractTitle");
                //dtContractorDetails.Columns.Add("ContractAmount");
                //dtContractorDetails.Columns.Add("StartDate");
                //dtContractorDetails.Columns.Add("FinishDate");
                //dtContractorDetails.AcceptChanges();

                DataRowView dtView = (DataRowView)cmbContractor.SelectedItem;                 
                DAL dalObj = new DAL();
                string sqlProjIdQuery = "";
                if (fiscalYearSelection != 0 && startReportDateChanged == 0 && endReportDateChanged == 0)
                    sqlProjIdQuery = "select distinct p.proj_id,FiscalYear.FiscalYear from PROJECTS p join FiscalYear on p.FYID=FiscalYear.FYID where p.FYID=" + fyId;
                else
                    sqlProjIdQuery = "select distinct p.proj_id,FiscalYear.FiscalYear from PROJECTS p join FiscalYear on p.FYID=FiscalYear.FYID ";
                DataTable dtProjectIds = dalObj.GetDataFromDB("ProjectIds", sqlProjIdQuery);
                DataTable dtContractorDetails = null;
                rowCounter = 0;

                if (dtProjectIds.Rows.Count != 0)
                {
                    strBuildContractorDetails.Append("<table style='border: solid 1px #506E87; width:100%'><tr>");

                    if (fiscalYearSelection != 0 && startReportDateChanged == 0 && endReportDateChanged == 0)
                    {
                        strBuildContractorDetails.Append("<td colspan='13' style='text-align:center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;'><b>PWA - CONTRACTS DEPARTMENT</b></td></tr>");
                        strBuildContractorDetails.Append("<tr><td colspan='13' style='text-align: center;font-size: 12pt;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;'><b>Awarded Contracts for Fiscal Year: " + dtProjectIds.Rows[0][1] + "</b></td></tr>");
                        strBuildContractorDetails.Append("<tr><td colspan='13' style='text-align: center;font-size: 12pt;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;' >Name of the Contractor/Vendor: <b>" + dtView.Row.ItemArray[1].ToString() + "</b></td></tr>");
                    }
                    else
                    {
                        strBuildContractorDetails.Append("<td colspan='14' style='text-align:center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;'><b>PWA - CONTRACTS DEPARTMENT</b></td></tr>");
                        strBuildContractorDetails.Append("<tr><td colspan='14' style='text-align: center;font-size: 12pt;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;'><b>Awarded Contracts</b></td></tr>");
                        strBuildContractorDetails.Append("<tr><td colspan='14' style='text-align: center;font-size: 12pt;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;' >Name of the Contractor: <b>" + dtView.Row.ItemArray[1].ToString() + "</b></td></tr>");
                        //strBuildContractorDetails.Append("<tr><td colspan='11' style='text-align: center;font-size: 12pt;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;' ></td></tr>");
                        //strBuildContractorDetails.Append("<tr><td colspan='11' style='text-align: center;font-size: 12pt;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;' ></td></tr>");
                    }


                   strBuildContractorDetails.Append("<tr><td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>SNo.</b></td>"+
                   "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Contract No</b></td>" +
                   "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Project Code</b></td>" +
                   "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Tender No.</b></td>" +
                   "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Project Title</b></td>" +
                   "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Date of Tender Issue</b></td>" +
                   "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Date of Award</b></td>" +
                   "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Date of Sign</b></td>" +
                   "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Contract Amount</b></td>" +
                   "<td style='width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC99;'>" +
                   "<b>Start Date</b></td><td style='width:100px;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;background-color: #FFCC99;'>" +
                   "<b>Finish Date</b></td><td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'" +
                   "><b>Contract Status</b></td>");

                   if ((fiscalYearSelection == 0 && (startReportDateChanged == 1 || endReportDateChanged == 1)))
                        strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'" +
                        "><b>Fiscal Year</b></td>");

                   strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'" +
                  "><b>Department Name</b></td></tr>");

                  //  string sqlContractDetailsQuery = string.Empty;

                   

                    //if (fyId==0)
                    //    sqlContractDetailsQuery = "SELECT   CONTRACTORS.bidder_id, CONTRACTORS.contract_no, CONTRACTORS.cp_tender_award, COMPANY.co_name FROM CONTRACTORS INNER JOIN " +
                    //      "  COMPANY ON CONTRACTORS.co_id = COMPANY.co_id WHERE (CONTRACTORS.cp_tender_award IS NOT NULL) AND (CONTRACTORS.co_id = " + coId + ") ";
                    //else if (fyId!=0)
                    //    sqlContractDetailsQuery = "SELECT        CONTRACTORS.bidder_id, CONTRACTORS.contract_no, CONTRACTORS.cp_tender_award, COMPANY.co_name, FiscalYear.FiscalYear, FiscalYear.FYID " + 
                    //              " FROM    CONTRACTORS INNER JOIN  COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN   p ON CONTRACTORS.proj_id = p.proj_id INNER JOIN " + 
                    //     " FiscalYear ON p.FYID = FiscalYear.FYID WHERE (CONTRACTORS.cp_tender_award IS NOT NULL) AND (CONTRACTORS.co_id = " + coId + ") AND (FiscalYear.FYID = " + fyId + "))  ";
                   
                    string sqlContractDetailsQuery = null;
                    foreach (DataRow projIds in dtProjectIds.Rows)
                    {            

                        if (fiscalYearSelection == 0 && (startReportDateChanged == 1 || endReportDateChanged == 1))
                        {
                            sqlContractDetailsQuery = "SELECT DISTINCT CONTRACTORS.contract_no, p.project_code,p.tender_no, CONTRACTORS.ContractTitle, td.ts_tender_invitation, CONTRACTORS.cp_tender_award, CONTRACTORS.cp_contractor_sign, " +
                            "CONTRACTORS.ContractAmount, CONTRACTORS.StartDate, CONTRACTORS.FinishDate, ContractStatus.ContractStatus,FiscalYear.FiscalYear,Department.Department FROM CONTRACTORS INNER JOIN " +
                            "COMPANY ON COMPANY.co_id = CONTRACTORS.co_id INNER JOIN ContractStatus ON ContractStatus.contract_status_id = CONTRACTORS.contract_status_id INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id " +
                            "INNER JOIN TenderDatesInfo as td ON CONTRACTORS.proj_id = td.proj_id INNER JOIN FiscalYear ON p.FYID = FiscalYear.FYID INNER JOIN Department ON p.department_id = Department.department_id WHERE (CONTRACTORS.co_id =" + coId + ") AND "+
                            "(CONTRACTORS.proj_id =" + projIds[0] + ") and td.ptd_receive_on between '" + dtpStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpEndReportDate.Value.ToString("dd/MMM/yyyy") + "'" + whereClause;
                            // "GROUP BY CONTRACTORS.contract_no, p.project_code, CONTRACTORS.ContractTitle, TenderDatesInfo.ts_tender_invitation, CONTRACTORS.ContractAmount, CONTRACTORS.StartDate, CONTRACTORS.FinishDate, CONTRACTORS.cp_tender_award, ContractStatus.ContractStatus, " +
                            // "CONTRACTORS.cp_contractor_sign,Department.Department ";
                        }
                        else
                        {
                            sqlContractDetailsQuery = "SELECT DISTINCT CONTRACTORS.contract_no, p.project_code,p.tender_no, CONTRACTORS.ContractTitle, td.ts_tender_invitation, CONTRACTORS.cp_tender_award, CONTRACTORS.cp_contractor_sign, " +
                           "CONTRACTORS.ContractAmount, CONTRACTORS.StartDate, CONTRACTORS.FinishDate, ContractStatus.ContractStatus,Department.Department FROM CONTRACTORS INNER JOIN " +
                           "COMPANY ON COMPANY.co_id = CONTRACTORS.co_id INNER JOIN ContractStatus ON ContractStatus.contract_status_id = CONTRACTORS.contract_status_id INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id " +
                           "INNER JOIN TenderDatesInfo As td ON CONTRACTORS.proj_id = td.proj_id INNER JOIN Department ON p.department_id = Department.department_id WHERE (CONTRACTORS.co_id =" + coId + ") AND (CONTRACTORS.proj_id =" + projIds[0] + ") ";// +
                           //"AND CONTRACTORS.contract_no is not NULL  whereClause;
                           //"GROUP BY CONTRACTORS.contract_no, p.project_code, CONTRACTORS.ContractTitle, TenderDatesInfo.ts_tender_invitation, CONTRACTORS.ContractAmount, CONTRACTORS.StartDate, CONTRACTORS.FinishDate, CONTRACTORS.cp_tender_award, ContractStatus.ContractStatus, " +
                           //"CONTRACTORS.cp_contractor_sign,FiscalYear.FiscalYear,Department.Department ";
                        }
                        
                        dtContractorDetails = dalObj.GetDataFromDB("ContractDetails", sqlContractDetailsQuery);
                      
                        int rowCounterForDuplicateRows = 0;
                        if (dtContractorDetails.Rows.Count != 0)
                        {                                                      

                            foreach (DataRow rowData in dtContractorDetails.Rows)
                            {
                                DataRowCollection uniqueRowsData = null;
                                if (dtContractorDetails.Rows.Count >= 2)
                                {
                                    uniqueRowsData = rowData.Table.Select("ts_tender_invitation is not Null").CopyToDataTable().Rows;
                                    chkDuplicateRows = 1;
                                }
                                else if (dtContractorDetails.Rows.Count == 1)
                                {
                                    uniqueRowsData = dtContractorDetails.Rows;
                                }

                                if (chkDuplicateRows == 1)
                                {
                                    if (rowCounterForDuplicateRows == 0)
                                    {
                                        FillData(dtContractorDetails, uniqueRowsData, strBuildContractorDetails, ref rowCounterForDuplicateRows, fiscalYearSelection);                                        
                                    }
                                }
                                else
                                {
                                    chkDuplicateRows = 0;
                                    rowCounterForDuplicateRows = 0;
                                    FillData(dtContractorDetails, uniqueRowsData, strBuildContractorDetails, ref rowCounterForDuplicateRows, fiscalYearSelection);
                                }
                                }

                                
                            }  
                            
                        }
                    
                    if (rowCounter != 0)
                    {
                        strBuildContractorDetails.Append("</table>");
                        lblTotalNoOfRecords.Text = "Total Records Count=" + rowCounter;
                    }
                    else
                    {
                        strBuildContractorDetails.Append("</table>");
                        lblTotalNoOfRecords.Text = "Total Records Count=0";
                        MessageBox.Show("No data exist for selected options", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    strBuildContractorDetails.Append("</table>");
                    lblTotalNoOfRecords.Text = "Total Records Count=0";
                    MessageBox.Show("No data exist for selected options", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while retrieving the information of the contractor");
            }

            return strBuildContractorDetails;
        }



        private void FillData(DataTable dtContractorDetails,DataRowCollection uniqueRowsData, StringBuilder strBuildContractorDetails, ref int rowCounterForDuplicateRows, int fiscalYearSelection)
        {
            foreach (DataRow rowData in uniqueRowsData)
            {
                strBuildContractorDetails.Append("<tr><td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + ++rowCounter + "</td>");
                strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[0] + "</td>");
                if (rowData[1] != DBNull.Value)
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[1] + "</td>");
                else
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'></td>");
                if (rowData[2] != DBNull.Value)
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[2] + "</td>");
                else
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'></td>");
                if (rowData[3] != DBNull.Value)
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[3] + "</td>");
                else
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'></td>");
                if (rowData[4] != DBNull.Value)
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + Convert.ToDateTime(rowData[4]).ToString("dd/MMM/yyyy") + "</td>");
                else
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'></td>");
                if (rowData[5] != DBNull.Value)
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + Convert.ToDateTime(rowData[5]).ToString("dd/MMM/yyyy") + "</td>");
                else
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'></td>");
                if (rowData[6] != DBNull.Value)
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + Convert.ToDateTime(rowData[6]).ToString("dd/MMM/yyyy") + "</td>");
                else
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'></td>");
                if (rowData[7] != DBNull.Value)
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + string.Format("{0:#,##0}", double.Parse(rowData[7].ToString())) + "</td>");
                else
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'></td>");
                if (rowData[8] != DBNull.Value)
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + Convert.ToDateTime(rowData[8]).ToString("dd/MMM/yyyy") + "</td>");
                else
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'></td>");
                if (rowData[9] != DBNull.Value)
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + Convert.ToDateTime(rowData[9]).ToString("dd/MMM/yyyy") + "</td>");
                else
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'></td>");
                if (rowData[10] != DBNull.Value)
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[10].ToString() + "</td>");
                else
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'></td>");


                if (dtContractorDetails.Columns.Count == 13 && fiscalYearSelection == 0)
                {
                    if (rowData[11] != DBNull.Value)
                    {
                        strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[11].ToString() + "</td>");
                    }

                    if (rowData[12] != DBNull.Value)
                    {
                        strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[12].ToString() + "</td>");
                    }
                }
                else
                {
                    if (rowData[11] != DBNull.Value)
                    {
                        strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[11].ToString() + "</td>");
                    }
                }
                // Commented by Sree ---- Should Open

                //if (fyId == 0)
                //    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + projIds[1] + "</td>");                                                                
                strBuildContractorDetails.Append("</tr>");
                if (chkDuplicateRows==1)
                {
                    rowCounterForDuplicateRows++;
                }
            }
        }

        /// <summary>
        /// Created by Varun on 07 Dec 2016 for Companies Contracts Information report
        /// </summary>
        /// <param name="?"></param>
        /// <returns></returns>
        private StringBuilder getCompaniesContractsInfo(StringBuilder strBuildContractorDetails, Int16 affairID, Int16 fyId)
        {
            try
            {               
                 
                DAL dalObj = new DAL();
               
                DataRowView dtView = (DataRowView)cmbFiscalyear.SelectedItem;
                strBuildContractorDetails.Append("<table style='border: solid 1px #506E87; width:100%'><tr>");

                strBuildContractorDetails.Append("<td colspan='12' style='text-align:center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;'><b>PWA - CONTRACTS DEPARTMENT</b></td></tr>");
                strBuildContractorDetails.Append("<td colspan='12' style='text-align:center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;'><b>" + lblCurrentReportName.Text + "</b></td></tr>");                        
                if (fyId != 0 && startReportDateChanged == 0 && endReportDateChanged == 0)
                {
                    strBuildContractorDetails.Append("<td colspan='12' style='text-align:center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;'><b>Fiscal Year: -" + dtView.Row.ItemArray[1].ToString() + "</b></td></tr>");                        
                }                


                    strBuildContractorDetails.Append("<tr><td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>SNo.</b></td>" +
                    "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Contract No</b></td>" +
                    "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Project Code</b></td>" +
                    "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Project Title</b></td>" +
                    "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Affairs Name</b></td>" +
                    "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Department Name</b></td>" +
                    "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Company Name</b></td>" +
                    "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Company Telephone</b></td>" +
                    "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Company Fax No.</b></td>" +
                    "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Company EmailID</b></td>" +
                    "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Fiscal Year</b></td>");                                            

                    
                    int rowCounter = 0;
                    string sqlCompaniesContractsInfoQuery = null;
                   

                    if (fiscalYearSelection == 0 && affairID != 0 && (startReportDateChanged == 1 || endReportDateChanged == 1))  //affairID == 7 means All
                        {                         
                            sqlCompaniesContractsInfoQuery = "SELECT DISTINCT CONTRACTORS.contract_no,p.project_code, p.project_newname_en,AFFAIRS.Affairs_Name, Department.Department, COMPANY.co_name, COMPANY.co_tel, COMPANY.co_fax, COMPANY.co_email_address, FiscalYear.FiscalYear FROM PROJECTS p INNER JOIN" +
                            " Department ON p.department_id = Department.department_id INNER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON p.FYID = FiscalYear.FYID INNER JOIN AFFAIRS ON p.Affair_id = AFFAIRS.Affair_id" +
                            " WHERE (CONTRACTORS.contract_no <> N'') AND (CONTRACTORS.contract_no IS NOT NULL) and p.Affair_id=" + affairID + " and CONTRACTORS.cp_tender_award between '" + dtpStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpEndReportDate.Value.ToString("dd/MMM/yyyy") + "'" + whereClause;                            
                        }
                        else if (fiscalYearSelection == 0 && affairID == 0 && (startReportDateChanged == 1 || endReportDateChanged == 1))
                        {
                            sqlCompaniesContractsInfoQuery = "SELECT DISTINCT CONTRACTORS.contract_no,p.project_code, p.project_newname_en,AFFAIRS.Affairs_Name, Department.Department, COMPANY.co_name, COMPANY.co_tel, COMPANY.co_fax, COMPANY.co_email_address, FiscalYear.FiscalYear FROM PROJECTS p INNER JOIN" +
                            " Department ON p.department_id = Department.department_id INNER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON p.FYID = FiscalYear.FYID INNER JOIN AFFAIRS ON p.Affair_id = AFFAIRS.Affair_id" +
                            " WHERE (CONTRACTORS.contract_no <> N'') AND (CONTRACTORS.contract_no IS NOT NULL) and CONTRACTORS.cp_tender_award between '" + dtpStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpEndReportDate.Value.ToString("dd/MMM/yyyy") + "'" + whereClause;                            
                        }
                        else if (fiscalYearSelection != 0 && affairID == 0 && (startReportDateChanged == 1 || endReportDateChanged == 1))
                        {
                            sqlCompaniesContractsInfoQuery = "SELECT DISTINCT CONTRACTORS.contract_no,p.project_code, p.project_newname_en,AFFAIRS.Affairs_Name, Department.Department, COMPANY.co_name, COMPANY.co_tel, COMPANY.co_fax, COMPANY.co_email_address, FiscalYear.FiscalYear FROM PROJECTS p INNER JOIN" +
                            " Department ON p.department_id = Department.department_id INNER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON p.FYID = FiscalYear.FYID INNER JOIN AFFAIRS ON p.Affair_id = AFFAIRS.Affair_id" +
                            " WHERE (CONTRACTORS.contract_no <> N'') AND (CONTRACTORS.contract_no IS NOT NULL) and p.FYID=" + fyId + " and CONTRACTORS.cp_tender_award between '" + dtpStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpEndReportDate.Value.ToString("dd/MMM/yyyy") + "'" + whereClause;
                        }
                    else if (fiscalYearSelection == 0 && affairID != 0 && (startReportDateChanged == 0 || endReportDateChanged == 0))
                        {
                            sqlCompaniesContractsInfoQuery = "SELECT DISTINCT CONTRACTORS.contract_no,p.project_code, p.project_newname_en,AFFAIRS.Affairs_Name, Department.Department, COMPANY.co_name, COMPANY.co_tel, COMPANY.co_fax, COMPANY.co_email_address, FiscalYear.FiscalYear FROM PROJECTS p INNER JOIN" +
                            " Department ON p.department_id = Department.department_id INNER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON p.FYID = FiscalYear.FYID INNER JOIN AFFAIRS ON p.Affair_id = AFFAIRS.Affair_id" +
                            " WHERE (CONTRACTORS.contract_no <> N'') AND (CONTRACTORS.contract_no IS NOT NULL) and p.Affair_id=" + affairID + whereClause;
                        }
                    else if (fiscalYearSelection != 0 && affairID != 0 && (startReportDateChanged == 0 || endReportDateChanged == 0))
                        {
                            sqlCompaniesContractsInfoQuery = "SELECT DISTINCT CONTRACTORS.contract_no,p.project_code, p.project_newname_en,AFFAIRS.Affairs_Name, Department.Department, COMPANY.co_name, COMPANY.co_tel, COMPANY.co_fax, COMPANY.co_email_address, FiscalYear.FiscalYear FROM PROJECTS p INNER JOIN" +
                            " Department ON p.department_id = Department.department_id INNER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON p.FYID = FiscalYear.FYID INNER JOIN AFFAIRS ON p.Affair_id = AFFAIRS.Affair_id" +
                            " WHERE (CONTRACTORS.contract_no <> N'') AND (CONTRACTORS.contract_no IS NOT NULL) and p.Affair_id=" + affairID + " and p.FYID=" + fyId + whereClause;                             
                        }
                    else if (fiscalYearSelection != 0 && affairID == 0 && (startReportDateChanged == 0 || endReportDateChanged == 0))
                        {
                            sqlCompaniesContractsInfoQuery = "SELECT DISTINCT CONTRACTORS.contract_no,p.project_code, p.project_newname_en,AFFAIRS.Affairs_Name, Department.Department, COMPANY.co_name, COMPANY.co_tel, COMPANY.co_fax, COMPANY.co_email_address, FiscalYear.FiscalYear FROM PROJECTS p INNER JOIN" +
                            " Department ON p.department_id = Department.department_id INNER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON p.FYID = FiscalYear.FYID INNER JOIN AFFAIRS ON p.Affair_id = AFFAIRS.Affair_id" +
                            " WHERE (CONTRACTORS.contract_no <> N'') AND (CONTRACTORS.contract_no IS NOT NULL) and p.FYID=" + fyId + whereClause;                             
                        }


                        DataTable dtContractorDetails = dalObj.GetDataFromDB("CmpContractsInfo", sqlCompaniesContractsInfoQuery);

                        if (dtContractorDetails.Rows.Count != 0)
                        {

                            foreach (DataRow colData in dtContractorDetails.Rows)
                            {
                                strBuildContractorDetails.Append("<tr><td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + ++rowCounter + "</b></td>");
                                strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + colData[0] + "</b></td>");
                                 
                                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + colData[1] + "</b></td>");
                                
                                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + colData[2] + "</b></td>");
                                 
                                strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + colData[3].ToString() + "</b></td>");
                                strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + colData[4].ToString() + "</b></td>");
                                strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + colData[5].ToString() + "</b></td>");
                                if (colData[6] != DBNull.Value)
                                {
                                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + colData[6].ToString() + "</b></td>");
                                }
                                else
                                {
                                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                                }
                                if (colData[7] != DBNull.Value)
                                {
                                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + colData[7].ToString() + "</b></td>");
                                }
                                else
                                {
                                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                                }
                                if (colData[8] != DBNull.Value)
                                {
                                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + colData[8].ToString() + "</b></td>");
                                }
                                else
                                {
                                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                                }                               
                                strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + colData[9].ToString() + "</b></td>");                            
                                strBuildContractorDetails.Append("</tr>");
                            }
                        }

                    

                    if (dtContractorDetails.Rows.Count != 0)
                    {
                        strBuildContractorDetails.Append("</table>");
                        lblTotalNoOfRecords.Text = "Total Records Count=" + rowCounter;
                    }
                    else
                    {
                        strBuildContractorDetails.Append("</table>");
                        lblTotalNoOfRecords.Text = "Total Records Count=0";
                        MessageBox.Show("No data exist for selected options", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
               
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while retrieving the information of the contractor");
            }

            return strBuildContractorDetails;
        }



        /// <summary>
        /// To create TenderApproval Dates Report By Varun
        /// </summary>
        /// <returns></returns> 
        /// 

        private StringBuilder getTenderApprovalDatesReport(StringBuilder strBuildTndrApprovalDates)
        {
            int iRowCtr = 0;
            try
            {
                DataTable dtTndrDateDiffData = new DataTable("TndrDateDiffData");
                dtTndrDateDiffData.Columns.Add("SNo");
                dtTndrDateDiffData.Columns.Add("Project_Code");
                dtTndrDateDiffData.Columns.Add("Project_Title");
                dtTndrDateDiffData.Columns.Add("Tender_No");

                dtTndrDateDiffData.Columns.Add("Date_In_Tender_Prep");
                dtTndrDateDiffData.Columns.Add("Date_Out_Document_App_Date");
                dtTndrDateDiffData.Columns.Add("Tender_Prep_Days_Taken");
                dtTndrDateDiffData.Columns.Add("Department");

                dtTndrDateDiffData.Columns.Add("Date_In_Dept_Tender_Req");        
                dtTndrDateDiffData.Columns.Add("Date_Of_Tender");
                dtTndrDateDiffData.Columns.Add("Tender_Days_Taken");
                
                dtTndrDateDiffData.AcceptChanges();
                
                DAL dalObj = new DAL();
                string sqlTndrApprovalStg1DatesQuery = null;
                if (whereClause != null)
                {
                    if (whereClause != "")
                    {
                        sqlTndrApprovalStg1DatesQuery = "SELECT p.proj_id,p.project_code, p.project_newname_en, p.tender_no, td.ptd_receive_on, td.ptd_forwarded_to_dep," +
                        "DATEDIFF(d, td.ptd_receive_on, td.ptd_forwarded_to_dep) AS [DaysTakenForStage1],Department.department FROM PROJECTS AS p INNER JOIN " +
                        "TenderDatesInfo AS td ON p.proj_id = td.proj_id INNER JOIN Department on p.department_ID=Department.department_ID WHERE p.project_code is not NULL and (td.stage_id = 1) AND (td.ptd_receive_on IS NOT NULL) AND (td.ptd_forwarded_to_dep IS NOT NULL) AND " +
                        "(td.ptd_purpose = 'Preparation') AND (td.ptd_tendec_doc_cur_status = 'Approved') and td.ptd_receive_on " +
                        "between '" + dtpStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpEndReportDate.Value.ToString("dd/MMM/yyyy") + "' and" + whereClause;
                    }
                    else
                    {
                        sqlTndrApprovalStg1DatesQuery = "SELECT p.proj_id,p.project_code, p.project_newname_en, p.tender_no, td.ptd_receive_on, td.ptd_forwarded_to_dep," +
                        "DATEDIFF(d, td.ptd_receive_on, td.ptd_forwarded_to_dep) AS [DaysTakenForStage1],Department.department FROM PROJECTS AS p INNER JOIN " +
                        "TenderDatesInfo AS td ON p.proj_id = td.proj_id INNER JOIN Department on p.department_ID=Department.department_ID WHERE p.project_code is not NULL and (td.stage_id = 1) AND (td.ptd_receive_on IS NOT NULL) AND (td.ptd_forwarded_to_dep IS NOT NULL) AND " +
                        "(td.ptd_purpose = 'Preparation') AND (td.ptd_tendec_doc_cur_status = 'Approved') and td.ptd_receive_on " +
                        "between '" + dtpStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpEndReportDate.Value.ToString("dd/MMM/yyyy") + "'";
                    }
                }
                else
                {
                    sqlTndrApprovalStg1DatesQuery = "SELECT p.proj_id,p.project_code, p.project_newname_en, p.tender_no, td.ptd_receive_on, td.ptd_forwarded_to_dep," +
                    "DATEDIFF(d, td.ptd_receive_on, td.ptd_forwarded_to_dep) AS [DaysTakenForStage1],Department.department FROM PROJECTS AS p INNER JOIN " +
                    "TenderDatesInfo AS td ON p.proj_id = td.proj_id INNER JOIN Department on p.department_ID=Department.department_ID WHERE p.project_code is not NULL and (td.stage_id = 1) AND (td.ptd_receive_on IS NOT NULL) AND (td.ptd_forwarded_to_dep IS NOT NULL) AND " +
                    "(td.ptd_purpose = 'Preparation') AND (td.ptd_tendec_doc_cur_status = 'Approved') and td.ptd_receive_on " +
                    "between '" + dtpStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpEndReportDate.Value.ToString("dd/MMM/yyyy") + "'";
                }

                //DataTable dtStage1 = dalObj.GetDataFromDB("Stg1Dates", sqlTndrApprovalStg1DatesQuery);

                string  strTenderTrackingQuery = generatedynamicSQLQuery(sqlTndrApprovalStg1DatesQuery,false);

                DataTable dtStage1 = dalObj.GetDataFromDB("Stg1Dates", strTenderTrackingQuery);

                string sqlTndrApprovalStg2DatesQuery = null;

                if (whereClause != null)
                {
                    if (whereClause != "")
                    {
                        sqlTndrApprovalStg2DatesQuery = "SELECT p.proj_id,p.project_code, p.project_newname_en, p.tender_no, td.ts_receive_on, td.ts_tender_invitation, DATEDIFF(d," +
                        "td.ts_receive_on, td.ts_tender_invitation) AS [DaysTakenForStage2],Department.department FROM PROJECTS AS p INNER JOIN TenderDatesInfo AS td ON p.proj_id = td.proj_id " +
                        "INNER JOIN Department on p.department_ID=Department.department_ID WHERE p.project_code is not NULL and (td.stage_id = 2) AND (td.ts_receive_on IS NOT NULL) AND (td.ts_tender_invitation IS NOT NULL) AND " +
                        "(td.ts_tender_issue IS NULL) and" + whereClause;
                    }
                    else
                    {
                        sqlTndrApprovalStg2DatesQuery = "SELECT p.proj_id,p.project_code, p.project_newname_en, p.tender_no, td.ts_receive_on, td.ts_tender_invitation, DATEDIFF(d," +
                        "td.ts_receive_on, td.ts_tender_invitation) AS [DaysTakenForStage2],Department.department FROM PROJECTS AS p INNER JOIN TenderDatesInfo AS td ON p.proj_id = td.proj_id " +
                        "INNER JOIN Department on p.department_ID=Department.department_ID WHERE p.project_code is not NULL and (td.stage_id = 2) AND (td.ts_receive_on IS NOT NULL) AND (td.ts_tender_invitation IS NOT NULL) AND " +
                        "(td.ts_tender_issue IS NULL)";
                    }
                    
                }
                else
                {
                    sqlTndrApprovalStg2DatesQuery = "SELECT p.proj_id,p.project_code, p.project_newname_en, p.tender_no, td.ts_receive_on, td.ts_tender_invitation, DATEDIFF(d," +
                    "td.ts_receive_on, td.ts_tender_invitation) AS [DaysTakenForStage2],Department.department FROM PROJECTS AS p INNER JOIN TenderDatesInfo AS td ON p.proj_id = td.proj_id " +
                    "INNER JOIN Department on p.department_ID=Department.department_ID WHERE p.project_code is not NULL and (td.stage_id = 2) AND (td.ts_receive_on IS NOT NULL) AND (td.ts_tender_invitation IS NOT NULL) AND " +
                    "(td.ts_tender_issue IS NULL)";
                }

                string strTenderTrackingQuery2 = generatedynamicSQLQuery(sqlTndrApprovalStg2DatesQuery,false);
                DataTable dtStage2 = dalObj.GetDataFromDB("Stg2Dates", strTenderTrackingQuery2);


                if (dtStage1.Rows.Count != 0 & dtStage2.Rows.Count != 0)
                {

                    IList<int> prjColl = getProjects();
                    int rowCounter = 0;
                    foreach (var prjID in prjColl)
                    {
                        DataRow[] drStage1 = dtStage1.Select("Proj_ID = " + prjID);
                        DataRow[] drStage2 = dtStage2.Select("Proj_ID = " + prjID);

                        if (drStage1.Length != 0 & drStage2.Length != 0)
                        {
                            DataRow newRow = dtTndrDateDiffData.NewRow();
                            foreach (DataRow item in drStage1)
                            {
                                newRow["SNo"] = ++rowCounter;
                                newRow["Project_Code"] = item[1];
                                newRow["Project_Title"] = item[2];
                                newRow["Tender_No"] = item[3];
                                newRow["Date_In_Tender_Prep"] = Convert.ToDateTime(item[4]).ToString("dd/MM/yyyy");
                                newRow["Date_Out_Document_App_Date"] = Convert.ToDateTime(item[5]).ToString("dd/MM/yyyy");
                                newRow["Tender_Prep_Days_Taken"] = item[6];
                                newRow["Department"] = item[7];
                            }
                            foreach (DataRow item in drStage2)
                            {
                                newRow["Date_In_Dept_Tender_Req"] = Convert.ToDateTime(item[4]).ToString("dd/MM/yyyy");
                                newRow["Date_Of_Tender"] = Convert.ToDateTime(item[5]).ToString("dd/MM/yyyy");
                                newRow["Tender_Days_Taken"] = item[6];
                                newRow["Department"] = item[7];
                            }

                            dtTndrDateDiffData.Rows.Add(newRow);
                        }
                        if (drStage1.Length != 0 & drStage2.Length == 0)
                        {
                            DataRow newRow = dtTndrDateDiffData.NewRow();
                            foreach (DataRow item in drStage1)
                            {
                                newRow["SNo"] = ++rowCounter;
                                newRow["Project_Code"] = item[1];
                                newRow["Project_Title"] = item[2];
                                newRow["Tender_No"] = item[3];
                                newRow["Date_In_Tender_Prep"] = Convert.ToDateTime(item[4]).ToString("dd/MM/yyyy");
                                newRow["Date_Out_Document_App_Date"] = Convert.ToDateTime(item[5]).ToString("dd/MM/yyyy");
                                newRow["Tender_Prep_Days_Taken"] = item[6];
                                newRow["Department"] = item[7];
                            }
                            foreach (DataRow item in drStage2)
                            {
                                newRow["Date_In_Dept_Tender_Req"] = Convert.ToDateTime(item[4]).ToString("dd/MM/yyyy");
                                newRow["Date_Of_Tender"] = Convert.ToDateTime(item[5]).ToString("dd/MM/yyyy");
                                newRow["Tender_Days_Taken"] = item[6];
                                newRow["Department"] = item[7];
                            }

                            dtTndrDateDiffData.Rows.Add(newRow);
                        }
                        if (drStage1.Length == 0 & drStage2.Length != 0)
                        {
                            DataRow newRow = dtTndrDateDiffData.NewRow();

                            foreach (DataRow item in drStage2)
                            {
                                newRow["SNo"] = ++rowCounter;
                                newRow["Project_Code"] = item[1];
                                newRow["Project_Title"] = item[2];
                                newRow["Tender_No"] = item[3];
                                newRow["Date_In_Dept_Tender_Req"] = Convert.ToDateTime(item[4]).ToString("dd/MM/yyyy");
                                newRow["Date_Of_Tender"] = Convert.ToDateTime(item[5]).ToString("dd/MM/yyyy");
                                newRow["Tender_Days_Taken"] = item[6];
                                newRow["Department"] = item[7];
                            }

                            dtTndrDateDiffData.Rows.Add(newRow);
                        }
                    }


                    strBuildTndrApprovalDates.Append("<table width='100%' cellpadding='0' cellspacing='0' style='border: solid 1px;'><tr><td colspan='11' style='text-align:center;height: 35px;font-size: 12pt !important;font-weight:bold; vertical-align:middle;border: solid 1px;background-color:#C0D9AF'><b>Count of Tender Approval Days</b></td></tr>");
                    strBuildTndrApprovalDates.Append("<tr><td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 12pt; font-weight:bold; vertical-align:middle; border:solid 1px; background-color:#ADD8E6;'><b>SNo.</b></td><td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 12pt; font-weight:bold; vertical-align:middle; border:solid 1px; background-color:#ADD8E6;'><b>Project Code</b></td>");
                    strBuildTndrApprovalDates.Append("<td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 12pt; font-weight:bold;");
                    strBuildTndrApprovalDates.Append(" vertical-align:middle; border:solid 1px; background-color:#ADD8E6;'><b>Project Title</b></td><td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 12pt; font-weight:bold; vertical-align:middle; border:solid 1px; background-color:#ADD8E6;'><b>Tender No. Generated</b></td>");
                    strBuildTndrApprovalDates.Append("<td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 12pt; font-weight:bold; vertical-align:middle; border:solid 1px; background-color:#ADD8E6;'><b>Date In-Document Approval Date</b></td><td style='border-style: none; border-color: inherit; border-width: 1; margin: inherit; text-align:center;");
                    strBuildTndrApprovalDates.Append(" font-size: 12pt; font-weight:bold; vertical-align:middle; background-color:#ADD8E6;'><b>Date Out-Document Approval Date</b></td><td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 12pt; font-weight:bold; vertical-align:middle; border:solid 1px; background-color:#ADD8E6;'><b>Days Taken</b></td>");
                    strBuildTndrApprovalDates.Append("<td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 12pt; font-weight:bold; vertical-align:middle; border:solid 1px; background-color:#ADD8E6;'><b>Date In-Dept. Tendering Request</b></td><td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 12pt; font-weight:bold; vertical-align:middle;");
                    strBuildTndrApprovalDates.Append(" border:solid 1px; background-color:#ADD8E6;'><b>Date of Tender</b></td><td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 12pt; font-weight:bold; vertical-align:middle; border:solid 1px; background-color:#ADD8E6;'><b>Days Taken</b></td>");
                    strBuildTndrApprovalDates.Append("<td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 12pt; font-weight:bold; vertical-align:middle; border:solid 1px; background-color:#ADD8E6;'><b>Department Name</b></td></tr>");


                    //var fullOuterJoin = leftOuterJoin.c(rightOuterJoin);

                    foreach (DataRow item in dtTndrDateDiffData.Rows)
                    {

                        //MessageBox.Show(String.Format("ProjCode = {0}, ProjTitle = {1}, TenderNo = {2}, PtdReceiveOn = {3}", item.strProjCode, item.strProjTitle, item.strTenderNo, item.datePtdReceiveOn));
                        strBuildTndrApprovalDates.Append("<tr><td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 12pt; vertical-align:middle; border:solid 1px; background-color:#ADD8E6;'>" + item[0] + "</td>");
                        strBuildTndrApprovalDates.Append("<td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 12pt; vertical-align:middle; border:solid 1px; background-color:#ADD8E6;'>" + item[1] + "</td>");
                      
                            strBuildTndrApprovalDates.Append("<td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 12pt; vertical-align:middle; border:solid 1px; background-color:#ADD8E6;'>" + item[2] + "</td>");
                        //else
                        //    strBuildTndrApprovalDates.Append("<td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 12pt; vertical-align:middle; border:solid 1px; background-color:#ADD8E6;'></td>");

                        //if (item[0] != null)
                            strBuildTndrApprovalDates.Append("<td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 12pt; vertical-align:middle; border:solid 1px; background-color:#ADD8E6;'>" + item[3] + "</td>");
                        //else
                        //    strBuildTndrApprovalDates.Append("<td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 12pt; vertical-align:middle; border:solid 1px; background-color:#ADD8E6;'></td>");
                        //if (item[0] != null)
                            strBuildTndrApprovalDates.Append("<td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 12pt; vertical-align:middle; border:solid 1px; background-color:#ADD8E6;'>" + item[4] + "</td>");
                        //else
                        //    strBuildTndrApprovalDates.Append("<td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 12pt; vertical-align:middle; border:solid 1px; background-color:#ADD8E6;'></td>");
                        //if (item[0] != null)
                            strBuildTndrApprovalDates.Append("<td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 12pt; vertical-align:middle; border:solid 1px; background-color:#ADD8E6;'>" + item[5] + "</td>");
                        //else
                        //    strBuildTndrApprovalDates.Append("<td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 12pt; vertical-align:middle; border:solid 1px; background-color:#ADD8E6;'></td>");
                        //if (item[0] != null)
                            strBuildTndrApprovalDates.Append("<td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 12pt; vertical-align:middle; border:solid 1px; background-color:#ADD8E6;'>" + item[6] + "</td>");
                        //else
                        //    strBuildTndrApprovalDates.Append("<td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 12pt; vertical-align:middle; border:solid 1px; background-color:#ADD8E6;'></td>");
                        //if (item[0] != null)                            
                        //else
                        //    strBuildTndrApprovalDates.Append("<td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 12pt; vertical-align:middle; border:solid 1px; background-color:#ADD8E6;'></td>");
                        //if (item[0] != null)
                            strBuildTndrApprovalDates.Append("<td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 12pt; vertical-align:middle; border:solid 1px; background-color:#ADD8E6;'>" + item[8] + "</td>");
                        //else
                        //    strBuildTndrApprovalDates.Append("<td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 12pt; vertical-align:middle; border:solid 1px; background-color:#ADD8E6;'></td>");
                        //if (item[0] != null)
                            strBuildTndrApprovalDates.Append("<td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 12pt; vertical-align:middle; border:solid 1px; background-color:#ADD8E6;'>" + item[9] + "</td>");
                        //else
                        //    strBuildTndrApprovalDates.Append("<td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 12pt; vertical-align:middle; border:solid 1px; background-color:#ADD8E6;'></td>");

                            strBuildTndrApprovalDates.Append("<td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 12pt; vertical-align:middle; border:solid 1px; background-color:#ADD8E6;'>" + item[10] + "</td>");

                            strBuildTndrApprovalDates.Append("<td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 12pt; vertical-align:middle; border:solid 1px; background-color:#ADD8E6;'>" + item[7] + "</td>");

                        strBuildTndrApprovalDates.Append("</tr>");
                         
                    }
                    strBuildTndrApprovalDates.Append("<tr><td colspan='11' style=\"width:auto;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b style=\"font-style: italic\">This report is generated by TCMS dated :</b><b>" + DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss") + "</b></td></tr>");
                    strBuildTndrApprovalDates.Append("</table>");
                    lblTotalNoOfRecords.Text = "Total Records Count=" + rowCounter.ToString();               
                }
                else
                {
                    lblTotalNoOfRecords.Text = "Total Records Count=0";
                    MessageBox.Show("No data exist for selected options","Information",MessageBoxButtons.OK,MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Excep" + ex.Message + " " + iRowCtr);
            }
        
            return strBuildTndrApprovalDates;
        }        

        private IList<int> getProjects()
        {
            IList<int> prjIDColl = new List<int>();
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();

                        string sqlQuery = "SELECT distinct proj_id FROM TenderDatesInfo WHERE (stage_id = 1) or (stage_id = 2)";
                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        int iCnt = 0;
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                prjIDColl.Add(Convert.ToInt16(dr[0]));
                            }
                        }
                        cmd.Dispose();
                    }
                    sqlConn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            return prjIDColl;
        } 

        private void frmReports_Load(object sender, EventArgs e)
        {
            try
            {
                //Retrieve Affairs
                getAllAffairs();
                //Retrieve departments
                getAllDepartments();
                //Retrieve list of Fiscal Years
                getAllFiscalYears();
                // Retrieve Tender Committees list
                getAllTenderCommittees();
                //Retrieve list of Tender Stages.
                getAllTenderStages();
                //Retrieve list of Tender Types
                getAllTenderTypes();
                //Retrieve list of Tender Status
                getAllTenderStatus();
                getAllContractTypes();
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }            
        }
        private void btnExport_Click(object sender, EventArgs e)
        {
            comCls.ExportToExcel(wbReport);             
        }


        string whereClause = null;
        private void btnSubmitReport_Click(object sender, EventArgs e)
        {            
            StringBuilder sblTenderTracking = new StringBuilder();
            SqlConnection sqlConn = new SqlConnection(strCon);
            //DataTable dtAffairs = null;
            sqlConn.Open();
            DAL dalObj = new DAL();
            try
            {
                //string sqlAffairsQuery = "SELECT AFFAIRS.[Affairs_Name],Affair_id FROM AFFAIRS ORDER BY AFFAIRS.[Affairs_Name] ASC";
                //dtAffairs = dalObj.GetDataFromDB("AffairsInfo", sqlAffairsQuery);
                whereClause = comCls.CheckAccessRightsForTenderNoYear(userRightsColl);                 
                if (strReportChoice.Equals("Tender Tracking"))
                    sblTenderTracking = getTenderTrackingHeader(sblTenderTracking, dtAffairs);
                else if (strReportChoice.Equals("Tender Committee"))
                    sblTenderTracking = getAwardedTenders(sblTenderTracking); //sblTenderTracking = getTenderCommitteeHeader(sblTenderTracking);
                //else if (strReportChoice.Equals("Awarded Tenders"))
                //    sblTenderTracking = getAwardedTenders(sblTenderTracking);
                else if (strReportChoice.Equals("Work Order"))        
                    sblTenderTracking = getWorkOrderReport();                
                else if (strReportChoice.Equals("Project Tracking"))
                    sblTenderTracking = getProjectTrackingHeader(sblTenderTracking, dtAffairs);
                else if (strReportChoice.Equals("Tender Approval Dates"))
                    sblTenderTracking = getTenderApprovalDatesReport(sblTenderTracking); //sblTenderTracking, dtAffairs
                //else if (strReportChoice.Equals("ContractorDetails"))
                //    sblTenderTracking = getContractorDetailsReport(sblTenderTracking, Convert.ToInt32(cmbDepartment.SelectedValue), Convert.ToInt16(cmbFiscalyear.SelectedValue), cmbDepartment); //sblTenderTracking, dtAffairs
                else if (strReportChoice.Equals("AwardedTenders"))
                    sblTenderTracking = getAwardedTendersReport(sblTenderTracking, cmbDepartment.SelectedIndex, cmbDepartment.SelectedItem.ToString(), Convert.ToInt16(cmbFiscalyear.SelectedValue), cmbFiscalyear, cmbTenderCommittee); //sblTenderTracking, dtAffairs
                //else if (strReportChoice.Equals("CompaniesContractsInfo"))
                //{
                //    DataRowView dtView = (DataRowView)cmbDepartment.SelectedItem;
                //    sblTenderTracking = getCompaniesContractsInfo(sblTenderTracking, Convert.ToInt16(dtView.Row.ItemArray[1].ToString()), Convert.ToInt16(cmbFiscalyear.SelectedValue)); //sblTenderTracking, dtAffairs
                //}

                wbReport.DocumentText = sblTenderTracking.ToString();
                wbReport.ScrollBarsEnabled = true;

            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }
        }
        private void setDefaultSearchChoice()
        {
            try
            {
                cmbDepartment.SelectedIndex = cmbDepartment.FindStringExact("All");
                cmbAffairs.SelectedIndex = cmbAffairs.FindStringExact("All");
                cmbFiscalyear.SelectedIndex = cmbFiscalyear.FindStringExact("All");
                cmbTenderCommittee.SelectedIndex = cmbTenderCommittee.FindStringExact("All");
                cmbTenderStage.SelectedIndex = cmbTenderStage.FindStringExact("All");
                cmbTenderType.SelectedIndex = cmbTenderType.FindStringExact("All");
                cmbTenderStatus.SelectedIndex = cmbTenderStatus.FindStringExact("All");
                cmbContractType.SelectedIndex = cmbContractType.FindStringExact("All");
            }
            catch(Exception ex)
            {
                string exMsg = ex.Message;
            }
        }    
        private void lnkTndrTracking_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //setDefaultSearchChoice();
            lblTotalNoOfRecords.Text = "";
            lblAffairs.Visible = true;
            lblAffairs.Text = "Departments";
            cmbDepartment.Visible = true;
            getAllAffairs();
            wbReport.DocumentText = string.Empty;             
            cmbAffairs.Visible = true;             
            label1.Visible = true;
            label1.Text = "Affairs";
            label2.Visible = true;
            cmbTenderCommittee.Visible = true;
            label4.Visible = true;
            cmbTenderStage.Visible = true;
            label6.Visible = true;
            cmbTenderType.Visible = true;
            label5.Visible = true;
            cmbTenderStatus.Visible = true;
            label7.Visible = true;
            cmbContractType.Visible = true;
            groupBox1.Visible = true;
            strReportChoice = string.Empty;
            groupBox1.Visible = true;
            lblStartRepDate.Visible =true;
            dtpStartReportDate.Visible = true;
            lblEndRepDate.Visible = true;
            dtpEndReportDate.Visible = true;
            lblStartRepDate.Text = "Start Report Date";
            lblEndRepDate.Text = "End Report Date";
            strReportChoice = "Tender Tracking";
            lblCurrentReportName.Text = "Tender Tracking Report";
        }
        private void lnkTndrCmt_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //setDefaultSearchChoice();
            lblTotalNoOfRecords.Text = "";
            lblAffairs.Visible = true;
            lblAffairs.Text = "Departments";
            cmbDepartment.Visible = true;
            getAllAffairs();
            wbReport.DocumentText = string.Empty;
            label1.Visible = true;
            label1.Text = "Affairs";
            cmbAffairs.Visible = true;
            label2.Visible = true;
            cmbTenderCommittee.Visible = true;
            label4.Visible = true;
            cmbTenderStage.Visible = true;
            label6.Visible = true;
            cmbTenderType.Visible = true;
            label5.Visible = true;
            cmbTenderStatus.Visible = true;
            label7.Visible = true;
            cmbContractType.Visible = true;
            groupBox1.Visible = true;
            strReportChoice = string.Empty;
            groupBox1.Visible = true;
            lblStartRepDate.Visible = true;
            dtpStartReportDate.Visible = true;
            lblEndRepDate.Visible = true;
            dtpEndReportDate.Visible = true;
            lblStartRepDate.Text = "Start Report Date";
            lblEndRepDate.Text = "End Report Date";
            strReportChoice = "Tender Committee";
            lblCurrentReportName.Text = "Tender Committee Report";
        }
        private void linkProjTracking_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //setDefaultSearchChoice();
            lblTotalNoOfRecords.Text = "";
            lblAffairs.Visible = true;
            lblAffairs.Text = "Departments";
            cmbDepartment.Visible = true;
            getAllAffairs();
            wbReport.DocumentText = string.Empty;
            label1.Visible = true;
            label1.Text = "Affairs";
            cmbAffairs.Visible = true;
            label2.Visible = true;
            cmbTenderCommittee.Visible = true;
            label4.Visible = true;
            cmbTenderStage.Visible = true;
            label6.Visible = true;
            cmbTenderType.Visible = true;
            label5.Visible = true;
            cmbTenderStatus.Visible = true;
            label7.Visible = true;
            cmbContractType.Visible = true;
            groupBox1.Visible = true;
            strReportChoice = string.Empty;
            groupBox1.Visible = true;
            lblStartRepDate.Visible = true;
            dtpStartReportDate.Visible = true;
            lblEndRepDate.Visible = true;
            dtpEndReportDate.Visible = true;
            lblStartRepDate.Text = "Start Report Date";
            lblEndRepDate.Text = "End Report Date";
            strReportChoice = "Project Tracking";
            lblCurrentReportName.Text = "Project Tracking Report";
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //setDefaultSearchChoice();
            //wbReport.DocumentText = string.Empty;
            //groupBox1.Visible = false;
            //strReportChoice = string.Empty;
            //strReportChoice = "Qatari Share In Company";
            //groupBox1.Visible = true;

            //frmShare frmcmpShare = new frmShare();
            frmGenerateBiddersReports frmGBidRep = new frmGenerateBiddersReports();
            frmGBidRep.StartPosition = FormStartPosition.CenterScreen;
            frmGBidRep.ShowDialog(); 
        }

        private void linkTotTndrApprovalDays_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //setDefaultSearchChoice();
            lblTotalNoOfRecords.Text = "";
            lblAffairs.Text = "Affairs";
            lblAffairs.Visible = true;
            //getAllAffairs();
            wbReport.DocumentText = string.Empty;
            label1.Visible = true;
            label1.Text = "Departments";
            cmbAffairs.Visible = true;
            label2.Visible = true;
            cmbTenderCommittee.Visible = true;
            label4.Visible = true;
            cmbTenderStage.Visible = true;
            label6.Visible = true;
            cmbTenderType.Visible = true;
            label5.Visible = true;
            cmbTenderStatus.Visible = true;
            label7.Visible = true;
            cmbContractType.Visible = true;
            groupBox1.Visible = true;
            strReportChoice = string.Empty;
            groupBox1.Visible = true;
            lblStartRepDate.Visible = true;
            dtpStartReportDate.Visible = true;
            lblEndRepDate.Visible = true;
            dtpEndReportDate.Visible = true;
            strReportChoice = "Tender Approval Dates";
            lblCurrentReportName.Text = "Tender Approval Dates Report";
        }

        private void linkContractorDetails_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //lblTotalNoOfRecords.Text = "";
            //wbReport.DocumentText = string.Empty;
            ////tableLayoutPanel1.Controls.RemoveAt(1);
            ////tableLayoutPanel1.Controls.RemoveAt(3);
            ////tableLayoutPanel1.Controls.RemoveAt(4);
            ////tableLayoutPanel1.Controls.RemoveAt(5);
            //lblAffairs.Text = "Contractor Names";
            //label3.Visible = true;
            //getAllContractors();
            //cmbFiscalyear.Visible = true;
            ////cmbFiscalyear.Width = 35;
            //label1.Visible = false;
            //cmbAffairs.Visible = false;
            //label2.Visible = false;
            //cmbTenderCommittee.Visible = false;
            //label4.Visible = false;
            //cmbTenderStage.Visible = false;
            //label6.Visible = false;
            //cmbTenderType.Visible = false;
            //label5.Visible = false;
            //cmbTenderStatus.Visible = false;
            //label7.Visible = false;
            //cmbContractType.Visible = false;
            //groupBox1.Visible = false;
            //strReportChoice = string.Empty;
            //groupBox1.Visible = true;
            //lblStartRepDate.Visible = true;
            //dtpStartReportDate.Visible = true;
            //lblEndRepDate.Visible = true;
            //dtpEndReportDate.Visible = true;
            //strReportChoice = "ContractorDetails";
            //lblCurrentReportName.Text = "Contractor Details Report";
            frmContractorDetails tenderInfo = new frmContractorDetails(userRightsColl, mAffairShortName);
            tenderInfo.StartPosition = FormStartPosition.CenterParent;
            tenderInfo.ShowDialog();
        }

        private void linkStaffJobTrackDetails_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmStaffJobTrackingDetails fStaffJobTrack = new frmStaffJobTrackingDetails(userRightsColl);
            fStaffJobTrack.Show();
        }

        

        static short startReportDateChanged = 0;
        private void dtpStartReportDate_ValueChanged(object sender, EventArgs e)
        {
            startReportDateChanged = 1;
            fiscalYearSelection = 0;
        }

        static short endReportDateChanged = 0;
        private void dtpEndReportDate_ValueChanged(object sender, EventArgs e)
        {
            endReportDateChanged = 1;
            fiscalYearSelection = 0;
        }

        static short fiscalYearSelection = 0;         
        private void cmbFiscalyear_SelectionChangeCommitted(object sender, EventArgs e)
        {
            startReportDateChanged = 0;
            endReportDateChanged = 0;
            fiscalYearSelection = 1;
        }

        private void linkAwardedTenders_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lblTotalNoOfRecords.Text = "";
            wbReport.DocumentText = string.Empty;
            //tableLayoutPanel1.Controls.RemoveAt(1);
            //tableLayoutPanel1.Controls.RemoveAt(3);
            //tableLayoutPanel1.Controls.RemoveAt(4);
            //tableLayoutPanel1.Controls.RemoveAt(5);
            lblAffairs.Text = "Month";
            lblAffairs.Visible = true;
            cmbDepartment.DataSource = null;
            cmbDepartment.Items.Clear();
            cmbDepartment.Items.Add("Select Month");
            cmbDepartment.Items.Add("January");
            cmbDepartment.Items.Add("Febuary");
            cmbDepartment.Items.Add("March");
            cmbDepartment.Items.Add("April");
            cmbDepartment.Items.Add("May");
            cmbDepartment.Items.Add("June");
            cmbDepartment.Items.Add("July");
            cmbDepartment.Items.Add("August");
            cmbDepartment.Items.Add("September");
            cmbDepartment.Items.Add("October");
            cmbDepartment.Items.Add("November");
            cmbDepartment.Items.Add("December");
            cmbDepartment.SelectedIndex = 0;
            cmbDepartment.Visible = true;

            getCalendarYears();
            cmbTenderCommittee.DataSource = null;
            cmbTenderCommittee.Items.Clear();             
            cmbTenderCommittee.Items.Add("All");
            cmbTenderCommittee.Items.Add("Qatari");
            cmbTenderCommittee.Items.Add("Non-Qatari");
            cmbTenderCommittee.SelectedIndex = 0;

            label3.Visible = true;
            label1.Visible = false;
            cmbAffairs.Visible = false;
            cmbFiscalyear.Visible = true;
            //cmbFiscalyear.Items.Clear();
            //cmbFiscalyear.Items.Add("Select Year");
            //cmbFiscalyear.Items.Add("2005");
            //cmbFiscalyear.Items.Add("2006");
            //cmbFiscalyear.Items.Add("2007");
            //cmbFiscalyear.Items.Add("2008");
            //cmbFiscalyear.Items.Add("2009");
            //cmbFiscalyear.Items.Add("2010");
            //cmbFiscalyear.Items.Add("2011");
            //cmbFiscalyear.Items.Add("2012");
            //cmbFiscalyear.Items.Add("2013");
            //cmbFiscalyear.Items.Add("2014");
            //cmbFiscalyear.Items.Add("2015");
            //cmbFiscalyear.Items.Add("2016");
            //cmbFiscalyear.Items.Add("2017");
            //cmbFiscalyear.Items.Add("2018");
            //cmbFiscalyear.Items.Add("2019");
            //cmbFiscalyear.Items.Add("2020");
            //cmbFiscalyear.Items.Add("2021");
            //cmbFiscalyear.Items.Add("2022");
            //cmbFiscalyear.Items.Add("2023");
            //cmbFiscalyear.Items.Add("2024");
            //cmbFiscalyear.Items.Add("2025");

            label2.Text = "Contractor Category";
            //cmbFiscalyear.Width = 35;
            label1.Visible = false;
            cmbAffairs.Visible = false;
            label2.Visible = true;
            cmbTenderCommittee.Visible = true;
            label4.Visible = false;
            cmbTenderStage.Visible = false;
            label6.Visible = false;
            cmbTenderType.Visible = false;
            label5.Visible = false;
            cmbTenderStatus.Visible = false;
            label7.Visible = false;
            cmbContractType.Visible = false;
            groupBox1.Visible = false;
            strReportChoice = string.Empty;
            groupBox1.Visible = true;
            lblStartRepDate.Visible = false;
            dtpStartReportDate.Visible = false;
            lblEndRepDate.Visible = false;
            dtpEndReportDate.Visible = false;

            strReportChoice = "AwardedTenders";
            lblCurrentReportName.Text = "Awarded Tenders Report";
        }

        private void linkCoParticipationInDiffTenders_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lblTotalNoOfRecords.Text = "";
            frmCompanyParticipationInDifferentTenders frmCQatariRep = new frmCompanyParticipationInDifferentTenders(userRightsColl);
            frmCQatariRep.StartPosition = FormStartPosition.CenterScreen;
            frmCQatariRep.ShowDialog();
        }
 

        private void linkContractorQatariNonQatariShare_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmContractorQatariShareReports frmCQatariRep = new frmContractorQatariShareReports();
            frmCQatariRep.StartPosition = FormStartPosition.CenterScreen;
            frmCQatariRep.ShowDialog();
        }

        private void cmbFiscalyear_SelectedIndexChanged(object sender, EventArgs e)
        {
            startReportDateChanged = 0;
            endReportDateChanged = 0;
            fiscalYearSelection = 1;
        }

        private void lblQSWorkingStatus_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmQSWorkingStatus frmQSWS = new frmQSWorkingStatus(userRightsColl);
            frmQSWS.StartPosition = FormStartPosition.CenterScreen;
            frmQSWS.ShowDialog();
        }

        private void linkShowContracts_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmListContracts frmListContracts = new frmListContracts(userRightsColl);
            frmListContracts.StartPosition = FormStartPosition.CenterScreen;
            frmListContracts.ShowDialog();
        }

        private void linkCntrAmnt_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmContractValues frmListContracts = new frmContractValues();
            frmListContracts.StartPosition = FormStartPosition.CenterScreen;
            frmListContracts.ShowDialog();
        }

        private void linkTenderingRecs_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmTenderingRecords frmListContracts = new frmTenderingRecords();
            frmListContracts.StartPosition = FormStartPosition.CenterScreen;
            frmListContracts.ShowDialog();
        }

        private void linkWorkOrder_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //setDefaultSearchChoice();
            lblTotalNoOfRecords.Text = "";
            lblAffairs.Visible = false;
            //getAllAffairs();
            wbReport.DocumentText = string.Empty;
            label1.Visible = false;
            cmbAffairs.Visible = false;
            cmbFiscalyear.Visible = true;
            label2.Visible = false;
            cmbTenderCommittee.Visible = false;
            label4.Visible = false;
            cmbTenderStage.Visible = false;
            label6.Visible = false;
            cmbTenderType.Visible = false;
            label5.Visible = false;
            cmbTenderStatus.Visible = false;
            label7.Visible = false;
            cmbContractType.Visible = false;
            cmbDepartment.Visible = false;
            groupBox1.Visible = true;
            strReportChoice = string.Empty;           
            lblStartRepDate.Visible = true;
            dtpStartReportDate.Visible = true;
            lblEndRepDate.Visible = true;
            dtpEndReportDate.Visible = true;
            startReportDateChanged = 0;
            endReportDateChanged = 0;
            dtpStartReportDate.Value = DateTime.Now;
            dtpEndReportDate.Value = DateTime.Now;
            lblStartRepDate.Text = "WorkOrder Start AwardDate";
            lblEndRepDate.Text = "WorkOrder End AwardDate";
            strReportChoice = "Work Order";
            lblCurrentReportName.Text = "Work Order Award Report";
        }

        private void lnkContractsInfo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmContractsInfo frmContractsInfo = new frmContractsInfo(userRightsColl,mAffairShortName);
            frmContractsInfo.StartPosition = FormStartPosition.CenterScreen;
            frmContractsInfo.ShowDialog();             
        }

        private void cmbDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            startReportDateChanged = 0;
            endReportDateChanged = 0;
            if (cmbFiscalyear.SelectedValue == null)
            {
                fiscalYearSelection = 0;
            }
            else if (cmbFiscalyear.SelectedValue.ToString() != "0")
            {
                fiscalYearSelection = 1;
            }
            else
            {
                fiscalYearSelection = 0;
            }
        }

        private void TenderCommittee_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmTenderCommittee frmTenderComm = new frmTenderCommittee(userRightsColl);
            frmTenderComm.StartPosition = FormStartPosition.CenterScreen;
            frmTenderComm.ShowDialog(); 
        }

        private void CommittedContacts_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmCommittedContracts frmCommContracts = new frmCommittedContracts(userRightsColl);
            frmCommContracts.StartPosition = FormStartPosition.CenterScreen;
            frmCommContracts.ShowDialog(); 
        }

        private void lnkTndrCmtAward_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmTenderCommAward frmTdrAward = new frmTenderCommAward();
            frmTdrAward.StartPosition = FormStartPosition.CenterScreen;
            frmTdrAward.ShowDialog(); 
        }

        private void lnkTdrBondTracking_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmTenderBondTracking frmTdrAward = new frmTenderBondTracking();
            frmTdrAward.StartPosition = FormStartPosition.CenterScreen;
            frmTdrAward.ShowDialog();
        }

        private void lnkLocalCompanies_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmLocalCompaniesDetails frmLocalCmp = new frmLocalCompaniesDetails();
            frmLocalCmp.StartPosition = FormStartPosition.CenterScreen;
            frmLocalCmp.ShowDialog();
        }

        private void lnkReTenderProj_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmReTenderProjects frmLocalCmp = new frmReTenderProjects();
            frmLocalCmp.StartPosition = FormStartPosition.CenterScreen;
            frmLocalCmp.ShowDialog();
        }                   
                
    }
}
