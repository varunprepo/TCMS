﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TenderTrackingSystem;

namespace MDI_ParenrForm.Reports
{
    public partial class frmLocalCompaniesDetails : Form
    {
        private string strCon = ConfigurationManager.AppSettings["TCMSConnString"].ToString();
        
        string whereClause = null;         
        CommonClass comCls = null;
        public frmLocalCompaniesDetails()
        {
            InitializeComponent();
            comCls = new CommonClass("");            
            
            //whereClause = comCls.CheckAccessRightsForTenderNoYear(userRightsCollComm);
            //getAllContractors();
            getCalendarYears(cmbFiscalYear);
            //getCalendarYears(cmbCommitmentYear);             
        }

         


        /// <summary>
        /// Created by Varun on 19/02/14, for Retrieving All Contractors
        /// </summary>
        private void getAllContractors()
        {
            SqlConnection sqlConn = new SqlConnection(strCon);
            DataTable dtContractors = null;
            try
            {
                sqlConn.Open();
                DAL dalObj = new DAL();
                string sqlContractorQuery = "";
                sqlContractorQuery = "SELECT DISTINCT COMPANY.co_id, COMPANY.co_name FROM COMPANY INNER JOIN  CONTRACTORS ON COMPANY.co_id = CONTRACTORS.co_id ORDER BY COMPANY.co_name";
                dtContractors = dalObj.GetDataFromDB("Contractors", sqlContractorQuery);
                //DataRow row = dtContractors.NewRow();
                //row["co_name"] = "All";
                //row["co_id"] = 0;
                //dtContractors.Rows.Add(row);   
                //cmbContractorNames.DataSource = dtContractors;
                //cmbContractorNames.DisplayMember = "co_name";
                //cmbContractorNames.ValueMember = "co_id";
                //cmbContractorNames.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }

        }
         

        /// <summary>
        /// 
        /// </summary>
        private void getCalendarYears(ComboBox cmb)
        {
            SqlConnection sqlConn = new SqlConnection(strCon);
            try
            {
                DataTable dtCalendarYear = null;
                sqlConn.Open();
                DAL dalObj = new DAL();
                string sqlQuery = "SELECT FYID,[FiscalYear] FROM [FiscalYear] ORDER BY [FiscalYear] ASC";
                dtCalendarYear = dalObj.GetDataFromDB("CalendarYears", sqlQuery);
                DataRow row = dtCalendarYear.NewRow();
                row["FiscalYear"] = "All";
                row["FYID"] = 0;
                dtCalendarYear.Rows.Add(row);
                cmb.DataSource = dtCalendarYear;
                cmb.DisplayMember = "FiscalYear";
                cmb.ValueMember = "FYID";
                cmb.SelectedIndex = cmb.FindStringExact("All");
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }
        }         

        static short startReportDateChanged = 0;
        static short endReportDateChanged = 0;
        static short fiscalYearSelection = 0;
        static short commitYearSelection = 0;
              

        private void dtpStartReportDate_ValueChanged(object sender, EventArgs e)
        {
            startReportDateChanged = 1;
            fiscalYearSelection = 0;
            commitYearSelection = 0;
        }

        private void dtpEndReportDate_ValueChanged(object sender, EventArgs e)
        {
            endReportDateChanged = 1;
            fiscalYearSelection = 0;
            commitYearSelection = 0;
        }

        private void cmbFiscalYear_SelectedIndexChanged(object sender, EventArgs e)
        {
            startReportDateChanged = 0;
            endReportDateChanged = 0;
            fiscalYearSelection = 1;
            commitYearSelection = 0;          
        }

        private void btnExportToExcel_Click(object sender, EventArgs e)
        {
            comCls.ExportToExcel(webReport);
        }

        int rowCounter = 0;         
        private void btnGenerateReport_Click(object sender, EventArgs e)
        {
            try
            {
                StringBuilder strBuildContractorDetails = new StringBuilder();
                
                int fyId = 0;
                rowCounter = 0;
                DAL dalObj = new DAL();
                //string sqlProjIdQuery = "";

                //DataTable dtProjectIds = new DataTable();
                if (fiscalYearSelection != 0 && startReportDateChanged == 0 && endReportDateChanged == 0)
                {
                    fyId = Convert.ToInt32(cmbFiscalYear.SelectedValue);
                    if (fyId != 0)
                    {
                        whereClause = " and p.FYID=" + fyId;
                    }
                    else
                    {
                        whereClause = "";
                    }
                    //sqlProjIdQuery = "select distinct p.proj_id,FiscalYear.FiscalYear from PROJECTS p join FiscalYear on p.FYID=FiscalYear.FYID where p.FYID=" + fyId;
                    //dtProjectIds = dalObj.GetDataFromDB("ProjectIds", sqlProjIdQuery);
                }
                //else if (commitYearSelection != 0 && startReportDateChanged == 0 && endReportDateChanged == 0)
                //{
                //    if (cmbCommitmentYear.SelectedValue.ToString() != "0")
                //    {
                //        //sqlProjIdQuery = "select distinct p.proj_id,FiscalYear.FiscalYear from PROJECTS p join FiscalYear on p.FYID=FiscalYear.FYID where p.FYID=" + cmbCommitmentYear.SelectedValue;
                //        //dtProjectIds = dalObj.GetDataFromDB("ProjectIds", sqlProjIdQuery);
                //        whereClause = " and p.FYID=" + cmbCommitmentYear.SelectedValue;
                //    }
                //    else
                //    {
                //        //sqlProjIdQuery = "select distinct p.proj_id,FiscalYear.FiscalYear from PROJECTS p join FiscalYear on p.FYID=FiscalYear.FYID";
                //        //dtProjectIds = dalObj.GetDataFromDB("ProjectIds", sqlProjIdQuery);
                //    }
                //}
                //else
                //{
                //    //sqlProjIdQuery = "select distinct p.proj_id,FiscalYear.FiscalYear from PROJECTS p join FiscalYear on p.FYID=FiscalYear.FYID ";
                //    //dtProjectIds = dalObj.GetDataFromDB("ProjectIds", sqlProjIdQuery);
                //}
                if(whereClause==null)
                {
                    whereClause = "";
                }

                DataTable dtContractorDetails = null;


                strBuildContractorDetails.Append("<table style='border: solid 1px #506E87; width:100%'><tr>");

                //dtView = (DataRowView)cmbContractorNames.SelectedItem;
                if ((fiscalYearSelection != 0) && startReportDateChanged == 0 && endReportDateChanged == 0) //|| commitYearSelection != 0
                {
                    strBuildContractorDetails.Append("<td colspan='11' style='text-align:center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;'><b>PWA - TENDER AWARDED TO QATARI LOCAL COMPANIES</b></td></tr>");
                    if (fiscalYearSelection != 0 && startReportDateChanged == 0 && endReportDateChanged == 0)
                    {
                        strBuildContractorDetails.Append("<tr><td colspan='11' style='text-align: center;font-size: 12pt;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;'><b>Awarded Contracts for Fiscal Year: " + ((DataRowView)cmbFiscalYear.SelectedItem).Row.ItemArray[1].ToString() + "</b></td></tr>");
                    }
                    else
                    {
                        strBuildContractorDetails.Append("<tr><td colspan='11' style='text-align: center;font-size: 12pt;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;'><b>Awarded Contracts</b></td></tr>");
                    }
                    //strBuildContractorDetails.Append("<tr><td colspan='13' style='text-align: center;font-size: 12pt;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;' >Name of the Contractor/Vendor: <b>" + dtView.Row.ItemArray[1].ToString() + "</b></td></tr>");
                }
                else
                {
                    strBuildContractorDetails.Append("<td colspan='12' style='text-align:center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;'><b>PWA - TENDER AWARDED TO QATARI LOCAL COMPANIES</b></td></tr>");
                    strBuildContractorDetails.Append("<tr><td colspan='12' style='text-align: center;font-size: 12pt;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;'><b>Awarded Contracts</b></td></tr>");
                    //strBuildContractorDetails.Append("<tr><td colspan='14' style='text-align: center;font-size: 12pt;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;' >Name of the Contractor: <b>" + dtView.Row.ItemArray[1].ToString() + "</b></td></tr>");
                }


                strBuildContractorDetails.Append("<tr><td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>SNo.</b></td>" +
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Contract No</b></td>" +
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Project Code</b></td>" +
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Tender No.</b></td>" +
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Project Title</b></td>" +
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Company Name</b></td>" +
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Type of Contract</b></td>" +
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Date of Award</b></td>" +
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Date of Sign</b></td>" +
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Contract Amount</b></td>");

                if (startReportDateChanged == 1 || endReportDateChanged == 1)
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'" +
                    "><b>Fiscal Year</b></td>");

                strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'" +
                "><b>Department Name</b></td></tr>");

                string sqlContractDetailsQuery = null;

                //int coId = Convert.ToInt32(cmbContractorNames.SelectedValue);

                //foreach (DataRow projIds in dtProjectIds.Rows)
                //{

                if (startReportDateChanged == 1 || endReportDateChanged == 1)
                {
                    sqlContractDetailsQuery = "SELECT DISTINCT CONTRACTORS.contract_no, p.project_code,p.tender_no, Convert(varchar(max), p.project_name_en) As ProjectName, COMPANY.co_name, ct.TypeofContract, CONTRACTORS.cp_tender_award, CONTRACTORS.cp_contractor_sign, " +
                    "CONTRACTORS.ContractAmount,FiscalYear.FiscalYear,d2.Department FROM CONTRACTORS INNER JOIN COMPANY ON COMPANY.co_id = CONTRACTORS.co_id left outer JOIN ContractStatus ON ContractStatus.contract_status_id = CONTRACTORS.contract_status_id INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id " +
                    "INNER JOIN TenderDatesInfo ON CONTRACTORS.proj_id = TenderDatesInfo.proj_id INNER JOIN FiscalYear ON p.FYID = FiscalYear.FYID inner join Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id join ContractTypes ct on p.contract_type_id=ct.contract_type_id WHERE  " + //(CONTRACTORS.co_id =" + coId + ") and
                    "CONTRACTORS.cp_tender_award between '" + dtpStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpEndReportDate.Value.ToString("dd/MMM/yyyy") + "' and TenderDatesInfo.ts_tender_issue is not Null and COMPANY.co_type_id=1 and TenderDatesInfo.stage_id=2 and CONTRACTORS.cp_tender_award is not Null " + whereClause + " order by CONTRACTORS.cp_tender_award desc";
                    // "GROUP BY CONTRACTORS.contract_no, p.project_code, CONTRACTORS.ContractTitle, TenderDatesInfo.ts_tender_invitation, CONTRACTORS.ContractAmount, CONTRACTORS.StartDate, CONTRACTORS.FinishDate, CONTRACTORS.cp_tender_award, ContractStatus.ContractStatus, " +
                    // "CONTRACTORS.cp_contractor_sign,Department.Department ";
                }
                else if (fiscalYearSelection == 1) //&& commitYearSelection == 0
                {
                    //if (dtProjectIds.Rows.Count != 0)
                    //{
                    sqlContractDetailsQuery = "SELECT DISTINCT CONTRACTORS.contract_no, p.project_code,p.tender_no, Convert(varchar(max), p.project_name_en) As ProjectName, COMPANY.co_name, ct.TypeofContract, CONTRACTORS.cp_tender_award, CONTRACTORS.cp_contractor_sign, " +
                        "CONTRACTORS.ContractAmount,d2.Department FROM CONTRACTORS INNER JOIN COMPANY ON COMPANY.co_id = CONTRACTORS.co_id left outer JOIN ContractStatus ON ContractStatus.contract_status_id = CONTRACTORS.contract_status_id INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id " +
                        "INNER JOIN TenderDatesInfo ON CONTRACTORS.proj_id = TenderDatesInfo.proj_id inner join Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id join ContractTypes ct on p.contract_type_id=ct.contract_type_id WHERE " +
                        "(TenderDatesInfo.ts_tender_issue is not Null and COMPANY.co_type_id=1 and TenderDatesInfo.stage_id=2 and CONTRACTORS.cp_tender_award is not Null)" + whereClause + " order by CONTRACTORS.cp_tender_award desc";
                    //AND " + (CONTRACTORS.proj_id in (" + string.Join(",", dtProjectIds.Rows.OfType<DataRow>().Select(r => r[0].ToString())) + ")) ";// +                             CONTRACTORS.co_id =" + coId + " and
                    //}
                    //else
                    //{
                        //sqlContractDetailsQuery = "SELECT DISTINCT CONTRACTORS.contract_no, p.project_code,p.tender_no, CONTRACTORS.ContractTitle, TenderDatesInfo.ts_tender_invitation, CONTRACTORS.cp_tender_award, CONTRACTORS.cp_contractor_sign, " +
                        //"CONTRACTORS.ContractAmount, CONTRACTORS.StartDate, CONTRACTORS.FinishDate, ContractStatus.ContractStatus,d2.Department FROM CONTRACTORS INNER JOIN " +
                        //"COMPANY ON COMPANY.co_id = CONTRACTORS.co_id left outer JOIN ContractStatus ON ContractStatus.contract_status_id = CONTRACTORS.contract_status_id INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id " +
                        //"INNER JOIN TenderDatesInfo ON CONTRACTORS.proj_id = TenderDatesInfo.proj_id inner join Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id WHERE (CONTRACTORS.co_id =" + coId + ")";// +                             

                    //}
                }
                //else if (fiscalYearSelection == 0 && commitYearSelection == 1)
                //{                    
                    
                //    //if (dtProjectIds.Rows.Count != 0)
                //    //{
                //        sqlContractDetailsQuery = "SELECT DISTINCT CONTRACTORS.contract_no, p.project_code,p.tender_no, CONTRACTORS.ContractTitle, TenderDatesInfo.ts_tender_invitation, CONTRACTORS.cp_tender_award, CONTRACTORS.cp_contractor_sign, " +
                //        "CONTRACTORS.ContractAmount, CONTRACTORS.StartDate, CONTRACTORS.FinishDate, ContractStatus.ContractStatus,d2.Department FROM CONTRACTORS INNER JOIN " +
                //        "COMPANY ON COMPANY.co_id = CONTRACTORS.co_id left outer JOIN ContractStatus ON ContractStatus.contract_status_id = CONTRACTORS.contract_status_id INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id " +
                //        "INNER JOIN TenderDatesInfo ON CONTRACTORS.proj_id = TenderDatesInfo.proj_id inner join Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id WHERE (CONTRACTORS.co_id =" + coId + " and TenderDatesInfo.ts_tender_issue is not Null and TenderDatesInfo.stage_id=2)" + whereClause;
                //        //AND " +"(CONTRACTORS.proj_id in (" + string.Join(",", dtProjectIds.Rows.OfType<DataRow>().Select(r => r[0].ToString())) + ")) ";
                //    //}
                //    //else
                //    //{
                //    //    sqlContractDetailsQuery = "SELECT DISTINCT CONTRACTORS.contract_no, p.project_code,p.tender_no, CONTRACTORS.ContractTitle, TenderDatesInfo.ts_tender_invitation, CONTRACTORS.cp_tender_award, CONTRACTORS.cp_contractor_sign, " +
                //    //    "CONTRACTORS.ContractAmount, CONTRACTORS.StartDate, CONTRACTORS.FinishDate, ContractStatus.ContractStatus,d2.Department FROM CONTRACTORS INNER JOIN " +
                //    //    "COMPANY ON COMPANY.co_id = CONTRACTORS.co_id left outer JOIN ContractStatus ON ContractStatus.contract_status_id = CONTRACTORS.contract_status_id INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id " +
                //    //    "INNER JOIN TenderDatesInfo ON CONTRACTORS.proj_id = TenderDatesInfo.proj_id inner join Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id WHERE (CONTRACTORS.co_id =" + coId + ") ";
                //    //}                    
                //}

                //if (whereClause != null)
                //{
                //    if (whereClause != "")
                //    {
                //        sqlContractDetailsQuery = sqlContractDetailsQuery + " and" + whereClause;
                //    }                    
                //}

                dtContractorDetails = dalObj.GetDataFromDB("ContractDetails", sqlContractDetailsQuery);

                //bool isRecAdded = false;
                ////int rowCounterForDuplicateRows = 0;
                int totalRecords = dtContractorDetails.Rows.Count;
                if (totalRecords != 0)
                {
                    FillData(dtContractorDetails, strBuildContractorDetails, fiscalYearSelection);

                    //DataView view = new DataView(dtContractorDetails);
                    //DataTable distinctRows = view.ToTable(true, "project_code");
                    //foreach (DataRow distinctRow in distinctRows.Rows)
                    //{
                    //    DataTable dtTmpContractDetails = dtContractorDetails.Select("project_code='" + distinctRow[0] + "'").CopyToDataTable();
                    //    isRecAdded = false;
                    //    foreach (DataRow rowData in dtTmpContractDetails.Rows)
                    //    {
                    //        DataRowCollection uniqueRow = null;
                    //        //if (dtContractorDetails.Rows.Count >= 2)
                    //        //{
                    //        if (!isRecAdded)
                    //        {
                    //            if (rowData.Table.Select("ts_tender_invitation is not Null").Count() != 0)
                    //            {
                    //                uniqueRow = rowData.Table.Select("ts_tender_invitation is not Null").CopyToDataTable().Rows;
                    //            }
                    //            else
                    //            {
                    //                uniqueRow = rowData.Table.Select("ts_tender_invitation is Null").CopyToDataTable().Rows;
                    //            }

                    //            FillData(dtContractorDetails, uniqueRow, strBuildContractorDetails, fiscalYearSelection);
                    //            isRecAdded = true;
                    //            rowCounter++;
                    //        }
                    //        //else if (dtContractorDetails.Rows.Count == 1)
                    //        //{
                    //        //    uniqueRowsData = dtContractorDetails.Rows;
                    //        //}

                    //        //if (chkDuplicateRows == 1)
                    //        //{
                    //        //    if (rowCounterForDuplicateRows == 0)
                    //        //    {
                    //        //        if (uniqueRowsData != null)
                    //        //        {
                    //        //            FillData(dtContractorDetails, uniqueRow, strBuildContractorDetails, fiscalYearSelection);
                    //        //        }
                    //        //    }
                    //        //}

                    //        //chkDuplicateRows = 0;
                    //        //rowCounterForDuplicateRows = 0;
                    //    }
                    //}
                     
                    if (fiscalYearSelection != 0 && startReportDateChanged == 0 && endReportDateChanged == 0)
                    {
                        strBuildContractorDetails.Append("<tr><td colspan='11' style='width:auto;font-family: Verdana;font-size: 9pt;font-weight: bold;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>Total Contract Amount:-" + string.Format("{0:#,##0}", totalAwardedAmount) + "</td></tr>");
                        strBuildContractorDetails.Append("<tr><td colspan='11' style=\"width:auto;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b style=\"font-style: italic\">This report is generated by TCMS dated :</b><b>" + DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss") + "</b></td></tr>");
                    }
                    else
                    {
                        strBuildContractorDetails.Append("<tr><td colspan='12' style='width:auto;font-family: Verdana;font-size: 9pt;font-weight: bold;vertical-align: top;text-align: center;padding-left: 5px;padding-top: 6px;'>Total Contract Amount:-" + string.Format("{0:#,##0}", totalAwardedAmount) + "</td></tr>");
                        strBuildContractorDetails.Append("<tr><td colspan='12' style=\"width:auto;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b style=\"font-style: italic\">This report is generated by TCMS dated :</b><b>" + DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss") + "</b></td></tr>");
                    }
                    strBuildContractorDetails.Append("</table>");
                    lblTotalNoOfRecords.Text = "Total Records Count=" + totalRecords;
                     
                }
                else
                {
                    strBuildContractorDetails.Append("</table>");
                    lblTotalNoOfRecords.Text = "Total Records Count=0";
                    MessageBox.Show("No data exist for selected options", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                webReport.DocumentText = strBuildContractorDetails.ToString();
                webReport.ScrollBarsEnabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while retrieving the information of the contractor");
            }
        }

        double totalAwardedAmount = 0.0;
        private void FillData(DataTable dtContractorDetails, StringBuilder strBuildContractorDetails, int fiscalYearSelection)
        {
            totalAwardedAmount = 0.0;
            foreach (DataRow rowData in dtContractorDetails.Rows)
            {
                strBuildContractorDetails.Append("<tr><td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + ++rowCounter + "</td>");
                strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[0] + "</td>");
                if (rowData[1] != DBNull.Value)
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[1] + "</td>");
                else
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'></td>");
                if (rowData[2] != DBNull.Value)
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[2] + "</td>");
                else
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'></td>");
                if (rowData[3] != DBNull.Value)
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[3] + "</td>");
                else
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'></td>");
                strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[4] + "</td>");
                if (rowData[5] != DBNull.Value)
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[5] + "</td>");
                else
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'></td>");
                if (rowData[6] != DBNull.Value)
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + Convert.ToDateTime(rowData[6]).ToString("dd/MMM/yyyy") + "</td>");
                else
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'></td>");
                if (rowData[7] != DBNull.Value)
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + Convert.ToDateTime(rowData[7]).ToString("dd/MMM/yyyy") + "</td>");
                else
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'></td>");
                if (rowData[8] != DBNull.Value)
                {
                    double contractAmount = double.Parse(rowData[8].ToString());
                    totalAwardedAmount = totalAwardedAmount + Convert.ToDouble(string.Format("{0:#,##0}", contractAmount));
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + string.Format("{0:#,##0}", contractAmount) + "</td>");
                }
                else
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'></td>");
                //if (rowData[9] != DBNull.Value)
                //    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + Convert.ToDateTime(rowData[9]).ToString("dd/MMM/yyyy") + "</td>");
                //else
                //    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'></td>");
                //if (rowData[10] != DBNull.Value)
                //    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + Convert.ToDateTime(rowData[10]).ToString("dd/MMM/yyyy") + "</td>");
                //else
                //    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'></td>");
                //if (rowData[11] != DBNull.Value)
                //    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[11].ToString() + "</td>");
                //else
                //    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'></td>");


                if (dtContractorDetails.Columns.Count == 11 && fiscalYearSelection == 0)
                {
                    if (rowData[9] != DBNull.Value)
                    {
                        strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[9].ToString() + "</td>");
                    }

                    if (rowData[10] != DBNull.Value)
                    {
                        strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[10].ToString() + "</td>");
                    }
                }
                else
                {
                    if (rowData[9] != DBNull.Value)
                    {
                        strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[9].ToString() + "</td>");
                    }
                }
                // Commented by Sree ---- Should Open

                //if (fyId == 0)
                //    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + projIds[1] + "</td>");                                                                
                strBuildContractorDetails.Append("</tr>");                
                
                //if (chkDuplicateRows == 1)
                //{
                //    rowCounterForDuplicateRows++;
                //}
            }
            
        }

        private void cmbCommitmentYear_SelectedIndexChanged(object sender, EventArgs e)
        {
            startReportDateChanged = 0;
            endReportDateChanged = 0;
            fiscalYearSelection = 0;
            commitYearSelection = 1;            
        }
       
    }

 
}
