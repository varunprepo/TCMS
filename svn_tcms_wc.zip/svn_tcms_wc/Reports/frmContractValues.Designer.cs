﻿namespace MDI_ParenrForm.Reports
{
    partial class frmContractValues
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCntrMinVal = new System.Windows.Forms.TextBox();
            this.txtCntrMaxVal = new System.Windows.Forms.TextBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.webReport = new System.Windows.Forms.WebBrowser();
            this.lblTotRecCount = new System.Windows.Forms.Label();
            this.cmbFiscalyear = new System.Windows.Forms.ComboBox();
            this.btnExportToExcel = new System.Windows.Forms.Button();
            this.cmbCommittee = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(49, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Min Value";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(173, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Max Value";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(298, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Fiscal Year";
            // 
            // txtCntrMinVal
            // 
            this.txtCntrMinVal.Location = new System.Drawing.Point(43, 67);
            this.txtCntrMinVal.Name = "txtCntrMinVal";
            this.txtCntrMinVal.Size = new System.Drawing.Size(100, 20);
            this.txtCntrMinVal.TabIndex = 3;
            // 
            // txtCntrMaxVal
            // 
            this.txtCntrMaxVal.Location = new System.Drawing.Point(176, 67);
            this.txtCntrMaxVal.Name = "txtCntrMaxVal";
            this.txtCntrMaxVal.Size = new System.Drawing.Size(100, 20);
            this.txtCntrMaxVal.TabIndex = 4;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(583, 65);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 23);
            this.btnSubmit.TabIndex = 6;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // webReport
            // 
            this.webReport.Location = new System.Drawing.Point(43, 121);
            this.webReport.MinimumSize = new System.Drawing.Size(20, 20);
            this.webReport.Name = "webReport";
            this.webReport.Size = new System.Drawing.Size(906, 430);
            this.webReport.TabIndex = 19;
            // 
            // lblTotRecCount
            // 
            this.lblTotRecCount.AutoSize = true;
            this.lblTotRecCount.Location = new System.Drawing.Point(765, 97);
            this.lblTotRecCount.Name = "lblTotRecCount";
            this.lblTotRecCount.Size = new System.Drawing.Size(0, 13);
            this.lblTotRecCount.TabIndex = 20;
            // 
            // cmbFiscalyear
            // 
            this.cmbFiscalyear.FormattingEnabled = true;
            this.cmbFiscalyear.Location = new System.Drawing.Point(301, 67);
            this.cmbFiscalyear.Name = "cmbFiscalyear";
            this.cmbFiscalyear.Size = new System.Drawing.Size(84, 21);
            this.cmbFiscalyear.TabIndex = 34;
            // 
            // btnExportToExcel
            // 
            this.btnExportToExcel.BackColor = System.Drawing.Color.Coral;
            this.btnExportToExcel.Location = new System.Drawing.Point(678, 65);
            this.btnExportToExcel.Name = "btnExportToExcel";
            this.btnExportToExcel.Size = new System.Drawing.Size(98, 23);
            this.btnExportToExcel.TabIndex = 35;
            this.btnExportToExcel.Text = "Export To Excel";
            this.btnExportToExcel.UseVisualStyleBackColor = false;
            this.btnExportToExcel.Click += new System.EventHandler(this.btnExportToExcel_Click);
            // 
            // cmbCommittee
            // 
            this.cmbCommittee.FormattingEnabled = true;
            this.cmbCommittee.Location = new System.Drawing.Point(416, 65);
            this.cmbCommittee.Name = "cmbCommittee";
            this.cmbCommittee.Size = new System.Drawing.Size(121, 21);
            this.cmbCommittee.TabIndex = 36;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(413, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 13);
            this.label4.TabIndex = 37;
            this.label4.Text = "Committee";
            // 
            // frmContractValues
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(986, 632);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cmbCommittee);
            this.Controls.Add(this.btnExportToExcel);
            this.Controls.Add(this.cmbFiscalyear);
            this.Controls.Add(this.lblTotRecCount);
            this.Controls.Add(this.webReport);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.txtCntrMaxVal);
            this.Controls.Add(this.txtCntrMinVal);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmContractValues";
            this.Text = "Contract Values";
            this.Load += new System.EventHandler(this.frmContractValues_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtCntrMinVal;
        private System.Windows.Forms.TextBox txtCntrMaxVal;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.WebBrowser webReport;
        private System.Windows.Forms.Label lblTotRecCount;
        private System.Windows.Forms.ComboBox cmbFiscalyear;
        private System.Windows.Forms.Button btnExportToExcel;
        private System.Windows.Forms.ComboBox cmbCommittee;
        private System.Windows.Forms.Label label4;
    }
}