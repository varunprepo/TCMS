﻿namespace MDI_ParenrForm.Reports
{
    partial class frmTenderingRecords
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.webReport = new System.Windows.Forms.WebBrowser();
            this.btnExportToExcel = new System.Windows.Forms.Button();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.dtpStartReportDate = new System.Windows.Forms.DateTimePicker();
            this.dtpEndReportDate = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblTotRecords = new System.Windows.Forms.Label();
            this.txtStartReportDate = new System.Windows.Forms.TextBox();
            this.txtEndReportDate = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // webReport
            // 
            this.webReport.Location = new System.Drawing.Point(3, 129);
            this.webReport.MinimumSize = new System.Drawing.Size(20, 20);
            this.webReport.Name = "webReport";
            this.webReport.Size = new System.Drawing.Size(1310, 408);
            this.webReport.TabIndex = 20;
            // 
            // btnExportToExcel
            // 
            this.btnExportToExcel.BackColor = System.Drawing.Color.Coral;
            this.btnExportToExcel.Location = new System.Drawing.Point(684, 66);
            this.btnExportToExcel.Name = "btnExportToExcel";
            this.btnExportToExcel.Size = new System.Drawing.Size(98, 23);
            this.btnExportToExcel.TabIndex = 37;
            this.btnExportToExcel.Text = "Export To Excel";
            this.btnExportToExcel.UseVisualStyleBackColor = false;
            this.btnExportToExcel.Click += new System.EventHandler(this.btnExportToExcel_Click);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(589, 66);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 23);
            this.btnSubmit.TabIndex = 36;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // dtpStartReportDate
            // 
            this.dtpStartReportDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpStartReportDate.Location = new System.Drawing.Point(108, 69);
            this.dtpStartReportDate.Name = "dtpStartReportDate";
            this.dtpStartReportDate.Size = new System.Drawing.Size(103, 20);
            this.dtpStartReportDate.TabIndex = 46;
            this.dtpStartReportDate.ValueChanged += new System.EventHandler(this.dtpStartReportDate_ValueChanged);
            // 
            // dtpEndReportDate
            // 
            this.dtpEndReportDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpEndReportDate.Location = new System.Drawing.Point(370, 69);
            this.dtpEndReportDate.Name = "dtpEndReportDate";
            this.dtpEndReportDate.Size = new System.Drawing.Size(103, 20);
            this.dtpEndReportDate.TabIndex = 47;
            this.dtpEndReportDate.ValueChanged += new System.EventHandler(this.dtpEndReportDate_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(50, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 48;
            this.label1.Text = "Start Date";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(315, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 49;
            this.label2.Text = "End Date";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(565, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(222, 25);
            this.label3.TabIndex = 50;
            this.label3.Text = "Project Stages Report";
            // 
            // lblTotRecords
            // 
            this.lblTotRecords.AutoSize = true;
            this.lblTotRecords.Location = new System.Drawing.Point(53, 549);
            this.lblTotRecords.Name = "lblTotRecords";
            this.lblTotRecords.Size = new System.Drawing.Size(77, 13);
            this.lblTotRecords.TabIndex = 51;
            this.lblTotRecords.Text = "Total Records ";
            this.lblTotRecords.Visible = false;
            // 
            // txtStartReportDate
            // 
            this.txtStartReportDate.Location = new System.Drawing.Point(108, 68);
            this.txtStartReportDate.Name = "txtStartReportDate";
            this.txtStartReportDate.Size = new System.Drawing.Size(69, 20);
            this.txtStartReportDate.TabIndex = 52;
            // 
            // txtEndReportDate
            // 
            this.txtEndReportDate.Location = new System.Drawing.Point(370, 68);
            this.txtEndReportDate.Name = "txtEndReportDate";
            this.txtEndReportDate.Size = new System.Drawing.Size(69, 20);
            this.txtEndReportDate.TabIndex = 53;
            // 
            // frmTenderingRecords
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1316, 574);
            this.Controls.Add(this.txtEndReportDate);
            this.Controls.Add(this.txtStartReportDate);
            this.Controls.Add(this.lblTotRecords);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtpStartReportDate);
            this.Controls.Add(this.dtpEndReportDate);
            this.Controls.Add(this.btnExportToExcel);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.webReport);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmTenderingRecords";
            this.Text = "Project Stages Report";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.WebBrowser webReport;
        private System.Windows.Forms.Button btnExportToExcel;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.DateTimePicker dtpStartReportDate;
        private System.Windows.Forms.DateTimePicker dtpEndReportDate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblTotRecords;
        private System.Windows.Forms.TextBox txtStartReportDate;
        private System.Windows.Forms.TextBox txtEndReportDate;
    }
}