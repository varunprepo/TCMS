﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TenderTrackingSystem;
using System.IO;
using System.Text.RegularExpressions;

namespace MDI_ParenrForm.Reports
{
    public partial class frmGenerateBiddersReports : Form
    {
        StringBuilder strBuildObj = null;
        DAL dalObj = null;
        public frmGenerateBiddersReports()
        {
            InitializeComponent();
            dalObj = new DAL();
            dalObj.populateCmbBox("select FYID,FiscalYear from FiscalYear", cmbFiscalYear);            
            createReport(-1,"");           
        }

        private void createReport(int paramPercentage, string strParamFiscalYear)
        {
            try
            {
                dalObj = new DAL();
                DataTable dtObj = null;
                if (strParamFiscalYear != "" && paramPercentage != -1)
                {
                    dtObj = dalObj.GetDataFromDB("BiddersShareHolding", "SELECT DISTINCT COMPANY.co_name, COMPANY.qatari_share,(100 - COMPANY.qatari_share) as [Others_Share] " +
                    "FROM COMPANY INNER JOIN TenderDatesInfo ON COMPANY.co_id = TenderDatesInfo.co_id INNER JOIN " +
                    "PROJECTS ON PROJECTS.proj_id = TenderDatesInfo.proj_id INNER JOIN FiscalYear ON PROJECTS.FYID = FiscalYear.FYID INNER JOIN COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id " +
                    "WHERE (COMPANY.qatari_share=" + paramPercentage + " and FiscalYear.FiscalYear ='" + strParamFiscalYear + "' and COMPANY_CAT.co_category_name<>'Owner')");
                }
                else if (strParamFiscalYear != "")
                {
                    dtObj = dalObj.GetDataFromDB("BiddersShareHolding", "SELECT DISTINCT COMPANY.co_name, COMPANY.qatari_share,(100 - COMPANY.qatari_share) as [Others_Share] " +
                    "FROM COMPANY INNER JOIN TenderDatesInfo ON COMPANY.co_id = TenderDatesInfo.co_id INNER JOIN " +
                    "PROJECTS ON PROJECTS.proj_id = TenderDatesInfo.proj_id INNER JOIN FiscalYear ON PROJECTS.FYID = FiscalYear.FYID INNER JOIN COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id " +
                    "WHERE (FiscalYear.FiscalYear ='" + strParamFiscalYear + "') and COMPANY_CAT.co_category_name<>'Owner'");
                }
                else if (paramPercentage != -1)
                {
                    dtObj = dalObj.GetDataFromDB("BiddersShareHolding", "SELECT DISTINCT COMPANY.co_name, COMPANY.qatari_share,(100 - COMPANY.qatari_share) as [Others_Share] " +
                    "FROM COMPANY INNER JOIN TenderDatesInfo ON COMPANY.co_id = TenderDatesInfo.co_id INNER JOIN " +
                    "PROJECTS ON PROJECTS.proj_id = TenderDatesInfo.proj_id INNER JOIN FiscalYear ON PROJECTS.FYID = FiscalYear.FYID INNER JOIN COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id " +
                    "WHERE COMPANY.qatari_share=" + paramPercentage + " and COMPANY_CAT.co_category_name<>'Owner'");
                }
                else
                {
                    dtObj = dalObj.GetDataFromDB("BiddersShareHolding", "SELECT DISTINCT COMPANY.co_name, COMPANY.qatari_share,(100 - COMPANY.qatari_share) as [Others_Share] " +
                    "FROM COMPANY INNER JOIN TenderDatesInfo ON COMPANY.co_id = TenderDatesInfo.co_id INNER JOIN " +
                    "PROJECTS ON PROJECTS.proj_id = TenderDatesInfo.proj_id INNER JOIN FiscalYear ON PROJECTS.FYID = FiscalYear.FYID INNER JOIN COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id " +
                    "where COMPANY_CAT.co_category_name<>'Owner'"); 
                }
                strBuildObj = new StringBuilder();
                strBuildObj.Append("<table width='100%' cellpadding='0' cellspacing='0' style='border: solid 1px;'> <tr><td colspan='2' style='text-align:center;height: 35px;font-size: 14pt ;font-weight:bold;");
                strBuildObj.Append(" vertical-align:middle;border: solid 1px;background-color:#C0D9AF'><b>FISCAL YEAR " + strParamFiscalYear + "</b></td></tr><tr><td style='border-style: solid; border-color: inherit; border-width: 1px; text-align:center;");
                strBuildObj.Append("font-size: 14pt; font-weight:bold; vertical-align:middle; background-color:#63D1F4'><b>Company Name</b></td><td style='margin: 0px; text-align:center;height: 35px; font-size: 14pt;");
                strBuildObj.Append("font-weight:bold; vertical-align:middle; border: solid 1px; background-color:#FFFF00; overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Shareholding as per CR (%)</b>");
                strBuildObj.Append("<table> <tr><td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 14pt; font-weight:bold; vertical-align:middle; border:1; background-color:#ADD8E6; width: 320px;'><b>Qatari (%)</b></td>");
                strBuildObj.Append("<td style='padding: inherit; margin: inherit; text-align:center; height: 40px; font-size: 14pt; font-weight:bold; vertical-align:middle; border:1; background-color:#ADD8E6; width: 320px;'><b>Others (%)</b></td></tr></table></td></tr>");
                int totRecords = dtObj.Rows.Count;
                lblCmpCount.Text = ""; 
                lblCmpCount.Text = "Total Filtered Companies are " + totRecords;
                Int16 rowCounter = 0;
                while (rowCounter < totRecords)
                {
                    strBuildObj.Append("<tr><td style='border-style: solid; border-color: inherit; border-width: 1px; text-align:center;font-size: 12pt; vertical-align:middle;background-color:#63D1F4'>" + dtObj.Rows[rowCounter][0].ToString() + "</td><td><table><tr>");
                    if (dtObj.Rows[rowCounter][1].ToString().Length == 1)
                        strBuildObj.Append("<td style='padding:inherit; margin: inherit;border-style: solid; border-width: 1px; text-align:center; height: 40px; font-size: 12pt; vertical-align:middle; background-color:#ADD8E6; width: 309px;'>" + dtObj.Rows[rowCounter][1].ToString() + "</td>");
                    else
                        strBuildObj.Append("<td style='padding:inherit; margin: inherit;border-style: solid; border-width: 1px; text-align:center; height: 40px; font-size: 12pt; vertical-align:middle; background-color:#ADD8E6; width: 300px;'>" + dtObj.Rows[rowCounter][1].ToString() + "</td>");
                    if (dtObj.Rows[rowCounter][2].ToString().Length == 1)
                        strBuildObj.Append("<td style='padding:inherit;margin: inherit;border-style: solid; border-width: 1px; text-align:center; height: 40px; font-size: 12pt; vertical-align:middle; background-color:#ADD8E6; width: 309px;'>" + dtObj.Rows[rowCounter][2].ToString() + "</td>");
                    else
                        strBuildObj.Append("<td style='padding: inherit;margin: inherit;border-style: solid; border-width: 1px; text-align:center; height: 40px; font-size: 12pt; vertical-align:middle; background-color:#ADD8E6; width: 300px;'>" + dtObj.Rows[rowCounter][2].ToString() + "</td>");
                    strBuildObj.Append("</tr></table></td></tr>");
                    rowCounter++;
                }
                strBuildObj.Append("<tr><td colspan='2' style=\"width:auto;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b style=\"font-style: italic\">This report is generated by TCMS dated :</b><b>" + DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss") + "</b></td></tr>");
                strBuildObj.Append("</table>");
                wbReport.DocumentText = strBuildObj.ToString();
                wbReport.ScrollBarsEnabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while creating the report", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void cmbFiscalYear_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (txtPercentage.Text != "")
            {
                if (IsItNumber(txtPercentage.Text))
                    createReport(Convert.ToInt32(txtPercentage.Text), ((DataRowView)cmbFiscalYear.SelectedItem).Row.ItemArray[1].ToString());
                else
                {
                    MessageBox.Show("Please enter only numeric characters", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtPercentage.Focus();
                }
            }
            else
                createReport(-1, ((DataRowView)cmbFiscalYear.SelectedItem).Row.ItemArray[1].ToString());            
        }

        private void btnExportToExcel_Click(object sender, EventArgs e)
        {
            //if (userRightsColl.Contains("32"))    //      * Assign Tender No.
            //{
            //    MessageBox.Show("You have no privilege,Contact administrator");
            //    return;
            //}

            try
            {
                DialogResult result = saveFileDialog1.ShowDialog();
                //string strFileName = "ExportExcel.xls";
                //saveFileDialog1.FileName = "ExportExcel.xls";
                string strFileName = saveFileDialog1.FileName.ToString();
                StreamWriter writer = new StreamWriter(strFileName);
                writer.Write(wbReport.DocumentText.ToString());
                writer.Close();
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
        }

        private void txtPercentage_TextChanged(object sender, EventArgs e)
        {
            if (IsItNumber(txtPercentage.Text) && cmbFiscalYear.SelectedItem != null)
            {
                if (txtPercentage.Text != "")
                    createReport(Convert.ToInt32(txtPercentage.Text), cmbFiscalYear.SelectedItem.ToString());                 
            }
            else if (cmbFiscalYear.SelectedItem == null && IsItNumber(txtPercentage.Text))
            {
                if (txtPercentage.Text != "")
                    createReport(Convert.ToInt32(txtPercentage.Text), "");                
            }
            else if (cmbFiscalYear.SelectedItem != null)
                createReport(-1, cmbFiscalYear.SelectedItem.ToString());            
        }

        public bool IsItNumber(string inputvalue)
        {
            Regex isnumber = new Regex("[^0-9]");
            return !isnumber.IsMatch(inputvalue);

        }

        private void btnRefreshCmp_Click(object sender, EventArgs e)
        {
            txtPercentage.Text = "";
            cmbFiscalYear.SelectedIndex = -1;
            createReport(-1, "");     

        }     

        private bool nonNumberEntered = false;
        private void txtPercentage_KeyDown(object sender, KeyEventArgs e)
        {
            nonNumberEntered = false;
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            {
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    if ((e.KeyCode != Keys.Back) & (e.KeyCode != Keys.Enter))
                    {
                        nonNumberEntered = true;
                    }
                }
            }
        }

        private void txtPercentage_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (nonNumberEntered == true)
            {
                MessageBox.Show("Please enter number only...");
                e.Handled = true;
            }
        }       

     }       
}

