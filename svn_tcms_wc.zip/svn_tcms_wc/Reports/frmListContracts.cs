﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TenderTrackingSystem;
using System.Data.SqlClient;
using System.Configuration;

namespace MDI_ParenrForm.Reports
{
    public partial class frmListContracts : Form
    {
        DAL dalObj = null;
        CommonClass comCls = null;
        IList<string> mUserRightsCollComm = null;
        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();

        public frmListContracts(IList<string> userRightsCollComm)
        {
            InitializeComponent();
            dalObj = new DAL();
            comCls = new CommonClass("");
            mUserRightsCollComm = userRightsCollComm;
            FillWithFiscalYears();
            cmbContractNoType.SelectedIndex = cmbContractNoType.FindStringExact("All");
            //FillContractTypes();
        }

        private void FillWithFiscalYears()
        {
            SqlConnection sqlConn = new SqlConnection(strCon);
            try
            {
                DataTable dtCalendarYear = null;
                sqlConn.Open();
                DAL dalObj = new DAL();
                string sqlQuery = "SELECT FYID,[FiscalYear] FROM [FiscalYear] ORDER BY [FiscalYear] ASC";
                dtCalendarYear = dalObj.GetDataFromDB("FiscalYears", sqlQuery);
                DataRow row = dtCalendarYear.NewRow();
                row["FiscalYear"] = "All";
                row["FYID"] = 0;
                dtCalendarYear.Rows.Add(row);
                cmbFiscalyear.DataSource = dtCalendarYear;
                cmbFiscalyear.DisplayMember = "FiscalYear";
                cmbFiscalyear.ValueMember = "FYID";
                cmbFiscalyear.SelectedIndex = cmbFiscalyear.FindStringExact("All");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred filling the Fiscal Year field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlConn.Close();
            }
        }

        private void FillContractTypes()
        {
            SqlConnection sqlConn = new SqlConnection(strCon);
            try
            {
                //SqlCommand sqlCom;
                //SqlDataReader sqlReader;
                DataTable dtContracts = null;
                sqlConn.Open();
                DAL dalObj = new DAL();
                string sqlQuery = "SELECT contract_type_id,[TypeofContract] FROM [ContractTypes] ORDER BY [ContractTypes].[TypeofContract] ASC";
                dtContracts = dalObj.GetDataFromDB("ContractsInfo", sqlQuery);
                DataRow row = dtContracts.NewRow();
                row["TypeofContract"] = "All";
                row["contract_type_id"] = 0;
                dtContracts.Rows.Add(row);
                cmbContractNoType.DataSource = dtContracts;
                cmbContractNoType.DisplayMember = "TypeofContract";
                cmbContractNoType.ValueMember = "contract_type_id";
                cmbContractNoType.SelectedIndex = cmbContractNoType.FindStringExact("All");
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }
        }

        private void btnGenerateListOfContracts_Click(object sender, EventArgs e)
        {
            SearchContractNo();        
        }

        private StringBuilder CreateListOfContractsReport(StringBuilder strBuilder, DataTable dtReports)
        {
            strBuilder.Append("<table width='100%' cellpadding='0' cellspacing='0' style='border: solid 1px;'><tr>");

            strBuilder.Append("<td colspan='16' style='font-family:Century Gothic;text-align:center;height: 35px;font-size: 11pt;vertical-align:middle;border: solid 1px;background-color:#C0D9AF';><b>CONTRACTS LIST</b></td></tr>");
            //strBuilder.Append("<tr><td colspan='10' style='text-align: center;font-size: 12pt;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;'><b>Awarded Contracts for Fiscal Year: " + dtProjectIds.Rows[0][1] + "</b></td></tr>");
            //strBuilder.Append("<tr><td colspan='10' style='text-align: center;font-size: 12pt;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;' >Name of the Contractor/Vendor: <b>" + dtView.Row.ItemArray[1].ToString() + "</b></td></tr>");

            strBuilder.Append("<tr>" +
            "<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>SNo.</b></td>" +
            "<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Project Code</b></td>" +
            "<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Project Title</b></td>" +
            "<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Tender Number</b></td>" +
            "<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Tender Issue Date</b></td>" +
            "<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Tender Closing Date</b></td>");
            if (!(contractNoType.Equals("Framework") || contractNoType.Equals("WorkOrder") || contractNoType.Equals("All")))
            {
                strBuilder.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>WorkOrder Tender Estimate</b></td>");
            }
            else
            {
                strBuilder.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Estimated Cost</b></td>");
            }

            strBuilder.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Tender Award Date</b></td>" +
            "<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Successful Tenderer</b></td>" +
            "<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Value of Contract</b></td>" +
            "<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Notice sent to Tenderer to Sign Contract</b></td>" +
            "<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>NoticeDate of Sign Contract</b></td>" +
            "<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Distribution</b></td>" +
            "<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Contract Number</b></td>" +
            "<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Department Name</b></td>" +
            "<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Nationality</b></td></tr>");

            //foreach (DataRow projIds in dtReports.Rows)
            //{

            //string sqlContractDetailsQuery = "SELECT DISTINCT CONTRACTORS.contract_no, PROJECTS.project_code, CONTRACTORS.ContractTitle, TenderDatesInfo.ts_tender_invitation, CONTRACTORS.cp_tender_award, CONTRACTORS.cp_contractor_sign, " +
            //"CONTRACTORS.ContractAmount, CONTRACTORS.StartDate, CONTRACTORS.FinishDate, ContractStatus.ContractStatus FROM CONTRACTORS INNER JOIN " +
            //"COMPANY ON COMPANY.co_id = CONTRACTORS.co_id INNER JOIN ContractStatus ON ContractStatus.contract_status_id = CONTRACTORS.contract_status_id INNER JOIN PROJECTS ON CONTRACTORS.proj_id = PROJECTS.proj_id " +
            //"INNER JOIN TenderDatesInfo ON CONTRACTORS.proj_id = TenderDatesInfo.proj_id WHERE (CONTRACTORS.co_id =" + coId + ") AND (CONTRACTORS.proj_id =" + projIds[0] + ") AND (CONTRACTORS.contract_no IS NOT NULL) AND (CONTRACTORS.contract_no <> ' ') " +
            //"GROUP BY CONTRACTORS.contract_no, PROJECTS.project_code, CONTRACTORS.ContractTitle, TenderDatesInfo.ts_tender_invitation, CONTRACTORS.ContractAmount, CONTRACTORS.StartDate, CONTRACTORS.FinishDate, CONTRACTORS.cp_tender_award, ContractStatus.ContractStatus, " +
            //"CONTRACTORS.cp_contractor_sign";

            //DataTable dtContractorDetails = dalObj.GetDataFromDB("ContractDetails", sqlContractDetailsQuery);
            int rowSNo = 0;
            if (dtReports.Rows.Count != 0)
            {
                foreach (DataRow colData in dtReports.Rows)
                {
                    strBuilder.Append("<tr>");
                    strBuilder.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + ++rowSNo + "</td>");
                    strBuilder.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + colData[0] + "</td>");
                    strBuilder.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + colData[1] + "</td>");
                    strBuilder.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + colData[2] + "</td>");

                    if (colData[3] != DBNull.Value)
                        strBuilder.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + colData[3].ToString().Split(' ')[0] + "</td>");
                    else
                        strBuilder.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'></td>");

                    if (colData[4] != DBNull.Value)
                        strBuilder.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + colData[4].ToString().Split(' ')[0] + "</td>");
                    else
                        strBuilder.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'></td>");

                    if (colData[5] != DBNull.Value)
                        strBuilder.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + string.Format("{0:#,##0.00}", colData[5]) + "</td>");
                    else
                        strBuilder.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'></td>");

                    if (colData[6] != DBNull.Value)
                        strBuilder.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + colData[6].ToString().Split(' ')[0] + "</td>");
                    else
                        strBuilder.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'></td>");

                    strBuilder.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + colData[7] + "</td>");

                    if (colData[8] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + string.Format("{0:#,##0.00}", colData[8]) + "</td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'></td>");
                    }
                     
                    if (colData[9] != DBNull.Value)
                        strBuilder.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + colData[9].ToString().Split(' ')[0] + "</td>");
                    else
                        strBuilder.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'></td>");

                    if (colData[10] != DBNull.Value)
                        strBuilder.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + colData[10].ToString().Split(' ')[0] + "</td>");
                    else
                        strBuilder.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b></b></td>");

                    if (colData[11] != DBNull.Value)
                        strBuilder.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + colData[11].ToString().Split(' ')[0] + "</td>");
                    else
                        strBuilder.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'></td>");

                    strBuilder.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + colData[12] + "</td>");
                    strBuilder.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + colData[13] + "</td>");
                    strBuilder.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + colData[14] + "</td>");                     
                    strBuilder.Append("</tr>");
                }
                strBuilder.Append("<tr><td colspan='16' style=\"width:auto;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b style=\"font-style: italic\">This report is generated by TCMS dated :</b><b>" + DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss") + "</b></td></tr>");
                strBuilder.Append("</table>");
            }
            else
            {
                MessageBox.Show("No data exist for selected option", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                strBuilder.Append("</table>");
            }
            //dtContractorDetails.Rows.Clear();
            return strBuilder;
        }

        private void btnExportToExcel_Click(object sender, EventArgs e)
        {
            comCls.ExportToExcel(webReport);
        }

        string contractNoType = null;
        private void SearchContractNo()
        {
            try
            {
                //if (txtContractNumber.Text.Trim()!="" || txtNationality.Text.Trim() != "")
                //{

                string sqlListOfContractsQuery = null;
                string contractNo = null;
                string nationality = null;
                string fyID = null;                

                if (txtContractNumber.Text.Trim() != "")
                {
                    contractNo = txtContractNumber.Text.Trim();
                }    
                else
                {
                    contractNo = "";
                }

                if (txtNationality.Text.Trim() != "")
                {
                    nationality = txtNationality.Text.Trim();
                }
                else
                {
                    nationality = "";
                }

                if (cmbFiscalyear.Text.Trim() != "")
                {
                    if (!cmbFiscalyear.Text.Trim().Equals("All"))
                    {
                        fyID = cmbFiscalyear.SelectedValue.ToString();
                    }
                    else
                    {
                        fyID = "select FYID from FiscalYear";
                    }
                }
                 

                if (cmbContractNoType.Text.Trim() != "")
                {
                    if (!cmbContractNoType.Text.Trim().Equals("All"))
                    {
                        contractNoType = cmbContractNoType.Text;
                    }
                    else
                    {
                        contractNoType = "All";
                    }
                }
                
                //INNER JOIN ContractTypes ON PROJECTS.contract_type_id = ContractTypes.contract_type_id

                if (!(contractNoType.Equals("Framework") || contractNoType.Equals("WorkOrder") || contractNoType.Equals("All")))
                {
                    sqlListOfContractsQuery = "SELECT PROJECTS.project_code, PROJECTS.project_newname_en, PROJECTS.tender_no, TenderDatesInfo.ts_tender_issue, TenderDatesInfo.ts_closing_s1, CONTRACTORS.WOTenderEstimate, CONTRACTORS.cp_tender_award, " +
                    "COMPANY.co_name, CONTRACTORS.ContractAmount, CONTRACTORS.cp_notice_contractor_to_sign, CONTRACTORS.cp_contractor_sign, CONTRACTORS.cp_distribution, CONTRACTORS.contract_no, d2.Department, COMPANY.nationality " +
                    "FROM PROJECTS INNER JOIN CONTRACTORS ON PROJECTS.proj_id = CONTRACTORS.proj_id join Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id INNER JOIN TenderDatesInfo ON PROJECTS.proj_id = TenderDatesInfo.proj_id INNER JOIN " +
                    "COMPANY ON CONTRACTORS.co_id = COMPANY.co_id AND TenderDatesInfo.co_id = COMPANY.co_id INNER JOIN FiscalYear ON PROJECTS.FYID=FiscalYear.FYID WHERE (COMPANY.nationality like '%" + nationality + "%' " +
                    " or COMPANY.nationality is Null) and (CONTRACTORS.contract_no like '%" + contractNo + "%' or CONTRACTORS.contract_no is Null) and (FiscalYear.FYID IN (" + fyID + ") or FiscalYear.FYID is Null) " +
                    "and CONTRACTORS.contract_no like '%" + contractNoType + "%' order by CONTRACTORS.contract_no";
                }
                else if (!(contractNoType.Equals("All")))
                {
                    sqlListOfContractsQuery = "SELECT PROJECTS.project_code, PROJECTS.project_newname_en, PROJECTS.tender_no, TenderDatesInfo.ts_tender_issue, TenderDatesInfo.ts_closing_s1, ProjectCost.estimated_cost, CONTRACTORS.cp_tender_award, " +
                    "COMPANY.co_name, CONTRACTORS.ContractAmount, CONTRACTORS.cp_notice_contractor_to_sign, CONTRACTORS.cp_contractor_sign, CONTRACTORS.cp_distribution, CONTRACTORS.contract_no, d2.Department, COMPANY.nationality " +
                    "FROM PROJECTS INNER JOIN CONTRACTORS ON PROJECTS.proj_id = CONTRACTORS.proj_id INNER join Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id INNER JOIN TenderDatesInfo ON PROJECTS.proj_id = TenderDatesInfo.proj_id INNER JOIN " +
                    "COMPANY ON CONTRACTORS.co_id = COMPANY.co_id AND TenderDatesInfo.co_id = COMPANY.co_id INNER JOIN FiscalYear ON PROJECTS.FYID=FiscalYear.FYID INNER JOIN ProjectCost ON PROJECTS.proj_id = ProjectCost.proj_id WHERE (COMPANY.nationality like '%" + nationality + "%' " +
                    " or COMPANY.nationality is Null) and (CONTRACTORS.contract_no like '%" + contractNo + "%' or CONTRACTORS.contract_no is Null) and (FiscalYear.FYID IN (" + fyID + ") or FiscalYear.FYID is Null) and CONTRACTORS.contract_no like '%" + contractNoType + "%' "+
                    "order by CONTRACTORS.contract_no";
                }
                else
                {
                    sqlListOfContractsQuery = "SELECT PROJECTS.project_code, PROJECTS.project_newname_en, PROJECTS.tender_no, TenderDatesInfo.ts_tender_issue, TenderDatesInfo.ts_closing_s1, ProjectCost.estimated_cost, CONTRACTORS.cp_tender_award, " +
                    "COMPANY.co_name, CONTRACTORS.ContractAmount, CONTRACTORS.cp_notice_contractor_to_sign, CONTRACTORS.cp_contractor_sign, CONTRACTORS.cp_distribution, CONTRACTORS.contract_no, d2.Department, COMPANY.nationality " +
                    "FROM PROJECTS INNER JOIN CONTRACTORS ON PROJECTS.proj_id = CONTRACTORS.proj_id INNER join Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id INNER JOIN TenderDatesInfo ON PROJECTS.proj_id = TenderDatesInfo.proj_id INNER JOIN " +
                    "COMPANY ON CONTRACTORS.co_id = COMPANY.co_id AND TenderDatesInfo.co_id = COMPANY.co_id INNER JOIN FiscalYear ON PROJECTS.FYID=FiscalYear.FYID INNER JOIN ProjectCost ON PROJECTS.proj_id = ProjectCost.proj_id WHERE (COMPANY.nationality like '%" + nationality + "%' " +
                    " or COMPANY.nationality is Null) and (CONTRACTORS.contract_no like '%" + contractNo + "%' or CONTRACTORS.contract_no is Null) and (FiscalYear.FYID IN (" + fyID + ") or FiscalYear.FYID is Null) order by CONTRACTORS.contract_no";
                }



                //if (txtContractNumber.Text.Trim() != "" && txtNationality.Text.Trim() == "" && cmbFiscalyear.SelectedValue.ToString() != "0" && cmbContractType.SelectedValue.ToString() != "0")
                //{
                //    sqlListOfContractsQuery = "SELECT PROJECTS.project_code, PROJECTS.project_newname_en, PROJECTS.tender_no, TenderDatesInfo.ts_tender_issue, TenderDatesInfo.ts_closing_s1, CONTRACTORS.cp_tender_award, " +
                //    "COMPANY.co_name, CONTRACTORS.ContractAmount, CONTRACTORS.cp_notice_contractor_to_sign, CONTRACTORS.cp_contractor_sign, CONTRACTORS.cp_distribution, CONTRACTORS.contract_no, Department.Department, COMPANY.nationality " +
                //    "FROM PROJECTS INNER JOIN CONTRACTORS ON PROJECTS.proj_id = CONTRACTORS.proj_id INNER JOIN Department ON PROJECTS.department_id = Department.department_id INNER JOIN TenderDatesInfo ON PROJECTS.proj_id = TenderDatesInfo.proj_id INNER JOIN " +
                //    "COMPANY ON CONTRACTORS.co_id = COMPANY.co_id AND TenderDatesInfo.co_id = COMPANY.co_id INNER JOIN FiscalYear ON PROJECTS.FYID=FiscalYear.FYID INNER JOIN ContractTypes ON PROJECTS.contract_type_id = ContractTypes.contract_type_id WHERE CONTRACTORS.contract_no like " +
                //    "'%" + txtContractNumber.Text.Trim() + "%' and FiscalYear.FYID=" + cmbFiscalyear.SelectedValue.ToString() + " and ContractTypes.contract_type_id=" + cmbContractType.SelectedValue.ToString() + " order by CONTRACTORS.contract_no";
                //}
                //else if (txtContractNumber.Text.Trim() != "" && txtNationality.Text.Trim() == "" && cmbFiscalyear.SelectedValue.ToString() == "0" && cmbContractType.SelectedValue.ToString() == "0")
                //    sqlListOfContractsQuery = "SELECT PROJECTS.project_code, PROJECTS.project_newname_en, PROJECTS.tender_no, TenderDatesInfo.ts_tender_issue, TenderDatesInfo.ts_closing_s1, CONTRACTORS.cp_tender_award, " +
                //    "COMPANY.co_name, CONTRACTORS.ContractAmount, CONTRACTORS.cp_notice_contractor_to_sign, CONTRACTORS.cp_contractor_sign, CONTRACTORS.cp_distribution, CONTRACTORS.contract_no, Department.Department, COMPANY.nationality " +
                //    "FROM PROJECTS INNER JOIN CONTRACTORS ON PROJECTS.proj_id = CONTRACTORS.proj_id INNER JOIN Department ON PROJECTS.department_id = Department.department_id INNER JOIN TenderDatesInfo ON PROJECTS.proj_id = TenderDatesInfo.proj_id INNER JOIN " +
                //    "COMPANY ON CONTRACTORS.co_id = COMPANY.co_id AND TenderDatesInfo.co_id = COMPANY.co_id WHERE CONTRACTORS.contract_no like '%" + txtContractNumber.Text.Trim() + "%' order by CONTRACTORS.contract_no";
                //else if (txtContractNumber.Text.Trim() == "" && txtNationality.Text.Trim() != "" && cmbFiscalyear.SelectedValue.ToString() != "0")
                //    sqlListOfContractsQuery = "SELECT PROJECTS.project_code, PROJECTS.project_newname_en, PROJECTS.tender_no, TenderDatesInfo.ts_tender_issue, TenderDatesInfo.ts_closing_s1, CONTRACTORS.cp_tender_award, " +
                //    "COMPANY.co_name, CONTRACTORS.ContractAmount, CONTRACTORS.cp_notice_contractor_to_sign, CONTRACTORS.cp_contractor_sign, CONTRACTORS.cp_distribution, CONTRACTORS.contract_no, Department.Department, COMPANY.nationality " +
                //    "FROM PROJECTS INNER JOIN CONTRACTORS ON PROJECTS.proj_id = CONTRACTORS.proj_id INNER JOIN Department ON PROJECTS.department_id = Department.department_id INNER JOIN TenderDatesInfo ON PROJECTS.proj_id = TenderDatesInfo.proj_id INNER JOIN " +
                //    "COMPANY ON CONTRACTORS.co_id = COMPANY.co_id AND TenderDatesInfo.co_id = COMPANY.co_id INNER JOIN FiscalYear ON PROJECTS.FYID=FiscalYear.FYID WHERE COMPANY.nationality like '%" + txtNationality.Text.Trim() + "%' " +
                //    "and FiscalYear.FYID=" + cmbFiscalyear.SelectedValue.ToString() + " order by CONTRACTORS.contract_no";
                //else if (txtContractNumber.Text.Trim() == "" && txtNationality.Text.Trim() != "" && cmbFiscalyear.SelectedValue.ToString() == "0")
                //    sqlListOfContractsQuery = "SELECT PROJECTS.project_code, PROJECTS.project_newname_en, PROJECTS.tender_no, TenderDatesInfo.ts_tender_issue, TenderDatesInfo.ts_closing_s1, CONTRACTORS.cp_tender_award, " +
                //    "COMPANY.co_name, CONTRACTORS.ContractAmount, CONTRACTORS.cp_notice_contractor_to_sign, CONTRACTORS.cp_contractor_sign, CONTRACTORS.cp_distribution, CONTRACTORS.contract_no, Department.Department, COMPANY.nationality " +
                //    "FROM PROJECTS INNER JOIN CONTRACTORS ON PROJECTS.proj_id = CONTRACTORS.proj_id INNER JOIN Department ON PROJECTS.department_id = Department.department_id INNER JOIN TenderDatesInfo ON PROJECTS.proj_id = TenderDatesInfo.proj_id INNER JOIN " +
                //    "COMPANY ON CONTRACTORS.co_id = COMPANY.co_id AND TenderDatesInfo.co_id = COMPANY.co_id WHERE COMPANY.nationality like '%" + txtNationality.Text.Trim() + "%' order by CONTRACTORS.contract_no";
                //else if (txtContractNumber.Text.Trim() == "" && txtNationality.Text.Trim() == "" && cmbFiscalyear.SelectedValue.ToString() != "0")
                //    sqlListOfContractsQuery = "SELECT PROJECTS.project_code, PROJECTS.project_newname_en, PROJECTS.tender_no, TenderDatesInfo.ts_tender_issue, TenderDatesInfo.ts_closing_s1, CONTRACTORS.cp_tender_award, " +
                //    "COMPANY.co_name, CONTRACTORS.ContractAmount, CONTRACTORS.cp_notice_contractor_to_sign, CONTRACTORS.cp_contractor_sign, CONTRACTORS.cp_distribution, CONTRACTORS.contract_no, Department.Department, COMPANY.nationality " +
                //    "FROM PROJECTS INNER JOIN CONTRACTORS ON PROJECTS.proj_id = CONTRACTORS.proj_id INNER JOIN Department ON PROJECTS.department_id = Department.department_id INNER JOIN TenderDatesInfo ON PROJECTS.proj_id = TenderDatesInfo.proj_id INNER JOIN " +
                //    "COMPANY ON CONTRACTORS.co_id = COMPANY.co_id AND TenderDatesInfo.co_id = COMPANY.co_id INNER JOIN FiscalYear ON PROJECTS.FYID=FiscalYear.FYID WHERE FiscalYear.FYID=" + cmbFiscalyear.SelectedValue.ToString() + " order by CONTRACTORS.contract_no";
                //else if (txtContractNumber.Text.Trim() == "" && txtNationality.Text.Trim() == "" && cmbFiscalyear.SelectedValue.ToString() == "0")
                //    sqlListOfContractsQuery = "SELECT PROJECTS.project_code, PROJECTS.project_newname_en, PROJECTS.tender_no, TenderDatesInfo.ts_tender_issue, TenderDatesInfo.ts_closing_s1, CONTRACTORS.cp_tender_award, " +
                //    "COMPANY.co_name, CONTRACTORS.ContractAmount, CONTRACTORS.cp_notice_contractor_to_sign, CONTRACTORS.cp_contractor_sign, CONTRACTORS.cp_distribution, CONTRACTORS.contract_no, Department.Department, COMPANY.nationality " +
                //    "FROM PROJECTS INNER JOIN CONTRACTORS ON PROJECTS.proj_id = CONTRACTORS.proj_id INNER JOIN Department ON PROJECTS.department_id = Department.department_id INNER JOIN TenderDatesInfo ON PROJECTS.proj_id = TenderDatesInfo.proj_id INNER JOIN " +
                //    "COMPANY ON CONTRACTORS.co_id = COMPANY.co_id AND TenderDatesInfo.co_id = COMPANY.co_id order by CONTRACTORS.contract_no";
                //else if (txtContractNumber.Text.Trim() != "" && txtNationality.Text.Trim() != "" && cmbFiscalyear.SelectedValue.ToString() != "0")
                //    sqlListOfContractsQuery = "SELECT PROJECTS.project_code, PROJECTS.project_newname_en, PROJECTS.tender_no, TenderDatesInfo.ts_tender_issue, TenderDatesInfo.ts_closing_s1, CONTRACTORS.cp_tender_award, " +
                //    "COMPANY.co_name, CONTRACTORS.ContractAmount, CONTRACTORS.cp_notice_contractor_to_sign, CONTRACTORS.cp_contractor_sign, CONTRACTORS.cp_distribution, CONTRACTORS.contract_no, Department.Department, COMPANY.nationality " +
                //    "FROM PROJECTS INNER JOIN CONTRACTORS ON PROJECTS.proj_id = CONTRACTORS.proj_id INNER JOIN Department ON PROJECTS.department_id = Department.department_id INNER JOIN TenderDatesInfo ON PROJECTS.proj_id = TenderDatesInfo.proj_id INNER JOIN " +
                //    "COMPANY ON CONTRACTORS.co_id = COMPANY.co_id AND TenderDatesInfo.co_id = COMPANY.co_id INNER JOIN FiscalYear ON PROJECTS.FYID=FiscalYear.FYID WHERE CONTRACTORS.contract_no like '%" + txtContractNumber.Text.Trim() + "%' " +
                //    "and FiscalYear.FYID=" + cmbFiscalyear.SelectedValue.ToString() + " and COMPANY.nationality like '%" + txtNationality.Text.Trim() + "%' order by CONTRACTORS.contract_no";
                //else if (txtContractNumber.Text.Trim() != "" && txtNationality.Text.Trim() != "" && cmbFiscalyear.SelectedValue.ToString() == "0")
                //    sqlListOfContractsQuery = "SELECT PROJECTS.project_code, PROJECTS.project_newname_en, PROJECTS.tender_no, TenderDatesInfo.ts_tender_issue, TenderDatesInfo.ts_closing_s1, CONTRACTORS.cp_tender_award, " +
                //    "COMPANY.co_name, CONTRACTORS.ContractAmount, CONTRACTORS.cp_notice_contractor_to_sign, CONTRACTORS.cp_contractor_sign, CONTRACTORS.cp_distribution, CONTRACTORS.contract_no, Department.Department, COMPANY.nationality " +
                //    "FROM PROJECTS INNER JOIN CONTRACTORS ON PROJECTS.proj_id = CONTRACTORS.proj_id INNER JOIN Department ON PROJECTS.department_id = Department.department_id INNER JOIN TenderDatesInfo ON PROJECTS.proj_id = TenderDatesInfo.proj_id INNER JOIN " +
                //    "COMPANY ON CONTRACTORS.co_id = COMPANY.co_id AND TenderDatesInfo.co_id = COMPANY.co_id WHERE CONTRACTORS.contract_no like '%" + txtContractNumber.Text.Trim() + "%' and COMPANY.nationality like '%" + txtNationality.Text.Trim() + "%' order by CONTRACTORS.contract_no";

                    DataTable dtListOfContractsReports = dalObj.GetDataFromDB("ListOfContractsReports", sqlListOfContractsQuery);

                    //DataTable dtUniqueProjIds = dtListOfContractsReports.Select // dalObj.GetDataFromDB("UniqueProjectIds", sqlListOfContractsQuery);

                    StringBuilder strBuilder = new StringBuilder();
                    if (dtListOfContractsReports.Rows.Count == 0)
                        lblTotRecCount.Text = "Total Records Count=0";
                    else
                        lblTotRecCount.Text = "Total Records Count=" + dtListOfContractsReports.Rows.Count;

                    strBuilder = CreateListOfContractsReport(strBuilder, dtListOfContractsReports);
                    webReport.DocumentText = strBuilder.ToString();
                    webReport.ScrollBarsEnabled = true;
                //}
                //else
                //    MessageBox.Show("Either Contract Number or Nationality is required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            catch (Exception)
            {
                MessageBox.Show("Error occurred displaying records", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }   
        }


        private void txtContractNumber_Leave(object sender, EventArgs e)
        {
            SearchContractNo();
        }

        private void txtContractNumber_Enter(object sender, EventArgs e)
        {
            SearchContractNo();
        }
        
    }
}
