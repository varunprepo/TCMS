﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TenderTrackingSystem;

namespace MDI_ParenrForm.Reports
{
    public partial class frmTenderBondTracking : Form
    {
        DAL dalObj = null;
        CommonClass comCls = null;
        
        IList<string> userRightsColl = new List<string>();
        //static short fiscalYearSelection = 0;         

        public frmTenderBondTracking()
        {
            InitializeComponent();
            //userRightsColl = userRightsCollComm;
            comCls = new CommonClass("");
            dalObj = new DAL();
            DataTable dtCommitteeNames = dalObj.GetDataFromDB("CommitteeNames", "select committee_id,committee_name from Committee");
            DataRow row = dtCommitteeNames.NewRow();
            row["committee_name"] = "All Committees";
            row["committee_id"] = 0;
            dtCommitteeNames.Rows.Add(row);
            cmbCommitteeNames.DataSource = dtCommitteeNames;
            cmbCommitteeNames.DisplayMember = "committee_name";
            cmbCommitteeNames.ValueMember = "committee_id";
            cmbCommitteeNames.SelectedIndex = cmbCommitteeNames.FindStringExact("All Committees");
            //dalObj.populateCmbBox("select committee_id,committee_name from Committee", cmbCommitteeNames);
            //DataTable dtCommitteeNames = (DataTable)cmbCommitteeNames;
            dalObj.populateCmbBox("select FYID,FiscalYear from FiscalYear order by FiscalYear desc", cmbFiscalYear);
            
            //fiscalYearSelection = 0;
        }

        private void btnSubmitReport_Click(object sender, EventArgs e)
        {
            try
            {
                GenerateReport();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Occurred while displaying the report","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
         
        }

        private void GenerateReport()
        {
            DataTable dtTdrBondTracking = new DataTable();
            dtTdrBondTracking.Columns.Add("SNo");
            dtTdrBondTracking.Columns.Add("ProjectTitle");
            dtTdrBondTracking.Columns.Add("TenderNo");
            dtTdrBondTracking.Columns.Add("TenderIssueDate");
            dtTdrBondTracking.Columns.Add("TotalDocumentFee");
            dtTdrBondTracking.Columns.Add("TenderBond");
            dtTdrBondTracking.Columns.Add("OriginalTenderbondValidity");
            dtTdrBondTracking.Columns.Add("TenderbondValidityExt1");
            dtTdrBondTracking.Columns.Add("TenderbondValidityExt2");
            dtTdrBondTracking.Columns.Add("TenderClosingDate");            
          
            dtTdrBondTracking.AcceptChanges();

           
            sNoCounter = 0;
            string sqlTdrBondTrack = null;
            string whereClause = comCls.CheckAccessRightsForTenderNoYear(userRightsColl);

            if (!cmbCommitteeNames.SelectedValue.ToString().Equals("0"))
            {
                sqlTdrBondTrack = "SELECT distinct p.proj_id,p.project_newname_en, p.tender_no,tdi.ts_tender_invitation, pc.doc_fee, pc.tender_bond,tdi.org_tenderbond_validity, tdi.tenderbond_validity_ext1, tdi.tenderbond_validity_ext2, CASE " +
                "WHEN tdi.ts_closing_s1 is not Null then tdi.ts_closing_s1 else tdi.ts_modified_closing end as ts_closing_date " +
                "FROM PROJECTS p INNER JOIN TenderDatesInfo tdi ON p.proj_id = tdi.proj_id INNER JOIN Committee com ON p.committee_id = com.committee_id INNER JOIN ProjectCost pc ON p.proj_id = pc.proj_id " +
                "WHERE (com.committee_id = " + cmbCommitteeNames.SelectedValue + ") AND (p.FYID = " + cmbFiscalYear.SelectedValue + ") and  p.tender_no is not NULL";

                if (whereClause != null)
                {
                    if (whereClause != "")
                    {
                        sqlTdrBondTrack = sqlTdrBondTrack+" and " + whereClause;
                    }
                }                
            }
            else
            {
                sqlTdrBondTrack = "SELECT distinct p.proj_id,p.project_newname_en, p.tender_no,tdi.ts_tender_invitation, pc.doc_fee, pc.tender_bond,tdi.org_tenderbond_validity, tdi.tenderbond_validity_ext1, tdi.tenderbond_validity_ext2, CASE " +
                "WHEN tdi.ts_closing_s1 is not Null then tdi.ts_closing_s1 else tdi.ts_modified_closing end as ts_closing_date " +
                "FROM PROJECTS p INNER JOIN TenderDatesInfo tdi ON p.proj_id = tdi.proj_id INNER JOIN Committee com ON p.committee_id = com.committee_id INNER JOIN ProjectCost pc ON p.proj_id = pc.proj_id " +
                "WHERE (p.FYID = " + cmbFiscalYear.SelectedValue + ") and  p.tender_no is not NULL";

                if (whereClause != null)
                {
                    if (whereClause != "")
                    {
                        sqlTdrBondTrack = sqlTdrBondTrack +" and " + whereClause;
                    }                                      
                }
                 
            }

            

            dtTdrBondTracking = TenderBondFilteredRecords(dtTdrBondTracking,sqlTdrBondTrack);

            
            StringBuilder strBuildObj = new StringBuilder();
            strBuildObj.Append("<table width='100%' cellpadding='0' cellspacing='0' style='border: solid 1px;'> <tr><td colspan='10' style='font-family:Century Gothic;text-align:center;height: 35px;font-size: 11pt ;");
            strBuildObj.Append(" vertical-align:middle;border: solid 1px;background-color:#C0D9AF'><b>TENDER BOND TRACKING REPORT</b></td></tr><tr><td colspan='10' style='font-family:Century Gothic;border-style: solid; border-color: inherit; border-width: 1px; text-align:center;");
            strBuildObj.Append("font-size: 11pt;  vertical-align:middle; background-color:#808080'><b>" + ((DataRowView)cmbCommitteeNames.SelectedItem).Row.ItemArray[1].ToString() + "</b></td></tr>");

             
            strBuildObj.Append("<tr><td colspan='10' style='font-family:Century Gothic;border-style: solid; border-color: inherit; border-width: 1px; text-align:center;");
            strBuildObj.Append("font-size: 11pt;  vertical-align:middle; background-color:#808080'><b>Tenders for FY " + ((DataRowView)cmbFiscalYear.SelectedItem).Row.ItemArray[1].ToString() + "</b></td></tr>");
            
            strBuildObj.Append("<tr><td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px; overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>SI.</b></td>");            
            strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Tender Title</b></td>");
            strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Tender No.</b></td>");
            strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Tender Issue Date</b></td>");
            strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Total Document Fee</b></td>");
            strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Tender Bond</b></td>");
            strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>TenderBond Validity</b></td>");
            strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>TenderBond Validity Extension1</b></td>");
            strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>TenderBond Validity Extension2</b></td>");
            strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Closing Date</b></td></tr>");             

            if (dtTdrBondTracking.Rows.Count != 0)
            {
                foreach (DataRow rowData in dtTdrBondTracking.Rows)
                {
                    strBuildObj.Append("<tr><td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[0] + "</td>");

                    strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[1] + "</td>");

                    strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[2] + "</td>");

                    strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[3] + "</td>");

                    strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[4] + "</td>");

                    strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[5] + "</td>");

                    strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[6] + "</td>");

                    strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[7] + "</td>");

                    strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[8] + "</td>");

                    strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[9] + "</td>");                                        
                    
                    strBuildObj.Append("</tr>");

                }
                strBuildObj.Append("<tr><td colspan='10' style=\"width:auto;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b style=\"font-style: italic\">This report is generated by TCMS dated :</b><b>" + DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss") + "</b></td></tr>");
                lblTotRecCount.Text = "Total Records Count=" + dtTdrBondTracking.Rows.Count;
            }
            else
            {
                lblTotRecCount.Text = "Total Records Count=0";
                MessageBox.Show("No data exist for selected options", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            strBuildObj.Append("</table>");
            webReport.DocumentText = strBuildObj.ToString();
            webReport.ScrollBarsEnabled = true;
        }

        static int sNoCounter = 0;

        private DataTable TenderBondFilteredRecords(DataTable dtTdrBondTracking, string sqlCommReport)
        {            
            DataTable dtTenderBondInfo = dalObj.GetDataFromDB("FinalTenderBondInfo", sqlCommReport);
            if (dtTenderBondInfo.Rows.Count != 0)
            {
                int rowCounter = 0;
                DataTable dtTenderBondInfoWithClosingDates = dtTenderBondInfo.Select("ts_closing_date is not null").CopyToDataTable();

                //while (rowCounter < dtTenderBondInfoWithClosingDates.Rows.Count)
                //{
                FillRowsOfDataTable(dtTdrBondTracking, dtTenderBondInfoWithClosingDates, ref rowCounter, ref sNoCounter);
                //}         

                StringBuilder sb = new StringBuilder();
                foreach (DataRow row in dtTenderBondInfoWithClosingDates.Rows)
                {
                    sb.Append(row.ItemArray[0] + ",");
                }
                if (dtTenderBondInfo.Select("proj_id not in (" + sb.ToString().Substring(0, sb.ToString().Length - 1) + ")").ToList().Count != 0)
                {
                    dtTenderBondInfo = dtTenderBondInfo.Select("proj_id not in (" + sb.ToString().Substring(0, sb.ToString().Length - 1) + ")").CopyToDataTable();
                    rowCounter = 0;                    
                    FillRowsOfDataTable(dtTdrBondTracking, dtTenderBondInfo, ref rowCounter, ref sNoCounter);
                }         
                 
            }
            return dtTdrBondTracking;

        }


        private void FillRowsOfDataTable(DataTable dtTdrBondTracking, DataTable dtTenderBondInfo,ref int rowCounter,ref int sNoCounter)
        {
            clsTs_Stage clsForTS = new clsTs_Stage("");
            
            while (rowCounter < dtTenderBondInfo.Rows.Count)
            {
                DataRow dr = dtTdrBondTracking.NewRow();
                dr[0] = sNoCounter + 1;
                if (dtTenderBondInfo.Rows[rowCounter][1].ToString() != "")
                {
                    dr[1] = dtTenderBondInfo.Rows[rowCounter][1];
                }
                else
                {
                    dr[1] = "";
                }
                if (dtTenderBondInfo.Rows[rowCounter][2].ToString() != "")
                {
                    dr[2] = dtTenderBondInfo.Rows[rowCounter][2];
                }
                else
                {
                    dr[2] = "";
                }
                if (dtTenderBondInfo.Rows[rowCounter][3].ToString() != "")
                {
                    dr[3] = Convert.ToDateTime(dtTenderBondInfo.Rows[rowCounter][3]).ToString("dd-MMM-yyyy");
                }
                else
                {
                    dr[3] = "";
                }
                if (dtTenderBondInfo.Rows[rowCounter][4].ToString() != "")
                {
                    dr[4] = clsForTS.GetbidderCount(Convert.ToInt32(dtTenderBondInfo.Rows[rowCounter][0])) * Convert.ToInt32(dtTenderBondInfo.Rows[rowCounter][4]);
                }
                else
                {
                    dr[4] = "";
                }
                if (dtTenderBondInfo.Rows[rowCounter][5].ToString() != "")
                {
                    dr[5] = string.Format("{0:#,##0.00}", dtTenderBondInfo.Rows[rowCounter][5]);
                }
                else
                {
                    dr[5] = "";
                }
                if (dtTenderBondInfo.Rows[rowCounter][6].ToString() != "")
                {
                    dr[6] = Convert.ToDateTime(dtTenderBondInfo.Rows[rowCounter][6]).ToString("dd-MMM-yyyy");
                }
                else
                {
                    dr[6] = "";
                }
                if (dtTenderBondInfo.Rows[rowCounter][7].ToString() != "")
                {
                    dr[7] = Convert.ToDateTime(dtTenderBondInfo.Rows[rowCounter][7]).ToString("dd-MMM-yyyy");
                }
                else
                {
                    dr[7] = "";
                }
                if (dtTenderBondInfo.Rows[rowCounter][8].ToString() != "")
                {
                    dr[8] = Convert.ToDateTime(dtTenderBondInfo.Rows[rowCounter][8]).ToString("dd-MMM-yyyy");
                }
                else
                {
                    dr[8] = "";
                }
                if (dtTenderBondInfo.Rows[rowCounter][9].ToString() != "")
                {
                    dr[9] = Convert.ToDateTime(dtTenderBondInfo.Rows[rowCounter][9]).ToString("dd-MMM-yyyy");
                }
                else
                {
                    dr[9] = "";
                }
                dtTdrBondTracking.Rows.Add(dr);
                dtTdrBondTracking.AcceptChanges();
                rowCounter++;
                sNoCounter++;
            }
        }

        private string FindTotal(string sqlFindTotInvitees)
        {
            DataTable dtFindTotInvitees = dalObj.GetDataFromDB("FindTotal", sqlFindTotInvitees);
            string count = null;
            if (dtFindTotInvitees.Rows.Count != 0)
            {
                count = dtFindTotInvitees.Rows[0][0].ToString();
            }
            else
            {
                count = "0";
            }
            return count;
        }

        private string GetTendererList(string sqlFindTotInvitees)
        {

            DataTable dtTendererList = dalObj.GetDataFromDB("TendererList", sqlFindTotInvitees);

            string tendererNames = null;
            if (dtTendererList.Rows.Count != 0)
            {
                tendererNames = string.Join(",", dtTendererList.AsEnumerable()
                                .Select(x => x["co_name"].ToString())
                                .ToArray());
            }
            else
            {
                tendererNames = "";
            }
            return tendererNames;
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            comCls.ExportToExcel(webReport);
        }       
      
    }
}
