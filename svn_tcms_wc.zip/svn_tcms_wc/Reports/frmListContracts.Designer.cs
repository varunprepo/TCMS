﻿namespace MDI_ParenrForm.Reports
{
    partial class frmListContracts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTotRecCount = new System.Windows.Forms.Label();
            this.btnExportToExcel = new System.Windows.Forms.Button();
            this.btnGenerateListOfContracts = new System.Windows.Forms.Button();
            this.webReport = new System.Windows.Forms.WebBrowser();
            this.cmbQSWorkingStatus = new System.Windows.Forms.ComboBox();
            this.lblQSWorkingStatus = new System.Windows.Forms.Label();
            this.cmbAssignedQS = new System.Windows.Forms.ComboBox();
            this.lblAssignedQS = new System.Windows.Forms.Label();
            this.lblContractNumber = new System.Windows.Forms.Label();
            this.txtContractNumber = new System.Windows.Forms.TextBox();
            this.lblNationality = new System.Windows.Forms.Label();
            this.txtNationality = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbFiscalyear = new System.Windows.Forms.ComboBox();
            this.cmbContractNoType = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTotRecCount
            // 
            this.lblTotRecCount.AutoSize = true;
            this.lblTotRecCount.Location = new System.Drawing.Point(799, 585);
            this.lblTotRecCount.Name = "lblTotRecCount";
            this.lblTotRecCount.Size = new System.Drawing.Size(117, 13);
            this.lblTotRecCount.TabIndex = 21;
            this.lblTotRecCount.Text = "Total Records Count=0";
            // 
            // btnExportToExcel
            // 
            this.btnExportToExcel.BackColor = System.Drawing.Color.Coral;
            this.btnExportToExcel.Location = new System.Drawing.Point(364, 82);
            this.btnExportToExcel.Name = "btnExportToExcel";
            this.btnExportToExcel.Size = new System.Drawing.Size(98, 23);
            this.btnExportToExcel.TabIndex = 20;
            this.btnExportToExcel.Text = "Export To Excel";
            this.btnExportToExcel.UseVisualStyleBackColor = false;
            this.btnExportToExcel.Click += new System.EventHandler(this.btnExportToExcel_Click);
            // 
            // btnGenerateListOfContracts
            // 
            this.btnGenerateListOfContracts.Location = new System.Drawing.Point(242, 82);
            this.btnGenerateListOfContracts.Name = "btnGenerateListOfContracts";
            this.btnGenerateListOfContracts.Size = new System.Drawing.Size(98, 23);
            this.btnGenerateListOfContracts.TabIndex = 19;
            this.btnGenerateListOfContracts.Text = "Generate Report";
            this.btnGenerateListOfContracts.UseVisualStyleBackColor = true;
            this.btnGenerateListOfContracts.Click += new System.EventHandler(this.btnGenerateListOfContracts_Click);
            // 
            // webReport
            // 
            this.webReport.Location = new System.Drawing.Point(21, 132);
            this.webReport.MinimumSize = new System.Drawing.Size(20, 20);
            this.webReport.Name = "webReport";
            this.webReport.Size = new System.Drawing.Size(906, 430);
            this.webReport.TabIndex = 18;
            // 
            // cmbQSWorkingStatus
            // 
            this.cmbQSWorkingStatus.FormattingEnabled = true;
            this.cmbQSWorkingStatus.Location = new System.Drawing.Point(132, -34);
            this.cmbQSWorkingStatus.Name = "cmbQSWorkingStatus";
            this.cmbQSWorkingStatus.Size = new System.Drawing.Size(155, 21);
            this.cmbQSWorkingStatus.TabIndex = 17;
            // 
            // lblQSWorkingStatus
            // 
            this.lblQSWorkingStatus.AutoSize = true;
            this.lblQSWorkingStatus.Location = new System.Drawing.Point(133, -50);
            this.lblQSWorkingStatus.Name = "lblQSWorkingStatus";
            this.lblQSWorkingStatus.Size = new System.Drawing.Size(98, 13);
            this.lblQSWorkingStatus.TabIndex = 16;
            this.lblQSWorkingStatus.Text = "QS Working Status";
            // 
            // cmbAssignedQS
            // 
            this.cmbAssignedQS.FormattingEnabled = true;
            this.cmbAssignedQS.Location = new System.Drawing.Point(-89, -34);
            this.cmbAssignedQS.Name = "cmbAssignedQS";
            this.cmbAssignedQS.Size = new System.Drawing.Size(185, 21);
            this.cmbAssignedQS.TabIndex = 15;
            // 
            // lblAssignedQS
            // 
            this.lblAssignedQS.AutoSize = true;
            this.lblAssignedQS.Location = new System.Drawing.Point(-88, -50);
            this.lblAssignedQS.Name = "lblAssignedQS";
            this.lblAssignedQS.Size = new System.Drawing.Size(68, 13);
            this.lblAssignedQS.TabIndex = 14;
            this.lblAssignedQS.Text = "Assigned QS";
            // 
            // lblContractNumber
            // 
            this.lblContractNumber.AutoSize = true;
            this.lblContractNumber.Location = new System.Drawing.Point(69, 31);
            this.lblContractNumber.Name = "lblContractNumber";
            this.lblContractNumber.Size = new System.Drawing.Size(86, 13);
            this.lblContractNumber.TabIndex = 23;
            this.lblContractNumber.Text = "Contracting Year";
            // 
            // txtContractNumber
            // 
            this.txtContractNumber.Location = new System.Drawing.Point(159, 28);
            this.txtContractNumber.Name = "txtContractNumber";
            this.txtContractNumber.Size = new System.Drawing.Size(100, 20);
            this.txtContractNumber.TabIndex = 24;
            // 
            // lblNationality
            // 
            this.lblNationality.AutoSize = true;
            this.lblNationality.Location = new System.Drawing.Point(287, 31);
            this.lblNationality.Name = "lblNationality";
            this.lblNationality.Size = new System.Drawing.Size(56, 13);
            this.lblNationality.TabIndex = 25;
            this.lblNationality.Text = "Nationality";
            // 
            // txtNationality
            // 
            this.txtNationality.Location = new System.Drawing.Point(349, 28);
            this.txtNationality.Name = "txtNationality";
            this.txtNationality.Size = new System.Drawing.Size(100, 20);
            this.txtNationality.TabIndex = 26;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(478, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 27;
            this.label2.Text = "Fiscal Year";
            // 
            // cmbFiscalyear
            // 
            this.cmbFiscalyear.FormattingEnabled = true;
            this.cmbFiscalyear.Location = new System.Drawing.Point(540, 27);
            this.cmbFiscalyear.Name = "cmbFiscalyear";
            this.cmbFiscalyear.Size = new System.Drawing.Size(84, 21);
            this.cmbFiscalyear.TabIndex = 33;
            // 
            // cmbContractNoType
            // 
            this.cmbContractNoType.FormattingEnabled = true;
            this.cmbContractNoType.Items.AddRange(new object[] {
            "Framework",
            "WorkOrder",
            "C",
            "SC",
            "P",
            "All"});
            this.cmbContractNoType.Location = new System.Drawing.Point(778, 27);
            this.cmbContractNoType.Name = "cmbContractNoType";
            this.cmbContractNoType.Size = new System.Drawing.Size(113, 21);
            this.cmbContractNoType.TabIndex = 35;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(661, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 13);
            this.label1.TabIndex = 34;
            this.label1.Text = "Contract Number Type";
            // 
            // frmListContracts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FloralWhite;
            this.ClientSize = new System.Drawing.Size(965, 616);
            this.Controls.Add(this.cmbContractNoType);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbFiscalyear);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtNationality);
            this.Controls.Add(this.lblNationality);
            this.Controls.Add(this.txtContractNumber);
            this.Controls.Add(this.lblContractNumber);
            this.Controls.Add(this.lblTotRecCount);
            this.Controls.Add(this.btnExportToExcel);
            this.Controls.Add(this.btnGenerateListOfContracts);
            this.Controls.Add(this.webReport);
            this.Controls.Add(this.cmbQSWorkingStatus);
            this.Controls.Add(this.lblQSWorkingStatus);
            this.Controls.Add(this.cmbAssignedQS);
            this.Controls.Add(this.lblAssignedQS);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmListContracts";
            this.Text = "Contracts List";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTotRecCount;
        private System.Windows.Forms.Button btnExportToExcel;
        private System.Windows.Forms.Button btnGenerateListOfContracts;
        private System.Windows.Forms.WebBrowser webReport;
        private System.Windows.Forms.ComboBox cmbQSWorkingStatus;
        private System.Windows.Forms.Label lblQSWorkingStatus;
        private System.Windows.Forms.ComboBox cmbAssignedQS;
        private System.Windows.Forms.Label lblAssignedQS;
        private System.Windows.Forms.Label lblContractNumber;
        private System.Windows.Forms.TextBox txtContractNumber;
        private System.Windows.Forms.Label lblNationality;
        private System.Windows.Forms.TextBox txtNationality;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbFiscalyear;
        private System.Windows.Forms.ComboBox cmbContractNoType;
        private System.Windows.Forms.Label label1;
    }
}