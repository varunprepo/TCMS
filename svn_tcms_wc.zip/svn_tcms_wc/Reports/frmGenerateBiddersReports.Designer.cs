﻿namespace MDI_ParenrForm.Reports
{
    partial class frmGenerateBiddersReports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbFiscalYear = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.wbReport = new System.Windows.Forms.WebBrowser();
            this.btnExportToExcel = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.lblPercentage = new System.Windows.Forms.Label();
            this.txtPercentage = new System.Windows.Forms.TextBox();
            this.btnRefreshCmp = new System.Windows.Forms.Button();
            this.lblCmpCount = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cmbFiscalYear
            // 
            this.cmbFiscalYear.FormattingEnabled = true;
            this.cmbFiscalYear.Location = new System.Drawing.Point(337, 32);
            this.cmbFiscalYear.Name = "cmbFiscalYear";
            this.cmbFiscalYear.Size = new System.Drawing.Size(100, 21);
            this.cmbFiscalYear.TabIndex = 0;
            this.cmbFiscalYear.SelectionChangeCommitted += new System.EventHandler(this.cmbFiscalYear_SelectionChangeCommitted);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(223, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Select Fiscal Year";
            // 
            // wbReport
            // 
            this.wbReport.Location = new System.Drawing.Point(19, 79);
            this.wbReport.MinimumSize = new System.Drawing.Size(23, 20);
            this.wbReport.Name = "wbReport";
            this.wbReport.Size = new System.Drawing.Size(747, 437);
            this.wbReport.TabIndex = 2;
            // 
            // btnExportToExcel
            // 
            this.btnExportToExcel.BackColor = System.Drawing.Color.Goldenrod;
            this.btnExportToExcel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExportToExcel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnExportToExcel.Location = new System.Drawing.Point(575, 32);
            this.btnExportToExcel.Name = "btnExportToExcel";
            this.btnExportToExcel.Size = new System.Drawing.Size(112, 32);
            this.btnExportToExcel.TabIndex = 3;
            this.btnExportToExcel.Text = "Export To Excel";
            this.btnExportToExcel.UseVisualStyleBackColor = false;
            this.btnExportToExcel.Click += new System.EventHandler(this.btnExportToExcel_Click);
            // 
            // lblPercentage
            // 
            this.lblPercentage.AutoSize = true;
            this.lblPercentage.Location = new System.Drawing.Point(16, 35);
            this.lblPercentage.Name = "lblPercentage";
            this.lblPercentage.Size = new System.Drawing.Size(112, 13);
            this.lblPercentage.TabIndex = 4;
            this.lblPercentage.Text = "Enter Qatari Share";
            // 
            // txtPercentage
            // 
            this.txtPercentage.Location = new System.Drawing.Point(130, 32);
            this.txtPercentage.Name = "txtPercentage";
            this.txtPercentage.Size = new System.Drawing.Size(88, 20);
            this.txtPercentage.TabIndex = 5;
            this.txtPercentage.TextChanged += new System.EventHandler(this.txtPercentage_TextChanged);
            this.txtPercentage.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtPercentage_KeyDown);
            this.txtPercentage.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPercentage_KeyPress);
            // 
            // btnRefreshCmp
            // 
            this.btnRefreshCmp.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnRefreshCmp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnRefreshCmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshCmp.ForeColor = System.Drawing.Color.Coral;
            this.btnRefreshCmp.Image = global::MDI_ParenrForm.Properties.Resources.Button_Reload_icon;
            this.btnRefreshCmp.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRefreshCmp.Location = new System.Drawing.Point(688, 32);
            this.btnRefreshCmp.Name = "btnRefreshCmp";
            this.btnRefreshCmp.Size = new System.Drawing.Size(77, 32);
            this.btnRefreshCmp.TabIndex = 32;
            this.btnRefreshCmp.Text = "Refresh";
            this.btnRefreshCmp.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnRefreshCmp.UseVisualStyleBackColor = false;
            this.btnRefreshCmp.Click += new System.EventHandler(this.btnRefreshCmp_Click);
            // 
            // lblCmpCount
            // 
            this.lblCmpCount.AutoSize = true;
            this.lblCmpCount.Location = new System.Drawing.Point(249, 529);
            this.lblCmpCount.Name = "lblCmpCount";
            this.lblCmpCount.Size = new System.Drawing.Size(0, 13);
            this.lblCmpCount.TabIndex = 33;
            // 
            // frmGenerateBiddersReports
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(779, 561);
            this.Controls.Add(this.lblCmpCount);
            this.Controls.Add(this.btnRefreshCmp);
            this.Controls.Add(this.txtPercentage);
            this.Controls.Add(this.lblPercentage);
            this.Controls.Add(this.btnExportToExcel);
            this.Controls.Add(this.wbReport);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbFiscalYear);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmGenerateBiddersReports";
            this.Text = "Companies List with Qatari Share ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbFiscalYear;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.WebBrowser wbReport;
        private System.Windows.Forms.Button btnExportToExcel;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Label lblPercentage;
        private System.Windows.Forms.TextBox txtPercentage;
        private System.Windows.Forms.Button btnRefreshCmp;
        private System.Windows.Forms.Label lblCmpCount;
    }
}