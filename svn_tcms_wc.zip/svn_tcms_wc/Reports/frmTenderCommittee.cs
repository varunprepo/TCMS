﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TenderTrackingSystem;

namespace MDI_ParenrForm.Reports
{
    public partial class frmTenderCommittee : Form
    {
        DAL dalObj = null;
        CommonClass comCls = null;
        static short startReportDateChanged = 0;
        static short endReportDateChanged = 0;
        IList<string> userRightsColl = new List<string>();
        //static short fiscalYearSelection = 0;         

        public frmTenderCommittee(IList<string> userRightsCollComm)
        {
            InitializeComponent();
            userRightsColl = userRightsCollComm;
            comCls = new CommonClass("");
            dalObj = new DAL();
            dalObj.populateCmbBox("select committee_id,committee_name from Committee", cmbCommitteeNames);
            dalObj.populateCmbBox("select FYID,FiscalYear from FiscalYear order by FiscalYear desc", cmbFiscalYear);
            startReportDateChanged = 0;
            endReportDateChanged = 0;
            //fiscalYearSelection = 0;
        }

        private void btnSubmitReport_Click(object sender, EventArgs e)
        {
            GenerateReport();
        }

        private void GenerateReport()
        {
            DataTable dtTenderInfo = new DataTable();
            dtTenderInfo.Columns.Add("SNo");
            dtTenderInfo.Columns.Add("TenderNo.");
            dtTenderInfo.Columns.Add("TenderTitle");
            dtTenderInfo.Columns.Add("ProjectCode");
            dtTenderInfo.Columns.Add("Department");
            dtTenderInfo.Columns.Add("TenderPublishDate");
            dtTenderInfo.Columns.Add("TypeOfTender");
            dtTenderInfo.Columns.Add("NoInvited");
            dtTenderInfo.Columns.Add("NoPurchased");
            dtTenderInfo.Columns.Add("NoSubmitted");
            dtTenderInfo.Columns.Add("TendererList");
            dtTenderInfo.Columns.Add("TenderStatus");
            dtTenderInfo.Columns.Add("SuccessfulTenderer");
            dtTenderInfo.Columns.Add("AwardingValue");
            dtTenderInfo.Columns.Add("ContractNo");
            dtTenderInfo.AcceptChanges();

            int rowCounter = 0;
            sNoCounter = 0;
            string sqlCommReport = null;
            string whereClause = comCls.CheckAccessRightsForTenderNoYear(userRightsColl);
            sqlCommReport = "SELECT distinct p.proj_id,p.tender_no, p.project_newname_en, p.project_code, d2.department_short_name, TenderTypes.tender_type_name, " +
            "TenderStatus.Status_Name, CONTRACTORS.ContractAmount, CONTRACTORS.contract_no, COMPANY.co_name FROM Committee left outer JOIN PROJECTS p ON Committee.committee_id = p.committee_id left outer JOIN " +
            "TenderTypes ON p.tender_type_id = TenderTypes.tender_type_id left outer JOIN TenderStatus ON p.Tender_Status_id = TenderStatus.Tender_Status_id left outer JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id left outer JOIN " +
            "FiscalYear ON p.FYID = FiscalYear.FYID  inner join Department2 as d1 on p.department_id=d1.department_id" +
            " inner join Department2 as d2 on d1.newDepID=d2.department_id left outer JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id " +
            " where p.committee_id=" + cmbCommitteeNames.SelectedValue;

            if (startReportDateChanged == 0 && endReportDateChanged == 0)
            {
                if(whereClause != null)
                {
                    if(whereClause !="")
                    {
                        sqlCommReport = sqlCommReport + " and p.FYID=" + cmbFiscalYear.SelectedValue + " and p.tender_no is not NULL and" + whereClause + " Order by p.tender_no";
                    }
                    else
                    {
                        sqlCommReport = sqlCommReport + " and p.FYID=" + cmbFiscalYear.SelectedValue + " and p.tender_no is not NULL Order by p.tender_no";
                    }
                }
                else
                {
                    sqlCommReport = sqlCommReport + " and p.FYID=" + cmbFiscalYear.SelectedValue + " and p.tender_no is not NULL Order by p.tender_no";
                }
                
                dtTenderInfo = TenderInfo(ref dtTenderInfo, sqlCommReport);
            }
            else
            {
                string sqlGetProjIdsFromDates = null;
                
                if (whereClause != null)
                {
                    if (whereClause != "")
                    {
                        sqlGetProjIdsFromDates = "SELECT p.proj_id from TenderDatesInfo inner join PROJECTS p on p.proj_id = TenderDatesInfo.proj_id  where (TenderDatesInfo.ts_tender_invitation " +
                        "between '" + dtpTenderPublishStartDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpTenderPublishEndDate.Value.ToString("dd/MMM/yyyy") + "') and TenderDatesInfo.ts_tender_invitation is not NULL and" + whereClause;
                    }
                    else
                    {
                        sqlGetProjIdsFromDates = "SELECT p.proj_id from TenderDatesInfo inner join PROJECTS p on p.proj_id = TenderDatesInfo.proj_id  where (TenderDatesInfo.ts_tender_invitation " +
                        "between '" + dtpTenderPublishStartDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpTenderPublishEndDate.Value.ToString("dd/MMM/yyyy") + "') and TenderDatesInfo.ts_tender_invitation is not NULL";
                    }
                     
                }
                else
                {
                    sqlGetProjIdsFromDates = "SELECT p.proj_id from TenderDatesInfo inner join PROJECTS p on p.proj_id = TenderDatesInfo.proj_id  where (TenderDatesInfo.ts_tender_invitation " +
                    "between '" + dtpTenderPublishStartDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtpTenderPublishEndDate.Value.ToString("dd/MMM/yyyy") + "') and TenderDatesInfo.ts_tender_invitation is not NULL";
                }
                
                
                DataTable dtProjIDsPubDate = dalObj.GetDataFromDB("TenderInvitationDate", sqlGetProjIdsFromDates);
                while (rowCounter < dtProjIDsPubDate.Rows.Count)
                {
                    string sqlTenderInfo = sqlCommReport + " and p.proj_id=" + dtProjIDsPubDate.Rows[rowCounter]["proj_id"];
                    dtTenderInfo = TenderInfo(ref dtTenderInfo, sqlTenderInfo);
                    rowCounter++;
                }
            }

            StringBuilder strBuildObj = new StringBuilder();
            strBuildObj.Append("<table width='100%' cellpadding='0' cellspacing='0' style='border: solid 1px;'> <tr><td colspan='15' style='font-family:Century Gothic;text-align:center;height: 35px;font-size: 11pt ;");
            strBuildObj.Append(" vertical-align:middle;border: solid 1px;background-color:#C0D9AF'><b>TENDER COMITTEE ANNUAL REPORT</b></td></tr><tr><td colspan='15' style='font-family:Century Gothic;border-style: solid; border-color: inherit; border-width: 1px; text-align:center;");

            if (startReportDateChanged == 0 && endReportDateChanged == 0)
            {
                strBuildObj.Append("font-size: 11pt;  vertical-align:middle; background-color:#808080'><b>ALL COMMITTEES</b></td></tr>");
            }
            else
            {
                strBuildObj.Append("font-size: 11pt;  vertical-align:middle; background-color:#808080'><b>" + ((DataRowView)cmbCommitteeNames.SelectedItem).Row.ItemArray[1].ToString() + "</b></td></tr>");
            }
            strBuildObj.Append("<tr><td colspan='15' style='font-family:Century Gothic;border-style: solid; border-color: inherit; border-width: 1px; text-align:center;");
            if (startReportDateChanged == 0 && endReportDateChanged == 0)
            {
                strBuildObj.Append("font-size: 11pt;  vertical-align:middle; background-color:#808080'><b>Tenders for FY " + ((DataRowView)cmbFiscalYear.SelectedItem).Row.ItemArray[1].ToString() + "</b></td></tr>");
            }
            else
            {
                strBuildObj.Append("font-size: 11pt;  vertical-align:middle; background-color:#808080'><b>Tenders between " + dtpTenderPublishStartDate.Value.ToString("dd/MMM/yyyy") + " and " + dtpTenderPublishEndDate.Value.ToString("dd/MMM/yyyy") + "</b></td></tr>");
            }
            strBuildObj.Append("<tr><td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px; overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>SI.</b></td>");
            strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Tender No.</b></td>");
            strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Tender Title</b></td>");
            strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Project Code</b></td>");
            strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Department</b></td>");
            strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Tender Publish Date</b></td>");
            strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px;  overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Type of Tender</b></td>");
            strBuildObj.Append("<td colspan='4' style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px; background-color:#E6B8B7; overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Tenderer Statistics</b>");
            strBuildObj.Append("<table border=\"0\">");
            strBuildObj.Append("<tr><td style=\"font-family:Century Gothic;width:150px;font-size: 11pt;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;\"><b>No. Invited</b><span><i>(if Limited)</i></span></td>");
            strBuildObj.Append("<td style=\"font-family:Century Gothic;width:150px;font-weight: bold;font-size: 11pt;font-weight: bold;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;\"><b>No. Purchased</b></td>");
            strBuildObj.Append("<td style=\"font-family:Century Gothic;width:150px;font-weight: bold;font-size: 11pt;font-weight: bold;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;\"><b>No. Submitted</b></td>");
            strBuildObj.Append("<td style=\"font-family:Century Gothic;width:150px;font-weight: bold;font-size: 11pt;font-weight: bold;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;\"><b>Tenderer List</b></td>");
            strBuildObj.Append("</tr></table></td>");
            strBuildObj.Append("<td style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px; background-color:#B8CCE4; overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Tender Status</b></td>");
            strBuildObj.Append("<td colspan='3' style='font-family:Century Gothic;margin: 0px; text-align:center;height: 35px; font-size: 11pt; vertical-align:middle; border: solid 1px; background-color:#EBF1DE; overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Award Details</b>");
            strBuildObj.Append("<table border=\"0\">");
            strBuildObj.Append("<tr><td style=\"font-family:Century Gothic;width:150px;font-weight: bold;font-size: 11pt;font-weight: bold;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;\"><b>Successful Tenderer</b></td>");
            strBuildObj.Append("<td style=\"font-family:Century Gothic;width:150px;font-weight: bold;font-size: 11pt;font-weight: bold;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;\"><b>Awarding Value</b></td>");
            strBuildObj.Append("<td style=\"font-family:Century Gothic;width:150px;font-weight: bold;font-size: 11pt;font-weight: bold;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 0px;padding-top: 0px;height: 35px;\"><b>Contract No.</b></td>");
            strBuildObj.Append("</tr></table></td></tr>");

            if (dtTenderInfo.Rows.Count != 0)
            {
                foreach (DataRow rowData in dtTenderInfo.Rows)
                {
                    strBuildObj.Append("<tr><td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[0] + "</td>");

                    strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[1] + "</td>");

                    strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[2] + "</td>");

                    strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[3] + "</td>");

                    strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[4] + "</td>");

                    strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[5] + "</td>");

                    strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[6] + "</td>");

                    strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[7] + "</td>");

                    strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[8] + "</td>");

                    strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[9] + "</td>");

                    strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>");

                    for (int counter = 0; counter < rowData[10].ToString().Split(',').Length; counter++)
                    {
                        strBuildObj.Append("<div style='font-family:Century Gothic;font-size: 10pt;'>" + rowData[10].ToString().Split(',')[counter] + "</div>");

                    }

                    strBuildObj.Append("</td>");

                    strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[11] + "</td>");

                    strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[12] + "</td>");

                    strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[13] + "</td>");

                    strBuildObj.Append("<td style='font-family:Century Gothic;font-size: 10pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[14] + "</td>");

                    //if (fyId == 0)
                    //    strBuildObj.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'><b>" + projIds[1] + "</b></td>");                                                                
                    strBuildObj.Append("</tr>");

                }
                strBuildObj.Append("<tr><td colspan='15' style=\"width:auto;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b style=\"font-style: italic\">This report is generated by TCMS dated :</b><b>" + DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss") + "</b></td></tr>");
                lblTotRecCount.Text = "Total Records Count=" + dtTenderInfo.Rows.Count;
            }
            else
            {
                lblTotRecCount.Text = "Total Records Count=0";
                MessageBox.Show("No data exist for selected options", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            strBuildObj.Append("</table>");
            webReport.DocumentText = strBuildObj.ToString();
            webReport.ScrollBarsEnabled = true;
        }

        static int sNoCounter = 0;

        private DataTable TenderInfo(ref DataTable dtTenderInfo, string sqlCommReport)
        {
            DataTable dtMainCommittee = dalObj.GetDataFromDB("MainCommittee", sqlCommReport);
            int rowCounter = 0;           
            
            while (rowCounter < dtMainCommittee.Rows.Count)
            {                
                DataRow dr = dtTenderInfo.NewRow();
                dr[0] = sNoCounter + 1;
                dr[1] = dtMainCommittee.Rows[rowCounter][1];
                dr[2] = dtMainCommittee.Rows[rowCounter][2];
                dr[3] = dtMainCommittee.Rows[rowCounter][3];
                dr[4] = dtMainCommittee.Rows[rowCounter][4];

                string projId = dtMainCommittee.Rows[rowCounter][0].ToString();
                string sqlGetTenderPublishDateFromProjId = "SELECT REPLACE(CONVERT(nvarchar, TenderDatesInfo.ts_tender_invitation, 106), ' ', '-') AS TenderPublishDate from TenderDatesInfo inner join PROJECTS on PROJECTS.proj_id = TenderDatesInfo.proj_id " +
                "where (TenderDatesInfo.proj_id=" + projId + ") and TenderDatesInfo.ts_tender_invitation is not NULL";
                DataTable dtTenderInvitationDate = dalObj.GetDataFromDB("TenderInvitationDate", sqlGetTenderPublishDateFromProjId);
                if (dtTenderInvitationDate.Rows.Count != 0)
                {
                    dr[5] = dtTenderInvitationDate.Rows[0][0];
                }
                else
                {
                    dr[5] = "";
                }

                dr[6] = dtMainCommittee.Rows[rowCounter][5];

                string sqlTenderDatesInfo = "SELECT TenderDatesInfo.date_id, TenderDatesInfo.TenderSubmittedTime,COMPANY.co_name, TenderTypes.tender_type_short_name, " +
                "TenderDatesInfo.stage_id,TenderDatesInfo.Tender_Issued FROM TenderDatesInfo INNER JOIN PROJECTS ON PROJECTS.proj_id = TenderDatesInfo.proj_id INNER JOIN " +
                "COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id INNER JOIN TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id where TenderDatesInfo.proj_id=" + projId;

                DataTable dtTenderDatesInfo = dalObj.GetDataFromDB("TenderDatesInfo", sqlTenderDatesInfo);

                int totalInvitees = dtTenderDatesInfo.AsEnumerable().Where(t => t["tender_type_short_name"].ToString().Equals("L")).GroupBy(r => r.Field<Int32>("date_id"))
                .Select(grp => new
                {
                    Count = grp.Count()
                }).ToList().Count;
                if (totalInvitees != 0)
                {
                    dr[7] = totalInvitees;
                }
                else
                {
                    dr[7] = "-";
                }                 

                //string sqlFindTotalPurchased = "SELECT COUNT(ts_tender_issue) FROM TenderDatesInfo WHERE (proj_id = " + projId + ") and stage_id=2 and Tender_Issued=1";
                dr[8] = dtTenderDatesInfo.AsEnumerable().Where(t => (t.Field<Int32>("stage_id") == 2) && (t.Field<bool>("Tender_Issued") == true))
                    .Select(r => r.Field<Int32>("date_id")).ToList().Count();

                //FindTotal(sqlFindTotalPurchased);
                dr[9] = (from t in dtTenderDatesInfo.AsEnumerable()
                .Where(t => t["TenderSubmittedTime"] != null)
                         select t).ToList().Count;

                if (dtTenderDatesInfo.Rows.Count != 0)
                {
                    dr[10] = string.Join(",", dtTenderDatesInfo.AsEnumerable()
                    .Select(x => x["co_name"].ToString())
                    .ToArray());
                }
                else
                {
                    dr[10] = "";
                }
                dr[11] = dtMainCommittee.Rows[rowCounter][6];
                if (dtMainCommittee.Rows[rowCounter][7].ToString() != "") // Awarding Value
                {
                    dr[13] = string.Format("{0:#,##0.00}", double.Parse(dtMainCommittee.Rows[rowCounter][7].ToString())); // dtMainCommittee.Rows[rowCounter][7];
                }
                else
                {
                    dr[13] = "";
                }
                dr[12] = dtMainCommittee.Rows[rowCounter][9]; // Successful Bidder
                dr[14] = dtMainCommittee.Rows[rowCounter][8]; //Contract No.                
                dtTenderInfo.Rows.Add(dr);
                dtTenderInfo.AcceptChanges();
                rowCounter++;
                sNoCounter++;
            }
            return dtTenderInfo;

        }

        private string FindTotal(string sqlFindTotInvitees)
        {
            DataTable dtFindTotInvitees = dalObj.GetDataFromDB("FindTotal", sqlFindTotInvitees);
            string count = null;
            if (dtFindTotInvitees.Rows.Count != 0)
            {
                count = dtFindTotInvitees.Rows[0][0].ToString();
            }
            else
            {
                count = "0";
            }
            return count;
        }

        private string GetTendererList(string sqlFindTotInvitees)
        {

            DataTable dtTendererList = dalObj.GetDataFromDB("TendererList", sqlFindTotInvitees);

            string tendererNames = null;
            if (dtTendererList.Rows.Count != 0)
            {
                tendererNames = string.Join(",", dtTendererList.AsEnumerable()
                                .Select(x => x["co_name"].ToString())
                                .ToArray());
            }
            else
            {
                tendererNames = "";
            }
            return tendererNames;
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            comCls.ExportToExcel(webReport);
        }       

        private void dtpTenderPublishStartDate_ValueChanged(object sender, EventArgs e)
        {
            startReportDateChanged = 1;            
        }

        private void dtpTenderPublishEndDate_ValueChanged(object sender, EventArgs e)
        {
            endReportDateChanged = 1;            
        }       

        private void cmbFiscalYear_SelectedIndexChanged(object sender, EventArgs e)
        {
            startReportDateChanged = 0;
            endReportDateChanged = 0;   
        }
      
    }
}
