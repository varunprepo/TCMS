﻿namespace MDI_ParenrForm.Reports
{
    partial class frmCommittedContracts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbCommitteeNames = new System.Windows.Forms.ComboBox();
            this.cmbCommittedYear = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSubmitReport = new System.Windows.Forms.Button();
            this.btnExport = new System.Windows.Forms.Button();
            this.webReport = new System.Windows.Forms.WebBrowser();
            this.lblTotRecCount = new System.Windows.Forms.Label();
            this.awardEndDate = new System.Windows.Forms.Label();
            this.dtpAwardEndDate = new System.Windows.Forms.DateTimePicker();
            this.awardStartDate = new System.Windows.Forms.Label();
            this.dtpAwardStartDate = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbDepartments = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // cmbCommitteeNames
            // 
            this.cmbCommitteeNames.FormattingEnabled = true;
            this.cmbCommitteeNames.Location = new System.Drawing.Point(12, 41);
            this.cmbCommitteeNames.Name = "cmbCommitteeNames";
            this.cmbCommitteeNames.Size = new System.Drawing.Size(196, 21);
            this.cmbCommitteeNames.TabIndex = 0;
            // 
            // cmbCommittedYear
            // 
            this.cmbCommittedYear.FormattingEnabled = true;
            this.cmbCommittedYear.Location = new System.Drawing.Point(410, 41);
            this.cmbCommittedYear.Name = "cmbCommittedYear";
            this.cmbCommittedYear.Size = new System.Drawing.Size(121, 21);
            this.cmbCommittedYear.TabIndex = 1;
            this.cmbCommittedYear.SelectedIndexChanged += new System.EventHandler(this.cmbCommittedYear_SelectedIndexChanged);
            this.cmbCommittedYear.Enter += new System.EventHandler(this.cmbCommittedYear_Enter);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Committee Names";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(413, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Committed Year";
            // 
            // btnSubmitReport
            // 
            this.btnSubmitReport.Location = new System.Drawing.Point(106, 97);
            this.btnSubmitReport.Name = "btnSubmitReport";
            this.btnSubmitReport.Size = new System.Drawing.Size(100, 23);
            this.btnSubmitReport.TabIndex = 32;
            this.btnSubmitReport.Text = "Generate Report";
            this.btnSubmitReport.UseVisualStyleBackColor = true;
            this.btnSubmitReport.Click += new System.EventHandler(this.btnSubmitReport_Click);
            // 
            // btnExport
            // 
            this.btnExport.BackColor = System.Drawing.Color.Coral;
            this.btnExport.Location = new System.Drawing.Point(212, 97);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(103, 23);
            this.btnExport.TabIndex = 31;
            this.btnExport.Text = "Export To Excel";
            this.btnExport.UseVisualStyleBackColor = false;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // webReport
            // 
            this.webReport.Location = new System.Drawing.Point(18, 141);
            this.webReport.MinimumSize = new System.Drawing.Size(20, 20);
            this.webReport.Name = "webReport";
            this.webReport.Size = new System.Drawing.Size(1091, 451);
            this.webReport.TabIndex = 33;
            // 
            // lblTotRecCount
            // 
            this.lblTotRecCount.AutoSize = true;
            this.lblTotRecCount.Location = new System.Drawing.Point(18, 611);
            this.lblTotRecCount.Name = "lblTotRecCount";
            this.lblTotRecCount.Size = new System.Drawing.Size(0, 13);
            this.lblTotRecCount.TabIndex = 34;
            // 
            // awardEndDate
            // 
            this.awardEndDate.AutoSize = true;
            this.awardEndDate.Location = new System.Drawing.Point(705, 25);
            this.awardEndDate.Name = "awardEndDate";
            this.awardEndDate.Size = new System.Drawing.Size(85, 13);
            this.awardEndDate.TabIndex = 51;
            this.awardEndDate.Text = "Award End Date";
            // 
            // dtpAwardEndDate
            // 
            this.dtpAwardEndDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpAwardEndDate.Location = new System.Drawing.Point(704, 41);
            this.dtpAwardEndDate.Name = "dtpAwardEndDate";
            this.dtpAwardEndDate.Size = new System.Drawing.Size(90, 20);
            this.dtpAwardEndDate.TabIndex = 50;
            this.dtpAwardEndDate.ValueChanged += new System.EventHandler(this.dtpAwardEndDate_ValueChanged);
            // 
            // awardStartDate
            // 
            this.awardStartDate.AutoSize = true;
            this.awardStartDate.Location = new System.Drawing.Point(572, 25);
            this.awardStartDate.Name = "awardStartDate";
            this.awardStartDate.Size = new System.Drawing.Size(88, 13);
            this.awardStartDate.TabIndex = 49;
            this.awardStartDate.Text = "Award Start Date";
            // 
            // dtpAwardStartDate
            // 
            this.dtpAwardStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpAwardStartDate.Location = new System.Drawing.Point(571, 41);
            this.dtpAwardStartDate.Name = "dtpAwardStartDate";
            this.dtpAwardStartDate.Size = new System.Drawing.Size(90, 20);
            this.dtpAwardStartDate.TabIndex = 48;
            this.dtpAwardStartDate.ValueChanged += new System.EventHandler(this.dtpAwardStartDate_ValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(234, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 13);
            this.label3.TabIndex = 53;
            this.label3.Text = "Department";
            // 
            // cmbDepartments
            // 
            this.cmbDepartments.FormattingEnabled = true;
            this.cmbDepartments.Location = new System.Drawing.Point(231, 41);
            this.cmbDepartments.Name = "cmbDepartments";
            this.cmbDepartments.Size = new System.Drawing.Size(121, 21);
            this.cmbDepartments.TabIndex = 52;
            // 
            // frmCommittedContracts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1121, 636);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cmbDepartments);
            this.Controls.Add(this.awardEndDate);
            this.Controls.Add(this.dtpAwardEndDate);
            this.Controls.Add(this.awardStartDate);
            this.Controls.Add(this.dtpAwardStartDate);
            this.Controls.Add(this.lblTotRecCount);
            this.Controls.Add(this.webReport);
            this.Controls.Add(this.btnSubmitReport);
            this.Controls.Add(this.btnExport);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbCommittedYear);
            this.Controls.Add(this.cmbCommitteeNames);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmCommittedContracts";
            this.Text = "Committed Contracts Report";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbCommitteeNames;
        private System.Windows.Forms.ComboBox cmbCommittedYear;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnSubmitReport;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.WebBrowser webReport;
        private System.Windows.Forms.Label lblTotRecCount;
        private System.Windows.Forms.Label awardEndDate;
        private System.Windows.Forms.DateTimePicker dtpAwardEndDate;
        private System.Windows.Forms.Label awardStartDate;
        private System.Windows.Forms.DateTimePicker dtpAwardStartDate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbDepartments;
    }
}