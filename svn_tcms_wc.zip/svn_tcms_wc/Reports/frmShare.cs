﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;
using TenderTrackingSystem;
using System.Configuration;
using Microsoft.Office.Interop;
using MDI_ParenrForm;

namespace MDI_ParenrForm.Reports
{
    public partial class frmShare : Form
    {
        const int WORKSHEETSTARTROW = 1;
        const int WORKSHEETSTARTCOL = 1;

        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();  

        public frmShare()
        {
            InitializeComponent();

            

            //for (int columncount = 0; columncount < 3; columncount++)
            //{
            //    new DataGridViewColumn();
            //    DataGridViewColumn NewColumn = new DataGridViewColumn();
            //    if (columncount == 0)
            //     NewColumn.Name = "CompanyName";
            //    if (columncount == 1)
            //        NewColumn.Name = "Qatari";
            //    if (columncount == 2)
            //        NewColumn.Name = "Others";

            //    NewColumn.Width = 50;
            //    NewColumn.DefaultCellStyle.Font =
            //       new Font(dgvShare.DefaultCellStyle.Font, FontStyle.Italic);
            //    DataGridViewCell cell = new DataGridViewTextBoxCell();
            //    cell.Style.BackColor = Color.Wheat;
            //    NewColumn.CellTemplate = cell;
            //    dgvShare.Columns.Add(NewColumn);
            //}
            //DataGridViewRow NewRow;
            //byte charA = 0x41;
            //for (int rowOffset = 1; rowOffset <= 10; rowOffset++)
            //{
            //    int RowNumber = dgvShare.Rows.Add();
            //    NewRow = dgvShare.Rows[RowNumber];
            //    for (int columncount = 0; columncount < 3; columncount++)
            //    {
            //        NewRow.Cells[columncount].Value = ((char)(charA + columncount)).ToString() + rowOffset.ToString();
            //    }
            //}
        }
        string _fileName = string.Empty;
        private void btnExcel_Click(object sender, EventArgs e)
        {
            _fileName = SelectTextFile("@C:");
            export_datagridview_to_excel(dgvShare, _fileName);
        }
        private string SelectTextFile(string initialDirectory)
        {
            string strFile = string.Empty;
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.Filter = "Excel Path|*.xls|Excel Format|*.xlsx";
            saveFileDialog1.Title = "Save an Excel File";
            saveFileDialog1.ShowDialog();

            // If the file name is not an empty string open it for saving.
            if (saveFileDialog1.FileName != "")
            {
                // Saves the Image via a FileStream created by the OpenFile method.
                System.IO.FileStream fs =
                   (System.IO.FileStream)saveFileDialog1.OpenFile();

                strFile = saveFileDialog1.FileName;

                fs.Close();
            }
            return strFile;
        }
        public void export_datagridview_to_excel(DataGridView dgv, string excel_file)
        {
            int cols;
            //open file
            if (excel_file == "")
            {
                return;
            }
            StreamWriter wr = new StreamWriter(excel_file);

            //determine the number of columns and write columns to file
            cols = dgv.Columns.Count;
            for (int i = 0; i < cols; i++)
            {
                wr.Write(dgv.Columns[i].HeaderText.ToString().ToUpper() + "\t");
            }

            wr.WriteLine();

            //write rows to excel file
            for (int i = 0; i < (dgv.Rows.Count - 1); i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    if (dgv.Rows[i].Cells[j].Value != null)
                        wr.Write(dgv.Rows[i].Cells[j].Value + "\t");
                    else
                    {
                        wr.Write("\t");
                    }
                }

                wr.WriteLine();
            }

            //close file
            wr.Close();

            MessageBox.Show("Data Exported Successfully");
        }

        private void frmShare_Load(object sender, EventArgs e)
        {
            DAL dalObj = new DAL();

            dalObj.populateCmbBox("Select FiscalYear From FiscalYear", cmbYear);
            cmbYear.SelectedIndex = -1;

            LoadData();
        }
        DataTable dtTemp  = new DataTable(); 
        private void LoadData()
        {
           

            var col1 = new DataGridViewTextBoxColumn();
            var col2 = new DataGridViewTextBoxColumn();
            var col3 = new DataGridViewTextBoxColumn();

            dgvShare.Columns.AddRange(new DataGridViewColumn[] {col1, col2, col3});
            
            dgvShare.AutoGenerateColumns = false;
            dgvShare.AllowUserToAddRows = false;
            dgvShare.AutoResizeColumns();

            
            col1.DataPropertyName = "CompanyName";
            col1.HeaderText = "Company Name";
            col2.Width = 300; //182 

            col2.DataPropertyName = "Qatari";
            col2.HeaderText = "Qatari (%)";
            col2.Width = 95; //182 

            col3.DataPropertyName = "Others";
            col3.HeaderText = "Others (%)";
            col3.Width = 95; //182 
           // col2.LinkBehavior = LinkBehavior.NeverUnderline;

            DataTable dtProject = null;

            string[] projRows = new string[8];
            SqlConnection sqlConn = new SqlConnection(strCon);

            try
            {
                sqlConn.Open();
                DAL dalObj = new DAL(); //Dharan

               // string sqlQuery =  "SELECT co_name, qatari_share FROM COMPANY ";

                string sqlQuery = "SELECT co_name,qatari_share AS [Qatari (%)], 100 - qatari_share AS [Others (%)] FROM COMPANY ";

                    //WHERE  (qatari_share = 51)

                dtProject = dalObj.GetDataFromDB("Project", sqlQuery);
                DataTable finalDt = new DataTable("Project");
                finalDt.Columns.Add("CompanyName");
                finalDt.Columns.Add("Qatari");
                finalDt.Columns.Add("Others");  

                foreach (DataRow drProj in dtProject.Rows)
                {
                    DataRow dr = finalDt.NewRow();

                    dr[0] = drProj[0];   
                    dr[1] = drProj[1];   
                    dr[2] = drProj[2];  

                    finalDt.Rows.Add(dr);
                    finalDt.AcceptChanges();
                }

                BindingSource myBindingSource = new BindingSource(finalDt, null);

                dtTemp = finalDt;

                dgvShare.DataSource = myBindingSource;

                dgvShare.DefaultCellStyle.Font = new Font(dgvShare.DefaultCellStyle.Font, FontStyle.Italic);
                dgvShare.DefaultCellStyle.Font = new Font(dgvShare.DefaultCellStyle.Font, FontStyle.Bold);

                DataGridViewCell cell = new DataGridViewTextBoxCell();
                  cell.Style.BackColor = Color.Wheat;
                  cell.Style.ForeColor = Color.Red;
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }
           
        }

        private void txtShare_KeyDown(object sender, KeyEventArgs e)
        {
            string filterQuery = "";
            if (txtShare.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "Qatari like '" + "%" + txtShare.Text + "%" + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "Qatari like '" + "%" + txtShare.Text + "%" + "'";
                }
            }


            if (filterQuery == "")
            {
                GridFill("");
            }
            else
            {
                GridFill(filterQuery);
            }
        }

        private void txtShare_KeyPress(object sender, KeyPressEventArgs e)
        {

        }
        private void GridFill(string filterQuery)
        {
            DataTable dtTempForCombo = new DataTable();
            BindingSource myBindingSource = null;
            dtTempForCombo = dtTemp;
            int iCnt = dtTempForCombo.Rows.Count;
            DataTable dtCmbTbl = null;
            if (dtTempForCombo.Select(filterQuery).Length != 0)
            {
                dtCmbTbl = dtTempForCombo.Select(filterQuery).CopyToDataTable();
                int jCnt = dtCmbTbl.Rows.Count;
                try
                {
                    myBindingSource = new BindingSource(dtCmbTbl, null);
                    dgvShare.DataSource = myBindingSource;

                    dtTempForCombo = dtCmbTbl;

                    //dgView.ColumnHeadersDefaultCellStyle.BackColor = Color.Olive;
                    //dgView.ColumnHeadersDefaultCellStyle.ForeColor = Color.Blue;

                    //dgView.ColumnHeadersDefaultCellStyle.Font = new Font(dgView.Font, FontStyle.Bold);

                    dgvShare.EnableHeadersVisualStyles = false;
                    //dgvShare.Columns[1].Visible = false;
                   
                }
                catch (Exception ex)
                {
                    string exMsg = ex.Message;
                }
                finally
                {
                }
            }
            else
            {
                DataTable nullTable = new DataTable();
                dtCmbTbl = null;
                myBindingSource = new BindingSource(nullTable, null);
                dgvShare.DataSource = myBindingSource;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var excelApp = new Microsoft.Office.Interop.Excel.Application();
            excelApp.Visible = true;
            Microsoft.Office.Interop.Excel.Workbook excelbk = excelApp.Workbooks.Add(Type.Missing);
            Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet1 = (Microsoft.Office.Interop.Excel.Worksheet)excelbk.Worksheets["Sheet1"];
            int worksheetRow = WORKSHEETSTARTROW;
            for (int rowCount = 0; rowCount < dgvShare.Rows.Count - 1; rowCount++)
            {
                int worksheetcol = WORKSHEETSTARTCOL;
                for (int colCount = 0; colCount < dgvShare.Columns.Count - 1; colCount++)
                {
                    Microsoft.Office.Interop.Excel.Range xlRange = (Microsoft.Office.Interop.Excel.Range)xlWorkSheet1.Cells[worksheetRow, worksheetcol];
                    xlRange.Value2 = dgvShare.Rows[rowCount].Cells[colCount].Value.ToString();
                    
                    //xlRange.Font.Background = dgvShare.Rows[rowCount].Cells[colCount].Style.BackColor;
                    xlRange.Font.Color = dgvShare.Rows[rowCount].Cells[colCount].Style.ForeColor.ToArgb();          

                    if (dgvShare.Rows[rowCount].Cells[colCount].Style.Font != null)
                    {
                        xlRange.Font.Bold = dgvShare.Rows[rowCount].Cells[colCount].Style.Font.Bold;
                        xlRange.Font.Italic = dgvShare.Rows[rowCount].Cells[colCount].Style.Font.Italic;
                        xlRange.Font.Underline = dgvShare.Rows[rowCount].Cells[colCount].Style.Font.Underline;
                        xlRange.Font.FontStyle = dgvShare.Rows[rowCount].Cells[colCount].Style.Font.FontFamily;
                    }
                    worksheetcol += 1;
                }
                worksheetRow += 1;
            }
        }

        private void btnCrystalBiddersReport_Click(object sender, EventArgs e)
        {
            frmGenerateBiddersReports frmGBidRep = new frmGenerateBiddersReports();
            frmGBidRep.StartPosition = FormStartPosition.CenterScreen;
            frmGBidRep.ShowDialog(); 

            //BiddersShareHoldingReport.BiddersShareHoldingReport bidShareHoldRpt = new BiddersShareHoldingReport.BiddersShareHoldingReport();
            //frmViewBiddersShareHolding frmBidShare = new frmViewBiddersShareHolding();             
            //frmBidShare.BiddersShareHoldingReport1.RecordSelectionFormula = "FiscalYear = 2012-13";
            //frmBidShare.Show();
            //frmBidShare.BiddersShareHoldingReport1.Database.Tables[0].Fields[3].Equals("2012-13"); 
 

        }
    }
}
