﻿namespace MDI_ParenrForm.Reports
{
    partial class frmShare
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvShare = new System.Windows.Forms.DataGridView();
            this.label13 = new System.Windows.Forms.Label();
            this.txtShare = new System.Windows.Forms.TextBox();
            this.cmbYear = new System.Windows.Forms.ComboBox();
            this.btnExcel = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnCrystalBiddersReport = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvShare)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvShare
            // 
            this.dgvShare.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvShare.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvShare.Location = new System.Drawing.Point(23, 124);
            this.dgvShare.Name = "dgvShare";
            this.dgvShare.Size = new System.Drawing.Size(583, 345);
            this.dgvShare.TabIndex = 0;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Blue;
            this.label13.Location = new System.Drawing.Point(161, 36);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(280, 18);
            this.label13.TabIndex = 32;
            this.label13.Text = "List of Companies with Qatari Share";
            // 
            // txtShare
            // 
            this.txtShare.Location = new System.Drawing.Point(115, 91);
            this.txtShare.Name = "txtShare";
            this.txtShare.Size = new System.Drawing.Size(100, 20);
            this.txtShare.TabIndex = 33;
            this.txtShare.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtShare_KeyDown);
            this.txtShare.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtShare_KeyPress);
            // 
            // cmbYear
            // 
            this.cmbYear.FormattingEnabled = true;
            this.cmbYear.Location = new System.Drawing.Point(295, 90);
            this.cmbYear.Name = "cmbYear";
            this.cmbYear.Size = new System.Drawing.Size(87, 21);
            this.cmbYear.TabIndex = 34;
            // 
            // btnExcel
            // 
            this.btnExcel.BackColor = System.Drawing.Color.Goldenrod;
            this.btnExcel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcel.Location = new System.Drawing.Point(23, 487);
            this.btnExcel.Name = "btnExcel";
            this.btnExcel.Size = new System.Drawing.Size(104, 23);
            this.btnExcel.TabIndex = 35;
            this.btnExcel.Text = "Export To Excel";
            this.btnExcel.UseVisualStyleBackColor = false;
            this.btnExcel.Click += new System.EventHandler(this.btnExcel_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Goldenrod;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(164, 487);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(104, 23);
            this.button1.TabIndex = 36;
            this.button1.Text = "Export To Excel";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 13);
            this.label1.TabIndex = 37;
            this.label1.Text = "Enter Percentage";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(230, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 38;
            this.label2.Text = "Fiscal Year";
            // 
            // btnCrystalBiddersReport
            // 
            this.btnCrystalBiddersReport.BackColor = System.Drawing.Color.Goldenrod;
            this.btnCrystalBiddersReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCrystalBiddersReport.Location = new System.Drawing.Point(295, 487);
            this.btnCrystalBiddersReport.Name = "btnCrystalBiddersReport";
            this.btnCrystalBiddersReport.Size = new System.Drawing.Size(196, 23);
            this.btnCrystalBiddersReport.TabIndex = 39;
            this.btnCrystalBiddersReport.Text = "Bidders Report With Qatari Shares";
            this.btnCrystalBiddersReport.UseVisualStyleBackColor = false;
            this.btnCrystalBiddersReport.Click += new System.EventHandler(this.btnCrystalBiddersReport_Click);
            // 
            // frmShare
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(626, 537);
            this.Controls.Add(this.btnCrystalBiddersReport);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnExcel);
            this.Controls.Add(this.cmbYear);
            this.Controls.Add(this.txtShare);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.dgvShare);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmShare";
            this.Text = "Qatari Share";
            this.Load += new System.EventHandler(this.frmShare_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvShare)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvShare;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtShare;
        private System.Windows.Forms.ComboBox cmbYear;
        private System.Windows.Forms.Button btnExcel;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnCrystalBiddersReport;
    }
}