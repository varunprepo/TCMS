﻿namespace MDI_ParenrForm.Reports
{
    partial class frmCompanyParticipationInDifferentTenders
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAssignedQS = new System.Windows.Forms.Label();
            this.webReport = new System.Windows.Forms.WebBrowser();
            this.btnGenerateReport = new System.Windows.Forms.Button();
            this.btnExportToExcel = new System.Windows.Forms.Button();
            this.lblTotRecCount = new System.Windows.Forms.Label();
            this.cmbCompanyName = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lblAssignedQS
            // 
            this.lblAssignedQS.AutoSize = true;
            this.lblAssignedQS.Location = new System.Drawing.Point(487, 43);
            this.lblAssignedQS.Name = "lblAssignedQS";
            this.lblAssignedQS.Size = new System.Drawing.Size(82, 13);
            this.lblAssignedQS.TabIndex = 0;
            this.lblAssignedQS.Text = "Company Name";
            // 
            // webReport
            // 
            this.webReport.Location = new System.Drawing.Point(29, 139);
            this.webReport.MinimumSize = new System.Drawing.Size(20, 20);
            this.webReport.Name = "webReport";
            this.webReport.Size = new System.Drawing.Size(1007, 430);
            this.webReport.TabIndex = 8;
            // 
            // btnGenerateReport
            // 
            this.btnGenerateReport.Location = new System.Drawing.Point(425, 101);
            this.btnGenerateReport.Name = "btnGenerateReport";
            this.btnGenerateReport.Size = new System.Drawing.Size(98, 23);
            this.btnGenerateReport.TabIndex = 9;
            this.btnGenerateReport.Text = "Generate Report";
            this.btnGenerateReport.UseVisualStyleBackColor = true;
            this.btnGenerateReport.Click += new System.EventHandler(this.btnGenerateReport_Click);
            // 
            // btnExportToExcel
            // 
            this.btnExportToExcel.BackColor = System.Drawing.Color.Coral;
            this.btnExportToExcel.Location = new System.Drawing.Point(540, 101);
            this.btnExportToExcel.Name = "btnExportToExcel";
            this.btnExportToExcel.Size = new System.Drawing.Size(98, 23);
            this.btnExportToExcel.TabIndex = 10;
            this.btnExportToExcel.Text = "Export To Excel";
            this.btnExportToExcel.UseVisualStyleBackColor = false;
            this.btnExportToExcel.Click += new System.EventHandler(this.btnExportToExcel_Click);
            // 
            // lblTotRecCount
            // 
            this.lblTotRecCount.AutoSize = true;
            this.lblTotRecCount.Location = new System.Drawing.Point(910, 581);
            this.lblTotRecCount.Name = "lblTotRecCount";
            this.lblTotRecCount.Size = new System.Drawing.Size(0, 13);
            this.lblTotRecCount.TabIndex = 13;
            // 
            // cmbCompanyName
            // 
            this.cmbCompanyName.FormattingEnabled = true;
            this.cmbCompanyName.Location = new System.Drawing.Point(364, 59);
            this.cmbCompanyName.Name = "cmbCompanyName";
            this.cmbCompanyName.Size = new System.Drawing.Size(332, 21);
            this.cmbCompanyName.TabIndex = 15;
            // 
            // frmCompanyParticipationInDifferentTenders
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FloralWhite;
            this.ClientSize = new System.Drawing.Size(1048, 613);
            this.Controls.Add(this.cmbCompanyName);
            this.Controls.Add(this.lblTotRecCount);
            this.Controls.Add(this.btnExportToExcel);
            this.Controls.Add(this.btnGenerateReport);
            this.Controls.Add(this.webReport);
            this.Controls.Add(this.lblAssignedQS);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmCompanyParticipationInDifferentTenders";
            this.Text = "Company Participation In Different Tenders";
            this.Load += new System.EventHandler(this.frmCompanyParticipationInDifferentTenders_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAssignedQS;
        private System.Windows.Forms.WebBrowser webReport;
        private System.Windows.Forms.Button btnGenerateReport;
        private System.Windows.Forms.Button btnExportToExcel;
        private System.Windows.Forms.Label lblTotRecCount;
        private System.Windows.Forms.ComboBox cmbCompanyName;
    }
}