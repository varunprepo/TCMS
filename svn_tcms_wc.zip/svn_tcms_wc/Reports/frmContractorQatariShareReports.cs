﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TenderTrackingSystem;
using System.IO;

namespace MDI_ParenrForm.Reports
{
    public partial class frmContractorQatariShareReports : Form
    {
        public frmContractorQatariShareReports()
        {
            InitializeComponent();
            CommonClass commCls = new CommonClass("");
            string sqlQuery = @"SELECT COMPANY.co_id, COMPANY.co_name, COMPANY.block_listed, COMPANY_TYPE.co_type_id FROM COMPANY INNER JOIN COMPANY_TYPE ON COMPANY.co_type_id = COMPANY_TYPE.co_type_id " +
            " WHERE COMPANY.co_name <>'' and (COMPANY.co_id <> 425) Order by Co_Name"; //(COMPANY.co_category_id<>4) and (COMPANY_TYPE.co_type_id IN (" + chkCmpFilter + ",4)) and 
            commCls.PopulateComboBox(cmbContractorOrCompanyName, sqlQuery, "co_id", "co_name");             
        }       
        
        private void cmbContractorOrCompanyName_SelectionChangeCommitted(object sender, EventArgs e)
        {
            try
            {
                DAL dalObj = new DAL();
                DataTable dtObj = null;

                dtObj = dalObj.GetDataFromDB("BiddersShareHolding", "SELECT DISTINCT COMPANY.co_name, COMPANY.qatari_share,(100 - COMPANY.qatari_share) as [Others_Share] " +
                "FROM COMPANY INNER JOIN TenderDatesInfo ON COMPANY.co_id = TenderDatesInfo.co_id INNER JOIN " +
                "PROJECTS ON PROJECTS.proj_id = TenderDatesInfo.proj_id INNER JOIN FiscalYear ON PROJECTS.FYID = FiscalYear.FYID INNER JOIN COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id " +
                "WHERE (COMPANY.co_name='" + ((DataRowView)cmbContractorOrCompanyName.SelectedItem).Row.ItemArray[1].ToString() + "')");

                StringBuilder strBuildObj = new StringBuilder();
                strBuildObj.Append("<table width='100%' cellpadding='0' cellspacing='0' style='border: solid 1px;'> <tr><td colspan='2' style='text-align:center;height: 35px;font-size: 14pt ;font-weight:bold;");
                strBuildObj.Append(" vertical-align:middle;border: solid 1px;background-color:#C0D9AF'><b>Contractor Qatari Share Reports</b></td></tr><tr><td style='border-style: solid; border-color: inherit; border-width: 1px; text-align:center;");
                strBuildObj.Append("font-size: 14pt; font-weight:bold; vertical-align:middle; background-color:#63D1F4'><b>Company Name</b></td><td style='margin: 0px; text-align:center;height: 35px; font-size: 14pt;");
                strBuildObj.Append("font-weight:bold; vertical-align:middle; border: solid 1px; background-color:#FFFF00; overflow: auto; float: inherit; display: table-cell; position:relative; table-layout: auto;'><b>Shareholding as per CR (%)</b>");
                strBuildObj.Append("<table> <tr><td style='padding:top; margin: inherit; text-align:center; height: 40px; font-size: 14pt; font-weight:bold; vertical-align:middle; border:1; background-color:#ADD8E6; width: 320px;'><b>Qatari (%)</b></td>");
                strBuildObj.Append("<td style='padding: inherit; margin: inherit; text-align:center; height: 40px; font-size: 14pt; font-weight:bold; vertical-align:middle; border:1; background-color:#ADD8E6; width: 320px;'><b>Others (%)</b></td></tr></table></td></tr>");
                if (dtObj.Rows.Count != 0)
                {                  
                    Int16 rowCounter = 0;
                    while (rowCounter < dtObj.Rows.Count)
                    {
                        strBuildObj.Append("<tr><td style='border-style: solid; border-color: inherit; border-width: 1px; text-align:center;font-size: 12pt; vertical-align:middle;background-color:#63D1F4'>" + dtObj.Rows[rowCounter][0].ToString() + "</td><td><table><tr>");
                        if (dtObj.Rows[rowCounter][1].ToString().Length == 1)
                            strBuildObj.Append("<td style='padding:inherit; margin: inherit;border-style: solid; border-width: 1px; text-align:center; height: 40px; font-size: 12pt; vertical-align:middle; background-color:#ADD8E6; width: 309px;'>" + dtObj.Rows[rowCounter][1].ToString() + "</td>");
                        else
                            strBuildObj.Append("<td style='padding:inherit; margin: inherit;border-style: solid; border-width: 1px; text-align:center; height: 40px; font-size: 12pt; vertical-align:middle; background-color:#ADD8E6; width: 300px;'>" + dtObj.Rows[rowCounter][1].ToString() + "</td>");
                        if (dtObj.Rows[rowCounter][2].ToString().Length == 1)
                            strBuildObj.Append("<td style='padding:inherit;margin: inherit;border-style: solid; border-width: 1px; text-align:center; height: 40px; font-size: 12pt; vertical-align:middle; background-color:#ADD8E6; width: 309px;'>" + dtObj.Rows[rowCounter][2].ToString() + "</td>");
                        else
                            strBuildObj.Append("<td style='padding: inherit;margin: inherit;border-style: solid; border-width: 1px; text-align:center; height: 40px; font-size: 12pt; vertical-align:middle; background-color:#ADD8E6; width: 300px;'>" + dtObj.Rows[rowCounter][2].ToString() + "</td>");
                        strBuildObj.Append("</tr></table></td></tr>");
                        rowCounter++;
                    }
                    strBuildObj.Append("<tr><td colspan='2' style=\"width:auto;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b style=\"font-style: italic\">This report is generated by TCMS dated :</b><b>" + DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss") + "</b></td></tr>");
                    strBuildObj.Append("</table>");
                    wbReport.DocumentText = strBuildObj.ToString();
                    wbReport.ScrollBarsEnabled = true;
                }
                else
                {
                    strBuildObj.Append("</table>");
                    wbReport.DocumentText = strBuildObj.ToString();
                    MessageBox.Show("No data exist for selected Company", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while creating the report", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        char lastChar = ' ';
       
        private void cmbContractorOrCompanyName_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            string strToFind;

            // if first char
            if (lastChar == 0)
                strToFind = ch.ToString();
            else
                strToFind = lastChar.ToString() + ch;

            // set first char
            lastChar = ch;

            // find first item that exactly like strToFind
            int idx = cmbContractorOrCompanyName.FindStringExact(strToFind);

            // if not found, find first item that start with strToFind
            if (idx == -1) idx = cmbContractorOrCompanyName.FindString(strToFind);

            if (idx == -1) return;

            cmbContractorOrCompanyName.SelectedIndex = idx;

            e.Handled = true;
            cmbContractorOrCompanyName_SelectionChangeCommitted(sender, e);
        }

        private void btnExportToExcel_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult result = saveFileDialog1.ShowDialog();
                //string strFileName = "ExportExcel.xls";
                //saveFileDialog1.FileName = "ExportExcel.xls";
                string strFileName = saveFileDialog1.FileName.ToString();
                StreamWriter writer = new StreamWriter(strFileName);
                writer.Write(wbReport.DocumentText.ToString());
                writer.Close();
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
        } 
    }
}
