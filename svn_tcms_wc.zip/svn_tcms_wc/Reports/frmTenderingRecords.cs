﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TenderTrackingSystem;

namespace MDI_ParenrForm.Reports
{
    public partial class frmTenderingRecords : Form
    {
        DAL dalObj = null;
        CommonClass comCls = null;
        public frmTenderingRecords()
        {
            InitializeComponent();
            dalObj = new DAL();
            comCls = new CommonClass("");    
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtStartReportDate.Text.Trim() == "")
                {
                    MessageBox.Show("Start Date cannot be left blank", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtStartReportDate.Focus();
                    return;
                }

                string sqlQuery = null;                 
                     
                sqlQuery = "SELECT PROJECTS.project_code AS [Project Code], PROJECTS.project_newname_en AS [Project Title], PROJECTS.tender_no AS [Tender Number]," +
                "TenderStatus.Status_Name AS [Tender Status], CONTRACTORS.contract_no AS [Contract No.], STAGES.Stage_Name AS [Stage Name]," +
                "TenderDatesInfo.ptd_receive_on AS [Receive On], TenderDatesInfo.ptd_purpose AS Purpose, TenderDatesInfo.ptd_assign_qs AS [Assign QS]," + 
                "TenderDatesInfo.ptd_qs_working_status AS [QS Working Status], TenderDatesInfo.ptd_sent_for_rev AS [Sent To Dept for Review]," + 
                "TenderDatesInfo.ptd_tendec_doc_cur_status AS [Tender doc  Status], TenderDatesInfo.ptd_forwarded_to_dep AS [Forwarded to Dept]," + 
                "TenderDatesInfo.ts_receive_on AS [(For Tendering) Receive on], TenderDatesInfo.ts_issue_handling AS [Issue Handling By]," + 
                "TenderDatesInfo.ts_return_to_dept AS [Return To Dept], TenderDatesInfo.ts_receive_from_dept AS [Receive from Dept]," + 
                "TenderDatesInfo.ts_pr_advertise AS [Sent to PR for Advertisement], TenderDatesInfo.ts_closing_s1 AS [Closing Date]," + 
                "TenderDatesInfo.ts_modified_closing AS [Modified Closing Date], TenderDatesInfo.eval_tender_opening AS [Tender Opening Date]," + 
                "TenderDatesInfo.eval_tender_doc_receive_from_cd AS [Doc Receive from CD], TenderDatesInfo.eval_tech_sent1 AS [Date Sent (Tech Eval)]," +
                "TenderDatesInfo.eval_tech_receive1 AS [Date Receive (Tech Eval)], TenderDatesInfo.eval_com_sent1 AS [Date Sent (Com Eval)]," +
                "TenderDatesInfo.eval_com_receive1 AS [Date Receive (Com Eval)], TenderDatesInfo.eval_no_of_meetings AS [No. of Meetings]," + 
                "TenderDatesInfo.eval_tender_award_approval AS [Tender Award Approval Date], CONTRACTORS.cp_received_of_doc AS [Receive of Award Document]," +
                "CONTRACTORS.cp_tender_award AS [Tender Award Date], CONTRACTORS.cp_request_start_date AS [Request Dept to Provide start date]," + 
                "CONTRACTORS.cp_start_date_receive AS [Start Date Receive], CONTRACTORS.cp_notice_contractor_to_sign AS [Notice to Contractor to Sign]," +
                "CONTRACTORS.cp_due_date_pb AS [Due Date of Sbmission of Performance Bond], CONTRACTORS.cp_contractor_sign AS [Contractor Sign]," + 
                "CONTRACTORS.cp_sent_dep_sign AS [Sent to Dept for Signature], CONTRACTORS.cp_receive_dep_sent_prsd AS [Receive from Dept for PRSD sign]," +
                "CONTRACTORS.cp_sent_fd_commit AS [Send to Finance Department for Commitment], CONTRACTORS.cp_receive_fd_commit AS [Receive from Finance Department]," +
                "CONTRACTORS.cp_distribution AS Distribution, TenderDatesInfo.remarks AS Remarks " +
                "FROM PROJECTS INNER JOIN TenderDatesInfo ON PROJECTS.proj_id = TenderDatesInfo.proj_id INNER JOIN TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id INNER JOIN ";
                if (txtEndReportDate.Text.Trim() != "")
                {
                    sqlQuery = sqlQuery + "STAGES ON PROJECTS.stage_id = STAGES.stage_id LEFT OUTER JOIN CONTRACTORS ON PROJECTS.proj_id = CONTRACTORS.proj_id WHERE (TenderDatesInfo.create_date between CONVERT(nvarchar,'" + dtpStartReportDate.Text + "', 106) and CONVERT(nvarchar,'" + dtpEndReportDate.Text + "', 106)) ";
                }
                else
                {
                    sqlQuery = sqlQuery + "STAGES ON PROJECTS.stage_id = STAGES.stage_id LEFT OUTER JOIN CONTRACTORS ON PROJECTS.proj_id = CONTRACTORS.proj_id WHERE (TenderDatesInfo.create_date between CONVERT(nvarchar,'" + dtpStartReportDate.Text + "', 106) and CONVERT(nvarchar,'" + DateTime.Now.ToString().Split(' ')[0] + "', 106)) ";
                }

                sqlQuery = sqlQuery +"AND (TenderDatesInfo.co_id IS NULL) AND (TenderDatesInfo.ts_tender_issue IS NULL) ORDER BY PROJECTS.proj_id, TenderDatesInfo.stage_id";

                DataTable dtProjectStagesReport = dalObj.GetDataFromDB("ProjectStagesReport", sqlQuery);
                StringBuilder strBuilder = new StringBuilder();
                lblTotRecords.Visible = true;
                if (dtProjectStagesReport.Rows.Count == 0)
                {
                    lblTotRecords.Text = "Total Records Count=0";
                }
                else
                {
                    lblTotRecords.Text = "Total Records Count=" + dtProjectStagesReport.Rows.Count;
                }

                strBuilder = CreateListOfContractsReport(strBuilder, dtProjectStagesReport);
                webReport.DocumentText = strBuilder.ToString();
                webReport.ScrollBarsEnabled = true;

            }
            catch (Exception)
            {
                MessageBox.Show("Error occurred displaying records", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private StringBuilder CreateListOfContractsReport(StringBuilder strBuilder, DataTable dtReports)
        {
            strBuilder.Append("<table style='border: solid 1px #506E87; width:100%'><tr>");
            strBuilder.Append("<td colspan='42' style='text-align:center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;'><b> Tendering Records Report </b></td></tr>");
            strBuilder.Append("<tr><td colspan='7'></td>");
            strBuilder.Append("<td colspan='7' style='text-align:center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;'><b>Prepare Tender Documents</b></td>");
            strBuilder.Append("<td colspan='7' style='text-align:center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;'><b>Tendering Stage (Stage 2)</b></td>");
            strBuilder.Append("<td colspan='8' style='text-align:center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;'><b>Tender Evaluation and Award (Stage 3)</b></td>");
            strBuilder.Append("<td colspan='12' style='text-align:center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;'><b>Contract Process (Stage 4)</b></td>");
            strBuilder.Append("<td></td>");
            strBuilder.Append("</tr>");
            strBuilder.Append("<tr>" +

            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>SNo.</b></td>" +

            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Project Code</b></td>" +

            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Project Title</b></td>" +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Tender Number</b></td>" +

            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Tender Status</b></td>" +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Contract No.</b></td>" +

            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Stage Name</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Receive On</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Purpose</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Assign QS</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>QS Working Status</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Sent To Dept for Review</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Tender doc  Status</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Forwarded to Dept</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>(For Tendering) Receive on</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Issue Handling By</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Return To Dept</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Receive from Dept</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Sent to PR for Advertisement</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Closing Date</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Modified Closing Date</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Tender Opening Date</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Doc Receive from CD</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Date Sent (Tech Eval)</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Date Receive (Tech Eval)</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Date Sent (Com Eval)</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Date Receive (Com Eval)</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>No. of Meetings</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Tender Award Approval Date</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Receive of Award Document</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Tender Award Date</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Request Dept to Provide start date</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Start Date Receive</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Notice to Contractor to Sign</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Due Date of Sbmission of Performance Bond</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Contractor Sign</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Sent to Dept for Signature</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Receive from Dept for PRSD sign</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Send to Finance Department for Commitment</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Receive from Finance Department</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Distribution</b></td>  " +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Remarks</b></td>  " +

            " </tr>");

            if (dtReports.Rows.Count != 0)
            {
                int rowSNo = 0;
                foreach (DataRow colData in dtReports.Rows)
                {
                    rowSNo = rowSNo + 1;
                    strBuilder.Append("<tr>");
                    strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b>" + rowSNo + "</b></td>");

                    strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b>" + colData[0] + "</b></td>");

                    strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b>" + colData[1] + "</b></td>");

                    if (colData[2] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b>" + colData[2] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b></b></td>");
                    }

                    strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b>" + colData[3] + "</b></td>");

                    if (colData[4] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[4] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b></b></td>");
                    }

                    strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[5] + "</b></td>");

                    if (colData[6] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[6] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[7] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[7] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[8] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[8] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[9] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[9] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[10] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[10] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[11] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[11] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[12] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[12] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[13] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[13] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[14] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[14] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[15] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[15] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[16] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[16] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[17] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[17] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[18] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[18] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[19] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[19] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[20] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[20] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[21] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[21] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[22] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[22] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[23] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[23] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[24] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[24] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[25] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[25] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[26] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[26] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[27] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[27] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[28] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[28] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[29] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[29] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[30] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[30] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[31] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[31] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[32] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[32] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[33] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[33] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[34] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[34] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[35] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[35] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[36] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[36] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[37] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[37] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[38] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[38] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[39] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[39] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    }

                    if (colData[40] != DBNull.Value)
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[40] + "</b></td>");
                    }
                    else
                    {
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                    } 

                    strBuilder.Append("</tr>");
                }
                strBuilder.Append("<tr><td colspan='42' style=\"width:auto;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b style=\"font-style: italic\">This report is generated by TCMS dated :</b><b>" + DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss") + "</b></td></tr>");
                strBuilder.Append("</table>");
            }
            else
            {
                MessageBox.Show("No data exist within selected dates", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                strBuilder.Append("</table>");
            }
            return strBuilder;
        }

        private void dtpStartReportDate_ValueChanged(object sender, EventArgs e)
        {
            txtStartReportDate.Text = dtpStartReportDate.Text;
        }

        private void dtpEndReportDate_ValueChanged(object sender, EventArgs e)
        {
            txtEndReportDate.Text = dtpEndReportDate.Text;
        }

        private void btnExportToExcel_Click(object sender, EventArgs e)
        {
            comCls.ExportToExcel(webReport);
        }
    }
}
