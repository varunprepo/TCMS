﻿namespace MDI_ParenrForm.Reports
{
    partial class frmTenderCommAward
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.webReport = new System.Windows.Forms.WebBrowser();
            this.btnSubmitReport = new System.Windows.Forms.Button();
            this.btnExport = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbFiscalYear = new System.Windows.Forms.ComboBox();
            this.cmbCommitteeNames = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lblTotalNoOfRecords = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbTenderYear = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // webReport
            // 
            this.webReport.Location = new System.Drawing.Point(21, 146);
            this.webReport.MinimumSize = new System.Drawing.Size(20, 20);
            this.webReport.Name = "webReport";
            this.webReport.Size = new System.Drawing.Size(1115, 451);
            this.webReport.TabIndex = 40;
            // 
            // btnSubmitReport
            // 
            this.btnSubmitReport.Location = new System.Drawing.Point(474, 108);
            this.btnSubmitReport.Name = "btnSubmitReport";
            this.btnSubmitReport.Size = new System.Drawing.Size(100, 23);
            this.btnSubmitReport.TabIndex = 39;
            this.btnSubmitReport.Text = "Generate Report";
            this.btnSubmitReport.UseVisualStyleBackColor = true;
            this.btnSubmitReport.Click += new System.EventHandler(this.btnSubmitReport_Click);
            // 
            // btnExport
            // 
            this.btnExport.BackColor = System.Drawing.Color.Coral;
            this.btnExport.Location = new System.Drawing.Point(580, 108);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(103, 23);
            this.btnExport.TabIndex = 38;
            this.btnExport.Text = "Export To Excel";
            this.btnExport.UseVisualStyleBackColor = false;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(612, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 37;
            this.label2.Text = "Fiscal Year";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(359, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 13);
            this.label1.TabIndex = 36;
            this.label1.Text = "Committee Names";
            // 
            // cmbFiscalYear
            // 
            this.cmbFiscalYear.FormattingEnabled = true;
            this.cmbFiscalYear.Location = new System.Drawing.Point(609, 69);
            this.cmbFiscalYear.Name = "cmbFiscalYear";
            this.cmbFiscalYear.Size = new System.Drawing.Size(121, 21);
            this.cmbFiscalYear.TabIndex = 35;
            // 
            // cmbCommitteeNames
            // 
            this.cmbCommitteeNames.FormattingEnabled = true;
            this.cmbCommitteeNames.Location = new System.Drawing.Point(356, 69);
            this.cmbCommitteeNames.Name = "cmbCommitteeNames";
            this.cmbCommitteeNames.Size = new System.Drawing.Size(196, 21);
            this.cmbCommitteeNames.TabIndex = 34;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(462, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(324, 25);
            this.label3.TabIndex = 51;
            this.label3.Text = "Tender Committee Award Report";
            // 
            // lblTotalNoOfRecords
            // 
            this.lblTotalNoOfRecords.AutoSize = true;
            this.lblTotalNoOfRecords.Location = new System.Drawing.Point(970, 613);
            this.lblTotalNoOfRecords.Name = "lblTotalNoOfRecords";
            this.lblTotalNoOfRecords.Size = new System.Drawing.Size(0, 13);
            this.lblTotalNoOfRecords.TabIndex = 52;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(789, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 13);
            this.label4.TabIndex = 54;
            this.label4.Text = "Tender Year";
            // 
            // cmbTenderYear
            // 
            this.cmbTenderYear.FormattingEnabled = true;
            this.cmbTenderYear.Location = new System.Drawing.Point(787, 69);
            this.cmbTenderYear.Name = "cmbTenderYear";
            this.cmbTenderYear.Size = new System.Drawing.Size(121, 21);
            this.cmbTenderYear.TabIndex = 53;
            // 
            // frmTenderCommAward
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1166, 652);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cmbTenderYear);
            this.Controls.Add(this.lblTotalNoOfRecords);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.webReport);
            this.Controls.Add(this.btnSubmitReport);
            this.Controls.Add(this.btnExport);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbFiscalYear);
            this.Controls.Add(this.cmbCommitteeNames);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmTenderCommAward";
            this.Text = "Tender Committee Award";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.WebBrowser webReport;
        private System.Windows.Forms.Button btnSubmitReport;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbFiscalYear;
        private System.Windows.Forms.ComboBox cmbCommitteeNames;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblTotalNoOfRecords;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbTenderYear;
    }
}