﻿namespace MDI_ParenrForm.Reports
{
    partial class frmStaffJobTrackingDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAssignedQS = new System.Windows.Forms.Label();
            this.cmbAssignedQS = new System.Windows.Forms.ComboBox();
            this.lblTenderIssue = new System.Windows.Forms.Label();
            this.cmbTenderIssue = new System.Windows.Forms.ComboBox();
            this.lblContractProcess = new System.Windows.Forms.Label();
            this.cmbContractProcess = new System.Windows.Forms.ComboBox();
            this.lblStartReportDate = new System.Windows.Forms.Label();
            this.dtStartReportDate = new System.Windows.Forms.DateTimePicker();
            this.webReport = new System.Windows.Forms.WebBrowser();
            this.btnGenerateReport = new System.Windows.Forms.Button();
            this.btnExportToExcel = new System.Windows.Forms.Button();
            this.lblEndReportDate = new System.Windows.Forms.Label();
            this.dtEndReportDate = new System.Windows.Forms.DateTimePicker();
            this.lblTotRecCount = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblAssignedQS
            // 
            this.lblAssignedQS.AutoSize = true;
            this.lblAssignedQS.Location = new System.Drawing.Point(89, 42);
            this.lblAssignedQS.Name = "lblAssignedQS";
            this.lblAssignedQS.Size = new System.Drawing.Size(98, 13);
            this.lblAssignedQS.TabIndex = 0;
            this.lblAssignedQS.Text = "Tender Preparation";
            // 
            // cmbAssignedQS
            // 
            this.cmbAssignedQS.FormattingEnabled = true;
            this.cmbAssignedQS.Location = new System.Drawing.Point(88, 58);
            this.cmbAssignedQS.Name = "cmbAssignedQS";
            this.cmbAssignedQS.Size = new System.Drawing.Size(185, 21);
            this.cmbAssignedQS.TabIndex = 1;
            this.cmbAssignedQS.SelectionChangeCommitted += new System.EventHandler(this.cmbAssignedQS_SelectionChangeCommitted);
            // 
            // lblTenderIssue
            // 
            this.lblTenderIssue.AutoSize = true;
            this.lblTenderIssue.Location = new System.Drawing.Point(307, 42);
            this.lblTenderIssue.Name = "lblTenderIssue";
            this.lblTenderIssue.Size = new System.Drawing.Size(69, 13);
            this.lblTenderIssue.TabIndex = 2;
            this.lblTenderIssue.Text = "Tender Issue";
            // 
            // cmbTenderIssue
            // 
            this.cmbTenderIssue.FormattingEnabled = true;
            this.cmbTenderIssue.Location = new System.Drawing.Point(309, 58);
            this.cmbTenderIssue.Name = "cmbTenderIssue";
            this.cmbTenderIssue.Size = new System.Drawing.Size(155, 21);
            this.cmbTenderIssue.TabIndex = 3;
            this.cmbTenderIssue.SelectionChangeCommitted += new System.EventHandler(this.cmbTenderIssue_SelectionChangeCommitted);
            // 
            // lblContractProcess
            // 
            this.lblContractProcess.AutoSize = true;
            this.lblContractProcess.Location = new System.Drawing.Point(496, 42);
            this.lblContractProcess.Name = "lblContractProcess";
            this.lblContractProcess.Size = new System.Drawing.Size(109, 13);
            this.lblContractProcess.TabIndex = 4;
            this.lblContractProcess.Text = "Contracts Preparation";
            // 
            // cmbContractProcess
            // 
            this.cmbContractProcess.FormattingEnabled = true;
            this.cmbContractProcess.Location = new System.Drawing.Point(499, 58);
            this.cmbContractProcess.Name = "cmbContractProcess";
            this.cmbContractProcess.Size = new System.Drawing.Size(152, 21);
            this.cmbContractProcess.TabIndex = 5;
            this.cmbContractProcess.SelectionChangeCommitted += new System.EventHandler(this.cmbContractProcess_SelectionChangeCommitted);
            // 
            // lblStartReportDate
            // 
            this.lblStartReportDate.AutoSize = true;
            this.lblStartReportDate.Location = new System.Drawing.Point(676, 42);
            this.lblStartReportDate.Name = "lblStartReportDate";
            this.lblStartReportDate.Size = new System.Drawing.Size(90, 13);
            this.lblStartReportDate.TabIndex = 6;
            this.lblStartReportDate.Text = "Start Report Date";
            // 
            // dtStartReportDate
            // 
            this.dtStartReportDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtStartReportDate.Location = new System.Drawing.Point(679, 58);
            this.dtStartReportDate.Name = "dtStartReportDate";
            this.dtStartReportDate.Size = new System.Drawing.Size(98, 20);
            this.dtStartReportDate.TabIndex = 7;
            this.dtStartReportDate.ValueChanged += new System.EventHandler(this.dtStartReportDate_ValueChanged);
            // 
            // webReport
            // 
            this.webReport.Location = new System.Drawing.Point(29, 139);
            this.webReport.MinimumSize = new System.Drawing.Size(20, 20);
            this.webReport.Name = "webReport";
            this.webReport.Size = new System.Drawing.Size(1007, 430);
            this.webReport.TabIndex = 8;
            // 
            // btnGenerateReport
            // 
            this.btnGenerateReport.Location = new System.Drawing.Point(423, 101);
            this.btnGenerateReport.Name = "btnGenerateReport";
            this.btnGenerateReport.Size = new System.Drawing.Size(98, 23);
            this.btnGenerateReport.TabIndex = 9;
            this.btnGenerateReport.Text = "Generate Report";
            this.btnGenerateReport.UseVisualStyleBackColor = true;
            this.btnGenerateReport.Click += new System.EventHandler(this.btnGenerateReport_Click);
            // 
            // btnExportToExcel
            // 
            this.btnExportToExcel.BackColor = System.Drawing.Color.Coral;
            this.btnExportToExcel.Location = new System.Drawing.Point(538, 101);
            this.btnExportToExcel.Name = "btnExportToExcel";
            this.btnExportToExcel.Size = new System.Drawing.Size(98, 23);
            this.btnExportToExcel.TabIndex = 10;
            this.btnExportToExcel.Text = "Export To Excel";
            this.btnExportToExcel.UseVisualStyleBackColor = false;
            this.btnExportToExcel.Click += new System.EventHandler(this.btnExportToExcel_Click);
            // 
            // lblEndReportDate
            // 
            this.lblEndReportDate.AutoSize = true;
            this.lblEndReportDate.Location = new System.Drawing.Point(810, 42);
            this.lblEndReportDate.Name = "lblEndReportDate";
            this.lblEndReportDate.Size = new System.Drawing.Size(87, 13);
            this.lblEndReportDate.TabIndex = 11;
            this.lblEndReportDate.Text = "End Report Date";
            // 
            // dtEndReportDate
            // 
            this.dtEndReportDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtEndReportDate.Location = new System.Drawing.Point(813, 58);
            this.dtEndReportDate.Name = "dtEndReportDate";
            this.dtEndReportDate.Size = new System.Drawing.Size(93, 20);
            this.dtEndReportDate.TabIndex = 12;
            this.dtEndReportDate.Value = new System.DateTime(2014, 4, 27, 9, 45, 0, 0);
            // 
            // lblTotRecCount
            // 
            this.lblTotRecCount.AutoSize = true;
            this.lblTotRecCount.Location = new System.Drawing.Point(910, 581);
            this.lblTotRecCount.Name = "lblTotRecCount";
            this.lblTotRecCount.Size = new System.Drawing.Size(0, 13);
            this.lblTotRecCount.TabIndex = 13;
            // 
            // frmStaffJobTrackingDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FloralWhite;
            this.ClientSize = new System.Drawing.Size(1048, 613);
            this.Controls.Add(this.lblTotRecCount);
            this.Controls.Add(this.dtEndReportDate);
            this.Controls.Add(this.lblEndReportDate);
            this.Controls.Add(this.btnExportToExcel);
            this.Controls.Add(this.btnGenerateReport);
            this.Controls.Add(this.webReport);
            this.Controls.Add(this.dtStartReportDate);
            this.Controls.Add(this.lblStartReportDate);
            this.Controls.Add(this.cmbContractProcess);
            this.Controls.Add(this.lblContractProcess);
            this.Controls.Add(this.cmbTenderIssue);
            this.Controls.Add(this.lblTenderIssue);
            this.Controls.Add(this.cmbAssignedQS);
            this.Controls.Add(this.lblAssignedQS);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmStaffJobTrackingDetails";
            this.Text = "TCMS Staff JobTracking Reports";
            this.Load += new System.EventHandler(this.frmStaffJobTrackingDetails_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAssignedQS;
        private System.Windows.Forms.ComboBox cmbAssignedQS;
        private System.Windows.Forms.Label lblTenderIssue;
        private System.Windows.Forms.ComboBox cmbTenderIssue;
        private System.Windows.Forms.Label lblContractProcess;
        private System.Windows.Forms.ComboBox cmbContractProcess;
        private System.Windows.Forms.Label lblStartReportDate;
        private System.Windows.Forms.DateTimePicker dtStartReportDate;
        private System.Windows.Forms.WebBrowser webReport;
        private System.Windows.Forms.Button btnGenerateReport;
        private System.Windows.Forms.Button btnExportToExcel;
        private System.Windows.Forms.Label lblEndReportDate;
        private System.Windows.Forms.DateTimePicker dtEndReportDate;
        private System.Windows.Forms.Label lblTotRecCount;
    }
}