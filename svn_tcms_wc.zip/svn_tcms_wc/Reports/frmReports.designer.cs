﻿namespace MDI_ParenrForm.Reports
{
    partial class frmReports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblReport = new System.Windows.Forms.Label();
            this.wbReport = new System.Windows.Forms.WebBrowser();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblTotalNoOfRecords = new System.Windows.Forms.Label();
            this.btnSubmitReport = new System.Windows.Forms.Button();
            this.btnExport = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.cmbTenderType = new System.Windows.Forms.ComboBox();
            this.cmbDepartment = new System.Windows.Forms.ComboBox();
            this.cmbAffairs = new System.Windows.Forms.ComboBox();
            this.lblAffairs = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbTenderStatus = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbTenderStage = new System.Windows.Forms.ComboBox();
            this.cmbTenderCommittee = new System.Windows.Forms.ComboBox();
            this.cmbFiscalyear = new System.Windows.Forms.ComboBox();
            this.cmbContractType = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.lblStartRepDate = new System.Windows.Forms.Label();
            this.dtpStartReportDate = new System.Windows.Forms.DateTimePicker();
            this.lblEndRepDate = new System.Windows.Forms.Label();
            this.dtpEndReportDate = new System.Windows.Forms.DateTimePicker();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.lnkTdrBondTracking = new System.Windows.Forms.LinkLabel();
            this.lnkTndrCmtAward = new System.Windows.Forms.LinkLabel();
            this.linkWorkOrder = new System.Windows.Forms.LinkLabel();
            this.CommittedContacts = new System.Windows.Forms.LinkLabel();
            this.TenderCommittee = new System.Windows.Forms.LinkLabel();
            this.linkProjTracking = new System.Windows.Forms.LinkLabel();
            this.grpBoxOtherReports = new System.Windows.Forms.GroupBox();
            this.lnkLocalCompanies = new System.Windows.Forms.LinkLabel();
            this.lnkContractsInfo = new System.Windows.Forms.LinkLabel();
            this.linkTenderingRecs = new System.Windows.Forms.LinkLabel();
            this.linkCntrAmnt = new System.Windows.Forms.LinkLabel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.linkTotTndrApprovalDays = new System.Windows.Forms.LinkLabel();
            this.linkShowContracts = new System.Windows.Forms.LinkLabel();
            this.linkContractorDetails = new System.Windows.Forms.LinkLabel();
            this.linkStaffJobTrackDetails = new System.Windows.Forms.LinkLabel();
            this.linkQSWorkingStatus = new System.Windows.Forms.LinkLabel();
            this.linkCoParticipationInDiffTenders = new System.Windows.Forms.LinkLabel();
            this.linkAwardedTenders = new System.Windows.Forms.LinkLabel();
            this.linkContractorQatariNonQatariShare = new System.Windows.Forms.LinkLabel();
            this.lnkTndrCmt = new System.Windows.Forms.LinkLabel();
            this.label8 = new System.Windows.Forms.Label();
            this.lnkTndrTracking = new System.Windows.Forms.LinkLabel();
            this.lblCurrentReportName = new System.Windows.Forms.Label();
            this.lnkReTenderProj = new System.Windows.Forms.LinkLabel();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.grpBoxOtherReports.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblReport
            // 
            this.lblReport.AutoSize = true;
            this.lblReport.Location = new System.Drawing.Point(0, 0);
            this.lblReport.Name = "lblReport";
            this.lblReport.Size = new System.Drawing.Size(0, 13);
            this.lblReport.TabIndex = 0;
            // 
            // wbReport
            // 
            this.wbReport.Location = new System.Drawing.Point(9, 163);
            this.wbReport.MinimumSize = new System.Drawing.Size(20, 20);
            this.wbReport.Name = "wbReport";
            this.wbReport.Size = new System.Drawing.Size(921, 500);
            this.wbReport.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblTotalNoOfRecords);
            this.groupBox1.Controls.Add(this.btnSubmitReport);
            this.groupBox1.Controls.Add(this.btnExport);
            this.groupBox1.Controls.Add(this.tableLayoutPanel1);
            this.groupBox1.Controls.Add(this.wbReport);
            this.groupBox1.Location = new System.Drawing.Point(3, 20);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1188, 766);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Visible = false;
            // 
            // lblTotalNoOfRecords
            // 
            this.lblTotalNoOfRecords.AutoSize = true;
            this.lblTotalNoOfRecords.Location = new System.Drawing.Point(787, 689);
            this.lblTotalNoOfRecords.Name = "lblTotalNoOfRecords";
            this.lblTotalNoOfRecords.Size = new System.Drawing.Size(0, 13);
            this.lblTotalNoOfRecords.TabIndex = 31;
            // 
            // btnSubmitReport
            // 
            this.btnSubmitReport.Location = new System.Drawing.Point(374, 131);
            this.btnSubmitReport.Name = "btnSubmitReport";
            this.btnSubmitReport.Size = new System.Drawing.Size(100, 23);
            this.btnSubmitReport.TabIndex = 30;
            this.btnSubmitReport.Text = "Generate Report";
            this.btnSubmitReport.UseVisualStyleBackColor = true;
            this.btnSubmitReport.Click += new System.EventHandler(this.btnSubmitReport_Click);
            // 
            // btnExport
            // 
            this.btnExport.BackColor = System.Drawing.Color.Coral;
            this.btnExport.Location = new System.Drawing.Point(480, 131);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(103, 23);
            this.btnExport.TabIndex = 29;
            this.btnExport.Text = "Export To Excel";
            this.btnExport.UseVisualStyleBackColor = false;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.ColumnCount = 11;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 201F));
            this.tableLayoutPanel1.Controls.Add(this.cmbTenderType, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.cmbDepartment, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.cmbAffairs, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblAffairs, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.label3, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label4, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.label1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label6, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.cmbTenderStatus, 6, 1);
            this.tableLayoutPanel1.Controls.Add(this.label5, 6, 0);
            this.tableLayoutPanel1.Controls.Add(this.cmbTenderStage, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.cmbTenderCommittee, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.cmbFiscalyear, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.cmbContractType, 8, 1);
            this.tableLayoutPanel1.Controls.Add(this.label7, 8, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblStartRepDate, 9, 0);
            this.tableLayoutPanel1.Controls.Add(this.dtpStartReportDate, 9, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblEndRepDate, 10, 0);
            this.tableLayoutPanel1.Controls.Add(this.dtpEndReportDate, 10, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(6, 11);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 29F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 71F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1176, 117);
            this.tableLayoutPanel1.TabIndex = 28;
            // 
            // cmbTenderType
            // 
            this.cmbTenderType.DropDownWidth = 150;
            this.cmbTenderType.FormattingEnabled = true;
            this.cmbTenderType.Location = new System.Drawing.Point(563, 36);
            this.cmbTenderType.Name = "cmbTenderType";
            this.cmbTenderType.Size = new System.Drawing.Size(97, 21);
            this.cmbTenderType.TabIndex = 39;
            // 
            // cmbDepartment
            // 
            this.cmbDepartment.DropDownWidth = 250;
            this.cmbDepartment.FormattingEnabled = true;
            this.cmbDepartment.Location = new System.Drawing.Point(3, 36);
            this.cmbDepartment.Name = "cmbDepartment";
            this.cmbDepartment.Size = new System.Drawing.Size(101, 21);
            this.cmbDepartment.TabIndex = 33;
            this.cmbDepartment.SelectedIndexChanged += new System.EventHandler(this.cmbDepartment_SelectedIndexChanged);
            // 
            // cmbAffairs
            // 
            this.cmbAffairs.DropDownWidth = 150;
            this.cmbAffairs.FormattingEnabled = true;
            this.cmbAffairs.Location = new System.Drawing.Point(110, 36);
            this.cmbAffairs.Name = "cmbAffairs";
            this.cmbAffairs.Size = new System.Drawing.Size(146, 21);
            this.cmbAffairs.TabIndex = 31;
            // 
            // lblAffairs
            // 
            this.lblAffairs.AutoSize = true;
            this.lblAffairs.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAffairs.Location = new System.Drawing.Point(10, 0);
            this.lblAffairs.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lblAffairs.Name = "lblAffairs";
            this.lblAffairs.Size = new System.Drawing.Size(36, 13);
            this.lblAffairs.TabIndex = 27;
            this.lblAffairs.Text = "Affairs";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(345, 0);
            this.label2.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 13);
            this.label2.TabIndex = 30;
            this.label2.Text = "Tender Committees";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(262, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 13);
            this.label3.TabIndex = 34;
            this.label3.Text = "Fiscal Year";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(456, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 13);
            this.label4.TabIndex = 35;
            this.label4.Text = "Tender Stage";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(117, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 13);
            this.label1.TabIndex = 29;
            this.label1.Text = "User Department";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(563, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 13);
            this.label6.TabIndex = 38;
            this.label6.Text = "Type of Tender";
            // 
            // cmbTenderStatus
            // 
            this.cmbTenderStatus.DropDownWidth = 200;
            this.cmbTenderStatus.FormattingEnabled = true;
            this.cmbTenderStatus.Location = new System.Drawing.Point(666, 36);
            this.cmbTenderStatus.Name = "cmbTenderStatus";
            this.cmbTenderStatus.Size = new System.Drawing.Size(83, 21);
            this.cmbTenderStatus.TabIndex = 37;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(666, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 13);
            this.label5.TabIndex = 36;
            this.label5.Text = "Status";
            // 
            // cmbTenderStage
            // 
            this.cmbTenderStage.DropDownWidth = 150;
            this.cmbTenderStage.FormattingEnabled = true;
            this.cmbTenderStage.Location = new System.Drawing.Point(456, 36);
            this.cmbTenderStage.Name = "cmbTenderStage";
            this.cmbTenderStage.Size = new System.Drawing.Size(101, 21);
            this.cmbTenderStage.TabIndex = 28;
            // 
            // cmbTenderCommittee
            // 
            this.cmbTenderCommittee.DropDownWidth = 200;
            this.cmbTenderCommittee.FormattingEnabled = true;
            this.cmbTenderCommittee.Location = new System.Drawing.Point(338, 36);
            this.cmbTenderCommittee.Name = "cmbTenderCommittee";
            this.cmbTenderCommittee.Size = new System.Drawing.Size(95, 21);
            this.cmbTenderCommittee.TabIndex = 2;
            // 
            // cmbFiscalyear
            // 
            this.cmbFiscalyear.FormattingEnabled = true;
            this.cmbFiscalyear.Location = new System.Drawing.Point(262, 36);
            this.cmbFiscalyear.Name = "cmbFiscalyear";
            this.cmbFiscalyear.Size = new System.Drawing.Size(70, 21);
            this.cmbFiscalyear.TabIndex = 32;
            this.cmbFiscalyear.SelectedIndexChanged += new System.EventHandler(this.cmbFiscalyear_SelectedIndexChanged);
            // 
            // cmbContractType
            // 
            this.cmbContractType.DropDownWidth = 200;
            this.cmbContractType.FormattingEnabled = true;
            this.cmbContractType.Location = new System.Drawing.Point(755, 36);
            this.cmbContractType.Name = "cmbContractType";
            this.cmbContractType.Size = new System.Drawing.Size(121, 21);
            this.cmbContractType.TabIndex = 41;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(755, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 13);
            this.label7.TabIndex = 40;
            this.label7.Text = "Type of Contract";
            // 
            // lblStartRepDate
            // 
            this.lblStartRepDate.AutoSize = true;
            this.lblStartRepDate.Location = new System.Drawing.Point(882, 0);
            this.lblStartRepDate.Name = "lblStartRepDate";
            this.lblStartRepDate.Size = new System.Drawing.Size(90, 13);
            this.lblStartRepDate.TabIndex = 42;
            this.lblStartRepDate.Text = "Start Report Date";
            // 
            // dtpStartReportDate
            // 
            this.dtpStartReportDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpStartReportDate.Location = new System.Drawing.Point(882, 36);
            this.dtpStartReportDate.Name = "dtpStartReportDate";
            this.dtpStartReportDate.Size = new System.Drawing.Size(90, 20);
            this.dtpStartReportDate.TabIndex = 43;
            this.dtpStartReportDate.ValueChanged += new System.EventHandler(this.dtpStartReportDate_ValueChanged);
            // 
            // lblEndRepDate
            // 
            this.lblEndRepDate.AutoSize = true;
            this.lblEndRepDate.Location = new System.Drawing.Point(978, 0);
            this.lblEndRepDate.Name = "lblEndRepDate";
            this.lblEndRepDate.Size = new System.Drawing.Size(87, 13);
            this.lblEndRepDate.TabIndex = 44;
            this.lblEndRepDate.Text = "End Report Date";
            // 
            // dtpEndReportDate
            // 
            this.dtpEndReportDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpEndReportDate.Location = new System.Drawing.Point(978, 36);
            this.dtpEndReportDate.Name = "dtpEndReportDate";
            this.dtpEndReportDate.Size = new System.Drawing.Size(95, 20);
            this.dtpEndReportDate.TabIndex = 45;
            this.dtpEndReportDate.ValueChanged += new System.EventHandler(this.dtpEndReportDate_ValueChanged);
            // 
            // splitContainer1
            // 
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer1.Location = new System.Drawing.Point(6, 9);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.lnkTdrBondTracking);
            this.splitContainer1.Panel1.Controls.Add(this.lnkTndrCmtAward);
            this.splitContainer1.Panel1.Controls.Add(this.linkWorkOrder);
            this.splitContainer1.Panel1.Controls.Add(this.CommittedContacts);
            this.splitContainer1.Panel1.Controls.Add(this.TenderCommittee);
            this.splitContainer1.Panel1.Controls.Add(this.linkProjTracking);
            this.splitContainer1.Panel1.Controls.Add(this.grpBoxOtherReports);
            this.splitContainer1.Panel1.Controls.Add(this.lnkTndrCmt);
            this.splitContainer1.Panel1.Controls.Add(this.label8);
            this.splitContainer1.Panel1.Controls.Add(this.lnkTndrTracking);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.lblCurrentReportName);
            this.splitContainer1.Panel2.Controls.Add(this.groupBox1);
            this.splitContainer1.Size = new System.Drawing.Size(1457, 800);
            this.splitContainer1.SplitterDistance = 301;
            this.splitContainer1.TabIndex = 3;
            // 
            // lnkTdrBondTracking
            // 
            this.lnkTdrBondTracking.AutoSize = true;
            this.lnkTdrBondTracking.BackColor = System.Drawing.Color.White;
            this.lnkTdrBondTracking.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lnkTdrBondTracking.Location = new System.Drawing.Point(19, 200);
            this.lnkTdrBondTracking.Name = "lnkTdrBondTracking";
            this.lnkTdrBondTracking.Size = new System.Drawing.Size(154, 18);
            this.lnkTdrBondTracking.TabIndex = 31;
            this.lnkTdrBondTracking.TabStop = true;
            this.lnkTdrBondTracking.Text = "Tender Bond Tracking";
            this.lnkTdrBondTracking.Visible = false;
            this.lnkTdrBondTracking.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkTdrBondTracking_LinkClicked);
            // 
            // lnkTndrCmtAward
            // 
            this.lnkTndrCmtAward.ActiveLinkColor = System.Drawing.Color.DarkSlateBlue;
            this.lnkTndrCmtAward.AutoSize = true;
            this.lnkTndrCmtAward.BackColor = System.Drawing.Color.White;
            this.lnkTndrCmtAward.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkTndrCmtAward.ForeColor = System.Drawing.Color.DarkGray;
            this.lnkTndrCmtAward.LinkBehavior = System.Windows.Forms.LinkBehavior.AlwaysUnderline;
            this.lnkTndrCmtAward.LinkColor = System.Drawing.Color.Blue;
            this.lnkTndrCmtAward.Location = new System.Drawing.Point(17, 100);
            this.lnkTndrCmtAward.Name = "lnkTndrCmtAward";
            this.lnkTndrCmtAward.Padding = new System.Windows.Forms.Padding(3);
            this.lnkTndrCmtAward.Size = new System.Drawing.Size(182, 24);
            this.lnkTndrCmtAward.TabIndex = 30;
            this.lnkTndrCmtAward.TabStop = true;
            this.lnkTndrCmtAward.Text = "Tender Committee Award";
            this.lnkTndrCmtAward.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lnkTndrCmtAward.Visible = false;
            this.lnkTndrCmtAward.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkTndrCmtAward_LinkClicked);
            // 
            // linkWorkOrder
            // 
            this.linkWorkOrder.AutoSize = true;
            this.linkWorkOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.linkWorkOrder.Location = new System.Drawing.Point(19, 261);
            this.linkWorkOrder.Name = "linkWorkOrder";
            this.linkWorkOrder.Size = new System.Drawing.Size(144, 18);
            this.linkWorkOrder.TabIndex = 29;
            this.linkWorkOrder.TabStop = true;
            this.linkWorkOrder.Text = "Work Order Reports";
            this.linkWorkOrder.Visible = false;
            this.linkWorkOrder.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkWorkOrder_LinkClicked);
            // 
            // CommittedContacts
            // 
            this.CommittedContacts.AutoSize = true;
            this.CommittedContacts.BackColor = System.Drawing.Color.White;
            this.CommittedContacts.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.CommittedContacts.Location = new System.Drawing.Point(18, 231);
            this.CommittedContacts.Name = "CommittedContacts";
            this.CommittedContacts.Size = new System.Drawing.Size(150, 18);
            this.CommittedContacts.TabIndex = 28;
            this.CommittedContacts.TabStop = true;
            this.CommittedContacts.Text = "Committed Contracts";
            this.CommittedContacts.Visible = false;
            this.CommittedContacts.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.CommittedContacts_LinkClicked);
            // 
            // TenderCommittee
            // 
            this.TenderCommittee.AutoSize = true;
            this.TenderCommittee.BackColor = System.Drawing.Color.White;
            this.TenderCommittee.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.TenderCommittee.Location = new System.Drawing.Point(21, 169);
            this.TenderCommittee.Name = "TenderCommittee";
            this.TenderCommittee.Size = new System.Drawing.Size(131, 18);
            this.TenderCommittee.TabIndex = 27;
            this.TenderCommittee.TabStop = true;
            this.TenderCommittee.Text = "Tender Committee";
            this.TenderCommittee.Visible = false;
            this.TenderCommittee.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.TenderCommittee_LinkClicked);
            // 
            // linkProjTracking
            // 
            this.linkProjTracking.ActiveLinkColor = System.Drawing.Color.DarkSlateBlue;
            this.linkProjTracking.AutoSize = true;
            this.linkProjTracking.BackColor = System.Drawing.Color.White;
            this.linkProjTracking.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkProjTracking.ForeColor = System.Drawing.Color.DarkGray;
            this.linkProjTracking.LinkBehavior = System.Windows.Forms.LinkBehavior.AlwaysUnderline;
            this.linkProjTracking.LinkColor = System.Drawing.Color.Blue;
            this.linkProjTracking.Location = new System.Drawing.Point(17, 134);
            this.linkProjTracking.Name = "linkProjTracking";
            this.linkProjTracking.Padding = new System.Windows.Forms.Padding(3);
            this.linkProjTracking.Size = new System.Drawing.Size(179, 24);
            this.linkProjTracking.TabIndex = 12;
            this.linkProjTracking.TabStop = true;
            this.linkProjTracking.Text = "Project Tracking Reports";
            this.linkProjTracking.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.linkProjTracking.Visible = false;
            this.linkProjTracking.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkProjTracking_LinkClicked);
            // 
            // grpBoxOtherReports
            // 
            this.grpBoxOtherReports.Controls.Add(this.lnkReTenderProj);
            this.grpBoxOtherReports.Controls.Add(this.lnkLocalCompanies);
            this.grpBoxOtherReports.Controls.Add(this.lnkContractsInfo);
            this.grpBoxOtherReports.Controls.Add(this.linkTenderingRecs);
            this.grpBoxOtherReports.Controls.Add(this.linkCntrAmnt);
            this.grpBoxOtherReports.Controls.Add(this.linkLabel1);
            this.grpBoxOtherReports.Controls.Add(this.linkTotTndrApprovalDays);
            this.grpBoxOtherReports.Controls.Add(this.linkShowContracts);
            this.grpBoxOtherReports.Controls.Add(this.linkContractorDetails);
            this.grpBoxOtherReports.Controls.Add(this.linkStaffJobTrackDetails);
            this.grpBoxOtherReports.Controls.Add(this.linkQSWorkingStatus);
            this.grpBoxOtherReports.Controls.Add(this.linkCoParticipationInDiffTenders);
            this.grpBoxOtherReports.Controls.Add(this.linkAwardedTenders);
            this.grpBoxOtherReports.Controls.Add(this.linkContractorQatariNonQatariShare);
            this.grpBoxOtherReports.Location = new System.Drawing.Point(5, 288);
            this.grpBoxOtherReports.Name = "grpBoxOtherReports";
            this.grpBoxOtherReports.Size = new System.Drawing.Size(283, 498);
            this.grpBoxOtherReports.TabIndex = 23;
            this.grpBoxOtherReports.TabStop = false;
            this.grpBoxOtherReports.Text = "Other Reports";
            this.grpBoxOtherReports.Visible = false;
            // 
            // lnkLocalCompanies
            // 
            this.lnkLocalCompanies.AutoSize = true;
            this.lnkLocalCompanies.BackColor = System.Drawing.Color.White;
            this.lnkLocalCompanies.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lnkLocalCompanies.Location = new System.Drawing.Point(14, 163);
            this.lnkLocalCompanies.Name = "lnkLocalCompanies";
            this.lnkLocalCompanies.Size = new System.Drawing.Size(229, 18);
            this.lnkLocalCompanies.TabIndex = 26;
            this.lnkLocalCompanies.TabStop = true;
            this.lnkLocalCompanies.Text = "Awarded Qatari Local Companies";
            this.lnkLocalCompanies.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkLocalCompanies_LinkClicked);
            // 
            // lnkContractsInfo
            // 
            this.lnkContractsInfo.AutoSize = true;
            this.lnkContractsInfo.BackColor = System.Drawing.Color.White;
            this.lnkContractsInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lnkContractsInfo.Location = new System.Drawing.Point(13, 470);
            this.lnkContractsInfo.Name = "lnkContractsInfo";
            this.lnkContractsInfo.Size = new System.Drawing.Size(231, 18);
            this.lnkContractsInfo.TabIndex = 25;
            this.lnkContractsInfo.TabStop = true;
            this.lnkContractsInfo.Text = "Companies Contracts Information";
            this.lnkContractsInfo.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkContractsInfo_LinkClicked);
            // 
            // linkTenderingRecs
            // 
            this.linkTenderingRecs.AutoSize = true;
            this.linkTenderingRecs.BackColor = System.Drawing.Color.White;
            this.linkTenderingRecs.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.linkTenderingRecs.Location = new System.Drawing.Point(13, 441);
            this.linkTenderingRecs.Name = "linkTenderingRecs";
            this.linkTenderingRecs.Size = new System.Drawing.Size(242, 18);
            this.linkTenderingRecs.TabIndex = 23;
            this.linkTenderingRecs.TabStop = true;
            this.linkTenderingRecs.Text = "Projects Pre && Post Stage Records";
            this.linkTenderingRecs.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkTenderingRecs_LinkClicked);
            // 
            // linkCntrAmnt
            // 
            this.linkCntrAmnt.AutoSize = true;
            this.linkCntrAmnt.BackColor = System.Drawing.Color.White;
            this.linkCntrAmnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.linkCntrAmnt.Location = new System.Drawing.Point(13, 408);
            this.linkCntrAmnt.Name = "linkCntrAmnt";
            this.linkCntrAmnt.Size = new System.Drawing.Size(113, 18);
            this.linkCntrAmnt.TabIndex = 22;
            this.linkCntrAmnt.TabStop = true;
            this.linkCntrAmnt.Text = "Contract Values";
            this.linkCntrAmnt.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkCntrAmnt_LinkClicked);
            // 
            // linkLabel1
            // 
            this.linkLabel1.ActiveLinkColor = System.Drawing.Color.DarkSlateBlue;
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.BackColor = System.Drawing.Color.White;
            this.linkLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.ForeColor = System.Drawing.Color.DarkGray;
            this.linkLabel1.LinkBehavior = System.Windows.Forms.LinkBehavior.AlwaysUnderline;
            this.linkLabel1.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel1.Location = new System.Drawing.Point(13, 22);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Padding = new System.Windows.Forms.Padding(3);
            this.linkLabel1.Size = new System.Drawing.Size(184, 24);
            this.linkLabel1.TabIndex = 13;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Qatari Share In Company ";
            this.linkLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // linkTotTndrApprovalDays
            // 
            this.linkTotTndrApprovalDays.AutoSize = true;
            this.linkTotTndrApprovalDays.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkTotTndrApprovalDays.Location = new System.Drawing.Point(13, 57);
            this.linkTotTndrApprovalDays.Name = "linkTotTndrApprovalDays";
            this.linkTotTndrApprovalDays.Size = new System.Drawing.Size(190, 18);
            this.linkTotTndrApprovalDays.TabIndex = 14;
            this.linkTotTndrApprovalDays.TabStop = true;
            this.linkTotTndrApprovalDays.Text = "Total Tender Approval Days";
            this.linkTotTndrApprovalDays.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkTotTndrApprovalDays_LinkClicked);
            // 
            // linkShowContracts
            // 
            this.linkShowContracts.AutoSize = true;
            this.linkShowContracts.BackColor = System.Drawing.Color.White;
            this.linkShowContracts.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.linkShowContracts.Location = new System.Drawing.Point(13, 375);
            this.linkShowContracts.Name = "linkShowContracts";
            this.linkShowContracts.Size = new System.Drawing.Size(100, 18);
            this.linkShowContracts.TabIndex = 21;
            this.linkShowContracts.TabStop = true;
            this.linkShowContracts.Text = "List Contracts";
            this.linkShowContracts.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkShowContracts_LinkClicked);
            // 
            // linkContractorDetails
            // 
            this.linkContractorDetails.AutoSize = true;
            this.linkContractorDetails.BackColor = System.Drawing.Color.White;
            this.linkContractorDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.linkContractorDetails.Location = new System.Drawing.Point(13, 91);
            this.linkContractorDetails.Name = "linkContractorDetails";
            this.linkContractorDetails.Size = new System.Drawing.Size(128, 18);
            this.linkContractorDetails.TabIndex = 15;
            this.linkContractorDetails.TabStop = true;
            this.linkContractorDetails.Text = "Contractor Details";
            this.linkContractorDetails.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkContractorDetails_LinkClicked);
            // 
            // linkStaffJobTrackDetails
            // 
            this.linkStaffJobTrackDetails.AutoSize = true;
            this.linkStaffJobTrackDetails.BackColor = System.Drawing.Color.White;
            this.linkStaffJobTrackDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.linkStaffJobTrackDetails.Location = new System.Drawing.Point(13, 201);
            this.linkStaffJobTrackDetails.Name = "linkStaffJobTrackDetails";
            this.linkStaffJobTrackDetails.Size = new System.Drawing.Size(177, 18);
            this.linkStaffJobTrackDetails.TabIndex = 16;
            this.linkStaffJobTrackDetails.TabStop = true;
            this.linkStaffJobTrackDetails.Text = "Staff Job Tracking Details";
            this.linkStaffJobTrackDetails.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkStaffJobTrackDetails_LinkClicked);
            // 
            // linkQSWorkingStatus
            // 
            this.linkQSWorkingStatus.AutoSize = true;
            this.linkQSWorkingStatus.BackColor = System.Drawing.Color.White;
            this.linkQSWorkingStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.linkQSWorkingStatus.Location = new System.Drawing.Point(13, 342);
            this.linkQSWorkingStatus.Name = "linkQSWorkingStatus";
            this.linkQSWorkingStatus.Size = new System.Drawing.Size(136, 18);
            this.linkQSWorkingStatus.TabIndex = 20;
            this.linkQSWorkingStatus.TabStop = true;
            this.linkQSWorkingStatus.Text = "QS Working Status";
            this.linkQSWorkingStatus.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblQSWorkingStatus_LinkClicked);
            // 
            // linkCoParticipationInDiffTenders
            // 
            this.linkCoParticipationInDiffTenders.AutoSize = true;
            this.linkCoParticipationInDiffTenders.BackColor = System.Drawing.Color.White;
            this.linkCoParticipationInDiffTenders.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.linkCoParticipationInDiffTenders.Location = new System.Drawing.Point(-3, 306);
            this.linkCoParticipationInDiffTenders.Name = "linkCoParticipationInDiffTenders";
            this.linkCoParticipationInDiffTenders.Size = new System.Drawing.Size(289, 18);
            this.linkCoParticipationInDiffTenders.TabIndex = 18;
            this.linkCoParticipationInDiffTenders.TabStop = true;
            this.linkCoParticipationInDiffTenders.Text = "Company Participation In Different Tenders";
            this.linkCoParticipationInDiffTenders.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkCoParticipationInDiffTenders_LinkClicked);
            // 
            // linkAwardedTenders
            // 
            this.linkAwardedTenders.AutoSize = true;
            this.linkAwardedTenders.BackColor = System.Drawing.Color.White;
            this.linkAwardedTenders.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.linkAwardedTenders.Location = new System.Drawing.Point(13, 236);
            this.linkAwardedTenders.Name = "linkAwardedTenders";
            this.linkAwardedTenders.Size = new System.Drawing.Size(123, 18);
            this.linkAwardedTenders.TabIndex = 17;
            this.linkAwardedTenders.TabStop = true;
            this.linkAwardedTenders.Text = "Awarded Tenders";
            this.linkAwardedTenders.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkAwardedTenders_LinkClicked);
            // 
            // linkContractorQatariNonQatariShare
            // 
            this.linkContractorQatariNonQatariShare.AutoSize = true;
            this.linkContractorQatariNonQatariShare.BackColor = System.Drawing.Color.White;
            this.linkContractorQatariNonQatariShare.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.linkContractorQatariNonQatariShare.Location = new System.Drawing.Point(13, 272);
            this.linkContractorQatariNonQatariShare.Name = "linkContractorQatariNonQatariShare";
            this.linkContractorQatariNonQatariShare.Size = new System.Drawing.Size(166, 18);
            this.linkContractorQatariNonQatariShare.TabIndex = 19;
            this.linkContractorQatariNonQatariShare.TabStop = true;
            this.linkContractorQatariNonQatariShare.Text = "Contractor Qatari Share";
            this.linkContractorQatariNonQatariShare.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkContractorQatariNonQatariShare_LinkClicked);
            // 
            // lnkTndrCmt
            // 
            this.lnkTndrCmt.ActiveLinkColor = System.Drawing.Color.DarkSlateBlue;
            this.lnkTndrCmt.AutoSize = true;
            this.lnkTndrCmt.BackColor = System.Drawing.Color.White;
            this.lnkTndrCmt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkTndrCmt.ForeColor = System.Drawing.Color.DarkGray;
            this.lnkTndrCmt.LinkBehavior = System.Windows.Forms.LinkBehavior.AlwaysUnderline;
            this.lnkTndrCmt.LinkColor = System.Drawing.Color.Blue;
            this.lnkTndrCmt.Location = new System.Drawing.Point(17, 66);
            this.lnkTndrCmt.Name = "lnkTndrCmt";
            this.lnkTndrCmt.Padding = new System.Windows.Forms.Padding(3);
            this.lnkTndrCmt.Size = new System.Drawing.Size(194, 24);
            this.lnkTndrCmt.TabIndex = 10;
            this.lnkTndrCmt.TabStop = true;
            this.lnkTndrCmt.Text = "Tender Committee Reports";
            this.lnkTndrCmt.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lnkTndrCmt.Visible = false;
            this.lnkTndrCmt.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkTndrCmt_LinkClicked);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Maroon;
            this.label8.Location = new System.Drawing.Point(13, 4);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(165, 25);
            this.label8.TabIndex = 11;
            this.label8.Text = "Export To Excel";
            // 
            // lnkTndrTracking
            // 
            this.lnkTndrTracking.ActiveLinkColor = System.Drawing.Color.DarkSlateBlue;
            this.lnkTndrTracking.AutoSize = true;
            this.lnkTndrTracking.BackColor = System.Drawing.Color.White;
            this.lnkTndrTracking.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkTndrTracking.ForeColor = System.Drawing.Color.DarkGray;
            this.lnkTndrTracking.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lnkTndrTracking.LinkBehavior = System.Windows.Forms.LinkBehavior.AlwaysUnderline;
            this.lnkTndrTracking.LinkColor = System.Drawing.Color.Blue;
            this.lnkTndrTracking.Location = new System.Drawing.Point(15, 36);
            this.lnkTndrTracking.Name = "lnkTndrTracking";
            this.lnkTndrTracking.Padding = new System.Windows.Forms.Padding(3);
            this.lnkTndrTracking.Size = new System.Drawing.Size(178, 24);
            this.lnkTndrTracking.TabIndex = 9;
            this.lnkTndrTracking.TabStop = true;
            this.lnkTndrTracking.Text = "Tender Tracking Reports";
            this.lnkTndrTracking.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lnkTndrTracking.Visible = false;
            this.lnkTndrTracking.VisitedLinkColor = System.Drawing.Color.Blue;
            this.lnkTndrTracking.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkTndrTracking_LinkClicked);
            // 
            // lblCurrentReportName
            // 
            this.lblCurrentReportName.AutoSize = true;
            this.lblCurrentReportName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentReportName.ForeColor = System.Drawing.Color.Maroon;
            this.lblCurrentReportName.Location = new System.Drawing.Point(539, 4);
            this.lblCurrentReportName.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lblCurrentReportName.Name = "lblCurrentReportName";
            this.lblCurrentReportName.Size = new System.Drawing.Size(0, 16);
            this.lblCurrentReportName.TabIndex = 28;
            // 
            // lnkReTenderProj
            // 
            this.lnkReTenderProj.AutoSize = true;
            this.lnkReTenderProj.BackColor = System.Drawing.Color.White;
            this.lnkReTenderProj.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lnkReTenderProj.Location = new System.Drawing.Point(16, 126);
            this.lnkReTenderProj.Name = "lnkReTenderProj";
            this.lnkReTenderProj.Size = new System.Drawing.Size(137, 18);
            this.lnkReTenderProj.TabIndex = 27;
            this.lnkReTenderProj.TabStop = true;
            this.lnkReTenderProj.Text = "Re-Tender Projects";
            this.lnkReTenderProj.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkReTenderProj_LinkClicked);
            // 
            // frmReports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FloralWhite;
            this.ClientSize = new System.Drawing.Size(1404, 814);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.lblReport);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmReports";
            this.Text = "TCMS Summary Reports";
            this.Load += new System.EventHandler(this.frmReports_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.grpBoxOtherReports.ResumeLayout(false);
            this.grpBoxOtherReports.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblReport;
        private System.Windows.Forms.WebBrowser wbReport;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cmbTenderCommittee;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label lblAffairs;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbTenderStage;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbDepartment;
        private System.Windows.Forms.ComboBox cmbFiscalyear;
        private System.Windows.Forms.ComboBox cmbAffairs;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbTenderType;
        private System.Windows.Forms.ComboBox cmbTenderStatus;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Button btnSubmitReport;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbContractType;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.LinkLabel lnkTndrCmt;
        private System.Windows.Forms.LinkLabel lnkTndrTracking;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.LinkLabel linkProjTracking;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.LinkLabel linkTotTndrApprovalDays;
        private System.Windows.Forms.LinkLabel linkContractorDetails;
        private System.Windows.Forms.LinkLabel linkStaffJobTrackDetails;
        private System.Windows.Forms.Label lblStartRepDate;
        private System.Windows.Forms.DateTimePicker dtpStartReportDate;
        private System.Windows.Forms.Label lblEndRepDate;
        private System.Windows.Forms.DateTimePicker dtpEndReportDate;
        private System.Windows.Forms.LinkLabel linkAwardedTenders;
        private System.Windows.Forms.LinkLabel linkCoParticipationInDiffTenders;
        private System.Windows.Forms.LinkLabel linkContractorQatariNonQatariShare;
        private System.Windows.Forms.Label lblTotalNoOfRecords;
        private System.Windows.Forms.LinkLabel linkQSWorkingStatus;
        private System.Windows.Forms.LinkLabel linkShowContracts;
        private System.Windows.Forms.GroupBox grpBoxOtherReports;
        private System.Windows.Forms.Label lblCurrentReportName;
        private System.Windows.Forms.LinkLabel linkCntrAmnt;
        private System.Windows.Forms.LinkLabel linkTenderingRecs;
        private System.Windows.Forms.LinkLabel lnkContractsInfo;
        private System.Windows.Forms.LinkLabel TenderCommittee;
        private System.Windows.Forms.LinkLabel CommittedContacts;
        private System.Windows.Forms.LinkLabel linkWorkOrder;
        private System.Windows.Forms.LinkLabel lnkTndrCmtAward;
        private System.Windows.Forms.LinkLabel lnkTdrBondTracking;
        private System.Windows.Forms.LinkLabel lnkLocalCompanies;
        private System.Windows.Forms.LinkLabel lnkReTenderProj;
    }
}