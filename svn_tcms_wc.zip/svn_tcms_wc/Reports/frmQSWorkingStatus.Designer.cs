﻿namespace MDI_ParenrForm.Reports
{
    partial class frmQSWorkingStatus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAssignedQS = new System.Windows.Forms.Label();
            this.cmbAssignedQS = new System.Windows.Forms.ComboBox();
            this.lblQSWorkingStatus = new System.Windows.Forms.Label();
            this.cmbQSWorkingStatus = new System.Windows.Forms.ComboBox();
            this.webReport = new System.Windows.Forms.WebBrowser();
            this.btnGenerateQSWorkingStatusReport = new System.Windows.Forms.Button();
            this.btnExportToExcel = new System.Windows.Forms.Button();
            this.lblTotRecCount = new System.Windows.Forms.Label();
            this.dtEndReportDate = new System.Windows.Forms.DateTimePicker();
            this.lblEndReportDate = new System.Windows.Forms.Label();
            this.dtStartReportDate = new System.Windows.Forms.DateTimePicker();
            this.lblStartReportDate = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblAssignedQS
            // 
            this.lblAssignedQS.AutoSize = true;
            this.lblAssignedQS.Location = new System.Drawing.Point(89, 42);
            this.lblAssignedQS.Name = "lblAssignedQS";
            this.lblAssignedQS.Size = new System.Drawing.Size(68, 13);
            this.lblAssignedQS.TabIndex = 0;
            this.lblAssignedQS.Text = "Assigned QS";
            // 
            // cmbAssignedQS
            // 
            this.cmbAssignedQS.FormattingEnabled = true;
            this.cmbAssignedQS.Location = new System.Drawing.Point(88, 58);
            this.cmbAssignedQS.Name = "cmbAssignedQS";
            this.cmbAssignedQS.Size = new System.Drawing.Size(185, 21);
            this.cmbAssignedQS.TabIndex = 1;
            this.cmbAssignedQS.SelectionChangeCommitted += new System.EventHandler(this.cmbAssignedQS_SelectionChangeCommitted);
            // 
            // lblQSWorkingStatus
            // 
            this.lblQSWorkingStatus.AutoSize = true;
            this.lblQSWorkingStatus.Location = new System.Drawing.Point(310, 42);
            this.lblQSWorkingStatus.Name = "lblQSWorkingStatus";
            this.lblQSWorkingStatus.Size = new System.Drawing.Size(98, 13);
            this.lblQSWorkingStatus.TabIndex = 2;
            this.lblQSWorkingStatus.Text = "QS Working Status";
            // 
            // cmbQSWorkingStatus
            // 
            this.cmbQSWorkingStatus.FormattingEnabled = true;
            this.cmbQSWorkingStatus.Location = new System.Drawing.Point(309, 58);
            this.cmbQSWorkingStatus.Name = "cmbQSWorkingStatus";
            this.cmbQSWorkingStatus.Size = new System.Drawing.Size(155, 21);
            this.cmbQSWorkingStatus.TabIndex = 3;
            this.cmbQSWorkingStatus.SelectionChangeCommitted += new System.EventHandler(this.cmbTenderIssue_SelectionChangeCommitted);
            // 
            // webReport
            // 
            this.webReport.Location = new System.Drawing.Point(29, 139);
            this.webReport.MinimumSize = new System.Drawing.Size(20, 20);
            this.webReport.Name = "webReport";
            this.webReport.Size = new System.Drawing.Size(1007, 430);
            this.webReport.TabIndex = 8;
            // 
            // btnGenerateQSWorkingStatusReport
            // 
            this.btnGenerateQSWorkingStatusReport.Location = new System.Drawing.Point(423, 101);
            this.btnGenerateQSWorkingStatusReport.Name = "btnGenerateQSWorkingStatusReport";
            this.btnGenerateQSWorkingStatusReport.Size = new System.Drawing.Size(98, 23);
            this.btnGenerateQSWorkingStatusReport.TabIndex = 9;
            this.btnGenerateQSWorkingStatusReport.Text = "Generate Report";
            this.btnGenerateQSWorkingStatusReport.UseVisualStyleBackColor = true;
            this.btnGenerateQSWorkingStatusReport.Click += new System.EventHandler(this.btnGenerateQSWorkingStatusReport_Click);
            // 
            // btnExportToExcel
            // 
            this.btnExportToExcel.BackColor = System.Drawing.Color.Coral;
            this.btnExportToExcel.Location = new System.Drawing.Point(538, 101);
            this.btnExportToExcel.Name = "btnExportToExcel";
            this.btnExportToExcel.Size = new System.Drawing.Size(98, 23);
            this.btnExportToExcel.TabIndex = 10;
            this.btnExportToExcel.Text = "Export To Excel";
            this.btnExportToExcel.UseVisualStyleBackColor = false;
            this.btnExportToExcel.Click += new System.EventHandler(this.btnExportToExcel_Click);
            // 
            // lblTotRecCount
            // 
            this.lblTotRecCount.AutoSize = true;
            this.lblTotRecCount.Location = new System.Drawing.Point(910, 581);
            this.lblTotRecCount.Name = "lblTotRecCount";
            this.lblTotRecCount.Size = new System.Drawing.Size(0, 13);
            this.lblTotRecCount.TabIndex = 13;
            // 
            // dtEndReportDate
            // 
            this.dtEndReportDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtEndReportDate.Location = new System.Drawing.Point(623, 58);
            this.dtEndReportDate.Name = "dtEndReportDate";
            this.dtEndReportDate.Size = new System.Drawing.Size(93, 20);
            this.dtEndReportDate.TabIndex = 17;
            this.dtEndReportDate.Value = new System.DateTime(2017, 8, 23, 0, 0, 0, 0);
            this.dtEndReportDate.ValueChanged += new System.EventHandler(this.dtEndReportDate_ValueChanged);
            // 
            // lblEndReportDate
            // 
            this.lblEndReportDate.AutoSize = true;
            this.lblEndReportDate.Location = new System.Drawing.Point(620, 42);
            this.lblEndReportDate.Name = "lblEndReportDate";
            this.lblEndReportDate.Size = new System.Drawing.Size(87, 13);
            this.lblEndReportDate.TabIndex = 16;
            this.lblEndReportDate.Text = "End Report Date";
            // 
            // dtStartReportDate
            // 
            this.dtStartReportDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtStartReportDate.Location = new System.Drawing.Point(489, 58);
            this.dtStartReportDate.Name = "dtStartReportDate";
            this.dtStartReportDate.Size = new System.Drawing.Size(98, 20);
            this.dtStartReportDate.TabIndex = 15;
            this.dtStartReportDate.ValueChanged += new System.EventHandler(this.dtStartReportDate_ValueChanged);
            // 
            // lblStartReportDate
            // 
            this.lblStartReportDate.AutoSize = true;
            this.lblStartReportDate.Location = new System.Drawing.Point(486, 42);
            this.lblStartReportDate.Name = "lblStartReportDate";
            this.lblStartReportDate.Size = new System.Drawing.Size(90, 13);
            this.lblStartReportDate.TabIndex = 14;
            this.lblStartReportDate.Text = "Start Report Date";
            // 
            // frmQSWorkingStatus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FloralWhite;
            this.ClientSize = new System.Drawing.Size(1048, 613);
            this.Controls.Add(this.dtEndReportDate);
            this.Controls.Add(this.lblEndReportDate);
            this.Controls.Add(this.dtStartReportDate);
            this.Controls.Add(this.lblStartReportDate);
            this.Controls.Add(this.lblTotRecCount);
            this.Controls.Add(this.btnExportToExcel);
            this.Controls.Add(this.btnGenerateQSWorkingStatusReport);
            this.Controls.Add(this.webReport);
            this.Controls.Add(this.cmbQSWorkingStatus);
            this.Controls.Add(this.lblQSWorkingStatus);
            this.Controls.Add(this.cmbAssignedQS);
            this.Controls.Add(this.lblAssignedQS);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmQSWorkingStatus";
            this.Text = "QS Working Status Reports";
            this.Load += new System.EventHandler(this.frmStaffJobTrackingDetails_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAssignedQS;
        private System.Windows.Forms.ComboBox cmbAssignedQS;
        private System.Windows.Forms.Label lblQSWorkingStatus;
        private System.Windows.Forms.ComboBox cmbQSWorkingStatus;
        private System.Windows.Forms.WebBrowser webReport;
        private System.Windows.Forms.Button btnGenerateQSWorkingStatusReport;
        private System.Windows.Forms.Button btnExportToExcel;
        private System.Windows.Forms.Label lblTotRecCount;
        private System.Windows.Forms.DateTimePicker dtEndReportDate;
        private System.Windows.Forms.Label lblEndReportDate;
        private System.Windows.Forms.DateTimePicker dtStartReportDate;
        private System.Windows.Forms.Label lblStartReportDate;
    }
}