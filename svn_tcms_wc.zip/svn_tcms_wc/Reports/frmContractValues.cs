﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TenderTrackingSystem;
using System.Data.SqlClient;
using System.Configuration;

namespace MDI_ParenrForm.Reports
{
    public partial class frmContractValues : Form
    {
        DAL dalObj = null;
        CommonClass comCls = null;
        IList<string> mUserRightsCollComm = null;
        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();
        public frmContractValues()
        {
            InitializeComponent();
            dalObj = new DAL();
            comCls = new CommonClass("");         
            FillWithFiscalYears();
            FillWithCommittee();
        }

        private void frmContractValues_Load(object sender, EventArgs e)
        {
           
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            SearchContractNo();     
        }
        private void SearchContractNo()
        {
            if (txtCntrMinVal.Text == "")
                txtCntrMinVal.Text = "1";
          
            try
            {
                string sqlListOfContractsQuery = string.Empty;

                if ((cmbFiscalyear.SelectedValue.ToString() != "0") & (cmbCommittee.SelectedValue.ToString() != "0"))
                {
                    if (txtCntrMaxVal.Text == "")
                    {
                        sqlListOfContractsQuery = "SELECT PROJECTS.project_newname_en AS ProjectTitle, PROJECTS.tender_no, Committee.committee_short_name, COMPANY.co_name, CONTRACTORS.ContractAmount, " +
                     "  CONTRACTORS.contract_no,FiscalYear.FiscalYear FROM  CONTRACTORS INNER JOIN PROJECTS ON CONTRACTORS.proj_id = PROJECTS.proj_id INNER JOIN  Committee ON PROJECTS.committee_id = Committee.committee_id INNER JOIN " +
                     " COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON PROJECTS.FYID = FiscalYear.FYID WHERE  (CONTRACTORS.ContractAmount >= '" + txtCntrMinVal.Text + "') " + 
                     " AND (FiscalYear.FYID = '" + cmbFiscalyear.SelectedValue.ToString() + "') AND (CONTRACTORS.contract_no IS NOT NULL) AND (CONTRACTORS.contract_no <> '') " +
                     " AND (PROJECTS.Tender_Status_id <> 8) AND (PROJECTS.Tender_Status_id <> 11) and (Committee.committee_id = " + cmbCommittee.SelectedValue + ")  ORDER BY CONTRACTORS.ContractAmount ";

                    }
                    else
                    {
                        sqlListOfContractsQuery = "SELECT PROJECTS.project_newname_en AS ProjectTitle, PROJECTS.tender_no, Committee.committee_short_name, COMPANY.co_name, CONTRACTORS.ContractAmount, " +
                          "  CONTRACTORS.contract_no,FiscalYear.FiscalYear FROM  CONTRACTORS INNER JOIN PROJECTS ON CONTRACTORS.proj_id = PROJECTS.proj_id INNER JOIN  Committee ON PROJECTS.committee_id = Committee.committee_id INNER JOIN " +
                           " COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON PROJECTS.FYID = FiscalYear.FYID WHERE  (CONTRACTORS.ContractAmount >= '" + txtCntrMinVal.Text + "') " + 
                        " AND (CONTRACTORS.ContractAmount <= '" + txtCntrMaxVal.Text + "') AND (FiscalYear.FYID = '" + cmbFiscalyear.SelectedValue.ToString() + "') AND (CONTRACTORS.contract_no IS NOT NULL) AND (CONTRACTORS.contract_no <> '') " +
                           " AND (PROJECTS.Tender_Status_id <> 8) AND (PROJECTS.Tender_Status_id <> 11) and (Committee.committee_id = " + cmbCommittee.SelectedValue + ") ORDER BY CONTRACTORS.ContractAmount ";
                    }
                }
                else if ((cmbFiscalyear.SelectedValue.ToString() != "0") & (cmbCommittee.SelectedValue.ToString() == "0"))
                {
                    if (txtCntrMaxVal.Text.Trim() == "" && txtCntrMinVal.Text.Trim() != "" && cmbCommittee.SelectedValue.ToString() == "0")
                    {
                        sqlListOfContractsQuery = "SELECT PROJECTS.project_newname_en AS ProjectTitle, PROJECTS.tender_no, Committee.committee_short_name, COMPANY.co_name, CONTRACTORS.ContractAmount, " +
                     "  CONTRACTORS.contract_no,FiscalYear.FiscalYear FROM  CONTRACTORS INNER JOIN PROJECTS ON CONTRACTORS.proj_id = PROJECTS.proj_id INNER JOIN  Committee ON PROJECTS.committee_id = Committee.committee_id INNER JOIN " +
                     " COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON PROJECTS.FYID = FiscalYear.FYID WHERE  (CONTRACTORS.ContractAmount >= '" + txtCntrMinVal.Text + "') " +
                     " AND (FiscalYear.FYID = '" + cmbFiscalyear.SelectedValue.ToString() + "') AND (CONTRACTORS.contract_no IS NOT NULL) AND (CONTRACTORS.contract_no <> '') " +
                     " AND (PROJECTS.Tender_Status_id <> 8) AND (PROJECTS.Tender_Status_id <> 11) ORDER BY CONTRACTORS.ContractAmount ";

                    }
                    else if (txtCntrMaxVal.Text.Trim() != "" && txtCntrMinVal.Text.Trim() != "" && cmbCommittee.SelectedValue.ToString() == "0")                    
                    {
                        sqlListOfContractsQuery = "SELECT PROJECTS.project_newname_en AS ProjectTitle, PROJECTS.tender_no, Committee.committee_short_name, COMPANY.co_name, CONTRACTORS.ContractAmount, " +
                          "  CONTRACTORS.contract_no,FiscalYear.FiscalYear FROM  CONTRACTORS INNER JOIN PROJECTS ON CONTRACTORS.proj_id = PROJECTS.proj_id INNER JOIN  Committee ON PROJECTS.committee_id = Committee.committee_id INNER JOIN " +
                           " COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON PROJECTS.FYID = FiscalYear.FYID WHERE  (CONTRACTORS.ContractAmount >= '" + txtCntrMinVal.Text + "') " +
                        " AND (CONTRACTORS.ContractAmount <= '" + txtCntrMaxVal.Text + "') AND (FiscalYear.FYID = '" + cmbFiscalyear.SelectedValue.ToString() + "') AND (CONTRACTORS.contract_no IS NOT NULL) AND (CONTRACTORS.contract_no <> '') " +
                           " AND (PROJECTS.Tender_Status_id <> 8) AND (PROJECTS.Tender_Status_id <> 11)  ORDER BY CONTRACTORS.ContractAmount ";
                    }
                    else if (txtCntrMaxVal.Text.Trim() == "" && txtCntrMinVal.Text.Trim() == "" && cmbCommittee.SelectedValue.ToString() == "0")
                    {
                        sqlListOfContractsQuery = "SELECT PROJECTS.project_newname_en AS ProjectTitle, PROJECTS.tender_no, Committee.committee_short_name, COMPANY.co_name, CONTRACTORS.ContractAmount, " +
                        "  CONTRACTORS.contract_no,FiscalYear.FiscalYear FROM  CONTRACTORS INNER JOIN PROJECTS ON CONTRACTORS.proj_id = PROJECTS.proj_id INNER JOIN  Committee ON PROJECTS.committee_id = Committee.committee_id INNER JOIN " +
                        " COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON PROJECTS.FYID = FiscalYear.FYID WHERE (FiscalYear.FYID = '" + cmbFiscalyear.SelectedValue.ToString() + "') AND (CONTRACTORS.contract_no IS NOT NULL) AND (CONTRACTORS.contract_no <> '') " +
                        " AND (PROJECTS.Tender_Status_id <> 8) AND (PROJECTS.Tender_Status_id <> 11)  ORDER BY CONTRACTORS.ContractAmount ";
                    }
                }
                else if ((cmbFiscalyear.SelectedValue.ToString() == "0") & (cmbCommittee.SelectedValue.ToString() != "0"))
                {
                    if (txtCntrMaxVal.Text == "")
                    {
                        sqlListOfContractsQuery = "SELECT PROJECTS.project_newname_en AS ProjectTitle, PROJECTS.tender_no, Committee.committee_short_name, COMPANY.co_name, CONTRACTORS.ContractAmount, " +
                     "  CONTRACTORS.contract_no,FiscalYear.FiscalYear FROM  CONTRACTORS INNER JOIN PROJECTS ON CONTRACTORS.proj_id = PROJECTS.proj_id INNER JOIN  Committee ON PROJECTS.committee_id = Committee.committee_id INNER JOIN " +
                     " COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON PROJECTS.FYID = FiscalYear.FYID WHERE  (CONTRACTORS.ContractAmount >= '" + txtCntrMinVal.Text + "') " +
                     "  AND (CONTRACTORS.contract_no IS NOT NULL) AND (CONTRACTORS.contract_no <> '') " +
                     " AND (PROJECTS.Tender_Status_id <> 8) AND (PROJECTS.Tender_Status_id <> 11) and (Committee.committee_id = " + cmbCommittee.SelectedValue + ")  ORDER BY CONTRACTORS.ContractAmount ";

                    }
                    else
                    {
                        sqlListOfContractsQuery = "SELECT PROJECTS.project_newname_en AS ProjectTitle, PROJECTS.tender_no, Committee.committee_short_name, COMPANY.co_name, CONTRACTORS.ContractAmount, " +
                          "  CONTRACTORS.contract_no,FiscalYear.FiscalYear FROM  CONTRACTORS INNER JOIN PROJECTS ON CONTRACTORS.proj_id = PROJECTS.proj_id INNER JOIN  Committee ON PROJECTS.committee_id = Committee.committee_id INNER JOIN " +
                           " COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON PROJECTS.FYID = FiscalYear.FYID WHERE  (CONTRACTORS.ContractAmount >= '" + txtCntrMinVal.Text + "') " +
                        " AND (CONTRACTORS.ContractAmount <= '" + txtCntrMaxVal.Text + "')  AND (CONTRACTORS.contract_no IS NOT NULL) AND (CONTRACTORS.contract_no <> '') " +
                           " AND (PROJECTS.Tender_Status_id <> 8) AND (PROJECTS.Tender_Status_id <> 11)  ORDER BY CONTRACTORS.ContractAmount ";
                    }
                }
                else 
                {
                    if (txtCntrMaxVal.Text == "")
                    {
                        sqlListOfContractsQuery = "SELECT PROJECTS.project_newname_en AS ProjectTitle, PROJECTS.tender_no, Committee.committee_short_name, COMPANY.co_name, CONTRACTORS.ContractAmount, " +
                     "  CONTRACTORS.contract_no,FiscalYear.FiscalYear FROM  CONTRACTORS INNER JOIN PROJECTS ON CONTRACTORS.proj_id = PROJECTS.proj_id INNER JOIN  Committee ON PROJECTS.committee_id = Committee.committee_id INNER JOIN " +
                      " COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON PROJECTS.FYID = FiscalYear.FYID WHERE (CONTRACTORS.ContractAmount >= '" + txtCntrMinVal.Text + "') AND (CONTRACTORS.contract_no IS NOT NULL) AND (CONTRACTORS.contract_no <> '') " +
                      " AND (PROJECTS.Tender_Status_id <> 8) AND (PROJECTS.Tender_Status_id <> 11)  ORDER BY CONTRACTORS.ContractAmount ";
                    }
                    else
                    {
                        sqlListOfContractsQuery = "SELECT PROJECTS.project_newname_en AS ProjectTitle, PROJECTS.tender_no, Committee.committee_short_name, COMPANY.co_name, CONTRACTORS.ContractAmount, " +
                         "  CONTRACTORS.contract_no,FiscalYear.FiscalYear FROM  CONTRACTORS INNER JOIN PROJECTS ON CONTRACTORS.proj_id = PROJECTS.proj_id INNER JOIN  Committee ON PROJECTS.committee_id = Committee.committee_id INNER JOIN " +
                          " COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN FiscalYear ON PROJECTS.FYID = FiscalYear.FYID WHERE  (CONTRACTORS.ContractAmount >= '" + txtCntrMinVal.Text + "') AND (CONTRACTORS.ContractAmount <= '" + txtCntrMaxVal.Text + "') AND (CONTRACTORS.contract_no IS NOT NULL) AND (CONTRACTORS.contract_no <> '') " +
                          " AND (PROJECTS.Tender_Status_id <> 8) AND (PROJECTS.Tender_Status_id <> 11) ORDER BY CONTRACTORS.ContractAmount ";
                    }
                }
               

                DataTable dtListOfContractsReports = dalObj.GetDataFromDB("ContractValuessReports", sqlListOfContractsQuery);
                StringBuilder strBuilder = new StringBuilder();
                if (dtListOfContractsReports.Rows.Count == 0)
                    lblTotRecCount.Text = "Total Records Count=0";
                else
                    lblTotRecCount.Text = "Total Records Count=" + dtListOfContractsReports.Rows.Count;

                strBuilder = CreateListOfContractsReport(strBuilder, dtListOfContractsReports);
                webReport.DocumentText = strBuilder.ToString();
                webReport.ScrollBarsEnabled = true;
                
            }
            catch (Exception)
            {
                MessageBox.Show("Error occurred displaying records", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private StringBuilder CreateListOfContractsReport(StringBuilder strBuilder, DataTable dtReports)
        {
            strBuilder.Append("<table style='border: solid 1px #506E87; width:100%'><tr>");
            strBuilder.Append("<td colspan='14' style='text-align:center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;'><b> Contracts Information Report - Contract Price </b></td></tr>");          
            strBuilder.Append("<tr>" +

            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>SNo.</b></td>" +
           
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Project Title</b></td>" +

            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Tender Number</b></td>" +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Tender Committe</b></td>" +

            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Contractor</b></td>" +

             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b> Value of Contract </b></td>" +

            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Contract Number</b></td>  " + 
            
             "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Fiscal Year</b></td>  " + 
            
            " </tr>");
                                 
            if (dtReports.Rows.Count != 0)
            {
                int rowSNo = 0;
                foreach (DataRow colData in dtReports.Rows)
                {
                    rowSNo = rowSNo+1;
                    strBuilder.Append("<tr>");
                    strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b>" + rowSNo + "</b></td>");

                    strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b>" + colData[0] + "</b></td>");

                    strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b>" + colData[1] + "</b></td>");

                    strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b >" + colData[2] + "</b></td>");

                    if (colData[3] != DBNull.Value)
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[3].ToString() + "</b></td>");
                    else
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b></b></td>");

                    if (colData[4] != DBNull.Value)
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[4].ToString() + "</b></td>");
                    else
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");

                    if (colData[5] != DBNull.Value)
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[5].ToString() + "</b></td>");
                    else
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");

                    strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px'><b>" + colData[6].ToString() + "</b></td>");

                    strBuilder.Append("</tr>");
                }
                strBuilder.Append("<tr><td colspan='14' style=\"width:auto;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b style=\"font-style: italic\">This report is generated by TCMS dated :</b><b>" + DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss") + "</b></td></tr>");
                strBuilder.Append("</table>");
            }
            else
            {
                MessageBox.Show("No data exist for selected option", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                strBuilder.Append("</table>");
            }            
            return strBuilder;
        }

        private void FillWithFiscalYears()
        {
            SqlConnection sqlConn = new SqlConnection(strCon);
            try
            {
                DataTable dtCalendarYear = null;
                sqlConn.Open();
                DAL dalObj = new DAL();
                string sqlQuery = "SELECT FYID,[FiscalYear] FROM [FiscalYear] ORDER BY [FiscalYear] ASC";
                dtCalendarYear = dalObj.GetDataFromDB("FiscalYears", sqlQuery);
                DataRow row = dtCalendarYear.NewRow();
                row["FiscalYear"] = "All";
                row["FYID"] = 0;
                dtCalendarYear.Rows.Add(row);
                cmbFiscalyear.DataSource = dtCalendarYear;
                cmbFiscalyear.DisplayMember = "FiscalYear";
                cmbFiscalyear.ValueMember = "FYID";
                cmbFiscalyear.SelectedIndex = cmbFiscalyear.FindStringExact("All");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred filling the Fiscal Year field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlConn.Close();
            }
        }
        private void FillWithCommittee()
        {
            SqlConnection sqlConn = new SqlConnection(strCon);
            try
            {
                DataTable dtCalendarYear = null;
                sqlConn.Open();
                DAL dalObj = new DAL();
                string sqlQuery = "SELECT committee_id, committee_short_name FROM Committee";
                dtCalendarYear = dalObj.GetDataFromDB("committee_short_name", sqlQuery);
                DataRow row = dtCalendarYear.NewRow();
                row["committee_short_name"] = "All";
                row["committee_id"] = 0;
                dtCalendarYear.Rows.Add(row);
                cmbCommittee.DataSource = dtCalendarYear;
                cmbCommittee.DisplayMember = "committee_short_name";
                cmbCommittee.ValueMember = "committee_id";
                cmbCommittee.SelectedIndex = cmbCommittee.FindStringExact("All");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred filling the committee_short_name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlConn.Close();
            }
        }

        private void btnExportToExcel_Click(object sender, EventArgs e)
        {
            comCls.ExportToExcel(webReport);
        }

    }

   
}
