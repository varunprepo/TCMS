﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TenderTrackingSystem;
using System.Configuration;
using System.Data.SqlClient;

namespace MDI_ParenrForm.Reports
{
    public partial class frmQSWorkingStatus : Form
    {
        DAL dalObj = null;
        CommonClass comCls = null;
        IList<string> mUserRightsCollComm = null;
        public frmQSWorkingStatus(IList<string> userRightsCollComm)
        {
            InitializeComponent();
            dalObj = new DAL();
            comCls = new CommonClass("");
            mUserRightsCollComm = userRightsCollComm;
        }

        private void frmStaffJobTrackingDetails_Load(object sender, EventArgs e)
        {
            string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();  
            SqlConnection sqlConn = null;
            SqlDataReader sqlDtReader = null;             
            //dalObj.populateCmbBox("Select distinct ptd_assign_qs From TenderDatesInfo where ptd_assign_qs is not NULL and ptd_assign_qs <>' ' order by ptd_assign_qs", cmbAssignedQS);
            try
            {

                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                SqlCommand sqlCmd = new SqlCommand("Select distinct ptd_assign_qs From TenderDatesInfo where ptd_assign_qs is not NULL and ptd_assign_qs <>' ' order by ptd_assign_qs", sqlConn);
                sqlDtReader = sqlCmd.ExecuteReader();
                cmbAssignedQS.Items.Add("All");
                if (sqlDtReader.HasRows == true)
                {
                    while (sqlDtReader.Read())
                    {
                        cmbAssignedQS.Items.Add(sqlDtReader[0].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while populating the " + cmbAssignedQS.Name + " combo box, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {
                if (sqlConn != null)
                    sqlConn.Close();
                if (sqlDtReader != null)
                    sqlDtReader.Close();
            }
            cmbAssignedQS.SelectedIndex = 0;

            cmbQSWorkingStatus.Items.Add("All");
            cmbQSWorkingStatus.Items.Add("On-going");
            cmbQSWorkingStatus.Items.Add("Completed");             
            cmbQSWorkingStatus.Items.Add("On Hold");
            cmbQSWorkingStatus.SelectedIndex = 0;           
        }           


        private StringBuilder CreateQSWorkingStatusReport(StringBuilder strBuilder, DataTable dtReports)
        {
            strBuilder.Append("<table style='border: solid 1px #506E87; width:100%'><tr>");
                         
            strBuilder.Append("<td colspan='13' style='text-align:center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;'><b>PWA - STAFF JOB TRACKING DETAILS</b></td></tr>");
            //strBuilder.Append("<tr><td colspan='10' style='text-align: center;font-size: 12pt;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;'><b>Awarded Contracts for Fiscal Year: " + dtProjectIds.Rows[0][1] + "</b></td></tr>");
            //strBuilder.Append("<tr><td colspan='10' style='text-align: center;font-size: 12pt;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;' >Name of the Contractor/Vendor: <b>" + dtView.Row.ItemArray[1].ToString() + "</b></td></tr>");
            
            strBuilder.Append("<tr>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>SNo.</b></td>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Project Code</b></td>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Project Title</b></td>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>TenderNo</b></td>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Type Of Tender</b></td>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>CurrentStage</b></td>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Prepare Tender Document Current Status</b></td>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>QS-Staff Name</b></td>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Received Date</b></td>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Prupose</b></td>" +            
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>User Dept</b></td>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Tender Committee</b></td>" +
            "<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Fiscal Year</b></td></tr>");
          
                if (dtReports.Rows.Count != 0)
                {
                    foreach (DataRow colData in dtReports.Rows)
                    {
                        strBuilder.Append("<tr>");
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b>" + colData[0] + "</b></td>");
                        strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b>" + colData[1] + "</b></td>");
                        if (colData[2] != DBNull.Value)
                            strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b>" + colData[2] + "</b></td>");
                        else
                            strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                        if (colData[3] != DBNull.Value)
                            strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b>" + colData[3] + "</b></td>");
                        else
                            strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                        if (colData[4] != DBNull.Value)
                            strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b >" + colData[4] + "</b></td>");
                        else
                            strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                        if (colData[5] != DBNull.Value)
                            strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b>" + colData[5] + "</b></td>");
                        else
                            strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                        if (colData[6] != DBNull.Value)
                            strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b>" + colData[6] + "</b></td>");
                        else
                            strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                        if (colData[7] != DBNull.Value)
                            strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;background-color:Yellow'><b>" + colData[7] + "</b></td>");
                        else
                            strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                        if (colData[8] != DBNull.Value)
                            strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b>" + colData[8] + "</b></td>");
                        else
                            strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                        if (colData[9] != DBNull.Value)
                            strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b>" + colData[9] + "</b></td>");
                        else
                            strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                        if (colData[10] != DBNull.Value)
                            strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b>" + colData[10] + "</b></td>");
                        else
                            strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                        if (colData[11] != DBNull.Value)
                            strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b>" + colData[11] + "</b></td>");
                        else
                            strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                        if (colData[12] != DBNull.Value)
                            strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b>" + colData[12] + "</b></td>");
                        else
                            strBuilder.Append("<td style='font-weight: bold;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: left;padding-left: 5px;padding-top: 6px;'><b></b></td>");
                        strBuilder.Append("</tr>");
                    }
                    strBuilder.Append("<tr><td colspan='13' style=\"width:auto;font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;height: 35px;\"><b style=\"font-style: italic\">This report is generated by TCMS dated :</b><b>" + DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss") + "</b></td></tr>");
                    strBuilder.Append("</table>");
                }
                else
                {
                    MessageBox.Show("No data exist for selected options", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    strBuilder.Append("</table>");
                }                 
                return strBuilder;
        }



        string assignedQS = null;
        private void cmbAssignedQS_SelectionChangeCommitted(object sender, EventArgs e)
        {            
            if (cmbAssignedQS.SelectedIndex != -1)
                assignedQS = cmbAssignedQS.SelectedItem.ToString();                 
        }

        string qsWorkingStatus = null;
        private void cmbTenderIssue_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (cmbQSWorkingStatus.SelectedIndex != -1)
                qsWorkingStatus = cmbQSWorkingStatus.SelectedItem.ToString();                              
        }      

        private void btnExportToExcel_Click(object sender, EventArgs e)
        {
            comCls.ExportToExcel(webReport);
        }

              

        private void btnGenerateQSWorkingStatusReport_Click(object sender, EventArgs e)
        {
            DataTable dtFinal = new DataTable("FinalReport");
            dtFinal.Columns.Add("SNo.");            
            dtFinal.Columns.Add("ProjectCode");
            dtFinal.Columns.Add("ProjectTitle");
            dtFinal.Columns.Add("TenderNo");
            dtFinal.Columns.Add("TypeOfTender");
            dtFinal.Columns.Add("StageName");
            dtFinal.Columns.Add("Prepare Tender Document Current Status");             
            dtFinal.Columns.Add("QSName");
            dtFinal.Columns.Add("DateReceivedOn");
            dtFinal.Columns.Add("TenderPurpose");             
            dtFinal.Columns.Add("UserDepartment");
            dtFinal.Columns.Add("TenderCommittee");
            dtFinal.Columns.Add("FiscalYear");
            dtFinal.AcceptChanges();

            Int16 rowCounter = 1;
            string sqlStaffReportsQuery = null;
            //if (assignedQS != null)
            //{
            //    if (qsWorkingStatus != null)
            //    {
            if (assignedQS==null)
            {
                assignedQS = "All";
            }
            if (qsWorkingStatus == null)
            {
                qsWorkingStatus = "All";
            }

                    if (startReportDateChanged == 1 || endReportDateChanged==1)
                    {
                        if (startReportDateChanged == 1 && endReportDateChanged == 0)
                        {
                            
                            if (!assignedQS.Equals("All") && !qsWorkingStatus.Equals("All"))
                            {
                                sqlStaffReportsQuery = "select PROJECTS.proj_id,PROJECTS.project_code, PROJECTS.project_newname_en,PROJECTS.Tender_No,TenderTypes.tender_type_name,STAGES.Stage_Name,TenderDatesInfo.ptd_tendec_doc_cur_status,TenderDatesInfo.ptd_assign_qs, TenderDatesInfo.ptd_receive_on, TenderDatesInfo.ptd_purpose,d2.Department,Committee.committee_short_name,FiscalYear.FiscalYear from TenderDatesInfo join PROJECTS on TenderDatesInfo.proj_id=" +
                                "PROJECTS.proj_id join STAGES on TenderDatesInfo.stage_id=STAGES.stage_id join TenderStatus on PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id join Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id join Committee on PROJECTS.committee_id = Committee.committee_id join FiscalYear on PROJECTS.FYID = FiscalYear.FYID INNER JOIN TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id where " +
                                "TenderDatesInfo.ptd_assign_qs ='" + assignedQS.Trim() + "' and TenderDatesInfo.ptd_qs_working_status ='" + qsWorkingStatus + "' and TenderStatus.Tender_Status_id not in(8,9,10) and TenderDatesInfo.stage_id=1 and TenderDatesInfo.ptd_receive_on >='" + dtStartReportDate.Value.ToString("dd/MMM/yyyy") + "' ORDER BY TenderDatesInfo.ptd_forwarded_to_dep DESC";
                            }
                            else if (assignedQS.Equals("All") && !qsWorkingStatus.Equals("All"))
                            {
                                sqlStaffReportsQuery = "select PROJECTS.proj_id,PROJECTS.project_code, PROJECTS.project_newname_en,PROJECTS.Tender_No,TenderTypes.tender_type_name,STAGES.Stage_Name,TenderDatesInfo.ptd_tendec_doc_cur_status,TenderDatesInfo.ptd_assign_qs, TenderDatesInfo.ptd_receive_on, TenderDatesInfo.ptd_purpose,d2.Department,Committee.committee_short_name,FiscalYear.FiscalYear from TenderDatesInfo join PROJECTS on TenderDatesInfo.proj_id=" +
                                "PROJECTS.proj_id join STAGES on TenderDatesInfo.stage_id=STAGES.stage_id join TenderStatus on PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id join Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id join Committee on PROJECTS.committee_id = Committee.committee_id join FiscalYear on PROJECTS.FYID = FiscalYear.FYID INNER JOIN TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id where " +
                                " TenderDatesInfo.ptd_qs_working_status ='" + qsWorkingStatus + "' and TenderStatus.Tender_Status_id not in(8,9,10) and TenderDatesInfo.stage_id=1 and TenderDatesInfo.ptd_receive_on >='" + dtStartReportDate.Value.ToString("dd/MMM/yyyy") + "' ORDER BY TenderDatesInfo.ptd_forwarded_to_dep DESC";
                            }
                            else if (!assignedQS.Equals("All") && qsWorkingStatus.Equals("All"))
                            {
                                sqlStaffReportsQuery = "select PROJECTS.proj_id,PROJECTS.project_code, PROJECTS.project_newname_en,PROJECTS.Tender_No,TenderTypes.tender_type_name,STAGES.Stage_Name,TenderDatesInfo.ptd_tendec_doc_cur_status,TenderDatesInfo.ptd_assign_qs, TenderDatesInfo.ptd_receive_on, TenderDatesInfo.ptd_purpose,d2.Department,Committee.committee_short_name,FiscalYear.FiscalYear from TenderDatesInfo join PROJECTS on TenderDatesInfo.proj_id=" +
                                "PROJECTS.proj_id join STAGES on TenderDatesInfo.stage_id=STAGES.stage_id join TenderStatus on PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id join Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id join Committee on PROJECTS.committee_id = Committee.committee_id join FiscalYear on PROJECTS.FYID = FiscalYear.FYID INNER JOIN TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id where " +
                                "TenderDatesInfo.ptd_assign_qs ='" + assignedQS.Trim() + "' and TenderStatus.Tender_Status_id not in(8,9,10) and TenderDatesInfo.stage_id=1 and TenderDatesInfo.ptd_receive_on >='" + dtStartReportDate.Value.ToString("dd/MMM/yyyy") + "' ORDER BY TenderDatesInfo.ptd_forwarded_to_dep DESC";
                            }
                            else if (assignedQS.Equals("All") && qsWorkingStatus.Equals("All"))
                            {
                                sqlStaffReportsQuery = "select PROJECTS.proj_id,PROJECTS.project_code, PROJECTS.project_newname_en,PROJECTS.Tender_No,TenderTypes.tender_type_name,STAGES.Stage_Name,TenderDatesInfo.ptd_tendec_doc_cur_status,TenderDatesInfo.ptd_assign_qs, TenderDatesInfo.ptd_receive_on, TenderDatesInfo.ptd_purpose,d2.Department,Committee.committee_short_name,FiscalYear.FiscalYear from TenderDatesInfo join PROJECTS on TenderDatesInfo.proj_id=" +
                                "PROJECTS.proj_id join STAGES on TenderDatesInfo.stage_id=STAGES.stage_id join TenderStatus on PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id join Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id join Committee on PROJECTS.committee_id = Committee.committee_id join FiscalYear on PROJECTS.FYID = FiscalYear.FYID INNER JOIN TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id where " +
                                " TenderStatus.Tender_Status_id not in(8,9,10) and TenderDatesInfo.stage_id=1 and TenderDatesInfo.ptd_receive_on >='" + dtStartReportDate.Value.ToString("dd/MMM/yyyy") + "' ORDER BY TenderDatesInfo.ptd_forwarded_to_dep DESC";
                            }
                            
                        }
                        else if (startReportDateChanged == 0 && endReportDateChanged == 1)
                        {
                            if (!assignedQS.Equals("All") && !qsWorkingStatus.Equals("All"))
                            {
                                sqlStaffReportsQuery = "select PROJECTS.proj_id,PROJECTS.project_code, PROJECTS.project_newname_en,PROJECTS.Tender_No,TenderTypes.tender_type_name,STAGES.Stage_Name,TenderDatesInfo.ptd_tendec_doc_cur_status,TenderDatesInfo.ptd_assign_qs, TenderDatesInfo.ptd_receive_on, TenderDatesInfo.ptd_purpose,d2.Department,Committee.committee_short_name,FiscalYear.FiscalYear from TenderDatesInfo join PROJECTS on TenderDatesInfo.proj_id=" +
                                "PROJECTS.proj_id join STAGES on TenderDatesInfo.stage_id=STAGES.stage_id join TenderStatus on PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id join Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id join Committee on PROJECTS.committee_id = Committee.committee_id join FiscalYear on PROJECTS.FYID = FiscalYear.FYID INNER JOIN TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id where " +
                                "TenderDatesInfo.ptd_assign_qs ='" + assignedQS.Trim() + "' and TenderDatesInfo.ptd_qs_working_status ='" + qsWorkingStatus + "' and TenderStatus.Tender_Status_id not in(8,9,10) and TenderDatesInfo.stage_id=1 and TenderDatesInfo.ptd_receive_on >='" + dtEndReportDate.Value.ToString("dd/MMM/yyyy") + "' ORDER BY TenderDatesInfo.ptd_forwarded_to_dep DESC";
                            }
                            else if (assignedQS.Equals("All") && !qsWorkingStatus.Equals("All"))
                            {
                                sqlStaffReportsQuery = "select PROJECTS.proj_id,PROJECTS.project_code, PROJECTS.project_newname_en,PROJECTS.Tender_No,TenderTypes.tender_type_name,STAGES.Stage_Name,TenderDatesInfo.ptd_tendec_doc_cur_status,TenderDatesInfo.ptd_assign_qs, TenderDatesInfo.ptd_receive_on, TenderDatesInfo.ptd_purpose,d2.Department,Committee.committee_short_name,FiscalYear.FiscalYear from TenderDatesInfo join PROJECTS on TenderDatesInfo.proj_id=" +
                                "PROJECTS.proj_id join STAGES on TenderDatesInfo.stage_id=STAGES.stage_id join TenderStatus on PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id join Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id join Committee on PROJECTS.committee_id = Committee.committee_id join FiscalYear on PROJECTS.FYID = FiscalYear.FYID INNER JOIN TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id where " +
                                " TenderDatesInfo.ptd_qs_working_status ='" + qsWorkingStatus + "' and TenderStatus.Tender_Status_id not in(8,9,10) and TenderDatesInfo.stage_id=1 and TenderDatesInfo.ptd_receive_on >='" + dtEndReportDate.Value.ToString("dd/MMM/yyyy") + "' ORDER BY TenderDatesInfo.ptd_forwarded_to_dep DESC";
                            }
                            else if (!assignedQS.Equals("All") && qsWorkingStatus.Equals("All"))
                            {
                                sqlStaffReportsQuery = "select PROJECTS.proj_id,PROJECTS.project_code, PROJECTS.project_newname_en,PROJECTS.Tender_No,TenderTypes.tender_type_name,STAGES.Stage_Name,TenderDatesInfo.ptd_tendec_doc_cur_status,TenderDatesInfo.ptd_assign_qs, TenderDatesInfo.ptd_receive_on, TenderDatesInfo.ptd_purpose,d2.Department,Committee.committee_short_name,FiscalYear.FiscalYear from TenderDatesInfo join PROJECTS on TenderDatesInfo.proj_id=" +
                                "PROJECTS.proj_id join STAGES on TenderDatesInfo.stage_id=STAGES.stage_id join TenderStatus on PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id join Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id join Committee on PROJECTS.committee_id = Committee.committee_id join FiscalYear on PROJECTS.FYID = FiscalYear.FYID INNER JOIN TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id where " +
                                "TenderDatesInfo.ptd_assign_qs ='" + assignedQS.Trim() + "' and TenderStatus.Tender_Status_id not in(8,9,10) and TenderDatesInfo.stage_id=1 and TenderDatesInfo.ptd_receive_on >='" + dtEndReportDate.Value.ToString("dd/MMM/yyyy") + "' ORDER BY TenderDatesInfo.ptd_forwarded_to_dep DESC";
                            }
                            else if (assignedQS.Equals("All") && qsWorkingStatus.Equals("All"))
                            {
                                sqlStaffReportsQuery = "select PROJECTS.proj_id,PROJECTS.project_code, PROJECTS.project_newname_en,PROJECTS.Tender_No,TenderTypes.tender_type_name,STAGES.Stage_Name,TenderDatesInfo.ptd_tendec_doc_cur_status,TenderDatesInfo.ptd_assign_qs, TenderDatesInfo.ptd_receive_on, TenderDatesInfo.ptd_purpose,d2.Department,Committee.committee_short_name,FiscalYear.FiscalYear from TenderDatesInfo join PROJECTS on TenderDatesInfo.proj_id=" +
                                "PROJECTS.proj_id join STAGES on TenderDatesInfo.stage_id=STAGES.stage_id join TenderStatus on PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id join Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id join Committee on PROJECTS.committee_id = Committee.committee_id join FiscalYear on PROJECTS.FYID = FiscalYear.FYID INNER JOIN TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id where " +
                                " TenderStatus.Tender_Status_id not in(8,9,10) and TenderDatesInfo.stage_id=1 and TenderDatesInfo.ptd_receive_on >='" + dtEndReportDate.Value.ToString("dd/MMM/yyyy") + "' ORDER BY TenderDatesInfo.ptd_forwarded_to_dep DESC";
                            }
                        }
                        else
                        {
                            if (!assignedQS.Equals("All") && !qsWorkingStatus.Equals("All"))
                            {
                                sqlStaffReportsQuery = "select PROJECTS.proj_id,PROJECTS.project_code, PROJECTS.project_newname_en,PROJECTS.Tender_No,TenderTypes.tender_type_name,STAGES.Stage_Name,TenderDatesInfo.ptd_tendec_doc_cur_status,TenderDatesInfo.ptd_assign_qs, TenderDatesInfo.ptd_receive_on, TenderDatesInfo.ptd_purpose,d2.Department,Committee.committee_short_name,FiscalYear.FiscalYear from TenderDatesInfo join PROJECTS on TenderDatesInfo.proj_id=" +
                                "PROJECTS.proj_id join STAGES on TenderDatesInfo.stage_id=STAGES.stage_id join TenderStatus on PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id join Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id join Committee on PROJECTS.committee_id = Committee.committee_id join FiscalYear on PROJECTS.FYID = FiscalYear.FYID INNER JOIN TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id where " +
                                "TenderDatesInfo.ptd_assign_qs ='" + assignedQS.Trim() + "' and TenderDatesInfo.ptd_qs_working_status ='" + qsWorkingStatus + "' and TenderStatus.Tender_Status_id not in(8,9,10) and TenderDatesInfo.stage_id=1 and TenderDatesInfo.ptd_receive_on between '" + dtStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtEndReportDate.Value.ToString("dd/MMM/yyyy") + "' ORDER BY TenderDatesInfo.ptd_forwarded_to_dep DESC";
                            }
                            else if (assignedQS.Equals("All") && !qsWorkingStatus.Equals("All"))
                            {
                               sqlStaffReportsQuery = "select PROJECTS.proj_id,PROJECTS.project_code, PROJECTS.project_newname_en,PROJECTS.Tender_No,TenderTypes.tender_type_name,STAGES.Stage_Name,TenderDatesInfo.ptd_tendec_doc_cur_status,TenderDatesInfo.ptd_assign_qs, TenderDatesInfo.ptd_receive_on, TenderDatesInfo.ptd_purpose,d2.Department,Committee.committee_short_name,FiscalYear.FiscalYear from TenderDatesInfo join PROJECTS on TenderDatesInfo.proj_id=" +
                               "PROJECTS.proj_id join STAGES on TenderDatesInfo.stage_id=STAGES.stage_id join TenderStatus on PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id join Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id join Committee on PROJECTS.committee_id = Committee.committee_id join FiscalYear on PROJECTS.FYID = FiscalYear.FYID INNER JOIN TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id where " +
                               " TenderDatesInfo.ptd_qs_working_status ='" + qsWorkingStatus + "' and TenderStatus.Tender_Status_id not in(8,9,10) and TenderDatesInfo.stage_id=1 and TenderDatesInfo.ptd_receive_on between '" + dtStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtEndReportDate.Value.ToString("dd/MMM/yyyy") + "' ORDER BY TenderDatesInfo.ptd_forwarded_to_dep DESC";
                            }
                            else if (!assignedQS.Equals("All") && qsWorkingStatus.Equals("All"))
                            {
                               sqlStaffReportsQuery = "select PROJECTS.proj_id,PROJECTS.project_code, PROJECTS.project_newname_en,PROJECTS.Tender_No,TenderTypes.tender_type_name,STAGES.Stage_Name,TenderDatesInfo.ptd_tendec_doc_cur_status,TenderDatesInfo.ptd_assign_qs, TenderDatesInfo.ptd_receive_on, TenderDatesInfo.ptd_purpose,d2.Department,Committee.committee_short_name,FiscalYear.FiscalYear from TenderDatesInfo join PROJECTS on TenderDatesInfo.proj_id=" +
                               "PROJECTS.proj_id join STAGES on TenderDatesInfo.stage_id=STAGES.stage_id join TenderStatus on PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id join Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id join Committee on PROJECTS.committee_id = Committee.committee_id join FiscalYear on PROJECTS.FYID = FiscalYear.FYID INNER JOIN TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id where " +
                               "TenderDatesInfo.ptd_assign_qs ='" + assignedQS.Trim() + "' and TenderStatus.Tender_Status_id not in(8,9,10) and TenderDatesInfo.stage_id=1 and TenderDatesInfo.ptd_receive_on between '" + dtStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtEndReportDate.Value.ToString("dd/MMM/yyyy") + "' ORDER BY TenderDatesInfo.ptd_forwarded_to_dep DESC";
                            }
                            else if (assignedQS.Equals("All") && qsWorkingStatus.Equals("All"))
                            {
                                sqlStaffReportsQuery = "select PROJECTS.proj_id,PROJECTS.project_code, PROJECTS.project_newname_en,PROJECTS.Tender_No,TenderTypes.tender_type_name,STAGES.Stage_Name,TenderDatesInfo.ptd_tendec_doc_cur_status,TenderDatesInfo.ptd_assign_qs, TenderDatesInfo.ptd_receive_on, TenderDatesInfo.ptd_purpose,d2.Department,Committee.committee_short_name,FiscalYear.FiscalYear from TenderDatesInfo join PROJECTS on TenderDatesInfo.proj_id=" +
                                "PROJECTS.proj_id join STAGES on TenderDatesInfo.stage_id=STAGES.stage_id join TenderStatus on PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id join Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id join Committee on PROJECTS.committee_id = Committee.committee_id join FiscalYear on PROJECTS.FYID = FiscalYear.FYID INNER JOIN TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id where " +
                                " TenderStatus.Tender_Status_id not in(8,9,10) and TenderDatesInfo.stage_id=1 and TenderDatesInfo.ptd_receive_on between '" + dtStartReportDate.Value.ToString("dd/MMM/yyyy") + "' and '" + dtEndReportDate.Value.ToString("dd/MMM/yyyy") + "' ORDER BY TenderDatesInfo.ptd_forwarded_to_dep DESC";
                            }

                        }
                    }
                    else
                    {
                        if (!assignedQS.Equals("All") && !qsWorkingStatus.Equals("All"))
                        {
                            sqlStaffReportsQuery = "select PROJECTS.proj_id,PROJECTS.project_code, PROJECTS.project_newname_en,PROJECTS.Tender_No,TenderTypes.tender_type_name,STAGES.Stage_Name,TenderDatesInfo.ptd_tendec_doc_cur_status,TenderDatesInfo.ptd_assign_qs, TenderDatesInfo.ptd_receive_on, TenderDatesInfo.ptd_purpose,d2.Department,Committee.committee_short_name,FiscalYear.FiscalYear from TenderDatesInfo join PROJECTS on TenderDatesInfo.proj_id=" +
                            "PROJECTS.proj_id join STAGES on TenderDatesInfo.stage_id=STAGES.stage_id join TenderStatus on PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id join Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id join Committee on PROJECTS.committee_id = Committee.committee_id join FiscalYear on PROJECTS.FYID = FiscalYear.FYID INNER JOIN TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id where " +
                            "TenderDatesInfo.ptd_assign_qs ='" + assignedQS.Trim() + "' and TenderDatesInfo.ptd_qs_working_status ='" + qsWorkingStatus + "' and TenderStatus.Tender_Status_id not in(8,9,10) and TenderDatesInfo.stage_id=1 ORDER BY TenderDatesInfo.ptd_forwarded_to_dep DESC";
                        }
                        else if (assignedQS.Equals("All") && !qsWorkingStatus.Equals("All"))
                        {
                           sqlStaffReportsQuery = "select PROJECTS.proj_id,PROJECTS.project_code, PROJECTS.project_newname_en,PROJECTS.Tender_No,TenderTypes.tender_type_name,STAGES.Stage_Name,TenderDatesInfo.ptd_tendec_doc_cur_status,TenderDatesInfo.ptd_assign_qs, TenderDatesInfo.ptd_receive_on, TenderDatesInfo.ptd_purpose,d2.Department,Committee.committee_short_name,FiscalYear.FiscalYear from TenderDatesInfo join PROJECTS on TenderDatesInfo.proj_id=" +
                           "PROJECTS.proj_id join STAGES on TenderDatesInfo.stage_id=STAGES.stage_id join TenderStatus on PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id join Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id join Committee on PROJECTS.committee_id = Committee.committee_id join FiscalYear on PROJECTS.FYID = FiscalYear.FYID INNER JOIN TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id where " +
                           " TenderDatesInfo.ptd_qs_working_status ='" + qsWorkingStatus + "' and TenderStatus.Tender_Status_id not in(8,9,10) and TenderDatesInfo.stage_id=1 ORDER BY TenderDatesInfo.ptd_forwarded_to_dep DESC";
                        }
                        else if (!assignedQS.Equals("All") && qsWorkingStatus.Equals("All"))
                        {
                            sqlStaffReportsQuery = "select PROJECTS.proj_id,PROJECTS.project_code, PROJECTS.project_newname_en,PROJECTS.Tender_No,TenderTypes.tender_type_name,STAGES.Stage_Name,TenderDatesInfo.ptd_tendec_doc_cur_status,TenderDatesInfo.ptd_assign_qs, TenderDatesInfo.ptd_receive_on, TenderDatesInfo.ptd_purpose,d2.Department,Committee.committee_short_name,FiscalYear.FiscalYear from TenderDatesInfo join PROJECTS on TenderDatesInfo.proj_id=" +
                            "PROJECTS.proj_id join STAGES on TenderDatesInfo.stage_id=STAGES.stage_id join TenderStatus on PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id join Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id join Committee on PROJECTS.committee_id = Committee.committee_id join FiscalYear on PROJECTS.FYID = FiscalYear.FYID INNER JOIN TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id where " +
                            "TenderDatesInfo.ptd_assign_qs ='" + assignedQS.Trim() + "' and TenderStatus.Tender_Status_id not in(8,9,10) and TenderDatesInfo.stage_id=1 ORDER BY TenderDatesInfo.ptd_forwarded_to_dep DESC";
                        }
                        else if (assignedQS.Equals("All") && qsWorkingStatus.Equals("All"))
                        {
                            sqlStaffReportsQuery = "select PROJECTS.proj_id,PROJECTS.project_code, PROJECTS.project_newname_en,PROJECTS.Tender_No,TenderTypes.tender_type_name,STAGES.Stage_Name,TenderDatesInfo.ptd_tendec_doc_cur_status,TenderDatesInfo.ptd_assign_qs, TenderDatesInfo.ptd_receive_on, TenderDatesInfo.ptd_purpose,d2.Department,Committee.committee_short_name,FiscalYear.FiscalYear from TenderDatesInfo join PROJECTS on TenderDatesInfo.proj_id=" +
                            "PROJECTS.proj_id join STAGES on TenderDatesInfo.stage_id=STAGES.stage_id join TenderStatus on PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id join Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id join Committee on PROJECTS.committee_id = Committee.committee_id join FiscalYear on PROJECTS.FYID = FiscalYear.FYID INNER JOIN TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id where " +
                            " TenderStatus.Tender_Status_id not in(8,9,10) and TenderDatesInfo.stage_id=1 ORDER BY TenderDatesInfo.ptd_forwarded_to_dep DESC";
                        }
                    }
                //}
                //else
                //{
                    //if (startReportDateChanged == 1 || endReportDateChanged == 1)
                    //{
                    //    if (startReportDateChanged == 1 && endReportDateChanged == 0)
                    //    {
                    //        if (!assignedQS.Equals("All"))
                    //        {
                    //            sqlStaffReportsQuery = "select PROJECTS.project_code, PROJECTS.project_newname_en,PROJECTS.Tender_No,TenderTypes.tender_type_name,STAGES.Stage_Name,TenderDatesInfo.ptd_tendec_doc_cur_status,TenderDatesInfo.ptd_assign_qs, TenderDatesInfo.ptd_receive_on, TenderDatesInfo.ptd_purpose,Department.Department,Committee.committee_short_name,FiscalYear.FiscalYear from TenderDatesInfo join PROJECTS on TenderDatesInfo.proj_id=" +
                    //            "PROJECTS.proj_id join STAGES on TenderDatesInfo.stage_id=STAGES.stage_id join TenderStatus on PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id join Department on PROJECTS.department_id = Department.department_id join Committee on PROJECTS.committee_id = Committee.committee_id join FiscalYear on PROJECTS.FYID = FiscalYear.FYID INNER JOIN TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id where " +
                    //            "TenderDatesInfo.ptd_assign_qs ='" + assignedQS.Trim() + "' and TenderDatesInfo.ptd_qs_working_status is not NULL and TenderStatus.Tender_Status_id not in(8,9,10) and TenderDatesInfo.stage_id=1 and TenderDatesInfo.ptd_receive_on >= '" + dtStartReportDate.Value.ToString("dd/MMM/yyyy") + "' ORDER BY TenderDatesInfo.ptd_forwarded_to_dep DESC";
                    //        }
                    //        else
                    //        {
                    //            sqlStaffReportsQuery = "select PROJECTS.project_code, PROJECTS.project_newname_en,PROJECTS.Tender_No,TenderTypes.tender_type_name,STAGES.Stage_Name,TenderDatesInfo.ptd_tendec_doc_cur_status,TenderDatesInfo.ptd_assign_qs, TenderDatesInfo.ptd_receive_on, TenderDatesInfo.ptd_purpose,Department.Department,Committee.committee_short_name,FiscalYear.FiscalYear from TenderDatesInfo join PROJECTS on TenderDatesInfo.proj_id=" +
                    //            "PROJECTS.proj_id join STAGES on TenderDatesInfo.stage_id=STAGES.stage_id join TenderStatus on PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id join Department on PROJECTS.department_id = Department.department_id join Committee on PROJECTS.committee_id = Committee.committee_id join FiscalYear on PROJECTS.FYID = FiscalYear.FYID INNER JOIN TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id where " +
                    //            " TenderDatesInfo.ptd_qs_working_status is not NULL and TenderStatus.Tender_Status_id not in(8,9,10) and TenderDatesInfo.stage_id=1 and TenderDatesInfo.ptd_receive_on >= '" + dtStartReportDate.Value.ToString("dd/MMM/yyyy") + "' ORDER BY TenderDatesInfo.ptd_forwarded_to_dep DESC";
                    //        }
                    //    }
                    //    else if (startReportDateChanged == 0 && endReportDateChanged == 1)
                    //    {
                    //        if (!assignedQS.Equals("All"))
                    //        {
                    //            sqlStaffReportsQuery = "select PROJECTS.project_code, PROJECTS.project_newname_en,PROJECTS.Tender_No,TenderTypes.tender_type_name,STAGES.Stage_Name,TenderDatesInfo.ptd_tendec_doc_cur_status,TenderDatesInfo.ptd_assign_qs, TenderDatesInfo.ptd_receive_on, TenderDatesInfo.ptd_purpose,Department.Department,Committee.committee_short_name,FiscalYear.FiscalYear from TenderDatesInfo join PROJECTS on TenderDatesInfo.proj_id=" +
                    //            "PROJECTS.proj_id join STAGES on TenderDatesInfo.stage_id=STAGES.stage_id join TenderStatus on PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id join Department on PROJECTS.department_id = Department.department_id join Committee on PROJECTS.committee_id = Committee.committee_id join FiscalYear on PROJECTS.FYID = FiscalYear.FYID INNER JOIN TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id where " +
                    //            "TenderDatesInfo.ptd_assign_qs ='" + assignedQS.Trim() + "' and TenderDatesInfo.ptd_qs_working_status is not NULL and TenderStatus.Tender_Status_id not in(8,9,10) and TenderDatesInfo.stage_id=1 and TenderDatesInfo.ptd_receive_on >= '" + dtEndReportDate.Value.ToString("dd/MMM/yyyy") + "' ORDER BY TenderDatesInfo.ptd_forwarded_to_dep DESC";
                    //        }
                    //        else
                    //        {
                    //            sqlStaffReportsQuery = "select PROJECTS.project_code, PROJECTS.project_newname_en,PROJECTS.Tender_No,TenderTypes.tender_type_name,STAGES.Stage_Name,TenderDatesInfo.ptd_tendec_doc_cur_status,TenderDatesInfo.ptd_assign_qs, TenderDatesInfo.ptd_receive_on, TenderDatesInfo.ptd_purpose,Department.Department,Committee.committee_short_name,FiscalYear.FiscalYear from TenderDatesInfo join PROJECTS on TenderDatesInfo.proj_id=" +
                    //            "PROJECTS.proj_id join STAGES on TenderDatesInfo.stage_id=STAGES.stage_id join TenderStatus on PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id join Department on PROJECTS.department_id = Department.department_id join Committee on PROJECTS.committee_id = Committee.committee_id join FiscalYear on PROJECTS.FYID = FiscalYear.FYID INNER JOIN TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id where " +
                    //            " TenderDatesInfo.ptd_qs_working_status is not NULL and TenderStatus.Tender_Status_id not in(8,9,10) and TenderDatesInfo.stage_id=1 and TenderDatesInfo.ptd_receive_on >= '" + dtEndReportDate.Value.ToString("dd/MMM/yyyy") + "' ORDER BY TenderDatesInfo.ptd_forwarded_to_dep DESC";
                    //        }
                    //    }

                    //}
                    //else  
                    //{
                    //    if (!assignedQS.Equals("All"))
                    //    {
                    //        sqlStaffReportsQuery = "select PROJECTS.project_code, PROJECTS.project_newname_en,PROJECTS.Tender_No,TenderTypes.tender_type_name,STAGES.Stage_Name,TenderDatesInfo.ptd_tendec_doc_cur_status,TenderDatesInfo.ptd_assign_qs, TenderDatesInfo.ptd_receive_on, TenderDatesInfo.ptd_purpose,Department.Department,Committee.committee_short_name,FiscalYear.FiscalYear from TenderDatesInfo join PROJECTS on TenderDatesInfo.proj_id=" +
                    //        "PROJECTS.proj_id join STAGES on TenderDatesInfo.stage_id=STAGES.stage_id join TenderStatus on PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id join Department on PROJECTS.department_id = Department.department_id join Committee on PROJECTS.committee_id = Committee.committee_id join FiscalYear on PROJECTS.FYID = FiscalYear.FYID INNER JOIN TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id where " +
                    //        "TenderDatesInfo.ptd_assign_qs ='" + assignedQS.Trim() + "' and TenderDatesInfo.ptd_qs_working_status is not NULL and TenderStatus.Tender_Status_id not in(8,9,10) and TenderDatesInfo.stage_id=1 and TenderDatesInfo.ptd_receive_on >= '" + dtEndReportDate.Value.ToString("dd/MMM/yyyy") + "' ORDER BY TenderDatesInfo.ptd_forwarded_to_dep DESC";
                    //    }
                    //    else
                    //    {
                    //        sqlStaffReportsQuery = "select PROJECTS.project_code, PROJECTS.project_newname_en,PROJECTS.Tender_No,TenderTypes.tender_type_name,STAGES.Stage_Name,TenderDatesInfo.ptd_tendec_doc_cur_status,TenderDatesInfo.ptd_assign_qs, TenderDatesInfo.ptd_receive_on, TenderDatesInfo.ptd_purpose,Department.Department,Committee.committee_short_name,FiscalYear.FiscalYear from TenderDatesInfo join PROJECTS on TenderDatesInfo.proj_id=" +
                    //        "PROJECTS.proj_id join STAGES on TenderDatesInfo.stage_id=STAGES.stage_id join TenderStatus on PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id join Department on PROJECTS.department_id = Department.department_id join Committee on PROJECTS.committee_id = Committee.committee_id join FiscalYear on PROJECTS.FYID = FiscalYear.FYID INNER JOIN TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id where " +
                    //        " TenderDatesInfo.ptd_qs_working_status is not NULL and TenderStatus.Tender_Status_id not in(8,9,10) and TenderDatesInfo.stage_id=1 and TenderDatesInfo.ptd_receive_on >= '" + dtEndReportDate.Value.ToString("dd/MMM/yyyy") + "' ORDER BY TenderDatesInfo.ptd_forwarded_to_dep DESC";
                    //    }
                    //}
                     
                //}

                DataTable dtJTDReports = dalObj.GetDataFromDB("PTDReports", sqlStaffReportsQuery);
                DataTable dtProjIds = dtJTDReports.DefaultView.ToTable(true, "proj_id"); //.Count
                int totProjCounts = dtJTDReports.DefaultView.ToTable(true, "proj_id").Rows.Count;
                int projCounter = 0;
                for (projCounter = 0; projCounter < totProjCounts; projCounter++)
                {

                    //DataRow[] row = dtJTDReports.Select("proj_id=" + dtProjIds.Rows[projCounter][0]);
//                    row[0][1]
                    foreach (DataRow drFilteredRecords in dtJTDReports.Select("proj_id=" + dtProjIds.Rows[projCounter][0]))
                    {
                        DataRow dr = dtFinal.NewRow();
                        dr[0] = rowCounter;
                        dr[1] = drFilteredRecords[1];
                        dr[2] = drFilteredRecords[2];
                        dr[3] = drFilteredRecords[3];
                        dr[4] = drFilteredRecords[4];
                        dr[5] = drFilteredRecords[5];
                        dr[6] = drFilteredRecords[6];
                        dr[7] = drFilteredRecords[7];
                        if (drFilteredRecords[8] != DBNull.Value)
                            dr[8] = Convert.ToDateTime(drFilteredRecords[8]).ToString("dd-MMM-yyyy");
                        else
                            dr[8] = "";
                        dr[9] = drFilteredRecords[9];
                        dr[10] = drFilteredRecords[10];
                        dr[11] = drFilteredRecords[11];
                        dr[12] = drFilteredRecords[12];

                        dtFinal.Rows.Add(dr);
                        dtFinal.AcceptChanges();
                        break;
                    }
                    rowCounter++;
                }


                StringBuilder strBuilder = new StringBuilder();
                if (dtFinal.Rows.Count == 0)
                    lblTotRecCount.Text = "Total Records Count=0";
                else
                    lblTotRecCount.Text = "Total Records Count=" + dtFinal.Rows.Count;

                strBuilder = CreateQSWorkingStatusReport(strBuilder, dtFinal);
                webReport.DocumentText = strBuilder.ToString();
                webReport.ScrollBarsEnabled = true;
            //}
            //else
            //{
            //    MessageBox.Show("Please select Assigned QS", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //    cmbAssignedQS.Focus();
            //}
        }

        static short startReportDateChanged = 0;
        private void dtStartReportDate_ValueChanged(object sender, EventArgs e)
        {
            startReportDateChanged = 1;
        }

        static short endReportDateChanged = 0;
        private void dtEndReportDate_ValueChanged(object sender, EventArgs e)
        {
            endReportDateChanged = 1;
        }
    }
}
