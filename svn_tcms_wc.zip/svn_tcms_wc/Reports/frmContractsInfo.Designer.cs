﻿namespace MDI_ParenrForm.Reports
{
    partial class frmContractsInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tenderPublishEndDate = new System.Windows.Forms.Label();
            this.dtpTenderPublishEndDate = new System.Windows.Forms.DateTimePicker();
            this.tenderPublishStartDate = new System.Windows.Forms.Label();
            this.dtpTenderPublishStartDate = new System.Windows.Forms.DateTimePicker();
            this.btnSubmitReport = new System.Windows.Forms.Button();
            this.btnExport = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbCommitteeNames = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.dtpEndReportDate = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.dtpStartReportDate = new System.Windows.Forms.DateTimePicker();
            this.webReport = new System.Windows.Forms.WebBrowser();
            this.button1 = new System.Windows.Forms.Button();
            this.btnExportToExcel = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbAffairs = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbCmpCategory = new System.Windows.Forms.ComboBox();
            this.cmbFiscalYear = new System.Windows.Forms.ComboBox();
            this.lblCurrentReportName = new System.Windows.Forms.Label();
            this.lblTotalNoOfRecords = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tenderPublishEndDate
            // 
            this.tenderPublishEndDate.AutoSize = true;
            this.tenderPublishEndDate.Location = new System.Drawing.Point(324, -151);
            this.tenderPublishEndDate.Name = "tenderPublishEndDate";
            this.tenderPublishEndDate.Size = new System.Drawing.Size(126, 13);
            this.tenderPublishEndDate.TabIndex = 58;
            this.tenderPublishEndDate.Text = "End Tender Publish Date";
            // 
            // dtpTenderPublishEndDate
            // 
            this.dtpTenderPublishEndDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTenderPublishEndDate.Location = new System.Drawing.Point(323, -135);
            this.dtpTenderPublishEndDate.Name = "dtpTenderPublishEndDate";
            this.dtpTenderPublishEndDate.Size = new System.Drawing.Size(20, 20);
            this.dtpTenderPublishEndDate.TabIndex = 57;
            // 
            // tenderPublishStartDate
            // 
            this.tenderPublishStartDate.AutoSize = true;
            this.tenderPublishStartDate.Location = new System.Drawing.Point(158, -151);
            this.tenderPublishStartDate.Name = "tenderPublishStartDate";
            this.tenderPublishStartDate.Size = new System.Drawing.Size(129, 13);
            this.tenderPublishStartDate.TabIndex = 56;
            this.tenderPublishStartDate.Text = "Start Tender Publish Date";
            // 
            // dtpTenderPublishStartDate
            // 
            this.dtpTenderPublishStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTenderPublishStartDate.Location = new System.Drawing.Point(157, -135);
            this.dtpTenderPublishStartDate.Name = "dtpTenderPublishStartDate";
            this.dtpTenderPublishStartDate.Size = new System.Drawing.Size(20, 20);
            this.dtpTenderPublishStartDate.TabIndex = 55;
            // 
            // btnSubmitReport
            // 
            this.btnSubmitReport.Location = new System.Drawing.Point(-175, -80);
            this.btnSubmitReport.Name = "btnSubmitReport";
            this.btnSubmitReport.Size = new System.Drawing.Size(20, 20);
            this.btnSubmitReport.TabIndex = 53;
            this.btnSubmitReport.Text = "Generate Report";
            this.btnSubmitReport.UseVisualStyleBackColor = true;
            // 
            // btnExport
            // 
            this.btnExport.BackColor = System.Drawing.Color.Coral;
            this.btnExport.Location = new System.Drawing.Point(-69, -80);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(20, 20);
            this.btnExport.TabIndex = 52;
            this.btnExport.Text = "Export To Excel";
            this.btnExport.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(-13, -152);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 51;
            this.label2.Text = "Fiscal Year";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(-266, -152);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 13);
            this.label1.TabIndex = 50;
            this.label1.Text = "Committee Names";
            // 
            // cmbCommitteeNames
            // 
            this.cmbCommitteeNames.FormattingEnabled = true;
            this.cmbCommitteeNames.Location = new System.Drawing.Point(-269, -136);
            this.cmbCommitteeNames.Name = "cmbCommitteeNames";
            this.cmbCommitteeNames.Size = new System.Drawing.Size(20, 21);
            this.cmbCommitteeNames.TabIndex = 48;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(423, 47);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 13);
            this.label3.TabIndex = 69;
            this.label3.Text = "End Report Date";
            // 
            // dtpEndReportDate
            // 
            this.dtpEndReportDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpEndReportDate.Location = new System.Drawing.Point(422, 63);
            this.dtpEndReportDate.Name = "dtpEndReportDate";
            this.dtpEndReportDate.Size = new System.Drawing.Size(90, 20);
            this.dtpEndReportDate.TabIndex = 68;
            this.dtpEndReportDate.ValueChanged += new System.EventHandler(this.dtpEndReportDate_ValueChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(312, 47);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 13);
            this.label4.TabIndex = 67;
            this.label4.Text = "Start Report Date";
            // 
            // dtpStartReportDate
            // 
            this.dtpStartReportDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpStartReportDate.Location = new System.Drawing.Point(311, 63);
            this.dtpStartReportDate.Name = "dtpStartReportDate";
            this.dtpStartReportDate.Size = new System.Drawing.Size(90, 20);
            this.dtpStartReportDate.TabIndex = 66;
            this.dtpStartReportDate.ValueChanged += new System.EventHandler(this.dtpStartReportDate_ValueChanged);
            // 
            // webReport
            // 
            this.webReport.Location = new System.Drawing.Point(20, 150);
            this.webReport.MinimumSize = new System.Drawing.Size(20, 20);
            this.webReport.Name = "webReport";
            this.webReport.Size = new System.Drawing.Size(1091, 438);
            this.webReport.TabIndex = 65;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(108, 106);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 23);
            this.button1.TabIndex = 64;
            this.button1.Text = "Generate Report";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnExportToExcel
            // 
            this.btnExportToExcel.BackColor = System.Drawing.Color.Coral;
            this.btnExportToExcel.Location = new System.Drawing.Point(214, 106);
            this.btnExportToExcel.Name = "btnExportToExcel";
            this.btnExportToExcel.Size = new System.Drawing.Size(103, 23);
            this.btnExportToExcel.TabIndex = 63;
            this.btnExportToExcel.Text = "Export To Excel";
            this.btnExportToExcel.UseVisualStyleBackColor = false;
            this.btnExportToExcel.Click += new System.EventHandler(this.btnExportToExcel_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(165, 46);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 13);
            this.label5.TabIndex = 62;
            this.label5.Text = "Fiscal Year";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 46);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 13);
            this.label6.TabIndex = 61;
            this.label6.Text = "Affairs";
            // 
            // cmbAffairs
            // 
            this.cmbAffairs.FormattingEnabled = true;
            this.cmbAffairs.Location = new System.Drawing.Point(14, 62);
            this.cmbAffairs.Name = "cmbAffairs";
            this.cmbAffairs.Size = new System.Drawing.Size(126, 21);
            this.cmbAffairs.TabIndex = 59;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(543, 46);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 13);
            this.label7.TabIndex = 71;
            this.label7.Text = "Category";
            // 
            // cmbCmpCategory
            // 
            this.cmbCmpCategory.FormattingEnabled = true;
            this.cmbCmpCategory.Location = new System.Drawing.Point(540, 62);
            this.cmbCmpCategory.Name = "cmbCmpCategory";
            this.cmbCmpCategory.Size = new System.Drawing.Size(121, 21);
            this.cmbCmpCategory.TabIndex = 70;
            // 
            // cmbFiscalYear
            // 
            this.cmbFiscalYear.FormattingEnabled = true;
            this.cmbFiscalYear.Location = new System.Drawing.Point(168, 63);
            this.cmbFiscalYear.Name = "cmbFiscalYear";
            this.cmbFiscalYear.Size = new System.Drawing.Size(121, 21);
            this.cmbFiscalYear.TabIndex = 72;
            this.cmbFiscalYear.SelectedIndexChanged += new System.EventHandler(this.cmbFiscalYear_SelectedIndexChanged);
            // 
            // lblCurrentReportName
            // 
            this.lblCurrentReportName.AutoSize = true;
            this.lblCurrentReportName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lblCurrentReportName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblCurrentReportName.Location = new System.Drawing.Point(359, 9);
            this.lblCurrentReportName.Name = "lblCurrentReportName";
            this.lblCurrentReportName.Size = new System.Drawing.Size(338, 17);
            this.lblCurrentReportName.TabIndex = 73;
            this.lblCurrentReportName.Text = "COMPANIES CONTRACTS INFORMATION REPORT";
            // 
            // lblTotalNoOfRecords
            // 
            this.lblTotalNoOfRecords.AutoSize = true;
            this.lblTotalNoOfRecords.Location = new System.Drawing.Point(20, 609);
            this.lblTotalNoOfRecords.Name = "lblTotalNoOfRecords";
            this.lblTotalNoOfRecords.Size = new System.Drawing.Size(0, 13);
            this.lblTotalNoOfRecords.TabIndex = 74;
            // 
            // frmContractsInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1125, 634);
            this.Controls.Add(this.lblTotalNoOfRecords);
            this.Controls.Add(this.lblCurrentReportName);
            this.Controls.Add(this.cmbFiscalYear);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cmbCmpCategory);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dtpEndReportDate);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dtpStartReportDate);
            this.Controls.Add(this.webReport);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnExportToExcel);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cmbAffairs);
            this.Controls.Add(this.tenderPublishEndDate);
            this.Controls.Add(this.dtpTenderPublishEndDate);
            this.Controls.Add(this.tenderPublishStartDate);
            this.Controls.Add(this.dtpTenderPublishStartDate);
            this.Controls.Add(this.btnSubmitReport);
            this.Controls.Add(this.btnExport);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbCommitteeNames);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmContractsInfo";
            this.Text = "Contracts Info";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label tenderPublishEndDate;
        private System.Windows.Forms.DateTimePicker dtpTenderPublishEndDate;
        private System.Windows.Forms.Label tenderPublishStartDate;
        private System.Windows.Forms.DateTimePicker dtpTenderPublishStartDate;
        private System.Windows.Forms.Button btnSubmitReport;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        
        private System.Windows.Forms.ComboBox cmbCommitteeNames;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dtpEndReportDate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dtpStartReportDate;
        private System.Windows.Forms.WebBrowser webReport;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnExportToExcel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbAffairs;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbCmpCategory;
        private System.Windows.Forms.ComboBox cmbFiscalYear;
        private System.Windows.Forms.Label lblCurrentReportName;
        private System.Windows.Forms.Label lblTotalNoOfRecords;
    }
}