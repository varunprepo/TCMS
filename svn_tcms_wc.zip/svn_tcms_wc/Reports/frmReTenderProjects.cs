﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TenderTrackingSystem;

namespace MDI_ParenrForm.Reports
{
    public partial class frmReTenderProjects : Form
    {
        private string strCon = ConfigurationManager.AppSettings["TCMSConnString"].ToString();
        CommonClass comCls = null;
        string whereClause = null;
        public frmReTenderProjects()
        {
            InitializeComponent();
            comCls = new CommonClass("");             
            getCalendarYears(cmbFiscalYear);
        }

        private void getCalendarYears(ComboBox cmb)
        {
            SqlConnection sqlConn = new SqlConnection(strCon);
            try
            {
                DataTable dtCalendarYear = null;
                sqlConn.Open();
                DAL dalObj = new DAL();
                string sqlQuery = "SELECT FYID,[FiscalYear] FROM [FiscalYear] WHERE fyid>=17 ORDER BY [FiscalYear] ASC";
                dtCalendarYear = dalObj.GetDataFromDB("CalendarYears", sqlQuery);
                DataRow row = dtCalendarYear.NewRow();
                row["FiscalYear"] = "All";
                row["FYID"] = 0;
                dtCalendarYear.Rows.Add(row);
                cmb.DataSource = dtCalendarYear;
                cmb.DisplayMember = "FiscalYear";
                cmb.ValueMember = "FYID";
                cmb.SelectedIndex = cmb.FindStringExact("All");
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }
        }

        int rowCounter = 0;         
        private void btnGenerateReport_Click(object sender, EventArgs e)
        {
            try
            {
                StringBuilder strBuildReTenderProj = new StringBuilder();

                int fyId = 0;
                rowCounter = 0;
                DAL dalObj = new DAL();
                //string sqlProjIdQuery = "";

                //DataTable dtProjectIds = new DataTable();
                
                fyId = Convert.ToInt32(cmbFiscalYear.SelectedValue);
                if (fyId != 0)
                {
                    whereClause = " and p.FYID=" + fyId;
                }
                else
                {
                    whereClause = "";
                }
                    //sqlProjIdQuery = "select distinct p.proj_id,FiscalYear.FiscalYear from PROJECTS p join FiscalYear on p.FYID=FiscalYear.FYID where p.FYID=" + fyId;
                    //dtProjectIds = dalObj.GetDataFromDB("ProjectIds", sqlProjIdQuery);
                
                //else if (commitYearSelection != 0 && startReportDateChanged == 0 && endReportDateChanged == 0)
                //{
                //    if (cmbCommitmentYear.SelectedValue.ToString() != "0")
                //    {
                //        //sqlProjIdQuery = "select distinct p.proj_id,FiscalYear.FiscalYear from PROJECTS p join FiscalYear on p.FYID=FiscalYear.FYID where p.FYID=" + cmbCommitmentYear.SelectedValue;
                //        //dtProjectIds = dalObj.GetDataFromDB("ProjectIds", sqlProjIdQuery);
                //        whereClause = " and p.FYID=" + cmbCommitmentYear.SelectedValue;
                //    }
                //    else
                //    {
                //        //sqlProjIdQuery = "select distinct p.proj_id,FiscalYear.FiscalYear from PROJECTS p join FiscalYear on p.FYID=FiscalYear.FYID";
                //        //dtProjectIds = dalObj.GetDataFromDB("ProjectIds", sqlProjIdQuery);
                //    }
                //}
                //else
                //{
                //    //sqlProjIdQuery = "select distinct p.proj_id,FiscalYear.FiscalYear from PROJECTS p join FiscalYear on p.FYID=FiscalYear.FYID ";
                //    //dtProjectIds = dalObj.GetDataFromDB("ProjectIds", sqlProjIdQuery);
                //}
                

                DataTable dtReTenderProj = null;

                strBuildReTenderProj.Append("<table style='border: solid 1px #506E87; width:100%'><tr>");

                //dtView = (DataRowView)cmbContractorNames.SelectedItem;
                if (fyId == 0) //|| commitYearSelection != 0
                {
                    strBuildReTenderProj.Append("<td colspan='6' style='text-align:center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;'><b>PWA - RE-TENDER PROJECTS</b></td></tr>");                    
                    
                    //strBuildContractorDetails.Append("<tr><td colspan='13' style='text-align: center;font-size: 12pt;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;' >Name of the Contractor/Vendor: <b>" + dtView.Row.ItemArray[1].ToString() + "</b></td></tr>");
                }
                else
                {
                    strBuildReTenderProj.Append("<td colspan='6' style='text-align:center;height: 35px;font-size: 12pt !important;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;'><b>PWA - RE-TENDER PROJECTS</b></td></tr>");
                    strBuildReTenderProj.Append("<tr><td colspan='6' style='text-align: center;font-size: 12pt;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;'><b>Fiscal Year: " + ((DataRowView)cmbFiscalYear.SelectedItem).Row.ItemArray[1].ToString() + "</b></td></tr>");                     
                    //strBuildContractorDetails.Append("<tr><td colspan='14' style='text-align: center;font-size: 12pt;text-decoration: underline;font-weight:bold; vertical-align:middle;border: solid 1px #4E4949;background-color: #C4D79B;' >Name of the Contractor: <b>" + dtView.Row.ItemArray[1].ToString() + "</b></td></tr>");
                }


                strBuildReTenderProj.Append("<tr><td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>SNo.</b></td>" +                
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Project Code</b></td>" +
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Tender No.</b></td>" +
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Project Title</b></td>" +
                "<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'><b>Closing Date</b></td>"
                );              

                strBuildReTenderProj.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;background-color: #FFCC99;'" +
                "><b>Department Name</b></td></tr>");

                string sqlReTenderQuery = null;

                //int coId = Convert.ToInt32(cmbContractorNames.SelectedValue);

                //foreach (DataRow projIds in dtProjectIds.Rows)
                //{

                 
                    //if (dtProjectIds.Rows.Count != 0)
                    //{
                if (fyId != 0) //|| commitYearSelection != 0
                {
                    sqlReTenderQuery = "SELECT distinct p.project_code,p.tender_no, Convert(varchar(max), p.project_name_en) As ProjectName,Coalesce(tdi.ts_modified_closing, tdi.ts_closing_s2, tdi.ts_closing_s1) As ClosingDate," +
                    "d2.Department FROM PROJECTS p join TenderDatesInfo tdi on p.proj_id = tdi.proj_id join Department2 d2 on d2.department_id=p.department_id where p.FYID=" + fyId + " and p.Tender_Status_id=9 order by ClosingDate desc"; //Tender_Status_id=9 ==Re-Tender
                }
                else
                {
                    sqlReTenderQuery = "SELECT distinct p.project_code,p.tender_no, Convert(varchar(max), p.project_name_en) As ProjectName,Coalesce(tdi.ts_modified_closing, tdi.ts_closing_s2, tdi.ts_closing_s1) As ClosingDate," +
                    "d2.Department FROM PROJECTS p join TenderDatesInfo tdi on p.proj_id = tdi.proj_id join Department2 d2 on d2.department_id=p.department_id where p.FYID>=17 and p.Tender_Status_id=9 order by ClosingDate desc"; //Tender_Status_id=9 ==Re-Tender
                }

                        
                    //AND " + (CONTRACTORS.proj_id in (" + string.Join(",", dtProjectIds.Rows.OfType<DataRow>().Select(r => r[0].ToString())) + ")) ";// +                             CONTRACTORS.co_id =" + coId + " and
                    //}
                    //else
                    //{
                    //sqlContractDetailsQuery = "SELECT DISTINCT CONTRACTORS.contract_no, p.project_code,p.tender_no, CONTRACTORS.ContractTitle, TenderDatesInfo.ts_tender_invitation, CONTRACTORS.cp_tender_award, CONTRACTORS.cp_contractor_sign, " +
                    //"CONTRACTORS.ContractAmount, CONTRACTORS.StartDate, CONTRACTORS.FinishDate, ContractStatus.ContractStatus,d2.Department FROM CONTRACTORS INNER JOIN " +
                    //"COMPANY ON COMPANY.co_id = CONTRACTORS.co_id left outer JOIN ContractStatus ON ContractStatus.contract_status_id = CONTRACTORS.contract_status_id INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id " +
                    //"INNER JOIN TenderDatesInfo ON CONTRACTORS.proj_id = TenderDatesInfo.proj_id inner join Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id WHERE (CONTRACTORS.co_id =" + coId + ")";// +                             

                    //}
                
                //else if (fiscalYearSelection == 0 && commitYearSelection == 1)
                //{                    

                //    //if (dtProjectIds.Rows.Count != 0)
                //    //{
                //        sqlContractDetailsQuery = "SELECT DISTINCT CONTRACTORS.contract_no, p.project_code,p.tender_no, CONTRACTORS.ContractTitle, TenderDatesInfo.ts_tender_invitation, CONTRACTORS.cp_tender_award, CONTRACTORS.cp_contractor_sign, " +
                //        "CONTRACTORS.ContractAmount, CONTRACTORS.StartDate, CONTRACTORS.FinishDate, ContractStatus.ContractStatus,d2.Department FROM CONTRACTORS INNER JOIN " +
                //        "COMPANY ON COMPANY.co_id = CONTRACTORS.co_id left outer JOIN ContractStatus ON ContractStatus.contract_status_id = CONTRACTORS.contract_status_id INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id " +
                //        "INNER JOIN TenderDatesInfo ON CONTRACTORS.proj_id = TenderDatesInfo.proj_id inner join Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id WHERE (CONTRACTORS.co_id =" + coId + " and TenderDatesInfo.ts_tender_issue is not Null and TenderDatesInfo.stage_id=2)" + whereClause;
                //        //AND " +"(CONTRACTORS.proj_id in (" + string.Join(",", dtProjectIds.Rows.OfType<DataRow>().Select(r => r[0].ToString())) + ")) ";
                //    //}
                //    //else
                //    //{
                //    //    sqlContractDetailsQuery = "SELECT DISTINCT CONTRACTORS.contract_no, p.project_code,p.tender_no, CONTRACTORS.ContractTitle, TenderDatesInfo.ts_tender_invitation, CONTRACTORS.cp_tender_award, CONTRACTORS.cp_contractor_sign, " +
                //    //    "CONTRACTORS.ContractAmount, CONTRACTORS.StartDate, CONTRACTORS.FinishDate, ContractStatus.ContractStatus,d2.Department FROM CONTRACTORS INNER JOIN " +
                //    //    "COMPANY ON COMPANY.co_id = CONTRACTORS.co_id left outer JOIN ContractStatus ON ContractStatus.contract_status_id = CONTRACTORS.contract_status_id INNER JOIN PROJECTS p ON CONTRACTORS.proj_id = p.proj_id " +
                //    //    "INNER JOIN TenderDatesInfo ON CONTRACTORS.proj_id = TenderDatesInfo.proj_id inner join Department2 as d1 on p.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id WHERE (CONTRACTORS.co_id =" + coId + ") ";
                //    //}                    
                //}

                //if (whereClause != null)
                //{
                //    if (whereClause != "")
                //    {
                //        sqlContractDetailsQuery = sqlContractDetailsQuery + " and" + whereClause;
                //    }                    
                //}

                dtReTenderProj = dalObj.GetDataFromDB("ReTenderProj", sqlReTenderQuery);

                //bool isRecAdded = false;
                ////int rowCounterForDuplicateRows = 0;
                int totalRecords = dtReTenderProj.Rows.Count;
                if (totalRecords != 0)
                {
                    FillData(dtReTenderProj, strBuildReTenderProj);

                    //DataView view = new DataView(dtContractorDetails);
                    //DataTable distinctRows = view.ToTable(true, "project_code");
                    //foreach (DataRow distinctRow in distinctRows.Rows)
                    //{
                    //    DataTable dtTmpContractDetails = dtContractorDetails.Select("project_code='" + distinctRow[0] + "'").CopyToDataTable();
                    //    isRecAdded = false;
                    //    foreach (DataRow rowData in dtTmpContractDetails.Rows)
                    //    {
                    //        DataRowCollection uniqueRow = null;
                    //        //if (dtContractorDetails.Rows.Count >= 2)
                    //        //{
                    //        if (!isRecAdded)
                    //        {
                    //            if (rowData.Table.Select("ts_tender_invitation is not Null").Count() != 0)
                    //            {
                    //                uniqueRow = rowData.Table.Select("ts_tender_invitation is not Null").CopyToDataTable().Rows;
                    //            }
                    //            else
                    //            {
                    //                uniqueRow = rowData.Table.Select("ts_tender_invitation is Null").CopyToDataTable().Rows;
                    //            }

                    //            FillData(dtContractorDetails, uniqueRow, strBuildContractorDetails, fiscalYearSelection);
                    //            isRecAdded = true;
                    //            rowCounter++;
                    //        }
                    //        //else if (dtContractorDetails.Rows.Count == 1)
                    //        //{
                    //        //    uniqueRowsData = dtContractorDetails.Rows;
                    //        //}

                    //        //if (chkDuplicateRows == 1)
                    //        //{
                    //        //    if (rowCounterForDuplicateRows == 0)
                    //        //    {
                    //        //        if (uniqueRowsData != null)
                    //        //        {
                    //        //            FillData(dtContractorDetails, uniqueRow, strBuildContractorDetails, fiscalYearSelection);
                    //        //        }
                    //        //    }
                    //        //}

                    //        //chkDuplicateRows = 0;
                    //        //rowCounterForDuplicateRows = 0;
                    //    }
                    //}

                  
                    strBuildReTenderProj.Append("</table>");
                    lblTotalNoOfRecords.Text = "Total Records Count=" + totalRecords;

                }
                else
                {
                    strBuildReTenderProj.Append("</table>");
                    lblTotalNoOfRecords.Text = "Total Records Count=0";
                    MessageBox.Show("No data exist for selected options", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                webReport.DocumentText = strBuildReTenderProj.ToString();
                webReport.ScrollBarsEnabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while retrieving the information of the contractor");
            }
        }

        private void FillData(DataTable dtContractorDetails, StringBuilder strBuildContractorDetails)
        {
          
            foreach (DataRow rowData in dtContractorDetails.Rows)
            {
                strBuildContractorDetails.Append("<tr><td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + ++rowCounter + "</td>");
                strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[0] + "</td>");
                if (rowData[1] != DBNull.Value)
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[1] + "</td>");
                else
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'></td>");                 
                strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[2] + "</td>");               
                if (rowData[3] != DBNull.Value)
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[3] + "</td>");
                else
                    strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'></td>");
                strBuildContractorDetails.Append("<td style='font-family: Verdana;font-size: 9pt;font-weight: normal;vertical-align: top;border: solid 1px #4E4949;text-align: center;padding-left: 5px;padding-top: 6px;'>" + rowData[4] + "</td>");                                   
                strBuildContractorDetails.Append("</tr>");                
            }

        }

        private void btnExportToExcel_Click(object sender, EventArgs e)
        {
            comCls.ExportToExcel(webReport);
        }
    }
}
