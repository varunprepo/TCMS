﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

using DataGridViewAutoFilter;
using MDI_ParenrForm.Contacts;
using TenderTrackingSystem;
using WindowsFormsApplication1;
using MDI_ParenrForm.Admin;
using MDI_ParenrForm.Projects;
using MDI_ParenrForm.Reports;
using MDI_ParenrForm; 

namespace MDI_ParenrForm
{
    public partial class TMS_MainView : Form
    {
        IList<string> userRightsColl = new List<string>();

        private string connStr = ConfigurationManager.AppSettings["TCMSConnString"].ToString();
        SqlConnection cn = new SqlConnection();
        string _userName = string.Empty;
        bool _isHeadOfSection = false; // Added by Varun on 11/Jun/15
        string _btnName = string.Empty;
        string profile_Name = string.Empty;
        string whereClause = null;
        CommonClass comCls = null;      


        public TMS_MainView(string userName, bool isHeadOfSection)
        {
            InitializeComponent();
            _userName = userName;
            _isHeadOfSection = isHeadOfSection;
            userRightsColl = getUserAccessList();
            comCls = new CommonClass(userName);
            if (userRightsColl.Contains("104"))
            {
                whereClause = comCls.CheckAccessRightsForTenderNoYear(userRightsColl) + " AND p.proj_id not IN (SELECT PROJECTS.proj_id FROM TenderStatus RIGHT OUTER JOIN STAGES INNER JOIN TenderTypes INNER JOIN " +
                " ContractTypes INNER JOIN  FiscalYear INNER JOIN  Committee RIGHT OUTER JOIN   AFFAIRS INNER JOIN PROJECTS ON AFFAIRS.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON FiscalYear.FYID = PROJECTS.FYID ON " +
                " ContractTypes.contract_type_id = PROJECTS.contract_type_id ON TenderTypes.tender_type_id = PROJECTS.tender_type_id INNER JOIN  Department ON PROJECTS.department_id = Department.department_id ON STAGES.stage_id = PROJECTS.stage_id ON " +
                " TenderStatus.Tender_Status_id = PROJECTS.Tender_Status_id INNER JOIN  TenderDatesInfo ON TenderDatesInfo.proj_id = PROJECTS.proj_id WHERE (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.ts_tender_issue IS NULL) AND (ISNULL(TenderDatesInfo.ts_modified_closing, TenderDatesInfo.ts_closing_s1) >= CONVERT(DATETIME, '" + DateTime.Now.Date.ToString() + "', 102)) " +
                "AND (PROJECTS.isDeleted=0 ) AND PROJECTS.Tender_Status_id<>10)";
            }
            else
            {
                whereClause = comCls.CheckAccessRightsForTenderNoYear(userRightsColl);
            }

            lblUserName.Text = userName;
            FillButtonsInfo();
            //showFormContent();
            if (profile_Name.Equals("EBSD Staff"))
            {
                lblMozanahID.Visible = true;
                cmbMozanahID.Visible = true;

                lblContractNo.Visible = true;
                cmbContractNo.Visible = true;
            }             
        }
        public TMS_MainView(string userName, Button btnName, bool isHeadOfSection)
        {
            InitializeComponent();
            _userName = userName;
            _isHeadOfSection = isHeadOfSection;
            userRightsColl = getUserAccessList();
            comCls = new CommonClass(userName);
            if (userRightsColl.Contains("104"))
            {
                whereClause = comCls.CheckAccessRightsForTenderNoYear(userRightsColl) + " AND p.proj_id not IN (SELECT PROJECTS.proj_id FROM TenderStatus RIGHT OUTER JOIN STAGES INNER JOIN TenderTypes INNER JOIN " +
                " ContractTypes INNER JOIN  FiscalYear INNER JOIN  Committee RIGHT OUTER JOIN   AFFAIRS INNER JOIN PROJECTS ON AFFAIRS.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON FiscalYear.FYID = PROJECTS.FYID ON " +
                " ContractTypes.contract_type_id = PROJECTS.contract_type_id ON TenderTypes.tender_type_id = PROJECTS.tender_type_id INNER JOIN  Department ON PROJECTS.department_id = Department.department_id ON STAGES.stage_id = PROJECTS.stage_id ON " +
                " TenderStatus.Tender_Status_id = PROJECTS.Tender_Status_id INNER JOIN  TenderDatesInfo ON TenderDatesInfo.proj_id = PROJECTS.proj_id WHERE (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.ts_tender_issue IS NULL) AND (ISNULL(TenderDatesInfo.ts_modified_closing, TenderDatesInfo.ts_closing_s1) >= CONVERT(DATETIME, '" + DateTime.Now.Date.ToString() + "', 102)) " +
                "AND (PROJECTS.isDeleted=0 ) and PROJECTS.Tender_Status_id<>10)";
            }
            else
            {
                whereClause = comCls.CheckAccessRightsForTenderNoYear(userRightsColl);
            }
            lblUserName.Text = userName;
            _btnName = btnName.Text.ToString();
            FillButtonsInfo();             
            if (profile_Name.Equals("EBSD Staff"))
            {
                lblMozanahID.Visible = true;
                cmbMozanahID.Visible = true;

                lblContractNo.Visible = true;
                cmbContractNo.Visible = true;
            }             
        }
        private IList<string> getUserAccessList()
        {
            userRightsColl.Clear();
            SqlConnection sqlConn = new SqlConnection(connStr);

            string sqlQuery = "SELECT  UserAccessRights.AccessID,UserAccessRights.[AccessRights], UserPrivelege.HasPrivelege, UserPrivelege.user_profile_id, UserSecurityProfile.profile_name, USERS.user_id, " +
            " USERS.user_name FROM UserAccessRights INNER JOIN UserPrivelege ON UserAccessRights.AccessID = UserPrivelege.AccessID INNER JOIN " +
            " UserSecurityProfile ON UserPrivelege.user_profile_id = UserSecurityProfile.user_profile_id INNER JOIN " +
            " USERS ON UserSecurityProfile.user_profile_id = USERS.user_profile_id WHERE (UserPrivelege.HasPrivelege = 0) AND (USERS.user_name = '" + _userName + "') ORDER BY UserAccessRights.AccessID";

            try
            {
                sqlConn.Open();
                SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
                SqlDataReader sqlReader = sqlCom.ExecuteReader();
                while (sqlReader.Read())
                {
                    userRightsColl.Add(sqlReader[0].ToString());

                    if (profile_Name == "")
                        profile_Name = sqlReader[4].ToString();
                }
                sqlReader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error getting while reading data !" + ex.Message);
            }
            finally
            {
                sqlConn.Close();
            }
            return userRightsColl;
        }
        private void ShowNewForm(object sender, EventArgs e)
        {
            //Form childForm = new Form();
            //childForm.MdiParent = this;
            //childForm.Text = "Window " + childFormNumber++;
            //childForm.Show();
        }
        private void OpenFile(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = openFileDialog.FileName;
            }
        }
        private void SaveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            saveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = saveFileDialog.FileName;
            }
        }
        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void CascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }
        private void TileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }
        private void TileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }
        private void ArrangeIconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.ArrangeIcons);
        }
        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }
        private void nameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmContactsDefault frmDef_Contacts = new frmContactsDefault(userRightsColl, _userName);
            frmDef_Contacts.StartPosition = FormStartPosition.CenterScreen;
            frmDef_Contacts.ShowDialog();
        }
        private void companyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Contacts.frmCompanyContacts frmDef_Contacts = new frmCompanyContacts(userRightsColl, _userName);
            frmDef_Contacts.StartPosition = FormStartPosition.CenterScreen;
            frmDef_Contacts.ShowDialog();
        }
        private void commitedProjectsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Projects.frmOngoingContracts OnGoingProjects = new MDI_ParenrForm.Projects.frmOngoingContracts(userRightsColl, _userName,_isHeadOfSection,null);
            OnGoingProjects.StartPosition = FormStartPosition.CenterParent;
            OnGoingProjects.ShowDialog();
        }
        private void projectsOnTenderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DefaultView frmDefault = new DefaultView(userRightsColl, "Admin",_isHeadOfSection,null);
            ScaleDown(frmDefault);
            frmDefault.StartPosition = FormStartPosition.CenterScreen;
            frmDefault.Show();            
        }
        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            WindowsFormsApplication1.Form1 frmDefault = new WindowsFormsApplication1.Form1(userRightsColl, _userName);
            frmDefault.StartPosition = FormStartPosition.CenterScreen;
            frmDefault.Show();
        }
                 
        string mCommitteeShortName = string.Empty;
        string mAffairShortName = "";
         
        
        private void MDIParent1_Load(object sender, EventArgs e)
        {
            // Added by Varun on 10 Feb 2014 
            userRightsColl.Clear();
            comCls = new CommonClass(_userName);
            userRightsColl = getUserAccessList();
            lblProfileName.Text = profile_Name;

            if (profile_Name.Equals("EBSD Staff"))
            {
                lblMozanahID.Visible = true;
                cmbMozanahID.Visible = true;

                lblContractNo.Visible = true;
                cmbContractNo.Visible = true;
            }
            // Code to make taskbar enable at Top on Screen 

            
            this.WindowState = FormWindowState.Maximized;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable;            
            if (userRightsColl.Contains("34"))   //Staff Filter Access Rights
            {
                lblStaff.Visible = false;
                lblQS.Visible = false;
                lblTndr.Visible = false;
                lblCp.Visible = false;
                cmbQs.Visible = false;
                cmbTndrHndl.Visible = false;
                cmbStaff.Visible = false;
            }
            else
            {
                lblStaff.Visible = true;
                lblQS.Visible = true;
                lblTndr.Visible = true;
                lblCp.Visible = true;
                cmbQs.Visible = true;
                cmbTndrHndl.Visible = true;
                cmbStaff.Visible = true;
            }

            if (_btnName.Trim().Equals("All Projects"))
            {
                mCommitteeShortName = comCls.checkAccessRightsForCommittee(userRightsColl, mCommitteeShortName);
                mAffairShortName = comCls.checkAccessRightsForAffairs(userRightsColl, mAffairShortName);
                if (mAffairShortName == "")
                {
                    MessageBox.Show("You do not have privilege for accessing any affairs, Contact administrator");
                    return;
                }
                //userRightsColl = getUserAccessList();
                splitContainer1.Panel2.Controls.Clear();
                btnProjects.BackColor = Color.Gray;
                btnProjects.ForeColor = Color.Black;                

                btnDashboard.BackColor = Color.LightSlateGray;      //LightGray
                btnDocuments.BackColor = Color.LightSlateGray;
                btnContacts.BackColor = Color.LightSlateGray;
                btnReports.BackColor = Color.LightSlateGray;
                btnAdmin.BackColor = Color.LightSlateGray;

                CreateDynamicButtons(AllProjects, btnProjects.Text);

                if (userRightsColl.Contains("11"))
                {
                    spliterForProjects.Visible = false;                    
                }
                else
                {
                    if (spliterForProjects.Visible == false)
                    {
                        spliterForProjects.Visible = true;
                    }
                   
                    FillAllProjectsInformation_CommitteWise(' ');
                    FillCombo();
                }                
            }
            if (_btnName.Equals("Documents"))
            {
                if (userRightsColl.Contains("18"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }

                spliterForProjects.Visible = false;

                splitContainer1.Panel2.Controls.Clear();
                btnDocuments.BackColor = Color.Gray;
                btnDocuments.ForeColor = Color.Black;

                btnDashboard.BackColor = Color.LightSlateGray;      //LightGray
                btnProjects.BackColor = Color.LightSlateGray;
                btnContacts.BackColor = Color.LightSlateGray;
                btnReports.BackColor = Color.LightSlateGray;
                btnAdmin.BackColor = Color.LightSlateGray;

                CreateDynamicButtons(Documents, btnDocuments.Text);

                if (userRightsColl.Contains("18"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }
                else
                {
                    Documents.frmCommunications frmComm = new Documents.frmCommunications(userRightsColl, _userName);
                    frmComm.StartPosition = FormStartPosition.CenterScreen;
                    frmComm.ShowDialog();
                }
            }
            if (_btnName.Equals("Contacts"))
            {
                if (userRightsColl.Contains("24"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }
                spliterForProjects.Visible = false;

                splitContainer1.Panel2.Controls.Clear();
                btnContacts.BackColor = Color.Gray;
                btnContacts.ForeColor = Color.Black;           

                btnDashboard.BackColor = Color.LightSlateGray;      //LightGray
                btnProjects.BackColor = Color.LightSlateGray;
                btnDocuments.BackColor = Color.LightSlateGray;
                btnReports.BackColor = Color.LightSlateGray;
                btnAdmin.BackColor = Color.LightSlateGray;

                CreateDynamicButtons(Contacts, btnContacts.Text);

                Contacts.frmCompanyContacts frmDef_Contacts = new frmCompanyContacts(userRightsColl, _userName);
                frmDef_Contacts.StartPosition = FormStartPosition.CenterScreen;
                frmDef_Contacts.ShowDialog();
            }
            if (_btnName.Equals("Admin"))
            {
                if (userRightsColl.Contains("34"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }

                spliterForProjects.Visible = false;
                splitContainer1.Panel2.Controls.Clear();

                btnAdmin.BackColor = Color.Gray;
                btnAdmin.ForeColor = Color.Black;                

                btnDashboard.BackColor = Color.LightSlateGray;      //LightGray
                btnProjects.BackColor = Color.LightSlateGray;
                btnDocuments.BackColor = Color.LightSlateGray;
                btnContacts.BackColor = Color.LightSlateGray;
                btnReports.BackColor = Color.LightSlateGray;

                CreateDynamicButtons(Admin, btnAdmin.Text);

                if (userRightsColl.Contains("34"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }
                else
                {
                    Admin.frmUsers frmUserInfo = new Admin.frmUsers(userRightsColl, _userName);
                    frmUserInfo.StartPosition = FormStartPosition.CenterParent;
                    frmUserInfo.ShowDialog();
                }
            }
            if (_btnName.Equals("Reports"))
            {
                if (userRightsColl.Contains("28"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }

                mCommitteeShortName = comCls.checkAccessRightsForCommittee(userRightsColl, mCommitteeShortName);
                mAffairShortName = comCls.checkAccessRightsForAffairs(userRightsColl, mAffairShortName);

                if (mAffairShortName == "")
                {
                    MessageBox.Show("You do not have privilege for accessing any affairs, Contact administrator");
                    return;
                }

                spliterForProjects.Visible = false;
                splitContainer1.Panel2.Controls.Clear();

                btnReports.BackColor = Color.Gray;
                btnReports.ForeColor = Color.Black;
                 
                btnDashboard.BackColor = Color.LightSlateGray;      //LightGray
                btnProjects.BackColor = Color.LightSlateGray;
                btnDocuments.BackColor = Color.LightSlateGray;
                btnContacts.BackColor = Color.LightSlateGray;
                btnAdmin.BackColor = Color.LightSlateGray;

                CreateDynamicButtons(Reports, btnReports.Text);

                if (userRightsColl.Contains("28"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }
                else
                {                   

                    frmReports frmReports = new frmReports(userRightsColl,mAffairShortName,mCommitteeShortName);
                    frmReports.StartPosition = FormStartPosition.CenterParent;
                    frmReports.ShowDialog();
                }
            }
        }
        private void committedProjectsClosedOthersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Projects.frmInactiveProjects contractorInfo = new MDI_ParenrForm.Projects.frmInactiveProjects(userRightsColl, _userName,_isHeadOfSection);
            contractorInfo.StartPosition = FormStartPosition.CenterParent;
            contractorInfo.ShowDialog();
        }
        private void communicationsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Documents.frmCommunications docCommunications = new MDI_ParenrForm.Documents.frmCommunications(userRightsColl, _userName);
            docCommunications.StartPosition = FormStartPosition.CenterParent;
            docCommunications.ShowDialog();
        }
        private void usersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Admin.frmUsers usersList = new MDI_ParenrForm.Admin.frmUsers(userRightsColl, _userName);
            usersList.StartPosition = FormStartPosition.CenterParent;
            usersList.ShowDialog();
        }
        public static void ScaleDown(System.Windows.Forms.Form frm)
        {
            int scrWidth = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width;
            int scrHeight = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height;
            if (scrWidth < frm.Width)
            {
                foreach (System.Windows.Forms.Control cntrl in frm.Controls)
                {
                    cntrl.Width = ((cntrl.Width) * (scrWidth)) / (frm.Width);
                    cntrl.Left = ((cntrl.Left) * (scrWidth)) / (frm.Width);
                }
            }
            if (scrHeight < frm.Height)
            {
                foreach (System.Windows.Forms.Control cntrl in frm.Controls)
                {
                    cntrl.Height = ((cntrl.Height) * (scrHeight)) / (frm.Height);
                    cntrl.Top = ((cntrl.Top) * (scrHeight)) / (frm.Height);
                }
            }
        }
        List<string> AllProjects = new List<string>();
        List<string> Admin = new List<string>();
        List<string> Documents = new List<string>();
        List<string> Reports = new List<string>();
        List<string> Contacts = new List<string>();
        Button btn;

        private void FillButtonsInfo()
        {
            AllProjects.Add("PWA Projects");
            AllProjects.Add("Ongoing Contracts");
            AllProjects.Add("Inactive Contracts");
            AllProjects.Add("Archives");
            AllProjects.Add("Current Day Closing Tenders");
            AllProjects.Add("One Month Back Closing Tenders");
            AllProjects.Add("Running Tenders");
            AllProjects.Add("Deleted Projects");

            Contacts.Add("Company");
            Contacts.Add("Contacts");

            Documents.Add("Communication");
            Documents.Add("Word Document");
            Documents.Add("Forms");

            Admin.Add("Users");
            Admin.Add("Security Profiles");
            Admin.Add("Security Codes");
            Admin.Add("Email Alerts");

            Reports.Add("Tender Reports");
            Reports.Add("Statistic");

        }
        private void CreateDynamicButtons(List<string> moduleData, string btnName)
        {
            int j = 0;
            for (int i = 0; i <= moduleData.Count - 1; i++)
            {
                if (btnName == "Contacts")
                {
                    j = j + 145;
                    btn = new Button();
                    btn.Location = new Point(295 + j, 1);         //478,9
                    btn.Size = new Size(148, 46);
                    btn.Text = moduleData[i];
                    btn.Font = new Font(btn.Font, FontStyle.Bold);

                    btn.FlatStyle = FlatStyle.Flat;
                    btn.FlatAppearance.BorderColor = Color.Maroon;
                    btn.FlatAppearance.MouseOverBackColor = Color.Maroon;                    
                    btn.ForeColor = Color.DarkGray;

                    btn.Click += new EventHandler(btn_Click);
                    splitContainer1.Panel2.Controls.Add(btn);
                }
                else if (btnName == "Reports")
                {
                    j = j + 145;
                    btn = new Button();
                    btn.Location = new Point(444 + j, 1);         //478,9
                    btn.Size = new Size(148, 46);
                    btn.Text = moduleData[i];
                    btn.Font = new Font(btn.Font, FontStyle.Bold);

                    btn.FlatStyle = FlatStyle.Flat;
                    btn.FlatAppearance.BorderColor = Color.Maroon;
                    btn.FlatAppearance.MouseOverBackColor = Color.Maroon;
                     
                    btn.ForeColor = Color.DarkGray;

                    btn.Click += new EventHandler(btn_Click);
                    splitContainer1.Panel2.Controls.Add(btn);
                }
                else if (btnName == "Admin")
                {

                    j = j + 147;
                    btn = new Button();
                    btn.Location = new Point(444 + j, 1);         //478,9
                    btn.Size = new Size(148, 46);
                    btn.Text = moduleData[i];
                    btn.Font = new Font(btn.Font, FontStyle.Bold);

                    btn.FlatStyle = FlatStyle.Flat;
                    btn.FlatAppearance.BorderColor = Color.Maroon;
                    btn.FlatAppearance.MouseOverBackColor = Color.Maroon;                     
                    btn.ForeColor = Color.DarkGray;

                    btn.Click += new EventHandler(btn_Click);
                    splitContainer1.Panel2.Controls.Add(btn);
                }
                else
                {
                    j = j + 145;
                    btn = new Button();
                    btn.Location = new Point(1 + j, 1);         //478,9
                    btn.Size = new Size(148, 46);
                    btn.Text = moduleData[i];
                    btn.Font = new Font(btn.Font, FontStyle.Bold);

                    btn.FlatStyle = FlatStyle.Flat;
                    btn.FlatAppearance.BorderColor = Color.Maroon;
                    btn.FlatAppearance.MouseOverBackColor = Color.Maroon;     //SaddleBrown                     
                    btn.ForeColor = Color.DarkGray;

                    btn.Click += new EventHandler(btn_Click);
                    splitContainer1.Panel2.Controls.Add(btn);
                }
            }
        }
        private void btn_Click(object sender, EventArgs e)
        {
            Button btnDummy = sender as Button;             
            btnDummy.ForeColor = Color.WhiteSmoke;

            foreach (Control item in splitContainer1.Panel2.Controls)
            {
                Button chkBtn = item as Button;
                if (chkBtn.Text.Trim() != btnDummy.Text.Trim())
                {
                    chkBtn.ForeColor = Color.DarkGray;
                    chkBtn.BackColor = Color.Maroon;
                }
            }
            if (btnDummy.Text == "PWA Projects")
            {
                if (userRightsColl.Contains("11"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }
                spliterForProjects.Visible = true;                 
            }
            if (btnDummy.Text == "Ongoing Contracts")
            {
                if (userRightsColl.Contains("13"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }
                spliterForProjects.Visible = false;

                Projects.frmOngoingContracts OnGoingProjects = new MDI_ParenrForm.Projects.frmOngoingContracts(userRightsColl, _userName,_isHeadOfSection,null);
                OnGoingProjects.StartPosition = FormStartPosition.CenterParent;
                OnGoingProjects.ShowDialog();
            }
            if (btnDummy.Text == "Inactive Contracts")
            {
                if (userRightsColl.Contains("14"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }

                spliterForProjects.Visible = false;

                Projects.frmInactiveProjects contractorInfo = new MDI_ParenrForm.Projects.frmInactiveProjects(userRightsColl, _userName,_isHeadOfSection);
                contractorInfo.StartPosition = FormStartPosition.CenterParent;
                contractorInfo.ShowDialog();
            }
            if (btnDummy.Text == "Archives")
            {
                if (userRightsColl.Contains("15"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }

                spliterForProjects.Visible = false;

                DefaultView frmrcheives = new DefaultView(userRightsColl, _userName, _isHeadOfSection, "Archives");
                frmrcheives.StartPosition = FormStartPosition.CenterParent;
                frmrcheives.ShowDialog();
            }

            if (btnDummy.Text == "Current Day Closing Tenders")
            {
                if (userRightsColl.Contains("71"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }

                spliterForProjects.Visible = false;

                DefaultView frmrcheives = new DefaultView(userRightsColl, _userName, _isHeadOfSection, "Current Day Closing Tenders");
                frmrcheives.StartPosition = FormStartPosition.CenterParent;
                frmrcheives.ShowDialog();
            }
            if (btnDummy.Text == "One Month Back Closing Tenders")
            {
                if (userRightsColl.Contains("71"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }

                spliterForProjects.Visible = false;

                DefaultView frmrcheives = new DefaultView(userRightsColl, _userName, _isHeadOfSection, "One Month Back Closing Tenders");
                frmrcheives.StartPosition = FormStartPosition.CenterParent;
                frmrcheives.ShowDialog();
            }
            if (btnDummy.Text == "Running Tenders")
            {
                if (userRightsColl.Contains("72"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }

                spliterForProjects.Visible = false;

                DefaultView frmrcheives = new DefaultView(userRightsColl, _userName, _isHeadOfSection, "Running Tenders");
                frmrcheives.StartPosition = FormStartPosition.CenterParent;
                frmrcheives.ShowDialog();
            }
            if (btnDummy.Text == "Deleted Projects")
            {
                if (userRightsColl.Contains("105"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }

                spliterForProjects.Visible = false;

                DefaultView frmrcheives = new DefaultView(userRightsColl, _userName, _isHeadOfSection, "Deleted Projects");
                frmrcheives.StartPosition = FormStartPosition.CenterParent;
                frmrcheives.ShowDialog();
            }            
            
            if (btnDummy.Text == "Company")
            {
                if (userRightsColl.Contains("24"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }
                Contacts.frmCompanyContacts frmDef_Contacts = new frmCompanyContacts(userRightsColl, _userName);
                frmDef_Contacts.StartPosition = FormStartPosition.CenterScreen;
                frmDef_Contacts.ShowDialog();
            }
            if (btnDummy.Text == "Contacts")
            {
                if (userRightsColl.Contains("24"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }
                frmContactsDefault frmDef_Contacts = new frmContactsDefault(userRightsColl, _userName);
                frmDef_Contacts.StartPosition = FormStartPosition.CenterScreen;
                frmDef_Contacts.ShowDialog();
            }
            if (btnDummy.Text == "Communication")
            {
                if (userRightsColl.Contains("18"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }

                Documents.frmCommunications frmComm = new Documents.frmCommunications(userRightsColl, _userName);
                frmComm.StartPosition = FormStartPosition.CenterScreen;
                frmComm.ShowDialog();
            }
            if (btnDummy.Text == "Users")
            {
                if (userRightsColl.Contains("34"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }

                Admin.frmUsers frmUserInfo = new Admin.frmUsers(userRightsColl, _userName);
                frmUserInfo.StartPosition = FormStartPosition.CenterParent;
                frmUserInfo.ShowDialog();
            }
            if (btnDummy.Text == "Security Profiles")
            {
                if (userRightsColl.Contains("34"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }

                MDI_ParenrForm.Admin.frmSecurityProfile1 frmSecurityProfile = new MDI_ParenrForm.Admin.frmSecurityProfile1(userRightsColl);
                frmSecurityProfile.StartPosition = FormStartPosition.CenterParent;
                frmSecurityProfile.ShowDialog();
            }
            if (btnDummy.Text == "Security Codes")
            {
                if (userRightsColl.Contains("34"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }

                frmAdminCodes frmSecCodes = new frmAdminCodes();
                frmSecCodes.StartPosition = FormStartPosition.CenterScreen;
                frmSecCodes.ShowDialog();
            }
            if (btnDummy.Text == "Email Alerts")
            {
                if (userRightsColl.Contains("34"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }

                frmEmailAlerts frmEmailAlerts = new frmEmailAlerts();
                frmEmailAlerts.StartPosition = FormStartPosition.CenterScreen;
                frmEmailAlerts.ShowDialog();
            }
        }
        private void btnDashboard_Click(object sender, EventArgs e)
        {
            this.Hide();
            spliterForProjects.Visible = false;
            dashBoardParent dashBoard = new dashBoardParent("",_isHeadOfSection);
            dashBoard.StartPosition = FormStartPosition.CenterScreen;
            dashBoard.Show();

        }

        public void showFormContent()
        {
            splitContainer1.Panel2.Controls.Clear();
            //Added by Varun on 10 Feb 2014 for clearing the user rights collection and the repopulating it to get the latest access rights
            userRightsColl.Clear();
            userRightsColl = getUserAccessList();
            btnProjects.BackColor = Color.Gray;
            btnProjects.ForeColor = Color.Black;            

            btnDashboard.BackColor = Color.LightSlateGray;      //LightGray
            btnDocuments.BackColor = Color.LightSlateGray;
            btnContacts.BackColor = Color.LightSlateGray;
            btnReports.BackColor = Color.LightSlateGray;
            btnAdmin.BackColor = Color.LightSlateGray;

            string filterQuery = string.Empty;
            CreateDynamicButtons(AllProjects, btnProjects.Text);  
            
            if (userRightsColl.Contains("11"))
            {
                spliterForProjects.Visible = false;                 
            }
            else
            {
                if (spliterForProjects.Visible == false)
                {
                    spliterForProjects.Visible = true;
                }
                
                FillAllProjectsInformation('R');                
                FillCombo();

                // Added by Varun on 10 Feb 2014
                mCommitteeShortName = comCls.checkAccessRightsForCommittee(userRightsColl, mCommitteeShortName);
                mAffairShortName = comCls.checkAccessRightsForAffairs(userRightsColl, mAffairShortName);
                if (mAffairShortName == "")
                {
                    MessageBox.Show("You do not have privilege for accessing any affairs, Contact administrator");
                    return;
                }
            }
        }
        private void btnProjects_Click(object sender, EventArgs e) //1
        {
            showFormContent();           
        }
        private void btnContacts_Click(object sender, EventArgs e)
        {
            if (userRightsColl.Contains("24"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            spliterForProjects.Visible = false;

            splitContainer1.Panel2.Controls.Clear();
            btnContacts.BackColor = Color.Gray;
            btnContacts.ForeColor = Color.Black;            

            btnDashboard.BackColor = Color.LightSlateGray;      //LightGray
            btnProjects.BackColor = Color.LightSlateGray;
            btnDocuments.BackColor = Color.LightSlateGray;
            btnReports.BackColor = Color.LightSlateGray;
            btnAdmin.BackColor = Color.LightSlateGray;

            CreateDynamicButtons(Contacts, btnContacts.Text);

            Contacts.frmCompanyContacts frmDef_Contacts = new frmCompanyContacts(userRightsColl, _userName);
            frmDef_Contacts.StartPosition = FormStartPosition.CenterScreen;
            frmDef_Contacts.ShowDialog();
        }

        private void btnAdmin_Click(object sender, EventArgs e)
        {            

            spliterForProjects.Visible = false;

            splitContainer1.Panel2.Controls.Clear();

            btnAdmin.BackColor = Color.Gray;
            btnAdmin.ForeColor = Color.Black;            
            btnDashboard.BackColor = Color.LightSlateGray;      //LightGray
            btnProjects.BackColor = Color.LightSlateGray;
            btnDocuments.BackColor = Color.LightSlateGray;
            btnContacts.BackColor = Color.LightSlateGray;
            btnReports.BackColor = Color.LightSlateGray;

            CreateDynamicButtons(Admin, btnAdmin.Text);

            if (userRightsColl.Contains("34"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }
            else
            {
                Admin.frmUsers frmUserInfo = new Admin.frmUsers(userRightsColl, _userName);
                frmUserInfo.StartPosition = FormStartPosition.CenterParent;
                frmUserInfo.ShowDialog();
            }

        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private void linkLabel10_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (userRightsColl.Contains("3"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            foreach (Control aControl in this.Controls)
            {
                if (aControl is Panel)
                {
                    if (aControl.Name.Equals("panelForDashboard"))
                    {
                        aControl.Visible = false;
                    }
                }
            }

            TenderTrackingSystem.DefaultView frmPrjView = new TenderTrackingSystem.DefaultView(userRightsColl, "Admin",_isHeadOfSection,null);
            frmPrjView.StartPosition = FormStartPosition.CenterParent;
            frmPrjView.ShowDialog();
        }
        private void btnDocuments_Click(object sender, EventArgs e)
        {            
            if (userRightsColl.Contains("18"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            spliterForProjects.Visible = false;

            splitContainer1.Panel2.Controls.Clear();

            btnDocuments.BackColor = Color.Gray;
            btnDocuments.ForeColor = Color.Black;            

            btnDashboard.BackColor = Color.LightSlateGray;      //LightGray
            btnProjects.BackColor = Color.LightSlateGray;
            btnContacts.BackColor = Color.LightSlateGray;
            btnReports.BackColor = Color.LightSlateGray;
            btnAdmin.BackColor = Color.LightSlateGray;

            CreateDynamicButtons(Documents, btnDocuments.Text);             

            if (userRightsColl.Contains("18"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }
            else
            {
                Documents.frmCommunications frmComm = new Documents.frmCommunications(userRightsColl, _userName);
                frmComm.StartPosition = FormStartPosition.CenterScreen;
                frmComm.ShowDialog();
            }
        }
        private void btnReports_Click(object sender, EventArgs e)
        {           

            spliterForProjects.Visible = false;

            splitContainer1.Panel2.Controls.Clear();

            btnReports.BackColor = Color.Gray;
            btnReports.ForeColor = Color.Black;          

            btnDashboard.BackColor = Color.LightSlateGray;      //LightGray
            btnProjects.BackColor = Color.LightSlateGray;
            btnDocuments.BackColor = Color.LightSlateGray;
            btnContacts.BackColor = Color.LightSlateGray;
            btnAdmin.BackColor = Color.LightSlateGray;

            CreateDynamicButtons(Reports, btnReports.Text);
            if (userRightsColl.Contains("28"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }
            else
            {
                frmReports frmReports = new frmReports(userRightsColl,mAffairShortName,mCommitteeShortName);
                frmReports.StartPosition = FormStartPosition.CenterScreen;
                frmReports.ShowDialog();
            }
        }
        CommonClass cmnCls = new CommonClass("");
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmSwitchUser frmSwitch = new frmSwitchUser();
            frmSwitch.StartPosition = FormStartPosition.CenterScreen;
            frmSwitch.Show();


            cmnCls.Users_LogOut_System(lblUserName.Text);
            this.Hide();
        }        

        private void linkLabel13_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (userRightsColl.Contains("1"))   //Add New Project
            {
                MessageBox.Show("You have no privilege to add project,Contact administrator");
                return;
            }

            MDI_ParenrForm.Projects.frmProjectInfo frmProj = new MDI_ParenrForm.Projects.frmProjectInfo(userRightsColl, lblUserName.Text,_isHeadOfSection);
            frmProj.StartPosition = FormStartPosition.CenterParent;
            frmProj.ShowDialog();
        }
        private void linkLabel12_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (userRightsColl.Contains("25"))   //Add New Company
            {
                MessageBox.Show("You have no privilege to add project,Contact administrator");
                return;
            }

            TenderTrackingSystem.Contacts.frmAddCompanyInfo frmCmp = new TenderTrackingSystem.Contacts.frmAddCompanyInfo(userRightsColl, 0, _userName, _isHeadOfSection);
            frmCmp.StartPosition = FormStartPosition.CenterParent;
            frmCmp.ShowDialog();
        }
        private void linkLabel11_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (userRightsColl.Contains("26"))   //Add New Company
            {
                MessageBox.Show("You have no privilege to add project,Contact administrator");
                return;
            }
            TenderTrackingSystem.Contacts.frmContactPerson frmPerson = new TenderTrackingSystem.Contacts.frmContactPerson(userRightsColl, _userName, _isHeadOfSection);
            frmPerson.StartPosition = FormStartPosition.CenterParent;
            frmPerson.ShowDialog();
        }
        private void linkLabel8_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (userRightsColl.Contains("13"))   //View On-going Contracts
            {
                MessageBox.Show("You have no privilege to add project,Contact administrator");
                return;
            }
            foreach (Control aControl in this.Controls)
            {
                if (aControl is Panel)
                {
                    if (aControl.Name.Equals("panelForDashboard"))
                    {
                        aControl.Visible = false;
                    }
                }
            }
            MDI_ParenrForm.Projects.frmOngoingContracts frmOngoingPrj = new MDI_ParenrForm.Projects.frmOngoingContracts(userRightsColl, _userName, _isHeadOfSection,null);
            frmOngoingPrj.StartPosition = FormStartPosition.CenterParent;
            frmOngoingPrj.ShowDialog();
        }
        private void linkLabel9_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (userRightsColl.Contains("14"))   //View Inactive Contracts
            {
                MessageBox.Show("You have no privilege to add project,Contact administrator");
                return;
            }
            foreach (Control aControl in this.Controls)
            {
                if (aControl is Panel)
                {
                    if (aControl.Name.Equals("panelForDashboard"))
                    {
                        aControl.Visible = false;
                    }
                }
            }

            MDI_ParenrForm.Projects.frmInactiveProjects frmInactivePrj = new MDI_ParenrForm.Projects.frmInactiveProjects(userRightsColl, _userName, _isHeadOfSection);
            frmInactivePrj.StartPosition = FormStartPosition.CenterParent;
            frmInactivePrj.ShowDialog();
        }                

        // Protected Connection.
        protected SqlConnection sqlConn;
        protected SqlCommand sqlCom;

        protected SqlDataReader sqlReader;
        private System.Windows.Forms.Label label1;         
        //CreateCheckBox chkBox = null;
        //CheckBox headerCheckBox = null;
        static BindingSource myBindingSource = null;
        DataTable dtTemp = null;
        DataTable dtTempForCombo = null;      

        DAL dataCls = new DAL();         
        DataTable finalDt = null;
        int totalProjectsCount = 0;
        private void FillAllProjectsInformation(char chkInfo)
        {
            if (chkInfo == 'R')
            {
                cmbPrjCode.SelectedIndex = -1;
                cmbTenderNo.SelectedIndex = -1;
                cmbCurrentStage.SelectedIndex = -1;
                cmbTenderStatus.SelectedIndex = -1;
                cmbTypeOftender.SelectedIndex = -1;
                cmbtenderCommittee.SelectedIndex = -1;
                cmbTypeofContract.SelectedIndex = -1;
                cmbFiscalYear.SelectedIndex = -1;
                cmbUserDepart.SelectedIndex = -1;

                txtPrjTitle.Text = "";
                cmbPrjCode.Text = "";
                cmbTenderNo.Text = "";
            }

            if (dgView.ColumnCount == 0)
            {
                //headerCheckBox = new CheckBox();
                //chkBox = new CreateCheckBox(dgView, headerCheckBox);
                //chkBox.AddHeaderCheckBox();                 

                var col0 = new DataGridViewCheckBoxColumn();
                var col1 = new DataGridViewTextBoxColumn();
                var col2 = new DataGridViewLinkColumn();        // DataGridViewAutoFilterTextBoxColumn();
                var col3 = new DataGridViewTextBoxColumn();
                var col4 = new DataGridViewTextBoxColumn();
                var col5 = new DataGridViewTextBoxColumn();
                var col6 = new DataGridViewTextBoxColumn();
                var col7 = new DataGridViewTextBoxColumn();
                var col8 = new DataGridViewTextBoxColumn();
                var col9 = new DataGridViewTextBoxColumn();
                var col10 = new DataGridViewTextBoxColumn();
                var col11 = new DataGridViewTextBoxColumn();
                var col12 = new DataGridViewTextBoxColumn();
                var col13 = new DataGridViewTextBoxColumn();
                var col14 = new DataGridViewTextBoxColumn();

                if (!profile_Name.Equals("EBSD Staff"))
                    dgView.Columns.AddRange(new DataGridViewColumn[] { col0, col1, col2, col3, col4, col5, col6, col7, col8, col9, col10, col11, col12 });
                else
                    dgView.Columns.AddRange(new DataGridViewColumn[] { col0, col1, col2, col3, col4, col5, col6, col7, col8, col9,col13, col10, col11, col12, col14 });

                col0.DataPropertyName = "";
                col0.Width = 1;

                col1.DataPropertyName = "ProjectId";
                col1.HeaderText = "ProjectId";
                col1.Width = 1;

                col2.DataPropertyName = "ProjectCode";
                col2.HeaderText = "Project Code";
                col2.Width = 10;
                col2.LinkBehavior = LinkBehavior.NeverUnderline;

                col3.DataPropertyName = "ProjectTitle";
                col3.HeaderText = "ProjectTitle";
                col3.Width = 20;

                col4.DataPropertyName = "TenderNo";
                col4.HeaderText = "TenderNo";
                col4.Width = 10;

                col5.DataPropertyName = "CurrentStage";
                col5.HeaderText = "Current Stage";
                col5.Width = 5;

                col6.DataPropertyName = "TenderStatus";
                col6.HeaderText = "Tender Status";
                col6.Width = 5;

                col7.DataPropertyName = "TypeOfTender";
                col7.HeaderText = "Tender Type";
                col7.Width = 5;

                col8.DataPropertyName = "TenderCommittee";
                col8.HeaderText = "Tender Committee";
                col8.Width = 3;

                col9.DataPropertyName = "TypeofContract";
                col9.HeaderText = "Contract Type";
                col9.Width = 5;

                col10.DataPropertyName = "FiscalYear";
                col10.HeaderText = "Fiscal Year";
                col10.Width = 3;

                col11.DataPropertyName = "UserDepartment";
                col11.HeaderText = "User Department";
                col11.Width = 10;

                if (!profile_Name.Equals("EBSD Staff"))
                {
                    col12.DataPropertyName = "ContractNo";
                    col12.HeaderText = "Contract No.";
                    col12.Width = 12;

                    col13.DataPropertyName = "ID";
                    col13.HeaderText = "ID";
                    col13.Width = 1;
                }
                else
                {
                    col12.DataPropertyName = "MozanahID";
                    col12.HeaderText = "Mozanah ID";
                    col12.Width = 13;

                    col13.DataPropertyName = "ContractNo";
                    col13.HeaderText = "Contract No.";
                    col13.Width = 12;

                    col14.DataPropertyName = "ID";
                    col14.HeaderText = "ID";
                    col14.Width = 1;
                }         
            }
            else
            {
                dgView.DataSource = null;
                dgView.Refresh();              
            }
            foreach (DataGridViewColumn c in dgView.Columns)
            {
                c.DefaultCellStyle.Font = new Font("Calibri (Body)", 11F, GraphicsUnit.Pixel);
            }
            dgView.Columns[1].Visible = false;
            DataTable dtProject = null;
            string[] projRows = new string[8];

            try
            {    

                // Added by Varun on 09 Feb 2014 for filtering the project details based on UserAccessList specified for Affairs_Short_name                  
               
                StringBuilder buildSqlQuery = new StringBuilder();
                comCls = new CommonClass(_userName);
                if (!profile_Name.Equals("EBSD Staff"))
                {
                    buildSqlQuery.Append("SELECT p.proj_id, p.project_code, p.project_newname_en, p.tender_no, STAGES.Stage_Name, TenderStatus.Status_Name, " +
                     "TenderTypes.tender_type_name, Committee.committee_short_name, ContractTypes.TypeofContract, FiscalYear.FiscalYear, Department.Department, " +
                     "p.ptd_assign_qs, p.ts_issue_handling, p.StaffInCharge,CONTRACTORS.contract_no FROM PROJECTS p INNER JOIN AFFAIRS ON AFFAIRS.Affair_id = p.Affair_id  INNER JOIN Department ON p.department_id = Department.department_id  INNER JOIN STAGES ON STAGES.stage_id = p.stage_id  INNER JOIN " +
                     "TenderTypes ON TenderTypes.tender_type_id = p.tender_type_id  INNER JOIN ContractTypes ON ContractTypes.contract_type_id = p.contract_type_id INNER JOIN " +
                     "FiscalYear ON FiscalYear.FYID = p.FYID  INNER JOIN Committee  ON Committee.committee_id = p.committee_id INNER JOIN TenderStatus ON TenderStatus.Tender_Status_id = p.Tender_Status_id " +
                     "FULL OUTER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id WHERE ([TenderStatus].Tender_Status_id <> 10) AND ([TenderStatus].Tender_Status_id <> 9) AND ([TenderStatus].Tender_Status_id <> 17) and (p.isDeleted=0 )" + whereClause); 
                }
                else
                {

                    buildSqlQuery.Append("SELECT p.proj_id, p.project_code, p.project_newname_en, p.tender_no, STAGES.Stage_Name, TenderStatus.Status_Name, " +
                    "TenderTypes.tender_type_name, Committee.committee_short_name, ContractTypes.TypeofContract, FiscalYear.FiscalYear, Department.Department, " +
                    "p.ptd_assign_qs, p.ts_issue_handling, p.StaffInCharge, moazanah_proj_id, CONTRACTORS.contract_no FROM p INNER JOIN AFFAIRS ON AFFAIRS.Affair_id = p.Affair_id  INNER JOIN Department ON p.department_id = Department.department_id  INNER JOIN STAGES ON STAGES.stage_id = p.stage_id  INNER JOIN " +
                    "TenderTypes ON TenderTypes.tender_type_id = p.tender_type_id  INNER JOIN ContractTypes ON ContractTypes.contract_type_id = p.contract_type_id INNER JOIN " +
                    "FiscalYear ON FiscalYear.FYID = p.FYID  INNER JOIN Committee  ON Committee.committee_id = p.committee_id INNER JOIN TenderStatus ON TenderStatus.Tender_Status_id = p.Tender_Status_id " +
                    "FULL OUTER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id WHERE ([TenderStatus].Tender_Status_id <> 10) AND ([TenderStatus].Tender_Status_id <> 9) AND ([TenderStatus].Tender_Status_id <> 17) and (p.isDeleted=0 )" + whereClause); 
                    
                }

                // Modified and Added by Varun on 10 Feb 2014 for checking the committee and affairs selection
                if (mCommitteeShortName == "All" && mAffairShortName == "All")
                {
                    buildSqlQuery.Append(" ORDER BY p.dummyfield DESC");
                }
                else
                {
                    buildSqlQuery = comCls.SetFilteredQuery(buildSqlQuery, mCommitteeShortName, mAffairShortName,"ORDER BY p.dummyfield DESC");
                }
                sqlConn = new SqlConnection(connStr);
                sqlConn.Open();

                DAL dalObj = new DAL(); //Dharan                

                dtProject = dalObj.GetDataFromDB("Project", buildSqlQuery.ToString());

                finalDt = new DataTable("Project");
                finalDt.Columns.Add("");

                finalDt.Columns.Add("ProjectId");

                finalDt.Columns.Add("ProjectCode");
                finalDt.Columns.Add("ProjectTitle");

                finalDt.Columns.Add("TenderNo");
                finalDt.Columns.Add("CurrentStage");

                finalDt.Columns.Add("TenderStatus");
                finalDt.Columns.Add("TypeOfTender");

                finalDt.Columns.Add("TenderCommittee");
                finalDt.Columns.Add("TypeofContract");
                //if (profile_Name.Equals("EBSD Staff"))
                    finalDt.Columns.Add("ContractNo");
                finalDt.Columns.Add("FiscalYear");
                finalDt.Columns.Add("UserDepartment");

                // Added on Nov 20th 2013 sreedhar
                finalDt.Columns.Add("Qs");
                finalDt.Columns.Add("TndrHndl");
                finalDt.Columns.Add("Staff");                

                // Added on Jan 5th 2014 sreedhar
                if (profile_Name.Equals("EBSD Staff"))
                {
                    finalDt.Columns.Add("MozanahID");                    
                    finalDt.Columns.Add("ID", typeof(Int32));
                }
                else
                    finalDt.Columns.Add("ID",typeof(Int32));
                
                finalDt.AcceptChanges();

                short rowId = 1;
                foreach (DataRow drProj in dtProject.Rows)
                {
                    DataRow dr = finalDt.NewRow();
                    //string strProj = null;
                    //strProj = drProj[0].ToString();

                    //dr[1] = strProj;    //ProjectId
                    dr[1] = drProj[0];  //ProjectId
                    dr[2] = drProj[1];  //ProjectCode
                    dr[3] = drProj[2];  //ProjectTitle

                    dr[4] = drProj[3];  //TenderNo
                    dr[5] = drProj[4];  //CurrentStage

                    dr[6] = drProj[5];  //TenderStatus
                    dr[7] = drProj[6];  //TypeOfTender

                    dr[8] = drProj[7];  //TenderCommittee
                    dr[9] = drProj[8];  //TypeofContract

                    if (!profile_Name.Equals("EBSD Staff"))
                    {
                        dr[10] = drProj[9];  //FiscalYear
                        dr[11] = drProj[10];  //UserDepartment 

                        dr[12] = drProj[11];  //Qs 
                        dr[13] = drProj[12];  //Handl
                        dr[14] = drProj[13];  //Staff 
                        dr[15] = rowId;
                    }

                    if (profile_Name.Equals("EBSD Staff"))
                    {
                        dr[10] = drProj[15];  //ContractNo 
                        dr[11] = drProj[9];  //FiscalYear
                        dr[12] = drProj[10];  //UserDepartment 

                        dr[13] = drProj[11];  //Qs 
                        dr[14] = drProj[12];  //Handl
                        dr[15] = drProj[13];  //Staff 

                        dr[16] = drProj[14];  //MozanahID                           
                        dr[17] = rowId;
                    }                  
                    rowId++;
                    finalDt.Rows.Add(dr);
                    finalDt.AcceptChanges();
                }
                 
                dtTemp = finalDt;
                if (dtTemp.Rows.Count != 0)
                {
                    if (dtTemp.Rows.Count >= 23)
                        id2 = 22;
                    else
                        id2 = Convert.ToInt32(dtTemp.Rows[dtTemp.Rows.Count - 1]["ID"]);
                    toolStripLabel2.Text = id1.ToString();
                    toolStripLabel3.Text = id2.ToString();
                    dgView.DataSource = dtTemp.Select("ID>=" + id1 + " and ID <= " + id2).CopyToDataTable();                    
                }
                else
                {
                    dgView.DataSource = null;
                }
                Cursor = Cursors.Default;
                if (!profile_Name.Equals("EBSD Staff"))
                {
                    dgView.Columns[12].Visible = false;
                }
                else
                {
                    dgView.Columns[14].Visible = false;
                }
                dgView.Columns[1].Visible = false;                                  
                dgView.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
                dgView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgView.ColumnHeadersDefaultCellStyle.Font = new Font(dgView.Font, FontStyle.Bold);
                dgView.EnableHeadersVisualStyles = false;
                dgView.DefaultCellStyle.WrapMode = DataGridViewTriState.True; 
                totalProjectsCount = dtTemp.Rows.Count;
                lblCnt.Text = totalProjectsCount.ToString();
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }

            //headerCheckBox.KeyUp += new KeyEventHandler(chkBox.HeaderCheckBox_KeyUp);
            //headerCheckBox.MouseClick += new MouseEventHandler(chkBox.HeaderCheckBox_MouseClick);
            //dgView.CellContentClick += new DataGridViewCellEventHandler(chkBox.dgvSelectAll_CellContentClick);
            //dgView.CurrentCellDirtyStateChanged += new EventHandler(chkBox.dgvSelectAll_CurrentCellDirtyStateChanged);
            //dgView.CellPainting += new DataGridViewCellPaintingEventHandler(chkBox.dgvSelectAll_CellPainting);

            this.label1 = new Label();
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Service Uri:";
        }
             

        private void FillAllProjectsInformation_CommitteWise(char chkInfo)
        {
            Cursor = Cursors.WaitCursor;
            if (mAffairShortName == "")
            {
                MessageBox.Show("You do not have privilege for accessing any affairs, Contact administrator");
                return;
            }
            if (chkInfo == 'R')
            {
                txtPrjTitle.Text = "";
                cmbPrjCode.Text = "";
                cmbTenderNo.Text = "";

                cmbPrjCode.SelectedIndex = -1;
                cmbTenderNo.SelectedIndex = -1;
                cmbCurrentStage.SelectedIndex = -1;
                cmbTenderStatus.SelectedIndex = -1;
                cmbTypeOftender.SelectedIndex = -1;
                cmbtenderCommittee.SelectedIndex = -1;
                cmbTypeofContract.SelectedIndex = -1;
                cmbFiscalYear.SelectedIndex = -1;
                cmbUserDepart.SelectedIndex = -1;

                cmbQs.Text = "";
                cmbTndrHndl.Text = "";
                cmbStaff.Text = "";

                cmbQs.SelectedIndex = -1;
                cmbTndrHndl.SelectedIndex = -1;
                cmbStaff.SelectedIndex = -1;
            }

            if (dgView.ColumnCount == 0)
            {
                //headerCheckBox = new CheckBox();
                //chkBox = new CreateCheckBox(dgView, headerCheckBox);
                //chkBox.AddHeaderCheckBox();                

                var col0 = new DataGridViewCheckBoxColumn();
                var col1 = new DataGridViewTextBoxColumn();
                var col2 = new DataGridViewLinkColumn();        // DataGridViewAutoFilterTextBoxColumn();

                var col3 = new DataGridViewTextBoxColumn();
                var col4 = new DataGridViewTextBoxColumn();
                var col5 = new DataGridViewTextBoxColumn();
                var col6 = new DataGridViewTextBoxColumn();
                var col7 = new DataGridViewTextBoxColumn();
                var col8 = new DataGridViewTextBoxColumn();
                var col9 = new DataGridViewTextBoxColumn();
                var col10 = new DataGridViewTextBoxColumn();
                var col11 = new DataGridViewTextBoxColumn();
                var col12 = new DataGridViewTextBoxColumn();
                var col13 = new DataGridViewTextBoxColumn();
                var col14 = new DataGridViewTextBoxColumn();                 

                if (!profile_Name.Equals("EBSD Staff"))
                    dgView.Columns.AddRange(new DataGridViewColumn[] { col0, col1, col2, col3, col4, col5, col6, col7, col8, col9, col10, col11, col12 });
                else
                    dgView.Columns.AddRange(new DataGridViewColumn[] { col0, col1, col2, col3, col4, col5, col6, col7, col8, col9, col13,col10, col11, col12, col14 });

                dgView.AutoGenerateColumns = false;
                dgView.AllowUserToAddRows = false;
                dgView.AutoResizeColumns();
                
                col0.DataPropertyName = "";                
                col0.Width = 1;

                col1.DataPropertyName = "ProjectId";
                col1.HeaderText = "ProjectId";
                col1.Width = 1;

                col2.DataPropertyName = "ProjectCode";
                col2.HeaderText = "Project Code";
                col2.Width = 10;
                col2.LinkBehavior = LinkBehavior.NeverUnderline;

                col3.DataPropertyName = "ProjectTitle";
                col3.HeaderText = "ProjectTitle";                
                col3.Width = 20;

                col4.DataPropertyName = "TenderNo";
                col4.HeaderText = "TenderNo";
                col4.Width = 10;

                col5.DataPropertyName = "CurrentStage";
                col5.HeaderText = "Current Stage";
                col5.Width = 7;

                col6.DataPropertyName = "TenderStatus";
                col6.HeaderText = "Tender Status";
                col6.Width = 5;

                col7.DataPropertyName = "TypeOfTender";
                col7.HeaderText = "Tender Type";
                col7.Width = 5;

                col8.DataPropertyName = "TenderCommittee";
                col8.HeaderText = "Tender Committee";
                col8.Width = 3;

                col9.DataPropertyName = "TypeofContract";
                col9.HeaderText = "Contract Type";
                col9.Width = 5;

                col10.DataPropertyName = "FiscalYear";
                col10.HeaderText = "Fiscal Year";
                col10.Width = 5;

                col11.DataPropertyName = "UserDepartment";
                col11.HeaderText = "User Department";
                col11.Width = 10;

                if (!profile_Name.Equals("EBSD Staff"))
                {
                    col12.DataPropertyName = "ID";
                    col12.HeaderText = "ID";
                    col12.Width = 1;
                }
                else
                {
                    col12.DataPropertyName = "MozanahID";
                    col12.HeaderText = "Mozanah ID";
                    col12.Width = 13;

                    col13.DataPropertyName = "ContractNo";
                    col13.HeaderText = "Contract No.";
                    col13.Width = 12;

                    col14.DataPropertyName = "ID";
                    col14.HeaderText = "ID";
                    col14.Width = 1;
                }               
            }
            else
            {
                dgView.DataSource = null;
                dgView.Refresh();              
            }

            foreach (DataGridViewColumn c in dgView.Columns)
            {
                c.DefaultCellStyle.Font = new Font("Calibri (Body)", 11F, GraphicsUnit.Pixel);
            }

            DataTable dtProject = null;
            string[] projRows = new string[8];

            try
            {
                sqlConn = new SqlConnection(connStr);
                sqlConn.Open();

                DAL dalObj = new DAL(); //Dharan

                string sqlQuery = string.Empty;                 
                StringBuilder sqlBuildQuery = new StringBuilder();

                if (!profile_Name.Equals("EBSD Staff"))

                    sqlBuildQuery.Append("SELECT p.proj_id, p.project_code, p.project_newname_en, p.tender_no, STAGES.Stage_Name, TenderStatus.Status_Name, "+
                    "TenderTypes.tender_type_name, Committee.committee_short_name, ContractTypes.TypeofContract, FiscalYear.FiscalYear, Department.Department, "+
                    "p.ptd_assign_qs, p.ts_issue_handling, p.StaffInCharge FROM PROJECTS p INNER JOIN AFFAIRS ON AFFAIRS.Affair_id = p.Affair_id  INNER JOIN Department ON p.department_id = Department.department_id  INNER JOIN STAGES ON STAGES.stage_id = p.stage_id  INNER JOIN " +
                    "TenderTypes ON TenderTypes.tender_type_id = p.tender_type_id  INNER JOIN ContractTypes ON ContractTypes.contract_type_id = p.contract_type_id INNER JOIN "+
                    "FiscalYear ON FiscalYear.FYID = p.FYID  INNER JOIN Committee  ON Committee.committee_id = p.committee_id INNER JOIN TenderStatus ON TenderStatus.Tender_Status_id = p.Tender_Status_id "+
                    " WHERE ([TenderStatus].Tender_Status_id <> 10)  AND ([TenderStatus].Tender_Status_id <> 9) AND ([TenderStatus].Tender_Status_id <> 17) and (p.isDeleted=0)"+whereClause); 

                else

                    sqlBuildQuery.Append("SELECT p.proj_id, p.project_code, p.project_newname_en, p.tender_no, STAGES.Stage_Name, TenderStatus.Status_Name, " +
                    "TenderTypes.tender_type_name, Committee.committee_short_name, ContractTypes.TypeofContract, FiscalYear.FiscalYear, Department.Department, " +
                    "p.ptd_assign_qs, p.ts_issue_handling, p.StaffInCharge, moazanah_proj_id, CONTRACTORS.contract_no FROM p INNER JOIN AFFAIRS ON AFFAIRS.Affair_id = p.Affair_id  INNER JOIN Department ON p.department_id = Department.department_id  INNER JOIN STAGES ON STAGES.stage_id = p.stage_id  INNER JOIN " +
                    "TenderTypes ON TenderTypes.tender_type_id = p.tender_type_id  INNER JOIN ContractTypes ON ContractTypes.contract_type_id = p.contract_type_id INNER JOIN " +
                    "FiscalYear ON FiscalYear.FYID = p.FYID  INNER JOIN Committee  ON Committee.committee_id = p.committee_id INNER JOIN TenderStatus ON TenderStatus.Tender_Status_id = p.Tender_Status_id " +
                    "FULL OUTER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id WHERE ([TenderStatus].Tender_Status_id <> 10)  AND ([TenderStatus].Tender_Status_id <> 9) AND ([TenderStatus].Tender_Status_id <> 17) and (p.isDeleted=0)"+whereClause); 
                    //sqlBuildQuery.Append("SELECT p.proj_id,p.project_code, p.project_newname_en, p.tender_no, STAGES.Stage_Name, TenderStatus.Status_Name," +
                    //    "TenderTypes.tender_type_name, Committee.committee_short_name, ContractTypes.TypeofContract, FiscalYear.FiscalYear, Department.Department," +
                    //    " p.ptd_assign_qs,p.ts_issue_handling,p.StaffInCharge, moazanah_proj_id, CONTRACTORS.contract_no" +
                    //    " FROM [TenderStatus] RIGHT OUTER JOIN STAGES INNER JOIN [TenderTypes] INNER JOIN" +
                    //    " [ContractTypes] INNER JOIN [FiscalYear] INNER JOIN Committee RIGHT OUTER JOIN AFFAIRS INNER JOIN" +
                    //    " p ON AFFAIRS.Affair_id = p.Affair_id ON Committee.committee_id = p.committee_id ON " +
                    //    " [FiscalYear].FYID = p.FYID ON [ContractTypes].contract_type_id = p.contract_type_id ON " +
                    //    " [TenderTypes].tender_type_id = p.tender_type_id INNER JOIN Department ON p.department_id = Department.department_id ON STAGES.stage_id = p.stage_id ON [TenderStatus].Tender_Status_id = p.Tender_Status_id " +
                    //    " LEFT OUTER JOIN CONTRACTORS ON p.proj_id = CONTRACTORS.proj_id " +
                    //    " WHERE ([TenderStatus].Tender_Status_id <> 10) AND ([TenderStatus].Tender_Status_id <> 9) " + //AND ([TenderStatus].Tender_Status_id <> 8)
                    //    " and (p.isDeleted=0 )");

                // Modified and Added by Varun on 10 Feb 2014 for checking the committee and affairs selection
                if (mCommitteeShortName == "All" && mAffairShortName == "All")
                {
                    sqlBuildQuery.Append(" ORDER BY p.dummyfield DESC");
                }
                else
                    sqlBuildQuery = comCls.SetFilteredQuery(sqlBuildQuery, mCommitteeShortName, mAffairShortName, "ORDER BY p.dummyfield DESC");                

                dtProject = dalObj.GetDataFromDB("Project", sqlBuildQuery.ToString());
                DataTable finalDt = new DataTable("Project");
                finalDt.Columns.Add("Select");

                finalDt.Columns.Add("ProjectId");
                finalDt.Columns.Add("ProjectCode");
                finalDt.Columns.Add("ProjectTitle");

                finalDt.Columns.Add("TenderNo");
                finalDt.Columns.Add("CurrentStage");

                finalDt.Columns.Add("TenderStatus");
                finalDt.Columns.Add("TypeOfTender");

                finalDt.Columns.Add("TenderCommittee");
                finalDt.Columns.Add("TypeofContract");
                if (profile_Name.Equals("EBSD Staff"))
                {
                    finalDt.Columns.Add("ContractNo");
                }
                finalDt.Columns.Add("FiscalYear");
                finalDt.Columns.Add("UserDepartment");

                finalDt.Columns.Add("Qs");
                finalDt.Columns.Add("TndrHndl");
                finalDt.Columns.Add("Staff");

                if (profile_Name.Equals("EBSD Staff"))
                {
                    finalDt.Columns.Add("MozanahID");
                    finalDt.Columns.Add("ID", typeof(Int16));
                }
                else
                {
                    finalDt.Columns.Add("ID", typeof(Int16));
                }
                               
                finalDt.AcceptChanges();

                short rowId = 1;
                foreach (DataRow drProj in dtProject.Rows)
                {
                    DataRow dr = finalDt.NewRow();                    

                    //dr[1] = strProj;    //ProjectId
                    dr[1] = drProj[0];  //ProjectId
                    dr[2] = drProj[1];  //ProjectCode
                    dr[3] = drProj[2];  //ProjectTitle

                    dr[4] = drProj[3];  //TenderNo
                    dr[5] = drProj[4];  //CurrentStage

                    dr[6] = drProj[5];  //TenderStatus
                    dr[7] = drProj[6];  //TypeOfTender

                    dr[8] = drProj[7];  //TenderCommittee
                    dr[9] = drProj[8];  //TypeofContract

                    if (!profile_Name.Equals("EBSD Staff"))
                    {
                        dr[10] = drProj[9];  //FiscalYear
                        dr[11] = drProj[10];  //UserDepartment 

                        dr[12] = drProj[11];  //Qs 
                        dr[13] = drProj[12];  //Handl
                        dr[14] = drProj[13];  //Staff 
                        dr[15] = rowId;
                    }

                    if (profile_Name.Equals("EBSD Staff"))
                    {
                        dr[10] = drProj[15];  //ContractNo 
                        dr[11] = drProj[9];  //FiscalYear
                        dr[12] = drProj[10];  //UserDepartment 

                        dr[13] = drProj[11];  //Qs 
                        dr[14] = drProj[12];  //Handl
                        dr[15] = drProj[13];  //Staff 

                        dr[16] = drProj[14];  //MozanahID                           
                        dr[17] = rowId;
                    }                       

                    rowId++;
                    finalDt.Rows.Add(dr);
                    finalDt.AcceptChanges();
                }
                
                dgView.Columns[1].Visible = false;             
                
                dtTemp = finalDt;
                //dtTempForCombo = finalDt;                
                id1 = 1;
                if (dtTemp.Rows.Count != 0)
                {
                    if (dtTemp.Rows.Count >= 23)
                    {
                        id2 = 22;
                    }
                    else
                    {
                        id2 = Convert.ToInt16(dtTemp.Rows[dtTemp.Rows.Count - 1]["ID"]);
                    }

                    toolStripLabel2.Text = id1.ToString();
                    toolStripLabel3.Text = id2.ToString();
                    //dtFilteredRecords = ;
                    dgView.DataSource = dtTemp.Select("ID>=" + id1 + " and ID <= " + id2).CopyToDataTable();
                }
                else
                {
                    dgView.DataSource = null;
                }
                if (!profile_Name.Equals("EBSD Staff"))
                {
                    dgView.Columns[12].Visible = false;
                }
                else
                {
                    dgView.Columns[14].Visible = false;
                }
                Cursor = Cursors.Default;                 
                dgView.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
                dgView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgView.ColumnHeadersDefaultCellStyle.Font = new Font(dgView.Font, FontStyle.Bold);
                dgView.EnableHeadersVisualStyles = false;
                dgView.DefaultCellStyle.WrapMode = DataGridViewTriState.True; 
                totalProjectsCount = dtTemp.Rows.Count;
                lblCnt.Text = totalProjectsCount.ToString();

            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }

            //headerCheckBox.KeyUp += new KeyEventHandler(chkBox.HeaderCheckBox_KeyUp);
            //headerCheckBox.MouseClick += new MouseEventHandler(chkBox.HeaderCheckBox_MouseClick);             
            //dgView.CurrentCellDirtyStateChanged += new EventHandler(chkBox.dgvSelectAll_CurrentCellDirtyStateChanged);
            //dgView.CellPainting += new DataGridViewCellPaintingEventHandler(chkBox.dgvSelectAll_CellPainting);

            this.label1 = new Label();
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Service Uri:";

        }

        Int32 id1 = 1;
        Int32 id2 = 25;
        private string NavClicked = "";
        int CurrentPage = 1;

        #region FilterDataGrid
        //Added By Varun on 24/02/14 for creating pagination functionality
        // Filter DataGrid based on changing ID values
        private void FilterDataGrid()
        {
            try
            {
                Cursor = Cursors.WaitCursor;
                if (id1 == 1 && dtCmbTbl!=null && isRefresh==false)
                {
                    if (dtCmbTbl.Rows.Count >= 23)
                        id2 = 22;
                    else
                        id2 = Convert.ToInt16(dtCmbTbl.Rows[dtCmbTbl.Rows.Count - 1]["ID"]);
                }
                else if (id1 == 1 && dtTemp != null)
                {
                    if (dtTemp.Rows.Count >= 23)
                        id2 = 22;
                    else
                        id2 = Convert.ToInt16(dtTemp.Rows[dtTemp.Rows.Count - 1]["ID"]);
                }
                toolStripLabel2.Text = id1.ToString();
                toolStripLabel3.Text = id2.ToString();
                if (dtCmbTbl != null && isRefresh == false)
                    dgView.DataSource  = new BindingSource(dtCmbTbl.Select("ID>=" + id1 + " and ID <= " + id2).CopyToDataTable(),null);
                else
                    dgView.DataSource  = new BindingSource(dtTemp.Select("ID>=" + id1 + " and ID <= " + id2).CopyToDataTable(),null);
                             
                //totalProjectsCount = dgView.RowCount;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }
        #endregion

        #region DeterminePageBoundaries
        // This method will determine the correct
        // Page Boundaries for the RecordID's to filter by
        private void DeterminePageBoundaries()
        {           
                int totalRowCount = 0;
                if (dtCmbTbl != null && isRefresh == false)
                {
                    totalRowCount = dtCmbTbl.Rows.Count;
                    dtTemp = dtCmbTbl;
                }
                else
                    totalRowCount = dtTemp.Rows.Count;

                //This is the maximum rows to display on a page.
                //So we want paging to be implemented at 100 rows a page                          
                int pageRows = 23;
                int pages = 0;

                //If the rows per page are less than
                //the total row count do the following:
                if (pageRows < totalRowCount)
                {
                    //If the Modulus returns > 0 then there should be another page.
                    if ((totalRowCount % pageRows) > 0)
                    {
                        pages = ((totalRowCount / pageRows) + 1);
                    }
                    else
                    {
                        //There is nothing left after the Modulus,
                        //so the pageRows divide exactly...
                        //...into TotalRowCount leaving no rest,
                        //thus no extra page needs to be added.
                        pages = totalRowCount / pageRows;
                    }
                }
                else
                {
                    //If the rows per page are more than the total
                    //row count, we will obviously only ever have 1 page
                    pages = 1;
                }

                //Added By Varun on 24/02/14 for creating pagination functionality
                //We now need to determine the LowerBoundary
                //and UpperBoundary in order to correctly...
                //...determine the Correct RecordID's
                //to use in the bindingSource1.Filter property.
                int LowerBoundary = 0;
                int UpperBoundary = 0;

                //We now need to know what button was clicked,
                //if any (First, Last, Next, Previous)
                switch (NavClicked)
                {
                    case "First":
                        //First clicked, the Current Page will always be 1
                        CurrentPage = 1;
                        //The LowerBoundary will thus be ((50 * 1) - (50 - 1)) = 1
                        LowerBoundary = ((pageRows * CurrentPage) - (pageRows - 1));

                        //If the rows per page are less than
                        //the total row count do the following:
                        if (pageRows < totalRowCount)
                        {
                            UpperBoundary = (pageRows * CurrentPage);
                        }
                        else
                        {
                            //If the rows per page are more than
                            //the total row count do the following:
                            //There is only one page, so get
                            //the total row count as an UpperBoundary
                            UpperBoundary = totalRowCount;
                        }

                        //Now using these boundaries, get the
                        //appropriate RecordID's (min & max)...
                        //...for this specific page.
                        //Remember, .NET is 0 based, so subtract 1 from both boundaries
                        id1 = Convert.ToInt16(dtTemp.Rows[LowerBoundary - 1]["ID"]);
                        id2 = Convert.ToInt16(dtTemp.Rows[UpperBoundary - 1]["ID"]);

                        break;

                    case "Last":
                        //Last clicked, the CurrentPage will always be = to the variable pages
                        CurrentPage = pages;
                        LowerBoundary = ((pageRows * CurrentPage) - (pageRows - 1));
                        //The UpperBoundary will always be the sum total of all the rows
                        UpperBoundary = totalRowCount;

                        //Now using these boundaries, get the appropriate
                        //RecordID's (min & max)...
                        //...for this specific page.
                        //Remember, .NET is 0 based, so subtract 1 from both boundaries
                        id1 = Convert.ToInt16(dtTemp.Rows[LowerBoundary - 1]["ID"]);
                        id2 = Convert.ToInt16(dtTemp.Rows[UpperBoundary - 1]["ID"]);

                        break;

                    case "Next":
                        //Next clicked
                        if (CurrentPage != pages)
                        {
                            //If we arent on the last page already, add another page
                            CurrentPage += 1;
                        }

                        LowerBoundary = ((pageRows * CurrentPage) - (pageRows - 1));

                        if (CurrentPage == pages)
                        {
                            //If we are on the last page, the UpperBougndary
                            //will always be the sum total of all the rows
                            UpperBoundary = totalRowCount;
                        }
                        else
                        {
                            //Else if we have a pageRow of 50 and we are
                            //on page 3, the UpperBoundary = 150
                            UpperBoundary = (pageRows * CurrentPage);
                        }

                        //Now using these boundaries, get the appropriate
                        //RecordID's (min & max)...
                        //...for this specific page.
                        //Remember, .NET is 0 based, so subtract 1 from both boundaries

                        id1 = Convert.ToInt16(dtTemp.Rows[LowerBoundary - 1]["ID"]);
                        id2 = Convert.ToInt16(dtTemp.Rows[UpperBoundary - 1]["ID"]);

                        break;

                    case "Previous":
                        //Previous clicked
                        if (CurrentPage != 1)
                        {
                            //If we aren't on the first page already,
                            //subtract 1 from the CurrentPage
                            CurrentPage -= 1;
                        }
                        //Get the LowerBoundary
                        LowerBoundary = ((pageRows * CurrentPage) - (pageRows - 1));

                        if (pageRows < totalRowCount)
                        {
                            UpperBoundary = (pageRows * CurrentPage);
                        }
                        else
                        {
                            UpperBoundary = totalRowCount;
                        }

                        //Now using these boundaries,
                        //get the appropriate RecordID's (min & max)...
                        //...for this specific page.
                        //Remember, .NET is 0 based, so subtract 1 from both boundaries
                        id1 = Convert.ToInt16(dtTemp.Rows[LowerBoundary - 1]["ID"]);
                        id2 = Convert.ToInt16(dtTemp.Rows[UpperBoundary - 1]["ID"]);

                        break;

                    default:
                        //No button was clicked.
                        LowerBoundary = ((pageRows * CurrentPage) - (pageRows - 1));

                        //If the rows per page are less than
                        //the total row count do the following:
                        if (pageRows < totalRowCount)
                        {
                            UpperBoundary = (pageRows * CurrentPage);
                        }
                        else
                        {
                            //If the rows per page are more than
                            //the total row count do the following:
                            //Therefore there is only one page,
                            //so get the total row count as an UpperBoundary
                            UpperBoundary = totalRowCount;
                        }

                        //Now using these boundaries, get the
                        //appropriate RecordID's (min & max)...
                        //...for this specific page.
                        //Remember, .NET is 0 based, so subtract 1 from both boundaries
                        id1 = Convert.ToInt16(dtTemp.Rows[LowerBoundary - 1]["ID"]);
                        id2 = Convert.ToInt16(dtTemp.Rows[UpperBoundary - 1]["ID"]);

                        break;
                }
            

        }
        #endregion

        private enum NavButton
        {
            First = 1,
            Next = 2,
            Previous = 3,
            Last = 4,
        }


        char cFilter = ' ';
        public char Filtered
        {
            get { return cFilter; }
            set { cFilter = value; }
        }

        DataTable dtCmbTbl = null;
        private void GridFill(string filterQuery)
        {
                       
            dtTempForCombo = dtTemp;
            int iCnt = dtTempForCombo.Rows.Count;
            
            if (dtTempForCombo.Select(filterQuery).Length != 0)
            {
                dtCmbTbl = dtTempForCombo.Select(filterQuery).CopyToDataTable();                 
                try
                {
                    int rowCounter = 1;
                    foreach (DataRow dr in dtCmbTbl.Rows)
                        dr["ID"] = rowCounter++;
                    dtCmbTbl.AcceptChanges();
                    id1 = 1;                    
                    if (dtCmbTbl.Rows.Count >= 23)
                        id2 = 22;
                    else
                        id2 = Convert.ToInt16(dtCmbTbl.Rows[dtCmbTbl.Rows.Count - 1]["ID"]);

                    toolStripLabel2.Text = id1.ToString();
                    toolStripLabel3.Text = id2.ToString();                                
                    myBindingSource = new BindingSource(dtCmbTbl.Select("ID>=" + id1 + " and ID <= " + id2).CopyToDataTable(), null);
                    dgView.DataSource = myBindingSource;                    

                    dgView.EnableHeadersVisualStyles = false;
                    dgView.Columns[1].Visible = false;

                    if (!profile_Name.Equals("EBSD Staff"))
                    {
                        dgView.Columns[12].Visible = false;
                    }

                    if (filterQuery != "")
                    {
                        Filtered = 'Y';
                        isRefresh = false;
                    }
                    else
                        Filtered = ' ';                    
                }
                catch (Exception ex)
                {
                    string exMsg = ex.Message;
                }
                finally
                {
                }
                totalProjectsCount = dtCmbTbl.Rows.Count;
                lblCnt.Text = totalProjectsCount.ToString();
            }
            else
            {
                dtCmbTbl = null;
                myBindingSource = new BindingSource(null, null);
                dgView.DataSource = myBindingSource;
                id1 = 0;
                id2 = 0;
                toolStripLabel2.Text = id1.ToString();
                toolStripLabel3.Text = id2.ToString();
                totalProjectsCount = 0;
                lblCnt.Text = "0";
            }            
        }
        private void FillCombo()
        {
            DAL dalObj = new DAL();

            if (whereClause != null)
            {
                if (whereClause != "")
                {
                    dalObj.populateCmbBox("Select p.Project_Code From Projects p where " + whereClause.Substring(4) + " Order by p.Project_Code", cmbPrjCode);
                }
            }
            else
            {
                dalObj.populateCmbBox("Select Project_Code From Projects p Order by p.Project_Code", cmbPrjCode);
            }
            cmbPrjCode.SelectedIndex = -1;

            dalObj.populateCmbBox("select tender_no from Projects p WHERE (tender_no IS NOT NULL) " + whereClause + " Order by tender_no ", cmbTenderNo);
            cmbTenderNo.SelectedIndex = -1;

            dalObj.populateCmbBox("select Stage_Name from STAGES", cmbCurrentStage);
            cmbCurrentStage.SelectedIndex = -1;

            dalObj.populateCmbBox("Select [Status_Name],[TenderStatusShortName] From [TenderStatus] WHERE Tender_Status_id not in (9,10)Order by Tender_Status_id ", cmbTenderStatus);
            cmbTenderStatus.SelectedIndex = -1;

            dalObj.populateCmbBox("Select tender_type_name From [TenderTypes] Order by tender_type_name", cmbTypeOftender);
            cmbTypeOftender.SelectedIndex = -1;

            dalObj.populateCmbBox("select committee_short_name,committee_name from [Committee]", cmbtenderCommittee);
            cmbtenderCommittee.SelectedIndex = -1;

            dalObj.populateCmbBox("select [TypeofContract] from [ContractTypes]", cmbTypeofContract);
            cmbTypeofContract.SelectedIndex = -1;

            dalObj.populateCmbBox("Select [FiscalYear] From [FiscalYear]", cmbFiscalYear);  //Fiscal_Year
            cmbFiscalYear.SelectedIndex = -1;

            dalObj.populateCmbBox("Select department_short_name,Department From Department", cmbUserDepart);
            cmbUserDepart.SelectedIndex = -1;

            dalObj.populateCmbBox("Select ShortName From Contacts where ShortName is not NULL order by ShortName", cmbQs);
            cmbQs.SelectedIndex = -1;

            dalObj.populateCmbBox("Select ShortName From Contacts where ShortName is not NULL order by ShortName", cmbTndrHndl);
            cmbTndrHndl.SelectedIndex = -1;

            dalObj.populateCmbBox("Select ShortName From Contacts where ShortName is not NULL order by ShortName", cmbStaff);
            cmbStaff.SelectedIndex = -1;

            if (profile_Name.Equals("EBSD Staff"))
            {
                dalObj.populateCmbBox("Select moazanah_proj_id From PROJECTS where moazanah_proj_id<>'' order by moazanah_proj_id", cmbMozanahID);
                cmbMozanahID.SelectedIndex = -1;

                dalObj.populateCmbBox("Select contract_no from CONTRACTORS where contract_no<>'' order by contract_no", cmbContractNo);
                cmbContractNo.SelectedIndex = -1;                
            } 
        }
        private void filterCombo()
        {
            string filterQuery = "";             
            if (cmbPrjCode.SelectedIndex != -1)
            {
                if (filterQuery == "")
                {
                    filterQuery = "ProjectCode = '" + cmbPrjCode.SelectedItem.ToString().Trim() + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "ProjectCode = '" + cmbPrjCode.SelectedItem.ToString() + "'";
                }
            }
            else if (cmbPrjCode.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "ProjectCode like '%" + cmbPrjCode.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "ProjectCode like '%" + cmbPrjCode.Text + "%'";
                }
            }


            if (txtPrjTitle.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "ProjectTitle like '%" + txtPrjTitle.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "ProjectTitle like '%" + txtPrjTitle.Text + "%'";
                }
            }


            if (cmbTenderNo.SelectedIndex != -1)
            {
                if (filterQuery == "")
                {
                    if (cmbTenderNo.SelectedItem.ToString() == "")
                    {
                        filterQuery = "TenderNo is Null";
                    }
                    else
                    {
                        filterQuery = "TenderNo = '" + cmbTenderNo.SelectedItem.ToString() + "'";
                    }
                }
                else
                {
                    filterQuery = filterQuery + " and " + "TenderNo = '" + cmbTenderNo.SelectedItem.ToString() + "'";
                }
            }
            else if (cmbTenderNo.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "TenderNo like '%" + cmbTenderNo.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "TenderNo like '%" + cmbTenderNo.Text + "%'";
                }
            }

            if (cmbFiscalYear.SelectedIndex != -1)
            {
                if (filterQuery == "")
                {
                    filterQuery = "FiscalYear = '" + cmbFiscalYear.SelectedItem.ToString() + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "FiscalYear = '" + cmbFiscalYear.SelectedItem.ToString() + "'";
                }
            }
            else if (cmbFiscalYear.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "FiscalYear like '%" + cmbFiscalYear.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "FiscalYear like '%" + cmbFiscalYear.Text + "%'";
                }
            }


            if (cmbTypeofContract.SelectedIndex != -1)
            {
                if (filterQuery == "")
                {
                    filterQuery = "TypeofContract = '" + cmbTypeofContract.SelectedItem.ToString() + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "TypeofContract = '" + cmbTypeofContract.SelectedItem.ToString() + "'";
                }
            }
            else if (cmbTypeofContract.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "TypeofContract like '%" + cmbTypeofContract.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "TypeofContract like '%" + cmbTypeofContract.Text + "%'";
                }
            }
            
            if (cmbtenderCommittee.SelectedIndex != -1)
            {
                if (filterQuery == "")
                {
                    filterQuery = "TenderCommittee = '" + cmbtenderCommittee.SelectedItem.ToString() + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "TenderCommittee = '" + cmbtenderCommittee.SelectedItem.ToString() + "'";
                }

            }
            else if (cmbtenderCommittee.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "TenderCommittee like '%" + cmbtenderCommittee.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "TenderCommittee like '%" + cmbtenderCommittee.Text + "%'";
                }
            }
            if (cmbTypeOftender.SelectedIndex != -1)
            {
                if (filterQuery == "")
                {
                    filterQuery = "TypeOfTender = '" + cmbTypeOftender.SelectedItem.ToString() + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "TypeOfTender = '" + cmbTypeOftender.SelectedItem.ToString() + "'";
                }
            }
            else if (cmbTypeOftender.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "TypeOfTender like '%" + cmbTypeOftender.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "TypeOfTender like '%" + cmbTypeOftender.Text + "%'";
                }
            }
            if (cmbTenderStatus.SelectedIndex != -1)
            {
                if (filterQuery == "")
                {
                    filterQuery = "TenderStatus = '" + cmbTenderStatus.SelectedItem.ToString() + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "TenderStatus = '" + cmbTenderStatus.SelectedItem.ToString() + "'";
                }
            }
            else if (cmbTenderStatus.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "TenderStatus like '%" + cmbTenderStatus.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "TenderStatus like '%" + cmbTenderStatus.Text + "%'";
                }
            }
            //DataRowView cmbCurrentStageView = (DataRowView)cmbCurrentStage.SelectedItem;
            if (cmbCurrentStage.SelectedIndex != -1)
            {
                if (cmbCurrentStage.SelectedItem.Equals("Contracts Process"))
                {
                    if (filterQuery == "")
                    {
                        filterQuery = "CurrentStage = '" + cmbCurrentStage.SelectedItem.ToString() + "' and TenderStatus<>'Cancelled' and TenderStatus<>'Committed'";
                    }
                    else
                    {
                        filterQuery = filterQuery + " and " + "CurrentStage = '" + cmbCurrentStage.SelectedItem.ToString() + "' and TenderStatus<>'Cancelled' and TenderStatus<>'Committed'";
                    }
                }
                else
                {
                    if (filterQuery == "")
                    {
                        filterQuery = "CurrentStage = '" + cmbCurrentStage.SelectedItem.ToString() + "' and TenderStatus<>'Cancelled'";
                    }
                    else
                    {
                        filterQuery = filterQuery + " and " + "CurrentStage = '" + cmbCurrentStage.SelectedItem.ToString() + "' and TenderStatus<>'Cancelled'";
                    }
                }
            }
            else if (cmbCurrentStage.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "CurrentStage like '%" + cmbCurrentStage.Text + "%' and TenderStatus<>'Cancelled'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "CurrentStage like '%" + cmbCurrentStage.Text + "%' and TenderStatus<>'Cancelled'";
                }
            }
             
            if (cmbUserDepart.SelectedIndex != -1)
            {
                if (filterQuery == "")
                {
                    filterQuery = "UserDepartment = '" + cmbUserDepart.SelectedValue + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "UserDepartment = '" + cmbUserDepart.SelectedValue + "'";
                }
            }
            else if (cmbUserDepart.Text != "")
            {

                if (filterQuery == "")
                {
                    filterQuery = "UserDepartment like '%" + cmbUserDepart.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "UserDepartment like '%" + cmbUserDepart.Text + "%'";
                }
            }


            // Newely Added on Nov 20th 2013 for AiisheNed Qs 
            if (cmbQs.SelectedIndex != -1)
            {
                if (filterQuery == "")
                {
                    filterQuery = "Qs = '" + cmbQs.SelectedItem + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "Qs = '" + cmbQs.SelectedItem + "'";
                }
            }
            else if (cmbQs.Text != "")
            {

                if (filterQuery == "")
                {
                    filterQuery = "Qs like '%" + cmbQs.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "Qs like '%" + cmbQs.Text + "%'";
                }
            }


            if (cmbTndrHndl.SelectedIndex != -1)
            {
                if (filterQuery == "")
                {
                    filterQuery = "TndrHndl = '" + cmbTndrHndl.SelectedItem + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "TndrHndl = '" + cmbTndrHndl.SelectedItem + "'";
                }
            }
            else if (cmbTndrHndl.Text != "")
            {

                if (filterQuery == "")
                {
                    filterQuery = "TndrHndl like '%" + cmbTndrHndl.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "TndrHndl like '%" + cmbTndrHndl.Text + "%'";
                }
            }

            if (cmbStaff.SelectedIndex != -1)
            {
                if (filterQuery == "")
                {
                    filterQuery = "Staff = '" + cmbStaff.SelectedItem + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "Staff = '" + cmbStaff.SelectedItem + "'";
                }
            }
            else if (cmbStaff.Text != "")
            {

                if (filterQuery == "")
                {
                    filterQuery = "Staff like '%" + cmbStaff.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "Staff like '%" + cmbStaff.Text + "%'";
                }
            }
            if (cmbMozanahID.SelectedIndex != -1)
            {
                if (filterQuery == "")
                {
                    filterQuery = "MozanahID = '" + cmbMozanahID.SelectedValue + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "MozanahID = '" + cmbMozanahID.SelectedValue + "'";
                }
            }
            else if (cmbMozanahID.Text != "")
            {

                if (filterQuery == "")
                {
                    filterQuery = "MozanahID like '%" + cmbMozanahID.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "MozanahID like '%" + cmbMozanahID.Text + "%'";
                }
            }

            if (cmbContractNo.SelectedIndex != -1)
            {
                if (filterQuery == "")
                {
                    filterQuery = "ContractNo = '" + cmbContractNo.SelectedValue + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "ContractNo = '" + cmbContractNo.SelectedValue + "'";
                }
            }
            else if (cmbContractNo.Text != "")
            {

                if (filterQuery == "")
                {
                    filterQuery = "ContractNo like '%" + cmbContractNo.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "ContractNo like '%" + cmbContractNo.Text + "%'";
                }
            }                     

            if (filterQuery == "")
            {
                GridFill("");
            }
            else
            {
                GridFill(filterQuery);
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            if (userRightsColl.Contains("1"))   //Add New Project
            {
                MessageBox.Show("You have no privilege to add project,Contact administrator");
                return;
            }
            MDI_ParenrForm.Projects.frmProjectInfo prjInfo = new MDI_ParenrForm.Projects.frmProjectInfo(userRightsColl, lblUserName.Text, _isHeadOfSection);
            prjInfo.StartPosition = FormStartPosition.CenterScreen;
            prjInfo.ShowDialog();
            FillAllProjectsInformation('R');          
        }
        private void dgView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 2)
            {
                string mnstryCode = string.Empty;
                try
                {
                    ProjectStages projStg = new ProjectStages(userRightsColl, "", Convert.ToInt16(dgView.Rows[e.RowIndex].Cells[1].Value), _userName,null,_isHeadOfSection);                     
                    projStg.StartPosition = FormStartPosition.CenterParent;
                    projStg.ShowDialog();
                    UpdateTimeInDummyField(projStg.ProjectId);

                    //if(projStg.ProjTransferedToComm=='Y' || Filtered ==' ')                     

                    //if (!userRightsColl.Contains("54"))
                    //{
                        if (projStg.ProjTransferedToComm == 'Y' || projStg.ProjReTendered=='Y')
                            FillAllProjectsInformation('R');

                    //    //else if (Filtered!='Y')
                    //    //    FillAllProjectsInformation_CommitteWise(' ', filterQueryMain, Filtered);
                    //}

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }             
        }
        private void UpdateTimeInDummyField(int ProjIDTime)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        cmd.CommandText = @"UPDATE PROJECTS SET dummyfield = @fieldForTime where proj_id=@prjID";
                        cmd.Parameters.AddWithValue("@fieldForTime", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@prjID", ProjIDTime);

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the TimeSpan, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }       
        private void txtPrjTitle_Leave(object sender, EventArgs e)
        {

        }

        bool isRefresh = true;
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            //Added by Varun on 10 Feb 2014 for displaying the projects related to user access rights only
            isRefresh = true;             
            FillAllProjectsInformation_CommitteWise('R');             
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (userRightsColl.Contains("3"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            int iCnt = 0;
            for (int iCounter = 0; iCounter < dgView.RowCount; iCounter++)
            {
                DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgView.Rows[iCounter].Cells[0];

                if (chkactive.Value != null)
                {
                    if (chkactive.Value.ToString().ToLower() == "true")
                        iCnt = iCnt + 1;
                }
            }
            if (iCnt > 1)
            {
                MessageBox.Show("Please Select Only One Record For Edit");
                return;
            }


            int ProjectID = 0;
            string prjCode = string.Empty;

            for (int iCounter = 0; iCounter < dgView.RowCount; iCounter++)
            {
                DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgView.Rows[iCounter].Cells[0];
                if (chkactive.Value != null)
                {
                    if (chkactive.Value.ToString().ToLower() == "true")
                    {
                        ProjectID = Convert.ToInt16(dgView.Rows[iCounter].Cells[1].Value);
                    }
                }
            }
            if (ProjectID == 0)
            {
                MessageBox.Show("Please click the checkbox to select the project you want to View/Edit.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                // frmProjectEdit frmEditProject = new frmProjectEdit(ProjectID, prjCode, affairsName, deptName, prjTitleEn, prjTitleArb, tndrCommitte, typeOfTender, fiscalYear, typeOfCntr);
                frmProjectEdit frmEditProject = new frmProjectEdit(userRightsColl, ProjectID, prjCode, lblUserName.Text);
                frmEditProject.StartPosition = FormStartPosition.CenterParent;
                frmEditProject.ShowDialog();
            }
        }
        int prjID = 0;
        private void btnDeleteProject_Click(object sender, EventArgs e)
        {
            try
            {
                if (userRightsColl.Contains("2"))
                {
                    MessageBox.Show("You have no privilege, Contact administrator");
                    return;
                }


                int iCnt = 0;
                for (int iCounter = 0; iCounter < dgView.RowCount; iCounter++)
                {
                    DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgView.Rows[iCounter].Cells[0];

                    if (chkactive.Value != null)
                    {
                        if (chkactive.Value.ToString().ToLower() == "true")
                            iCnt = iCnt + 1;
                    }
                }

                if (iCnt > 1)
                {
                    MessageBox.Show("Please Select Only One Record For Delete");
                    return;
                }

                List<int> lstObj = new List<int>();
                 
                sqlConn = new SqlConnection(connStr);
                sqlConn.Open();
                for (int iCounter = 0; iCounter < dgView.RowCount; iCounter++)
                {
                    DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgView.Rows[iCounter].Cells[0];
                    if (chkactive.Value != null)
                    {
                        if (chkactive.Value.ToString().ToLower() == "true")
                        {                            
                            prjID = Convert.ToInt16(dgView.Rows[iCounter].Cells[1].Value);                            
                            try
                            {                               
                                DialogResult dlgResult = DialogResult.Yes;
                                dlgResult = MessageBox.Show(" Are you sure you want to move the Project to Deleted Projects?", "Delete Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                                if (dlgResult.ToString() == "Yes")
                                {
                                    try
                                    {
                                        using (SqlCommand sqlCom = new SqlCommand("update Projects set isDeleted=1 where Proj_id =" + prjID, sqlConn))
                                        {
                                            sqlCom.ExecuteNonQuery();
                                        }                                       
                                        MessageBox.Show("Record Successfully moved to Deleted Projects");
                                    }
                                    catch (Exception ex)
                                    {
                                        MessageBox.Show("Error occurred while updating the value of isDeleted column of Project table.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    }
                                    // moved by Varun
                                    lstObj.Add(iCounter);

                                }
                                else
                                {
                                    return;
                                }

                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("You have no privilege to delete this project,Contact administrator", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                sqlConn.Close();
                                return;
                            }
                            finally
                            {
                                sqlConn.Close();
                            }
                        }
                    }
                }
                short sClear = 0;
                if (dgView.Rows.Count == lstObj.Count)
                {
                    dgView.Rows.RemoveAt(lstObj[0]);
                    sClear = 1;
                }
                if (sClear != 1)
                {
                    for (int iCounter = 0; iCounter < lstObj.Count; iCounter++)
                    {
                        if (iCounter == 0)
                            dgView.Rows.RemoveAt(lstObj[iCounter]);
                        if (iCounter != 0)
                            dgView.Rows.RemoveAt(lstObj[iCounter] - 1);
                    }
                }

                if (lstObj.Count == 0)
                    MessageBox.Show("Please click the checkbox to select the project you want to Delete.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while connecting to database", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }             
        }       

        private void cmbUserDepart_DropDown(object sender, EventArgs e)
        {
            ComboBox senderComboBox = (ComboBox)sender;
            int width = senderComboBox.DropDownWidth;
            Graphics g = senderComboBox.CreateGraphics();
            Font font = senderComboBox.Font;
            int vertScrollBarWidth =
                (senderComboBox.Items.Count > senderComboBox.MaxDropDownItems)
                ? SystemInformation.VerticalScrollBarWidth : 0;
            int newWidth;


            foreach (string s in ((ComboBox)sender).Items)
            {
                newWidth = (int)g.MeasureString(s, font).Width
                    + vertScrollBarWidth;

                if (width < newWidth)
                {
                    width = newWidth;
                }
            }
            senderComboBox.DropDownWidth = width;
        }

        private void cmbTenderNo_DropDown(object sender, EventArgs e)
        {
            ComboBox senderComboBox = (ComboBox)sender;
            int width = senderComboBox.DropDownWidth;
            Graphics g = senderComboBox.CreateGraphics();
            Font font = senderComboBox.Font;
            int vertScrollBarWidth =
                (senderComboBox.Items.Count > senderComboBox.MaxDropDownItems)
                ? SystemInformation.VerticalScrollBarWidth : 0;
            int newWidth;
            foreach (string s in ((ComboBox)sender).Items)
            {
                newWidth = (int)g.MeasureString(s, font).Width
                    + vertScrollBarWidth;


                if (width < newWidth)
                {
                    width = newWidth;
                }
            }
            senderComboBox.DropDownWidth = width;
        }

        private void cmbCurrentStage_DropDown(object sender, EventArgs e)
        {
            ComboBox senderComboBox = (ComboBox)sender;
            int width = senderComboBox.DropDownWidth;
            Graphics g = senderComboBox.CreateGraphics();
            Font font = senderComboBox.Font;
            int vertScrollBarWidth =
                (senderComboBox.Items.Count > senderComboBox.MaxDropDownItems)
                ? SystemInformation.VerticalScrollBarWidth : 0;
            int newWidth;
            foreach (string s in ((ComboBox)sender).Items)
            {
                newWidth = (int)g.MeasureString(s, font).Width
                    + vertScrollBarWidth;


                if (width < newWidth)
                {
                    width = newWidth;
                }
            }
            senderComboBox.DropDownWidth = width;
        }

        private void cmbTenderStatus_DropDown(object sender, EventArgs e)
        {
            ComboBox senderComboBox = (ComboBox)sender;
            int width = senderComboBox.DropDownWidth;
            Graphics g = senderComboBox.CreateGraphics();
            Font font = senderComboBox.Font;
            int vertScrollBarWidth =
                (senderComboBox.Items.Count > senderComboBox.MaxDropDownItems)
                ? SystemInformation.VerticalScrollBarWidth : 0;
            int newWidth;
            foreach (string s in ((ComboBox)sender).Items)
            {
                newWidth = (int)g.MeasureString(s, font).Width
                    + vertScrollBarWidth;


                if (width < newWidth)
                {
                    width = newWidth;
                }
            }
            senderComboBox.DropDownWidth = width;
        }

        private void cmbTypeOftender_DropDown(object sender, EventArgs e)
        {
            ComboBox senderComboBox = (ComboBox)sender;
            int width = senderComboBox.DropDownWidth;
            Graphics g = senderComboBox.CreateGraphics();
            Font font = senderComboBox.Font;
            int vertScrollBarWidth =
                (senderComboBox.Items.Count > senderComboBox.MaxDropDownItems)
                ? SystemInformation.VerticalScrollBarWidth : 0;
            int newWidth;
            foreach (string s in ((ComboBox)sender).Items)
            {
                newWidth = (int)g.MeasureString(s, font).Width
                    + vertScrollBarWidth;


                if (width < newWidth)
                {
                    width = newWidth;
                }
            }
            senderComboBox.DropDownWidth = width;
        }

        private void cmbtenderCommitte_DropDown(object sender, EventArgs e)
        {
            ComboBox senderComboBox = (ComboBox)sender;
            int width = senderComboBox.DropDownWidth;
            Graphics g = senderComboBox.CreateGraphics();
            Font font = senderComboBox.Font;
            int vertScrollBarWidth =
                (senderComboBox.Items.Count > senderComboBox.MaxDropDownItems)
                ? SystemInformation.VerticalScrollBarWidth : 0;
            int newWidth;


            foreach (string s in ((ComboBox)sender).Items)
            {
                newWidth = (int)g.MeasureString(s, font).Width
                    + vertScrollBarWidth;


                if (width < newWidth)
                {
                    width = newWidth;
                }
            }
            senderComboBox.DropDownWidth = width;
        }

        private void cmbTypeofContract_DropDown(object sender, EventArgs e)
        {
            ComboBox senderComboBox = (ComboBox)sender;
            int width = senderComboBox.DropDownWidth;
            Graphics g = senderComboBox.CreateGraphics();
            Font font = senderComboBox.Font;
            int vertScrollBarWidth =
                (senderComboBox.Items.Count > senderComboBox.MaxDropDownItems)
                ? SystemInformation.VerticalScrollBarWidth : 0;
            int newWidth;


            foreach (string s in ((ComboBox)sender).Items)
            {
                newWidth = (int)g.MeasureString(s, font).Width
                    + vertScrollBarWidth;


                if (width < newWidth)
                {
                    width = newWidth;
                }
            }
            senderComboBox.DropDownWidth = width;
        }
        private void AutomaticUpdateStageID()
        {
            MessageBox.Show("Chk prjID");

            string sqlQuery = "SELECT date_id, proj_id, stage_id, ts_closing_s1, ts_closing_s2, ts_modified_closing " +
             " FROM TenderDatesInfo WHERE (stage_id = 3)";            //Check prjID *****************************************************************

            DataSet dsDocStat = new DataSet();
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                sqlConn.Open();
                using (SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn))
                {
                    SqlDataAdapter daDocStatus = new SqlDataAdapter(sqlCom);
                    daDocStatus.Fill(dsDocStat);
                }
                sqlConn.Close();
            }

            for (int i = 0; i < dsDocStat.Tables[0].Rows.Count; i++)
            {
                DateTime docDate = Convert.ToDateTime(dsDocStat.Tables[0].Rows[i][3]);
                if (docDate > System.DateTime.Now)
                {
                    int prjID = Convert.ToInt16(dsDocStat.Tables[0].Rows[i][1]);

                    string sqlQueryUpd = "UPDATE PROJECTS SET stage_id = 3 WHERE proj_id = " + prjID + "";

                    using (SqlConnection sqlConn = new SqlConnection(connStr))
                    {
                        sqlConn.Open();
                        using (SqlCommand sqlCom = new SqlCommand(sqlQueryUpd, sqlConn))
                        {
                            sqlCom.ExecuteNonQuery();
                        }
                        sqlConn.Close();
                    }
                }
            }
        }
        private void AutomaticUpdateDocumentStatus()
        {
            //  if Document issue date + days to act less than current date : make document status as For Follow Up

            string sqlQuery = "SELECT doc_issue_date + days_to_act AS DocDate, doc_status_id, doc_id, CURRENT_TIMESTAMP AS Todaydate " +
            " FROM DOCUMENTS ORDER BY doc_status_id Where doc_status_id = 1";

            DataSet dsDocStat = new DataSet();
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                sqlConn.Open();
                using (SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn))
                {
                    SqlDataAdapter daDocStatus = new SqlDataAdapter(sqlCom);
                    daDocStatus.Fill(dsDocStat);
                }
                sqlConn.Close();
            }

            for (int i = 0; i < dsDocStat.Tables[0].Rows.Count; i++)
            {
                DateTime docDate = Convert.ToDateTime(dsDocStat.Tables[0].Rows[i][0]);
                if (docDate > System.DateTime.Now)
                {
                    int docID = Convert.ToInt16(dsDocStat.Tables[0].Rows[i][0]);

                    string sqlQueryUpd = "UPDATE DOCUMENTS SET doc_status_id = 2 WHERE doc_id = " + docID + "";

                    using (SqlConnection sqlConn = new SqlConnection(connStr))
                    {
                        sqlConn.Open();
                        using (SqlCommand sqlCom = new SqlCommand(sqlQueryUpd, sqlConn))
                        {
                            sqlCom.ExecuteNonQuery();
                        }
                        sqlConn.Close();
                    }
                }
            }
        }

        
        private Boolean ChkProjectCodeExist()
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"SELECT project_code FROM PROJECTS Where project_code = '" + cmbPrjCode.Text + "'";
                        SqlDataReader dr = cmd.ExecuteReader();
                        if (dr.HasRows == false)
                        {
                            return false;
                        }
                        dr.Close();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while reading  existed projectCode, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            return true;
        }

        private void cmbTenderNo_Leave(object sender, EventArgs e)
        {
            filterCombo();
        }

        private void cmbUserDepart_Leave(object sender, EventArgs e)
        {
            filterCombo();
        }         

        private void cmbFiscalYear_SelectionChangeCommitted(object sender, EventArgs e)
        {
            filterCombo();
        }

        private void cmbTypeofContract_SelectionChangeCommitted(object sender, EventArgs e)
        {
            filterCombo();
        }

        private void cmbtenderCommitte_SelectionChangeCommitted(object sender, EventArgs e)
        {
            filterCombo();
        }

        private void cmbTypeOftender_SelectionChangeCommitted(object sender, EventArgs e)
        {
            filterCombo();
        }

        private void cmbTenderStatus_SelectionChangeCommitted(object sender, EventArgs e)
        {
            filterCombo();
        }

        private void cmbCurrentStage_SelectionChangeCommitted(object sender, EventArgs e)
        {
            filterCombo();
        }

        private void cmbTenderNo_SelectionChangeCommitted(object sender, EventArgs e)
        {
            filterCombo();
        }

        private void cmbPrjCode_SelectionChangeCommitted(object sender, EventArgs e)
        {
            filterCombo();
        }

        private void cmbUserDepart_SelectionChangeCommitted(object sender, EventArgs e)
        {
            filterCombo();
        }

        protected void cmbPrjCode_OnKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                filterCombo();
            }
        }

        protected void cmbTypeofContract_OnKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                filterCombo();
            }
        }

        protected void cmbFiscalYear_OnKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                filterCombo();
            }
        }

        protected void cmbtenderCommitte_OnKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                filterCombo();
            }
        }

        private void cmbUserDepart_OnKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                filterCombo();
            }
        }

        private void cmbTenderNo_OnKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                filterCombo();
            }
        }
        private void txtPrjTitle_OnKeyPress(object sender, KeyPressEventArgs e)
        {

        }
        private void cmbCurrentStage_OnKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                filterCombo();
            }
        }
        private void cmbTypeOftender_OnKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                filterCombo();
            }
        }

        private void cmbTenderStatus_OnKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                filterCombo();
            }
        }

        private void cmbUserDepart_SelectedIndexChanged(object sender, EventArgs e)
        {
            filterCombo();
        }

        private void cmbQs_SelectionChangeCommitted(object sender, EventArgs e)
        {
            filterCombo();
        }

        private void cmbTndrHndl_SelectionChangeCommitted(object sender, EventArgs e)
        {
            filterCombo();
        }

        private void cmbStaff_SelectionChangeCommitted(object sender, EventArgs e)
        {
            filterCombo();
        }

        private void cmbQs_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                filterCombo();
            }
        }
        private void cmbTndrHndl_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                filterCombo();
            }
        }
        private void cmbStaff_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                filterCombo();
            }
        }         

        //Added By Varun on 24/02/14 for creating pagination functionality
        private void tsbFirst_Click(object sender, EventArgs e)
        {
            try
            {
                if (id1 != 0)
                {
                    NavClicked = NavButton.First.ToString();                 
                    DeterminePageBoundaries();
                    FilterDataGrid();
                }
                else
                {
                    MessageBox.Show("No records found to traverse");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        //Added By Varun on 24/02/14 for creating pagination functionality
        private void tsbPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                if (id1 != 0)
                {
                    NavClicked = NavButton.Previous.ToString();                
                    DeterminePageBoundaries();
                    FilterDataGrid();
                }
                else
                {
                    MessageBox.Show("No records found to traverse");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        //Added By Varun on 24/02/14 for creating pagination functionality
        private void tsbNext_Click(object sender, EventArgs e)
        {
            try
            {
                if (id1 != 0)
                {
                    NavClicked = NavButton.Next.ToString();
                    DeterminePageBoundaries();
                    FilterDataGrid();
                }
                else
                {
                    MessageBox.Show("No records found to traverse");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        //Added By Varun on 24/02/14 for creating pagination functionality
        private void tsbLast_Click(object sender, EventArgs e)
        {
            try
            {
                if (id1 != 0)
                {
                    NavClicked = NavButton.Last.ToString();
                    DeterminePageBoundaries();
                    FilterDataGrid();
                }
                else
                {
                    MessageBox.Show("No records found to traverse");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

         
        private void cmbMozanahID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                filterCombo();
            }
        }

        private void cmbMozanahID_SelectionChangeCommitted(object sender, EventArgs e)
        {
            filterCombo();
        }

        private void cmbContractNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                filterCombo();
            }
        }

        private void cmbContractNo_SelectionChangeCommitted(object sender, EventArgs e)
        {
            filterCombo();
        }

        private void txtPrjTitle_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                filterCombo();
            }
        }

        private void btnExportToExcel_Click(object sender, EventArgs e)
        {
            try
            {
                if (userRightsColl.Contains("92"))    //      * Assign Tender No.
                {
                    MessageBox.Show("You have no privilege to export project details into excel sheet. Please Contact system administrator.");
                    return;
                }


                SaveFileDialog saveFileDialog1 = new SaveFileDialog();
                Microsoft.Office.Interop.Excel._Application app = null;
                Microsoft.Office.Interop.Excel._Workbook workbook = null;
                //if(!mIsWorkOrder)
                //{
                // commented by Varun on 08/Jun/15 saveFileDialog1.Filter = "Excel Path|*.xls|Excel Format|*.xlsx";

                saveFileDialog1.Filter = "Excel Path|*.xls|Excel Path|*.xlsx";
                saveFileDialog1.Title = "Save an Excel File";
                saveFileDialog1.ShowDialog();

                if (saveFileDialog1.FileName != "")
                {
                    // creating Excel Application
                    app = new Microsoft.Office.Interop.Excel.Application();

                    // creating new WorkBook within Excel application
                    workbook = app.Workbooks.Add(Type.Missing);

                    // creating new Excelsheet in workbook
                    Microsoft.Office.Interop.Excel._Worksheet worksheet = null;

                    // see the excel sheet behind the program
                    app.Visible = true;

                    // get the reference of first sheet. By default its name is Sheet1.
                    // store its reference to worksheet
                    worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Sheets["Sheet1"];
                    worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.ActiveSheet;

                    Microsoft.Office.Interop.Excel.Range formatRange = worksheet.UsedRange;
                    Microsoft.Office.Interop.Excel.Range formatA1CellRange = null;
                    Microsoft.Office.Interop.Excel.Range formatA1Cell = null;

                    formatA1CellRange = worksheet.get_Range("A1", "H1");
                    formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[1, 7];
                    formatA1CellRange.ColumnWidth = 150;
                    formatA1CellRange.Merge(true);

                    DataTable dtExportToExcel = null;
                    if (dtCmbTbl != null)
                    {
                        dtExportToExcel = dtCmbTbl;
                    }
                    else
                    {
                        dtExportToExcel = dtTemp;
                    }

                    if (dtCmbTbl != null)
                    {
                        formatA1CellRange.FormulaR1C1 = "PROJECT REPORT(" + dtExportToExcel.Rows[0]["TenderStatus"].ToString() + ")";
                    }
                    else
                    {
                        formatA1CellRange.FormulaR1C1 = "PROJECT REPORT";
                    }

                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(196, 215, 155));
                    formatA1CellRange.Font.Size = 18;

                    System.Drawing.Color color = Color.FromArgb(255, 204, 0);
                   
                    // storing header part in Excel
                    for (int i = 1; i <= 8; i++)
                    {
                        if (i == 1)
                        {
                            worksheet.Cells[3, 1] = "SNo.";
                            formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, i];
                            formatA1Cell.Font.Name = "Calibri";
                            formatA1Cell.Font.Size = "12";
                            formatA1Cell.Font.Bold = true;
                            formatA1Cell.WrapText = true;
                            formatA1Cell.ColumnWidth = 5;
                            formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                            formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                        }
                        else if (i == 2)
                        {
                            worksheet.Cells[3, 2] = dtExportToExcel.Columns["ProjectCode"].ColumnName; // Project Code == Columns[2]
                            formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, i];
                            formatA1Cell.Font.Name = "Calibri";
                            formatA1Cell.Font.Size = "12";
                            formatA1Cell.Font.Bold = true;
                            formatA1Cell.WrapText = true;
                            formatA1Cell.ColumnWidth = 20;
                            formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                            formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                        }
                        else if (i == 3)
                        {
                            worksheet.Cells[3, 3] = dtExportToExcel.Columns["ProjectTitle"].ColumnName; // Project Title == Columns[3]
                            formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, i];
                            formatA1Cell.Font.Name = "Calibri";
                            formatA1Cell.Font.Size = "12";
                            formatA1Cell.Font.Bold = true;
                            formatA1Cell.WrapText = true;
                            formatA1Cell.ColumnWidth = 40;
                            formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                            formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                        }
                        else if (i == 4)
                        {
                            worksheet.Cells[3, 4] = dtExportToExcel.Columns["TenderNo"].ColumnName; // Tender No. == Columns[4]
                            formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, i];
                            formatA1Cell.Font.Name = "Calibri";
                            formatA1Cell.Font.Size = "12";
                            formatA1Cell.Font.Bold = true;
                            formatA1Cell.WrapText = true;
                            formatA1Cell.ColumnWidth = 20;
                            formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                            formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                        }
                        else if (i == 5)
                        {
                            worksheet.Cells[3, 5] = dtExportToExcel.Columns["TenderCommittee"].ColumnName; // Tender Committee == Columns[5]
                            formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, i];
                            formatA1Cell.Font.Name = "Calibri";
                            formatA1Cell.Font.Size = "12";
                            formatA1Cell.Font.Bold = true;
                            formatA1Cell.WrapText = true;
                            formatA1Cell.ColumnWidth = 20;
                            formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                            formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                        }
                        else if (i == 6)
                        {
                            worksheet.Cells[3, 6] = dtExportToExcel.Columns["UserDepartment"].ColumnName; // Department Name == Columns[11]
                            formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, i];
                            formatA1Cell.Font.Name = "Calibri";
                            formatA1Cell.Font.Size = "12";
                            formatA1Cell.Font.Bold = true;
                            formatA1Cell.WrapText = true;
                            formatA1Cell.ColumnWidth = 40;
                            formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                            formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                        }
                        else if (i == 7)
                        {
                            worksheet.Cells[3, 7] = dtExportToExcel.Columns["TenderStatus"].ColumnName; // Status == Columns[6]
                            formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, i];
                            formatA1Cell.Font.Name = "Calibri";
                            formatA1Cell.Font.Size = "12";
                            formatA1Cell.Font.Bold = true;
                            formatA1Cell.WrapText = true;
                            formatA1Cell.ColumnWidth = 20;
                            formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                            formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                        }
                        else if (i == 8)
                        {
                            worksheet.Cells[3, 8] = dtExportToExcel.Columns["FiscalYear"].ColumnName; // Fiscal Year == Columns[10]
                            formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, i];
                            formatA1Cell.Font.Name = "Calibri";
                            formatA1Cell.Font.Size = "12";
                            formatA1Cell.Font.Bold = true;
                            formatA1Cell.WrapText = true;
                            formatA1Cell.ColumnWidth = 20;
                            formatA1Cell.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
                            formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                            //formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                            formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                        }
                    }

                    // storing Each row and column value to excel sheet
                    for (int i = 0; i < dtExportToExcel.Rows.Count; i++)
                    {

                        for (int asciiCode = 65; asciiCode <= 72; asciiCode++)
                        {
                            char alphaBet = (char)asciiCode;
                            worksheet.get_Range(alphaBet + (i + 5).ToString(), alphaBet + (i + 5).ToString()).Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeLeft].Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
                            worksheet.get_Range(alphaBet + (i + 5).ToString(), alphaBet + (i + 5).ToString()).Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeLeft].Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
                            worksheet.get_Range(alphaBet + (i + 5).ToString(), alphaBet + (i + 5).ToString()).Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeTop].Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
                            worksheet.get_Range(alphaBet + (i + 5).ToString(), alphaBet + (i + 5).ToString()).RowHeight = 45;
                            worksheet.get_Range(alphaBet + (i + 5).ToString(), alphaBet + (i + 5).ToString()).Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeRight].Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
                            worksheet.get_Range(alphaBet + (i + 5).ToString(), alphaBet + (i + 5).ToString()).Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeBottom].Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
                            worksheet.get_Range(alphaBet + (i + 5).ToString(), alphaBet + (i + 5).ToString()).Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeBottom].Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
                            worksheet.get_Range(alphaBet + (i + 5).ToString(), alphaBet + (i + 5).ToString()).Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeBottom].Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
                            worksheet.get_Range(alphaBet + (i + 5).ToString(), alphaBet + (i + 5).ToString()).Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeBottom].Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
                        }

                        worksheet.Cells[i + 5, 1] = i + 1;

                        worksheet.Cells[i + 5, 2] = dtExportToExcel.Rows[i]["ProjectCode"].ToString();

                        worksheet.Cells[i + 5, 3] = dtExportToExcel.Rows[i]["ProjectTitle"].ToString();

                        worksheet.Cells[i + 5, 4] = dtExportToExcel.Rows[i]["TenderNo"].ToString();

                        worksheet.Cells[i + 5, 5] = dtExportToExcel.Rows[i]["TenderCommittee"].ToString();

                        worksheet.Cells[i + 5, 6] = dtExportToExcel.Rows[i]["UserDepartment"].ToString();

                        worksheet.Cells[i + 5, 7] = dtExportToExcel.Rows[i]["TenderStatus"].ToString();

                        worksheet.Cells[i + 5, 8] = dtExportToExcel.Rows[i]["FiscalYear"].ToString();
                         
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while creating the excel file", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                                    
            }
        }
        
    }
    
}
