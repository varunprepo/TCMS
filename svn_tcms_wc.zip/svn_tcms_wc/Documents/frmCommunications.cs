﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using DataGridViewAutoFilter;

namespace MDI_ParenrForm.Documents
{
    public partial class frmCommunications : Form
    {
        protected SqlConnection sqlConn;
        protected SqlCommand sqlCom;
        protected SqlDataReader sqlReader;
        protected DataTable dtTemp = null;
       

        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();
        IList<string> userRightsColl = new List<string>();
        string _userName = string.Empty;
        bool _isHeadOfSection = false;
        string mCommitteeShortName = string.Empty;
        string mAffairShortName = "";
        CommonClass comCls = null;
        public frmCommunications(IList<string> userRightsCollComm,string user)
        {
            InitializeComponent();
            userRightsColl = userRightsCollComm;             
            FillCommunicationData();            
            _userName = user;           
        }

        public frmCommunications(IList<string> userRightsCollComm, string user, string formName, bool isHeadOfSection)
        {
            InitializeComponent();
            userRightsColl = userRightsCollComm;             
            FillCommunicationData();            
            _userName = user;
            _isHeadOfSection = isHeadOfSection;
            if (formName.Equals("dashBoardParent"))
            { 
                this.FormBorderStyle = FormBorderStyle.FixedSingle;                
                btnClose.Visible = false;                
            }
        }

        Int16 id1 = 1;
        Int16 id2 = 0;
        private string NavClicked = "";
        int CurrentPage = 1;
        DataTable dtFilteredRecords = null;         
        #region DeterminePageBoundaries
        // This method will determine the correct
        // Page Boundaries for the RecordID's to filter by
        private void DeterminePageBoundaries()
        {
            int totalRowCount = 0;
            if (dtCmbTbl != null && isRefresh == false)
            {
                totalRowCount = dtCmbTbl.Rows.Count;
                dtTemp = dtCmbTbl;
            }
            else
            {
                totalRowCount = finalDt.Rows.Count;
                dtTemp = finalDt;
            }
            
            
            //else
            //    totalRowCount = dtTemp.Rows.Count;
            //This is the maximum rows to display on a page.
            //So we want paging to be implemented at 100 rows a page                          
            int pageRows = 24;
            int pages = 0;

            //If the rows per page are less than
            //the total row count do the following:
            if (pageRows < totalRowCount)
            {
                //If the Modulus returns > 0 then there should be another page.
                if ((totalRowCount % pageRows) > 0)
                {
                    pages = ((totalRowCount / pageRows) + 1);
                }
                else
                {
                    //There is nothing left after the Modulus,
                    //so the pageRows divide exactly...
                    //...into TotalRowCount leaving no rest,
                    //thus no extra page needs to be added.
                    pages = totalRowCount / pageRows;
                }
            }
            else
            {
                //If the rows per page are more than the total
                //row count, we will obviously only ever have 1 page
                pages = 1;
            }

            //Added By Varun on 24/02/14 for creating pagination functionality
            //We now need to determine the LowerBoundary
            //and UpperBoundary in order to correctly...
            //...determine the Correct RecordID's
            //to use in the bindingSource1.Filter property.
            int LowerBoundary = 0;
            int UpperBoundary = 0;

            //We now need to know what button was clicked,
            //if any (First, Last, Next, Previous)
            switch (NavClicked)
            {
                case "First":
                    //First clicked, the Current Page will always be 1
                    CurrentPage = 1;
                    //The LowerBoundary will thus be ((50 * 1) - (50 - 1)) = 1
                    LowerBoundary = ((pageRows * CurrentPage) - (pageRows - 1));

                    //If the rows per page are less than
                    //the total row count do the following:
                    if (pageRows < totalRowCount)
                    {
                        UpperBoundary = (pageRows * CurrentPage);
                    }
                    else
                    {
                        //If the rows per page are more than
                        //the total row count do the following:
                        //There is only one page, so get
                        //the total row count as an UpperBoundary
                        UpperBoundary = totalRowCount;
                    }

                    //Now using these boundaries, get the
                    //appropriate RecordID's (min & max)...
                    //...for this specific page.
                    //Remember, .NET is 0 based, so subtract 1 from both boundaries
                    id1 = Convert.ToInt16(dtTemp.Rows[LowerBoundary - 1]["ID"]);
                    id2 = Convert.ToInt16(dtTemp.Rows[UpperBoundary - 1]["ID"]);

                    break;

                case "Last":
                    //Last clicked, the CurrentPage will always be = to the variable pages
                    CurrentPage = pages;
                    LowerBoundary = ((pageRows * CurrentPage) - (pageRows - 1));
                    //The UpperBoundary will always be the sum total of all the rows
                    UpperBoundary = totalRowCount;

                    //Now using these boundaries, get the appropriate
                    //RecordID's (min & max)...
                    //...for this specific page.
                    //Remember, .NET is 0 based, so subtract 1 from both boundaries
                    id1 = Convert.ToInt16(dtTemp.Rows[LowerBoundary - 1]["ID"]);
                    id2 = Convert.ToInt16(dtTemp.Rows[UpperBoundary - 1]["ID"]);

                    break;

                case "Next":
                    //Next clicked
                    if (CurrentPage != pages)
                    {
                        //If we arent on the last page already, add another page
                        CurrentPage += 1;
                    }

                    LowerBoundary = ((pageRows * CurrentPage) - (pageRows - 1));

                    if (CurrentPage == pages)
                    {
                        //If we are on the last page, the UpperBougndary
                        //will always be the sum total of all the rows
                        UpperBoundary = totalRowCount;
                    }
                    else
                    {
                        //Else if we have a pageRow of 50 and we are
                        //on page 3, the UpperBoundary = 150
                        UpperBoundary = (pageRows * CurrentPage);
                    }

                    //Now using these boundaries, get the appropriate
                    //RecordID's (min & max)...
                    //...for this specific page.
                    //Remember, .NET is 0 based, so subtract 1 from both boundaries

                    id1 = Convert.ToInt16(dtTemp.Rows[LowerBoundary - 1]["ID"]);
                    id2 = Convert.ToInt16(dtTemp.Rows[UpperBoundary - 1]["ID"]);

                    break;

                case "Previous":
                    //Previous clicked
                    if (CurrentPage != 1)
                    {
                        //If we aren't on the first page already,
                        //subtract 1 from the CurrentPage
                        CurrentPage -= 1;
                    }
                    //Get the LowerBoundary
                    LowerBoundary = ((pageRows * CurrentPage) - (pageRows - 1));

                    if (pageRows < totalRowCount)
                    {
                        UpperBoundary = (pageRows * CurrentPage);
                    }
                    else
                    {
                        UpperBoundary = totalRowCount;
                    }

                    //Now using these boundaries,
                    //get the appropriate RecordID's (min & max)...
                    //...for this specific page.
                    //Remember, .NET is 0 based, so subtract 1 from both boundaries
                    id1 = Convert.ToInt16(dtTemp.Rows[LowerBoundary - 1]["ID"]);
                    id2 = Convert.ToInt16(dtTemp.Rows[UpperBoundary - 1]["ID"]);

                    break;

                default:
                    //No button was clicked.
                    LowerBoundary = ((pageRows * CurrentPage) - (pageRows - 1));

                    //If the rows per page are less than
                    //the total row count do the following:
                    if (pageRows < totalRowCount)
                    {
                        UpperBoundary = (pageRows * CurrentPage);
                    }
                    else
                    {
                        //If the rows per page are more than
                        //the total row count do the following:
                        //Therefore there is only one page,
                        //so get the total row count as an UpperBoundary
                        UpperBoundary = totalRowCount;
                    }

                    //Now using these boundaries, get the
                    //appropriate RecordID's (min & max)...
                    //...for this specific page.
                    //Remember, .NET is 0 based, so subtract 1 from both boundaries
                    id1 = Convert.ToInt16(dtTemp.Rows[LowerBoundary - 1]["ID"]);
                    id2 = Convert.ToInt16(dtTemp.Rows[UpperBoundary - 1]["ID"]);

                    break;
            }

        }
        #endregion

        private enum NavButton
        {
            First = 1,
            Next = 2,
            Previous = 3,
            Last = 4,
        }

        private void tsbFirst_Click(object sender, EventArgs e)
        {
            try
            {
                NavClicked = NavButton.First.ToString();
                DeterminePageBoundaries();
                fillCombo(); 
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        //Added By Varun on 24/02/14 for creating pagination functionality
        private void tsbPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                NavClicked = NavButton.Previous.ToString();
                DeterminePageBoundaries();
                fillCombo();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        //Added By Varun on 24/02/14 for creating pagination functionality
        private void tsbNext_Click(object sender, EventArgs e)
        {
            try
            {
                NavClicked = NavButton.Next.ToString();
                DeterminePageBoundaries();
                fillCombo();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        //Added By Varun on 24/02/14 for creating pagination functionality
        private void tsbLast_Click(object sender, EventArgs e)
        {
            try
            {
                NavClicked = NavButton.Last.ToString();
                DeterminePageBoundaries();
                fillCombo();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        DataTable finalDt = new DataTable("DocCommunication");
        BindingSource myBindingSource = null;
        private void FillCommunicationData()
        {
            try
            {

                if (dtFilteredRecords == null && finalDt.Columns.Count == 0 )
                {
                    Cursor = Cursors.WaitCursor;
                    var col0 = new DataGridViewTextBoxColumn();
                    var col1 = new DataGridViewLinkColumn();
                    var col2 = new DataGridViewTextBoxColumn();
                    var col3 = new DataGridViewTextBoxColumn();
                    var col4 = new DataGridViewAutoFilterTextBoxColumn();
                    var col5 = new DataGridViewAutoFilterTextBoxColumn();
                    var col6 = new DataGridViewLinkColumn();
                    var col7 = new DataGridViewAutoFilterTextBoxColumn();
                    var col8 = new DataGridViewAutoFilterTextBoxColumn();
                    var col9 = new DataGridViewAutoFilterTextBoxColumn();
                    var col10 = new DataGridViewAutoFilterTextBoxColumn();
                    var col11 = new DataGridViewTextBoxColumn();
                    var col12 = new DataGridViewTextBoxColumn();
                    var col13 = new DataGridViewTextBoxColumn();

                    dgViewComm.Columns.AddRange(new DataGridViewColumn[] { col0, col1, col2, col3, col4, col5, col6, col7, col8, col9, col10, col11, col12, col13 });
                    dgViewComm.AutoGenerateColumns = false;
                    dgViewComm.AllowUserToAddRows = false;

                    col0.DataPropertyName = "DocID";
                    col0.HeaderText = "DocID";
                    col0.Resizable = System.Windows.Forms.DataGridViewTriState.True;

                    col1.DataPropertyName = "FileName";
                    col1.HeaderText = "File Name";
                    col1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
                    col1.LinkBehavior = LinkBehavior.HoverUnderline;
                    col2.Width = 70;

                    col2.DataPropertyName = "Subject";
                    col2.HeaderText = "Subject";
                    col2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
                    col2.Width = 110;

                    col3.DataPropertyName = "ReferenceNo";
                    col3.HeaderText = "Reference No";
                    col3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
                    col3.Width = 110;

                    col4.DataPropertyName = "CrossRefNo";
                    col4.HeaderText = "Cross ReferenceNo";
                    col4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
                    col4.Width = 110;

                    col5.DataPropertyName = "Status";
                    col5.HeaderText = "Status";
                    col5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
                    col5.Width = 50;

                    col6.DataPropertyName = "ProjectCode";
                    col6.HeaderText = "Project Code";
                    col6.Resizable = System.Windows.Forms.DataGridViewTriState.True;
                    col6.Width = 120;
                    col6.LinkBehavior = LinkBehavior.HoverUnderline;

                    col7.DataPropertyName = "TenderCommitte";
                    col7.HeaderText = "Tender Committee";
                    col7.Resizable = System.Windows.Forms.DataGridViewTriState.True;
                    col7.CellTemplate.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
                    col7.Width = 65;

                    col8.DataPropertyName = "TenderStage";
                    col8.HeaderText = "Stage";
                    col8.Resizable = System.Windows.Forms.DataGridViewTriState.True;
                    col8.Width = 80;

                    col9.DataPropertyName = "DocCategory";
                    col9.HeaderText = "Received /Sent";
                    col9.Resizable = System.Windows.Forms.DataGridViewTriState.True;

                    col10.DataPropertyName = "PrjID";
                    col10.HeaderText = "PrjID";
                    col10.Resizable = System.Windows.Forms.DataGridViewTriState.True;

                    col11.DataPropertyName = "stgID";
                    col11.HeaderText = "stgID";
                    col11.Resizable = System.Windows.Forms.DataGridViewTriState.True;

                    col12.DataPropertyName = "CircularNo";
                    col12.HeaderText = "CircularNo";
                    col12.Resizable = System.Windows.Forms.DataGridViewTriState.True;

                    col13.DataPropertyName = "ID";
                    col13.HeaderText = "ID";
                    col13.Width = 5;


                    finalDt.Columns.Add("DocID");
                    finalDt.Columns.Add("FileName");
                    finalDt.Columns.Add("Subject");
                    finalDt.Columns.Add("ReferenceNo");
                    finalDt.Columns.Add("CrossRefNo");
                    finalDt.Columns.Add("Status");

                    finalDt.Columns.Add("ProjectCode");
                    finalDt.Columns.Add("TenderCommitte");
                    finalDt.Columns.Add("TenderStage");
                    finalDt.Columns.Add("DocCategory");
                    finalDt.Columns.Add("PrjID");
                    finalDt.Columns.Add("stgID");
                    finalDt.Columns.Add("CircularNo");
                    finalDt.Columns.Add("ID", typeof(Int16));
                    finalDt.AcceptChanges();
                }
                if (isDocOpen != true && isRefresh == true)
                {
                    finalDt.Rows.Clear();

                    short rowId = 1;
                    sqlConn = new SqlConnection(strCon);
                    sqlConn.Open();

                    StringBuilder sqlBuildQuery = new StringBuilder();

                    sqlBuildQuery.Append("SELECT DOCUMENTS.doc_ID,DOCUMENTS.attFileName AS FileName, DOCUMENTS.subject AS Subject, DOCUMENTS.ref_no AS RefNo, DOCUMENTS.cross_ref_no AS [Cross Ref No], " +
                    " [DocumentStatus].doc_status_name AS [Document Status], PROJECTS.project_code AS [Project Code], Committee.committee_short_name AS Committe, " +
                    " STAGES.Stage_Name AS [Stage Type], [DocumentCategory].doc_category_name AS [Document Cat], Department.department_short_name AS Department,DOCUMENTS.Proj_ID,DOCUMENTS.stage_id,DOCUMENTS.CircularNo" +
                    " FROM DOCUMENTS INNER JOIN [DocumentStatus] ON DOCUMENTS.doc_status_id = [DocumentStatus].doc_status_id INNER JOIN PROJECTS ON DOCUMENTS.proj_id = PROJECTS.proj_id INNER JOIN " +
                    " Committee ON PROJECTS.committee_id = Committee.committee_id INNER JOIN STAGES ON DOCUMENTS.stage_id = STAGES.stage_id INNER JOIN " +
                    " [DocumentCategory] ON DOCUMENTS.doc_category_id = [DocumentCategory].doc_category_id INNER JOIN Department ON PROJECTS.department_id = Department.department_id INNER JOIN AFFAIRS " +
                    " ON AFFAIRS.Affair_id = PROJECTS.Affair_id WHERE (DOCUMENTS.date_id IS NULL) ");

                    comCls = new CommonClass(_userName);
                    mCommitteeShortName = comCls.checkAccessRightsForCommittee(userRightsColl, mCommitteeShortName);
                    mAffairShortName = comCls.checkAccessRightsForAffairs(userRightsColl, mAffairShortName);

                    // Modified and Added by Varun on 10 Feb 2014 for checking the committee and affairs selection
                    if (mCommitteeShortName == "All" && mAffairShortName == "All")
                    {
                        sqlBuildQuery.Append("ORDER BY PROJECTS.dummyfield DESC");
                    }
                    else
                        sqlBuildQuery = comCls.SetFilteredQuery(sqlBuildQuery, mCommitteeShortName, mAffairShortName, "ORDER BY PROJECTS.dummyfield DESC");

                    sqlCom = new SqlCommand(sqlBuildQuery.ToString(), sqlConn);
                    sqlReader = sqlCom.ExecuteReader();

                    while (sqlReader.Read())
                    {
                        DataRow dr = finalDt.NewRow();

                        dr[0] = sqlReader[0];   //Employee_Name
                        dr[1] = sqlReader[1];   //Employee_Name
                        dr[2] = sqlReader[2];   //Emp_Intial                  
                        dr[3] = sqlReader[3];   //Emp_Telephone_No
                        dr[4] = sqlReader[4];   //Emp_Fax_No
                        dr[5] = sqlReader[5];   //Email_Address
                        dr[6] = sqlReader[6];   //Co_Name
                        dr[7] = sqlReader[7];
                        dr[8] = sqlReader[8];    //Employee_No
                        dr[9] = sqlReader[9];
                        dr[10] = sqlReader[11];
                        dr[11] = sqlReader[12];
                        dr[12] = sqlReader[13];
                        dr[13] = rowId;
                        finalDt.Rows.Add(dr);
                        finalDt.AcceptChanges();
                        rowId++;
                    }
                    sqlReader.Close();
                    if (isRefresh == true)
                        id1 = 1;

                    if (finalDt.Rows.Count >= 24)
                        id2 = 23;
                    else
                        id2 = Convert.ToInt16(finalDt.Rows[finalDt.Rows.Count - 1]["ID"]);
                    toolStripLabel1.Text = id1.ToString();
                    toolStripLabel2.Text = id2.ToString();
                    dtFilteredRecords = finalDt.Select("ID>=" + id1 + " and ID <= " + id2).CopyToDataTable(); //


                    myBindingSource = new BindingSource(dtFilteredRecords, null);
                    dgViewComm.DataSource = myBindingSource;
                    Cursor = Cursors.Default;

                    dgViewComm.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                    // dgView.EnableHeadersVisualStyles = false;

                    dgViewComm.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
                    dgViewComm.RowsDefaultCellStyle.WrapMode = DataGridViewTriState.True;
                    dgViewComm.RowsDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                    dgViewComm.ReadOnly = true;


                    dgViewComm.Columns[0].Visible = false;
                    dgViewComm.Columns[10].Visible = false;
                    dgViewComm.Columns[11].Visible = false;
                    dgViewComm.Columns[12].Visible = false;
                    dgViewComm.Columns[13].Visible = false;
                    sqlConn.Close();
                    lblCnt2.Text = finalDt.Rows.Count.ToString();
                }
                else
                {
                    if(dtCmbTbl.Rows.Count !=0)
                        lblCnt2.Text = dtCmbTbl.Rows.Count.ToString();
                    else
                        lblCnt2.Text = finalDt.Rows.Count.ToString();
                }
                isDocOpen = false;
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
                //MessageBox.Show("Inside CommData. " + exMsg);
            }            
        }        
       
        //DataTable dtTempForCombo = null;
        DataTable dtCmbTbl = null;
        static bool isRefresh = true;
        private void FillDocCommunicationsInfo(string sqlFilterQuery)     //WHERE     (DOCUMENTS.subject LIKE '%stage%')
        {
            //dtTempForCombo = dtTemp;
            //int iCnt = dtTempForCombo.Rows.Count; 
          
            if (finalDt.Select(sqlFilterQuery).Length != 0)
            {
                Cursor = Cursors.WaitCursor;
                dtCmbTbl = finalDt.Select(sqlFilterQuery).CopyToDataTable();
                int jCnt = dtCmbTbl.Rows.Count;

                if (txtPrjCode.Text == "" && txtRefNo.Text == "" && txtSubject.Text == "")
                    sqlFilterQuery = "";

                if (sqlFilterQuery != "")
                {
                    isRefresh = false;
                    lblCnt2.Text = dtCmbTbl.Rows.Count.ToString();                   
                    dtFilteredRecords = dtCmbTbl;
                }
                else
                {
                    isRefresh = true;
                    lblCnt2.Text = finalDt.Rows.Count.ToString();
                    dtCmbTbl.Rows.Clear();
                    dtFilteredRecords = finalDt;
                }
                try
                {
                    if (isRefresh != true)
                    {
                        int rowCounter = 1;
                        foreach (DataRow dr in dtFilteredRecords.Rows)
                            dr["ID"] = rowCounter++;
                        dtFilteredRecords.AcceptChanges();
                    }
                    id1 = 1;
                    if (dtFilteredRecords.Rows.Count >= 24)
                        id2 = 23;
                    else
                        id2 = Convert.ToInt16(dtFilteredRecords.Rows[dtFilteredRecords.Rows.Count - 1]["ID"]);
                                      
                    toolStripLabel1.Text = id1.ToString();
                    toolStripLabel2.Text = id2.ToString();
                    dtFilteredRecords = dtFilteredRecords.Select("ID>=" + id1 + " and ID <= " + id2).CopyToDataTable();                     
                    myBindingSource = new BindingSource(dtFilteredRecords, null);
                    dgViewComm.DataSource = myBindingSource;
                    Cursor = Cursors.Default;
                    dgViewComm.EnableHeadersVisualStyles = false;
                }
                catch (Exception ex)
                {
                    string exMsg = ex.Message;
                }
                finally
                {
                }
            }
            else
            {
                DataTable nullTable = new DataTable();                
                BindingSource myBindingSource = new BindingSource(nullTable, null);
                dgViewComm.DataSource = myBindingSource;
                lblCnt2.Text = "0";                
            }           
        }
        private void dgView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }
        private void dgView_RowStateChanged(object sender, DataGridViewRowStateChangedEventArgs e)
        {
            //if (dtCmbTbl != null)
            //    lblCnt2.Text = dtCmbTbl.Rows.Count.ToString();
            //else
            //    lblCnt2.Text = finalDt.Rows.Count.ToString();
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            isRefresh = true;
            isDocOpen = false; 
            txtSubject.Text = "";
            txtRefNo.Text = "";
            txtPrjCode.Text = "";
            dtCmbTbl.Rows.Clear();
            FillCommunicationData();
            //loadDocumentCommunicationData();
        }
        private void loadDocumentCommunicationData()
        {
            BindingSource myBindingSource = null;
            try
            {
                DataTable finalDt = new DataTable("DocCommunication");
                finalDt.Columns.Add("DocID");
                finalDt.Columns.Add("FileName");
                finalDt.Columns.Add("Subject");
                finalDt.Columns.Add("ReferenceNo");
                finalDt.Columns.Add("CrossRefNo");
                finalDt.Columns.Add("Status");

                finalDt.Columns.Add("ProjectCode");
                finalDt.Columns.Add("TenderCommitte");
                finalDt.Columns.Add("TenderStage");
                finalDt.Columns.Add("DocCategory");
                finalDt.Columns.Add("PrjID");
                finalDt.Columns.Add("stgID");
                finalDt.Columns.Add("CircularNo");

                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();

                string sqlQuery = "SELECT DOCUMENTS.doc_ID,DOCUMENTS.attFileName AS FileName, DOCUMENTS.subject AS Subject, DOCUMENTS.ref_no AS RefNo, DOCUMENTS.cross_ref_no AS [Cross Ref No], " +
                " [DocumentStatus].doc_status_name AS [Document Status], PROJECTS.project_code AS [Project Code], Committee.committee_short_name AS Committe, " +
                " STAGES.Stage_Name AS [Stage Type], [DocumentCategory].doc_category_name AS [Document Cat], Department.department_short_name AS Department,DOCUMENTS.Proj_ID,DOCUMENTS.stage_id, DOCUMENTS.CircularNo " +
                " FROM DOCUMENTS INNER JOIN [DocumentStatus] ON DOCUMENTS.doc_status_id = [DocumentStatus].doc_status_id INNER JOIN PROJECTS ON DOCUMENTS.proj_id = PROJECTS.proj_id INNER JOIN " +
                " Committee ON PROJECTS.committee_id = Committee.committee_id INNER JOIN STAGES ON DOCUMENTS.stage_id = STAGES.stage_id INNER JOIN " +
                " [DocumentCategory] ON DOCUMENTS.doc_category_id = [DocumentCategory].doc_category_id INNER JOIN Department ON PROJECTS.department_id = Department.department_id WHERE (DOCUMENTS.date_id IS NULL) ORDER BY DOCUMENTS.doc_ID DESC";


                finalDt.AcceptChanges();
                sqlCom = new SqlCommand(sqlQuery, sqlConn);
                sqlReader = sqlCom.ExecuteReader();

                while (sqlReader.Read())
                {
                    DataRow dr = finalDt.NewRow();

                    dr[0] = sqlReader[0];   //Employee_Name
                    dr[1] = sqlReader[1];   //Employee_Name
                    dr[2] = sqlReader[2];   //Emp_Intial                  
                    dr[3] = sqlReader[3];   //Emp_Telephone_No
                    dr[4] = sqlReader[4];   //Emp_Fax_No
                    dr[5] = sqlReader[5];   //Email_Address
                    dr[6] = sqlReader[6];   //Co_Name
                    dr[7] = sqlReader[7];
                    dr[8] = sqlReader[8];    //Employee_No
                    dr[9] = sqlReader[9];
                    dr[10] = sqlReader[11];
                    dr[11] = sqlReader[12];
                    dr[12] = sqlReader[13];

                    finalDt.Rows.Add(dr);
                    finalDt.AcceptChanges();
                }
                sqlReader.Close();
                myBindingSource = new BindingSource(finalDt, null);
                dgViewComm.DataSource = myBindingSource;


                dtTemp = finalDt;  // Chk

                dgViewComm.Columns[0].Visible = false;
                dgViewComm.Columns[10].Visible = false;
                dgViewComm.Columns[11].Visible = false;
                dgViewComm.Columns[12].Visible = false;
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }

            lblCnt2.Text = dtTemp.Rows.Count.ToString();
        }
        bool isDocOpen = false;
        private void dgView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (userRightsColl.Contains("20"))    //   * View Document Details
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            if (e.ColumnIndex == 1)
            {
                string mnstryCode = string.Empty;
                string prvsnNo = string.Empty;
                string tendrStatus = string.Empty;
                string budgetRefNo = string.Empty;

                try
                {
                    string staticUserName = string.Empty;
                    if (dgViewComm.Rows[e.RowIndex].Cells[9].Value.ToString().Equals("Received"))
                    {
                        TenderTrackingSystem.ReceivedDocProperties frmRec = new TenderTrackingSystem.ReceivedDocProperties(userRightsColl,Convert.ToInt16(dgViewComm.Rows[e.RowIndex].Cells[0].Value), Convert.ToInt16(dgViewComm.Rows[e.RowIndex].Cells[10].Value), dgViewComm.Rows[e.RowIndex].Cells[9].Value.ToString(), Convert.ToInt16(dgViewComm.Rows[e.RowIndex].Cells[11].Value),_userName);
                        frmRec.StartPosition = FormStartPosition.CenterParent;
                        frmRec.ShowDialog();
                        isDocOpen = true;
                        FillCommunicationData();
                        //loadDocumentCommunicationData();
                    }
                    else if (dgViewComm.Rows[e.RowIndex].Cells[9].Value.ToString().Equals("Sent"))
                    {
                        TenderTrackingSystem.SentDocProperties frmSent = new TenderTrackingSystem.SentDocProperties(userRightsColl, Convert.ToInt16(dgViewComm.Rows[e.RowIndex].Cells[0].Value), Convert.ToInt16(dgViewComm.Rows[e.RowIndex].Cells[10].Value), 0, Convert.ToInt16(dgViewComm.Rows[e.RowIndex].Cells[11].Value), _userName, dgViewComm.Rows[e.RowIndex].Cells[12].Value);
                        frmSent.StartPosition = FormStartPosition.CenterParent;
                        frmSent.ShowDialog();
                        isDocOpen = true;
                        FillCommunicationData();
                        //loadDocumentCommunicationData();
                    }
                }
                catch (Exception ex)
                {
                }
                finally
                {                   
                }
            }
            if (e.ColumnIndex == 6)
            {
                try
                {
                    TenderTrackingSystem.ProjectStages projStg = new TenderTrackingSystem.ProjectStages(userRightsColl, "", Convert.ToInt16(dgViewComm.Rows[e.RowIndex].Cells[10].Value),null, _userName,null,_isHeadOfSection);
                    // ProjectStages projStg = new ProjectStages(Convert.ToInt16(dgView.Rows[e.RowIndex].Cells[0].Value));                 
                    projStg.StartPosition = FormStartPosition.CenterParent;
                    projStg.ShowDialog();
                }
                catch (Exception ex)
                {

                }
                finally
                {
                    sqlConn.Close();
                }
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void frmCommunications_Load(object sender, EventArgs e)
        {
          
        }

        private void txtSubject_KeyDown(object sender, KeyEventArgs e)
        {             
                fillCombo();            
        }

        private void txtSubject_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                fillCombo();
            }
        }

        private void txtRefNo_KeyDown(object sender, KeyEventArgs e)
        {            
                fillCombo();           
        }

        private void txtRefNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                fillCombo();
            }
        }

        private void txtPrjCode_KeyDown(object sender, KeyEventArgs e)
        {
            //if (e.KeyData == Keys.Down)            
                fillCombo();
        }

        private void txtPrjCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                fillCombo();
        }
        
        private void fillCombo()
        {
            string filterQuery = "";             
            if (txtSubject.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "Subject LIKE '" + "%" + txtSubject.Text + "%" + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "Subject LIKE '" + "%" + txtSubject.Text + "%" + "'";
                }
            }

            if (txtRefNo.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "ReferenceNo LIKE '" + "%" + txtRefNo.Text + "%" + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "ReferenceNo LIKE '" + "%" + txtRefNo.Text + "%" + "'";
                }
            }

            if (txtPrjCode.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "ProjectCode LIKE '" + "%" + txtPrjCode.Text + "%" + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "ProjectCode LIKE '" + "%" + txtPrjCode.Text + "%" + "'";
                }
            }

            if (filterQuery == "")
            {
                FillDocCommunicationsInfo("");
            }
            else
            {
                FillDocCommunicationsInfo(filterQuery);
            }  
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void NavigateRecords()
        {
            if (dtCmbTbl != null)
            {
                 if (dtCmbTbl.Rows.Count != 0)                    
                     dtFilteredRecords = dtCmbTbl;
                 else
                     dtFilteredRecords = finalDt;
            }
            else
                dtFilteredRecords = finalDt;
                     
            if (id1 == 1)
            {                   
                if (dtFilteredRecords.Rows.Count >= 24)
                    id2 = 23;
                else
                    id2 = Convert.ToInt16(dtFilteredRecords.Rows[dtFilteredRecords.Rows.Count - 1]["ID"]);                                        
            }
            toolStripLabel1.Text = id1.ToString();
            toolStripLabel2.Text = id2.ToString();
            dtFilteredRecords = dtFilteredRecords.Select("ID>=" + id1 + " and ID <= " + id2).CopyToDataTable();                 
            myBindingSource = new BindingSource(dtFilteredRecords, null);
            dgViewComm.DataSource = myBindingSource;             
            Cursor = Cursors.Default;
        }

        private void tsBtnNext_Click(object sender, EventArgs e)
        {
            try
            {
                NavClicked = NavButton.Next.ToString();
                DeterminePageBoundaries();
                NavigateRecords();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        private void tsBtnLast_Click(object sender, EventArgs e)
        {
            try
            {
                NavClicked = NavButton.Last.ToString();
                DeterminePageBoundaries();
                NavigateRecords();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        private void tsBtnFirst_Click(object sender, EventArgs e)
        {
            try
            {
                NavClicked = NavButton.First.ToString();
                DeterminePageBoundaries();
                NavigateRecords();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        private void tsBtnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                NavClicked = NavButton.Previous.ToString();
                DeterminePageBoundaries();
                NavigateRecords();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }
    }
}
