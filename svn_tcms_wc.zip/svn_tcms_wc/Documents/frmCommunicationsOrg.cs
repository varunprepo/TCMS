﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace MDI_ParenrForm.Documents
{
    public partial class frmCommunicationsOrg : Form
    {
        protected SqlConnection sqlConn;
        protected SqlCommand sqlCom;

        protected SqlDataReader sqlReader;
        private string strCon = ConfigurationSettings.AppSettings["strSqlConn"].ToString();
        public frmCommunicationsOrg()
        {
            InitializeComponent();
        }

        private void frmCommunications_Load(object sender, EventArgs e)
        {
            // var col0 = new DataGridViewCheckBoxColumn();
            var col1 = new DataGridViewLinkColumn();
            var col2 = new DataGridViewTextBoxColumn();
            var col3 = new DataGridViewTextBoxColumn();
            var col4 = new DataGridViewTextBoxColumn();
            var col5 = new DataGridViewTextBoxColumn();
            var col6 = new DataGridViewTextBoxColumn();
            var col7 = new DataGridViewTextBoxColumn();
            var col8 = new DataGridViewTextBoxColumn();
            var col9 = new DataGridViewTextBoxColumn();

            dgView.Columns.AddRange(new DataGridViewColumn[] { col1, col2, col3, col4, col5, col6, col7, col8, col9 });


            dgView.AutoGenerateColumns = false;
            dgView.AllowUserToAddRows = false;


            //dgView.AutoResizeColumns();

            //col0.Name = "chkBxSelect";
            //col0.DataPropertyName = "Select";
            //col0.HeaderText = "Select";
            //col0.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;

            col1.DataPropertyName = "Person Name";
            col1.HeaderText = "Person Name";
            col1.Resizable = System.Windows.Forms.DataGridViewTriState.True;

            col2.DataPropertyName = "Intial";
            col2.HeaderText = "Intial";
            col2.Resizable = System.Windows.Forms.DataGridViewTriState.True;

            col3.DataPropertyName = "Position";
            col3.HeaderText = "Position";
            col3.Resizable = System.Windows.Forms.DataGridViewTriState.True;

            col4.DataPropertyName = "Telephone No";
            col4.HeaderText = "Telephone No";
            col4.Resizable = System.Windows.Forms.DataGridViewTriState.True;

            col5.DataPropertyName = "Fax No";
            col5.HeaderText = "Fax No";
            col5.Resizable = System.Windows.Forms.DataGridViewTriState.True;

            col6.DataPropertyName = "Email";
            col6.HeaderText = "Email";
            col6.Resizable = System.Windows.Forms.DataGridViewTriState.True;

            col7.DataPropertyName = "Company Name";
            col7.HeaderText = "Company Name";
            col7.Resizable = System.Windows.Forms.DataGridViewTriState.True;

            col8.DataPropertyName = "Company Category";
            col8.HeaderText = "Company Category";
            col8.Resizable = System.Windows.Forms.DataGridViewTriState.True;

            col9.DataPropertyName = "EmpID";
            col9.HeaderText = "EmpID";
            col9.Resizable = System.Windows.Forms.DataGridViewTriState.True;

            BindingSource myBindingSource = null;
            try
            {
                DataTable finalDt = new DataTable("Company");
                finalDt.Columns.Add("Select");
                finalDt.Columns.Add("Person Name");
                finalDt.Columns.Add("Intial");
                finalDt.Columns.Add("Position");
                finalDt.Columns.Add("Telephone No");

                finalDt.Columns.Add("Fax No");
                finalDt.Columns.Add("Email");
                finalDt.Columns.Add("Company Name");
                finalDt.Columns.Add("Company Category");
                finalDt.Columns.Add("EmpID");

                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                // string sqlQuery = "SELECT EMPLOYEE.Employee_Name, EMPLOYEE.Position, EMPLOYEE.Emp_Telephone_No, EMPLOYEE.Emp_Fax_No, EMPLOYEE.Email_Address,EMPLOYEE.Authorized_Rep, EMPLOYEE.Dept_Id, EMPLOYEE.Section_Id, Company_Names.Co_Name AS CompanyName FROM EMPLOYEE INNER JOIN Company_Names ON EMPLOYEE.Company_Id = Company_Names.Co_Id";

                // string sqlQuery = "SELECT EMPLOYEE.Employee_Name,EMPLOYEE.Emp_Intial,EMPLOYEE.Position,EMPLOYEE.Emp_Telephone_No,EMPLOYEE.Emp_Fax_No,EMPLOYEE.Email_Address,EMPLOYEE.Authorized_Rep,EMPLOYEE.Dept_Id, EMPLOYEE.Section_Id, COMPANY.Co_Name,EMPLOYEE.EMPLOYEE_NO FROM EMPLOYEE INNER JOIN COMPANY ON EMPLOYEE.Company_Id = COMPANY.Co_Id";

                string sqlQuery = "SELECT EMPLOYEE.Employee_Name, EMPLOYEE.Emp_Intial, EMPLOYEE.Position, EMPLOYEE.Emp_Telephone_No, EMPLOYEE.Emp_Fax_No, EMPLOYEE.Email_Address,COMPANY.Co_Name, COMPANY_CAT.Co_Category_Name, EMPLOYEE.Employee_No FROM EMPLOYEE INNER JOIN COMPANY ON EMPLOYEE.Company_Id = COMPANY.Co_Id INNER JOIN COMPANY_CAT ON COMPANY.Co_Category_Id = COMPANY_CAT.Co_Category_Id";
                //string sqlQuery = "SELECT EMPLOYEE.Employee_Name,EMPLOYEE.Emp_Intial,EMPLOYEE.Position, EMPLOYEE.Emp_Telephone_No, EMPLOYEE.Emp_Fax_No, EMPLOYEE.Email_Address,EMPLOYEE.Authorized_Rep, EMPLOYEE.Dept_Id, EMPLOYEE.Section_Id,EMPLOYEE.Employee_No FROM EMPLOYEE";
                finalDt.AcceptChanges();
                sqlCom = new SqlCommand(sqlQuery, sqlConn);
                sqlReader = sqlCom.ExecuteReader();

                while (sqlReader.Read())
                {
                    DataRow dr = finalDt.NewRow();
                    dr[1] = sqlReader[0];   //Employee_Name
                    dr[2] = sqlReader[1];   //Emp_Intial
                    dr[3] = sqlReader[2];   //Position
                    dr[4] = sqlReader[3];   //Emp_Telephone_No
                    dr[5] = sqlReader[4];   //Emp_Fax_No
                    dr[6] = sqlReader[5];   //Email_Address
                    dr[7] = sqlReader[6];   //Co_Name
                    dr[8] = sqlReader[7];
                    dr[9] = sqlReader[8];    //Employee_No
                    finalDt.Rows.Add(dr);
                    finalDt.AcceptChanges();
                }
                sqlReader.Close();
                myBindingSource = new BindingSource(finalDt, null);
                dgView.DataSource = myBindingSource;
                dgView.Columns[9].Visible = false;
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }            
          
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            BindingSource myBindingSource = null;
            try
            {
                DataTable finalDt = new DataTable("Company");
                finalDt.Columns.Add("Select");
                finalDt.Columns.Add("Person Name");
                finalDt.Columns.Add("Intial");
                finalDt.Columns.Add("Position");
                finalDt.Columns.Add("Telephone No");

                finalDt.Columns.Add("Fax No");
                finalDt.Columns.Add("Email");
                finalDt.Columns.Add("Company Name");
                finalDt.Columns.Add("Company Category");
                finalDt.Columns.Add("EmpID");

                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                string sqlQuery = "SELECT EMPLOYEE.Employee_Name, EMPLOYEE.Emp_Intial, EMPLOYEE.Position, EMPLOYEE.Emp_Telephone_No, EMPLOYEE.Emp_Fax_No, EMPLOYEE.Email_Address,COMPANY.Co_Name, COMPANY_CAT.Co_Category_Name, EMPLOYEE.Employee_No FROM EMPLOYEE INNER JOIN COMPANY ON EMPLOYEE.Company_Id = COMPANY.Co_Id INNER JOIN COMPANY_CAT ON COMPANY.Co_Category_Id = COMPANY_CAT.Co_Category_Id WHERE Employee_Name = '" + txtContractNo.Text + "'";
                finalDt.AcceptChanges();
                sqlCom = new SqlCommand(sqlQuery, sqlConn);
                sqlReader = sqlCom.ExecuteReader();

                while (sqlReader.Read())
                {
                    DataRow dr = finalDt.NewRow();
                    dr[1] = sqlReader[0];   //Employee_Name
                    dr[2] = sqlReader[1];   //Emp_Intial
                    dr[3] = sqlReader[2];   //Position
                    dr[4] = sqlReader[3];   //Emp_Telephone_No
                    dr[5] = sqlReader[4];   //Emp_Fax_No
                    dr[6] = sqlReader[5];   //Email_Address
                    dr[7] = sqlReader[6];   //Co_Name
                    dr[8] = sqlReader[7];
                    dr[9] = sqlReader[8];    //Employee_No
                    finalDt.Rows.Add(dr);
                    finalDt.AcceptChanges();
                }
                sqlReader.Close();
                myBindingSource = new BindingSource(finalDt, null);
                dgView.DataSource = myBindingSource;
                dgView.Columns[9].Visible = false;
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }     
        }

        private void button1_Click(object sender, EventArgs e)
        {
            BindingSource myBindingSource = null;
            try
            {
                DataTable finalDt = new DataTable("Company");
                finalDt.Columns.Add("Select");
                finalDt.Columns.Add("Person Name");
                finalDt.Columns.Add("Intial");
                finalDt.Columns.Add("Position");
                finalDt.Columns.Add("Telephone No");

                finalDt.Columns.Add("Fax No");
                finalDt.Columns.Add("Email");
                finalDt.Columns.Add("Company Name");
                finalDt.Columns.Add("Company Category");
                finalDt.Columns.Add("EmpID");

                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                string sqlQuery = "SELECT EMPLOYEE.Employee_Name, EMPLOYEE.Emp_Intial, EMPLOYEE.Position, EMPLOYEE.Emp_Telephone_No, EMPLOYEE.Emp_Fax_No, EMPLOYEE.Email_Address,COMPANY.Co_Name, COMPANY_CAT.Co_Category_Name, EMPLOYEE.Employee_No FROM EMPLOYEE INNER JOIN COMPANY ON EMPLOYEE.Company_Id = COMPANY.Co_Id INNER JOIN COMPANY_CAT ON COMPANY.Co_Category_Id = COMPANY_CAT.Co_Category_Id";
                finalDt.AcceptChanges();
                sqlCom = new SqlCommand(sqlQuery, sqlConn);
                sqlReader = sqlCom.ExecuteReader();

                while (sqlReader.Read())
                {
                    DataRow dr = finalDt.NewRow();
                    dr[1] = sqlReader[0];   //Employee_Name
                    dr[2] = sqlReader[1];   //Emp_Intial
                    dr[3] = sqlReader[2];   //Position
                    dr[4] = sqlReader[3];   //Emp_Telephone_No
                    dr[5] = sqlReader[4];   //Emp_Fax_No
                    dr[6] = sqlReader[5];   //Email_Address
                    dr[7] = sqlReader[6];   //Co_Name
                    dr[8] = sqlReader[7];
                    dr[9] = sqlReader[8];    //Employee_No
                    finalDt.Rows.Add(dr);
                    finalDt.AcceptChanges();
                }
                sqlReader.Close();
                myBindingSource = new BindingSource(finalDt, null);
                dgView.DataSource = myBindingSource;
                dgView.Columns[9].Visible = false;
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }
        }
    }
}
