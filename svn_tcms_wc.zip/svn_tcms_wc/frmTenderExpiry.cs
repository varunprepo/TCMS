﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms; 
using System.Configuration;
using System.Data.SqlClient;
using MDI_ParenrForm.Admin;
using MDI_ParenrForm.Reports;
using TenderTrackingSystem;
using DataGridViewAutoFilter;
using System.IO;
using System.Text.RegularExpressions; 

namespace MDI_ParenrForm
{
    public partial class frmTenderExpiry : Form
    {         
        IList<string> userRightsColl = new List<string>();
        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();       
             
        BindingSource myBindingSource = null;
        DataTable dtTemp = null;
        DataTable dtTempForCombo = null;

        public static string _userName = string.Empty;

        DAL dataCls = new DAL();

        string mCommitteeShortName = "";
        string mAffairShortName = "";
        CommonClass comCls = null;
        bool _isHeadOfSection = false;
        public frmTenderExpiry(string userName,bool isHeadOfSection)
        {
            InitializeComponent();
            if (userName != "")
                _userName = userName;

            _isHeadOfSection = isHeadOfSection;
            userRightsColl = getUserAccessList();             
            comCls = new CommonClass(_userName);
            mCommitteeShortName = comCls.checkAccessRightsForCommittee(userRightsColl, mCommitteeShortName);
            mAffairShortName = comCls.checkAccessRightsForAffairs(userRightsColl, mAffairShortName);
            if (mAffairShortName == "")
            {
                MessageBox.Show("You do not have privilege for accessing any affairs, Contact administrator");
                return;
            }
            FillCombo();    
        }
        private void FillCombo()
        {
            DAL dalObj = new DAL();

            dalObj.populateCmbBox("SELECT DISTINCT PROJECTS.project_code FROM PROJECTS INNER JOIN TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id INNER JOIN " +
            "TenderDatesInfo ON PROJECTS.proj_id = TenderDatesInfo.proj_id WHERE (NOT (TenderStatus.Tender_Status_id IN (1,7,8, 9, 10,14,15))) AND (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.org_tender_to_expire < 20)"
            , cmbPrjCode);
            cmbPrjCode.SelectedIndex = -1;

            dalObj.populateCmbBox("SELECT DISTINCT PROJECTS.tender_no FROM PROJECTS INNER JOIN TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id INNER JOIN " +
            "TenderDatesInfo ON PROJECTS.proj_id = TenderDatesInfo.proj_id WHERE (NOT (TenderStatus.Tender_Status_id IN (1,7,8, 9, 10,14,15))) AND (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.org_tender_to_expire < 20) AND "+
            "(PROJECTS.tender_no IS NOT NULL)", cmbTenderNo);
            cmbTenderNo.SelectedIndex = -1;

            dalObj.populateCmbBox("select Stage_Name from STAGES", cmbCurrentStage);
            cmbCurrentStage.SelectedIndex = -1;

           // dalObj.populateCmbBox("SELECT [Status_Name], [TenderStatusShortName], Tender_Status_id FROM [TenderStatus] WHERE (Tender_Status_id = 8) OR (Tender_Status_id = 9) OR (Tender_Status_id = 10) ", cmbTenderStatus);
            dalObj.populateCmbBox("Select [Status_Name] From [TenderStatus] WHERE Tender_Status_id not in (1,7,8,9,10,14,15) Order by Tender_Status_id ", cmbTenderStatus);
            cmbTenderStatus.SelectedIndex = -1;

            dalObj.populateCmbBox("Select tender_type_name From [TenderTypes]", cmbTypeOftender);
            cmbTypeOftender.SelectedIndex = -1;

            dalObj.populateCmbBox("select [committee_short_name] from [Committee]", cmbtenderCommitte);
            cmbtenderCommitte.SelectedIndex = -1;

            dalObj.populateCmbBox("select [TypeofContract] from [ContractTypes]", cmbTypeofContract);
            cmbTypeofContract.SelectedIndex = -1;

            dalObj.populateCmbBox("Select [FiscalYear] From [FiscalYear]", cmbFiscalYear);  //Fiscal_Year
            cmbFiscalYear.SelectedIndex = -1;

            dalObj.populateCmbBox("Select Department From Department", cmbUserDepart);
            cmbUserDepart.SelectedIndex = -1;

        }
        private IList<string> getUserAccessList()
        {
            userRightsColl.Clear();
            SqlConnection sqlConn = new SqlConnection(strCon);
            string sqlQuery = "SELECT  UserAccessRights.AccessID,UserAccessRights.[AccessRights], UserPrivelege.HasPrivelege, UserPrivelege.user_profile_id, UserSecurityProfile.profile_name, USERS.user_id, " +
            " USERS.user_name FROM UserAccessRights INNER JOIN UserPrivelege ON UserAccessRights.AccessID = UserPrivelege.AccessID INNER JOIN " +
            " UserSecurityProfile ON UserPrivelege.user_profile_id = UserSecurityProfile.user_profile_id INNER JOIN " +
            " USERS ON UserSecurityProfile.user_profile_id = USERS.user_profile_id WHERE (UserPrivelege.HasPrivelege = 0) AND (USERS.user_name = '" + _userName + "') ORDER BY UserAccessRights.AccessID";

            try
            {
                sqlConn.Open();
                SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
                SqlDataReader sqlReader = sqlCom.ExecuteReader();
                while (sqlReader.Read())
                {
                    userRightsColl.Add(sqlReader[0].ToString());
                }
                sqlReader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error getting while reading data !" + ex.Message);
            }
            finally
            {
                sqlConn.Close();
            }
            return userRightsColl;
        }        

        private void frmTenderExpiry_Load(object sender, EventArgs e)
        {
            if (!userRightsColl.Contains("54"))
            {
                FillAllProjectsInformation();
            }
            else
            {
                //mCommitteeShortName = comCls.checkAccessRightsForCommittee(userRightsColl, mCommitteeShortName);
                FillAllProjectsInformation();
            }

            FillCombo(); 
        }
        // private void FillAllProjectsInformation(char chkInfo, string committesList)

        DataTable finalDt = new DataTable("Project");
        private void FillAllProjectsInformation()
        {
            
            //this.dgView.CellContentClick += new DataGridViewCellEventHandler(dgView_CellContentClick);

            var col0 = new DataGridViewTextBoxColumn();
            var col1 = new DataGridViewAutoFilterTextBoxColumn();
            var col2 = new DataGridViewLinkColumn();        // DataGridViewAutoFilterTextBoxColumn();

            var col3 = new DataGridViewTextBoxColumn();
            var col4 = new DataGridViewTextBoxColumn();
            var col5 = new DataGridViewTextBoxColumn();
            var col6 = new DataGridViewTextBoxColumn();
            var col7 = new DataGridViewTextBoxColumn();
            var col8 = new DataGridViewTextBoxColumn();
            var col9 = new DataGridViewTextBoxColumn();
            var col10 = new DataGridViewTextBoxColumn();
            var col11 = new DataGridViewTextBoxColumn();
            //var col12 = new DataGridViewTextBoxColumn();

            dgViewExpiryDays.Columns.AddRange(new DataGridViewColumn[] { col0, col1, col2, col3, col4, col5, col6, col7, col8, col9, col10, col11 });

            // dgView.Columns.AddRange(new DataGridViewColumn[] { col0, col1, col2, col3, col4, col5, col6, col7, col8, col9, col10, col11 });
            dgViewExpiryDays.AutoGenerateColumns = false;
            dgViewExpiryDays.AllowUserToAddRows = false;
            dgViewExpiryDays.AutoResizeColumns();

            col0.Name = "txtBoxExpiryDays";
            col0.DataPropertyName = "ExpiryDays";
            col0.HeaderText = "Days To Expire"; 
            col0.Width = 45;

            col1.DataPropertyName = "ProjectId";
            col1.HeaderText = "ProjectId";

            col2.DataPropertyName = "ProjectCode";
            col2.HeaderText = "Project Code";
            col2.Width = 145; //182 
            col2.LinkBehavior = LinkBehavior.NeverUnderline;

            col3.DataPropertyName = "ProjectTitle";
            col3.HeaderText = "ProjectTitle";
            col3.Width = 150; //182


            col4.DataPropertyName = "TenderNo";
            col4.HeaderText = "      TenderNo ";
            col4.Width = 141; //182

            col5.DataPropertyName = "CurrentStage";
            col5.HeaderText = "Current Stage";
            col5.Width = 85; //182

            col6.DataPropertyName = "TenderStatusFullName";
            col6.HeaderText = "Tender Status";
            col6.Width = 86;

            col7.DataPropertyName = "TypeOfTender";
            col7.HeaderText = "Tender Type";
            col7.Width = 76;

            col8.DataPropertyName = "TenderCommittee";
            col8.HeaderText = "Tender Committee";
            col8.Width = 70;


            col9.DataPropertyName = "TypeofContract";
            col9.HeaderText = "Contract Type";
            col9.Width = 80;

            col10.DataPropertyName = "FiscalYear";
            col10.HeaderText = "Fiscal Year";
            col10.Width = 56;

            col11.DataPropertyName = "UserDepartment";
            col11.HeaderText = "User Department";
            col11.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            //col11.ReadOnly = true;

            //col12.DataPropertyName = "TenderStatusFullName";
            //col12.HeaderText = "TenderStatusFullName";
            //col12.Resizable = System.Windows.Forms.DataGridViewTriState.True;             

            //col12.DataPropertyName = "ExpiryDays";
            //col12.HeaderText = "Expiry Days";
            //col12.Width = 56;

            DataTable dtProject = null;

            string[] projRows = new string[8];
            SqlConnection sqlConn = new SqlConnection(strCon);
            StringBuilder sqlBuildQuery = new StringBuilder();

            try
            {
                sqlConn.Open();
                DAL dalObj = new DAL(); //Dharan                 
                 
                sqlBuildQuery.Append("SELECT  PROJECTS.proj_id, PROJECTS.project_code, PROJECTS.project_newname_en, Committee.committee_short_name, STAGES.Stage_Name, " +
                " PROJECTS.tender_no, TenderTypes.tender_type_name, FiscalYear.FiscalYear, ContractTypes.TypeofContract, PROJECTS.SelectPrj, " +
                " Department.Department, TenderStatus.Status_Name, TenderStatus.TenderStatusShortName, Committee.committee_name, " +
                " TenderDatesInfo.org_tender_to_expire, TenderDatesInfo.stage_id FROM TenderDatesInfo INNER JOIN STAGES INNER JOIN TenderTypes INNER JOIN " +
                " ContractTypes INNER JOIN FiscalYear INNER JOIN Committee RIGHT OUTER JOIN AFFAIRS INNER JOIN " +
                " PROJECTS ON AFFAIRS.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON " +
                " FiscalYear.FYID = PROJECTS.FYID ON ContractTypes.contract_type_id = PROJECTS.contract_type_id ON " +
                " TenderTypes.tender_type_id = PROJECTS.tender_type_id INNER JOIN " +
                " Department ON PROJECTS.department_id = Department.department_id ON STAGES.stage_id = PROJECTS.stage_id ON " +
                " TenderDatesInfo.proj_id = PROJECTS.proj_id LEFT OUTER JOIN " +
                " TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id " +
                " WHERE (TenderStatus.Tender_Status_id not in (1,7,8,9,10,14,15)) AND " +
                " (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.org_tender_to_expire < 20) ");

                // Modified and Added by Varun on 10 Feb 2014 for checking the committee and affairs selection
                if (mCommitteeShortName == "All" && mAffairShortName == "All")
                {
                    sqlBuildQuery.Append("ORDER BY TenderDatesInfo.org_tender_to_expire DESC");
                }
                else
                    sqlBuildQuery = comCls.SetFilteredQuery(sqlBuildQuery, mCommitteeShortName, mAffairShortName,"ORDER BY TenderDatesInfo.org_tender_to_expire DESC");

                dtProject = dalObj.GetDataFromDB("Project", sqlBuildQuery.ToString());
               
                finalDt.Columns.Add("ExpiryDays");

                finalDt.Columns.Add("ProjectId");

                finalDt.Columns.Add("ProjectCode");
                finalDt.Columns.Add("ProjectTitle");

                finalDt.Columns.Add("TenderNo");
                finalDt.Columns.Add("CurrentStage");

                finalDt.Columns.Add("TenderStatusFullName");
                finalDt.Columns.Add("TypeOfTender");

                finalDt.Columns.Add("TenderCommittee");
                finalDt.Columns.Add("TypeofContract");

                finalDt.Columns.Add("FiscalYear");
                finalDt.Columns.Add("UserDepartment");
                //finalDt.Columns.Add("TenderStatusFullName"); 
               // finalDt.Columns.Add("ExpiryDays");

                finalDt.AcceptChanges();

                foreach (DataRow drProj in dtProject.Rows)
                {
                    DataRow dr = finalDt.NewRow();
                    string strProj = null;
                    strProj = drProj[0].ToString();

                    dr[1] = strProj;    //ProjectId
                    dr[2] = drProj[1];  //ProjectCode
                    dr[3] = drProj[2];  //ProjectTitle

                    dr[4] = drProj[5];  //TenderNo
                    dr[5] = drProj[4];  //CurrentStage


                    dr[6] = drProj[11];  //TenderStatus_ShortName
                    dr[7] = drProj[6];  //TypeOfTender

                    dr[8] = drProj[3];  //TenderCommittee
                    dr[9] = drProj[8];  //TypeofContract

                    dr[10] = drProj[7];  //FiscalYear
                    dr[11] = drProj[10];  //UserDepartment 
                    //dr[12] = drProj[11];  //TenderStatusFullName 
                     
                    dr[0] = drProj[14];  //ExpiryDays

                    finalDt.Rows.Add(dr);
                    finalDt.AcceptChanges();
                }

                myBindingSource = new BindingSource(finalDt, null);
                dgViewExpiryDays.DataSource = myBindingSource;
                dtTemp = finalDt;

                dtTempForCombo = finalDt;

                dgViewExpiryDays.ColumnHeadersDefaultCellStyle.BackColor = Color.Maroon;
                dgViewExpiryDays.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

                dgViewExpiryDays.ColumnHeadersDefaultCellStyle.Font = new Font(dgViewExpiryDays.Font, FontStyle.Bold);
                dgViewExpiryDays.EnableHeadersVisualStyles = false;
                dgViewExpiryDays.Columns[1].Visible = false;
                //dgViewExpiryDays.Columns[12].Visible = false;

                //dgViewExpiryDays.Columns[0].DefaultCellStyle.BackColor = Color.Maroon;
                //dgViewExpiryDays.Columns[0].DefaultCellStyle.ForeColor = Color.White;

                dgViewExpiryDays.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                dgViewExpiryDays.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgViewExpiryDays.Columns[6].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgViewExpiryDays.Columns[7].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgViewExpiryDays.Columns[8].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgViewExpiryDays.Columns[10].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                label1.Text = dgViewExpiryDays.Rows.Count.ToString();
              
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
           string _fileName = comCls.SelectTextFile("@C:");
           comCls.export_datagridview_to_excel(dgViewExpiryDays, _fileName);
        }              

        private void dgView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 2)
            {
                string mnstryCode = string.Empty;
                try
                {
                    ProjectStages projStg = new ProjectStages(userRightsColl, "", Convert.ToInt16(dgViewExpiryDays.Rows[e.RowIndex].Cells[1].Value), dgViewExpiryDays.Rows[e.RowIndex].Cells[8].Value.ToString(), _userName,null,_isHeadOfSection);
                    // ProjectStages projStg = new ProjectStages(Convert.ToInt16(dgView.Rows[e.RowIndex].Cells[0].Value));                 
                    projStg.StartPosition = FormStartPosition.CenterParent;
                    projStg.ShowDialog();

                    UpdateTimeInDummyField(Convert.ToInt16(dgViewExpiryDays.Rows[e.RowIndex].Cells[1].Value));
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
         private void UpdateTimeInDummyField(int ProjIDTime)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        cmd.CommandText = @"UPDATE PROJECTS SET dummyfield = @fieldForTime where proj_id=@prjID";
                        cmd.Parameters.AddWithValue("@fieldForTime", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@prjID", ProjIDTime);

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the TimeSpan, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
         
       

         private void txtPrjTitle_KeyDown(object sender, KeyEventArgs e)
         {
             //filterCombo();
         }        
         private void filterCombo()
         {
             string filterQuery = "";
            
             if (cmbPrjCode.SelectedIndex != -1)
             {
                 if (filterQuery == "")
                 {
                     filterQuery = "ProjectCode = '" + cmbPrjCode.SelectedItem.ToString().Trim() + "'";
                 }
                 else
                 {
                     filterQuery = filterQuery + " and " + "ProjectCode = '" + cmbPrjCode.SelectedItem.ToString() + "'";
                 }
             }
             else if (cmbPrjCode.Text != "")
             {
                 if (filterQuery == "")
                 {
                     filterQuery = "ProjectCode like '%" + cmbPrjCode.Text + "%'";
                 }
                 else
                 {
                     filterQuery = filterQuery + " and " + "ProjectCode like '%" + cmbPrjCode.Text + "%'";
                 }
             }
             if (txtPrjTitle.Text != "")
             {
                 if (filterQuery == "")
                 {
                     filterQuery = "ProjectTitle like '%" + txtPrjTitle.Text + "%'";
                 }
                 else
                 {
                     filterQuery = filterQuery + " and " + "ProjectTitle like '%" + txtPrjTitle.Text + "%'";
                 }
             }
             if (cmbTenderNo.SelectedIndex != -1)
             {
                 if (filterQuery == "")
                 {
                     filterQuery = "TenderNo = '" + cmbTenderNo.SelectedItem.ToString() + "'";
                 }
                 else
                 {
                     filterQuery = filterQuery + " and " + "TenderNo = '" + cmbTenderNo.SelectedItem.ToString() + "'";
                 }
             }
             else if (cmbTenderNo.Text != "")
             {
                 if (filterQuery == "")
                 {
                     filterQuery = "TenderNo like '%" + cmbTenderNo.Text + "%'";
                 }
                 else
                 {
                     filterQuery = filterQuery + " and " + "TenderNo like '%" + cmbTenderNo.Text + "%'";
                 }
             }
             if (cmbFiscalYear.SelectedIndex != -1)
             {
                 if (filterQuery == "")
                 {
                     filterQuery = "FiscalYear = '" + cmbFiscalYear.SelectedItem.ToString() + "'";
                 }
                 else
                 {
                     filterQuery = filterQuery + " and " + "FiscalYear = '" + cmbFiscalYear.SelectedItem.ToString() + "'";
                 }
             }
            
             if (cmbTypeofContract.SelectedIndex != -1)
             {
                 if (filterQuery == "")
                 {
                     filterQuery = "TypeofContract = '" + cmbTypeofContract.SelectedItem.ToString() + "'";
                 }
                 else
                 {
                     filterQuery = filterQuery + " and " + "TypeofContract = '" + cmbTypeofContract.SelectedItem.ToString() + "'";
                 }
             }
             
             if (cmbtenderCommitte.SelectedIndex != -1)
             {
                 if (filterQuery == "")
                 {
                     filterQuery = "TenderCommittee = '" + cmbtenderCommitte.SelectedItem.ToString() + "'";
                 }
                 else
                 {
                     filterQuery = filterQuery + " and " + "TenderCommittee = '" + cmbtenderCommitte.SelectedItem.ToString() + "'";
                 }

             }
            
             if (cmbTypeOftender.SelectedIndex != -1)
             {
                 if (filterQuery == "")
                 {
                     filterQuery = "TypeOfTender = '" + cmbTypeOftender.SelectedItem.ToString() + "'";
                 }
                 else
                 {
                     filterQuery = filterQuery + " and " + "TypeOfTender = '" + cmbTypeOftender.SelectedItem.ToString() + "'";
                 }
             }             
             if (cmbTenderStatus.SelectedIndex != -1)
             {
                 if (filterQuery == "")
                 {
                     filterQuery = "TenderStatusFullName = '" + cmbTenderStatus.SelectedItem.ToString() + "'";
                 }
                 else
                 {
                     filterQuery = filterQuery + " and " + "TenderStatusFullName = '" + cmbTenderStatus.SelectedItem.ToString() + "'";
                 }
             }
             
             //DataRowView cmbCurrentStageView = (DataRowView)cmbCurrentStage.SelectedItem;
             if (cmbCurrentStage.SelectedIndex != -1)
             {
                 if (filterQuery == "")
                 {
                     filterQuery = "CurrentStage = '" + cmbCurrentStage.SelectedItem.ToString() + "'";
                 }
                 else
                 {
                     filterQuery = filterQuery + " and " + "CurrentStage = '" + cmbCurrentStage.SelectedItem.ToString() + "'";
                 }
             }
             
          
             if (cmbUserDepart.SelectedIndex != -1)
             {
                 if (filterQuery == "")
                 {
                     filterQuery = "UserDepartment = '" + cmbUserDepart.SelectedValue + "'";
                 }
                 else
                 {
                     filterQuery = filterQuery + " and " + "UserDepartment = '" + cmbUserDepart.SelectedValue + "'";
                 }
             }
             

             if (filterQuery == "")
             {
                 GridFill("");
             }
             else
             {
                 GridFill(filterQuery);
             }
         }
         private void GridFill(string filterQuery)
         {
             dtTempForCombo = dtTemp;
             int iCnt = dtTempForCombo.Rows.Count;
             label1.Text = "0";
             DataTable dtCmbTbl = null;
             if (dtTempForCombo.Select(filterQuery).Length != 0)
             {
                 dtCmbTbl = dtTempForCombo.Select(filterQuery).CopyToDataTable();
                 int jCnt = dtCmbTbl.Rows.Count;
                 try
                 {
                     myBindingSource = new BindingSource(dtCmbTbl, null);
                     dgViewExpiryDays.DataSource = myBindingSource;

                     dtTempForCombo = dtCmbTbl;

  

                     dgViewExpiryDays.ColumnHeadersDefaultCellStyle.BackColor = Color.Maroon;
                     dgViewExpiryDays.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

                     //dgView.ColumnHeadersDefaultCellStyle.Font = new Font(dgView.Font, FontStyle.Bold);

                     dgViewExpiryDays.EnableHeadersVisualStyles = false;
                     dgViewExpiryDays.Columns[1].Visible = false;
                     label1.Text = dtTempForCombo.Rows.Count.ToString();
                 }
                 catch (Exception ex)
                 {
                     string exMsg = ex.Message;
                 }
                 finally
                 {
                 }
             }
             else
             {
                 DataTable nullTable = new DataTable();
                 dtCmbTbl = null;
                 myBindingSource = new BindingSource(nullTable, null);
                 dgViewExpiryDays.DataSource = myBindingSource;
             }
         }

         private void btnRefresh_Click(object sender, EventArgs e)
         {
             txtPrjTitle.Text = "";
             cmbPrjCode.Text = "";
             cmbTenderNo.Text = "";

             cmbPrjCode.SelectedIndex = -1;
             cmbTenderNo.SelectedIndex = -1;
             cmbCurrentStage.SelectedIndex = -1;
             cmbTenderStatus.SelectedIndex = -1;
             cmbTypeOftender.SelectedIndex = -1;
             cmbtenderCommitte.SelectedIndex = -1;
             cmbTypeofContract.SelectedIndex = -1;
             cmbFiscalYear.SelectedIndex = -1;
             cmbUserDepart.SelectedIndex = -1;            

             DataTable dtProject = null;
             string[] projRows = new string[8];
             SqlConnection sqlConn = new SqlConnection(strCon);


              


             try
             {
                 sqlConn.Open();
                 DAL dalObj = new DAL(); //Dharan

                 string sqlQuery = string.Empty;

                 if (mCommitteeShortName == "")

                     sqlQuery = "SELECT PROJECTS.proj_id,PROJECTS.project_code, PROJECTS.project_newname_en, PROJECTS.tender_no, STAGES.Stage_Name, TenderStatus.Status_Name," +
                     "TenderTypes.tender_type_name, Committee.committee_short_name, ContractTypes.TypeofContract, FiscalYear.FiscalYear, Department.Department" + " FROM [TenderStatus] RIGHT OUTER JOIN STAGES INNER JOIN [TenderTypes] INNER JOIN" +
                     " [ContractTypes] INNER JOIN [FiscalYear] INNER JOIN Committee RIGHT OUTER JOIN AFFAIRS INNER JOIN" +
                     " PROJECTS ON AFFAIRS.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON " +
                     " [FiscalYear].FYID = PROJECTS.FYID ON [ContractTypes].contract_type_id = PROJECTS.contract_type_id ON " +
                     " [TenderTypes].tender_type_id = PROJECTS.tender_type_id INNER JOIN Department ON PROJECTS.department_id = Department.department_id ON STAGES.stage_id = PROJECTS.stage_id ON [TenderStatus].Tender_Status_id = PROJECTS.Tender_Status_id " +
                     " WHERE (TenderStatus.Tender_Status_id IN (8, 9, 10)) " +
                     "  ORDER BY PROJECTS.dummyfield DESC";

                 else

                     sqlQuery = "SELECT PROJECTS.proj_id,PROJECTS.project_code, PROJECTS.project_newname_en, PROJECTS.tender_no, STAGES.Stage_Name, TenderStatus.Status_Name," +
              "TenderTypes.tender_type_name, Committee.committee_short_name, ContractTypes.TypeofContract, FiscalYear.FiscalYear,Department.Department" + " FROM [TenderStatus] RIGHT OUTER JOIN STAGES INNER JOIN [TenderTypes] INNER JOIN" +
              " [ContractTypes] INNER JOIN [FiscalYear] INNER JOIN Committee RIGHT OUTER JOIN AFFAIRS INNER JOIN" +
              " PROJECTS ON AFFAIRS.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON " +
              " [FiscalYear].FYID = PROJECTS.FYID ON [ContractTypes].contract_type_id = PROJECTS.contract_type_id ON " +
              " [TenderTypes].tender_type_id = PROJECTS.tender_type_id INNER JOIN Department ON PROJECTS.department_id = Department.department_id ON STAGES.stage_id = PROJECTS.stage_id ON [TenderStatus].Tender_Status_id = PROJECTS.Tender_Status_id " +
              " WHERE (TenderStatus.Tender_Status_id IN (8, 9, 10)) AND (Committee.committee_short_name IN (" + mCommitteeShortName + ")) " +
              " ORDER BY PROJECTS.dummyfield DESC";


                 //if (filterQuery != "")
                 //    sqlQuery = "SELECT  PROJECTS.proj_id, PROJECTS.project_code, PROJECTS.project_newname_en, Committee.committee_short_name, STAGES.Stage_Name, " +
                 //         " PROJECTS.tender_no, TenderTypes.tender_type_name, FiscalYear.FiscalYear, ContractTypes.TypeofContract, PROJECTS.SelectPrj, " +
                 //         " Department.Department, TenderStatus.Status_Name, TenderStatus.TenderStatusShortName, Committee.committee_name, " +
                 //         " TenderDatesInfo.org_tender_to_expire, TenderDatesInfo.stage_id FROM TenderDatesInfo INNER JOIN STAGES INNER JOIN TenderTypes INNER JOIN " +
                 //         " ContractTypes INNER JOIN FiscalYear INNER JOIN Committee RIGHT OUTER JOIN AFFAIRS INNER JOIN " +
                 //         " PROJECTS ON AFFAIRS.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON " +
                 //         " FiscalYear.FYID = PROJECTS.FYID ON ContractTypes.contract_type_id = PROJECTS.contract_type_id ON " +
                 //         " TenderTypes.tender_type_id = PROJECTS.tender_type_id INNER JOIN " +
                 //         " Department ON PROJECTS.department_id = Department.department_id ON STAGES.stage_id = PROJECTS.stage_id ON " +
                 //         " TenderDatesInfo.proj_id = PROJECTS.proj_id LEFT OUTER JOIN " +
                 //         " TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id " +
                 //         " WHERE (TenderStatus.Tender_Status_id not in (1,7,8,9,10,14,15)) AND " +
                 //         " (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.org_tender_to_expire < 20)AND (Committee.committee_short_name IN (" + committesList + ")) ORDER BY TenderDatesInfo.org_tender_to_expire DESC";

                 //else
                 //    sqlQuery = "SELECT  PROJECTS.proj_id, PROJECTS.project_code, PROJECTS.project_newname_en, Committee.committee_short_name, STAGES.Stage_Name, " +
                 //        " PROJECTS.tender_no, TenderTypes.tender_type_name, FiscalYear.FiscalYear, ContractTypes.TypeofContract, PROJECTS.SelectPrj, " +
                 //        " Department.Department, TenderStatus.Status_Name, TenderStatus.TenderStatusShortName, Committee.committee_name, " +
                 //        " TenderDatesInfo.org_tender_to_expire, TenderDatesInfo.stage_id FROM TenderDatesInfo INNER JOIN STAGES INNER JOIN TenderTypes INNER JOIN " +
                 //        " ContractTypes INNER JOIN FiscalYear INNER JOIN Committee RIGHT OUTER JOIN AFFAIRS INNER JOIN " +
                 //        " PROJECTS ON AFFAIRS.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON " +
                 //        " FiscalYear.FYID = PROJECTS.FYID ON ContractTypes.contract_type_id = PROJECTS.contract_type_id ON " +
                 //        " TenderTypes.tender_type_id = PROJECTS.tender_type_id INNER JOIN " +
                 //        " Department ON PROJECTS.department_id = Department.department_id ON STAGES.stage_id = PROJECTS.stage_id ON " +
                 //        " TenderDatesInfo.proj_id = PROJECTS.proj_id LEFT OUTER JOIN " +
                 //        " TenderStatus ON PROJECTS.Tender_Status_id = TenderStatus.Tender_Status_id " +
                 //        " WHERE (TenderStatus.Tender_Status_id not in (1,7,8,9,10,14,15)) AND " +
                 //        " (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.org_tender_to_expire < 20) ORDER BY TenderDatesInfo.org_tender_to_expire DESC";


                 dtProject = dalObj.GetDataFromDB("Project", sqlQuery);
                 DataTable finalDt = new DataTable("Project");
                 finalDt.Columns.Add("ExpiryDays");

                 finalDt.Columns.Add("ProjectId");

                 finalDt.Columns.Add("ProjectCode");
                 finalDt.Columns.Add("ProjectTitle");

                 finalDt.Columns.Add("TenderNo");
                 finalDt.Columns.Add("CurrentStage");

                 //finalDt.Columns.Add("TenderStatusShortName");
                 finalDt.Columns.Add("TenderStatusFullName");
                 finalDt.Columns.Add("TypeOfTender");

                 finalDt.Columns.Add("TenderCommittee");
                 finalDt.Columns.Add("TypeofContract");

                 finalDt.Columns.Add("FiscalYear");
                 finalDt.Columns.Add("UserDepartment");
                 //finalDt.Columns.Add("TenderStatusFullName");         
                 // finalDt.Columns.Add("ExpiryDays");

                 finalDt.AcceptChanges();

                 foreach (DataRow drProj in dtProject.Rows)
                 {
                     DataRow dr = finalDt.NewRow();
                     string strProj = null;
                     strProj = drProj[0].ToString();

                     dr[1] = strProj;    //ProjectId

                     dr[2] = drProj[1];  //ProjectCode
                     dr[3] = drProj[2];  //ProjectTitle

                     dr[4] = drProj[5];  //TenderNo
                     dr[5] = drProj[4];  //CurrentStage


                     dr[6] = drProj[11];  //TenderStatusShortName
                     dr[7] = drProj[6];  //TypeOfTender

                     dr[8] = drProj[3];  //TenderCommittee
                     dr[9] = drProj[8];  //TypeofContract

                     dr[10] = drProj[7];  //FiscalYear
                     dr[11] = drProj[10];  //UserDepartment 
                     //dr[12] = drProj[11];  //Tender_StatusFullName 
                     dr[0] = drProj[14];  //ExpiryDays

                     finalDt.Rows.Add(dr);
                     finalDt.AcceptChanges();
                 }

                 myBindingSource = new BindingSource(finalDt, null);
                 dgViewExpiryDays.DataSource = myBindingSource;
                 dtTemp = finalDt;

                 dtTempForCombo = finalDt;


                 dgViewExpiryDays.Columns[0].DefaultCellStyle.BackColor = Color.Maroon;
                 dgViewExpiryDays.Columns[0].DefaultCellStyle.ForeColor = Color.White;

                 dgViewExpiryDays.ColumnHeadersDefaultCellStyle.Font = new Font(dgViewExpiryDays.Font, FontStyle.Bold);
                 dgViewExpiryDays.EnableHeadersVisualStyles = false;
                 dgViewExpiryDays.Columns[1].Visible = false;
                 //dgViewExpiryDays.Columns[12].Visible = false;


                 dgViewExpiryDays.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                 dgViewExpiryDays.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                 dgViewExpiryDays.Columns[6].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                 dgViewExpiryDays.Columns[7].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                 dgViewExpiryDays.Columns[8].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                 dgViewExpiryDays.Columns[10].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                 label1.Text = dgViewExpiryDays.Rows.Count.ToString();

             }
             catch (Exception ex)
             {
                 string exMsg = ex.Message;
             }
             finally
             {
                 sqlConn.Close();
             }
         }

         string outTenderSubmissionDateAndTime = null;
         private void btnExportToPdf_Click(object sender, EventArgs e)
         {

             CommonClass comCls = new CommonClass(_userName);

             comCls.ExportToPDF(strCon, null, dgViewExpiryDays, null, null, null, null, 0, null, null, 0, null, null, null, 'Y', 'N', null, null, 0, null, 1, "", 1, null, false,false);           //ref outTenderSubmissionDateAndTime,

//=======
//             CommonClass comCls = new CommonClass(_userName);
//             comCls.ExportToPDF(strCon, null, dgViewExpiryDays, null, null, null, null, 0, null, null, 0, null, null, null, 'Y', 'N', null, null, 0, null, 1, "");
//>>>>>>> .r24
             //pending Work
         }
         private void button2_Click(object sender, EventArgs e)
         {
             //added by Varun                           
             CommonClass comCls = new CommonClass(_userName);


             string strFilePath = comCls.ExportToPDF(strCon, null, dgViewExpiryDays, null, null, null, null, 0, null, null, 0, null, null, null, 'Y', 'Y', null, null, 0, null, 1, "", 1, null, false,false);           //ref outTenderSubmissionDateAndTime,

//=======
//             string strFilePath = comCls.ExportToPDF(strCon, null, dgViewExpiryDays, null, null, null, null, 0, null, null, 0, null, null, null, 'Y', 'Y', null, null, 0, null, 1, "");
//>>>>>>> .r24
             //pending Work
             strFilePath = Regex.Replace(strFilePath, @"\\", @"/");                          
             comCls.CreateOutlookEmail(null, strFilePath,"Tender Bond Expiry");
         }
         private void cmbUserDepart_SelectionChangeCommitted(object sender, EventArgs e)
         {
             filterCombo();
         }
         private void cmbFiscalYear_SelectionChangeCommitted(object sender, EventArgs e)
         {
             filterCombo();
         }
         private void cmbTypeofContract_SelectionChangeCommitted(object sender, EventArgs e)
         {
             filterCombo();
         }
         private void cmbtenderCommitte_SelectionChangeCommitted(object sender, EventArgs e)
         {
             filterCombo();
         }
         private void cmbTypeOftender_SelectionChangeCommitted(object sender, EventArgs e)
         {
             filterCombo();
         }
         private void cmbTenderStatus_SelectionChangeCommitted(object sender, EventArgs e)
         {
             filterCombo();
         }
         private void cmbCurrentStage_SelectionChangeCommitted(object sender, EventArgs e)
         {
             filterCombo();
         }
         private void cmbTenderNo_SelectionChangeCommitted(object sender, EventArgs e)
         {
             filterCombo();
         }
         private void txtPrjTitle_KeyPress(object sender, KeyPressEventArgs e)
         {
             filterCombo();
         }
         private void cmbPrjCode_SelectionChangeCommitted(object sender, EventArgs e)
         {
             filterCombo();
         }
         private void cmbPrjCode_KeyDown(object sender, KeyEventArgs e)
         {
             filterCombo();
         }
         private void cmbPrjCode_KeyPress(object sender, KeyPressEventArgs e)
         {
             filterCombo();
         }
         private void cmbTenderNo_KeyDown(object sender, KeyEventArgs e)
         {
             filterCombo();
         }
         private void cmbTenderNo_KeyPress(object sender, KeyPressEventArgs e)
         {
             filterCombo();
         }

         private void button3_Click(object sender, EventArgs e)
         {
             txtPrjTitle.Text = "";
             cmbPrjCode.Text = "";
             cmbTenderNo.Text = "";

             cmbPrjCode.SelectedIndex = -1;
             cmbTenderNo.SelectedIndex = -1;
             cmbCurrentStage.SelectedIndex = -1;
             cmbTenderStatus.SelectedIndex = -1;
             cmbTypeOftender.SelectedIndex = -1;
             cmbtenderCommitte.SelectedIndex = -1;
             cmbTypeofContract.SelectedIndex = -1;
             cmbFiscalYear.SelectedIndex = -1;
             cmbUserDepart.SelectedIndex = -1;

             BindingSource myBindingSource = new BindingSource(finalDt, null);

             dgViewExpiryDays.DataSource = myBindingSource;     


             dgViewExpiryDays.Columns[0].DefaultCellStyle.BackColor = Color.Maroon;
             dgViewExpiryDays.Columns[0].DefaultCellStyle.ForeColor = Color.White;

             dgViewExpiryDays.ColumnHeadersDefaultCellStyle.Font = new Font(dgViewExpiryDays.Font, FontStyle.Bold);
             dgViewExpiryDays.EnableHeadersVisualStyles = false;
             dgViewExpiryDays.Columns[1].Visible = false;        


             dgViewExpiryDays.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

             dgViewExpiryDays.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
             dgViewExpiryDays.Columns[6].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
             dgViewExpiryDays.Columns[7].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
             dgViewExpiryDays.Columns[8].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
             dgViewExpiryDays.Columns[10].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

             label1.Text = dgViewExpiryDays.Rows.Count.ToString();
         }
    }
}
