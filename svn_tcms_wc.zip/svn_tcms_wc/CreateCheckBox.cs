﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using System.Data;
using System.Data.SqlClient;
using MDI_ParenrForm;
using System.Configuration;

namespace TenderTrackingSystem
{
    class CreateCheckBox
    {
        bool isHeaderCheckBoxClicked = false;
        bool isHeaderCheckBoxClicked1 = false;

        int TotalCheckBoxes = 1;
        int TotalCheckBoxes1 = 1;
        int TotalCheckedCheckBoxes = 0;
        int TotalCheckedCheckBoxes1 = 0;
        CheckBox headerCheckBox = null;
        CheckBox headerCheckBox2 = null;

        private DataGridView dgvObj = null;
        public CreateCheckBox(DataGridView dgv,CheckBox paramHeaderCheckBox)
        {
            dgvObj = dgv;
            headerCheckBox = paramHeaderCheckBox;
        }

        public CreateCheckBox(DataGridView dgv, CheckBox paramHeaderCheckBox, char secondChk)
        {
            dgvObj = dgv;
            headerCheckBox2 = paramHeaderCheckBox;
        }

        public void AddHeaderCheckBox()
        {

            headerCheckBox.Size = new Size(15, 15);            
            //Add the CheckBox into the DataGridView
            dgvObj.Controls.Add(headerCheckBox);
        }

        public void AddHeaderCheckBox2()
        {

            headerCheckBox2.Size = new Size(15, 15);

            //Add the CheckBox into the DataGridView
            dgvObj.Controls.Add(headerCheckBox2);
        }

        public void dgvSelectAll_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (e.RowIndex == -1 && e.ColumnIndex == 0)
                ResetHeaderCheckBoxLocation(e.ColumnIndex, e.RowIndex);
        }
        public void dgvSelectAll1_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (e.RowIndex == -1 && e.ColumnIndex == 0)
                ResetHeaderCheckBoxLocation2(e.ColumnIndex, e.RowIndex);
        }

        private void ResetHeaderCheckBoxLocation(int ColumnIndex, int RowIndex)
        {
            //Get the column header cell bounds
            Rectangle oRectangle = this.dgvObj.GetCellDisplayRectangle(ColumnIndex, RowIndex, true);

            Point oPoint = new Point();

            oPoint.X = oRectangle.Location.X + (oRectangle.Width - headerCheckBox.Width) / 2 + 1;
            oPoint.Y = oRectangle.Location.Y + (oRectangle.Height - headerCheckBox.Height) / 2 + 1;

            //Change the location of the CheckBox to make it stay on the header
            headerCheckBox.Location = oPoint;
        }

        private void ResetHeaderCheckBoxLocation2(int ColumnIndex, int RowIndex)
        {
            //Get the column header cell bounds
            Rectangle oRectangle = this.dgvObj.GetCellDisplayRectangle(ColumnIndex, RowIndex, true);

            Point oPoint = new Point();

            oPoint.X = oRectangle.Location.X + (oRectangle.Width - headerCheckBox2.Width) / 2 + 1;
            oPoint.Y = oRectangle.Location.Y + (oRectangle.Height - headerCheckBox2.Height) / 2 + 1;

            //Change the location of the CheckBox to make it stay on the header
            headerCheckBox2.Location = oPoint;
        }
        public void HeaderCheckBox_MouseClick(object sender, MouseEventArgs e)
        {
            HeaderCheckBoxClick((CheckBox)sender);
        }

        public void HeaderCheckBox1_MouseClick(object sender, MouseEventArgs e)
        {
            HeaderCheckBoxClick1((CheckBox)sender);
        }

        public void HeaderCheckBox_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
                HeaderCheckBoxClick((CheckBox)sender);
        }

        public void HeaderCheckBox1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
                HeaderCheckBoxClick1((CheckBox)sender);
        }

        public void dgvSelectAll_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (!isHeaderCheckBoxClicked)
                RowCheckBoxClick((DataGridViewCheckBoxCell)dgvObj[0, e.RowIndex]);
        }

        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();
        public void dgvSelectAll1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (!isHeaderCheckBoxClicked1)
            {         
                RowCheckBoxClick1((DataGridViewCheckBoxCell)dgvObj[0, e.RowIndex]);
            }
        }                

        public void dgvSelectAll_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            if (dgvObj.Columns[e.ColumnIndex].Name == "chkBxSelect1")
            {
                for (int i = 0; i < dgvObj.RowCount - 1; i++)
                {
                    if (i != e.RowIndex)
                        dgvObj.Rows[i].DataGridView[0, i].Value = false;
                }         
            }
            else if (dgvObj.Columns[e.ColumnIndex].Name == "chkBxSelect")
            {
                for (int i = 0; i < dgvObj.RowCount - 1; i++)
                {
                    if (i != e.RowIndex)
                        dgvObj.Rows[i].DataGridView[0, i].Value = false;
                }
            }
        }        

        public void dgvSelectAll_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {
            if (dgvObj.CurrentCell is DataGridViewCheckBoxCell)
                dgvObj.CommitEdit(DataGridViewDataErrorContexts.Commit);
        }

        public void dgvSelectAll1_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {            
            if (dgvObj.CurrentCell is DataGridViewCheckBoxCell)
                dgvObj.CommitEdit(DataGridViewDataErrorContexts.Commit);
        } 
        
        private void HeaderCheckBoxClick(CheckBox HCheckBox1)
        {          
            isHeaderCheckBoxClicked = true;
            foreach (DataGridViewRow Row in dgvObj.Rows)
                ((DataGridViewCheckBoxCell)Row.Cells["chkBxSelect1"]).Value = HCheckBox1.Checked;

            dgvObj.RefreshEdit();
            TotalCheckedCheckBoxes = HCheckBox1.Checked ? TotalCheckBoxes : 0;            
        }

        private void HeaderCheckBoxClick1(CheckBox HCheckBox2)
        {
            isHeaderCheckBoxClicked1 = true;
            foreach (DataGridViewRow Row in dgvObj.Rows)
                ((DataGridViewCheckBoxCell)Row.Cells["chkBxSelect2"]).Value = HCheckBox2.Checked;

            dgvObj.RefreshEdit();
            TotalCheckedCheckBoxes1 = HCheckBox2.Checked ? TotalCheckBoxes1 : 0;
        }         

        public void RowCheckBoxClick(DataGridViewCheckBoxCell RCheckBox)
        {
            //Int32 rowCtr = 0;
            if (RCheckBox != null)
            {                         
                //HeaderCheckBox = new CheckBox();
                //Modifiy Counter;  
                if (isHeaderCheckBoxClicked == true)
                {
                    if (RCheckBox.Value != DBNull.Value)
                    {
                        if (Convert.ToBoolean(RCheckBox.Value) && TotalCheckedCheckBoxes < TotalCheckBoxes)
                            TotalCheckedCheckBoxes++;
                        else if (TotalCheckedCheckBoxes > 0)
                            TotalCheckedCheckBoxes--;
                    }
                    else
                        TotalCheckedCheckBoxes--;

                    //Change state of the header CheckBox.
                    if (TotalCheckedCheckBoxes < TotalCheckBoxes)
                        headerCheckBox.Checked = false;
                    else if (TotalCheckedCheckBoxes == TotalCheckBoxes)
                        headerCheckBox.Checked = true;
                }                
            }
        }

        public void RowCheckBoxClick1(DataGridViewCheckBoxCell RCheckBox)
        {

            //Int32 rowCtr = 0;
            if (RCheckBox != null)
            {
                //HeaderCheckBox = new CheckBox();
                //Modifiy Counter;  
                if (isHeaderCheckBoxClicked == true)
                {
                    if (RCheckBox.Value != DBNull.Value)
                    {
                        if (Convert.ToBoolean(RCheckBox.Value) && TotalCheckedCheckBoxes < TotalCheckBoxes)
                            TotalCheckedCheckBoxes++;
                        else if (TotalCheckedCheckBoxes > 0)
                            TotalCheckedCheckBoxes--;
                    }
                    else
                        TotalCheckedCheckBoxes--;

                    //Change state of the header CheckBox.
                    if (TotalCheckedCheckBoxes < TotalCheckBoxes)
                        headerCheckBox.Checked = false;
                    else if (TotalCheckedCheckBoxes == TotalCheckBoxes)
                        headerCheckBox.Checked = true;
                }
            }
        }
               
         

        public DataTable GetDataSource()
        {
            DataTable dTable = new DataTable();

            DataRow dRow = null;
            DateTime dTime;
            Random rnd = new Random();

            dTable.Columns.Add("IsChecked", System.Type.GetType("System.Boolean"));
            //dTable.Columns.Add("RandomNo");
            //dTable.Columns.Add("Date");
            //dTable.Columns.Add("Time");

            for (int n = 0; n < 10; ++n)
            {
                dRow = dTable.NewRow();
                dTime = DateTime.Now;

                dRow["IsChecked"] = "false";
                //dRow["RandomNo"] = rnd.NextDouble();
                //dRow["Date"] = dTime.ToString("dd/MMM/yyyy");
                //dRow["Time"] = dTime.ToString("hh:mm:ss tt");

                dTable.Rows.Add(dRow);
                dTable.AcceptChanges();
            }

            return dTable;
        }

    }
}
