﻿namespace TenderTrackingSystem
{
    partial class OngoingTenders
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgView = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmbUserDepart = new System.Windows.Forms.ComboBox();
            this.lblUserDept = new System.Windows.Forms.Label();
            this.cmbtenderCommitte = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.cmbTenderNo = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtPrjTitle = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbFiscalYear = new System.Windows.Forms.ComboBox();
            this.cmbTypeofContract = new System.Windows.Forms.ComboBox();
            this.cmbTypeOftender = new System.Windows.Forms.ComboBox();
            this.cmbTenderStatus = new System.Windows.Forms.ComboBox();
            this.cmbCurrentStage = new System.Windows.Forms.ComboBox();
            this.cmbPrjCode = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblCnt = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnEditArchieve = new System.Windows.Forms.Button();
            this.btnDeleteArchieve = new System.Windows.Forms.Button();
            this.lblStaff = new System.Windows.Forms.Label();
            this.lblCp = new System.Windows.Forms.Label();
            this.cmbStaff = new System.Windows.Forms.ComboBox();
            this.lblTndr = new System.Windows.Forms.Label();
            this.cmbTndrHndl = new System.Windows.Forms.ComboBox();
            this.lblQS = new System.Windows.Forms.Label();
            this.cmbQs = new System.Windows.Forms.ComboBox();
            this.btnExportToExcel = new System.Windows.Forms.Button();
            this.btnExportToPdf = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgView)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgView
            // 
            this.dgView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dgView.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(236)))), ((int)(((byte)(236)))));
            this.dgView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.HotPink;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dgView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgView.DefaultCellStyle = dataGridViewCellStyle11;
            this.dgView.GridColor = System.Drawing.Color.Olive;
            this.dgView.Location = new System.Drawing.Point(4, 205);
            this.dgView.Name = "dgView";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgView.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dgView.RowHeadersVisible = false;
            this.dgView.Size = new System.Drawing.Size(1112, 557);
            this.dgView.TabIndex = 2;
            this.dgView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgView_CellContentClick_1);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cmbUserDepart);
            this.groupBox1.Controls.Add(this.lblUserDept);
            this.groupBox1.Controls.Add(this.cmbtenderCommitte);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.cmbTenderNo);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txtPrjTitle);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.cmbFiscalYear);
            this.groupBox1.Controls.Add(this.cmbTypeofContract);
            this.groupBox1.Controls.Add(this.cmbTypeOftender);
            this.groupBox1.Controls.Add(this.cmbTenderStatus);
            this.groupBox1.Controls.Add(this.cmbCurrentStage);
            this.groupBox1.Controls.Add(this.cmbPrjCode);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(4, 68);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1112, 81);
            this.groupBox1.TabIndex = 26;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Search Project Details";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // cmbUserDepart
            // 
            this.cmbUserDepart.FormattingEnabled = true;
            this.cmbUserDepart.Location = new System.Drawing.Point(1021, 46);
            this.cmbUserDepart.Name = "cmbUserDepart";
            this.cmbUserDepart.Size = new System.Drawing.Size(75, 23);
            this.cmbUserDepart.TabIndex = 45;
            this.cmbUserDepart.SelectionChangeCommitted += new System.EventHandler(this.cmbUserDepart_SelectionChangeCommitted);
            // 
            // lblUserDept
            // 
            this.lblUserDept.AutoSize = true;
            this.lblUserDept.Location = new System.Drawing.Point(1021, 27);
            this.lblUserDept.Name = "lblUserDept";
            this.lblUserDept.Size = new System.Drawing.Size(75, 15);
            this.lblUserDept.TabIndex = 44;
            this.lblUserDept.Text = "Deptartment";
            // 
            // cmbtenderCommitte
            // 
            this.cmbtenderCommitte.FormattingEnabled = true;
            this.cmbtenderCommitte.Location = new System.Drawing.Point(749, 45);
            this.cmbtenderCommitte.Name = "cmbtenderCommitte";
            this.cmbtenderCommitte.Size = new System.Drawing.Size(77, 23);
            this.cmbtenderCommitte.TabIndex = 43;
            this.cmbtenderCommitte.SelectionChangeCommitted += new System.EventHandler(this.cmbtenderCommitte_SelectionChangeCommitted);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label12.Location = new System.Drawing.Point(749, 24);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(60, 15);
            this.label12.TabIndex = 42;
            this.label12.Text = "Committe";
            // 
            // cmbTenderNo
            // 
            this.cmbTenderNo.FormattingEnabled = true;
            this.cmbTenderNo.Location = new System.Drawing.Point(275, 45);
            this.cmbTenderNo.Name = "cmbTenderNo";
            this.cmbTenderNo.Size = new System.Drawing.Size(142, 23);
            this.cmbTenderNo.TabIndex = 39;
            this.cmbTenderNo.SelectionChangeCommitted += new System.EventHandler(this.cmbTenderNo_SelectionChangeCommitted);
            this.cmbTenderNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbTenderNo_KeyDown);
            this.cmbTenderNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbTenderNo_KeyPress);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label10.Location = new System.Drawing.Point(272, 21);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(62, 15);
            this.label10.TabIndex = 38;
            this.label10.Text = "TenderNo";
            // 
            // txtPrjTitle
            // 
            this.txtPrjTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrjTitle.Location = new System.Drawing.Point(162, 46);
            this.txtPrjTitle.Name = "txtPrjTitle";
            this.txtPrjTitle.Size = new System.Drawing.Size(109, 23);
            this.txtPrjTitle.TabIndex = 37;
            this.txtPrjTitle.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtPrjTitle_KeyDown);
            this.txtPrjTitle.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPrjTitle_KeyPress);
            this.txtPrjTitle.Leave += new System.EventHandler(this.txtPrjTitle_Leave);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label9.Location = new System.Drawing.Point(161, 21);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(68, 15);
            this.label9.TabIndex = 36;
            this.label9.Text = "ProjectTitle";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label8.Location = new System.Drawing.Point(9, 22);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 15);
            this.label8.TabIndex = 35;
            this.label8.Text = "ProjectCode";
            // 
            // cmbFiscalYear
            // 
            this.cmbFiscalYear.FormattingEnabled = true;
            this.cmbFiscalYear.Location = new System.Drawing.Point(946, 46);
            this.cmbFiscalYear.Name = "cmbFiscalYear";
            this.cmbFiscalYear.Size = new System.Drawing.Size(70, 23);
            this.cmbFiscalYear.TabIndex = 34;
            this.cmbFiscalYear.SelectionChangeCommitted += new System.EventHandler(this.cmbFiscalYear_SelectionChangeCommitted);
            // 
            // cmbTypeofContract
            // 
            this.cmbTypeofContract.FormattingEnabled = true;
            this.cmbTypeofContract.Location = new System.Drawing.Point(832, 45);
            this.cmbTypeofContract.Name = "cmbTypeofContract";
            this.cmbTypeofContract.Size = new System.Drawing.Size(108, 23);
            this.cmbTypeofContract.TabIndex = 33;
            this.cmbTypeofContract.SelectionChangeCommitted += new System.EventHandler(this.cmbTypeofContract_SelectionChangeCommitted);
            // 
            // cmbTypeOftender
            // 
            this.cmbTypeOftender.FormattingEnabled = true;
            this.cmbTypeOftender.Location = new System.Drawing.Point(663, 45);
            this.cmbTypeOftender.Name = "cmbTypeOftender";
            this.cmbTypeOftender.Size = new System.Drawing.Size(80, 23);
            this.cmbTypeOftender.TabIndex = 32;
            this.cmbTypeOftender.SelectionChangeCommitted += new System.EventHandler(this.cmbTypeOftender_SelectionChangeCommitted);
            // 
            // cmbTenderStatus
            // 
            this.cmbTenderStatus.FormattingEnabled = true;
            this.cmbTenderStatus.Location = new System.Drawing.Point(552, 46);
            this.cmbTenderStatus.Name = "cmbTenderStatus";
            this.cmbTenderStatus.Size = new System.Drawing.Size(109, 23);
            this.cmbTenderStatus.TabIndex = 31;
            this.cmbTenderStatus.SelectionChangeCommitted += new System.EventHandler(this.cmbTenderStatus_SelectionChangeCommitted);
            // 
            // cmbCurrentStage
            // 
            this.cmbCurrentStage.FormattingEnabled = true;
            this.cmbCurrentStage.Location = new System.Drawing.Point(423, 46);
            this.cmbCurrentStage.Name = "cmbCurrentStage";
            this.cmbCurrentStage.Size = new System.Drawing.Size(123, 23);
            this.cmbCurrentStage.TabIndex = 30;
            this.cmbCurrentStage.SelectionChangeCommitted += new System.EventHandler(this.cmbCurrentStage_SelectionChangeCommitted);
            // 
            // cmbPrjCode
            // 
            this.cmbPrjCode.FormattingEnabled = true;
            this.cmbPrjCode.Location = new System.Drawing.Point(9, 46);
            this.cmbPrjCode.Name = "cmbPrjCode";
            this.cmbPrjCode.Size = new System.Drawing.Size(150, 23);
            this.cmbPrjCode.TabIndex = 29;
            this.cmbPrjCode.SelectionChangeCommitted += new System.EventHandler(this.cmbPrjCode_SelectionChangeCommitted);
            this.cmbPrjCode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbPrjCode_KeyDown);
            this.cmbPrjCode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbPrjCode_OnKeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label7.Location = new System.Drawing.Point(420, 22);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 15);
            this.label7.TabIndex = 22;
            this.label7.Text = "Current Stage";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.Location = new System.Drawing.Point(943, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 15);
            this.label6.TabIndex = 27;
            this.label6.Text = "Fiscal Year";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label5.Location = new System.Drawing.Point(829, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 15);
            this.label5.TabIndex = 26;
            this.label5.Text = "Contract Type";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(661, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 15);
            this.label4.TabIndex = 25;
            this.label4.Text = "Tender Type";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(550, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 15);
            this.label3.TabIndex = 24;
            this.label3.Text = "Tender Status";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(185, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 15);
            this.label2.TabIndex = 23;
            // 
            // lblCnt
            // 
            this.lblCnt.AutoSize = true;
            this.lblCnt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblCnt.Location = new System.Drawing.Point(104, 771);
            this.lblCnt.Name = "lblCnt";
            this.lblCnt.Size = new System.Drawing.Size(41, 13);
            this.lblCnt.TabIndex = 44;
            this.lblCnt.Text = "label14";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label14.Location = new System.Drawing.Point(13, 771);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(85, 13);
            this.label14.TabIndex = 45;
            this.label14.Text = "Projects Count : ";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button1.Image = global::MDI_ParenrForm.Properties.Resources.Actions_window_close_icon;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(1050, 32);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(66, 30);
            this.button1.TabIndex = 29;
            this.button1.Text = "Close";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.BackColor = System.Drawing.Color.White;
            this.btnRefresh.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefresh.ForeColor = System.Drawing.Color.Coral;
            this.btnRefresh.Image = global::MDI_ParenrForm.Properties.Resources.Button_Reload_icon;
            this.btnRefresh.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRefresh.Location = new System.Drawing.Point(975, 32);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(75, 30);
            this.btnRefresh.TabIndex = 25;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = false;
            this.btnRefresh.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // btnEditArchieve
            // 
            this.btnEditArchieve.BackColor = System.Drawing.Color.Maroon;
            this.btnEditArchieve.ForeColor = System.Drawing.Color.White;
            this.btnEditArchieve.Image = global::MDI_ParenrForm.Properties.Resources.Text_Edit_icon__1_;
            this.btnEditArchieve.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEditArchieve.Location = new System.Drawing.Point(4, 32);
            this.btnEditArchieve.Name = "btnEditArchieve";
            this.btnEditArchieve.Size = new System.Drawing.Size(149, 30);
            this.btnEditArchieve.TabIndex = 46;
            this.btnEditArchieve.Text = "View/ Edit Project Details";
            this.btnEditArchieve.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEditArchieve.UseVisualStyleBackColor = false;
            this.btnEditArchieve.Click += new System.EventHandler(this.btnEditArchieve_Click);
            // 
            // btnDeleteArchieve
            // 
            this.btnDeleteArchieve.BackColor = System.Drawing.Color.Maroon;
            this.btnDeleteArchieve.ForeColor = System.Drawing.Color.White;
            this.btnDeleteArchieve.Image = global::MDI_ParenrForm.Properties.Resources.Actions_window_close_icon;
            this.btnDeleteArchieve.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDeleteArchieve.Location = new System.Drawing.Point(152, 32);
            this.btnDeleteArchieve.Name = "btnDeleteArchieve";
            this.btnDeleteArchieve.Size = new System.Drawing.Size(69, 30);
            this.btnDeleteArchieve.TabIndex = 47;
            this.btnDeleteArchieve.Text = "Delete";
            this.btnDeleteArchieve.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDeleteArchieve.UseVisualStyleBackColor = false;
            this.btnDeleteArchieve.Visible = false;
            this.btnDeleteArchieve.Click += new System.EventHandler(this.btnDeleteArchieve_Click);
            // 
            // lblStaff
            // 
            this.lblStaff.AutoSize = true;
            this.lblStaff.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStaff.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblStaff.Location = new System.Drawing.Point(241, 169);
            this.lblStaff.Name = "lblStaff";
            this.lblStaff.Size = new System.Drawing.Size(210, 15);
            this.lblStaff.TabIndex = 69;
            this.lblStaff.Text = "Filter Projects By Assigned Staff";
            // 
            // lblCp
            // 
            this.lblCp.AutoSize = true;
            this.lblCp.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblCp.Location = new System.Drawing.Point(638, 19);
            this.lblCp.Name = "lblCp";
            this.lblCp.Size = new System.Drawing.Size(93, 13);
            this.lblCp.TabIndex = 68;
            this.lblCp.Text = "Contracts Process";
            this.lblCp.Visible = false;
            // 
            // cmbStaff
            // 
            this.cmbStaff.FormattingEnabled = true;
            this.cmbStaff.Location = new System.Drawing.Point(641, 39);
            this.cmbStaff.Name = "cmbStaff";
            this.cmbStaff.Size = new System.Drawing.Size(106, 21);
            this.cmbStaff.TabIndex = 67;
            this.cmbStaff.Visible = false;
            this.cmbStaff.SelectionChangeCommitted += new System.EventHandler(this.cmbStaff_SelectionChangeCommitted);
            // 
            // lblTndr
            // 
            this.lblTndr.AutoSize = true;
            this.lblTndr.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblTndr.Location = new System.Drawing.Point(531, 21);
            this.lblTndr.Name = "lblTndr";
            this.lblTndr.Size = new System.Drawing.Size(74, 13);
            this.lblTndr.TabIndex = 66;
            this.lblTndr.Text = "Tender Issues";
            this.lblTndr.Visible = false;
            // 
            // cmbTndrHndl
            // 
            this.cmbTndrHndl.FormattingEnabled = true;
            this.cmbTndrHndl.Location = new System.Drawing.Point(531, 39);
            this.cmbTndrHndl.Name = "cmbTndrHndl";
            this.cmbTndrHndl.Size = new System.Drawing.Size(106, 21);
            this.cmbTndrHndl.TabIndex = 65;
            this.cmbTndrHndl.Visible = false;
            this.cmbTndrHndl.SelectionChangeCommitted += new System.EventHandler(this.cmbTndrHndl_SelectionChangeCommitted);
            // 
            // lblQS
            // 
            this.lblQS.AutoSize = true;
            this.lblQS.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQS.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblQS.Location = new System.Drawing.Point(460, 169);
            this.lblQS.Name = "lblQS";
            this.lblQS.Size = new System.Drawing.Size(86, 13);
            this.lblQS.TabIndex = 64;
            this.lblQS.Text = "Assighned QS";
            // 
            // cmbQs
            // 
            this.cmbQs.FormattingEnabled = true;
            this.cmbQs.Location = new System.Drawing.Point(566, 165);
            this.cmbQs.Name = "cmbQs";
            this.cmbQs.Size = new System.Drawing.Size(106, 21);
            this.cmbQs.TabIndex = 63;
            this.cmbQs.SelectionChangeCommitted += new System.EventHandler(this.cmbQs_SelectionChangeCommitted);
            // 
            // btnExportToExcel
            // 
            this.btnExportToExcel.Location = new System.Drawing.Point(783, 36);
            this.btnExportToExcel.Name = "btnExportToExcel";
            this.btnExportToExcel.Size = new System.Drawing.Size(95, 23);
            this.btnExportToExcel.TabIndex = 70;
            this.btnExportToExcel.Text = "Export To Excel";
            this.btnExportToExcel.UseVisualStyleBackColor = true;
            this.btnExportToExcel.Click += new System.EventHandler(this.btnExportToExcel_Click);
            // 
            // btnExportToPdf
            // 
            this.btnExportToPdf.Location = new System.Drawing.Point(884, 36);
            this.btnExportToPdf.Name = "btnExportToPdf";
            this.btnExportToPdf.Size = new System.Drawing.Size(85, 23);
            this.btnExportToPdf.TabIndex = 71;
            this.btnExportToPdf.Text = "Export To Pdf";
            this.btnExportToPdf.UseVisualStyleBackColor = true;
            this.btnExportToPdf.Click += new System.EventHandler(this.btnExportToPdf_Click);
            // 
            // OngoingTenders
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(236)))), ((int)(((byte)(236)))));
            this.ClientSize = new System.Drawing.Size(1150, 792);
            this.Controls.Add(this.btnExportToPdf);
            this.Controls.Add(this.btnExportToExcel);
            this.Controls.Add(this.lblStaff);
            this.Controls.Add(this.btnDeleteArchieve);
            this.Controls.Add(this.lblCp);
            this.Controls.Add(this.btnEditArchieve);
            this.Controls.Add(this.cmbStaff);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.lblTndr);
            this.Controls.Add(this.lblCnt);
            this.Controls.Add(this.cmbTndrHndl);
            this.Controls.Add(this.lblQS);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.cmbQs);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.dgView);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.HelpButton = true;
            this.Name = "OngoingTenders";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "On-going Tenders Details ";
            this.Load += new System.EventHandler(this.DefaultView_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgView)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgView;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbFiscalYear;
        private System.Windows.Forms.ComboBox cmbTypeofContract;
        private System.Windows.Forms.ComboBox cmbTypeOftender;
        private System.Windows.Forms.ComboBox cmbTenderStatus;
        private System.Windows.Forms.ComboBox cmbCurrentStage;
        private System.Windows.Forms.ComboBox cmbPrjCode;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPrjTitle;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cmbTenderNo;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cmbtenderCommitte;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblCnt;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox cmbUserDepart;
        private System.Windows.Forms.Label lblUserDept;
        private System.Windows.Forms.Button btnEditArchieve;
        private System.Windows.Forms.Button btnDeleteArchieve;
        private System.Windows.Forms.Label lblStaff;
        private System.Windows.Forms.Label lblCp;
        private System.Windows.Forms.ComboBox cmbStaff;
        private System.Windows.Forms.Label lblTndr;
        private System.Windows.Forms.ComboBox cmbTndrHndl;
        private System.Windows.Forms.Label lblQS;
        private System.Windows.Forms.ComboBox cmbQs;
        private System.Windows.Forms.Button btnExportToExcel;
        private System.Windows.Forms.Button btnExportToPdf;         
         
    }
}