﻿namespace MDI_ParenrForm.Projects
{
    partial class frmWorkOrderContractProcessDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblReqDeptStartDate = new System.Windows.Forms.Label();
            this.dtpReqDeptStartDate = new System.Windows.Forms.DateTimePicker();
            this.lblStartDateReceive = new System.Windows.Forms.Label();
            this.dtpStartDateReceive = new System.Windows.Forms.DateTimePicker();
            this.lblNoticeSendTendererSignContract = new System.Windows.Forms.Label();
            this.dtpNoticeSendSignContract = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.dtpDueDateOfSubPBSign = new System.Windows.Forms.DateTimePicker();
            this.lblDateOfSignContract = new System.Windows.Forms.Label();
            this.dtpDateOfSignContract = new System.Windows.Forms.DateTimePicker();
            this.lblSentDeptForSign = new System.Windows.Forms.Label();
            this.dtpSentDeptForSign = new System.Windows.Forms.DateTimePicker();
            this.lblRcvdDeptSentPRSDForSign = new System.Windows.Forms.Label();
            this.dtpRcvdDeptSentPRSDForSign = new System.Windows.Forms.DateTimePicker();
            this.lblSentFinanceDeptForCommittment = new System.Windows.Forms.Label();
            this.dtpSentFinanceDeptForCommittment = new System.Windows.Forms.DateTimePicker();
            this.lblRcvdFromFinanceDeptForCommittment = new System.Windows.Forms.Label();
            this.dtpRcvdFromFinanceDeptForCommittment = new System.Windows.Forms.DateTimePicker();
            this.lblDistribution = new System.Windows.Forms.Label();
            this.dtpDistribution = new System.Windows.Forms.DateTimePicker();
            this.lblContractNo = new System.Windows.Forms.Label();
            this.txtContractNo = new System.Windows.Forms.TextBox();
            this.lblRemarks = new System.Windows.Forms.Label();
            this.textRemarks = new System.Windows.Forms.TextBox();
            this.btnDeleteWO = new System.Windows.Forms.Button();
            this.btnCancelWO = new System.Windows.Forms.Button();
            this.btnUpdateAndCloseWO = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.grpBoxContractsProcess = new System.Windows.Forms.GroupBox();
            this.mskTxtRecOfAwardDoc = new System.Windows.Forms.MaskedTextBox();
            this.dtpRecOfAwardDoc = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.mskTxtDistribution = new System.Windows.Forms.MaskedTextBox();
            this.mskTxtRcvdFromFinanceDeptForCommittment = new System.Windows.Forms.MaskedTextBox();
            this.mskTxtSentFinanceDeptForCommittment = new System.Windows.Forms.MaskedTextBox();
            this.mskTxtRcvdDeptSentPRSDForSign = new System.Windows.Forms.MaskedTextBox();
            this.mskTxtSentDeptForSign = new System.Windows.Forms.MaskedTextBox();
            this.mskTxtDateOfSignContract = new System.Windows.Forms.MaskedTextBox();
            this.mskTxtDueDateOfSubPBSign = new System.Windows.Forms.MaskedTextBox();
            this.mskTxtNoticeSendSignContract = new System.Windows.Forms.MaskedTextBox();
            this.mskTxtStartDateReceive = new System.Windows.Forms.MaskedTextBox();
            this.mskTxtReqDeptStartDate = new System.Windows.Forms.MaskedTextBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.lblContractAmt = new System.Windows.Forms.Label();
            this.dtpWOClosingDate = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtWorkOrderNo = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dtpWOAwardDate = new System.Windows.Forms.DateTimePicker();
            this.lblWorkOrderNo = new System.Windows.Forms.Label();
            this.txtWOTitle = new System.Windows.Forms.TextBox();
            this.lblProjectTitle = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtWOAmount = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbCompany = new System.Windows.Forms.ComboBox();
            this.mskTxtWOAwardDate = new System.Windows.Forms.MaskedTextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.dtpTenderOpenDate = new System.Windows.Forms.DateTimePicker();
            this.mskTxtTenderOpenDate = new System.Windows.Forms.MaskedTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.dtpEvalReportDateSend = new System.Windows.Forms.DateTimePicker();
            this.mskTxtEvalReportDateSend = new System.Windows.Forms.MaskedTextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtTechnoFinTotWorkdays = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.dtpEvalRepDateReceived = new System.Windows.Forms.DateTimePicker();
            this.mskTxtEvalRepDateReceived = new System.Windows.Forms.MaskedTextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.dtpTenderAwardApprovalDate = new System.Windows.Forms.DateTimePicker();
            this.mskTxtTenderAwardApprovalDate = new System.Windows.Forms.MaskedTextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtNoOfMeetings = new System.Windows.Forms.TextBox();
            this.grpBoxTenderEvalPhase = new System.Windows.Forms.GroupBox();
            this.grpBoxTenderingPhase = new System.Windows.Forms.GroupBox();
            this.mskTxtWOClosingDate = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtWOTenderEstimate = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.grpBoxContractsProcess.SuspendLayout();
            this.grpBoxTenderEvalPhase.SuspendLayout();
            this.grpBoxTenderingPhase.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblReqDeptStartDate
            // 
            this.lblReqDeptStartDate.AutoSize = true;
            this.lblReqDeptStartDate.Location = new System.Drawing.Point(12, 76);
            this.lblReqDeptStartDate.Name = "lblReqDeptStartDate";
            this.lblReqDeptStartDate.Size = new System.Drawing.Size(161, 13);
            this.lblReqDeptStartDate.TabIndex = 6;
            this.lblReqDeptStartDate.Text = "Req. Dept. to Provide Start Date";
            // 
            // dtpReqDeptStartDate
            // 
            this.dtpReqDeptStartDate.Checked = false;
            this.dtpReqDeptStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpReqDeptStartDate.Location = new System.Drawing.Point(245, 72);
            this.dtpReqDeptStartDate.Name = "dtpReqDeptStartDate";
            this.dtpReqDeptStartDate.ShowCheckBox = true;
            this.dtpReqDeptStartDate.Size = new System.Drawing.Size(118, 20);
            this.dtpReqDeptStartDate.TabIndex = 22;
            this.dtpReqDeptStartDate.Value = new System.DateTime(2015, 10, 15, 0, 0, 0, 0);
            this.dtpReqDeptStartDate.ValueChanged += new System.EventHandler(this.dtpReqDeptStartDate_ValueChanged);
            // 
            // lblStartDateReceive
            // 
            this.lblStartDateReceive.AutoSize = true;
            this.lblStartDateReceive.Location = new System.Drawing.Point(12, 118);
            this.lblStartDateReceive.Name = "lblStartDateReceive";
            this.lblStartDateReceive.Size = new System.Drawing.Size(98, 13);
            this.lblStartDateReceive.TabIndex = 8;
            this.lblStartDateReceive.Text = "Start Date Receive";
            // 
            // dtpStartDateReceive
            // 
            this.dtpStartDateReceive.Checked = false;
            this.dtpStartDateReceive.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpStartDateReceive.Location = new System.Drawing.Point(245, 117);
            this.dtpStartDateReceive.Name = "dtpStartDateReceive";
            this.dtpStartDateReceive.ShowCheckBox = true;
            this.dtpStartDateReceive.Size = new System.Drawing.Size(118, 20);
            this.dtpStartDateReceive.TabIndex = 24;
            this.dtpStartDateReceive.Value = new System.DateTime(2015, 10, 15, 0, 0, 0, 0);
            this.dtpStartDateReceive.ValueChanged += new System.EventHandler(this.dtpStartDateReceive_ValueChanged);
            // 
            // lblNoticeSendTendererSignContract
            // 
            this.lblNoticeSendTendererSignContract.AutoSize = true;
            this.lblNoticeSendTendererSignContract.Location = new System.Drawing.Point(12, 168);
            this.lblNoticeSendTendererSignContract.Name = "lblNoticeSendTendererSignContract";
            this.lblNoticeSendTendererSignContract.Size = new System.Drawing.Size(203, 13);
            this.lblNoticeSendTendererSignContract.TabIndex = 10;
            this.lblNoticeSendTendererSignContract.Text = "Notice Send to Tenderer to Sign Contract";
            // 
            // dtpNoticeSendSignContract
            // 
            this.dtpNoticeSendSignContract.Checked = false;
            this.dtpNoticeSendSignContract.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNoticeSendSignContract.Location = new System.Drawing.Point(246, 164);
            this.dtpNoticeSendSignContract.Name = "dtpNoticeSendSignContract";
            this.dtpNoticeSendSignContract.ShowCheckBox = true;
            this.dtpNoticeSendSignContract.Size = new System.Drawing.Size(118, 20);
            this.dtpNoticeSendSignContract.TabIndex = 26;
            this.dtpNoticeSendSignContract.Value = new System.DateTime(2015, 10, 15, 0, 0, 0, 0);
            this.dtpNoticeSendSignContract.ValueChanged += new System.EventHandler(this.dtpNoticeSendSignContract_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 213);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(177, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Due Date of Submission of PB Sign.";
            // 
            // dtpDueDateOfSubPBSign
            // 
            this.dtpDueDateOfSubPBSign.Checked = false;
            this.dtpDueDateOfSubPBSign.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDueDateOfSubPBSign.Location = new System.Drawing.Point(246, 209);
            this.dtpDueDateOfSubPBSign.Name = "dtpDueDateOfSubPBSign";
            this.dtpDueDateOfSubPBSign.ShowCheckBox = true;
            this.dtpDueDateOfSubPBSign.Size = new System.Drawing.Size(118, 20);
            this.dtpDueDateOfSubPBSign.TabIndex = 28;
            this.dtpDueDateOfSubPBSign.Value = new System.DateTime(2015, 10, 15, 0, 0, 0, 0);
            this.dtpDueDateOfSubPBSign.ValueChanged += new System.EventHandler(this.dtpDueDateOfSubPBSign_ValueChanged);
            // 
            // lblDateOfSignContract
            // 
            this.lblDateOfSignContract.AutoSize = true;
            this.lblDateOfSignContract.Location = new System.Drawing.Point(12, 260);
            this.lblDateOfSignContract.Name = "lblDateOfSignContract";
            this.lblDateOfSignContract.Size = new System.Drawing.Size(112, 13);
            this.lblDateOfSignContract.TabIndex = 14;
            this.lblDateOfSignContract.Text = "Date of Sign. Contract";
            // 
            // dtpDateOfSignContract
            // 
            this.dtpDateOfSignContract.Checked = false;
            this.dtpDateOfSignContract.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDateOfSignContract.Location = new System.Drawing.Point(246, 255);
            this.dtpDateOfSignContract.Name = "dtpDateOfSignContract";
            this.dtpDateOfSignContract.ShowCheckBox = true;
            this.dtpDateOfSignContract.Size = new System.Drawing.Size(118, 20);
            this.dtpDateOfSignContract.TabIndex = 30;
            this.dtpDateOfSignContract.Value = new System.DateTime(2015, 10, 15, 0, 0, 0, 0);
            this.dtpDateOfSignContract.ValueChanged += new System.EventHandler(this.dtpDateOfSignContract_ValueChanged);
            // 
            // lblSentDeptForSign
            // 
            this.lblSentDeptForSign.AutoSize = true;
            this.lblSentDeptForSign.Location = new System.Drawing.Point(12, 304);
            this.lblSentDeptForSign.Name = "lblSentDeptForSign";
            this.lblSentDeptForSign.Size = new System.Drawing.Size(109, 13);
            this.lblSentDeptForSign.TabIndex = 16;
            this.lblSentDeptForSign.Text = "Sent to Dept for Sign.";
            // 
            // dtpSentDeptForSign
            // 
            this.dtpSentDeptForSign.Checked = false;
            this.dtpSentDeptForSign.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpSentDeptForSign.Location = new System.Drawing.Point(245, 299);
            this.dtpSentDeptForSign.Name = "dtpSentDeptForSign";
            this.dtpSentDeptForSign.ShowCheckBox = true;
            this.dtpSentDeptForSign.Size = new System.Drawing.Size(118, 20);
            this.dtpSentDeptForSign.TabIndex = 32;
            this.dtpSentDeptForSign.Value = new System.DateTime(2015, 10, 15, 0, 0, 0, 0);
            this.dtpSentDeptForSign.ValueChanged += new System.EventHandler(this.dtpSentDeptForSign_ValueChanged);
            // 
            // lblRcvdDeptSentPRSDForSign
            // 
            this.lblRcvdDeptSentPRSDForSign.AutoSize = true;
            this.lblRcvdDeptSentPRSDForSign.Location = new System.Drawing.Point(10, 347);
            this.lblRcvdDeptSentPRSDForSign.Name = "lblRcvdDeptSentPRSDForSign";
            this.lblRcvdDeptSentPRSDForSign.Size = new System.Drawing.Size(224, 13);
            this.lblRcvdDeptSentPRSDForSign.TabIndex = 18;
            this.lblRcvdDeptSentPRSDForSign.Text = "Rcvd. from Dept. and Sent to PRSD. for Sign.";
            // 
            // dtpRcvdDeptSentPRSDForSign
            // 
            this.dtpRcvdDeptSentPRSDForSign.Checked = false;
            this.dtpRcvdDeptSentPRSDForSign.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpRcvdDeptSentPRSDForSign.Location = new System.Drawing.Point(246, 347);
            this.dtpRcvdDeptSentPRSDForSign.Name = "dtpRcvdDeptSentPRSDForSign";
            this.dtpRcvdDeptSentPRSDForSign.ShowCheckBox = true;
            this.dtpRcvdDeptSentPRSDForSign.Size = new System.Drawing.Size(118, 20);
            this.dtpRcvdDeptSentPRSDForSign.TabIndex = 34;
            this.dtpRcvdDeptSentPRSDForSign.Value = new System.DateTime(2015, 10, 15, 0, 0, 0, 0);
            this.dtpRcvdDeptSentPRSDForSign.ValueChanged += new System.EventHandler(this.dtpRcvdDeptSentPRSDForSign_ValueChanged);
            // 
            // lblSentFinanceDeptForCommittment
            // 
            this.lblSentFinanceDeptForCommittment.AutoSize = true;
            this.lblSentFinanceDeptForCommittment.Location = new System.Drawing.Point(10, 388);
            this.lblSentFinanceDeptForCommittment.Name = "lblSentFinanceDeptForCommittment";
            this.lblSentFinanceDeptForCommittment.Size = new System.Drawing.Size(189, 13);
            this.lblSentFinanceDeptForCommittment.TabIndex = 20;
            this.lblSentFinanceDeptForCommittment.Text = "Sent to Finance Dept. for Committment";
            // 
            // dtpSentFinanceDeptForCommittment
            // 
            this.dtpSentFinanceDeptForCommittment.Checked = false;
            this.dtpSentFinanceDeptForCommittment.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpSentFinanceDeptForCommittment.Location = new System.Drawing.Point(244, 387);
            this.dtpSentFinanceDeptForCommittment.Name = "dtpSentFinanceDeptForCommittment";
            this.dtpSentFinanceDeptForCommittment.ShowCheckBox = true;
            this.dtpSentFinanceDeptForCommittment.Size = new System.Drawing.Size(118, 20);
            this.dtpSentFinanceDeptForCommittment.TabIndex = 36;
            this.dtpSentFinanceDeptForCommittment.Value = new System.DateTime(2015, 10, 15, 0, 0, 0, 0);
            this.dtpSentFinanceDeptForCommittment.ValueChanged += new System.EventHandler(this.dtpSentFinanceDeptForCommittment_ValueChanged);
            // 
            // lblRcvdFromFinanceDeptForCommittment
            // 
            this.lblRcvdFromFinanceDeptForCommittment.AutoSize = true;
            this.lblRcvdFromFinanceDeptForCommittment.Location = new System.Drawing.Point(12, 432);
            this.lblRcvdFromFinanceDeptForCommittment.Name = "lblRcvdFromFinanceDeptForCommittment";
            this.lblRcvdFromFinanceDeptForCommittment.Size = new System.Drawing.Size(161, 13);
            this.lblRcvdFromFinanceDeptForCommittment.TabIndex = 22;
            this.lblRcvdFromFinanceDeptForCommittment.Text = "Rcvd. From Finance Department";
            // 
            // dtpRcvdFromFinanceDeptForCommittment
            // 
            this.dtpRcvdFromFinanceDeptForCommittment.Checked = false;
            this.dtpRcvdFromFinanceDeptForCommittment.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpRcvdFromFinanceDeptForCommittment.Location = new System.Drawing.Point(245, 426);
            this.dtpRcvdFromFinanceDeptForCommittment.Name = "dtpRcvdFromFinanceDeptForCommittment";
            this.dtpRcvdFromFinanceDeptForCommittment.ShowCheckBox = true;
            this.dtpRcvdFromFinanceDeptForCommittment.Size = new System.Drawing.Size(118, 20);
            this.dtpRcvdFromFinanceDeptForCommittment.TabIndex = 38;
            this.dtpRcvdFromFinanceDeptForCommittment.Value = new System.DateTime(2015, 10, 15, 0, 0, 0, 0);
            this.dtpRcvdFromFinanceDeptForCommittment.ValueChanged += new System.EventHandler(this.dtpRcvdFromFinanceDeptForCommittment_ValueChanged);
            // 
            // lblDistribution
            // 
            this.lblDistribution.AutoSize = true;
            this.lblDistribution.Location = new System.Drawing.Point(12, 471);
            this.lblDistribution.Name = "lblDistribution";
            this.lblDistribution.Size = new System.Drawing.Size(59, 13);
            this.lblDistribution.TabIndex = 24;
            this.lblDistribution.Text = "Distribution";
            // 
            // dtpDistribution
            // 
            this.dtpDistribution.Checked = false;
            this.dtpDistribution.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDistribution.Location = new System.Drawing.Point(244, 464);
            this.dtpDistribution.Name = "dtpDistribution";
            this.dtpDistribution.ShowCheckBox = true;
            this.dtpDistribution.Size = new System.Drawing.Size(118, 20);
            this.dtpDistribution.TabIndex = 40;
            this.dtpDistribution.Value = new System.DateTime(2015, 10, 15, 0, 0, 0, 0);
            this.dtpDistribution.ValueChanged += new System.EventHandler(this.dtpDistribution_ValueChanged);
            // 
            // lblContractNo
            // 
            this.lblContractNo.AutoSize = true;
            this.lblContractNo.Location = new System.Drawing.Point(12, 511);
            this.lblContractNo.Name = "lblContractNo";
            this.lblContractNo.Size = new System.Drawing.Size(67, 13);
            this.lblContractNo.TabIndex = 26;
            this.lblContractNo.Text = "Contract No.";
            // 
            // txtContractNo
            // 
            this.txtContractNo.Location = new System.Drawing.Point(244, 504);
            this.txtContractNo.Name = "txtContractNo";
            this.txtContractNo.Size = new System.Drawing.Size(117, 20);
            this.txtContractNo.TabIndex = 42;
            this.txtContractNo.Leave += new System.EventHandler(this.txtContractNo_Leave);
            // 
            // lblRemarks
            // 
            this.lblRemarks.AutoSize = true;
            this.lblRemarks.Location = new System.Drawing.Point(12, 547);
            this.lblRemarks.Name = "lblRemarks";
            this.lblRemarks.Size = new System.Drawing.Size(49, 13);
            this.lblRemarks.TabIndex = 28;
            this.lblRemarks.Text = "Remarks";
            // 
            // textRemarks
            // 
            this.textRemarks.Location = new System.Drawing.Point(13, 563);
            this.textRemarks.Multiline = true;
            this.textRemarks.Name = "textRemarks";
            this.textRemarks.Size = new System.Drawing.Size(350, 43);
            this.textRemarks.TabIndex = 43;
            // 
            // btnDeleteWO
            // 
            this.btnDeleteWO.BackColor = System.Drawing.Color.Maroon;
            this.btnDeleteWO.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDeleteWO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteWO.ForeColor = System.Drawing.Color.White;
            this.btnDeleteWO.Location = new System.Drawing.Point(15, 609);
            this.btnDeleteWO.Name = "btnDeleteWO";
            this.btnDeleteWO.Size = new System.Drawing.Size(60, 26);
            this.btnDeleteWO.TabIndex = 44;
            this.btnDeleteWO.Text = "Delete";
            this.btnDeleteWO.UseVisualStyleBackColor = false;
            this.btnDeleteWO.Click += new System.EventHandler(this.btnDeleteWO_Click);
            // 
            // btnCancelWO
            // 
            this.btnCancelWO.BackColor = System.Drawing.Color.Maroon;
            this.btnCancelWO.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCancelWO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelWO.ForeColor = System.Drawing.Color.White;
            this.btnCancelWO.Location = new System.Drawing.Point(127, 609);
            this.btnCancelWO.Name = "btnCancelWO";
            this.btnCancelWO.Size = new System.Drawing.Size(60, 26);
            this.btnCancelWO.TabIndex = 45;
            this.btnCancelWO.Text = "Cancel";
            this.btnCancelWO.UseVisualStyleBackColor = false;
            this.btnCancelWO.Click += new System.EventHandler(this.btnCancelWO_Click);
            // 
            // btnUpdateAndCloseWO
            // 
            this.btnUpdateAndCloseWO.BackColor = System.Drawing.Color.Maroon;
            this.btnUpdateAndCloseWO.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnUpdateAndCloseWO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateAndCloseWO.ForeColor = System.Drawing.Color.White;
            this.btnUpdateAndCloseWO.Location = new System.Drawing.Point(233, 608);
            this.btnUpdateAndCloseWO.Name = "btnUpdateAndCloseWO";
            this.btnUpdateAndCloseWO.Size = new System.Drawing.Size(86, 27);
            this.btnUpdateAndCloseWO.TabIndex = 46;
            this.btnUpdateAndCloseWO.UseVisualStyleBackColor = false;
            this.btnUpdateAndCloseWO.Click += new System.EventHandler(this.btnSaveAndCloseWO_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(10, 573);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 13);
            this.label3.TabIndex = 36;
            this.label3.Text = "* Mandatory Fields";
            // 
            // grpBoxContractsProcess
            // 
            this.grpBoxContractsProcess.Controls.Add(this.mskTxtRecOfAwardDoc);
            this.grpBoxContractsProcess.Controls.Add(this.dtpRecOfAwardDoc);
            this.grpBoxContractsProcess.Controls.Add(this.label7);
            this.grpBoxContractsProcess.Controls.Add(this.mskTxtDistribution);
            this.grpBoxContractsProcess.Controls.Add(this.mskTxtRcvdFromFinanceDeptForCommittment);
            this.grpBoxContractsProcess.Controls.Add(this.mskTxtSentFinanceDeptForCommittment);
            this.grpBoxContractsProcess.Controls.Add(this.mskTxtRcvdDeptSentPRSDForSign);
            this.grpBoxContractsProcess.Controls.Add(this.mskTxtSentDeptForSign);
            this.grpBoxContractsProcess.Controls.Add(this.mskTxtDateOfSignContract);
            this.grpBoxContractsProcess.Controls.Add(this.textRemarks);
            this.grpBoxContractsProcess.Controls.Add(this.mskTxtDueDateOfSubPBSign);
            this.grpBoxContractsProcess.Controls.Add(this.lblRemarks);
            this.grpBoxContractsProcess.Controls.Add(this.mskTxtNoticeSendSignContract);
            this.grpBoxContractsProcess.Controls.Add(this.txtContractNo);
            this.grpBoxContractsProcess.Controls.Add(this.mskTxtStartDateReceive);
            this.grpBoxContractsProcess.Controls.Add(this.lblContractNo);
            this.grpBoxContractsProcess.Controls.Add(this.mskTxtReqDeptStartDate);
            this.grpBoxContractsProcess.Controls.Add(this.lblReqDeptStartDate);
            this.grpBoxContractsProcess.Controls.Add(this.dtpReqDeptStartDate);
            this.grpBoxContractsProcess.Controls.Add(this.dtpDistribution);
            this.grpBoxContractsProcess.Controls.Add(this.lblStartDateReceive);
            this.grpBoxContractsProcess.Controls.Add(this.lblDistribution);
            this.grpBoxContractsProcess.Controls.Add(this.dtpStartDateReceive);
            this.grpBoxContractsProcess.Controls.Add(this.lblNoticeSendTendererSignContract);
            this.grpBoxContractsProcess.Controls.Add(this.dtpNoticeSendSignContract);
            this.grpBoxContractsProcess.Controls.Add(this.dtpRcvdFromFinanceDeptForCommittment);
            this.grpBoxContractsProcess.Controls.Add(this.label1);
            this.grpBoxContractsProcess.Controls.Add(this.lblRcvdFromFinanceDeptForCommittment);
            this.grpBoxContractsProcess.Controls.Add(this.dtpDueDateOfSubPBSign);
            this.grpBoxContractsProcess.Controls.Add(this.lblDateOfSignContract);
            this.grpBoxContractsProcess.Controls.Add(this.dtpDateOfSignContract);
            this.grpBoxContractsProcess.Controls.Add(this.dtpSentFinanceDeptForCommittment);
            this.grpBoxContractsProcess.Controls.Add(this.lblSentDeptForSign);
            this.grpBoxContractsProcess.Controls.Add(this.lblSentFinanceDeptForCommittment);
            this.grpBoxContractsProcess.Controls.Add(this.dtpSentDeptForSign);
            this.grpBoxContractsProcess.Controls.Add(this.lblRcvdDeptSentPRSDForSign);
            this.grpBoxContractsProcess.Controls.Add(this.dtpRcvdDeptSentPRSDForSign);
            this.grpBoxContractsProcess.Location = new System.Drawing.Point(508, 16);
            this.grpBoxContractsProcess.Name = "grpBoxContractsProcess";
            this.grpBoxContractsProcess.Size = new System.Drawing.Size(395, 634);
            this.grpBoxContractsProcess.TabIndex = 60;
            this.grpBoxContractsProcess.TabStop = false;
            this.grpBoxContractsProcess.Text = "Contracts Process";
            // 
            // mskTxtRecOfAwardDoc
            // 
            this.mskTxtRecOfAwardDoc.Location = new System.Drawing.Point(246, 35);
            this.mskTxtRecOfAwardDoc.Name = "mskTxtRecOfAwardDoc";
            this.mskTxtRecOfAwardDoc.Size = new System.Drawing.Size(95, 20);
            this.mskTxtRecOfAwardDoc.TabIndex = 21;
            // 
            // dtpRecOfAwardDoc
            // 
            this.dtpRecOfAwardDoc.Checked = false;
            this.dtpRecOfAwardDoc.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpRecOfAwardDoc.Location = new System.Drawing.Point(245, 35);
            this.dtpRecOfAwardDoc.Name = "dtpRecOfAwardDoc";
            this.dtpRecOfAwardDoc.ShowCheckBox = true;
            this.dtpRecOfAwardDoc.Size = new System.Drawing.Size(119, 20);
            this.dtpRecOfAwardDoc.TabIndex = 20;
            this.dtpRecOfAwardDoc.Value = new System.DateTime(2015, 10, 15, 0, 0, 0, 0);
            this.dtpRecOfAwardDoc.ValueChanged += new System.EventHandler(this.dtpRecOfAwardDoc_ValueChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 38);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(152, 13);
            this.label7.TabIndex = 36;
            this.label7.Text = "Received Of Award Document";
            // 
            // mskTxtDistribution
            // 
            this.mskTxtDistribution.Location = new System.Drawing.Point(244, 464);
            this.mskTxtDistribution.Name = "mskTxtDistribution";
            this.mskTxtDistribution.Size = new System.Drawing.Size(97, 20);
            this.mskTxtDistribution.TabIndex = 41;
            // 
            // mskTxtRcvdFromFinanceDeptForCommittment
            // 
            this.mskTxtRcvdFromFinanceDeptForCommittment.Location = new System.Drawing.Point(244, 426);
            this.mskTxtRcvdFromFinanceDeptForCommittment.Name = "mskTxtRcvdFromFinanceDeptForCommittment";
            this.mskTxtRcvdFromFinanceDeptForCommittment.Size = new System.Drawing.Size(97, 20);
            this.mskTxtRcvdFromFinanceDeptForCommittment.TabIndex = 39;
            // 
            // mskTxtSentFinanceDeptForCommittment
            // 
            this.mskTxtSentFinanceDeptForCommittment.Location = new System.Drawing.Point(244, 387);
            this.mskTxtSentFinanceDeptForCommittment.Name = "mskTxtSentFinanceDeptForCommittment";
            this.mskTxtSentFinanceDeptForCommittment.Size = new System.Drawing.Size(97, 20);
            this.mskTxtSentFinanceDeptForCommittment.TabIndex = 37;
            // 
            // mskTxtRcvdDeptSentPRSDForSign
            // 
            this.mskTxtRcvdDeptSentPRSDForSign.Location = new System.Drawing.Point(245, 347);
            this.mskTxtRcvdDeptSentPRSDForSign.Name = "mskTxtRcvdDeptSentPRSDForSign";
            this.mskTxtRcvdDeptSentPRSDForSign.Size = new System.Drawing.Size(96, 20);
            this.mskTxtRcvdDeptSentPRSDForSign.TabIndex = 35;
            // 
            // mskTxtSentDeptForSign
            // 
            this.mskTxtSentDeptForSign.Location = new System.Drawing.Point(246, 299);
            this.mskTxtSentDeptForSign.Name = "mskTxtSentDeptForSign";
            this.mskTxtSentDeptForSign.Size = new System.Drawing.Size(95, 20);
            this.mskTxtSentDeptForSign.TabIndex = 33;
            // 
            // mskTxtDateOfSignContract
            // 
            this.mskTxtDateOfSignContract.Location = new System.Drawing.Point(245, 255);
            this.mskTxtDateOfSignContract.Name = "mskTxtDateOfSignContract";
            this.mskTxtDateOfSignContract.Size = new System.Drawing.Size(96, 20);
            this.mskTxtDateOfSignContract.TabIndex = 31;
            // 
            // mskTxtDueDateOfSubPBSign
            // 
            this.mskTxtDueDateOfSubPBSign.Location = new System.Drawing.Point(246, 209);
            this.mskTxtDueDateOfSubPBSign.Name = "mskTxtDueDateOfSubPBSign";
            this.mskTxtDueDateOfSubPBSign.Size = new System.Drawing.Size(95, 20);
            this.mskTxtDueDateOfSubPBSign.TabIndex = 29;
            // 
            // mskTxtNoticeSendSignContract
            // 
            this.mskTxtNoticeSendSignContract.Location = new System.Drawing.Point(246, 164);
            this.mskTxtNoticeSendSignContract.Name = "mskTxtNoticeSendSignContract";
            this.mskTxtNoticeSendSignContract.Size = new System.Drawing.Size(95, 20);
            this.mskTxtNoticeSendSignContract.TabIndex = 27;
            // 
            // mskTxtStartDateReceive
            // 
            this.mskTxtStartDateReceive.Location = new System.Drawing.Point(245, 117);
            this.mskTxtStartDateReceive.Name = "mskTxtStartDateReceive";
            this.mskTxtStartDateReceive.Size = new System.Drawing.Size(96, 20);
            this.mskTxtStartDateReceive.TabIndex = 25;
            // 
            // mskTxtReqDeptStartDate
            // 
            this.mskTxtReqDeptStartDate.Location = new System.Drawing.Point(246, 72);
            this.mskTxtReqDeptStartDate.Name = "mskTxtReqDeptStartDate";
            this.mskTxtReqDeptStartDate.Size = new System.Drawing.Size(95, 20);
            this.mskTxtReqDeptStartDate.TabIndex = 23;
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.Maroon;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(348, 608);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(86, 27);
            this.btnClose.TabIndex = 47;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // lblContractAmt
            // 
            this.lblContractAmt.AutoSize = true;
            this.lblContractAmt.Location = new System.Drawing.Point(17, 340);
            this.lblContractAmt.Name = "lblContractAmt";
            this.lblContractAmt.Size = new System.Drawing.Size(101, 13);
            this.lblContractAmt.TabIndex = 4;
            this.lblContractAmt.Text = "Work Order Amount";
            // 
            // dtpWOClosingDate
            // 
            this.dtpWOClosingDate.Checked = false;
            this.dtpWOClosingDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpWOClosingDate.Location = new System.Drawing.Point(250, 127);
            this.dtpWOClosingDate.Name = "dtpWOClosingDate";
            this.dtpWOClosingDate.ShowCheckBox = true;
            this.dtpWOClosingDate.Size = new System.Drawing.Size(118, 20);
            this.dtpWOClosingDate.TabIndex = 3;
            this.dtpWOClosingDate.Value = new System.DateTime(2016, 12, 25, 0, 0, 0, 0);
            this.dtpWOClosingDate.ValueChanged += new System.EventHandler(this.dtpWOClosingDate_ValueChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(17, 271);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(121, 13);
            this.label8.TabIndex = 44;
            this.label8.Text = "Work Order Award Date";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 127);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(125, 13);
            this.label4.TabIndex = 53;
            this.label4.Text = "Work Order Closing Date";
            // 
            // txtWorkOrderNo
            // 
            this.txtWorkOrderNo.Enabled = false;
            this.txtWorkOrderNo.Location = new System.Drawing.Point(248, 97);
            this.txtWorkOrderNo.Name = "txtWorkOrderNo";
            this.txtWorkOrderNo.Size = new System.Drawing.Size(117, 20);
            this.txtWorkOrderNo.TabIndex = 2;
            this.txtWorkOrderNo.Leave += new System.EventHandler(this.txtWorkOrderNo_Leave);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(368, 128);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(12, 15);
            this.label5.TabIndex = 56;
            this.label5.Text = "*";
            // 
            // dtpWOAwardDate
            // 
            this.dtpWOAwardDate.Checked = false;
            this.dtpWOAwardDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpWOAwardDate.Location = new System.Drawing.Point(250, 271);
            this.dtpWOAwardDate.Name = "dtpWOAwardDate";
            this.dtpWOAwardDate.ShowCheckBox = true;
            this.dtpWOAwardDate.Size = new System.Drawing.Size(118, 20);
            this.dtpWOAwardDate.TabIndex = 16;
            this.dtpWOAwardDate.Value = new System.DateTime(2015, 10, 15, 0, 0, 0, 0);
            this.dtpWOAwardDate.ValueChanged += new System.EventHandler(this.dtpWOAwardDate_ValueChanged);
            // 
            // lblWorkOrderNo
            // 
            this.lblWorkOrderNo.AutoSize = true;
            this.lblWorkOrderNo.Location = new System.Drawing.Point(14, 97);
            this.lblWorkOrderNo.Name = "lblWorkOrderNo";
            this.lblWorkOrderNo.Size = new System.Drawing.Size(82, 13);
            this.lblWorkOrderNo.TabIndex = 2;
            this.lblWorkOrderNo.Text = "Work Order No.";
            // 
            // txtWOTitle
            // 
            this.txtWOTitle.Enabled = false;
            this.txtWOTitle.Location = new System.Drawing.Point(14, 41);
            this.txtWOTitle.Multiline = true;
            this.txtWOTitle.Name = "txtWOTitle";
            this.txtWOTitle.Size = new System.Drawing.Size(348, 43);
            this.txtWOTitle.TabIndex = 1;
            // 
            // lblProjectTitle
            // 
            this.lblProjectTitle.AutoSize = true;
            this.lblProjectTitle.Location = new System.Drawing.Point(11, 25);
            this.lblProjectTitle.Name = "lblProjectTitle";
            this.lblProjectTitle.Size = new System.Drawing.Size(85, 13);
            this.lblProjectTitle.TabIndex = 0;
            this.lblProjectTitle.Text = "Work Order Title";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 305);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 13);
            this.label6.TabIndex = 50;
            this.label6.Text = "Awarded Bidder";
            // 
            // txtWOAmount
            // 
            this.txtWOAmount.Location = new System.Drawing.Point(250, 340);
            this.txtWOAmount.Name = "txtWOAmount";
            this.txtWOAmount.Size = new System.Drawing.Size(117, 20);
            this.txtWOAmount.TabIndex = 19;
            this.txtWOAmount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtContractAmt_KeyPress);
            this.txtWOAmount.Leave += new System.EventHandler(this.txtContractAmt_Leave);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(370, 343);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 13);
            this.label2.TabIndex = 35;
            this.label2.Text = "QAR";
            // 
            // cmbCompany
            // 
            this.cmbCompany.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCompany.FormattingEnabled = true;
            this.cmbCompany.Location = new System.Drawing.Point(250, 305);
            this.cmbCompany.Name = "cmbCompany";
            this.cmbCompany.Size = new System.Drawing.Size(199, 21);
            this.cmbCompany.TabIndex = 18;
            this.cmbCompany.SelectionChangeCommitted += new System.EventHandler(this.cmbCompany_SelectionChangeCommitted);
            // 
            // mskTxtWOAwardDate
            // 
            this.mskTxtWOAwardDate.Location = new System.Drawing.Point(251, 271);
            this.mskTxtWOAwardDate.Name = "mskTxtWOAwardDate";
            this.mskTxtWOAwardDate.Size = new System.Drawing.Size(96, 20);
            this.mskTxtWOAwardDate.TabIndex = 17;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(17, 30);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(96, 13);
            this.label9.TabIndex = 61;
            this.label9.Text = "Tender Open Date";
            // 
            // dtpTenderOpenDate
            // 
            this.dtpTenderOpenDate.Checked = false;
            this.dtpTenderOpenDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTenderOpenDate.Location = new System.Drawing.Point(250, 30);
            this.dtpTenderOpenDate.Name = "dtpTenderOpenDate";
            this.dtpTenderOpenDate.ShowCheckBox = true;
            this.dtpTenderOpenDate.Size = new System.Drawing.Size(118, 20);
            this.dtpTenderOpenDate.TabIndex = 5;
            this.dtpTenderOpenDate.Value = new System.DateTime(2015, 10, 15, 0, 0, 0, 0);
            this.dtpTenderOpenDate.ValueChanged += new System.EventHandler(this.dtpTenderOpenDate_ValueChanged);
            // 
            // mskTxtTenderOpenDate
            // 
            this.mskTxtTenderOpenDate.Location = new System.Drawing.Point(251, 30);
            this.mskTxtTenderOpenDate.Name = "mskTxtTenderOpenDate";
            this.mskTxtTenderOpenDate.Size = new System.Drawing.Size(96, 20);
            this.mskTxtTenderOpenDate.TabIndex = 6;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(17, 63);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(146, 13);
            this.label10.TabIndex = 64;
            this.label10.Text = "Evaluation Report Date Send";
            // 
            // dtpEvalReportDateSend
            // 
            this.dtpEvalReportDateSend.Checked = false;
            this.dtpEvalReportDateSend.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpEvalReportDateSend.Location = new System.Drawing.Point(250, 64);
            this.dtpEvalReportDateSend.Name = "dtpEvalReportDateSend";
            this.dtpEvalReportDateSend.ShowCheckBox = true;
            this.dtpEvalReportDateSend.Size = new System.Drawing.Size(118, 20);
            this.dtpEvalReportDateSend.TabIndex = 7;
            this.dtpEvalReportDateSend.Value = new System.DateTime(2015, 10, 15, 0, 0, 0, 0);
            this.dtpEvalReportDateSend.ValueChanged += new System.EventHandler(this.dtpEvalReportDateSend_ValueChanged);
            // 
            // mskTxtEvalReportDateSend
            // 
            this.mskTxtEvalReportDateSend.Location = new System.Drawing.Point(251, 64);
            this.mskTxtEvalReportDateSend.Name = "mskTxtEvalReportDateSend";
            this.mskTxtEvalReportDateSend.Size = new System.Drawing.Size(96, 20);
            this.mskTxtEvalReportDateSend.TabIndex = 8;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(17, 101);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(167, 13);
            this.label11.TabIndex = 67;
            this.label11.Text = "Techno Financial Total Workdays";
            // 
            // txtTechnoFinTotWorkdays
            // 
            this.txtTechnoFinTotWorkdays.Location = new System.Drawing.Point(250, 99);
            this.txtTechnoFinTotWorkdays.Name = "txtTechnoFinTotWorkdays";
            this.txtTechnoFinTotWorkdays.Size = new System.Drawing.Size(117, 20);
            this.txtTechnoFinTotWorkdays.TabIndex = 9;
            this.txtTechnoFinTotWorkdays.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTechnoFinTotWorkdays_KeyPress);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(17, 137);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(167, 13);
            this.label12.TabIndex = 69;
            this.label12.Text = "Evaluation Report Date Received";
            // 
            // dtpEvalRepDateReceived
            // 
            this.dtpEvalRepDateReceived.Checked = false;
            this.dtpEvalRepDateReceived.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpEvalRepDateReceived.Location = new System.Drawing.Point(250, 137);
            this.dtpEvalRepDateReceived.Name = "dtpEvalRepDateReceived";
            this.dtpEvalRepDateReceived.ShowCheckBox = true;
            this.dtpEvalRepDateReceived.Size = new System.Drawing.Size(118, 20);
            this.dtpEvalRepDateReceived.TabIndex = 10;
            this.dtpEvalRepDateReceived.Value = new System.DateTime(2015, 10, 15, 0, 0, 0, 0);
            this.dtpEvalRepDateReceived.ValueChanged += new System.EventHandler(this.dtpEvalRepDateReceived_ValueChanged);
            // 
            // mskTxtEvalRepDateReceived
            // 
            this.mskTxtEvalRepDateReceived.Location = new System.Drawing.Point(251, 137);
            this.mskTxtEvalRepDateReceived.Name = "mskTxtEvalRepDateReceived";
            this.mskTxtEvalRepDateReceived.Size = new System.Drawing.Size(96, 20);
            this.mskTxtEvalRepDateReceived.TabIndex = 11;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(18, 169);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(145, 13);
            this.label13.TabIndex = 72;
            this.label13.Text = "Tender Award Approval Date";
            // 
            // dtpTenderAwardApprovalDate
            // 
            this.dtpTenderAwardApprovalDate.Checked = false;
            this.dtpTenderAwardApprovalDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTenderAwardApprovalDate.Location = new System.Drawing.Point(251, 169);
            this.dtpTenderAwardApprovalDate.Name = "dtpTenderAwardApprovalDate";
            this.dtpTenderAwardApprovalDate.ShowCheckBox = true;
            this.dtpTenderAwardApprovalDate.Size = new System.Drawing.Size(118, 20);
            this.dtpTenderAwardApprovalDate.TabIndex = 12;
            this.dtpTenderAwardApprovalDate.Value = new System.DateTime(2015, 10, 15, 0, 0, 0, 0);
            this.dtpTenderAwardApprovalDate.ValueChanged += new System.EventHandler(this.dtpTenderAwardApprovalDate_ValueChanged);
            // 
            // mskTxtTenderAwardApprovalDate
            // 
            this.mskTxtTenderAwardApprovalDate.Location = new System.Drawing.Point(252, 169);
            this.mskTxtTenderAwardApprovalDate.Name = "mskTxtTenderAwardApprovalDate";
            this.mskTxtTenderAwardApprovalDate.Size = new System.Drawing.Size(95, 20);
            this.mskTxtTenderAwardApprovalDate.TabIndex = 13;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(19, 204);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(104, 13);
            this.label14.TabIndex = 75;
            this.label14.Text = "Number Of Meetings";
            // 
            // txtNoOfMeetings
            // 
            this.txtNoOfMeetings.Location = new System.Drawing.Point(251, 204);
            this.txtNoOfMeetings.Name = "txtNoOfMeetings";
            this.txtNoOfMeetings.Size = new System.Drawing.Size(117, 20);
            this.txtNoOfMeetings.TabIndex = 14;
            this.txtNoOfMeetings.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNoOfMeetings_KeyPress);
            // 
            // grpBoxTenderEvalPhase
            // 
            this.grpBoxTenderEvalPhase.Controls.Add(this.label15);
            this.grpBoxTenderEvalPhase.Controls.Add(this.txtWOTenderEstimate);
            this.grpBoxTenderEvalPhase.Controls.Add(this.label16);
            this.grpBoxTenderEvalPhase.Controls.Add(this.txtNoOfMeetings);
            this.grpBoxTenderEvalPhase.Controls.Add(this.label14);
            this.grpBoxTenderEvalPhase.Controls.Add(this.mskTxtTenderAwardApprovalDate);
            this.grpBoxTenderEvalPhase.Controls.Add(this.dtpTenderAwardApprovalDate);
            this.grpBoxTenderEvalPhase.Controls.Add(this.label13);
            this.grpBoxTenderEvalPhase.Controls.Add(this.mskTxtEvalRepDateReceived);
            this.grpBoxTenderEvalPhase.Controls.Add(this.dtpEvalRepDateReceived);
            this.grpBoxTenderEvalPhase.Controls.Add(this.label12);
            this.grpBoxTenderEvalPhase.Controls.Add(this.txtTechnoFinTotWorkdays);
            this.grpBoxTenderEvalPhase.Controls.Add(this.label11);
            this.grpBoxTenderEvalPhase.Controls.Add(this.mskTxtEvalReportDateSend);
            this.grpBoxTenderEvalPhase.Controls.Add(this.dtpEvalReportDateSend);
            this.grpBoxTenderEvalPhase.Controls.Add(this.label10);
            this.grpBoxTenderEvalPhase.Controls.Add(this.mskTxtTenderOpenDate);
            this.grpBoxTenderEvalPhase.Controls.Add(this.dtpTenderOpenDate);
            this.grpBoxTenderEvalPhase.Controls.Add(this.label9);
            this.grpBoxTenderEvalPhase.Controls.Add(this.mskTxtWOAwardDate);
            this.grpBoxTenderEvalPhase.Controls.Add(this.cmbCompany);
            this.grpBoxTenderEvalPhase.Controls.Add(this.label2);
            this.grpBoxTenderEvalPhase.Controls.Add(this.txtWOAmount);
            this.grpBoxTenderEvalPhase.Controls.Add(this.label6);
            this.grpBoxTenderEvalPhase.Controls.Add(this.dtpWOAwardDate);
            this.grpBoxTenderEvalPhase.Controls.Add(this.label8);
            this.grpBoxTenderEvalPhase.Controls.Add(this.lblContractAmt);
            this.grpBoxTenderEvalPhase.Location = new System.Drawing.Point(13, 180);
            this.grpBoxTenderEvalPhase.Name = "grpBoxTenderEvalPhase";
            this.grpBoxTenderEvalPhase.Size = new System.Drawing.Size(460, 379);
            this.grpBoxTenderEvalPhase.TabIndex = 59;
            this.grpBoxTenderEvalPhase.TabStop = false;
            this.grpBoxTenderEvalPhase.Text = "Tender Evaluation Phase";
            // 
            // grpBoxTenderingPhase
            // 
            this.grpBoxTenderingPhase.Controls.Add(this.mskTxtWOClosingDate);
            this.grpBoxTenderingPhase.Controls.Add(this.lblProjectTitle);
            this.grpBoxTenderingPhase.Controls.Add(this.txtWOTitle);
            this.grpBoxTenderingPhase.Controls.Add(this.lblWorkOrderNo);
            this.grpBoxTenderingPhase.Controls.Add(this.txtWorkOrderNo);
            this.grpBoxTenderingPhase.Controls.Add(this.label4);
            this.grpBoxTenderingPhase.Controls.Add(this.dtpWOClosingDate);
            this.grpBoxTenderingPhase.Controls.Add(this.label5);
            this.grpBoxTenderingPhase.Location = new System.Drawing.Point(15, 13);
            this.grpBoxTenderingPhase.Name = "grpBoxTenderingPhase";
            this.grpBoxTenderingPhase.Size = new System.Drawing.Size(458, 154);
            this.grpBoxTenderingPhase.TabIndex = 62;
            this.grpBoxTenderingPhase.TabStop = false;
            this.grpBoxTenderingPhase.Text = "Tendering Phase";
            // 
            // mskTxtWOClosingDate
            // 
            this.mskTxtWOClosingDate.Location = new System.Drawing.Point(247, 127);
            this.mskTxtWOClosingDate.Name = "mskTxtWOClosingDate";
            this.mskTxtWOClosingDate.Size = new System.Drawing.Size(98, 20);
            this.mskTxtWOClosingDate.TabIndex = 4;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label15.Location = new System.Drawing.Point(371, 240);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(30, 13);
            this.label15.TabIndex = 78;
            this.label15.Text = "QAR";
            // 
            // txtWOTenderEstimate
            // 
            this.txtWOTenderEstimate.Location = new System.Drawing.Point(251, 237);
            this.txtWOTenderEstimate.Name = "txtWOTenderEstimate";
            this.txtWOTenderEstimate.Size = new System.Drawing.Size(117, 20);
            this.txtWOTenderEstimate.TabIndex = 15;
            this.txtWOTenderEstimate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtContractAmt_KeyPress);
            this.txtWOTenderEstimate.Leave += new System.EventHandler(this.txtContractAmt_Leave);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(18, 237);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(106, 13);
            this.label16.TabIndex = 77;
            this.label16.Text = "WO Tender Estimate";
            // 
            // frmWorkOrderContractProcessDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FloralWhite;
            this.ClientSize = new System.Drawing.Size(931, 662);
            this.Controls.Add(this.grpBoxTenderingPhase);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.grpBoxContractsProcess);
            this.Controls.Add(this.grpBoxTenderEvalPhase);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnUpdateAndCloseWO);
            this.Controls.Add(this.btnCancelWO);
            this.Controls.Add(this.btnDeleteWO);
            this.Name = "frmWorkOrderContractProcessDetails";
            this.Text = "Work Order Contract Process Details";
            this.grpBoxContractsProcess.ResumeLayout(false);
            this.grpBoxContractsProcess.PerformLayout();
            this.grpBoxTenderEvalPhase.ResumeLayout(false);
            this.grpBoxTenderEvalPhase.PerformLayout();
            this.grpBoxTenderingPhase.ResumeLayout(false);
            this.grpBoxTenderingPhase.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblReqDeptStartDate;
        private System.Windows.Forms.DateTimePicker dtpReqDeptStartDate;
        private System.Windows.Forms.Label lblStartDateReceive;
        private System.Windows.Forms.DateTimePicker dtpStartDateReceive;
        private System.Windows.Forms.Label lblNoticeSendTendererSignContract;
        private System.Windows.Forms.DateTimePicker dtpNoticeSendSignContract;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtpDueDateOfSubPBSign;
        private System.Windows.Forms.Label lblDateOfSignContract;
        private System.Windows.Forms.DateTimePicker dtpDateOfSignContract;
        private System.Windows.Forms.Label lblSentDeptForSign;
        private System.Windows.Forms.DateTimePicker dtpSentDeptForSign;
        private System.Windows.Forms.Label lblRcvdDeptSentPRSDForSign;
        private System.Windows.Forms.DateTimePicker dtpRcvdDeptSentPRSDForSign;
        private System.Windows.Forms.Label lblSentFinanceDeptForCommittment;
        private System.Windows.Forms.DateTimePicker dtpSentFinanceDeptForCommittment;
        private System.Windows.Forms.Label lblRcvdFromFinanceDeptForCommittment;
        private System.Windows.Forms.DateTimePicker dtpRcvdFromFinanceDeptForCommittment;
        private System.Windows.Forms.Label lblDistribution;
        private System.Windows.Forms.DateTimePicker dtpDistribution;
        private System.Windows.Forms.Label lblContractNo;
        private System.Windows.Forms.TextBox txtContractNo;
        private System.Windows.Forms.Label lblRemarks;
        private System.Windows.Forms.TextBox textRemarks;
        private System.Windows.Forms.Button btnDeleteWO;
        private System.Windows.Forms.Button btnCancelWO;
        private System.Windows.Forms.Button btnUpdateAndCloseWO;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox grpBoxContractsProcess;
        private System.Windows.Forms.MaskedTextBox mskTxtStartDateReceive;
        private System.Windows.Forms.MaskedTextBox mskTxtReqDeptStartDate;
        private System.Windows.Forms.MaskedTextBox mskTxtNoticeSendSignContract;
        private System.Windows.Forms.MaskedTextBox mskTxtDueDateOfSubPBSign;
        private System.Windows.Forms.MaskedTextBox mskTxtDateOfSignContract;
        private System.Windows.Forms.MaskedTextBox mskTxtSentDeptForSign;
        private System.Windows.Forms.MaskedTextBox mskTxtRcvdDeptSentPRSDForSign;
        private System.Windows.Forms.MaskedTextBox mskTxtSentFinanceDeptForCommittment;
        private System.Windows.Forms.MaskedTextBox mskTxtRcvdFromFinanceDeptForCommittment;
        private System.Windows.Forms.MaskedTextBox mskTxtDistribution;
        private System.Windows.Forms.DateTimePicker dtpRecOfAwardDoc;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.MaskedTextBox mskTxtRecOfAwardDoc;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblContractAmt;
        private System.Windows.Forms.DateTimePicker dtpWOClosingDate;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtWorkOrderNo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dtpWOAwardDate;
        private System.Windows.Forms.Label lblWorkOrderNo;
        private System.Windows.Forms.TextBox txtWOTitle;
        private System.Windows.Forms.Label lblProjectTitle;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtWOAmount;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbCompany;
        private System.Windows.Forms.MaskedTextBox mskTxtWOAwardDate;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker dtpTenderOpenDate;
        private System.Windows.Forms.MaskedTextBox mskTxtTenderOpenDate;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker dtpEvalReportDateSend;
        private System.Windows.Forms.MaskedTextBox mskTxtEvalReportDateSend;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtTechnoFinTotWorkdays;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DateTimePicker dtpEvalRepDateReceived;
        private System.Windows.Forms.MaskedTextBox mskTxtEvalRepDateReceived;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DateTimePicker dtpTenderAwardApprovalDate;
        private System.Windows.Forms.MaskedTextBox mskTxtTenderAwardApprovalDate;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtNoOfMeetings;
        private System.Windows.Forms.GroupBox grpBoxTenderEvalPhase;
        private System.Windows.Forms.GroupBox grpBoxTenderingPhase;
        private System.Windows.Forms.TextBox mskTxtWOClosingDate;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtWOTenderEstimate;
        private System.Windows.Forms.Label label16;
    }
}