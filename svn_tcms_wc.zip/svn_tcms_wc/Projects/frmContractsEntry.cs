﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using TenderTrackingSystem;

namespace MDI_ParenrForm.Projects
{
    public partial class frmContractsEntry : Form
    {         
        protected SqlConnection sqlConn;
        protected SqlCommand sqlCom;
        protected SqlDataReader sqlReader;

        string contractNo = string.Empty;
        string contractTitle = string.Empty;
        string contractStatus = string.Empty;
        string cmpName = null;

        DateTime contractStartDate = DateTime.Now;
        DateTime contractEndDate = DateTime.Now;
        DateTime contarctRevisedDate = DateTime.Now;
        string _contractorNo = string.Empty;
        CommonClass cmnCls = new CommonClass("");
        int _bidID = 0;
        int _prjID = 0;
        string _cmpId = null;
         //public frmContractsEntry(short paramSelectedValue, string cntrNo, string cntrTitle, string strtDate, string endDate, string revisedDate, string ministry_Code, string budjet_RefNo, string provision_No, string tender_Status)

        IList<string> userRightsColl = new List<string>();
        string _userName = string.Empty;
        string _projectTitle = null;
        string mTenderNo = null;
        string mTEAModifiedClosingDate = null;
        string mTEAClosingDate = null;
        string mCmpName = null;
        bool _isHeadOfSection = false;
        public frmContractsEntry(IList<string> userRightsCollContracts, int bidID, int PrjID, string cmpId, string user, bool isHeadOfSection,string projectTitle,string tenderNo,string tEAModifiedClosingDate,string tEAClosingDate)
        {
            InitializeComponent();
            userRightsColl = userRightsCollContracts;
            _userName = user;            
            _bidID = bidID;
            _prjID = PrjID;
            _cmpId = cmpId;
            mTenderNo = tenderNo;
            mTEAModifiedClosingDate = tEAModifiedClosingDate;
            mTEAClosingDate = tEAClosingDate;             
            _isHeadOfSection = isHeadOfSection;
            _projectTitle = projectTitle;
            cmnCls.PopulateComboBox(cmbCompany, "Select CO_ID,CO_NAME FROM COMPANY Order by CO_NAME ", "CO_ID", "CO_NAME");
            cmnCls.PopulateComboBox(cmbContractStatus, "Select contract_status_id,[ContractStatus] as Status FROM [ContractStatus]", "contract_status_id", "Status");
            //clsDatabase clsDB = new clsDatabase(ConfigurationManager.AppSettings["TCMSConnString"].ToString());
            //clsDB.ConnectDB();
            //SqlDataReader sqlDtReader = clsDB.ExecuteReader1("SELECT workOrderID FROM WorkOrders WHERE (proj_id = " + PrjID + ")", 'C');
            //if (sqlDtReader.HasRows)
            //{
            //    cmnCls.CreateWorkOrderGridViewColumns(dgvWorkOrders, _prjID, bidID);
            //}
            //sqlDtReader.Close();
            //clsDB.DisconnectDB(); 
             
            //dgvWorkOrders.ColumnHeadersDefaultCellStyle.BackColor = Color.Gainsboro;
            //dgvWorkOrders.ColumnHeadersDefaultCellStyle.ForeColor = Color.Chocolate;
            //dgvWorkOrders.ColumnHeadersDefaultCellStyle.Font = new Font(dgvWorkOrders.Font, FontStyle.Regular);
            //dgvWorkOrders.EnableHeadersVisualStyles = false;
            //dgvWorkOrders.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            //txtContractNo.Text = cntrNo;
            //txtContractTitle.Text = cntrTitle;

            //DateTime dt = Convert.ToDateTime(strtDate.ToString());
            //dtpStartDate.Text = dt.ToString("dd/MMM/yyyy");

            //// dtpStartDate.Text = Convert.ToDateTime(strtDate).ToString("dd/MMM/yyyy");
            //dtpEndDate.Text = Convert.ToDateTime(revisedDate).ToString("dd/MMM/yyyy");
            //dtpEndDate.Text = Convert.ToDateTime(revisedDate).ToString("dd/MMM/yyyy"); 
          
        }

        ////Added by Varun on 02 Jul 15 based on req. from Riyas
        //public void CreateWorkOrderGridViewColumns(DataGridView dgvWorkOrders, int PC_prjID, string cmpId)
        //{
        //    SqlConnection sqlConn = null;
        //    if (dgvWorkOrders.ColumnCount == 0)
        //    {
        //        var col1 = new DataGridViewLinkColumn();
        //        var col2 = new DataGridViewTextBoxColumn();
        //        var col3 = new DataGridViewTextBoxColumn();
        //        var col4 = new DataGridViewTextBoxColumn();
        //        var col5 = new DataGridViewTextBoxColumn();

        //        dgvWorkOrders.Columns.AddRange(new DataGridViewColumn[] { col1, col2, col3, col4, col5 });

        //        //dgvWorkOrders.AutoGenerateColumns = false;
        //        dgvWorkOrders.AllowUserToAddRows = false;
        //        dgvWorkOrders.AutoResizeColumns();

        //        col1.DataPropertyName = "workOrder_No";
        //        col1.HeaderText = "Work Order No.";
        //        col1.Resizable = System.Windows.Forms.DataGridViewTriState.True;

        //        col2.DataPropertyName = "ContractTitle";
        //        col2.HeaderText = "Work Order Title";
        //        //col2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
        //        col2.Width = 80;

        //        col3.DataPropertyName = "bidder_id";
        //        col3.HeaderText = "bidder_id";

        //        col4.DataPropertyName = "ContractAmount";
        //        col4.HeaderText = "ContractAmount";

        //        col5.DataPropertyName = "co_id";
        //        col5.HeaderText = "co_id";


        //        //col3.Resizable = System.Windows.Forms.DataGridViewTriState.True;

        //        dgvWorkOrders.ColumnHeadersDefaultCellStyle.BackColor = Color.Gainsboro;
        //        dgvWorkOrders.ColumnHeadersDefaultCellStyle.ForeColor = Color.Chocolate;
        //        dgvWorkOrders.ColumnHeadersDefaultCellStyle.Font = new Font(dgvWorkOrders.Font, FontStyle.Regular);
        //        dgvWorkOrders.EnableHeadersVisualStyles = false;
        //        dgvWorkOrders.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
        //    }
             
        //    try
        //    {        
        //        sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString());
        //        sqlConn.Open();

        //        string sqlQuery = "SELECT workOrderNo, workOrderTitle, bidder_id,co_id,workOrderAmount FROM WorkOrders WHERE proj_id = " + PC_prjID + " and co_Id=" + cmpId;
        //        cmnCls = new CommonClass(_userName);                
                
        //        //myBindingSource = new BindingSource();
        //        DataTable dtWorkOrders = cmnCls.GetDataTable(sqlQuery, sqlConn);
        //        if (dtWorkOrders.Rows.Count != 0)
        //        {
        //            dgvWorkOrders.DataSource = dtWorkOrders;                     
        //        }
        //        else
        //            dgvWorkOrders.DataSource = null;

        //        dgvWorkOrders.Columns[2].Visible = false;
        //        dgvWorkOrders.Columns[3].Visible = false;
        //        dgvWorkOrders.Columns[4].Visible = false;                 
        //    }
        //    catch (Exception ex)
        //    {
        //        string exMsg = ex.Message;
        //    }
        //    finally
        //    {
        //        sqlConn.Close();
        //    }
        //}
         
        static string strCon = ConfigurationManager.AppSettings["TCMSConnString"].ToString();
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (chk_dataExist == true)
            {
                try
                {
                    using (SqlConnection sqlConn = new SqlConnection(strCon))
                    {
                        using (SqlCommand cmd = new SqlCommand())
                        {
                            sqlConn.Open();
                            cmd.Connection = sqlConn;     //co_type_id = @cmpTypeID " proj_id = @prjID
                            cmd.CommandText = @"UPDATE CONTRACTORS SET " +
                            " contract_status_id = @cntrStatusID,co_id = @cmpID, " +
                            " contract_no = @CntrNO,[ContractTitle] =@cntrTitle,StartDate =@startDate,FinishDate =@endDate,[RevFinishDate] = @finishDate,[PB_Expiry_Date] = @PBE_Date,[PB_Ext1] = @PB1,[PB_Ext2] = @PB2," +
                            " Remarks = @Remarks,MaintenancePeriod = @MaintainPeriod,ContractDuration = @cntrDuration,ExtensionOfTime = @extTime Where bidder_id = @bidID";

                            if (txtMaintenencePeriod.Text!="")
                            cmd.Parameters.AddWithValue("@MaintainPeriod", Convert.ToInt16(txtMaintenencePeriod.Text));
                            else
                                cmd.Parameters.AddWithValue("@MaintainPeriod", DBNull.Value);

                            if (txtCntrDuration.Text != "")
                              cmd.Parameters.AddWithValue("@cntrDuration", Convert.ToInt16(txtCntrDuration.Text));
                            else
                                cmd.Parameters.AddWithValue("@cntrDuration", DBNull.Value);

                            if (txtDaysElapsed.Text != "")
                            cmd.Parameters.AddWithValue("@extTime", Convert.ToInt16(txtDaysElapsed.Text));
                            else
                                cmd.Parameters.AddWithValue("@extTime", DBNull.Value);

                            //Where bidder_id = @bidID

                            cmd.Parameters.AddWithValue("@bidID", _bidID);
                            cmd.Parameters.AddWithValue("@cntrStatusID", cmbContractStatus.SelectedValue);
                            //cmd.Parameters.AddWithValue("@prjID", _prjID);
                            //cmd.Parameters.AddWithValue("@stageId", 6);
                            cmd.Parameters.AddWithValue("@cmpID", cmbCompany.SelectedValue);
                            //cmd.Parameters.AddWithValue("@cmpTypeID", );  // CntrNO

                            cmd.Parameters.AddWithValue("@CntrNO", txtContractNo.Text);
                            cmd.Parameters.AddWithValue("@cntrTitle", txtContractTitle.Text);

                            if (dtpCntrStartDate.Text != " ")
                               cmd.Parameters.AddWithValue("@startDate", Convert.ToDateTime(dtpCntrStartDate.Text).ToString("dd/MMM/yyyy"));
                            else
                                cmd.Parameters.AddWithValue("@startDate", DBNull.Value);

                            if (dtpEndDate.Text != " ")
                                cmd.Parameters.AddWithValue("@endDate", Convert.ToDateTime(dtpEndDate.Text).ToString("dd/MMM/yyyy"));
                            else
                                cmd.Parameters.AddWithValue("@endDate", DBNull.Value);

                            if (dtpRevisedDate.Text != " ")
                                cmd.Parameters.AddWithValue("@finishDate", Convert.ToDateTime(dtpRevisedDate.Text).ToString("dd/MMM/yyyy"));
                            else
                                cmd.Parameters.AddWithValue("@finishDate", DBNull.Value);

                            if (dtpPerfomenseDate.Text != " ")
                                cmd.Parameters.AddWithValue("@PBE_Date", dtpPerfomenseDate.Value.ToString("dd/MMM/yyyy"));
                            else
                                cmd.Parameters.AddWithValue("@PBE_Date", DBNull.Value);

                            if (dtpPB_Ext1.Text != " ")
                                cmd.Parameters.AddWithValue("@PB1", dtpPB_Ext1.Value.ToString("dd/MMM/yyyy"));
                            else
                                cmd.Parameters.AddWithValue("@PB1", DBNull.Value);

                            if (dtpPB_Ext2.Text != " ")
                                cmd.Parameters.AddWithValue("@PB2", dtpPB_Ext2.Value.ToString("dd/MMM/yyyy"));
                            else
                                cmd.Parameters.AddWithValue("@PB2", DBNull.Value);

                            //if (dtpPB_Ext3.Text != " ")
                            //    cmd.Parameters.AddWithValue("@PB3", dtpPB_Ext3.Value.ToString("dd/MMM/yyyy"));
                            //else
                            //    cmd.Parameters.AddWithValue("@PB3", DBNull.Value);

                               cmd.Parameters.AddWithValue("@Remarks",txtPCRemarks.Text);
                                                    

                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                            MessageBox.Show("Rocords Updated SuccessFully ");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while Updating the UPDATE DATES records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            //int _prjCost_ID =  MaxCustomID(); 

            //SqlConnection sqlCon = new SqlConnection(strCon);
            //sqlCon.Open();
            //double pbond = 0.0;
            //SqlCommand sqlCom = new SqlCommand("INSERT INTO ProjectCost(cost_item_id,stage_id,proj_id,bidder_id,PerformanceBond) values (" +
            //"" + _prjCost_ID + ", " + 2 + "," + _prjID + "," + _bidID + "," + pbond + "", sqlCon);  //dTime.ToString("dd/MMM/yyyy");                       
            //sqlCom.ExecuteNonQuery();
            //sqlCon.Close();


            //int bidId = 0;
            //sqlConn.Open();
            //sqlCom = new SqlCommand("SELECT MAX(bidder_id) FROM CONTRACTORS");
            //bidId = Convert.ToInt16(sqlCom.ExecuteScalar());
            //bidId = bidId + 1;
            //sqlConn.Close();

            //int cmpType_Id = 0;
            //sqlConn.Open();
            //sqlCom = new SqlCommand("INSERT INTO CONTRACTORS(bidder_id,contract_status_id,Co_Id,co_type_id,[contract_no],[Contract Title],[ContractStartDat],[ContractFinishDat],[Revised Finish Dat],[Performance Bond Expiry Date],[PB Ext 1],[PB Ext 2],[PB Ext 3],Remarks) values (" +
            //"" + bidId + ", '" + cmbContractStatus.SelectedValue + "','" + cmbCompany.SelectedValue + "','" + cmpType_Id + "','" + txtContractNo.Text + "','" + txtContractTitle.Text + "','" + Convert.ToDateTime(dtpStartDate.Value).ToString("dd/MMM/yyyy") + "','" + Convert.ToDateTime(dtpEndDate.Value).ToString("dd/MMM/yyyy") + "','" + Convert.ToDateTime(dtpRevisedDate.Value).ToString("dd/MMM/yyyy") + "','" + Convert.ToDateTime(dtpPerfomenseDate.Value).ToString("dd/MMM/yyyy") + "'," + Convert.ToDateTime(dtpPB_Ext1.Value).ToString("dd/MMM/yyyy") + ",'" + Convert.ToDateTime(dtpPB_Ext2.Value).ToString("dd/MMM/yyyy") + "','" + Convert.ToDateTime(dtpPB_Ext3.Value).ToString("dd/MMM/yyyy") + "','" + txtRemarks.Text + "')", sqlConn);  //dTime.ToString("dd/MMM/yyyy");                       
            //sqlCom.ExecuteNonQuery();
            //sqlConn.Close();

            //MessageBox.Show("Company Info Inserted");
        }
        private int MaxCustomID()
        {
            int prjCostID  = 0;
            SqlConnection sqlConn = new SqlConnection(strCon);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("SELECT MAX(cost_item_id)+1 FROM PROJECTCOST");
            sqlCom.Connection = sqlConn;
            prjCostID = Convert.ToInt16(sqlCom.ExecuteScalar());            
            sqlConn.Close();
            return prjCostID;
        }
        Boolean chk_dataExist = false;
        private void frmContractsEntry_Load(object sender, EventArgs e)
        {
            loadContractsInfo();
            cmnCls.FillGridReceivedDocsInfo(_prjID, ref dgvCP_Rec, 6);
            cmnCls.FillGridSentDocsInfo(_prjID, ref dgvCP_Sent, 6);

            //txtPBtoExpire.Text = (System.DateTime.Now - dtpPB_Ext1.Value).ToString();
        }
        private void loadContractsInfo()
        {
            string sqlQuery = "SELECT CONTRACTORS.co_id, CONTRACTORS.co_type_id, CONTRACTORS.contract_no, CONTRACTORS.[ContractTitle], CONTRACTORS.StartDate, " +
                        " CONTRACTORS.FinishDate, CONTRACTORS.[RevFinishDate], CONTRACTORS.[PB_Expiry_Date], CONTRACTORS.[PB_Ext1], " +
                        " CONTRACTORS.[PB_Ext2], CONTRACTORS.[PB_Ext3], CONTRACTORS.Remarks, CONTRACTORS.proj_id, [ContractStatus].[ContractStatus], COMPANY.co_name, " +
                        " COMPANY_TYPE.co_type_name,CONTRACTORS.ContractDuration, CONTRACTORS.MaintenancePeriod,CONTRACTORS.ExtensionOfTime  FROM CONTRACTORS INNER JOIN [ContractStatus] ON CONTRACTORS.contract_status_id = [ContractStatus].contract_status_id INNER JOIN " +
                        " COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN COMPANY_TYPE ON COMPANY.co_type_id = COMPANY_TYPE.co_type_id WHERE (CONTRACTORS.bidder_Id = '" + _bidID + "' )";

            sqlConn = new SqlConnection(strCon);
            sqlConn.Open();
            sqlCom = new SqlCommand(sqlQuery, sqlConn);
            sqlReader = sqlCom.ExecuteReader();
            if (sqlReader.HasRows)
            {
                chk_dataExist = true;
                while (sqlReader.Read())
                {
                    txtContractNo.Text = sqlReader[2].ToString();
                    txtContractTitle.Text = sqlReader[3].ToString();
                    string strtDate = sqlReader[4].ToString();
                    string endDate = sqlReader[5].ToString();
                    string revisedDate = sqlReader[6].ToString();


                    if (strtDate != "")
                        dtpCntrStartDate.Text = Convert.ToDateTime(strtDate).ToString("dd/MMM/yyyy");

                    if (endDate != "")
                        dtpEndDate.Text = Convert.ToDateTime(endDate).ToString("dd/MMM/yyyy");

                    if (revisedDate != "")
                        dtpRevisedDate.Text = Convert.ToDateTime(revisedDate).ToString("dd/MMM/yyyy");

                    if (sqlReader[7].ToString() != "")
                        dtpPerfomenseDate.Text = Convert.ToDateTime(sqlReader[7]).ToString("dd/MMM/yyyy");

                    if (sqlReader[8].ToString() != "")
                        dtpPB_Ext1.Text = Convert.ToDateTime(sqlReader[8]).ToString("dd/MMM/yyyy");

                    if (sqlReader[9].ToString() != "")
                        dtpPB_Ext2.Text = Convert.ToDateTime(sqlReader[9]).ToString("dd/MMM/yyyy");

                    //if (sqlReader[10].ToString() != "")
                    //    dtpPB_Ext3.Text = Convert.ToDateTime(sqlReader[10]).ToString("dd/MMM/yyyy");

                    cmbCompany.Text = sqlReader[14].ToString();
                    mCmpName = cmbCompany.Text;
                    cmbContractStatus.Text = sqlReader[13].ToString();

                    txtPCRemarks.Text = sqlReader[11].ToString();

                    txtCmpType.Text = sqlReader[15].ToString();
                    txtCntrDuration.Text = sqlReader[16].ToString();
                    txtMaintenencePeriod.Text = sqlReader[17].ToString();
                    txtDaysElapsed.Text = sqlReader[18].ToString();
                }
            }
            sqlReader.Close();
            sqlConn.Close();
        }       
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        private void label7_Click(object sender, EventArgs e)
        {

        }
        private void dtpStartDate_ValueChanged(object sender, EventArgs e)
        {
            dtpCntrStartDate.CustomFormat = "dd/MMM/yyyy";
            dtpCntrStartDate.Text = dtpCntrStartDate.Value.ToString("dd/MMM/yyyy");
        }
        private void dtpEndDate_ValueChanged(object sender, EventArgs e)
        {
            dtpEndDate.CustomFormat = "dd/MMM/yyyy";
            dtpEndDate.Text = dtpEndDate.Value.ToString("dd/MMM/yyyy");
        }
        private void dtpRevisedDate_ValueChanged(object sender, EventArgs e)
        {
            dtpRevisedDate.CustomFormat = "dd/MMM/yyyy";
            dtpRevisedDate.Text = dtpRevisedDate.Value.ToString("dd/MMM/yyyy");
        }
        private void dtpPerfomenseDate_ValueChanged(object sender, EventArgs e)
        {
            dtpPerfomenseDate.CustomFormat = "dd/MMM/yyyy";
            dtpPerfomenseDate.Text = dtpPerfomenseDate.Value.ToString("dd/MMM/yyyy");
        }
        private void dtpPB_Ext1_ValueChanged(object sender, EventArgs e)
        {
            dtpPB_Ext1.CustomFormat = "dd/MMM/yyyy";
            dtpPB_Ext1.Text = dtpPB_Ext1.Value.ToString("dd/MMM/yyyy");
        }
        private void dtpPB_Ext2_ValueChanged(object sender, EventArgs e)
        {
            dtpPB_Ext2.CustomFormat = "dd/MMM/yyyy";
            dtpPB_Ext2.Text = dtpPB_Ext2.Value.ToString("dd/MMM/yyyy");
        }
       
        private void dtpStartDate_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Delete)
            {
                if (sender is DateTimePicker)
                {
                    dtpCntrStartDate.CustomFormat = " ";
                }
            }
        }
        private void dtpEndDate_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Delete)
            {
                if (sender is DateTimePicker)
                {
                    dtpEndDate.CustomFormat = " ";
                }
            }
        }
        private void dtpRevisedDate_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Delete)
            {
                if (sender is DateTimePicker)
                {
                    dtpRevisedDate.CustomFormat = " ";
                }
            }
        }
        private void dtpPerfomenseDate_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Delete)
            {
                if (sender is DateTimePicker)
                {
                    dtpPerfomenseDate.CustomFormat = " ";
                }
            }
        }
        private void dtpPB_Ext1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Delete)
            {
                if (sender is DateTimePicker)
                {
                    dtpPB_Ext1.CustomFormat = " ";
                }
            }
        }
        private void dtpPB_Ext2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Delete)
            {
                if (sender is DateTimePicker)
                {
                    dtpPB_Ext2.CustomFormat = " ";
                }
            }
        }      
        private void btnReceiveDoc_Click(object sender, EventArgs e)
        {
            TenderTrackingSystem.ReceivedDocProperties receivedFrm = new TenderTrackingSystem.ReceivedDocProperties(userRightsColl,_prjID, 6,_userName);
            receivedFrm.StartPosition = FormStartPosition.CenterParent;
            receivedFrm.ShowDialog();

            cmnCls.FillGridReceivedDocsInfo(_prjID,ref dgvCP_Rec, 6);

        }
        private void btnSentDoc_Click(object sender, EventArgs e)
        {
            TenderTrackingSystem.SentDocProperties sentFrm = new TenderTrackingSystem.SentDocProperties(userRightsColl, _prjID, 6,_userName);
            sentFrm.StartPosition = FormStartPosition.CenterParent;
            sentFrm.ShowDialog();

            cmnCls.FillGridSentDocsInfo(_prjID,ref dgvCP_Sent, 6);
        }
        private void dgvCP_Rec_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = e.RowIndex;
            try
            {
                if (rowIndex != -1)
                {
                    if (dgvCP_Rec.Rows[rowIndex].Cells[3].Value.ToString() != "")
                    {
                        int docId = Convert.ToInt16(dgvCP_Rec.Rows[rowIndex].Cells[3].Value);
                        ReceivedDocProperties receivedDoc = new ReceivedDocProperties(userRightsColl,_prjID, "", docId, 6,_userName);
                        receivedDoc.StartPosition = FormStartPosition.CenterParent;
                        receivedDoc.ShowDialog();
                        cmnCls.FillGridReceivedDocsInfo(_prjID, ref dgvCP_Rec, 6);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void dgvCP_Sent_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = e.RowIndex;             
            try
            {
                if (rowIndex != -1)
                {
                    if (dgvCP_Sent.Rows[rowIndex].Cells[0].Value.ToString() != "")
                    {
                        int docId = Convert.ToInt16(dgvCP_Sent.Rows[rowIndex].Cells[0].Value);
                        SentDocProperties sentDoc = new SentDocProperties(userRightsColl, _prjID, "", docId, 6, _userName,"",'Y',_isHeadOfSection);
                        sentDoc.StartPosition = FormStartPosition.CenterParent;
                        sentDoc.ShowDialog();
                        cmnCls.FillGridSentDocsInfo(_prjID,ref dgvCP_Sent, 6);
                    }
                }
            }
            catch
            {

            }
        }
        private void btnSentRefresh_Click(object sender, EventArgs e)
        {
            //cmnCls.FillGridSentDocsInfo(_prjID, dgvCP_Sent, 6);
        }
        private void btnRecRefresh_Click(object sender, EventArgs e)
        {
            //cmnCls.FillGridReceivedDocsInfo(_prjID, dgvCP_Rec, 6);
        }
        private void txtMaintenencePeriod_Leave(object sender, EventArgs e)
        {
            if (txtMaintenencePeriod.Text != "")
            {
                int tempMaintenence = Convert.ToInt16(txtMaintenencePeriod.Text);
                int tempDays = tempMaintenence + 90;

                dtpPerfomenseDate.Value = dtpEndDate.Value.AddDays(tempDays);
            }
        }

        private void dtpEndDate_Leave(object sender, EventArgs e)
        {
            if (txtMaintenencePeriod.Text != "")
            {
                int tempMaintenence = Convert.ToInt16(txtMaintenencePeriod.Text);
                int tempDays = tempMaintenence + 90;

                dtpPerfomenseDate.Value = dtpEndDate.Value.AddDays(tempDays);
            }
        }
        private void txtCntrDuration_Leave(object sender, EventArgs e)
        {
            if (txtCntrDuration.Text != "")
            {
                int tempCntrDuration = Convert.ToInt16(txtCntrDuration.Text);
                int tempDays = tempCntrDuration - 1;

                dtpEndDate.Value = dtpCntrStartDate.Value.AddDays(tempDays);
            }
        }

        private void dtpStartDate_Leave(object sender, EventArgs e)
        {
            if (txtCntrDuration.Text != "")
            {
                int tempCntrDuration = Convert.ToInt16(txtCntrDuration.Text);
                int tempDays = tempCntrDuration - 1;

                dtpEndDate.Value = dtpCntrStartDate.Value.AddDays(tempDays);
            }
        }

        private void cmbContractStatus_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (cmbContractStatus.Text.Equals("Completed") || cmbContractStatus.Text.Equals("Terminated") || cmbContractStatus.Text.Equals("Closed"))
            {
                txtPBtoExpire.Text = "";
            }
            else if (!cmbContractStatus.Text.Trim().Equals("On-going"))
            {
                if (dtpPB_Ext2.Value != null)
                {
                    txtPBtoExpire.Text = Convert.ToDateTime(dtpPB_Ext2.Value - System.DateTime.Now).ToString();
                }
                else if (dtpPB_Ext1.Value != null)
                {
                    txtPBtoExpire.Text = Convert.ToDateTime(dtpPB_Ext1.Value - System.DateTime.Now).ToString();
                }
                else if (dtpPerfomenseDate.Value != null)
                {
                    txtPBtoExpire.Text = Convert.ToDateTime(dtpPerfomenseDate.Value - System.DateTime.Now).ToString();
                }
            }

            if (cmbContractStatus.Text.Equals("On-going"))
            {
                if (dtpCntrStartDate.Text != " " || dtpCntrStartDate.Text == "")
                {
                    txtDaysElapsed.Text = (System.DateTime.Now.Date.Subtract(dtpCntrStartDate.Value)).Days.ToString();
                }
            }
            else
            {
                txtDaysElapsed.Text = "";
            }
        }

        private void dtpPB_Ext2_Leave(object sender, EventArgs e)
        {
            //if (dtpPB_Ext2.Value.ToString() != "")
            //{
            //    txtPBtoExpire.Text = (System.DateTime.Now - dtpPB_Ext2.Value).ToString();
            //}
        }
        private void dtpPB_Ext1_Leave(object sender, EventArgs e)
        {
            //if (dtpPB_Ext1.Value.ToString() != "")
            //{
            //    txtPBtoExpire.Text = (System.DateTime.Now - dtpPB_Ext1.Value).ToString();
            //}
        }

        private void btnNewWorkOrder_Click(object sender, EventArgs e)
        {
            //int bidId = Convert.ToInt16(dgvPC_Contracts.Rows[rowIndex].Cells[8].Value);
            //frmContractsEntry cntrEntry = null;
            //if (dgvPC_Contracts.Rows[rowIndex].Cells[2].Value.ToString().ToLower() != "framework")
            //cntrEntry = new frmContractsEntry(userRightsColl, bidId, _projID, null, _userName, _isHeadOfSection);
            //else
            //    cntrEntry = new frmContractsEntry(userRightsColl, bidId, _projID, dgvPC_Contracts.Rows[rowIndex].Cells[9].Value.ToString(), _userName, _isHeadOfSection);
            //cntrEntry.StartPosition = FormStartPosition.CenterParent;
            //cntrEntry.ShowDialog();

            //frmNewWorkOrder frmNewWorkOrder = new frmNewWorkOrder(userRightsColl, _bidID, _prjID, _userName, _isHeadOfSection, this, dgvWorkOrders);
            //frmNewWorkOrder.StartPosition = FormStartPosition.CenterParent;
            //frmNewWorkOrder.ShowDialog();             
        }

        //private void dgvWorkOrders_CellContentClick(object sender, DataGridViewCellEventArgs e)
        //{
        //    int rowIndex = e.RowIndex;
        //    int colIndex = e.ColumnIndex;
        //    try
        //    {
        //        if (rowIndex != -1)
        //        {
        //            if (colIndex == 1)
        //            {
        //                frmWorkOrderContractProcessDetails frmWOContract = null;
        //                string[] workOrderInfo = new string[6];
        //                workOrderInfo[0] = dgvWorkOrders.Rows[rowIndex].Cells[1].Value.ToString();
        //                workOrderInfo[1] = dgvWorkOrders.Rows[rowIndex].Cells[2].Value.ToString();
        //                workOrderInfo[2] = dgvWorkOrders.Rows[rowIndex].Cells[3].Value.ToString();
        //                workOrderInfo[3] = dgvWorkOrders.Rows[rowIndex].Cells[4].Value.ToString();
        //                workOrderInfo[4] = dgvWorkOrders.Rows[rowIndex].Cells[5].Value.ToString();
        //                workOrderInfo[5] = dgvWorkOrders.Rows[rowIndex].Cells[6].Value.ToString(); 
                                               
        //                frmWOContract = new frmWorkOrderContractProcessDetails(userRightsColl, _userName, workOrderInfo, _prjID, dgvWorkOrders, _isHeadOfSection, _projectTitle);
        //                frmWOContract.StartPosition = FormStartPosition.CenterParent;
        //                frmWOContract.ShowDialog();
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("Exception occurred while displaying the Work Orders", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //    }

        //}

        private void btnAddSiteInstruction_Click(object sender, EventArgs e)
        {

        }

        private void btnAddVarOrderDet_Click(object sender, EventArgs e)
        {
            frmAddVariationOrder frmAddVar = new frmAddVariationOrder(txtContractNo.Text.Trim(),_bidID);            
            frmAddVar.StartPosition = FormStartPosition.CenterParent;
            frmAddVar.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            frmAddSiteInstruction frmSite = new frmAddSiteInstruction(txtContractNo.Text.Trim(), _bidID);
            frmSite.StartPosition = FormStartPosition.CenterParent;
            frmSite.Show();
        }

            
    }
}
