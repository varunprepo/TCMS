﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MDI_ParenrForm.Projects
{
    public partial class frmAddSiteInstruction : Form
    {
        string mContractNo = null;
        int mBidderID = 0;
        public frmAddSiteInstruction(string contractNo, int bidderID)
        {
            InitializeComponent();
            mBidderID = bidderID;
            mContractNo = contractNo;
        }

        private void dtpSIReqDate_ValueChanged(object sender, EventArgs e)
        {
            if (mskSIComAppDate.Text != "")
            {
                if (Convert.ToDateTime(dtpSIReqDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(mskSIComAppDate.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                {
                    MessageBox.Show("SI Request Date cannot be greater than or equal to Committee Approval Date");
                    mskSIReqDate.Focus();
                    return;
                }
            }

            mskSIReqDate.Text = Convert.ToDateTime(dtpSIReqDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");            
        }


        private void dtpComAppDate_ValueChanged(object sender, EventArgs e)
        {
            if (mskSIReqDate.Text != "")
            {
                if (Convert.ToDateTime(dtpComAppDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(mskSIReqDate.Text)) <= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                {
                    MessageBox.Show("Committee Approval Date cannot be less than or equal to SI Request Date");
                    mskSIComAppDate.Focus();
                    return;
                }
            }

            mskSIComAppDate.Text = Convert.ToDateTime(dtpComAppDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
            txtVOSubDeadLine.Text = Convert.ToDateTime(mskSIComAppDate.Text).AddMonths(3).ToString("dd/MMM/yyyy hh:mm:ss tt");
        }

        private bool nonNumberEntered = false;
        private void ValidateNumericAndDecimalInput(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != 8 && e.KeyChar != 13) //&& e.KeyChar.ToString().Contains('.').ToString().Length>=2
            {
                nonNumberEntered = true;
            }
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                nonNumberEntered = true;
                e.Handled = true;
            }

            if (nonNumberEntered == true)
            {
                MessageBox.Show("Please enter number only...");
                e.Handled = true;
            }

            nonNumberEntered = false;
        }

        private void btnAddSiteIns_Click(object sender, EventArgs e)
        {
            if(txtSINo.Text.Trim().Equals(""))
            {
                MessageBox.Show("SI No. cannot be left blank");
                txtSINo.Focus();
                return;
            }
            else if (txtSIValue.Text.Trim().Equals(""))
            {
                MessageBox.Show("SI value cannot be left blank");
                txtSIValue.Focus();
                return;
            }
            else if (txtSIDur.Text.Trim().Equals(""))
            {
                MessageBox.Show("SI Duration cannot be left blank");
                txtSIDur.Focus();
                return;
            }
            else if (mskSIReqDate.Text.Trim().Equals(""))
            {
                MessageBox.Show("SI Request date cannot be left blank");
                mskSIReqDate.Focus();
                return;
            }
            else if (mskSIComAppDate.Text.Trim().Equals(""))
            {
                MessageBox.Show("SI Committee approval date cannot be left blank");
                mskSIComAppDate.Focus();
                return;
            }
            //else if(txtVOSubDeadLine.Text!="")
            //{
            //    MessageBox.Show("SI VO Submission deadLine cannot be left blank");
            //    txtVOSubDeadLine.Focus();
            //    return;
            //}

            try
            {
                //string voID = null;
                using (SqlConnection sqlConn = new SqlConnection(ConfigurationSettings.AppSettings["TCMSConnString"].ToString()))
                {                    
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        if (sqlConn.State == ConnectionState.Closed)
                            sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "AddOrUpdateSI";
                        cmd.Parameters.AddWithValue("@siID", SqlDbType.Int).Direction = ParameterDirection.Output;                         
                        cmd.Parameters.AddWithValue("@siNo", txtSINo.Text);
                        cmd.Parameters.AddWithValue("@siValue", Convert.ToDouble(txtSIValue.Text));
                        cmd.Parameters.AddWithValue("@siDuration", txtSIDur.Text);
                        cmd.Parameters.AddWithValue("@siRequestDate", Convert.ToDateTime(mskSIReqDate.Text).ToString("dd/MMM/yyyy hh:mm:ss tt"));
                        cmd.Parameters.AddWithValue("@siCommApprovalDate", Convert.ToDateTime(mskSIComAppDate.Text).ToString("dd/MMM/yyyy hh:mm:ss tt"));
                        cmd.Parameters.AddWithValue("@voSubmissionDeadline", txtVOSubDeadLine.Text);
                        if(rdBtnYes.Checked)
                        {
                            cmd.Parameters.AddWithValue("@isVoSubmitted", 1);
                        }
                        else
                        {
                            cmd.Parameters.AddWithValue("@isVoSubmitted", 0);
                        }
                        cmd.Parameters.AddWithValue("@contractNo", mContractNo);
                        cmd.Parameters.AddWithValue("@bidderId", mBidderID);
                        cmd.Parameters.AddWithValue("@isUpdate", 0);                        
                        cmd.ExecuteNonQuery();
                        //voID = cmd.Parameters["@voID"].Value.ToString();
                    }
                    //using (SqlCommand cmd = new SqlCommand())
                    //{
                    //    if (sqlConn.State == ConnectionState.Closed)
                    //        sqlConn.Open();
                    //    cmd.Connection = sqlConn;
                    //    foreach (DataGridViewRow dr in dgvVOReqDate.Rows)
                    //    {                             
                    //        cmd.CommandType = CommandType.Text;
                    //        cmd.Connection = sqlConn;
                    //        cmd.CommandText = "insert into VORequestDates (voID,voRequestDate) values (@voID,@voRequestDate)";
                    //        cmd.Parameters.AddWithValue("@voID",voID);
                    //        cmd.Parameters.AddWithValue("@voRequestDate", dr.Cells[0].Value.ToString());                            
                    //        cmd.ExecuteNonQuery();
                    //        cmd.Parameters.RemoveAt("@voID");
                    //        cmd.Parameters.RemoveAt("@voRequestDate");                            
                    //    }
                    //    foreach (DataGridViewRow dr in dgvCommDecDate.Rows)
                    //    {
                    //        cmd.CommandType = CommandType.Text;
                    //        cmd.Connection = sqlConn;
                    //        cmd.CommandText = "insert into VOCommDecDates (voID,voCommDecDate) values (@voID,@voCommDecDate)";
                    //        cmd.Parameters.AddWithValue("@voID", voID);
                    //        cmd.Parameters.AddWithValue("@voCommDecDate", dr.Cells[0].Value.ToString());                             
                    //        cmd.ExecuteNonQuery();
                    //        cmd.Parameters.RemoveAt("@voID");
                    //        cmd.Parameters.RemoveAt("@voCommDecDate");
                    //    }
                    //}
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Occurred while Adding the Site Instruction Order");                 
            }            
        

        }        

        private void txtSIValue_Leave(object sender, EventArgs e)
        {
            if (!txtSIValue.Text.Equals(""))
            {
                txtSIValue.Text = string.Format("{0:#,##0.00}", double.Parse(txtSIValue.Text));
            }
        }

        private void txtSIValue_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }
    }
}
