﻿namespace MDI_ParenrForm.Projects
{
    partial class frmProjectInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panelNewProjFromMoazzanah = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnMozanah = new System.Windows.Forms.Button();
            this.cmbMozMinistryCode = new System.Windows.Forms.ComboBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.txtMozBudget = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.txtMozProvision = new System.Windows.Forms.TextBox();
            this.cmbMozBudjetRefNo = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.cmbMozPrjID = new System.Windows.Forms.ComboBox();
            this.cmbFiscalYear = new System.Windows.Forms.ComboBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtProjCode = new System.Windows.Forms.TextBox();
            this.cmbMohTypeContract = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.txtProjTitleAr = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.txtProjTitleEn = new System.Windows.Forms.TextBox();
            this.btnMoazzanahProceed = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.btnMoazzanahCancel = new System.Windows.Forms.Button();
            this.cboMohTOTender = new System.Windows.Forms.ComboBox();
            this.cmbMohTenderCommittee = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.cmbMohAffairs = new System.Windows.Forms.ComboBox();
            this.cmbMohUserDept = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panelNewProjFromNonMoazzanah = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label32 = new System.Windows.Forms.Label();
            this.txtNonBudgetAmt = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.txtNonProvisionNo = new System.Windows.Forms.TextBox();
            this.cmbNonMozBudjetRef = new System.Windows.Forms.ComboBox();
            this.cmbNonMozMinistryCode = new System.Windows.Forms.ComboBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbNonMohTypeOfTender = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.lblNonMohProjCode = new System.Windows.Forms.Label();
            this.txtNonMohProjTitleAr = new System.Windows.Forms.TextBox();
            this.txtNonMohProjCode = new System.Windows.Forms.TextBox();
            this.lblNonMohProjTitleAr = new System.Windows.Forms.Label();
            this.lblNonMohFiscalYr = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblNonMohProjTitleEn = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNonMohProjTitleEn = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblNonMohTypeOfTender = new System.Windows.Forms.Label();
            this.lblProjIDNonMohMandatory = new System.Windows.Forms.Label();
            this.cmbNonMohTenderCommittee = new System.Windows.Forms.ComboBox();
            this.lblNonMohAffairs = new System.Windows.Forms.Label();
            this.cmbNonMohUserDept = new System.Windows.Forms.ComboBox();
            this.lblNonMohUserDept = new System.Windows.Forms.Label();
            this.cmbNonMohAffairs = new System.Windows.Forms.ComboBox();
            this.lblNonMohTenderCommittee = new System.Windows.Forms.Label();
            this.cmbNonMohFiscalYr = new System.Windows.Forms.ComboBox();
            this.btnNonMohCancel = new System.Windows.Forms.Button();
            this.cmbNonMohTypeOfContract = new System.Windows.Forms.ComboBox();
            this.btnNonMohProceed = new System.Windows.Forms.Button();
            this.lblNonlMohTypeOfProj = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panelNewProjFromMoazzanah.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panelNewProjFromNonMoazzanah.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tabControl1.Location = new System.Drawing.Point(27, 22);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.Padding = new System.Drawing.Point(10, 10);
            this.tabControl1.RightToLeftLayout = true;
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(595, 653);
            this.tabControl1.TabIndex = 1;
            this.tabControl1.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.tabControl1_DrawItem);
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            this.tabControl1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tabControl1_MouseClick);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Transparent;
            this.tabPage1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPage1.Controls.Add(this.panelNewProjFromMoazzanah);
            this.tabPage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World, ((byte)(8)));
            this.tabPage1.ForeColor = System.Drawing.Color.Blue;
            this.tabPage1.Location = new System.Drawing.Point(4, 36);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(587, 613);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Moazanah                             ";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panelNewProjFromMoazzanah
            // 
            this.panelNewProjFromMoazzanah.BackColor = System.Drawing.Color.FloralWhite;
            this.panelNewProjFromMoazzanah.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelNewProjFromMoazzanah.Controls.Add(this.groupBox2);
            this.panelNewProjFromMoazzanah.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelNewProjFromMoazzanah.Location = new System.Drawing.Point(-6, -2);
            this.panelNewProjFromMoazzanah.Name = "panelNewProjFromMoazzanah";
            this.panelNewProjFromMoazzanah.Size = new System.Drawing.Size(622, 613);
            this.panelNewProjFromMoazzanah.TabIndex = 14;
            this.panelNewProjFromMoazzanah.Paint += new System.Windows.Forms.PaintEventHandler(this.panelNewProjFromMoazzanah_Paint);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FloralWhite;
            this.groupBox2.Controls.Add(this.btnMozanah);
            this.groupBox2.Controls.Add(this.cmbMozMinistryCode);
            this.groupBox2.Controls.Add(this.label37);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.txtMozBudget);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.txtMozProvision);
            this.groupBox2.Controls.Add(this.cmbMozBudjetRefNo);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.cmbMozPrjID);
            this.groupBox2.Controls.Add(this.cmbFiscalYear);
            this.groupBox2.Controls.Add(this.label29);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label31);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.txtProjCode);
            this.groupBox2.Controls.Add(this.cmbMohTypeContract);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.txtProjTitleAr);
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.txtProjTitleEn);
            this.groupBox2.Controls.Add(this.btnMoazzanahProceed);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.btnMoazzanahCancel);
            this.groupBox2.Controls.Add(this.cboMohTOTender);
            this.groupBox2.Controls.Add(this.cmbMohTenderCommittee);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.cmbMohAffairs);
            this.groupBox2.Controls.Add(this.cmbMohUserDept);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Location = new System.Drawing.Point(-2, -10);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(618, 625);
            this.groupBox2.TabIndex = 44;
            this.groupBox2.TabStop = false;
            // 
            // btnMozanah
            // 
            this.btnMozanah.Location = new System.Drawing.Point(243, 64);
            this.btnMozanah.Name = "btnMozanah";
            this.btnMozanah.Size = new System.Drawing.Size(48, 23);
            this.btnMozanah.TabIndex = 2;
            this.btnMozanah.Text = "Submit";
            this.btnMozanah.UseVisualStyleBackColor = true;
            this.btnMozanah.Click += new System.EventHandler(this.btnMozanah_Click);
            // 
            // cmbMozMinistryCode
            // 
            this.cmbMozMinistryCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMozMinistryCode.FormattingEnabled = true;
            this.cmbMozMinistryCode.Location = new System.Drawing.Point(42, 468);
            this.cmbMozMinistryCode.Name = "cmbMozMinistryCode";
            this.cmbMozMinistryCode.Size = new System.Drawing.Size(196, 21);
            this.cmbMozMinistryCode.TabIndex = 12;
            this.cmbMozMinistryCode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbMozMinistryCode_KeyDown);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.Color.Red;
            this.label37.Location = new System.Drawing.Point(551, 178);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(14, 18);
            this.label37.TabIndex = 52;
            this.label37.Text = "*";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(551, 122);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(14, 18);
            this.label5.TabIndex = 51;
            this.label5.Text = "*";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.FloralWhite;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.Black;
            this.label26.Location = new System.Drawing.Point(355, 497);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(46, 15);
            this.label26.TabIndex = 49;
            this.label26.Text = "Budget";
            // 
            // txtMozBudget
            // 
            this.txtMozBudget.Location = new System.Drawing.Point(355, 520);
            this.txtMozBudget.Name = "txtMozBudget";
            this.txtMozBudget.Size = new System.Drawing.Size(190, 20);
            this.txtMozBudget.TabIndex = 15;
            this.txtMozBudget.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtMozBudjet_KeyDown);
            this.txtMozBudget.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMozBudjet_KeyPress);
            this.txtMozBudget.Leave += new System.EventHandler(this.txtMozBudjet_Leave);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.FloralWhite;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Black;
            this.label25.Location = new System.Drawing.Point(41, 496);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(76, 15);
            this.label25.TabIndex = 47;
            this.label25.Text = "Provision No";
            // 
            // txtMozProvision
            // 
            this.txtMozProvision.Location = new System.Drawing.Point(42, 520);
            this.txtMozProvision.Name = "txtMozProvision";
            this.txtMozProvision.Size = new System.Drawing.Size(196, 20);
            this.txtMozProvision.TabIndex = 14;
            // 
            // cmbMozBudjetRefNo
            // 
            this.cmbMozBudjetRefNo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMozBudjetRefNo.FormattingEnabled = true;
            this.cmbMozBudjetRefNo.Location = new System.Drawing.Point(355, 468);
            this.cmbMozBudjetRefNo.Name = "cmbMozBudjetRefNo";
            this.cmbMozBudjetRefNo.Size = new System.Drawing.Size(190, 21);
            this.cmbMozBudjetRefNo.TabIndex = 13;
            this.cmbMozBudjetRefNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbMozBudjetRefNo_KeyDown);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(551, 413);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(14, 18);
            this.label11.TabIndex = 45;
            this.label11.Text = "*";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.FloralWhite;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(41, 443);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(81, 15);
            this.label12.TabIndex = 43;
            this.label12.Text = "Ministry Code";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.FloralWhite;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Black;
            this.label24.Location = new System.Drawing.Point(355, 443);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(90, 15);
            this.label24.TabIndex = 42;
            this.label24.Text = "Budget Ref No ";
            // 
            // cmbMozPrjID
            // 
            this.cmbMozPrjID.FormattingEnabled = true;
            this.cmbMozPrjID.Location = new System.Drawing.Point(43, 65);
            this.cmbMozPrjID.Name = "cmbMozPrjID";
            this.cmbMozPrjID.Size = new System.Drawing.Size(195, 21);
            this.cmbMozPrjID.TabIndex = 1;
            this.cmbMozPrjID.SelectionChangeCommitted += new System.EventHandler(this.cmbMozPrjID_SelectionChangeCommitted);
            this.cmbMozPrjID.Leave += new System.EventHandler(this.cmbMozPrjID_Leave);
            // 
            // cmbFiscalYear
            // 
            this.cmbFiscalYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFiscalYear.FormattingEnabled = true;
            this.cmbFiscalYear.Location = new System.Drawing.Point(354, 413);
            this.cmbFiscalYear.Name = "cmbFiscalYear";
            this.cmbFiscalYear.Size = new System.Drawing.Size(191, 21);
            this.cmbFiscalYear.TabIndex = 11;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.Red;
            this.label29.Location = new System.Drawing.Point(244, 118);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(14, 18);
            this.label29.TabIndex = 40;
            this.label29.Text = "*";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(245, 357);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(14, 18);
            this.label13.TabIndex = 37;
            this.label13.Text = "*";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Red;
            this.label14.Location = new System.Drawing.Point(245, 412);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(14, 18);
            this.label14.TabIndex = 36;
            this.label14.Text = "*";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.Color.FloralWhite;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.Black;
            this.label31.Location = new System.Drawing.Point(41, 40);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(128, 15);
            this.label31.TabIndex = 1;
            this.label31.Text = "Moazzanah Project ID";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Red;
            this.label15.Location = new System.Drawing.Point(551, 361);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(14, 18);
            this.label15.TabIndex = 35;
            this.label15.Text = "*";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.FloralWhite;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.Black;
            this.label30.Location = new System.Drawing.Point(355, 40);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(77, 15);
            this.label30.TabIndex = 2;
            this.label30.Text = "Project Code";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Red;
            this.label16.Location = new System.Drawing.Point(551, 68);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(14, 18);
            this.label16.TabIndex = 34;
            this.label16.Text = "*";
            // 
            // txtProjCode
            // 
            this.txtProjCode.Location = new System.Drawing.Point(355, 65);
            this.txtProjCode.Name = "txtProjCode";
            this.txtProjCode.Size = new System.Drawing.Size(190, 20);
            this.txtProjCode.TabIndex = 3;
            this.txtProjCode.Leave += new System.EventHandler(this.txtProjCode_Leave);
            // 
            // cmbMohTypeContract
            // 
            this.cmbMohTypeContract.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMohTypeContract.FormattingEnabled = true;
            this.cmbMohTypeContract.Location = new System.Drawing.Point(42, 413);
            this.cmbMohTypeContract.Name = "cmbMohTypeContract";
            this.cmbMohTypeContract.Size = new System.Drawing.Size(197, 21);
            this.cmbMohTypeContract.TabIndex = 10;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.FloralWhite;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(41, 388);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(94, 15);
            this.label18.TabIndex = 31;
            this.label18.Text = "Type of Contract";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.FloralWhite;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.Black;
            this.label28.Location = new System.Drawing.Point(355, 388);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(67, 15);
            this.label28.TabIndex = 9;
            this.label28.Text = "Fiscal Year";
            // 
            // txtProjTitleAr
            // 
            this.txtProjTitleAr.Location = new System.Drawing.Point(42, 268);
            this.txtProjTitleAr.Multiline = true;
            this.txtProjTitleAr.Name = "txtProjTitleAr";
            this.txtProjTitleAr.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtProjTitleAr.Size = new System.Drawing.Size(503, 53);
            this.txtProjTitleAr.TabIndex = 7;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.FloralWhite;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.Black;
            this.label27.Location = new System.Drawing.Point(41, 153);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(128, 15);
            this.label27.TabIndex = 11;
            this.label27.Text = "Project Title In English\r\n";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.FloralWhite;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(41, 245);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(121, 15);
            this.label19.TabIndex = 29;
            this.label19.Text = "Project Title In Arabic";
            // 
            // txtProjTitleEn
            // 
            this.txtProjTitleEn.Location = new System.Drawing.Point(42, 177);
            this.txtProjTitleEn.Multiline = true;
            this.txtProjTitleEn.Name = "txtProjTitleEn";
            this.txtProjTitleEn.Size = new System.Drawing.Size(503, 54);
            this.txtProjTitleEn.TabIndex = 6;
            // 
            // btnMoazzanahProceed
            // 
            this.btnMoazzanahProceed.BackColor = System.Drawing.Color.Maroon;
            this.btnMoazzanahProceed.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMoazzanahProceed.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMoazzanahProceed.ForeColor = System.Drawing.Color.White;
            this.btnMoazzanahProceed.Location = new System.Drawing.Point(43, 559);
            this.btnMoazzanahProceed.Name = "btnMoazzanahProceed";
            this.btnMoazzanahProceed.Size = new System.Drawing.Size(70, 26);
            this.btnMoazzanahProceed.TabIndex = 16;
            this.btnMoazzanahProceed.Text = "Proceed";
            this.btnMoazzanahProceed.UseVisualStyleBackColor = false;
            this.btnMoazzanahProceed.Click += new System.EventHandler(this.btnMoazzanahProceed_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.FloralWhite;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Black;
            this.label23.Location = new System.Drawing.Point(355, 332);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(88, 15);
            this.label23.TabIndex = 19;
            this.label23.Text = "Type of Tender";
            // 
            // btnMoazzanahCancel
            // 
            this.btnMoazzanahCancel.BackColor = System.Drawing.Color.Maroon;
            this.btnMoazzanahCancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMoazzanahCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMoazzanahCancel.ForeColor = System.Drawing.Color.White;
            this.btnMoazzanahCancel.Location = new System.Drawing.Point(114, 559);
            this.btnMoazzanahCancel.Name = "btnMoazzanahCancel";
            this.btnMoazzanahCancel.Size = new System.Drawing.Size(70, 26);
            this.btnMoazzanahCancel.TabIndex = 17;
            this.btnMoazzanahCancel.Text = "Cancel";
            this.btnMoazzanahCancel.UseVisualStyleBackColor = false;
            this.btnMoazzanahCancel.Click += new System.EventHandler(this.btnMoazzanahCancel_Click);
            // 
            // cboMohTOTender
            // 
            this.cboMohTOTender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMohTOTender.FormattingEnabled = true;
            this.cboMohTOTender.Location = new System.Drawing.Point(355, 358);
            this.cboMohTOTender.Name = "cboMohTOTender";
            this.cboMohTOTender.Size = new System.Drawing.Size(190, 21);
            this.cboMohTOTender.TabIndex = 9;
            // 
            // cmbMohTenderCommittee
            // 
            this.cmbMohTenderCommittee.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMohTenderCommittee.FormattingEnabled = true;
            this.cmbMohTenderCommittee.Location = new System.Drawing.Point(42, 355);
            this.cmbMohTenderCommittee.Name = "cmbMohTenderCommittee";
            this.cmbMohTenderCommittee.Size = new System.Drawing.Size(196, 21);
            this.cmbMohTenderCommittee.TabIndex = 8;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.FloralWhite;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Black;
            this.label22.Location = new System.Drawing.Point(41, 98);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(40, 15);
            this.label22.TabIndex = 21;
            this.label22.Text = "Affairs";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.FloralWhite;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(41, 332);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(109, 15);
            this.label20.TabIndex = 25;
            this.label20.Text = "Tender Committee";
            // 
            // cmbMohAffairs
            // 
            this.cmbMohAffairs.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMohAffairs.FormattingEnabled = true;
            this.cmbMohAffairs.Location = new System.Drawing.Point(44, 119);
            this.cmbMohAffairs.Name = "cmbMohAffairs";
            this.cmbMohAffairs.Size = new System.Drawing.Size(194, 21);
            this.cmbMohAffairs.TabIndex = 4;
            this.cmbMohAffairs.SelectionChangeCommitted += new System.EventHandler(this.cmbMohAffairs_SelectionChangeCommitted);
            // 
            // cmbMohUserDept
            // 
            this.cmbMohUserDept.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMohUserDept.FormattingEnabled = true;
            this.cmbMohUserDept.Location = new System.Drawing.Point(355, 122);
            this.cmbMohUserDept.Name = "cmbMohUserDept";
            this.cmbMohUserDept.Size = new System.Drawing.Size(187, 21);
            this.cmbMohUserDept.TabIndex = 5;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.FloralWhite;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(355, 98);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(101, 15);
            this.label21.TabIndex = 23;
            this.label21.Text = "User Department";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.tabPage2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPage2.Controls.Add(this.panelNewProjFromNonMoazzanah);
            this.tabPage2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage2.ForeColor = System.Drawing.Color.Blue;
            this.tabPage2.Location = new System.Drawing.Point(4, 36);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(587, 613);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Non-Mozanah                            ";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // panelNewProjFromNonMoazzanah
            // 
            this.panelNewProjFromNonMoazzanah.BackColor = System.Drawing.Color.FloralWhite;
            this.panelNewProjFromNonMoazzanah.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelNewProjFromNonMoazzanah.Controls.Add(this.groupBox1);
            this.panelNewProjFromNonMoazzanah.Controls.Add(this.label6);
            this.panelNewProjFromNonMoazzanah.Location = new System.Drawing.Point(-6, -1);
            this.panelNewProjFromNonMoazzanah.Name = "panelNewProjFromNonMoazzanah";
            this.panelNewProjFromNonMoazzanah.Size = new System.Drawing.Size(590, 609);
            this.panelNewProjFromNonMoazzanah.TabIndex = 14;
            this.panelNewProjFromNonMoazzanah.Paint += new System.Windows.Forms.PaintEventHandler(this.panelNewProjFromNonMoazzanah_Paint);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label32);
            this.groupBox1.Controls.Add(this.txtNonBudgetAmt);
            this.groupBox1.Controls.Add(this.label33);
            this.groupBox1.Controls.Add(this.txtNonProvisionNo);
            this.groupBox1.Controls.Add(this.cmbNonMozBudjetRef);
            this.groupBox1.Controls.Add(this.cmbNonMozMinistryCode);
            this.groupBox1.Controls.Add(this.label35);
            this.groupBox1.Controls.Add(this.label36);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.cmbNonMohTypeOfTender);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.lblNonMohProjCode);
            this.groupBox1.Controls.Add(this.txtNonMohProjTitleAr);
            this.groupBox1.Controls.Add(this.txtNonMohProjCode);
            this.groupBox1.Controls.Add(this.lblNonMohProjTitleAr);
            this.groupBox1.Controls.Add(this.lblNonMohFiscalYr);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.lblNonMohProjTitleEn);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtNonMohProjTitleEn);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.lblNonMohTypeOfTender);
            this.groupBox1.Controls.Add(this.lblProjIDNonMohMandatory);
            this.groupBox1.Controls.Add(this.cmbNonMohTenderCommittee);
            this.groupBox1.Controls.Add(this.lblNonMohAffairs);
            this.groupBox1.Controls.Add(this.cmbNonMohUserDept);
            this.groupBox1.Controls.Add(this.lblNonMohUserDept);
            this.groupBox1.Controls.Add(this.cmbNonMohAffairs);
            this.groupBox1.Controls.Add(this.lblNonMohTenderCommittee);
            this.groupBox1.Controls.Add(this.cmbNonMohFiscalYr);
            this.groupBox1.Controls.Add(this.btnNonMohCancel);
            this.groupBox1.Controls.Add(this.cmbNonMohTypeOfContract);
            this.groupBox1.Controls.Add(this.btnNonMohProceed);
            this.groupBox1.Controls.Add(this.lblNonlMohTypeOfProj);
            this.groupBox1.Location = new System.Drawing.Point(2, -2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(585, 616);
            this.groupBox1.TabIndex = 43;
            this.groupBox1.TabStop = false;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.Color.FloralWhite;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.Black;
            this.label32.Location = new System.Drawing.Point(341, 486);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(46, 15);
            this.label32.TabIndex = 58;
            this.label32.Text = "Budget";
            // 
            // txtNonBudgetAmt
            // 
            this.txtNonBudgetAmt.Location = new System.Drawing.Point(341, 510);
            this.txtNonBudgetAmt.Name = "txtNonBudgetAmt";
            this.txtNonBudgetAmt.Size = new System.Drawing.Size(187, 20);
            this.txtNonBudgetAmt.TabIndex = 13;
            this.txtNonBudgetAmt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtNonBudjet_KeyDown);
            this.txtNonBudgetAmt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNonBudjet_KeyPress);
            this.txtNonBudgetAmt.Leave += new System.EventHandler(this.txtNonBudjet_Leave);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.Color.FloralWhite;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.Black;
            this.label33.Location = new System.Drawing.Point(38, 486);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(76, 15);
            this.label33.TabIndex = 56;
            this.label33.Text = "Provision No";
            // 
            // txtNonProvisionNo
            // 
            this.txtNonProvisionNo.Location = new System.Drawing.Point(41, 510);
            this.txtNonProvisionNo.Name = "txtNonProvisionNo";
            this.txtNonProvisionNo.Size = new System.Drawing.Size(190, 20);
            this.txtNonProvisionNo.TabIndex = 12;
            // 
            // cmbNonMozBudjetRef
            // 
            this.cmbNonMozBudjetRef.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNonMozBudjetRef.ForeColor = System.Drawing.SystemColors.WindowText;
            this.cmbNonMozBudjetRef.FormattingEnabled = true;
            this.cmbNonMozBudjetRef.Location = new System.Drawing.Point(341, 456);
            this.cmbNonMozBudjetRef.Name = "cmbNonMozBudjetRef";
            this.cmbNonMozBudjetRef.Size = new System.Drawing.Size(187, 21);
            this.cmbNonMozBudjetRef.TabIndex = 11;
            this.cmbNonMozBudjetRef.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbNonMozBudjetRef_KeyDown);
            // 
            // cmbNonMozMinistryCode
            // 
            this.cmbNonMozMinistryCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNonMozMinistryCode.ForeColor = System.Drawing.SystemColors.WindowText;
            this.cmbNonMozMinistryCode.FormattingEnabled = true;
            this.cmbNonMozMinistryCode.Location = new System.Drawing.Point(40, 455);
            this.cmbNonMozMinistryCode.Name = "cmbNonMozMinistryCode";
            this.cmbNonMozMinistryCode.Size = new System.Drawing.Size(190, 21);
            this.cmbNonMozMinistryCode.TabIndex = 10;
            this.cmbNonMozMinistryCode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbNonMozMinistryCode_KeyDown);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.BackColor = System.Drawing.Color.FloralWhite;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.Black;
            this.label35.Location = new System.Drawing.Point(38, 430);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(81, 15);
            this.label35.TabIndex = 52;
            this.label35.Text = "Ministry Code";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.Color.FloralWhite;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.Color.Black;
            this.label36.Location = new System.Drawing.Point(341, 431);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(90, 15);
            this.label36.TabIndex = 51;
            this.label36.Text = "Budget Ref No ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(534, 163);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(14, 18);
            this.label10.TabIndex = 49;
            this.label10.Text = "*";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(534, 114);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(14, 18);
            this.label9.TabIndex = 48;
            this.label9.Text = "*";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(234, 111);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(14, 18);
            this.label7.TabIndex = 47;
            this.label7.Text = "*";
            // 
            // cmbNonMohTypeOfTender
            // 
            this.cmbNonMohTypeOfTender.BackColor = System.Drawing.Color.White;
            this.cmbNonMohTypeOfTender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNonMohTypeOfTender.ForeColor = System.Drawing.SystemColors.WindowText;
            this.cmbNonMohTypeOfTender.FormattingEnabled = true;
            this.cmbNonMohTypeOfTender.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.cmbNonMohTypeOfTender.Location = new System.Drawing.Point(341, 340);
            this.cmbNonMohTypeOfTender.Name = "cmbNonMohTypeOfTender";
            this.cmbNonMohTypeOfTender.Size = new System.Drawing.Size(187, 21);
            this.cmbNonMohTypeOfTender.TabIndex = 7;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(235, 398);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(14, 18);
            this.label8.TabIndex = 46;
            this.label8.Text = "*";
            // 
            // lblNonMohProjCode
            // 
            this.lblNonMohProjCode.AutoSize = true;
            this.lblNonMohProjCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNonMohProjCode.ForeColor = System.Drawing.Color.Black;
            this.lblNonMohProjCode.Location = new System.Drawing.Point(38, 33);
            this.lblNonMohProjCode.Name = "lblNonMohProjCode";
            this.lblNonMohProjCode.Size = new System.Drawing.Size(77, 15);
            this.lblNonMohProjCode.TabIndex = 2;
            this.lblNonMohProjCode.Text = "Project Code";
            // 
            // txtNonMohProjTitleAr
            // 
            this.txtNonMohProjTitleAr.Location = new System.Drawing.Point(40, 252);
            this.txtNonMohProjTitleAr.Multiline = true;
            this.txtNonMohProjTitleAr.Name = "txtNonMohProjTitleAr";
            this.txtNonMohProjTitleAr.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtNonMohProjTitleAr.Size = new System.Drawing.Size(488, 54);
            this.txtNonMohProjTitleAr.TabIndex = 5;
            // 
            // txtNonMohProjCode
            // 
            this.txtNonMohProjCode.Location = new System.Drawing.Point(40, 55);
            this.txtNonMohProjCode.Name = "txtNonMohProjCode";
            this.txtNonMohProjCode.Size = new System.Drawing.Size(187, 20);
            this.txtNonMohProjCode.TabIndex = 1;
            this.txtNonMohProjCode.Leave += new System.EventHandler(this.txtNonMohProjCode_Leave);
            // 
            // lblNonMohProjTitleAr
            // 
            this.lblNonMohProjTitleAr.AutoSize = true;
            this.lblNonMohProjTitleAr.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNonMohProjTitleAr.ForeColor = System.Drawing.Color.Black;
            this.lblNonMohProjTitleAr.Location = new System.Drawing.Point(38, 227);
            this.lblNonMohProjTitleAr.Name = "lblNonMohProjTitleAr";
            this.lblNonMohProjTitleAr.Size = new System.Drawing.Size(121, 15);
            this.lblNonMohProjTitleAr.TabIndex = 43;
            this.lblNonMohProjTitleAr.Text = "Project Title In Arabic\r\n";
            // 
            // lblNonMohFiscalYr
            // 
            this.lblNonMohFiscalYr.AutoSize = true;
            this.lblNonMohFiscalYr.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNonMohFiscalYr.ForeColor = System.Drawing.Color.Black;
            this.lblNonMohFiscalYr.Location = new System.Drawing.Point(38, 371);
            this.lblNonMohFiscalYr.Name = "lblNonMohFiscalYr";
            this.lblNonMohFiscalYr.Size = new System.Drawing.Size(67, 15);
            this.lblNonMohFiscalYr.TabIndex = 9;
            this.lblNonMohFiscalYr.Text = "Fiscal Year";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(532, 397);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(14, 18);
            this.label4.TabIndex = 41;
            this.label4.Text = "*";
            // 
            // lblNonMohProjTitleEn
            // 
            this.lblNonMohProjTitleEn.AutoSize = true;
            this.lblNonMohProjTitleEn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNonMohProjTitleEn.ForeColor = System.Drawing.Color.Black;
            this.lblNonMohProjTitleEn.Location = new System.Drawing.Point(38, 138);
            this.lblNonMohProjTitleEn.Name = "lblNonMohProjTitleEn";
            this.lblNonMohProjTitleEn.Size = new System.Drawing.Size(128, 15);
            this.lblNonMohProjTitleEn.TabIndex = 11;
            this.lblNonMohProjTitleEn.Text = "Project Title In English";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(235, 342);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(14, 18);
            this.label3.TabIndex = 40;
            this.label3.Text = "*";
            // 
            // txtNonMohProjTitleEn
            // 
            this.txtNonMohProjTitleEn.Location = new System.Drawing.Point(40, 164);
            this.txtNonMohProjTitleEn.Multiline = true;
            this.txtNonMohProjTitleEn.Name = "txtNonMohProjTitleEn";
            this.txtNonMohProjTitleEn.Size = new System.Drawing.Size(488, 54);
            this.txtNonMohProjTitleEn.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(532, 340);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(14, 18);
            this.label2.TabIndex = 39;
            this.label2.Text = "*";
            // 
            // lblNonMohTypeOfTender
            // 
            this.lblNonMohTypeOfTender.AutoSize = true;
            this.lblNonMohTypeOfTender.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNonMohTypeOfTender.ForeColor = System.Drawing.Color.Black;
            this.lblNonMohTypeOfTender.Location = new System.Drawing.Point(341, 317);
            this.lblNonMohTypeOfTender.Name = "lblNonMohTypeOfTender";
            this.lblNonMohTypeOfTender.Size = new System.Drawing.Size(88, 15);
            this.lblNonMohTypeOfTender.TabIndex = 19;
            this.lblNonMohTypeOfTender.Text = "Type of Tender";
            // 
            // lblProjIDNonMohMandatory
            // 
            this.lblProjIDNonMohMandatory.AutoSize = true;
            this.lblProjIDNonMohMandatory.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjIDNonMohMandatory.ForeColor = System.Drawing.Color.Red;
            this.lblProjIDNonMohMandatory.Location = new System.Drawing.Point(235, 55);
            this.lblProjIDNonMohMandatory.Name = "lblProjIDNonMohMandatory";
            this.lblProjIDNonMohMandatory.Size = new System.Drawing.Size(14, 18);
            this.lblProjIDNonMohMandatory.TabIndex = 38;
            this.lblProjIDNonMohMandatory.Text = "*";
            // 
            // cmbNonMohTenderCommittee
            // 
            this.cmbNonMohTenderCommittee.BackColor = System.Drawing.Color.White;
            this.cmbNonMohTenderCommittee.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNonMohTenderCommittee.ForeColor = System.Drawing.SystemColors.WindowText;
            this.cmbNonMohTenderCommittee.FormattingEnabled = true;
            this.cmbNonMohTenderCommittee.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.cmbNonMohTenderCommittee.Location = new System.Drawing.Point(40, 340);
            this.cmbNonMohTenderCommittee.Name = "cmbNonMohTenderCommittee";
            this.cmbNonMohTenderCommittee.Size = new System.Drawing.Size(187, 21);
            this.cmbNonMohTenderCommittee.TabIndex = 6;
            this.cmbNonMohTenderCommittee.SelectedIndexChanged += new System.EventHandler(this.cmbNonMohTenderCommittee_SelectedIndexChanged);
            // 
            // lblNonMohAffairs
            // 
            this.lblNonMohAffairs.AutoSize = true;
            this.lblNonMohAffairs.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNonMohAffairs.ForeColor = System.Drawing.Color.Black;
            this.lblNonMohAffairs.Location = new System.Drawing.Point(38, 84);
            this.lblNonMohAffairs.Name = "lblNonMohAffairs";
            this.lblNonMohAffairs.Size = new System.Drawing.Size(40, 15);
            this.lblNonMohAffairs.TabIndex = 21;
            this.lblNonMohAffairs.Text = "Affairs";
            // 
            // cmbNonMohUserDept
            // 
            this.cmbNonMohUserDept.BackColor = System.Drawing.Color.White;
            this.cmbNonMohUserDept.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNonMohUserDept.ForeColor = System.Drawing.SystemColors.WindowText;
            this.cmbNonMohUserDept.FormattingEnabled = true;
            this.cmbNonMohUserDept.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.cmbNonMohUserDept.Location = new System.Drawing.Point(341, 112);
            this.cmbNonMohUserDept.Name = "cmbNonMohUserDept";
            this.cmbNonMohUserDept.Size = new System.Drawing.Size(187, 21);
            this.cmbNonMohUserDept.TabIndex = 3;
            // 
            // lblNonMohUserDept
            // 
            this.lblNonMohUserDept.AutoSize = true;
            this.lblNonMohUserDept.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNonMohUserDept.ForeColor = System.Drawing.Color.Black;
            this.lblNonMohUserDept.Location = new System.Drawing.Point(341, 84);
            this.lblNonMohUserDept.Name = "lblNonMohUserDept";
            this.lblNonMohUserDept.Size = new System.Drawing.Size(101, 15);
            this.lblNonMohUserDept.TabIndex = 23;
            this.lblNonMohUserDept.Text = "User Department";
            // 
            // cmbNonMohAffairs
            // 
            this.cmbNonMohAffairs.BackColor = System.Drawing.Color.White;
            this.cmbNonMohAffairs.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNonMohAffairs.ForeColor = System.Drawing.SystemColors.WindowText;
            this.cmbNonMohAffairs.FormattingEnabled = true;
            this.cmbNonMohAffairs.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.cmbNonMohAffairs.Location = new System.Drawing.Point(40, 108);
            this.cmbNonMohAffairs.Name = "cmbNonMohAffairs";
            this.cmbNonMohAffairs.Size = new System.Drawing.Size(187, 21);
            this.cmbNonMohAffairs.TabIndex = 2;
            this.cmbNonMohAffairs.SelectionChangeCommitted += new System.EventHandler(this.cmbNonMohAffairs_SelectionChangeCommitted);
            // 
            // lblNonMohTenderCommittee
            // 
            this.lblNonMohTenderCommittee.AutoSize = true;
            this.lblNonMohTenderCommittee.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNonMohTenderCommittee.ForeColor = System.Drawing.Color.Black;
            this.lblNonMohTenderCommittee.Location = new System.Drawing.Point(38, 316);
            this.lblNonMohTenderCommittee.Name = "lblNonMohTenderCommittee";
            this.lblNonMohTenderCommittee.Size = new System.Drawing.Size(109, 15);
            this.lblNonMohTenderCommittee.TabIndex = 25;
            this.lblNonMohTenderCommittee.Text = "Tender Committee";
            // 
            // cmbNonMohFiscalYr
            // 
            this.cmbNonMohFiscalYr.BackColor = System.Drawing.Color.White;
            this.cmbNonMohFiscalYr.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNonMohFiscalYr.ForeColor = System.Drawing.SystemColors.WindowText;
            this.cmbNonMohFiscalYr.FormattingEnabled = true;
            this.cmbNonMohFiscalYr.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.cmbNonMohFiscalYr.Location = new System.Drawing.Point(40, 397);
            this.cmbNonMohFiscalYr.Name = "cmbNonMohFiscalYr";
            this.cmbNonMohFiscalYr.Size = new System.Drawing.Size(187, 21);
            this.cmbNonMohFiscalYr.TabIndex = 8;
            // 
            // btnNonMohCancel
            // 
            this.btnNonMohCancel.BackColor = System.Drawing.Color.Maroon;
            this.btnNonMohCancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNonMohCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNonMohCancel.ForeColor = System.Drawing.Color.White;
            this.btnNonMohCancel.Location = new System.Drawing.Point(111, 552);
            this.btnNonMohCancel.Name = "btnNonMohCancel";
            this.btnNonMohCancel.Size = new System.Drawing.Size(70, 26);
            this.btnNonMohCancel.TabIndex = 15;
            this.btnNonMohCancel.Text = "Close";
            this.btnNonMohCancel.UseVisualStyleBackColor = false;
            this.btnNonMohCancel.Click += new System.EventHandler(this.btnNonMohCancel_Click);
            // 
            // cmbNonMohTypeOfContract
            // 
            this.cmbNonMohTypeOfContract.BackColor = System.Drawing.Color.White;
            this.cmbNonMohTypeOfContract.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNonMohTypeOfContract.ForeColor = System.Drawing.SystemColors.WindowText;
            this.cmbNonMohTypeOfContract.FormattingEnabled = true;
            this.cmbNonMohTypeOfContract.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.cmbNonMohTypeOfContract.Location = new System.Drawing.Point(341, 397);
            this.cmbNonMohTypeOfContract.Name = "cmbNonMohTypeOfContract";
            this.cmbNonMohTypeOfContract.Size = new System.Drawing.Size(187, 21);
            this.cmbNonMohTypeOfContract.TabIndex = 9;
            // 
            // btnNonMohProceed
            // 
            this.btnNonMohProceed.BackColor = System.Drawing.Color.Maroon;
            this.btnNonMohProceed.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNonMohProceed.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNonMohProceed.ForeColor = System.Drawing.Color.White;
            this.btnNonMohProceed.Location = new System.Drawing.Point(40, 552);
            this.btnNonMohProceed.Name = "btnNonMohProceed";
            this.btnNonMohProceed.Size = new System.Drawing.Size(70, 26);
            this.btnNonMohProceed.TabIndex = 14;
            this.btnNonMohProceed.Text = "Proceed";
            this.btnNonMohProceed.UseVisualStyleBackColor = false;
            this.btnNonMohProceed.Click += new System.EventHandler(this.btnNonMohProceed_Click);
            // 
            // lblNonlMohTypeOfProj
            // 
            this.lblNonlMohTypeOfProj.AutoSize = true;
            this.lblNonlMohTypeOfProj.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNonlMohTypeOfProj.ForeColor = System.Drawing.Color.Black;
            this.lblNonlMohTypeOfProj.Location = new System.Drawing.Point(341, 371);
            this.lblNonlMohTypeOfProj.Name = "lblNonlMohTypeOfProj";
            this.lblNonlMohTypeOfProj.Size = new System.Drawing.Size(94, 15);
            this.lblNonlMohTypeOfProj.TabIndex = 32;
            this.lblNonlMohTypeOfProj.Text = "Type of Contract";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(471, 146);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(14, 18);
            this.label6.TabIndex = 45;
            this.label6.Text = "*";
            // 
            // frmProjectInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FloralWhite;
            this.ClientSize = new System.Drawing.Size(648, 701);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmProjectInfo";
            this.RightToLeftLayout = true;
            this.Text = "Add New Project";
            this.Load += new System.EventHandler(this.frmProjectInfo_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.frmProjectInfo_Paint);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panelNewProjFromMoazzanah.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.panelNewProjFromNonMoazzanah.ResumeLayout(false);
            this.panelNewProjFromNonMoazzanah.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Panel panelNewProjFromMoazzanah;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox cmbMohTypeContract;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtProjTitleAr;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btnMoazzanahProceed;
        private System.Windows.Forms.Button btnMoazzanahCancel;
        private System.Windows.Forms.ComboBox cmbMohTenderCommittee;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox cmbMohUserDept;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox cmbMohAffairs;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox cboMohTOTender;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtProjTitleEn;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtProjCode;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panelNewProjFromNonMoazzanah;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtNonMohProjTitleAr;
        private System.Windows.Forms.Label lblNonMohProjTitleAr;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblProjIDNonMohMandatory;
        private System.Windows.Forms.ComboBox cmbNonMohTenderCommittee;
        private System.Windows.Forms.ComboBox cmbNonMohUserDept;
        private System.Windows.Forms.ComboBox cmbNonMohAffairs;
        private System.Windows.Forms.ComboBox cmbNonMohFiscalYr;
        private System.Windows.Forms.ComboBox cmbNonMohTypeOfContract;
        private System.Windows.Forms.Label lblNonlMohTypeOfProj;
        private System.Windows.Forms.Button btnNonMohCancel;
        private System.Windows.Forms.Label lblNonMohTenderCommittee;
        private System.Windows.Forms.Label lblNonMohUserDept;
        private System.Windows.Forms.Label lblNonMohAffairs;
        private System.Windows.Forms.Label lblNonMohTypeOfTender;
        private System.Windows.Forms.TextBox txtNonMohProjTitleEn;
        private System.Windows.Forms.Label lblNonMohProjTitleEn;
        private System.Windows.Forms.Label lblNonMohFiscalYr;
        private System.Windows.Forms.TextBox txtNonMohProjCode;
        private System.Windows.Forms.Label lblNonMohProjCode;
        private System.Windows.Forms.ComboBox cmbFiscalYear;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox cmbNonMohTypeOfTender;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbMozPrjID;
        private System.Windows.Forms.Button btnNonMohProceed;
        private System.Windows.Forms.ComboBox cmbMozBudjetRefNo;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtMozBudget;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtMozProvision;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox txtNonBudgetAmt;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txtNonProvisionNo;
        private System.Windows.Forms.ComboBox cmbNonMozBudjetRef;
        private System.Windows.Forms.ComboBox cmbNonMozMinistryCode;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbMozMinistryCode;
        private System.Windows.Forms.Button btnMozanah;

    }
}