﻿namespace MDI_ParenrForm.Projects
{
    partial class frmBidderInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtProjectCode = new System.Windows.Forms.TextBox();
            this.txtTenderNo = new System.Windows.Forms.TextBox();
            this.txtClosingDate = new System.Windows.Forms.TextBox();
            this.txtTenderTitle = new System.Windows.Forms.TextBox();
            this.txtModifiedDate = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnReportInExcel = new System.Windows.Forms.Button();
            this.txtProjectType = new System.Windows.Forms.TextBox();
            this.lblProjectType = new System.Windows.Forms.Label();
            this.btnDeleteFromShortList = new System.Windows.Forms.Button();
            this.btnEmailCirculars = new System.Windows.Forms.Button();
            this.btnDeleteBidder = new System.Windows.Forms.Button();
            this.cmbCircularNo = new System.Windows.Forms.ComboBox();
            this.btnBidEdit = new System.Windows.Forms.Button();
            this.lblCircularNo = new System.Windows.Forms.Label();
            this.dgViewCircularInfo = new System.Windows.Forms.DataGridView();
            this.btnExportToPdf = new System.Windows.Forms.Button();
            this.dgViewBidders = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgViewCircularInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgViewBidders)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(7, 23);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Project Code";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Maroon;
            this.label2.Location = new System.Drawing.Point(347, 24);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tender No";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Maroon;
            this.label3.Location = new System.Drawing.Point(632, 24);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Tender Closing Date";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Maroon;
            this.label4.Location = new System.Drawing.Point(4, 79);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Tender Title";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Maroon;
            this.label5.Location = new System.Drawing.Point(632, 74);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(149, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "Modified Closing Date";
            // 
            // txtProjectCode
            // 
            this.txtProjectCode.Location = new System.Drawing.Point(7, 43);
            this.txtProjectCode.Margin = new System.Windows.Forms.Padding(4);
            this.txtProjectCode.Name = "txtProjectCode";
            this.txtProjectCode.Size = new System.Drawing.Size(204, 21);
            this.txtProjectCode.TabIndex = 6;
            // 
            // txtTenderNo
            // 
            this.txtTenderNo.Location = new System.Drawing.Point(350, 44);
            this.txtTenderNo.Margin = new System.Windows.Forms.Padding(4);
            this.txtTenderNo.Name = "txtTenderNo";
            this.txtTenderNo.Size = new System.Drawing.Size(204, 21);
            this.txtTenderNo.TabIndex = 7;
            // 
            // txtClosingDate
            // 
            this.txtClosingDate.Location = new System.Drawing.Point(635, 43);
            this.txtClosingDate.Margin = new System.Windows.Forms.Padding(4);
            this.txtClosingDate.Name = "txtClosingDate";
            this.txtClosingDate.Size = new System.Drawing.Size(206, 21);
            this.txtClosingDate.TabIndex = 8;
            // 
            // txtTenderTitle
            // 
            this.txtTenderTitle.Location = new System.Drawing.Point(10, 100);
            this.txtTenderTitle.Margin = new System.Windows.Forms.Padding(4);
            this.txtTenderTitle.Multiline = true;
            this.txtTenderTitle.Name = "txtTenderTitle";
            this.txtTenderTitle.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtTenderTitle.Size = new System.Drawing.Size(544, 68);
            this.txtTenderTitle.TabIndex = 9;
            // 
            // txtModifiedDate
            // 
            this.txtModifiedDate.Location = new System.Drawing.Point(635, 93);
            this.txtModifiedDate.Margin = new System.Windows.Forms.Padding(4);
            this.txtModifiedDate.Name = "txtModifiedDate";
            this.txtModifiedDate.Size = new System.Drawing.Size(206, 21);
            this.txtModifiedDate.TabIndex = 10;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnReportInExcel);
            this.groupBox1.Controls.Add(this.txtProjectType);
            this.groupBox1.Controls.Add(this.lblProjectType);
            this.groupBox1.Controls.Add(this.btnDeleteFromShortList);
            this.groupBox1.Controls.Add(this.btnEmailCirculars);
            this.groupBox1.Controls.Add(this.btnDeleteBidder);
            this.groupBox1.Controls.Add(this.cmbCircularNo);
            this.groupBox1.Controls.Add(this.btnBidEdit);
            this.groupBox1.Controls.Add(this.lblCircularNo);
            this.groupBox1.Controls.Add(this.dgViewCircularInfo);
            this.groupBox1.Controls.Add(this.btnExportToPdf);
            this.groupBox1.Controls.Add(this.dgViewBidders);
            this.groupBox1.Controls.Add(this.txtProjectCode);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtModifiedDate);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtTenderTitle);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtClosingDate);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtTenderNo);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(3, 10);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(1176, 784);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Bidder Information";
            // 
            // btnReportInExcel
            // 
            this.btnReportInExcel.BackColor = System.Drawing.Color.Maroon;
            this.btnReportInExcel.ForeColor = System.Drawing.Color.White;
            this.btnReportInExcel.Location = new System.Drawing.Point(367, 186);
            this.btnReportInExcel.Name = "btnReportInExcel";
            this.btnReportInExcel.Size = new System.Drawing.Size(130, 31);
            this.btnReportInExcel.TabIndex = 21;
            this.btnReportInExcel.Text = "View Report In Excel";
            this.btnReportInExcel.UseVisualStyleBackColor = false;
            this.btnReportInExcel.Click += new System.EventHandler(this.btnReportInExcel_Click);
            // 
            // txtProjectType
            // 
            this.txtProjectType.Location = new System.Drawing.Point(635, 147);
            this.txtProjectType.Margin = new System.Windows.Forms.Padding(4);
            this.txtProjectType.Name = "txtProjectType";
            this.txtProjectType.Size = new System.Drawing.Size(206, 21);
            this.txtProjectType.TabIndex = 20;
            // 
            // lblProjectType
            // 
            this.lblProjectType.AutoSize = true;
            this.lblProjectType.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectType.ForeColor = System.Drawing.Color.Maroon;
            this.lblProjectType.Location = new System.Drawing.Point(632, 124);
            this.lblProjectType.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblProjectType.Name = "lblProjectType";
            this.lblProjectType.Size = new System.Drawing.Size(120, 15);
            this.lblProjectType.TabIndex = 19;
            this.lblProjectType.Text = "Eligible Tenders :";
            // 
            // btnDeleteFromShortList
            // 
            this.btnDeleteFromShortList.BackColor = System.Drawing.Color.Maroon;
            this.btnDeleteFromShortList.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteFromShortList.ForeColor = System.Drawing.Color.White;
            this.btnDeleteFromShortList.Location = new System.Drawing.Point(173, 186);
            this.btnDeleteFromShortList.Name = "btnDeleteFromShortList";
            this.btnDeleteFromShortList.Size = new System.Drawing.Size(183, 31);
            this.btnDeleteFromShortList.TabIndex = 18;
            this.btnDeleteFromShortList.Text = "Delete From Short List";
            this.btnDeleteFromShortList.UseVisualStyleBackColor = false;
            this.btnDeleteFromShortList.Click += new System.EventHandler(this.btnDeleteFromShortList_Click);
            // 
            // btnEmailCirculars
            // 
            this.btnEmailCirculars.BackColor = System.Drawing.Color.Maroon;
            this.btnEmailCirculars.ForeColor = System.Drawing.Color.White;
            this.btnEmailCirculars.Location = new System.Drawing.Point(648, 187);
            this.btnEmailCirculars.Name = "btnEmailCirculars";
            this.btnEmailCirculars.Size = new System.Drawing.Size(179, 31);
            this.btnEmailCirculars.TabIndex = 13;
            this.btnEmailCirculars.Text = "Email Circulars To All Bidders";
            this.btnEmailCirculars.UseVisualStyleBackColor = false;
            this.btnEmailCirculars.Click += new System.EventHandler(this.btnEmailCirculars_Click);
            // 
            // btnDeleteBidder
            // 
            this.btnDeleteBidder.BackColor = System.Drawing.Color.Maroon;
            this.btnDeleteBidder.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.btnDeleteBidder.ForeColor = System.Drawing.Color.White;
            this.btnDeleteBidder.Location = new System.Drawing.Point(95, 186);
            this.btnDeleteBidder.Name = "btnDeleteBidder";
            this.btnDeleteBidder.Size = new System.Drawing.Size(72, 31);
            this.btnDeleteBidder.TabIndex = 3;
            this.btnDeleteBidder.Text = "Delete";
            this.btnDeleteBidder.UseVisualStyleBackColor = false;
            this.btnDeleteBidder.Click += new System.EventHandler(this.btnDeleteBidder_Click);
            // 
            // cmbCircularNo
            // 
            this.cmbCircularNo.FormattingEnabled = true;
            this.cmbCircularNo.Location = new System.Drawing.Point(917, 194);
            this.cmbCircularNo.Name = "cmbCircularNo";
            this.cmbCircularNo.Size = new System.Drawing.Size(43, 23);
            this.cmbCircularNo.TabIndex = 17;
            this.cmbCircularNo.SelectionChangeCommitted += new System.EventHandler(this.cmbCircularNo_SelectionChangeCommitted);
            // 
            // btnBidEdit
            // 
            this.btnBidEdit.BackColor = System.Drawing.Color.Maroon;
            this.btnBidEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBidEdit.ForeColor = System.Drawing.Color.White;
            this.btnBidEdit.Location = new System.Drawing.Point(10, 186);
            this.btnBidEdit.Name = "btnBidEdit";
            this.btnBidEdit.Size = new System.Drawing.Size(79, 31);
            this.btnBidEdit.TabIndex = 1;
            this.btnBidEdit.Text = "Edit";
            this.btnBidEdit.UseVisualStyleBackColor = false;
            this.btnBidEdit.Click += new System.EventHandler(this.btnBidEdit_Click);
            // 
            // lblCircularNo
            // 
            this.lblCircularNo.AutoSize = true;
            this.lblCircularNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCircularNo.ForeColor = System.Drawing.Color.Maroon;
            this.lblCircularNo.Location = new System.Drawing.Point(838, 198);
            this.lblCircularNo.Name = "lblCircularNo";
            this.lblCircularNo.Size = new System.Drawing.Size(73, 19);
            this.lblCircularNo.TabIndex = 16;
            this.lblCircularNo.Text = "Circular No.";
            this.lblCircularNo.UseCompatibleTextRendering = true;
            // 
            // dgViewCircularInfo
            // 
            this.dgViewCircularInfo.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgViewCircularInfo.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dgViewCircularInfo.BackgroundColor = System.Drawing.Color.Cornsilk;
            this.dgViewCircularInfo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.HotPink;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgViewCircularInfo.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgViewCircularInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Peru;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgViewCircularInfo.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgViewCircularInfo.GridColor = System.Drawing.Color.LightGray;
            this.dgViewCircularInfo.Location = new System.Drawing.Point(9, 553);
            this.dgViewCircularInfo.Name = "dgViewCircularInfo";
            this.dgViewCircularInfo.RowHeadersVisible = false;
            this.dgViewCircularInfo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgViewCircularInfo.Size = new System.Drawing.Size(971, 210);
            this.dgViewCircularInfo.TabIndex = 15;
            this.dgViewCircularInfo.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgViewCircularInfo_CellContentClick);
            // 
            // btnExportToPdf
            // 
            this.btnExportToPdf.BackColor = System.Drawing.Color.Maroon;
            this.btnExportToPdf.ForeColor = System.Drawing.Color.White;
            this.btnExportToPdf.Location = new System.Drawing.Point(511, 186);
            this.btnExportToPdf.Name = "btnExportToPdf";
            this.btnExportToPdf.Size = new System.Drawing.Size(121, 31);
            this.btnExportToPdf.TabIndex = 14;
            this.btnExportToPdf.Text = "View Report In Pdf";
            this.btnExportToPdf.UseVisualStyleBackColor = false;
            this.btnExportToPdf.Click += new System.EventHandler(this.btnExportToPdf_Click);
            // 
            // dgViewBidders
            // 
            this.dgViewBidders.AllowUserToAddRows = false;
            this.dgViewBidders.AllowUserToDeleteRows = false;
            this.dgViewBidders.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgViewBidders.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dgViewBidders.BackgroundColor = System.Drawing.Color.Cornsilk;
            this.dgViewBidders.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.HotPink;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgViewBidders.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgViewBidders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Peru;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgViewBidders.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgViewBidders.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgViewBidders.GridColor = System.Drawing.Color.LightGray;
            this.dgViewBidders.Location = new System.Drawing.Point(9, 224);
            this.dgViewBidders.Name = "dgViewBidders";
            this.dgViewBidders.RowHeadersVisible = false;
            this.dgViewBidders.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgViewBidders.Size = new System.Drawing.Size(1160, 308);
            this.dgViewBidders.TabIndex = 11;
            this.dgViewBidders.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgViewBidders_CellContentClick);
            this.dgViewBidders.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgViewBidders_CellFormatting);
            this.dgViewBidders.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dgView_KeyDown);
            // 
            // frmBidderInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cornsilk;
            this.ClientSize = new System.Drawing.Size(1197, 810);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmBidderInfo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bidder Information Window";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmBidderInfo_FormClosed);
            this.Load += new System.EventHandler(this.frmBidderInfo_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgViewCircularInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgViewBidders)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtProjectCode;
        private System.Windows.Forms.TextBox txtTenderNo;
        private System.Windows.Forms.TextBox txtClosingDate;
        private System.Windows.Forms.TextBox txtTenderTitle;
        private System.Windows.Forms.TextBox txtModifiedDate;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dgViewBidders;
        private System.Windows.Forms.Button btnBidEdit;
        private System.Windows.Forms.Button btnDeleteBidder;
        private System.Windows.Forms.Button btnEmailCirculars;
        private System.Windows.Forms.Button btnExportToPdf;
        private System.Windows.Forms.DataGridView dgViewCircularInfo;
        private System.Windows.Forms.Label lblCircularNo;
        private System.Windows.Forms.ComboBox cmbCircularNo;
        private System.Windows.Forms.Button btnDeleteFromShortList;
        private System.Windows.Forms.TextBox txtProjectType;
        private System.Windows.Forms.Label lblProjectType;
        private System.Windows.Forms.Button btnReportInExcel;
    }
}