﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Transactions;
using System.Windows.Forms;
using TenderTrackingSystem;

namespace MDI_ParenrForm.Projects
{
    public partial class UserAuthentication : Form
    {
        string _prjCode = null;
        string _mohOrNonMohPrjCode = null;         
        string _projTitle = null;
        string _tndrTypeName = null;
        string _committeeName = null;
        string _mohOrNonMohCommitteeId = null;
        string _mohOrNonMohFiscalId = null;
        string _fiscalYear = null;
        string _mohOrNonMohUserDeptId = null;
        string _userDept = null;
        string _AffairsName = null;
        string _mohOrNonMohAffairsId = null;
        string _userName = null;
        string _projId = null;
        string _mohOrNonMohTypeOfPrjId = null;
        string _tndrType = null;
        string _mohOrNonMohPrjTitleEn = null;
        string _mohOrNonMohPrjTitleAr = null;
        string _mohOrNonMohMinistryCode = null;         
        string _mohOrNonMohBudgetRefNo = null;
        string _mohOrNonMohProvisionNo = null;
        string _mohOrNonMohBudgetAmt = null;
        string _mohOrNonTenderTypeId = null;
        string _mohOrNonMohPrjId = null;
        string _mohOrNonMohProjType = null;
        string _selectedCommitteeName = null;
        string _tenderNo = null;
        string _tndrStatus = null;
        bool _isTenderTypeVisible = false;
        bool _isLmtProj = false;
        bool _isProjTransfer = false;
        IList<string> _userRightsColl = new List<string>();
        bool isException = false;
        int _newPrjID = 0;
       
        public UserAuthentication(string[] projData, string selectedCommitteeName, IList<string> userRightsColl, bool isTenderTypeVisible,bool isLmtProj, bool isProjTransfer)
        {
            InitializeComponent();
            if (projData.Length == 13) 
            {
                _prjCode = projData[0]; //prjCode
                _projTitle = projData[1]; //projTitle
                if (projData[2] != null)
                {
                    _tndrTypeName = projData[2]; //tndrTypeName;
                }
                _committeeName = projData[3];  //cmtName;            
                _fiscalYear = projData[4]; //fiscalYear;
                if (projData[5] != null)
                {
                    _userDept = projData[5];  //userDept;
                }
                if (projData[6] != null)
                {
                    _AffairsName = projData[6];  //affairsName;
                }
                _userName = projData[7];  //user;
                ashghalUserName.Text = _userName;
                _projId = projData[8];
                _tndrType = projData[9];
                if (projData[10] != null)
                {
                    _tenderNo = projData[10]; //Tender Number
                }
                if (projData[11] != null)
                {
                    _tndrStatus = projData[11]; //TndrStatus            
                }
                if (projData[12] != null)
                {
                    _newPrjID = Convert.ToInt32(projData[12]); //New ProjID
                }
            }
            else
            {
                _mohOrNonMohPrjCode = projData[0]; //MohOrNonMoh-PrjCode
                _mohOrNonMohPrjTitleEn = projData[1]; //MohOrNonMoh-ProjTitle English
                _mohOrNonMohPrjId = projData[13]; //NonMohOrMohznaPrjID                     
                _mohOrNonMohPrjTitleAr = projData[15]; //MohOrNonMoh-ProjTitle Arabic
                _mohOrNonMohMinistryCode = projData[16]; //MohOrNonMoh-MinistryCode
                _mohOrNonMohBudgetRefNo = projData[17]; //MohOrNonMoh-BudgetRefNo
                _mohOrNonMohProvisionNo = projData[18]; //MohOrNonMoh-ProvisionNo
                _mohOrNonMohBudgetAmt = projData[19]; //MohOrNonMoh-BudgetAmt
                _mohOrNonMohProjType = projData[20]; //MohOrNonMoh-ProjType
                if (projData[2] != null)
                {
                    _tndrTypeName = projData[2]; //tndrTypeName;
                }
                _mohOrNonMohTypeOfPrjId = projData[14]; //typeOfPrj-TypeOfContractId;
                _mohOrNonMohCommitteeId = projData[3];  //committeeId;            
                _mohOrNonMohFiscalId = projData[4]; //fiscalId
                _mohOrNonMohUserDeptId = projData[5]; //userDeptId;                 
                if (projData[6] != null)
                {
                    _mohOrNonMohAffairsId = projData[6];  //affairsName;
                }
                _userName = projData[7];  //user;
                
                ashghalUserName.Text = _userName;
                if (projData[8] != null)
                {
                    _projId = projData[8];
                }
               
                _mohOrNonTenderTypeId = projData[9];              
                if (projData[10] != null)
                {
                    _tenderNo = projData[10]; //Tender Number
                }
                if (projData[11] != null)
                {
                    _tndrStatus = projData[11]; //TndrStatus            
                }
                if (projData[12] != null)
                {
                    _newPrjID = Convert.ToInt32(projData[12]); //New ProjID
                }                
            }
            _userRightsColl = userRightsColl;            
            _selectedCommitteeName = selectedCommitteeName;
            _isTenderTypeVisible = isTenderTypeVisible;
            _isLmtProj = isLmtProj;
            _isProjTransfer = isProjTransfer;             
        }

        int _maxPrjiD = 0;
        private int GetMaxID(string sqlQuery)
        {
            SqlConnection sqlCon = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString());
            sqlCon.Open();
            try
            {
                SqlCommand sqlCommand = new SqlCommand(sqlQuery, sqlCon);
                _maxPrjiD = Convert.ToInt16(sqlCommand.ExecuteScalar());
                _maxPrjiD = _maxPrjiD + 1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlCon.Close();
            }
            return _maxPrjiD;
        }

        bool ValidateData()
        {
            bool isValidated = true;
            //if(ashghal_UserName.Text=="")
            //{
            //    MessageBox.Show("Email Address cannot be left blank");
            //    ashghal_UserName.Focus();
            //    isValidated = false;                
            //}
            //else 
            if (password.Text == "")
            {
                MessageBox.Show("Email Password cannot be left blank");
                password.Focus();
                isValidated = false; 
            }
            return isValidated;
        }


        string FindEmailIDOfTheUser(string userName)
        {
            string emailID = null;
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();

                        string sqlQuery = "SELECT email_address FROM USERS WHERE (user_name = '" + userName + "')";

                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            if (dr.Read())
                            {
                                emailID = dr["email_address"].ToString();
                                //if (!userListColl.Contains(strData))                                    
                                //    userListColl.Add(strData);
                            }
                            dr.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while retrieving the user email from the database", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                emailID = null;
            }
            return emailID;
        }

        StringBuilder emailIds = new StringBuilder();
        private void UserList_ForAlert(int categryID)
        {
            //userListColl.Clear();
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();

                        string sqlQuery = "SELECT DISTINCT EmailAlertRecipients.user_id, USERS.email_address, USERS.user_name, EmailAlertCategory.AlertCategory, EmailAlertRecipients.alert_cat_id, " +
                                             " Committee.committee_short_name FROM EmailAlertCategory INNER JOIN EmailAlertRecipients ON EmailAlertCategory.alert_cat_id = EmailAlertRecipients.alert_cat_id INNER JOIN " +
                                             " USERS ON EmailAlertRecipients.user_id = USERS.user_id INNER JOIN Committee ON EmailAlertRecipients.committee_id = Committee.committee_id " +
                                             " WHERE (EmailAlertRecipients.alert_cat_id = " + categryID + ") AND (USERS.email_address <> N'') AND (Committee.committee_short_name ='" + _committeeName + "')";

                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                emailIds.Append(dr[1].ToString() + ",");
                                //if (!userListColl.Contains(strData))                                    
                                //    userListColl.Add(strData);
                            }
                            dr.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while retrieving the email ids of a particular committee.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                isException = true;
            }
        }

        string assignTenderNo()
        {
            string tenderNo = null;
            if (ValidateData())
            {
                string emailID = FindEmailIDOfTheUser(_userName);
                if (emailID!=null)
                {
                    try
                    {

                        // Test Email for checking the SMTP Server is up and running Added By Varun on 31st Jan 2016
                        MailMessage mailMessage = new MailMessage();
                        mailMessage.From = new MailAddress(emailID);
                        mailMessage.To.Add(new MailAddress(ConfigurationManager.AppSettings["To"].ToString()));
                        mailMessage.Subject = "Test TCMS Alert: Tender No. was going to be assigned";
                        mailMessage.IsBodyHtml = true;
                        mailMessage.Body = "<html><body><i style='font-family:Calibri; font-size:15'>Dear Sir/Madam,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Tender & Contract Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>" +
                        "Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'> New Tender No. </i><i style='font-family:Calibri; font-size:15'> has created and the details are as follows:-</i><br /><br />" +
                        "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:Maroon;color:White;font-family:Calibri;font-size:18;font-weight:bold'>TENDER NO: </td>" +
                        "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Code</i></td><td style='font-family:Calibri;font-size:15'>" + _prjCode + "</td></tr>" +
                        "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Title</i></td><td style='font-family:Calibri;font-size:15'>" + _projTitle + "</td></tr>" +
                        "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Type of Tender</i></td><td style='font-family:Calibri;font-size:15'>" + _tndrTypeName + "</td></tr>" +
                        "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Tender Committee</i></td><td style='font-family:Calibri;font-size:15'>" + _committeeName + "</td></tr>" +
                        "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Financial Year</i></td><td style='font-family:Calibri;font-size:15'>" + _fiscalYear + "</td></tr>" +       //+ "(" + _AffairsName + ")
                        "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>User Dept.</i></td><td style='font-family:Calibri;font-size:15'>" + _userDept + " / " + _AffairsName + " </td></tr>" +
                        "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                        "</table><br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>TCMS Team</div></body></html>";

                        //mailMessage.Body = "This is an automated alert from TCMS." + "\n" + "\n" + "Project Code     : " + _prjCode + "\n" + "Project Title    : " + proj_Title + "\n" +   "Type of Tender   : " + _tndrTypeName + " " +
                        // "\n"  + "Tender Committee : " + _committeeName + " " +
                        // "\n" +  "User Department  : " + _userDept + " " +
                        // "\n" +  "Date Created     : " + System.DateTime.Now.ToString() + " " +
                        //" \n" +  "\n" + "Tender No. " + strTenderNo + " was assigned to above project.";

                        SmtpClient client = new SmtpClient();
                        client.EnableSsl = true;
                        //client.UseDefaultCredentials = true;
                        client.Credentials = new System.Net.NetworkCredential(_userName, password.Text.Trim());
                        ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                        client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                        client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                        client.Send(mailMessage);
                        //SendEmail myAction = new SendEmail(SendCompletedCallback);
                        //myAction.BeginInvoke(client, mailMessage, null, null);

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Unable to send the Test Email." +ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        isException = true;
                        //MessageBox.Show("Unable to send the Test Email. May be UserName and Password is incorrect. Try again, or inform to Administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        return tenderNo;
                    }

                    if (isException == false)
                    {
                        UserList_ForAlert(1);
                        if (isException == false)
                        {
                            if (emailIds.Length == 0)
                            {
                                MessageBox.Show("Information for Tender No.assignment is required to be sent to a user who handles " + _committeeName + " projects, " +
                                  " but there is no identified user to receive the email. Please contact system administrator for information.");
                                return tenderNo;
                            }

                            DialogResult dlgResult = DialogResult.No;
                            dlgResult = MessageBox.Show("Do you want to create new Tender Number. ", "Assign Tender No.", MessageBoxButtons.YesNo);

                            if (dlgResult.ToString() == "Yes")
                            {

                                string _prjCreaedOn = string.Empty;

                                CommonClass comCls = new CommonClass(_userName);

                                string strTenderNo = comCls.AssignTenderNo(_userRightsColl, Convert.ToInt32(_projId), _tndrType, _prjCode, _projTitle, 'A', null, null, ref _tndrTypeName, ref _userDept, ref _prjCreaedOn, ref _AffairsName);
                                // Added by Varun on 10 Feb 2014 for checking the exception occurence and to stop sending email alerts if there is a problem in assigning the Tender No.
                                if (!strTenderNo.Contains("Exception"))
                                {
                                    //string DisplayName = ""; string Email = ""; string Department = ""; string Title = "";                         
                                    // AlertOnNewTenderNo(tenderNo, _projID.ToString(), "New Project");
                                    

                                    try
                                    {
                                        //if (GetUserInformation4rmActiveDirectory(fromUser, "ashghal.gov.qa", ref user_DisplayName, ref user_Email, ref  user_Department, ref user_Title) == true)
                                        //{
                                        //foreach (string strname in userListColl)
                                        //{
                                        // if (GetUserInformation4rmActiveDirectory(strname, "ashghal.gov.qa", ref DisplayName, ref Email, ref  Department, ref Title) == true)

                                        MailMessage mailMessage = new MailMessage();
                                        //mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["MailFrom"].ToString());

                                        mailMessage.From = new MailAddress(emailID);
                                        //mailMessage.To.Add(emailIds.ToString().Substring(0, emailIds.ToString().Length - 1));
                                        foreach (var address in emailIds.ToString().Substring(0, emailIds.ToString().Length - 1).Split(','))
                                        {
                                            mailMessage.To.Add(new MailAddress(address, ""));
                                        }
                                        if (!_tndrType.Equals("PQ"))
                                        {
                                            mailMessage.Subject = "TCMS Alert: Tender No. " + strTenderNo + " was assigned";
                                        }
                                        else
                                        {
                                            mailMessage.Subject = "TCMS Alert: Pre-Qualification No. " + strTenderNo + " was assigned";
                                        }
                                        mailMessage.IsBodyHtml = true;

                                        string emailBodyText = null;

                                        emailBodyText = "<html><body><i style='font-family:Calibri; font-size:15'>Dear Sir/Madam,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Tender & Contract Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>";
                                        if (!_tndrType.Equals("PQ") && !_tndrType.Equals("A"))
                                        {
                                            emailBodyText = emailBodyText + "Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'> New Tender No. " + strTenderNo + "</i><i style='font-family:Calibri; font-size:15'> has created and the details are as follows:-</i><br /><br />";
                                        }
                                        else if (_tndrType.Equals("PQ"))
                                        {
                                            emailBodyText = emailBodyText + "Please be noted that</i><i style='color:Blue;font-family:Calibri; font-size:15'> New Pre-Qualification No. " + strTenderNo + "</i><i style='font-family:Calibri; font-size:15'> has created and the details are as follows:-</i><br /><br />";
                                        }
                                        else
                                        {
                                            emailBodyText = emailBodyText + "Please be noted that</i><i style='color:#1F4E79;font-family:Calibri; font-size:15'> New Tender No. " + strTenderNo + "</i><i style='font-family:Calibri; font-size:15'> has created and the details are as follows:-</i><br /><br />";
                                        }

                                        if (!_tndrType.Equals("PQ") && !_tndrType.Equals("A"))
                                        {
                                            emailBodyText = emailBodyText + "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:Maroon;color:White;font-family:Calibri;font-size:18;font-weight:bold'>TENDER No. : " + strTenderNo + "</td>" +
                                            "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Code</i></td><td style='font-family:Calibri;font-size:15'>" + _prjCode + "</td></tr>" +
                                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Title</i></td><td style='font-family:Calibri;font-size:15'>" + _projTitle + "</td></tr>" +
                                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Type of Tender</i></td><td style='font-family:Calibri;font-size:15'>" + _tndrTypeName + "</td></tr>" +
                                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Tender Committee</i></td><td style='font-family:Calibri;font-size:15'>" + _committeeName + "</td></tr>" +
                                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Financial Year</i></td><td style='font-family:Calibri;font-size:15'>" + _fiscalYear + "</td></tr>" +       //+ "(" + _AffairsName + ")
                                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>User Dept.</i></td><td style='font-family:Calibri;font-size:15'>" + _userDept + " / " + _AffairsName + " </td></tr>" +
                                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                                            "</table>";

                                        }
                                        else if (_tndrType.Equals("PQ"))
                                        {
                                            emailBodyText = emailBodyText + "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:#A9A9A9;color:Black;font-family:Calibri;font-size:18;font-weight:bold'>PQ No. : " + strTenderNo + "</td>" +
                                            "</tr><tr><td style='font-family:Calibri;font-size:15'><i>Project Code</i></td><td style='font-family:Calibri;font-size:15'>" + _prjCode + "</td></tr>" +
                                            "<tr><td style='font-family:Calibri;font-size:15'><i>Project Title</i></td><td style='font-family:Calibri;font-size:15'>" + _projTitle + "</td></tr>" +
                                            "<tr><td style='font-family:Calibri;font-size:15'><i>Tender Committee</i></td><td style='font-family:Calibri;font-size:15'>" + _committeeName + "</td></tr>" +
                                            "<tr><td style='font-family:Calibri;font-size:15'><i>Financial Year</i></td><td style='font-family:Calibri;font-size:15'>" + _fiscalYear + "</td></tr>" +       //+ "(" + _AffairsName + ")
                                            "<tr><td style='font-family:Calibri;font-size:15'><i>User Dept.</i></td><td style='font-family:Calibri;font-size:15'>" + _AffairsName + " </td></tr>" +
                                            "<tr><td style='font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                                            "</table>";
                                        }
                                        else
                                        {
                                            emailBodyText = emailBodyText + "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:#1F4E79;color:White;font-family:Calibri;font-size:18;font-weight:bold'>TENDER No. : " + strTenderNo + "</td>" +
                                            "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Code</i></td><td style='font-family:Calibri;font-size:15'>" + _prjCode + "</td></tr>" +
                                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Title</i></td><td style='font-family:Calibri;font-size:15'>" + _projTitle + "</td></tr>" +
                                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Type of Tender</i></td><td style='font-family:Calibri;font-size:15'>" + _tndrTypeName + "</td></tr>" +
                                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Tender Committee</i></td><td style='font-family:Calibri;font-size:15'>" + _committeeName + "</td></tr>" +
                                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Financial Year</i></td><td style='font-family:Calibri;font-size:15'>" + _fiscalYear + "</td></tr>" +       //+ "(" + _AffairsName + ")
                                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>User Dept.</i></td><td style='font-family:Calibri;font-size:15'>" + _userDept + " / " + _AffairsName + " </td></tr>" +
                                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                                            "</table>";
                                        }

                                        emailBodyText = emailBodyText + "<br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>TCMS Team</div></body></html>";

                                        mailMessage.Body = emailBodyText;
                                        //mailMessage.Body = "This is an automated alert from TCMS." + "\n" + "\n" + "Project Code     : " + _prjCode + "\n" + "Project Title    : " + proj_Title + "\n" +   "Type of Tender   : " + _tndrTypeName + " " +
                                        // "\n"  + "Tender Committee : " + _committeeName + " " +
                                        // "\n" +  "User Department  : " + _userDept + " " +
                                        // "\n" +  "Date Created     : " + System.DateTime.Now.ToString() + " " +
                                        //" \n" +  "\n" + "Tender No. " + strTenderNo + " was assigned to above project.";

                                        SmtpClient client = new SmtpClient();
                                        client.EnableSsl = true;
                                        //client.UseDefaultCredentials = true;
                                        client.Credentials = new System.Net.NetworkCredential(_userName, password.Text.Trim());
                                        ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                                        client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                                        client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                                        //client.Send(mailMessage);
                                        SendEmail myAction = new SendEmail(SendCompletedCallback);
                                        myAction.BeginInvoke(client, mailMessage, null, null);

                                        //}
                                        //}
                                        //MessageBox.Show("Tender Alert E-mail send to the users", "Create Tender Number");
                                        if (strTenderNo != "")
                                        {
                                            tenderNo = strTenderNo;
                                            return tenderNo;
                                            //txtTenderNo.Enabled = false;
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        MessageBox.Show("Unable to send the Test Email." + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                        //MessageBox.Show("Exception occurred while sending the email notification to Tender Committee. Please inform to Administrator", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                        return tenderNo;
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Error occurred while assigning Tender Number. Please inform to Administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                    return tenderNo;
                                }
                            }
                        }
                    }
                    return tenderNo;
                }
                else
                {
                    return null;
                }
            }
            else
            {
                return null;
            }
        }

        private void SendCompletedCallback(SmtpClient smtpclient, System.Net.Mail.MailMessage mail) //private static void SendCompletedCallback(object sender, AsyncCompletedEventArgs e
        {
            try
            {
                smtpclient.Send(mail);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Occurred while sending the email. " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            finally
            {
                mail.Dispose();
                mail = null;
                // smtpclient = null;
            }
        }
        string tenderVal = null;
        public string TenderNum
        {
            get { return tenderVal; }
            set { tenderVal = value; }
        }

        bool isErrorOccurred = false;
        public bool IsErrorOccurred
        {
            get { return isErrorOccurred; }
            set { isErrorOccurred = value; }
        }

        char chProjReTendered = ' ';
        public char ProjReTender
        {
            get { return chProjReTendered; }
            set { chProjReTendered = value; }
        }

        private int MaxDateID()
        {
            int dateId = 0;
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"SELECT MAX(DATE_ID) FROM TenderDatesInfo";
                        dateId = Convert.ToInt16(cmd.ExecuteScalar());
                        dateId = dateId + 1;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            return dateId;
        }

        private void transforTenderDates_Stage1()
        {
            string sqlQuery = "SELECT date_id, proj_id, stage_id, ptd_receive_on, ptd_purpose, ptd_assign_qs, ptd_sent_for_rev, ptd_qs_working_status, ptd_tendec_doc_cur_status, " +
            " ptd_forwarded_to_dep,remarks,create_date,update_date,create_user,update_user,Alert FROM TenderDatesInfo WHERE (proj_id = " + _projId + ") AND (stage_id = 1)";

            SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString());
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            DataSet dsStg1 = new DataSet();
            SqlDataAdapter daStage1 = new SqlDataAdapter(sqlCom);
            daStage1.Fill(dsStg1);
            sqlConn.Close();
            if (dsStg1.Tables[0].Rows.Count > 0)
            {
                InsertDocumentPreparationInfo(dsStg1);
            }
        }

        int dateID = 0;
        private void InsertDocumentPreparationInfo(DataSet stg1Ds)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                {
                    sqlConn.Open();
                    int totRows = stg1Ds.Tables[0].Rows.Count;
                    for (int i = 0; i < totRows; i++)
                    {
                        dateID = MaxDateID();
                        string insertQuery = "INSERT INTO TenderDatesInfo(date_id,proj_id, stage_id, ptd_receive_on, ptd_purpose, ptd_assign_qs," +
                        " ptd_sent_for_rev, ptd_qs_working_status, ptd_tendec_doc_cur_status,ptd_forwarded_to_dep, remarks,create_date,update_date,create_user,update_user,Alert) VALUES " +
                        " (@dateId,@projId,@stageId,@PTDreceiveOn,@PTDPurpose,@PTDassignQs,@PTDForReview,@PTDQsStatus,@PTDdocStatus,@PTDfrwdDept,@PTDRemarks,@createDate,@updateDate,@createUser,@updateUser,@alert)";

                        SqlCommand cmd = new SqlCommand(insertQuery, sqlConn);
                        cmd.Parameters.AddWithValue("@dateId", dateID);
                        cmd.Parameters.AddWithValue("@projId", _newPrjID);
                        cmd.Parameters.AddWithValue("@stageId", 1);

                        if (stg1Ds.Tables[0].Rows[i][3].ToString() != "")
                            cmd.Parameters.AddWithValue("@PTDreceiveOn", stg1Ds.Tables[0].Rows[i][3]);
                        else
                            cmd.Parameters.AddWithValue("@PTDreceiveOn", DBNull.Value);

                        if (stg1Ds.Tables[0].Rows[i][4].ToString() != "")
                            cmd.Parameters.AddWithValue("@PTDPurpose", stg1Ds.Tables[0].Rows[i][4].ToString());
                        else
                            cmd.Parameters.AddWithValue("@PTDPurpose", DBNull.Value);

                        if (stg1Ds.Tables[0].Rows[i][5].ToString() != "")
                            cmd.Parameters.AddWithValue("@PTDassignQs", stg1Ds.Tables[0].Rows[i][5].ToString());
                        else
                            cmd.Parameters.AddWithValue("@PTDassignQs", DBNull.Value);

                        if (stg1Ds.Tables[0].Rows[i][6].ToString() != "")
                            cmd.Parameters.AddWithValue("@PTDForReview", stg1Ds.Tables[0].Rows[i][6]);
                        else
                            cmd.Parameters.AddWithValue("@PTDForReview", DBNull.Value);

                        if (stg1Ds.Tables[0].Rows[i][7].ToString() != "")
                            cmd.Parameters.AddWithValue("@PTDQsStatus", stg1Ds.Tables[0].Rows[i][7].ToString());
                        else
                            cmd.Parameters.AddWithValue("@PTDQsStatus", DBNull.Value);

                        if (stg1Ds.Tables[0].Rows[i][8].ToString() != "")
                            cmd.Parameters.AddWithValue("@PTDdocStatus", stg1Ds.Tables[0].Rows[i][8].ToString());
                        else
                            cmd.Parameters.AddWithValue("@PTDdocStatus", DBNull.Value);

                        if (stg1Ds.Tables[0].Rows[i][9].ToString() != "")
                            cmd.Parameters.AddWithValue("@PTDfrwdDept", stg1Ds.Tables[0].Rows[i][9]);
                        else
                            cmd.Parameters.AddWithValue("@PTDfrwdDept", DBNull.Value);

                        cmd.Parameters.AddWithValue("@PTDRemarks", stg1Ds.Tables[0].Rows[i][10].ToString()); // + "**Note: This tender was formerly Assigned to "  + _committeeName + " with assigned Tender No. PWA/ITC/039/2011-12"
                        cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@createUser", _userName);
                        cmd.Parameters.AddWithValue("@updateUser", _userName);

                        if (stg1Ds.Tables[0].Rows[i][15] != DBNull.Value)
                            if (stg1Ds.Tables[0].Rows[i][15].ToString() != "")
                                cmd.Parameters.AddWithValue("@alert", stg1Ds.Tables[0].Rows[i][15]);
                            else
                                cmd.Parameters.AddWithValue("@alert", DBNull.Value);
                        else
                            cmd.Parameters.AddWithValue("@alert", DBNull.Value);

                        cmd.ExecuteNonQuery();

                        //MessageBox.Show("Tender Document Preparation Data Added Successfully!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while copying the records." + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {
            }
        }

        DataSet dsStg2 = new DataSet();
        DataSet dsStg2Bidders = new DataSet();
        DataSet dsStg3 = new DataSet();
        private void transforTenderDates_Stage2()
        {
            string sqlQuery = "SELECT date_id, proj_id, stage_id, ts_receive_on, ts_issue_handling, ts_return_to_dept, ts_receive_from_dept, ts_pr_advertise, ts_tender_invitation, ts_closing_s1," +
            "ts_closing_s2, ts_modified_closing, ts_tender_issue, ts_receipt_no,co_id,employee_id,remarks,org_tender_validity,org_tenderbond_validity,org_tender_to_expire,org_tenderbond_to_expire," +
            "tender_validity_ext1,tender_validity_ext2,tenderbond_validity_ext1,tenderbond_validity_ext2,Tender_Issued,SN,create_date,update_date,create_user,update_user,Alert,Company_EmailID FROM TenderDatesInfo WHERE (proj_id = " + _projId + ") AND (stage_id = 2) " +
            "AND (ts_tender_issue IS NULL)"; //and ts_closing_s1 is NULL and ts_closing_s2 is NULL

            SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString());
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataAdapter daStage2 = new SqlDataAdapter(sqlCom);
            daStage2.Fill(dsStg2);
            sqlConn.Close();
            if (dsStg2.Tables[0].Rows.Count > 0)
            {
                InsertTenderStageInfo(dsStg2, false);
            }

            sqlQuery = "SELECT date_id, proj_id, stage_id, ts_receive_on, ts_issue_handling, ts_return_to_dept, ts_receive_from_dept, ts_pr_advertise, ts_tender_invitation, ts_closing_s1," +
            "ts_closing_s2, ts_modified_closing, ts_tender_issue, ts_receipt_no,co_id,employee_id,remarks,org_tender_validity,org_tenderbond_validity,org_tender_to_expire,org_tenderbond_to_expire," +
            "tender_validity_ext1,tender_validity_ext2,tenderbond_validity_ext1,tenderbond_validity_ext2,Tender_Issued,SN,create_date,update_date,create_user,update_user,Alert,Company_EmailID FROM TenderDatesInfo WHERE (proj_id = " + _projId + ") AND (stage_id = 2) " +
            "AND (ts_tender_issue IS not NULL)"; //and ts_closing_s1 is NULL and ts_closing_s2 is NULL

            sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString());
            sqlConn.Open();
            sqlCom = new SqlCommand(sqlQuery, sqlConn);
            daStage2 = new SqlDataAdapter(sqlCom);
            daStage2.Fill(dsStg2Bidders);
            sqlConn.Close();
            if (dsStg2Bidders.Tables[0].Rows.Count > 0)
            {
                InsertTenderStageInfo(dsStg2Bidders, true);
            }
        }

        private void transforTenderDates_Stage3()
        {
            string sqlQuery = "SELECT date_id, proj_id, stage_id, eval_tender_opening, eval_tender_doc_receive_from_cd, eval_tech_sent1, eval_tech_receive1,remarks," +
            "create_date,update_date,create_user,update_user,Alert FROM TenderDatesInfo WHERE (proj_id = " + _projId + ") AND (stage_id = 3)";

            SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString());
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataAdapter daStage3 = new SqlDataAdapter(sqlCom);
            daStage3.Fill(dsStg3);
            sqlConn.Close();
            if (dsStg3.Tables[0].Rows.Count > 0)
            {
                InsertTenderEvaluationData(dsStg3);
            }
        }

        private void InsertTenderEvaluationData(DataSet stg3Ds)
        {
            int totRowCount = stg3Ds.Tables[0].Rows.Count;
            for (int i = 0; i < totRowCount; i++)
            {
                try
                {
                    using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                    {
                        using (SqlCommand cmd = new SqlCommand())
                        {
                            sqlConn.Open();
                            cmd.Connection = sqlConn;
                            dateID = MaxDateID();
                            cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,eval_tender_opening,eval_tender_doc_receive_from_cd, " +
                            " eval_tech_sent1,eval_tech_receive1,remarks,create_date,update_date,create_user,update_user,Alert) " +
                            " VALUES(@dateId,@projId,@stageId,@evltendrReq,@fromCd,@senttoTech,@recfromtech,@remarksTE,@createDate,@updateDate,@createUser,@updateUser,@alert)";

                            cmd.Parameters.AddWithValue("@dateId", dateID);
                            cmd.Parameters.AddWithValue("@projId", _newPrjID);
                            cmd.Parameters.AddWithValue("@stageId", 3);

                            if (stg3Ds.Tables[0].Rows[i][3].ToString() != "")
                                cmd.Parameters.AddWithValue("@evltendrReq", stg3Ds.Tables[0].Rows[i][3]);
                            else
                                cmd.Parameters.AddWithValue("@evltendrReq", DBNull.Value);

                            if (stg3Ds.Tables[0].Rows[i][4].ToString() != "")
                                cmd.Parameters.AddWithValue("@fromCd", stg3Ds.Tables[0].Rows[i][4]);
                            else
                                cmd.Parameters.AddWithValue("@fromCd", DBNull.Value);

                            if (stg3Ds.Tables[0].Rows[i][5].ToString() != "")
                                cmd.Parameters.AddWithValue("@senttoTech", stg3Ds.Tables[0].Rows[i][5]);
                            else
                                cmd.Parameters.AddWithValue("@senttoTech", DBNull.Value);

                            if (stg3Ds.Tables[0].Rows[i][6].ToString() != "")
                                cmd.Parameters.AddWithValue("@recfromtech", stg3Ds.Tables[0].Rows[i][6]);
                            else
                                cmd.Parameters.AddWithValue("@recfromtech", DBNull.Value);

                            if (i == 0)
                            {
                                if (stg3Ds.Tables[0].Rows[i][7].ToString() != "")
                                    cmd.Parameters.AddWithValue("@remarksTE", stg3Ds.Tables[0].Rows[i][7].ToString() + " **Note: This tender was formerly Assigned to " + _committeeName + " with assigned Tender No.  " + _tenderNo);
                                else
                                    cmd.Parameters.AddWithValue("@remarksTE", " **Note: This tender was formerly Assigned to " + _committeeName + " with assigned Tender No.  " + _tenderNo);
                            }
                            else
                                cmd.Parameters.AddWithValue("@remarksTE", stg3Ds.Tables[0].Rows[i][7].ToString());

                            cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                            cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                            cmd.Parameters.AddWithValue("@createUser", _userName);
                            cmd.Parameters.AddWithValue("@updateUser", _userName);

                            if (stg3Ds.Tables[0].Rows[i][12] != DBNull.Value)
                                if (stg3Ds.Tables[0].Rows[i][12].ToString() != "")
                                    cmd.Parameters.AddWithValue("@alert", stg3Ds.Tables[0].Rows[i][12]);
                                else
                                    cmd.Parameters.AddWithValue("@alert", DBNull.Value);
                            else
                                cmd.Parameters.AddWithValue("@alert", DBNull.Value);

                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();

                            // MessageBox.Show("Tender Evaluation & Award data added Succesfully");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while copying the records." + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }     
        private void InsertTenderStageInfo(DataSet stg2Ds, bool isBidder)
        {

            try
            {
                using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        int totRowsCount = stg2Ds.Tables[0].Rows.Count;
                        for (int i = 0; i < totRowsCount; i++)
                        {
                            dateID = MaxDateID();
                            //if (stg2Ds.Tables[0].Rows[0][9].ToString() != "")   // Tender Closing date 
                            //{

                            if (!isBidder)
                            {
                                cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,ts_receive_on,ts_issue_handling,ts_return_to_dept, " +
                                " ts_receive_from_dept,ts_pr_advertise,ts_tender_invitation,ts_closing_s1,ts_closing_s2,ts_modified_closing,remarks,org_tender_validity," +
                                "org_tenderbond_validity,org_tender_to_expire,org_tenderbond_to_expire,tender_validity_ext1,tender_validity_ext2,tenderbond_validity_ext1,tenderbond_validity_ext2,create_date,update_date,create_user,update_user,Alert,Company_EmailID) VALUES " +
                                "(@dateId,@projId,@stageId,@receiveOn,@issueHandling,@returnDept,@receivedFromDept,@advertisement,@invitation,@closingDate1,@closingDate2,@tsModifyDate,@Remarks," +
                                "@orgTenderValidity,@orgTenderbondValidity,@orgTenderToExpire,@orgTenderbondExpire,@tenderValidityExt1,@tenderValidityExt2,@tenderbondValidityExt1,@tenderbondValidityExt2,@createDate,@updateDate,@createUser,@updateUser,@alert,@companyEmailID)";
                            }
                            else
                            {
                                cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,ts_tender_issue, " +
                                " ts_receipt_no,co_id,employee_id,remarks,Tender_Issued,SN,create_date,update_date,create_user,update_user,Alert,Company_EmailID) VALUES " +
                                "(@dateId,@projId,@stageId,@issueTndrDate,@receiptNo,@coID,@empID,@Remarks,@tenderIssued,@sn,@createDate,@updateDate,@createUser,@updateUser,@alert,@companyEmailID)";
                            }

                            cmd.Parameters.AddWithValue("@stageId", 2);

                            cmd.Parameters.AddWithValue("@projId", _newPrjID);

                            if (!isBidder)
                            {
                                cmd.Parameters.AddWithValue("@receiveOn", stg2Ds.Tables[0].Rows[i][3]);

                                if (stg2Ds.Tables[0].Rows[i][4].ToString() != "")
                                    cmd.Parameters.AddWithValue("@issueHandling", stg2Ds.Tables[0].Rows[i][4]);
                                else
                                    cmd.Parameters.AddWithValue("@issueHandling", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][5].ToString() != "")
                                    cmd.Parameters.AddWithValue("@returnDept", stg2Ds.Tables[0].Rows[i][5]);
                                else
                                    cmd.Parameters.AddWithValue("@returnDept", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][6].ToString() != "")
                                    cmd.Parameters.AddWithValue("@receivedFromDept", stg2Ds.Tables[0].Rows[i][6]);
                                else
                                    cmd.Parameters.AddWithValue("@receivedFromDept", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][7].ToString() != "")
                                    cmd.Parameters.AddWithValue("@advertisement", stg2Ds.Tables[0].Rows[i][7]);
                                else
                                    cmd.Parameters.AddWithValue("@advertisement", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][8].ToString() != "")
                                    cmd.Parameters.AddWithValue("@invitation", stg2Ds.Tables[0].Rows[i][8]);
                                else
                                    cmd.Parameters.AddWithValue("@invitation", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[0][9].ToString() != "")
                                    cmd.Parameters.AddWithValue("@closingDate1", stg2Ds.Tables[0].Rows[i][9]);
                                else
                                    cmd.Parameters.AddWithValue("@closingDate1", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][10].ToString() != "")
                                    cmd.Parameters.AddWithValue("@closingDate2", stg2Ds.Tables[0].Rows[i][10]);
                                else
                                    cmd.Parameters.AddWithValue("@closingDate2", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][11].ToString() != "")
                                    cmd.Parameters.AddWithValue("@tsModifyDate", stg2Ds.Tables[0].Rows[i][11]);
                                else
                                    cmd.Parameters.AddWithValue("@tsModifyDate", DBNull.Value);
                            }
                            else
                            {
                                if (stg2Ds.Tables[0].Rows[i][12].ToString() != "")
                                    cmd.Parameters.AddWithValue("@issueTndrDate", stg2Ds.Tables[0].Rows[i][12]);
                                else
                                    cmd.Parameters.AddWithValue("@issueTndrDate", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][13].ToString() != "")
                                    cmd.Parameters.AddWithValue("@receiptNo", stg2Ds.Tables[0].Rows[i][13]);
                                else
                                    cmd.Parameters.AddWithValue("@receiptNo", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][14].ToString() != "")
                                    cmd.Parameters.AddWithValue("@coID", stg2Ds.Tables[0].Rows[i][14]);
                                else
                                    cmd.Parameters.AddWithValue("@coID", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][15].ToString() != "")
                                    cmd.Parameters.AddWithValue("@empID", stg2Ds.Tables[0].Rows[i][15]);
                                else
                                    cmd.Parameters.AddWithValue("@empID", DBNull.Value);
                            }

                            if (!isBidder)
                            {
                                if (stg2Ds.Tables[0].Rows[i][16].ToString() == "")
                                    cmd.Parameters.AddWithValue("@Remarks", " **Note: This tender was formerly Assigned to " + _committeeName + " with assigned Tender No.  " + _tenderNo);
                                else
                                    cmd.Parameters.AddWithValue("@Remarks", stg2Ds.Tables[0].Rows[i][16] + " **Note: This tender was formerly Assigned to " + _committeeName + " with assigned Tender No.  " + _tenderNo);
                            }
                            else
                                cmd.Parameters.AddWithValue("@Remarks", stg2Ds.Tables[0].Rows[i][16].ToString());

                            cmd.Parameters.AddWithValue("@dateId", dateID);

                            if (!isBidder)
                            {
                                if (stg2Ds.Tables[0].Rows[i][17].ToString() != "")
                                    cmd.Parameters.AddWithValue("@orgTenderValidity", stg2Ds.Tables[0].Rows[i][17]);
                                else
                                    cmd.Parameters.AddWithValue("@orgTenderValidity", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][18].ToString() != "")
                                    cmd.Parameters.AddWithValue("@orgTenderbondValidity", stg2Ds.Tables[0].Rows[i][18]);
                                else
                                    cmd.Parameters.AddWithValue("@orgTenderbondValidity", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][19] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][19].ToString() != "")
                                        cmd.Parameters.AddWithValue("@orgTenderToExpire", Convert.ToInt16(stg2Ds.Tables[0].Rows[i][19]));
                                    else
                                        cmd.Parameters.AddWithValue("@orgTenderToExpire", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@orgTenderToExpire", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][20] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][20].ToString() != "")
                                        cmd.Parameters.AddWithValue("@orgTenderbondExpire", Convert.ToInt16(stg2Ds.Tables[0].Rows[i][20]));
                                    else
                                        cmd.Parameters.AddWithValue("@orgTenderbondExpire", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@orgTenderbondExpire", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][21] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][21].ToString() != "")
                                        cmd.Parameters.AddWithValue("@tenderValidityExt1", stg2Ds.Tables[0].Rows[i][21]);
                                    else
                                        cmd.Parameters.AddWithValue("@tenderValidityExt1", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@tenderValidityExt1", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][22] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][22].ToString() != "")
                                        cmd.Parameters.AddWithValue("@tenderValidityExt2", stg2Ds.Tables[0].Rows[i][22]);
                                    else
                                        cmd.Parameters.AddWithValue("@tenderValidityExt2", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@tenderValidityExt2", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][23] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][23].ToString() != "")
                                        cmd.Parameters.AddWithValue("@tenderbondValidityExt1", stg2Ds.Tables[0].Rows[i][23]);
                                    else
                                        cmd.Parameters.AddWithValue("@tenderbondValidityExt1", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@tenderbondValidityExt1", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][24] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][24].ToString() != "")
                                        cmd.Parameters.AddWithValue("@tenderbondValidityExt2", stg2Ds.Tables[0].Rows[i][24]);
                                    else
                                        cmd.Parameters.AddWithValue("@tenderbondValidityExt2", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@tenderbondValidityExt2", DBNull.Value);
                            }
                            else
                            {
                                if (stg2Ds.Tables[0].Rows[i][25] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][25].ToString() != "")
                                        cmd.Parameters.AddWithValue("@tenderIssued", stg2Ds.Tables[0].Rows[i][25]);
                                    else
                                        cmd.Parameters.AddWithValue("@tenderIssued", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@tenderIssued", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][26] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][26].ToString() != "")
                                        cmd.Parameters.AddWithValue("@sn", Convert.ToInt16(stg2Ds.Tables[0].Rows[i][26]));
                                    else
                                        cmd.Parameters.AddWithValue("@sn", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@sn", DBNull.Value);
                            }
                            cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now);

                            cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                            cmd.Parameters.AddWithValue("@createUser", _userName);
                            cmd.Parameters.AddWithValue("@updateUser", _userName);

                            if (stg2Ds.Tables[0].Rows[i][31] != DBNull.Value)
                                if (stg2Ds.Tables[0].Rows[i][31].ToString() != "")
                                    cmd.Parameters.AddWithValue("@alert", stg2Ds.Tables[0].Rows[i][31]);
                                else
                                    cmd.Parameters.AddWithValue("@alert", DBNull.Value);
                            else
                                cmd.Parameters.AddWithValue("@alert", DBNull.Value);

                            // Added by Varun on 08 May 2014 for copying the newly added column data
                            if (stg2Ds.Tables[0].Rows[i][32] != DBNull.Value)
                                if (stg2Ds.Tables[0].Rows[i][32].ToString() != "")
                                    cmd.Parameters.AddWithValue("@companyEmailID", stg2Ds.Tables[0].Rows[i][32]);
                                else
                                    cmd.Parameters.AddWithValue("@companyEmailID", DBNull.Value);
                            else
                                cmd.Parameters.AddWithValue("@companyEmailID", DBNull.Value);

                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();

                            //}
                            //else
                            //    i = stg2Ds.Tables[0].Rows.Count;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while copying the records." + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        void transferProject()
        {
            CommonClass comCls = null;
            if (ValidateData())
            {
                string emailID = FindEmailIDOfTheUser(_userName);
                if (emailID != null)
                {

                    if (_tndrStatus.Equals("9"))
                    {
                        try
                        {
                            // Test Email for checking the SMTP Server is up and running Added By Varun on 31st Jan 2016
                            MailMessage mailMessage = new MailMessage();
                            mailMessage.From = new MailAddress(emailID);
                            mailMessage.To.Add(new MailAddress(ConfigurationManager.AppSettings["To"].ToString()));
                            mailMessage.Subject = "Test TCMS Alert: Tender No. " + _tenderNo + " is Re-Tendered";
                            mailMessage.IsBodyHtml = true;

                            mailMessage.Body = "<html><body><i style='font-family:Calibri; font-size:15'>Dear Sir/Madam,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Tender & Contract Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>" +
                            "Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'> Tender No. " + _tenderNo + "</i><i style='font-family:Calibri; font-size:15'> has been Re-Tendered and the new Tender No. is <i style='color:Maroon;font-family:Calibri; font-size:15'></i> and the details are as follows:-</i><br /><br />" +
                            "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Code</i></td><td style='font-family:Calibri;font-size:15'>" + _prjCode + "</td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Title</i></td><td style='font-family:Calibri;font-size:15'>" + _projTitle + "</td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Tender Committee</i></td><td style='font-family:Calibri;font-size:15'>" + _committeeName + "</td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Financial Year</i></td><td style='font-family:Calibri;font-size:15'>" + _fiscalYear + "</td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                            "</table><br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>TCMS Team</div></body></html>";

                            SmtpClient client = new SmtpClient();
                            client.EnableSsl = true;
                            //client.UseDefaultCredentials = true;
                            client.Credentials = new System.Net.NetworkCredential(ashghalUserName.Text.Trim(), password.Text.Trim());
                            ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                            client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                            client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                            client.Send(mailMessage);
                            //SendEmail myAction = new SendEmail(SendCompletedCallback);
                            //myAction.BeginInvoke(client, mailMessage, null, null);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Cannot perform ReTender operation, Exception occurred while sending the email notification to Tender Committee, Please inform them Personally", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            isException = true;
                        }


                        if (isException == false)
                        {
                            comCls = new CommonClass(_userName);
                            //userListColl.Clear();
                            UserList_ForAlert(1, _committeeName);

                            if (isException == false)
                            {
                                if (emailIds.Length == 0)
                                {
                                    MessageBox.Show("Information for Tender No.assignment is required to be sent to a user who handles " + _committeeName + " projects, " +
                                      " but there is no identified user to receive the email. Please contact system administrator for information.");
                                    return;
                                }
                                // this.Visible = false;
                                DialogResult dlgResult = DialogResult.Yes;
                                dlgResult = MessageBox.Show("A copy of this Project will be created and this version shall be sent to Archives if you choose to Re-tender this Project." +
                                " Are you sure want to re-tender this project? ", "", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                                string reTenderNo = null;
                                if (dlgResult.ToString() == "Yes")
                                {

                                    // Modified on Dec 30th 2013
                                    string[] strTndrNoColl = _tenderNo.Split('-');
                                    string strTndr = strTndrNoColl[strTndrNoColl.Length - 1];

                                    string strPrjPrefix = string.Empty;
                                    if (strTndr.Contains("R"))
                                    {
                                        strPrjPrefix = _tenderNo.Substring(_tenderNo.LastIndexOf('/'));
                                        strPrjPrefix = strPrjPrefix.Substring(2);
                                        if (strPrjPrefix != "")
                                        {
                                            int incrementedIdx = Convert.ToInt16(strPrjPrefix) + 1;
                                            strPrjPrefix = "/R" + incrementedIdx;
                                        }
                                        else
                                            strPrjPrefix = "/R1";
                                    }
                                    else
                                    {
                                        strPrjPrefix = "/R";
                                    }

                                    // added by Varun on 3 Jun 2015
                                    string pubOrLim = null;
                                    if (_isTenderTypeVisible)
                                    {
                                        if (_isLmtProj)
                                            pubOrLim = "L";
                                    }
                                    if (Regex.Matches(_tenderNo, "/").Count == 4 && _tenderNo.Split('/')[0].ToString() == "PWA" && !strTndr.Contains("R"))
                                    {
                                        if (pubOrLim != null)
                                        {
                                            if (!_tenderNo.Contains("/L"))
                                                reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + "/" + _tenderNo.Split('/')[3] + "/" + _tenderNo.Split('/')[4] + "/" + pubOrLim + strPrjPrefix;
                                            else
                                                reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + "/" + _tenderNo.Split('/')[3] + "/" + _tenderNo.Split('/')[4] + strPrjPrefix;
                                        }
                                        else
                                            reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + "/" + _tenderNo.Split('/')[3] + "/" + _tenderNo.Split('/')[4] + strPrjPrefix;
                                    }
                                    else if (Regex.Matches(_tenderNo, "/").Count == 3 && _tenderNo.Split('/')[0].ToString() == "PWA" && !strTndr.Contains("R"))
                                    {
                                        if (pubOrLim != null)
                                        {
                                            if (!_tenderNo.Contains("/L"))
                                                reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + "/" + _tenderNo.Split('/')[3] + "/" + pubOrLim + strPrjPrefix;
                                            else
                                                reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + "/" + _tenderNo.Split('/')[3] + strPrjPrefix;
                                        }
                                        else
                                            reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + "/" + _tenderNo.Split('/')[3] + strPrjPrefix;
                                    }
                                    else if (Regex.Matches(_tenderNo, "/").Count == 4 && _tenderNo.Split('/')[0].ToString() == "MRPSC" && !strTndr.Contains("R"))
                                    {
                                        if (pubOrLim != null)
                                        {
                                            if (!_tenderNo.Contains("/L"))
                                                reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + "/" + _tenderNo.Split('/')[3] + "/" + _tenderNo.Split('/')[4] + "/" + pubOrLim + strPrjPrefix;
                                            else
                                                reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + "/" + _tenderNo.Split('/')[3] + "/" + _tenderNo.Split('/')[4] + strPrjPrefix;
                                        }
                                        else
                                            reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + "/" + _tenderNo.Split('/')[3] + "/" + _tenderNo.Split('/')[4] + strPrjPrefix;
                                    }
                                    else if (Regex.Matches(_tenderNo, "/").Count == 3 && _tenderNo.Split('/')[0].ToString() == "MRPSC" && !strTndr.Contains("R"))
                                    {
                                        if (pubOrLim != null)
                                        {
                                            if (!_tenderNo.Contains("/L"))
                                                reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + "/" + _tenderNo.Split('/')[3] + "/" + pubOrLim + strPrjPrefix;
                                            else
                                                reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + "/" + _tenderNo.Split('/')[3] + strPrjPrefix;
                                        }
                                        else
                                            reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + "/" + _tenderNo.Split('/')[3] + strPrjPrefix;
                                    }
                                    else if (Regex.Matches(_tenderNo, "/").Count == 2 && _tenderNo.Split('/')[0].ToString() == "MRPSC" && !strTndr.Contains("R"))
                                    {
                                        if (pubOrLim != null)
                                        {
                                            if (!_tenderNo.Contains("/L"))
                                                reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + "/" + pubOrLim + strPrjPrefix;
                                            else
                                                reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + strPrjPrefix;
                                        }
                                        else
                                            reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + strPrjPrefix;
                                    }
                                    else if (Regex.Matches(_tenderNo, "/").Count == 2 && (_tenderNo.Split('/')[0].ToString() == "U&EWTC" || _tenderNo.Split('/')[0].ToString() == "EUWC") && !strTndr.Contains("R"))
                                    {
                                        if (pubOrLim != null)
                                        {
                                            if (!_tenderNo.Contains("/L"))
                                                reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + "/" + pubOrLim + strPrjPrefix;
                                            else
                                                reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + strPrjPrefix;
                                        }
                                        else
                                            reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + strPrjPrefix;
                                    }
                                    else
                                    {
                                        reTenderNo = _tenderNo.Substring(0, _tenderNo.LastIndexOf('/'));

                                        if (pubOrLim != null)
                                        {
                                            if (!reTenderNo.Contains("/L"))
                                                reTenderNo = reTenderNo + "/" + pubOrLim + strPrjPrefix;
                                            else
                                                reTenderNo = reTenderNo + strPrjPrefix;
                                        }
                                        else
                                            reTenderNo = reTenderNo + strPrjPrefix;
                                    }
                                    if (pubOrLim != null)
                                        _tndrType = pubOrLim;

                                    transforProjectsInfo(strPrjPrefix, _tndrStatus, reTenderNo);
                                    dateID = MaxDateID();
                                    transforTenderDates_Stage1();
                                   

                                    transfor_ProjectCost();

                                    UpdateDocumnts_ProjectID();

                                    UpdateProjectStatus(9);

                                    // Added by Varun on 5th Nov 2015
                                    dateID = MaxDateID();
                                    using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                                    {
                                        sqlConn.Open();
                                        SqlCommand sqlCom = new SqlCommand();
                                        sqlCom.Connection = sqlConn;
                                        sqlCom.CommandText = @"insert into TenderDatesInfo(proj_id,date_id,stage_id,remarks,update_date,update_user) values(" + _projId + "," + dateID + ",2,'This tender was Re-Tendered by " + _userName + " Dated " + DateTime.Now.ToString() + "','" + DateTime.Now.ToString() + "','" +
                                        _userName + "')";
                                        sqlCom.ExecuteNonQuery();
                                        sqlCom.Parameters.Clear();

                                        dateID = MaxDateID();
                                        sqlCom.CommandText = @"insert into TenderDatesInfo(proj_id,date_id,stage_id,remarks,update_date,update_user) values(" + _projId + "," + dateID + ",3,'This tender was Re-Tendered by " + _userName + " Dated " + DateTime.Now.ToString() + "','" + DateTime.Now.ToString() + "','" +
                                        _userName + "')";
                                        sqlCom.ExecuteNonQuery();
                                        sqlCom.Parameters.Clear();
                                    }

                                    MessageBox.Show("Copy of Project for Retender is now ready for updating the record. Old version of the record was sent to Archives");

                                    //string DisplayName = ""; string Email = ""; string Department = ""; string Title = "";
                                    string user_Department = ""; string affair_Name = ""; //string user_Title = ""
                                    // AlertOnNewTenderNo(tenderNo, _projID.ToString(), "New Project");

                                    clsTs_Stage clsForTS = new clsTs_Stage(_userName);
                                    clsForTS.GetAffairsName(Convert.ToInt32(_projId), ref user_Department, ref affair_Name);
                                    string tenderTypeFullName = null;
                                    if (_tndrType == "L")
                                        tenderTypeFullName = "Limited";
                                    else if (_tndrType == "DO")
                                        tenderTypeFullName = "Direct Order";
                                    else if (_tndrType == "PT")
                                        tenderTypeFullName = "Public Tender";
                                    else
                                        tenderTypeFullName = "Re-Tender";

                                    try
                                    {
                                        // Modified the parameters of the function GetUserInformation4rmActiveDirectory by Varun on 04/03/14 because its fetching the department of the person not the committee                        
                                        //foreach (string strname in userListColl)
                                        //{           

                                        MailMessage mailMessage = new MailMessage();
                                        //mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["MailFrom"].ToString());

                                        mailMessage.From = new MailAddress(emailID);
                                        foreach (var address in emailIds.ToString().Substring(0, emailIds.ToString().Length - 1).Split(','))
                                        {
                                            mailMessage.To.Add(new MailAddress(address, ""));
                                        }

                                        //mailMessage.To.Add(emailIds.ToString().Substring(0, emailIds.ToString().Length).Replace(";",","));
                                        mailMessage.Subject = "TCMS Alert: Tender No. " + _tenderNo + " is Re-Tendered";
                                        mailMessage.IsBodyHtml = true;

                                        mailMessage.Body = "<html><body><i style='font-family:Calibri; font-size:15'>Dear Sir/Madam,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Tender & Contract Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>" +
                                        "Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'> Tender No. " + _tenderNo + "</i><i style='font-family:Calibri; font-size:15'> has been Re-Tendered and the new Tender No. is <i style='color:Maroon;font-family:Calibri; font-size:15'>" + reTenderNo + "</i> and the details are as follows:-</i><br /><br />" +
                                        "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:#548DD4;color:White;font-family:Calibri;font-size:18;font-weight:bold'>TENDER NO: " + reTenderNo + "</td>" +
                                        "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Code</i></td><td style='font-family:Calibri;font-size:15'>" + _prjCode + "</td></tr>" +
                                        "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Title</i></td><td style='font-family:Calibri;font-size:15'>" + _projTitle + "</td></tr>" +
                                        "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Type of Tender</i></td><td style='font-family:Calibri;font-size:15'>" + tenderTypeFullName + "</td></tr>" +
                                        "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Tender Committee</i></td><td style='font-family:Calibri;font-size:15'>" + _committeeName + "</td></tr>" +
                                        "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Financial Year</i></td><td style='font-family:Calibri;font-size:15'>" + _fiscalYear + "</td></tr>" +       //+ "(" + _AffairsName + ")
                                        "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>User Dept.</i></td><td style='font-family:Calibri;font-size:15'>" + user_Department + " / " + affair_Name + " </td></tr>" +
                                        "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                                        "</table><br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>TCMS Team</div></body></html>";

                                        SmtpClient client = new SmtpClient();
                                        client.EnableSsl = true;
                                        //client.UseDefaultCredentials = true;
                                        client.Credentials = new System.Net.NetworkCredential(_userName, password.Text.Trim());
                                        ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                                        client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                                        client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                                        //client.Send(mailMessage);
                                        SendEmail myAction = new SendEmail(SendCompletedCallback);
                                        myAction.BeginInvoke(client, mailMessage, null, null);
                                        //}

                                    }
                                    catch (Exception ex)
                                    {
                                        MessageBox.Show("Exception occurred while sending the email notification to Tender Committee, Please inform them Personally", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                    }
                                }
                                ProjReTender = 'Y';
                                this.Close();
                            }
                        }
                    }

                    else
                    {
                        try
                        {
                            comCls = new CommonClass(_userName);
                            // Test Email for checking the SMTP Server is up and running Added By Varun on 31st Jan 2016
                            MailMessage mailMessage = new MailMessage();
                            mailMessage.From = new MailAddress(emailID);
                            mailMessage.To.Add(new MailAddress(ConfigurationManager.AppSettings["To"].ToString()));

                            mailMessage.Subject = "Test TCMS Alert: Project Transferred From. " + _committeeName;
                            mailMessage.IsBodyHtml = true;

                            mailMessage.Body = "<i style='font-family:Calibri; font-size:15'>Dear Sir/Madam,</i><br/><br/><i style='font-family:Calibri; font-size:15'></i><i style='font-family:Calibri; font-size:15'>This is an automated alert from Tender & Contract Management System.</i><br/><br/>" +
                            "<i style='font-family:Calibri; font-size:15'>Please be noted that the tender </i><i style='color:Blue;font-family:Calibri; font-size:15'>" + _tenderNo + "</i><i style='font-family:Calibri; font-size:15'>" +
                            " has been transferred to Tender Committee <i style='font-family:Calibri;font-size:15;color:Maroon'></i>, with Tender No. <i style='color:Maroon;font-family:Calibri; font-size:15'></i></i><br /><i>And the details are as follows:-</i>" +
                            "<br /><br /><table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:#76923C;color:White;font-family:Calibri; font-size:18;font-weight:bold'>TENDER NO:</td>" +
                            "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri; font-size:15;font-weight:bold'><i>Project Code</i></td><td style='font-family:Calibri;font-size:15'>" + _prjCode + "</td></tr><tr>" +
                            "<td style='background-color:#B58AA5;font-family:Calibri; font-size:15;font-weight:bold'><i>Project Title</i></td><td style='font-family:Calibri;font-size:15'>" + _projTitle + "</td></tr><tr>" +
                            "<td style='background-color:#B58AA5;font-family:Calibri; font-size:15;font-weight:bold'><i>Type of Tender</i></td><td style='font-family:Calibri;font-size:15'></td></tr><tr>" +
                            "<td style='background-color:#B58AA5;font-family:Calibri; font-size:15;font-weight:bold'><i>Previous Tender Committee</i></td><td style='font-family:Calibri;font-size:15'>" + _committeeName + "</td></tr><tr>" +
                            "<td style='background-color:#B58AA5;font-family:Calibri; font-size:15;font-weight:bold'><i>New Tender Committee</i></td><td style='font-family:Calibri;font-size:15'></td></tr><tr>" +
                            "<td style='background-color:#B58AA5;font-family:Calibri; font-size:15;font-weight:bold'><i>Financial Year</i></td><td style='font-family:Calibri;font-size:15'></td></tr><tr>" +               //newTndrNo.Split('/')[3].ToString()
                            "<td style='background-color:#B58AA5;font-family:Calibri; font-size:15;font-weight:bold'><i>User Dept.</i></td><td style='font-family:Calibri;font-size:15'></td></tr><tr>" +
                            "<td style='background-color:#B58AA5;font-family:Calibri; font-size:15;font-weight:bold'>Date of Creation</td><td style='font-family:Calibri;font-size:15'></td></tr></table>" +
                            "<br /><br /><div style='font-family:Calibri;font-size:15'>Best Regards,<br />TCMS Team</div>";

                            SmtpClient client = new SmtpClient();
                            client.EnableSsl = true;
                            //client.UseDefaultCredentials = true;
                            client.Credentials = new System.Net.NetworkCredential(ashghalUserName.Text.Trim(), password.Text.Trim());
                            ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                            client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                            client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                            client.Send(mailMessage);
                            //SendEmail myAction = new SendEmail(SendCompletedCallback);
                            //myAction.BeginInvoke(client, mailMessage, null, null);


                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Cannot perform Transfer Project operation, Exception occurred while sending the email notification to Tender Committee, Please inform them Personally", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            isException = true;
                        }

                        if (isException == false)
                        {
                            emailIds.Clear();
                            UserList_ForAlert(3, _committeeName);
                            if (isException == false)
                            {
                                if (emailIds.Length == 0)
                                {
                                    MessageBox.Show("Information for Tender Number Assignment is required to be sent to a user who handles " + _committeeName + " projects, " +
                                      " but there is no identified user to receive the email. Please contact system administrator for information.");
                                    return;
                                }

                                DialogResult dlgResult = DialogResult.Yes;
                                dlgResult = MessageBox.Show("Are you sure want to transfer this Project to " + _selectedCommitteeName + "?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                                DataTable dtTenderDatesInfoData = null;

                                Int16 loopCtr = 0;
                                DAL dalObj = new DAL();
                                string sqlQuery = null;

                                if (dlgResult.ToString() == "Yes")
                                {
                                    try
                                    {
                                        string strType = string.Empty;
                                        strType = "Transfer";
                                        string strPrjPrefix = " - (From " + _committeeName + ")";
                                        transforProjectsInfo(strPrjPrefix, strType, null);

                                        transforTenderDates_Stage1();
                                        transforTenderDates_Stage2();
                                        transforTenderDates_Stage3();

                                        transfor_ProjectCost();
                                        UpdateProjectStatus(10); //10==Transferred To Other Committee

                                        string _tndrTypeName = string.Empty;
                                        string _userDept = string.Empty;
                                        string _prjCreaedOn = string.Empty;
                                        string _AffairsName = string.Empty;
                                        string _newFiscalYear = string.Empty;

                                        string newTndrNo = comCls.AssignTenderNo_For_Transfor(_userRightsColl, Convert.ToInt32(_newPrjID), _tndrType, currentProjCode, _projTitle, 'T', _committeeName, _tenderNo, ref  _tndrTypeName, ref _userDept, ref _prjCreaedOn, ref _AffairsName, ref _newFiscalYear);

                                        int exeStatus = 0;
                                        string newCommitteeName = newTndrNo.Split('/')[1].ToString();
                                        UserList_ForAlert(3, newCommitteeName);
                                        // Modified by Varun on 5th Nov 2015
                                        string strMsgToTransfer = " **Note: This tender was transferred to " + newCommitteeName + " under Tender No. " + newTndrNo;
                                        SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString());
                                        SqlCommand sqlCom = null;
                                        sqlConn.Open();
                                        if (dsStg2.Tables[0].Rows.Count != 0)
                                        {
                                            if (dsStg2.Tables[0].Rows[0][16].ToString() == "")
                                                sqlQuery = "Update TenderDatesInfo Set Remarks = 'This tender was transferred by " + _userName + " Dated " + DateTime.Now.ToString() + strMsgToTransfer.Replace("'", "") + "',update_date='" + DateTime.Now.ToString() + "',update_user='" + _userName + "' Where Proj_id = " + Convert.ToInt32(dsStg2.Tables[0].Rows[0][1]) + " and stage_id =2 and ts_closing_s1 is not null";
                                            else
                                                sqlQuery = "Update TenderDatesInfo Set Remarks = 'This tender was transferred by " + _userName + " Dated " + DateTime.Now.ToString() + " " + dsStg2.Tables[0].Rows[0][16].ToString().Replace("'", "") + strMsgToTransfer.Replace("'", "") + "',update_date='" + DateTime.Now.ToString() + "',update_user='" + _userName + "' Where Proj_id = " + Convert.ToInt32(dsStg2.Tables[0].Rows[0][1]) + " and stage_id =2 and ts_closing_s1 is not null";
                                            sqlCom = new SqlCommand(sqlQuery, sqlConn);
                                            sqlCom.ExecuteNonQuery();
                                            sqlCom.Dispose();
                                        }
                                        else
                                        {
                                            // Added by Varun on 5th Nov 2015
                                            dateID = MaxDateID();
                                            using (sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                                            {
                                                sqlConn.Open();
                                                sqlCom = new SqlCommand();
                                                sqlCom.Connection = sqlConn;
                                                sqlCom.CommandText = @"insert into TenderDatesInfo(proj_id,date_id,stage_id,remarks,update_date,update_user) values(" + _projId + "," + dateID + ",2,'This tender was transferred by " + _userName + " Dated " + DateTime.Now.ToString() + strMsgToTransfer + "','" + DateTime.Now.ToString() + "','" +
                                                _userName + "')";
                                                sqlCom.ExecuteNonQuery();
                                                sqlCom.Parameters.Clear();
                                            }
                                        }

                                        if (dsStg3.Tables[0].Rows.Count != 0)
                                        {
                                            if (dsStg3.Tables[0].Rows[0][7].ToString() == "")
                                                sqlQuery = "Update TenderDatesInfo Set Remarks = 'This tender was transferred by " + _userName + " Dated " + DateTime.Now.ToString() + strMsgToTransfer.Replace("'", "") + "',update_date='" + DateTime.Now.ToString() + "',update_user='" + _userName + "' Where Proj_id = " + Convert.ToInt32(dsStg3.Tables[0].Rows[0][1]) + " and stage_id=3";
                                            else
                                                sqlQuery = "Update TenderDatesInfo Set Remarks = 'This tender was transferred by " + _userName + " Dated " + DateTime.Now.ToString() + " " + dsStg3.Tables[0].Rows[0][7].ToString().Replace("'", "") + strMsgToTransfer.Replace("'", "") + "',update_date='" + DateTime.Now.ToString() + "',update_user='" + _userName + "' Where Proj_id = " + Convert.ToInt32(dsStg3.Tables[0].Rows[0][1]) + " and stage_id=3";
                                            sqlCom = new SqlCommand(sqlQuery, sqlConn);
                                            sqlCom.ExecuteNonQuery();
                                            sqlCom.Dispose();
                                        }
                                        else
                                        {
                                            // Added by Varun on 5th Nov 2015
                                            dateID = MaxDateID();
                                            using (sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                                            {
                                                sqlConn.Open();
                                                sqlCom = new SqlCommand();
                                                sqlCom.Connection = sqlConn;
                                                sqlCom.CommandText = @"insert into TenderDatesInfo(proj_id,date_id,stage_id,remarks,update_date,update_user) values(" + _projId + "," + dateID + ",3,'This tender was transferred by " + _userName + " Dated " + DateTime.Now.ToString() + strMsgToTransfer + "','" + DateTime.Now.ToString() + "','" +
                                                _userName + "')";
                                                sqlCom.ExecuteNonQuery();
                                                sqlCom.Parameters.Clear();
                                            }
                                        }

                                        dtTenderDatesInfoData = null;
                                        sqlQuery = "select date_id, co_id from TenderDatesInfo where proj_id=" + _newPrjID + " and co_id is not null";
                                        dtTenderDatesInfoData = dalObj.GetDataFromDB("TenderDatesInfoData", sqlQuery);
                                        loopCtr = 0;

                                        sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString());
                                        sqlConn.Open();

                                        while (loopCtr < dtTenderDatesInfoData.Rows.Count)
                                        {
                                            sqlQuery = "Update DOCUMENTS Set proj_id = " + _newPrjID + ",date_id=" + Convert.ToInt32(dtTenderDatesInfoData.Rows[loopCtr][0]) + " Where Proj_id = " + _projId + " and date_id is not null and co_id =" + Convert.ToInt16(dtTenderDatesInfoData.Rows[loopCtr][1]);
                                            sqlCom = new SqlCommand(sqlQuery, sqlConn);
                                            exeStatus = sqlCom.ExecuteNonQuery();
                                            loopCtr++;
                                        }


                                        string sqlUpdate = "Update DOCUMENTS Set proj_id = " + _newPrjID + " Where Proj_id = " + _projId + " and date_id is null and co_id is not null";
                                        if (sqlCom != null)
                                            sqlCom.Dispose();
                                        sqlCom = new SqlCommand(sqlUpdate, sqlConn);
                                        exeStatus = sqlCom.ExecuteNonQuery();
                                        MessageBox.Show("Selected Project Transferred to other committee.");
                                        sqlConn.Close();                                       
                                                                               

                                        try
                                        {                                           

                                            MailMessage mailMessage = new MailMessage();
                                            mailMessage.From = new MailAddress(emailID);                                             
                                            //mailMessage.To.Add(emailIds.ToString().Substring(0, emailIds.ToString().Length - 1));
                                            foreach (var address in emailIds.ToString().Substring(0, emailIds.ToString().Length - 1).Split(','))
                                            {
                                                mailMessage.To.Add(new MailAddress(address, ""));
                                            }
                                            mailMessage.Subject = "TCMS Alert: Project Transferred From. " + _committeeName + " To: " + newCommitteeName + " with Tender No.:" + newTndrNo;
                                            mailMessage.IsBodyHtml = true;

                                            mailMessage.Body = "<i style='font-family:Calibri; font-size:15'>Dear Sir/Madam,</i><br/><br/><i style='font-family:Calibri; font-size:15'></i><i style='font-family:Calibri; font-size:15'>This is an automated alert from Tender & Contract Management System.</i><br/><br/>" +
                                            "<i style='font-family:Calibri; font-size:15'>Please be noted that the tender </i><i style='color:Blue;font-family:Calibri; font-size:15'>" + _tenderNo + "</i><i style='font-family:Calibri; font-size:15'>" +
                                            " has been transferred to Tender Committee <i style='font-family:Calibri;font-size:15;color:Maroon'>" + newCommitteeName + "</i>, with Tender No. <i style='color:Maroon;font-family:Calibri; font-size:15'>" + newTndrNo + ".</i></i><br /><i>And the details are as follows:-</i>" +
                                            "<br /><br /><table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:#76923C;color:White;font-family:Calibri; font-size:18;font-weight:bold'>TENDER NO: " + newTndrNo + "</td>" +
                                            "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri; font-size:15;font-weight:bold'><i>Project Code</i></td><td style='font-family:Calibri;font-size:15'>" + _prjCode + "</td></tr><tr>" +
                                            "<td style='background-color:#B58AA5;font-family:Calibri; font-size:15;font-weight:bold'><i>Project Title</i></td><td style='font-family:Calibri;font-size:15'>" + _projTitle + "</td></tr><tr>" +
                                            "<td style='background-color:#B58AA5;font-family:Calibri; font-size:15;font-weight:bold'><i>Type of Tender</i></td><td style='font-family:Calibri;font-size:15'>" + _tndrTypeName + "</td></tr><tr>" +
                                            "<td style='background-color:#B58AA5;font-family:Calibri; font-size:15;font-weight:bold'><i>Previous Tender Committee</i></td><td style='font-family:Calibri;font-size:15'>" + _committeeName + "</td></tr><tr>" +
                                            "<td style='background-color:#B58AA5;font-family:Calibri; font-size:15;font-weight:bold'><i>New Tender Committee</i></td><td style='font-family:Calibri;font-size:15'>" + newCommitteeName + "</td></tr><tr>" +
                                            "<td style='background-color:#B58AA5;font-family:Calibri; font-size:15;font-weight:bold'><i>Financial Year</i></td><td style='font-family:Calibri;font-size:15'>" + _newFiscalYear + "</td></tr><tr>" +               //newTndrNo.Split('/')[3].ToString()
                                            "<td style='background-color:#B58AA5;font-family:Calibri; font-size:15;font-weight:bold'><i>User Dept.</i></td><td style='font-family:Calibri;font-size:15'>" + _userDept + " / " + _AffairsName + "</td></tr><tr>" +
                                            "<td style='background-color:#B58AA5;font-family:Calibri; font-size:15;font-weight:bold'>Date of Creation</td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr></table>" +
                                            "<br /><br /><div style='font-family:Calibri;font-size:15'>Best Regards,<br />TCMS Team</div>";


                                            SmtpClient client = new SmtpClient();
                                            client.EnableSsl = true;
                                            //client.UseDefaultCredentials = true;
                                            client.Credentials = new System.Net.NetworkCredential(ashghalUserName.Text.Trim(), password.Text.Trim());
                                            ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                                            client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                                            client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                                            //client.Send(mailMessage);
                                            SendEmail myAction = new SendEmail(SendCompletedCallback);
                                            myAction.BeginInvoke(client, mailMessage, null, null);
                                            //}                                

                                        }
                                        catch (Exception ex)
                                        {
                                            MessageBox.Show("Exception occurred while sending the email notification to Tender Committee, Please inform them Personally", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                        }

                                        ProjTransfered = 'Y';
                                        this.Close();

                                    }
                                    catch (Exception ex)
                                    {
                                        MessageBox.Show("Error occurred while creating the duplicate records for the project to be transferred.", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                    }

                                }
                            }
                        }
                    }
                }
            }
        }

        private delegate void SendEmail(SmtpClient smtpclient, System.Net.Mail.MailMessage mail);

        char chProjTransfered = ' ';
        public char ProjTransfered
        {
            get { return chProjTransfered; }
            set { chProjTransfered = value; }
        }
        private void UpdateProjectStatus(int statusID)
        {
            SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString());
            sqlConn.Open();
            string insertQuery = "UPDATE PROJECTS SET Tender_Status_id = @tndtStatus,moazanah_proj_id = @MoazID WHERE proj_id = @prjID";
            using (SqlCommand cmd = new SqlCommand(insertQuery, sqlConn))
            {
                cmd.Parameters.AddWithValue("@prjID", _projId);
                cmd.Parameters.AddWithValue("@tndtStatus", statusID);
                cmd.Parameters.AddWithValue("@MoazID", DBNull.Value);
                int exUpdated = cmd.ExecuteNonQuery();
                cmd.Parameters.Clear();
            }
        }

        private void UpdateDocumnts_ProjectID()
        {
            SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString());
            sqlConn.Open();
            //doc_type_id<>2 Added by Varun on 04 Feb 2014 Based on req. from Adonis
            string insertQuery = "UPDATE DOCUMENTS SET Proj_ID =  " + _newPrjID + " WHERE Proj_ID = " + _projId + " and doc_type_id<>2";
            using (SqlCommand cmd = new SqlCommand(insertQuery, sqlConn))
            {
                int exUpdated = cmd.ExecuteNonQuery();
                cmd.Parameters.Clear();
            }
            sqlConn.Close();
        }

        private void transfor_ProjectCost()
        {
            string sqlQuery = "update ProjectCost set proj_id =" + _newPrjID + " WHERE (proj_id =" + _projId+ ") AND (stage_id = 4) ";
            SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString());
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            sqlCom.ExecuteNonQuery();
        }

        private void transforProjectsInfo(string prjPrifix, string statusType, string reTenderNo)
        {
            DataSet dsProjects = new DataSet();
            string sqlQuery = "Select proj_id,project_code,project_newname_en,committee_id, " +
                        " FYID, Affair_id, department_id, contract_type_id, tender_type_id, project_newname_en,project_name_ar,stage_id, " +
                        " SelectPrj,Tender_Status_id,[Ministry_Code],[Budget_Reference_No],[Provision_Number],moazanah_proj_id,tender_no,create_date From Projects Where proj_id = " + _projId + "";
            using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
            {
                sqlConn.Open();
                using (SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn))
                {
                    SqlDataAdapter daPrj = new SqlDataAdapter(sqlCom);
                    daPrj.Fill(dsProjects);
                }
                sqlConn.Close();
            }
            InsertProjectsInfo(dsProjects, prjPrifix, statusType, reTenderNo);
        }

        private int GetStatus_ID()
        {
            int cmtID = 0;
            string sqlUpdate = "SELECT committee_id FROM Committee WHERE (committee_short_name = '" + _selectedCommitteeName + "')";
            using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
            {
                sqlConn.Open();
                using (SqlCommand sqlCom = new SqlCommand(sqlUpdate, sqlConn))
                {
                    cmtID = Convert.ToInt16(sqlCom.ExecuteScalar());
                }
                sqlConn.Close();
            }
            return cmtID;
        }

        string currentProjCode = null;
        private void InsertProjectsInfo(DataSet dsProj, string prjCodePrefix, string _statusType, string reTenderNo)
        {
            DAL dalObj = new DAL();
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                {
                    int _getcmtID = 0;
                    sqlConn.Open();
                    for (int i = 0; i < dsProj.Tables[0].Rows.Count; i++)
                    {
                        // DataRow dRow = ds.Tables[0].Rows[i][0];

                        if (_statusType.Contains("Transfer"))
                        {
                            _getcmtID = GetStatus_ID();
                        }

                        string insertQuery = "INSERT INTO PROJECTS(proj_id,project_code, project_newname_en,committee_id, " +
                             " FYID, Affair_id, department_id, contract_type_id, tender_type_id, project_name_en,project_name_ar,stage_id,SelectPrj,Tender_Status_id,[Ministry_Code],[Budget_Reference_No],[Provision_Number],moazanah_proj_id,tender_no,dummyfield,create_date," +
                             "create_user) " +
                             " VALUES(@prjID,@PrjCode,@PrjTitleEnNew,@CmtId,@FiscalID,@AffairID,@UserDept,@TypeOfPrj,@TypeOfTndr,@PrjTitleEn, @PrjTitleArb,@StageID,@SelPrj,@TndrStatusId,@MinistryCode,@BudgetRefNo,@ProvisionNo,@moazanah_id,@tndrNO,@dummy_field,@createDate," +
                             "@createUser)";

                        using (SqlCommand cmd = new SqlCommand(insertQuery, sqlConn))
                        {
                            cmd.Parameters.AddWithValue("@prjID", _newPrjID);

                            // Modified as per faisal request on Dec 30th 2013 By Sreedhar
                            // Modified by Varun on Jan 29 2013
                            // Modified by Varun on Aug 12 2014
                            if (!(_statusType.Contains("Transfer")))
                            {
                                currentProjCode = dsProj.Tables[0].Rows[i][1].ToString();
                            }
                            else
                            {
                                currentProjCode = dsProj.Tables[0].Rows[i][1].ToString() + prjCodePrefix;
                            }

                            //currentProjCode = dsProj.Tables[0].Rows[i][1].ToString();
                            cmd.Parameters.AddWithValue("@PrjCode", currentProjCode);

                            cmd.Parameters.AddWithValue("@PrjTitleEnNew", dsProj.Tables[0].Rows[i][2].ToString());

                            if (_statusType.Contains("Transfer"))
                            {
                                cmd.Parameters.AddWithValue("@CmtId", _getcmtID);
                                if (dsProj.Tables[0].Rows[i][13].ToString() == "")
                                {
                                    cmd.Parameters.AddWithValue("@StageID", 1);
                                    cmd.Parameters.AddWithValue("@TndrStatusId", 1);
                                }
                                else if (Convert.ToInt32(dsProj.Tables[0].Rows[i][13].ToString()) >= 4)
                                {
                                    cmd.Parameters.AddWithValue("@StageID", 3); //3==Tender Evaluation & Award
                                    cmd.Parameters.AddWithValue("@TndrStatusId", 3); //3==Technical Evaluation
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@StageID", dsProj.Tables[0].Rows[i][11].ToString());
                                    cmd.Parameters.AddWithValue("@TndrStatusId", dsProj.Tables[0].Rows[i][13].ToString());
                                }
                            }
                            else
                            {
                                cmd.Parameters.AddWithValue("@CmtId", Convert.ToInt16(dsProj.Tables[0].Rows[i][3]));
                                cmd.Parameters.AddWithValue("@StageID", 1);
                                cmd.Parameters.AddWithValue("@TndrStatusId", 1);
                            }

                            //if (Convert.ToDateTime(dsProj.Tables[0].Rows[i][19]).Year == DateTime.Now.Year)
                            //{
                            //    cmd.Parameters.AddWithValue("@FiscalID", Convert.ToInt16(dsProj.Tables[0].Rows[i][4]));
                            //}
                            //else
                            //{
                            cmd.Parameters.AddWithValue("@FiscalID", Convert.ToInt16(dsProj.Tables[0].Rows[i][4]));
                            //}

                            cmd.Parameters.AddWithValue("@AffairID", Convert.ToInt16(dsProj.Tables[0].Rows[i][5]));
                            cmd.Parameters.AddWithValue("@UserDept", Convert.ToInt16(dsProj.Tables[0].Rows[i][6]));
                            cmd.Parameters.AddWithValue("@TypeOfPrj", Convert.ToInt16(dsProj.Tables[0].Rows[i][7]));
                            cmd.Parameters.AddWithValue("@TypeOfTndr", Convert.ToInt16(dsProj.Tables[0].Rows[i][8]));
                            cmd.Parameters.AddWithValue("@PrjTitleEn", dsProj.Tables[0].Rows[i][9]);
                            cmd.Parameters.AddWithValue("@PrjTitleArb", dsProj.Tables[0].Rows[i][10]);

                            cmd.Parameters.AddWithValue("@SelPrj", 1);
                            cmd.Parameters.AddWithValue("@MinistryCode", dsProj.Tables[0].Rows[i][14]);
                            cmd.Parameters.AddWithValue("@BudgetRefNo", dsProj.Tables[0].Rows[i][15]);
                            if (dsProj.Tables[0].Rows[i][16].ToString() != "")
                                cmd.Parameters.AddWithValue("@ProvisionNo", dsProj.Tables[0].Rows[i][16]);
                            else
                                cmd.Parameters.AddWithValue("@ProvisionNo", DBNull.Value);

                            cmd.Parameters.AddWithValue("@moazanah_id", dsProj.Tables[0].Rows[i][17]);

                            if (!_statusType.Contains("Transfer"))
                            {
                                string newTndrCode = null;
                                if (reTenderNo != null)
                                {
                                    if (reTenderNo.Contains("R"))
                                    {                                        
                                        cmd.Parameters.AddWithValue("@tndrNO", reTenderNo);
                                    }
                                    else
                                    {
                                        newTndrCode = dsProj.Tables[0].Rows[i][18].ToString() + prjCodePrefix;
                                        cmd.Parameters.AddWithValue("@tndrNO", newTndrCode);
                                    }
                                }
                                else
                                    cmd.Parameters.AddWithValue("@tndrNO", DBNull.Value);
                            }
                            else
                                cmd.Parameters.AddWithValue("@tndrNO", DBNull.Value);

                            cmd.Parameters.AddWithValue("@dummy_field", System.DateTime.Now);
                            cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                            cmd.Parameters.AddWithValue("@createUser", _userName);


                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                    }
                    sqlConn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while inserting projects info" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UserList_ForAlert(int categryID, string committeeName)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        string sqlQuery = "SELECT DISTINCT EmailAlertRecipients.user_id, USERS.email_address, USERS.user_name, EmailAlertCategory.AlertCategory, EmailAlertRecipients.alert_cat_id, " +
                         " Committee.committee_short_name FROM EmailAlertCategory INNER JOIN EmailAlertRecipients ON EmailAlertCategory.alert_cat_id = EmailAlertRecipients.alert_cat_id INNER JOIN " +
                         " USERS ON EmailAlertRecipients.user_id = USERS.user_id INNER JOIN Committee ON EmailAlertRecipients.committee_id = Committee.committee_id " +
                         " WHERE (EmailAlertRecipients.alert_cat_id = " + categryID + ") AND (USERS.email_address <> N'') AND (Committee.committee_short_name ='" + committeeName + "')";

                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                emailIds.Append(dr[1].ToString() + ",");
                                //if (!userListColl.Contains(strData))
                                //    userListColl.Add(strData);
                            }
                            dr.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE DATES records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                isException = true;
            }
        }

        
        bool createNewProject()
        {
            bool isErrorOccurred = false;
            try
            {
                string emailID = FindEmailIDOfTheUser(_userName);
                if (emailID != null)
                {
                    // Test Email for checking the SMTP Server is up and running Added By Varun on 31st Jan 2016
                    //MailMessage mailMessage = new MailMessage();

                    //mailMessage.From = new MailAddress(emailID);
                    //mailMessage.To.Add(new MailAddress(ConfigurationManager.AppSettings["To"].ToString()));
                    //mailMessage.Subject = "TCMS Alert: New Project is going to get created";
                    //mailMessage.IsBodyHtml = true;


                    //mailMessage.Body = "<html><body><i style='font-family:Calibri; font-size:15'>Dear Sir/Madam,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Tender & Contract Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>" +
                    //"Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'> New " + _mohOrNonMohProjType + " Project having Project Code/ID: " + _mohOrNonMohPrjCode + " is about to get created</i><br /><br />" +
                    //"<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation:</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now.ToString("dd/MMM/yyyy") + "</td></tr>" +
                    //"</table><br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>TCMS Team</div></body></html>";

                    //SmtpClient client = new SmtpClient();
                    //client.EnableSsl = true;
                    ////client.UseDefaultCredentials = true;
                    //client.Credentials = new System.Net.NetworkCredential(@"Ashghal\" + ashghalUserName.Text.Trim(), password.Text); //
                    ////client.Credentials = new System.Net.NetworkCredential(@"Ashghal\ESD", "03esd@2020"); //
                    //ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                    ////client.Host = "172.30.30.44"; // ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                    ////client.Port = 25; // Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                    //client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                    //client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                    //client.Send(mailMessage);                    
                    if (_mohOrNonMohProjType == "Non-Moazanah")
                    {
                        InsertNonMoazanahProj(null, ashghalUserName.Text.Trim(), password.Text);                            
                            
                    }
                    else if (_mohOrNonMohProjType == "Moazanah")
                    {
                        InsertMoazanahData(null, ashghalUserName.Text.Trim(), password.Text);
                        //btnMoazzanahProceed.Enabled = false;
                    }

                }

            }
            catch (Exception ex)
            {
            //    MessageBox.Show("Unable to create New " + _mohOrNonMohProjType + " Project, having Project Code/ID: " + _prjCode + ". Error occurred while sending the email notification to ESD Department, Please inform network administrator about send email functionality not working",
            //    "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            //    isErrorOccurred = true;                 
            }
            return isErrorOccurred;
        }


        private void InsertNonMoazanahProj(string emailID, string ashghalUserName, string password)
        {
            SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString());
            try
            {
                int prjID = 0;
                sqlConn.Open();
                SqlCommand sqlCom = new SqlCommand("select MAX(Proj_ID) from PROJECTS", sqlConn);
                prjID = Convert.ToInt16(sqlCom.ExecuteScalar());
                prjID = prjID + 1;
                sqlConn.Close();                

                using (TransactionScope scope = new TransactionScope())
                {
                    using (SqlConnection sqlInnerConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                    {
                        sqlInnerConn.Open();
                        string insertQuery = "INSERT INTO PROJECTS(proj_id,project_code, project_newname_en,committee_id, " +
                        " FYID, Affair_id, department_id, contract_type_id, tender_type_id, project_name_en,project_name_ar,stage_id,SelectPrj,Tender_Status_id,[Ministry_Code],[Budget_Reference_No],[Provision_Number],dummyfield,Create_Date,Create_User,isDeleted) " +
                        " VALUES(@prjID,@PrjCode,@PrjTitleEnNew,@CmtId,@FiscalID,@AffairID,@UserDept,@TypeOfPrj,@TypeOfTndr,@PrjTitleEn, @PrjTitleArb,@StatusID,@SelPrj,@TndrStatusId,@MinistryCode,@BudgetRefNo,@ProvisionNo,@dummy_field,@CreateDate,@CreateUser,@isDeleted)";


                        using (SqlCommand cmd = new SqlCommand(insertQuery, sqlInnerConn))
                        {
                            cmd.Parameters.AddWithValue("@prjID", Convert.ToInt16(prjID));
                            cmd.Parameters.AddWithValue("@PrjCode", _mohOrNonMohPrjCode);//txtNonMohProjCode.Text.Replace(" ", "").Trim()
                            cmd.Parameters.AddWithValue("@PrjTitleEnNew", _mohOrNonMohPrjTitleEn); //txtNonMohProjTitleEn.Text
                            cmd.Parameters.AddWithValue("@CmtId", _mohOrNonMohCommitteeId); //cmbNonMohTenderCommittee.SelectedValue
                           
                            cmd.Parameters.AddWithValue("@FiscalID", _mohOrNonMohFiscalId); //cmbNonMohFiscalYr.SelectedValue
                            cmd.Parameters.AddWithValue("@AffairID", _mohOrNonMohAffairsId); //cmbNonMohAffairs.SelectedValue
                            cmd.Parameters.AddWithValue("@UserDept", _mohOrNonMohUserDeptId); //cmbNonMohUserDept.SelectedValue
                            cmd.Parameters.AddWithValue("@TypeOfPrj", _mohOrNonMohTypeOfPrjId); //cmbNonMohTypeOfProject.SelectedValue
                            cmd.Parameters.AddWithValue("@TypeOfTndr", _mohOrNonTenderTypeId); //cmbNonMohTypeOfTender.SelectedValue
                            cmd.Parameters.AddWithValue("@PrjTitleEn", _mohOrNonMohPrjTitleEn); //txtNonMohProjTitleEn.Text
                            cmd.Parameters.AddWithValue("@PrjTitleArb", _mohOrNonMohPrjTitleAr); //txtNonMohProjTitleAr.Text
                            cmd.Parameters.AddWithValue("@StatusID", 1);
                            cmd.Parameters.AddWithValue("@SelPrj", 1);
                            cmd.Parameters.AddWithValue("@TndrStatusId", 1);

                            cmd.Parameters.AddWithValue("@MinistryCode", _mohOrNonMohMinistryCode); //cmbNonMozMinistryCode.Text
                            cmd.Parameters.AddWithValue("@BudgetRefNo", _mohOrNonMohBudgetRefNo); //cmbNonMozBudjetRef.Text
                            if (_mohOrNonMohProvisionNo != "")
                                cmd.Parameters.AddWithValue("@ProvisionNo", _mohOrNonMohProvisionNo); //txtNonProvisionNo.Text
                            else
                                cmd.Parameters.AddWithValue("@ProvisionNo", DBNull.Value);

                            cmd.Parameters.AddWithValue("@dummy_field", System.DateTime.Now);

                            cmd.Parameters.AddWithValue("@CreateDate", System.DateTime.Now);
                            cmd.Parameters.AddWithValue("@CreateUser", _userName);
                            cmd.Parameters.AddWithValue("@isDeleted", 0);
                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                         
                        string insertQueryBdgt = "INSERT INTO ProjectCost(stage_id, proj_id, budgeted_cost,bidder_id,create_date,create_user) VALUES(@stgID,@PrjID,@budgetAmnt,@bidID,@createDate,@createUser)";
                        using (SqlCommand cmd = new SqlCommand(insertQueryBdgt, sqlInnerConn))
                        {
                            // cmd.Parameters.AddWithValue("@costID", Convert.ToInt16(_costID));
                            cmd.Parameters.AddWithValue("@stgID", 4);
                            cmd.Parameters.AddWithValue("@PrjID", Convert.ToInt16(prjID));
                            cmd.Parameters.AddWithValue("@bidID", DBNull.Value);

                            if (_mohOrNonMohBudgetAmt != "")
                            {
                                if (_mohOrNonMohBudgetAmt.Contains("QAR"))
                                {

                                    // txtMozBudjet.Text = txtMozBudjet.Text.Substring(0, txtMozBudjet.Text.Length);
                                    cmd.Parameters.AddWithValue("@budgetAmnt", Convert.ToDouble(_mohOrNonMohBudgetAmt.Substring(3, _mohOrNonMohBudgetAmt.Length - 3)));
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@budgetAmnt", Convert.ToDouble(_mohOrNonMohBudgetAmt));
                                }
                            }
                            else
                            {
                                cmd.Parameters.AddWithValue("@budgetAmnt", DBNull.Value);
                            }

                            cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                            cmd.Parameters.AddWithValue("@createUser", _userName);

                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                        sqlInnerConn.Close();
                    }
                    scope.Complete();
                    //txtNonMohProjCode.Text, cmbNonMozBudjetRef.Text
                    MessageBox.Show("Non-Moazanah Project Added Successfully", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while inserting the project details, Try again", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                _mohOrNonMohProjType = "Error";
            }
            finally
            {
                sqlConn.Close();
            }

            if (_mohOrNonMohProjType != "Error")
            {
                SendEmailsToEBSD(_mohOrNonMohPrjCode, _mohOrNonMohBudgetRefNo, emailID, ashghalUserName, password);
            }

        }

        private void InsertMoazanahData(string emailID, string ashghalUserName, string password) 
        {
            int _prjID = 0;                 

            try
            {
                SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString());
                sqlConn.Open();
                SqlCommand sqlCom = new SqlCommand("select MAX(proj_id) from Projects", sqlConn);
                _prjID = Convert.ToInt16(sqlCom.ExecuteScalar());
                _prjID = _prjID + 1;
                sqlConn.Close();
               
                using (TransactionScope scope = new TransactionScope())
                {
                    using (SqlConnection sqlInnerConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                    {
                        sqlInnerConn.Open();
                        string insertQuery = "INSERT INTO PROJECTS(proj_id,project_code, project_newname_en,committee_id, " +
                        " FYID, Affair_id, department_id, contract_type_id, tender_type_id, project_name_en,project_name_ar,stage_id,SelectPrj,Tender_Status_id,[Ministry_Code],[Budget_Reference_No],[Provision_Number],moazanah_proj_id,dummyfield,Create_Date,Create_User,isDeleted) " +
                        " VALUES(@prjID,@PrjCode,@PrjTitleEnNew,@CmtId,@FiscalID,@AffairID,@UserDept,@TypeOfPrj,@TypeOfTndr,@PrjTitleEn, @PrjTitleArb,@StatusID,@SelPrj,@TndrStatusId,@MinistryCode,@BudgetRefNo,@ProvisionNo,@moazPrjID,@dumfield,@CreateDate,@CreateUser,@isDeleted)";

                        
                        using (SqlCommand cmd = new SqlCommand(insertQuery, sqlInnerConn))
                        {
                            cmd.Parameters.AddWithValue("@prjID", Convert.ToInt16(_prjID));
                            cmd.Parameters.AddWithValue("@PrjCode", _mohOrNonMohPrjCode);
                            cmd.Parameters.AddWithValue("@PrjTitleEnNew", _mohOrNonMohPrjTitleEn);
                            cmd.Parameters.AddWithValue("@CmtId", _mohOrNonMohCommitteeId);                            
                            cmd.Parameters.AddWithValue("@FiscalID", _mohOrNonMohFiscalId);
                            cmd.Parameters.AddWithValue("@AffairID", _mohOrNonMohAffairsId);
                            cmd.Parameters.AddWithValue("@UserDept", _mohOrNonMohUserDeptId);
                            cmd.Parameters.AddWithValue("@TypeOfPrj", _mohOrNonMohTypeOfPrjId);
                            cmd.Parameters.AddWithValue("@TypeOfTndr", _mohOrNonTenderTypeId);
                            cmd.Parameters.AddWithValue("@PrjTitleEn", _mohOrNonMohPrjTitleEn);
                            cmd.Parameters.AddWithValue("@PrjTitleArb", _mohOrNonMohPrjTitleAr);
                            cmd.Parameters.AddWithValue("@StatusID", 1);
                            cmd.Parameters.AddWithValue("@SelPrj", 1);
                            cmd.Parameters.AddWithValue("@TndrStatusId", 1);

                            cmd.Parameters.AddWithValue("@MinistryCode", _mohOrNonMohMinistryCode);
                            cmd.Parameters.AddWithValue("@BudgetRefNo", _mohOrNonMohBudgetRefNo);

                            if (_mohOrNonMohProvisionNo != "")
                                cmd.Parameters.AddWithValue("@ProvisionNo", _mohOrNonMohProvisionNo);
                            else
                                cmd.Parameters.AddWithValue("@ProvisionNo", DBNull.Value);

                            cmd.Parameters.AddWithValue("@moazPrjID", _mohOrNonMohPrjId);
                            cmd.Parameters.AddWithValue("@dumfield", System.DateTime.Now);

                            cmd.Parameters.AddWithValue("@CreateDate", System.DateTime.Now);
                            cmd.Parameters.AddWithValue("@CreateUser", _userName);
                            cmd.Parameters.AddWithValue("@isDeleted", 0);

                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                         
                        string insertQueryBdgt = "INSERT INTO ProjectCost(stage_id, proj_id, budgeted_cost,create_date,create_user) VALUES(@stgID,@PrjID,@budgetAmnt,@createDate,@createUser)";
                        using (SqlCommand cmd = new SqlCommand(insertQueryBdgt, sqlInnerConn))
                        {
                            //cmd.Parameters.AddWithValue("@costID", Convert.ToInt16(_costID));
                            cmd.Parameters.AddWithValue("@stgID", 4);
                            cmd.Parameters.AddWithValue("@PrjID", Convert.ToInt16(_prjID));
                            if (_mohOrNonMohBudgetAmt != "")
                            {
                                if (_mohOrNonMohBudgetAmt.Contains("QAR"))
                                {

                                    // txtMozBudjet.Text = txtMozBudjet.Text.Substring(0, txtMozBudjet.Text.Length);
                                    cmd.Parameters.AddWithValue("@budgetAmnt", Convert.ToDouble(_mohOrNonMohBudgetAmt.Substring(3, _mohOrNonMohBudgetAmt.Length - 3)));
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@budgetAmnt", Convert.ToDouble(_mohOrNonMohBudgetAmt));
                                }
                            }
                            else
                            {
                                cmd.Parameters.AddWithValue("@budgetAmnt", DBNull.Value);
                            }

                            cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                            cmd.Parameters.AddWithValue("@createUser", "FROM MOAZANAH");

                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                        sqlInnerConn.Close();
                    }
                    scope.Complete();
                    MessageBox.Show(_mohOrNonMohProjType + " Project Added Successfully ", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    //this.Close();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while inserting the project details, Try again", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                _mohOrNonMohProjType = "Error";
            }

            if (_mohOrNonMohProjType != "Error")
            {
                SendEmailsToEBSD(_mohOrNonMohPrjCode, _mohOrNonMohBudgetRefNo, emailID, ashghalUserName, password);
            }

        }         

        private void SendEmailsToEBSD(string projCode, string budgetRefCode, string emailId, string ashghalUserName, string password)
        {
            
            try
            {                                  

                MailMessage mailMessage = new MailMessage();

                mailMessage.From = new MailAddress(emailId);
                //mailMessage.To.Add(ConfigurationManager.AppSettings["EBSDStaffEmails"].ToString());
                foreach (var address in ConfigurationManager.AppSettings["EBSDStaffEmails"].ToString().Split(','))
                {
                    mailMessage.To.Add(new MailAddress(address.Trim(), ""));
                }

                mailMessage.Subject = "TCMS Alert: New Project with project code " + projCode + " has been added";

                mailMessage.IsBodyHtml = true;

                string emailBodyText = null;

                emailBodyText = "<html><body><i style='font-family:Calibri; font-size:15'>Dear Sir/Madam,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Tender & Contract Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>";
                if (budgetRefCode != "")
                {
                    string twoChars = budgetRefCode.Substring(0, 2);
                    if (twoChars.Equals("14"))
                    {
                        emailBodyText = emailBodyText + "Please be noted that</i><i style='color:#1F4E79;font-family:Calibri; font-size:15'> New Project with project code " + projCode + ", Budget Reference No." + budgetRefCode + " and Chapter-4 has been added to TCMS</i>";
                    }
                    else if (twoChars.Equals("12") || twoChars.Equals("13"))
                    {
                        emailBodyText = emailBodyText + "Please be noted that</i><i style='color:#1F4E79;font-family:Calibri; font-size:15'> New Project with project code " + projCode + ", Budget Reference No." + budgetRefCode + " and Chapter-2,3 has been added to TCMS</i>";
                    }
                }
                else
                {
                    emailBodyText = emailBodyText + "Please be noted that</i><i style='color:#1F4E79;font-family:Calibri; font-size:15'> New Project with project code " + projCode + " has been added to TCMS, without any Chapter information</i>";
                }

                emailBodyText = emailBodyText + "<br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>TCMS Team</div></body></html>";

                mailMessage.Body = emailBodyText;
                SmtpClient client = new SmtpClient();
                client.EnableSsl = true;
                client.Credentials = new System.Net.NetworkCredential(ashghalUserName, password);
                ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                client.Send(mailMessage);               

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while sending the email notification to Engineering Services Department, Please inform them Personally", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void submit_Click(object sender, EventArgs e)
        {
            if (_isProjTransfer == false)
            {
                if (_userRightsColl != null)
                {
                    TenderNum = assignTenderNo();
                    this.Close();
                }
                else
                {
                    IsErrorOccurred = createNewProject();
                    this.Close();
                }
            }
            else 
            {
                transferProject();
                this.Close();
            }
        }

        private void close_Click(object sender, EventArgs e)
        {
            this.Close();
        }        
    }
}
