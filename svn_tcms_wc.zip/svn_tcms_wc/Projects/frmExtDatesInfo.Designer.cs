﻿namespace MDI_ParenrForm.Projects
{
    partial class frmExtDatesInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.msk_dtpTBV_SEdate_Cp = new System.Windows.Forms.MaskedTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.msk_dtpTV_SEdate_Cp = new System.Windows.Forms.MaskedTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.msk_dtpTBV_FEdate_Cp = new System.Windows.Forms.MaskedTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.msk_dtpTV_FEdate_Cp = new System.Windows.Forms.MaskedTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.msk_dtpTBV_OrgDate_Cp = new System.Windows.Forms.MaskedTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.msk_dtpTV_OrgDate_Cp = new System.Windows.Forms.MaskedTextBox();
            this.dtpTV_FEdate_Cp = new System.Windows.Forms.DateTimePicker();
            this.dtpTV_SEdate_Cp = new System.Windows.Forms.DateTimePicker();
            this.dtpTBV_FEdate_Cp = new System.Windows.Forms.DateTimePicker();
            this.dtpTBV_SEdate_Cp = new System.Windows.Forms.DateTimePicker();
            this.txtCp_TVDays = new System.Windows.Forms.TextBox();
            this.txtCp_TBVDays = new System.Windows.Forms.TextBox();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Controls.Add(this.msk_dtpTBV_SEdate_Cp);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.msk_dtpTV_SEdate_Cp);
            this.groupBox5.Controls.Add(this.label5);
            this.groupBox5.Controls.Add(this.msk_dtpTBV_FEdate_Cp);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.msk_dtpTV_FEdate_Cp);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.msk_dtpTBV_OrgDate_Cp);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Controls.Add(this.msk_dtpTV_OrgDate_Cp);
            this.groupBox5.Controls.Add(this.dtpTV_FEdate_Cp);
            this.groupBox5.Controls.Add(this.dtpTV_SEdate_Cp);
            this.groupBox5.Controls.Add(this.dtpTBV_FEdate_Cp);
            this.groupBox5.Controls.Add(this.dtpTBV_SEdate_Cp);
            this.groupBox5.Controls.Add(this.txtCp_TVDays);
            this.groupBox5.Controls.Add(this.txtCp_TBVDays);
            this.groupBox5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox5.Location = new System.Drawing.Point(21, 13);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox5.Size = new System.Drawing.Size(509, 149);
            this.groupBox5.TabIndex = 225;
            this.groupBox5.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Cornsilk;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Chocolate;
            this.label3.Location = new System.Drawing.Point(120, 26);
            this.label3.Name = "label3";
            this.label3.Padding = new System.Windows.Forms.Padding(3);
            this.label3.Size = new System.Drawing.Size(81, 34);
            this.label3.TabIndex = 139;
            this.label3.Text = "  Original   \r\nExpiry Date    ";
            // 
            // msk_dtpTBV_SEdate_Cp
            // 
            this.msk_dtpTBV_SEdate_Cp.Location = new System.Drawing.Point(302, 104);
            this.msk_dtpTBV_SEdate_Cp.Name = "msk_dtpTBV_SEdate_Cp";
            this.msk_dtpTBV_SEdate_Cp.Size = new System.Drawing.Size(69, 20);
            this.msk_dtpTBV_SEdate_Cp.TabIndex = 222;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Cornsilk;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Chocolate;
            this.label4.Location = new System.Drawing.Point(208, 26);
            this.label4.Name = "label4";
            this.label4.Padding = new System.Windows.Forms.Padding(3);
            this.label4.Size = new System.Drawing.Size(91, 34);
            this.label4.TabIndex = 140;
            this.label4.Text = "         First \r\n     Extension     ";
            // 
            // msk_dtpTV_SEdate_Cp
            // 
            this.msk_dtpTV_SEdate_Cp.Location = new System.Drawing.Point(302, 73);
            this.msk_dtpTV_SEdate_Cp.Name = "msk_dtpTV_SEdate_Cp";
            this.msk_dtpTV_SEdate_Cp.Size = new System.Drawing.Size(69, 20);
            this.msk_dtpTV_SEdate_Cp.TabIndex = 221;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Cornsilk;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Chocolate;
            this.label5.Location = new System.Drawing.Point(302, 26);
            this.label5.Name = "label5";
            this.label5.Padding = new System.Windows.Forms.Padding(3);
            this.label5.Size = new System.Drawing.Size(88, 34);
            this.label5.TabIndex = 141;
            this.label5.Text = "         Last \r\n     Extension    ";
            // 
            // msk_dtpTBV_FEdate_Cp
            // 
            this.msk_dtpTBV_FEdate_Cp.Location = new System.Drawing.Point(208, 105);
            this.msk_dtpTBV_FEdate_Cp.Name = "msk_dtpTBV_FEdate_Cp";
            this.msk_dtpTBV_FEdate_Cp.Size = new System.Drawing.Size(69, 20);
            this.msk_dtpTBV_FEdate_Cp.TabIndex = 220;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Cornsilk;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Chocolate;
            this.label6.Location = new System.Drawing.Point(395, 26);
            this.label6.Name = "label6";
            this.label6.Padding = new System.Windows.Forms.Padding(3);
            this.label6.Size = new System.Drawing.Size(54, 34);
            this.label6.TabIndex = 142;
            this.label6.Text = " Days to\r\n  Expire";
            // 
            // msk_dtpTV_FEdate_Cp
            // 
            this.msk_dtpTV_FEdate_Cp.Location = new System.Drawing.Point(208, 74);
            this.msk_dtpTV_FEdate_Cp.Name = "msk_dtpTV_FEdate_Cp";
            this.msk_dtpTV_FEdate_Cp.Size = new System.Drawing.Size(69, 20);
            this.msk_dtpTV_FEdate_Cp.TabIndex = 219;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(37, 77);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 13);
            this.label7.TabIndex = 143;
            this.label7.Text = "Tender Validity";
            // 
            // msk_dtpTBV_OrgDate_Cp
            // 
            this.msk_dtpTBV_OrgDate_Cp.Location = new System.Drawing.Point(120, 105);
            this.msk_dtpTBV_OrgDate_Cp.Name = "msk_dtpTBV_OrgDate_Cp";
            this.msk_dtpTBV_OrgDate_Cp.ReadOnly = true;
            this.msk_dtpTBV_OrgDate_Cp.Size = new System.Drawing.Size(82, 20);
            this.msk_dtpTBV_OrgDate_Cp.TabIndex = 218;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(9, 110);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(105, 13);
            this.label8.TabIndex = 144;
            this.label8.Text = "Tender Bond Validity";
            // 
            // msk_dtpTV_OrgDate_Cp
            // 
            this.msk_dtpTV_OrgDate_Cp.Location = new System.Drawing.Point(120, 74);
            this.msk_dtpTV_OrgDate_Cp.Name = "msk_dtpTV_OrgDate_Cp";
            this.msk_dtpTV_OrgDate_Cp.ReadOnly = true;
            this.msk_dtpTV_OrgDate_Cp.Size = new System.Drawing.Size(82, 20);
            this.msk_dtpTV_OrgDate_Cp.TabIndex = 217;
            // 
            // dtpTV_FEdate_Cp
            // 
            this.dtpTV_FEdate_Cp.Checked = false;
            this.dtpTV_FEdate_Cp.CustomFormat = "  ";
            this.dtpTV_FEdate_Cp.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTV_FEdate_Cp.Location = new System.Drawing.Point(208, 74);
            this.dtpTV_FEdate_Cp.Name = "dtpTV_FEdate_Cp";
            this.dtpTV_FEdate_Cp.ShowCheckBox = true;
            this.dtpTV_FEdate_Cp.Size = new System.Drawing.Size(90, 20);
            this.dtpTV_FEdate_Cp.TabIndex = 189;
            // 
            // dtpTV_SEdate_Cp
            // 
            this.dtpTV_SEdate_Cp.Checked = false;
            this.dtpTV_SEdate_Cp.CustomFormat = "  ";
            this.dtpTV_SEdate_Cp.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTV_SEdate_Cp.Location = new System.Drawing.Point(302, 73);
            this.dtpTV_SEdate_Cp.Name = "dtpTV_SEdate_Cp";
            this.dtpTV_SEdate_Cp.ShowCheckBox = true;
            this.dtpTV_SEdate_Cp.Size = new System.Drawing.Size(88, 20);
            this.dtpTV_SEdate_Cp.TabIndex = 190;
            // 
            // dtpTBV_FEdate_Cp
            // 
            this.dtpTBV_FEdate_Cp.Checked = false;
            this.dtpTBV_FEdate_Cp.CustomFormat = "  ";
            this.dtpTBV_FEdate_Cp.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTBV_FEdate_Cp.Location = new System.Drawing.Point(208, 105);
            this.dtpTBV_FEdate_Cp.Name = "dtpTBV_FEdate_Cp";
            this.dtpTBV_FEdate_Cp.ShowCheckBox = true;
            this.dtpTBV_FEdate_Cp.Size = new System.Drawing.Size(90, 20);
            this.dtpTBV_FEdate_Cp.TabIndex = 193;
            // 
            // dtpTBV_SEdate_Cp
            // 
            this.dtpTBV_SEdate_Cp.Checked = false;
            this.dtpTBV_SEdate_Cp.CustomFormat = "  ";
            this.dtpTBV_SEdate_Cp.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTBV_SEdate_Cp.Location = new System.Drawing.Point(303, 104);
            this.dtpTBV_SEdate_Cp.Name = "dtpTBV_SEdate_Cp";
            this.dtpTBV_SEdate_Cp.ShowCheckBox = true;
            this.dtpTBV_SEdate_Cp.Size = new System.Drawing.Size(87, 20);
            this.dtpTBV_SEdate_Cp.TabIndex = 194;
            // 
            // txtCp_TVDays
            // 
            this.txtCp_TVDays.Enabled = false;
            this.txtCp_TVDays.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCp_TVDays.Location = new System.Drawing.Point(395, 73);
            this.txtCp_TVDays.Name = "txtCp_TVDays";
            this.txtCp_TVDays.Size = new System.Drawing.Size(54, 20);
            this.txtCp_TVDays.TabIndex = 204;
            // 
            // txtCp_TBVDays
            // 
            this.txtCp_TBVDays.Enabled = false;
            this.txtCp_TBVDays.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCp_TBVDays.Location = new System.Drawing.Point(395, 104);
            this.txtCp_TBVDays.Name = "txtCp_TBVDays";
            this.txtCp_TBVDays.Size = new System.Drawing.Size(54, 20);
            this.txtCp_TBVDays.TabIndex = 205;
            // 
            // frmExtDatesInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cornsilk;
            this.ClientSize = new System.Drawing.Size(549, 182);
            this.Controls.Add(this.groupBox5);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "frmExtDatesInfo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Extend Tender Close Dates";
            this.Load += new System.EventHandler(this.frmExtDatesInfo_Load);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.MaskedTextBox msk_dtpTBV_SEdate_Cp;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.MaskedTextBox msk_dtpTV_SEdate_Cp;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.MaskedTextBox msk_dtpTBV_FEdate_Cp;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.MaskedTextBox msk_dtpTV_FEdate_Cp;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.MaskedTextBox msk_dtpTBV_OrgDate_Cp;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.MaskedTextBox msk_dtpTV_OrgDate_Cp;
        private System.Windows.Forms.DateTimePicker dtpTV_FEdate_Cp;
        private System.Windows.Forms.DateTimePicker dtpTV_SEdate_Cp;
        private System.Windows.Forms.DateTimePicker dtpTBV_FEdate_Cp;
        private System.Windows.Forms.DateTimePicker dtpTBV_SEdate_Cp;
        private System.Windows.Forms.TextBox txtCp_TVDays;
        private System.Windows.Forms.TextBox txtCp_TBVDays;
    }
}