﻿namespace MDI_ParenrForm.Projects
{
    partial class UserAuthentication
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.ashghal_UserName = new System.Windows.Forms.Label();
            this.ashghalUserName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.submit = new System.Windows.Forms.Button();
            this.password = new System.Windows.Forms.MaskedTextBox();
            this.close = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(62, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(250, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter Password To Authenticate";
            // 
            // ashghal_UserName
            // 
            this.ashghal_UserName.AutoSize = true;
            this.ashghal_UserName.Location = new System.Drawing.Point(57, 66);
            this.ashghal_UserName.Name = "ashghal_UserName";
            this.ashghal_UserName.Size = new System.Drawing.Size(98, 13);
            this.ashghal_UserName.TabIndex = 1;
            this.ashghal_UserName.Text = "Ashghal UserName";
            // 
            // ashghalUserName
            // 
            this.ashghalUserName.Enabled = false;
            this.ashghalUserName.Location = new System.Drawing.Point(157, 63);
            this.ashghalUserName.Name = "ashghalUserName";
            this.ashghalUserName.Size = new System.Drawing.Size(101, 20);
            this.ashghalUserName.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(103, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Password";
            // 
            // submit
            // 
            this.submit.Location = new System.Drawing.Point(106, 144);
            this.submit.Name = "submit";
            this.submit.Size = new System.Drawing.Size(75, 23);
            this.submit.TabIndex = 5;
            this.submit.Text = "Submit";
            this.submit.UseVisualStyleBackColor = true;
            this.submit.Click += new System.EventHandler(this.submit_Click);
            // 
            // password
            // 
            this.password.Location = new System.Drawing.Point(158, 103);
            this.password.Name = "password";
            this.password.PasswordChar = '*';
            this.password.Size = new System.Drawing.Size(100, 20);
            this.password.TabIndex = 6;
            // 
            // close
            // 
            this.close.Location = new System.Drawing.Point(205, 144);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(75, 23);
            this.close.TabIndex = 7;
            this.close.Text = "Close";
            this.close.UseVisualStyleBackColor = true;
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // UserAuthentication
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(399, 195);
            this.Controls.Add(this.close);
            this.Controls.Add(this.password);
            this.Controls.Add(this.submit);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ashghalUserName);
            this.Controls.Add(this.ashghal_UserName);
            this.Controls.Add(this.label1);
            this.Name = "UserAuthentication";
            this.Text = "EmailAddressAuthentication";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label ashghal_UserName;
        private System.Windows.Forms.TextBox ashghalUserName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button submit;
        private System.Windows.Forms.MaskedTextBox password;
        private System.Windows.Forms.Button close;
    }
}