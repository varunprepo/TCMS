﻿namespace MDI_ParenrForm.Projects
{
    partial class frmProjectEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.btnNonMohCancel = new System.Windows.Forms.Button();
            this.btnNonMohProceed = new System.Windows.Forms.Button();
            this.lblNonMohProjTitleEn = new System.Windows.Forms.Label();
            this.txtPrjnameEn = new System.Windows.Forms.TextBox();
            this.cmbTndrCommitte = new System.Windows.Forms.ComboBox();
            this.lblNonMohFiscalYr = new System.Windows.Forms.Label();
            this.cmbFiscalYear = new System.Windows.Forms.ComboBox();
            this.lblNonlMohTypeOfProj = new System.Windows.Forms.Label();
            this.lblNonMohTypeOfTender = new System.Windows.Forms.Label();
            this.cmbTndrType = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.cmbBudjetRefNo = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.txtProvision = new System.Windows.Forms.TextBox();
            this.lblBudget = new System.Windows.Forms.Label();
            this.txtBudgetAmnt = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.cmbMinistryCode = new System.Windows.Forms.ComboBox();
            this.txtPrjnameArb = new System.Windows.Forms.TextBox();
            this.lblNonMohProjTitleAr = new System.Windows.Forms.Label();
            this.lblNonMohTenderCommittee = new System.Windows.Forms.Label();
            this.txtPrjCode = new System.Windows.Forms.TextBox();
            this.lblNonMohProjCode = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbTypeOfContract = new System.Windows.Forms.ComboBox();
            this.txtTenderNo = new System.Windows.Forms.TextBox();
            this.txtMoazanah = new System.Windows.Forms.TextBox();
            this.lblNonMohAffairs = new System.Windows.Forms.Label();
            this.lblNonMohUserDept = new System.Windows.Forms.Label();
            this.cmbAffairs = new System.Windows.Forms.ComboBox();
            this.cmbDept = new System.Windows.Forms.ComboBox();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.AutoSize = true;
            this.groupBox1.BackColor = System.Drawing.Color.DarkKhaki;
            this.groupBox1.Controls.Add(this.tableLayoutPanel2);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(-2, 0);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(1);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(1);
            this.groupBox1.Size = new System.Drawing.Size(812, 559);
            this.groupBox1.TabIndex = 44;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 53.86024F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 46.13977F));
            this.tableLayoutPanel2.Controls.Add(this.btnNonMohCancel, 1, 18);
            this.tableLayoutPanel2.Controls.Add(this.btnNonMohProceed, 0, 18);
            this.tableLayoutPanel2.Controls.Add(this.lblNonMohProjTitleEn, 0, 7);
            this.tableLayoutPanel2.Controls.Add(this.txtPrjnameEn, 0, 8);
            this.tableLayoutPanel2.Controls.Add(this.cmbTndrCommitte, 0, 10);
            this.tableLayoutPanel2.Controls.Add(this.lblNonMohFiscalYr, 1, 9);
            this.tableLayoutPanel2.Controls.Add(this.cmbFiscalYear, 1, 10);
            this.tableLayoutPanel2.Controls.Add(this.lblNonlMohTypeOfProj, 0, 11);
            this.tableLayoutPanel2.Controls.Add(this.lblNonMohTypeOfTender, 1, 11);
            this.tableLayoutPanel2.Controls.Add(this.cmbTndrType, 1, 12);
            this.tableLayoutPanel2.Controls.Add(this.label24, 1, 13);
            this.tableLayoutPanel2.Controls.Add(this.cmbBudjetRefNo, 1, 14);
            this.tableLayoutPanel2.Controls.Add(this.label25, 0, 15);
            this.tableLayoutPanel2.Controls.Add(this.txtProvision, 0, 16);
            this.tableLayoutPanel2.Controls.Add(this.lblBudget, 1, 15);
            this.tableLayoutPanel2.Controls.Add(this.txtBudgetAmnt, 1, 16);
            this.tableLayoutPanel2.Controls.Add(this.label12, 0, 13);
            this.tableLayoutPanel2.Controls.Add(this.cmbMinistryCode, 0, 14);
            this.tableLayoutPanel2.Controls.Add(this.txtPrjnameArb, 1, 8);
            this.tableLayoutPanel2.Controls.Add(this.lblNonMohProjTitleAr, 1, 7);
            this.tableLayoutPanel2.Controls.Add(this.lblNonMohTenderCommittee, 0, 9);
            this.tableLayoutPanel2.Controls.Add(this.txtPrjCode, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.lblNonMohProjCode, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.label2, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.label1, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.cmbTypeOfContract, 0, 12);
            this.tableLayoutPanel2.Controls.Add(this.txtTenderNo, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.txtMoazanah, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.lblNonMohAffairs, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.lblNonMohUserDept, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.cmbAffairs, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.cmbDept, 1, 6);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(34, 18);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 19;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 17F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 19F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 98F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 17F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 17F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 77F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(751, 516);
            this.tableLayoutPanel2.TabIndex = 64;
            // 
            // btnNonMohCancel
            // 
            this.btnNonMohCancel.BackColor = System.Drawing.Color.Maroon;
            this.btnNonMohCancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNonMohCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNonMohCancel.ForeColor = System.Drawing.Color.White;
            this.btnNonMohCancel.Location = new System.Drawing.Point(407, 486);
            this.btnNonMohCancel.Name = "btnNonMohCancel";
            this.btnNonMohCancel.Size = new System.Drawing.Size(60, 26);
            this.btnNonMohCancel.TabIndex = 16;
            this.btnNonMohCancel.Text = "Cancel";
            this.btnNonMohCancel.UseVisualStyleBackColor = false;
            this.btnNonMohCancel.Visible = false;
            // 
            // btnNonMohProceed
            // 
            this.btnNonMohProceed.BackColor = System.Drawing.Color.Maroon;
            this.btnNonMohProceed.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNonMohProceed.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNonMohProceed.ForeColor = System.Drawing.Color.White;
            this.btnNonMohProceed.Location = new System.Drawing.Point(3, 486);
            this.btnNonMohProceed.Name = "btnNonMohProceed";
            this.btnNonMohProceed.Size = new System.Drawing.Size(60, 26);
            this.btnNonMohProceed.TabIndex = 16;
            this.btnNonMohProceed.Text = "Update";
            this.btnNonMohProceed.UseVisualStyleBackColor = false;
            this.btnNonMohProceed.Click += new System.EventHandler(this.btnNonMohProceed_Click);
            // 
            // lblNonMohProjTitleEn
            // 
            this.lblNonMohProjTitleEn.AutoSize = true;
            this.lblNonMohProjTitleEn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblNonMohProjTitleEn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNonMohProjTitleEn.Location = new System.Drawing.Point(3, 148);
            this.lblNonMohProjTitleEn.Name = "lblNonMohProjTitleEn";
            this.lblNonMohProjTitleEn.Size = new System.Drawing.Size(152, 15);
            this.lblNonMohProjTitleEn.TabIndex = 11;
            this.lblNonMohProjTitleEn.Text = "Project Title In English\r\n";
            // 
            // txtPrjnameEn
            // 
            this.txtPrjnameEn.Location = new System.Drawing.Point(3, 169);
            this.txtPrjnameEn.Multiline = true;
            this.txtPrjnameEn.Name = "txtPrjnameEn";
            this.txtPrjnameEn.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtPrjnameEn.Size = new System.Drawing.Size(319, 92);
            this.txtPrjnameEn.TabIndex = 6;
            // 
            // cmbTndrCommitte
            // 
            this.cmbTndrCommitte.FormattingEnabled = true;
            this.cmbTndrCommitte.Location = new System.Drawing.Point(3, 285);
            this.cmbTndrCommitte.Name = "cmbTndrCommitte";
            this.cmbTndrCommitte.Size = new System.Drawing.Size(319, 23);
            this.cmbTndrCommitte.TabIndex = 8;
            this.cmbTndrCommitte.SelectionChangeCommitted += new System.EventHandler(this.cmbTndrCommitte_SelectionChangeCommitted);
            // 
            // lblNonMohFiscalYr
            // 
            this.lblNonMohFiscalYr.AutoSize = true;
            this.lblNonMohFiscalYr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblNonMohFiscalYr.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNonMohFiscalYr.Location = new System.Drawing.Point(407, 264);
            this.lblNonMohFiscalYr.Name = "lblNonMohFiscalYr";
            this.lblNonMohFiscalYr.Size = new System.Drawing.Size(78, 15);
            this.lblNonMohFiscalYr.TabIndex = 9;
            this.lblNonMohFiscalYr.Text = "Fiscal Year";
            // 
            // cmbFiscalYear
            // 
            this.cmbFiscalYear.FormattingEnabled = true;
            this.cmbFiscalYear.Location = new System.Drawing.Point(407, 285);
            this.cmbFiscalYear.Name = "cmbFiscalYear";
            this.cmbFiscalYear.Size = new System.Drawing.Size(319, 23);
            this.cmbFiscalYear.TabIndex = 9;
            this.cmbFiscalYear.SelectionChangeCommitted += new System.EventHandler(this.cmbFiscalYear_SelectionChangeCommitted);
            // 
            // lblNonlMohTypeOfProj
            // 
            this.lblNonlMohTypeOfProj.AutoSize = true;
            this.lblNonlMohTypeOfProj.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblNonlMohTypeOfProj.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNonlMohTypeOfProj.Location = new System.Drawing.Point(3, 313);
            this.lblNonlMohTypeOfProj.Name = "lblNonlMohTypeOfProj";
            this.lblNonlMohTypeOfProj.Size = new System.Drawing.Size(110, 15);
            this.lblNonlMohTypeOfProj.TabIndex = 32;
            this.lblNonlMohTypeOfProj.Text = "Type of Contract";
            // 
            // lblNonMohTypeOfTender
            // 
            this.lblNonMohTypeOfTender.AutoSize = true;
            this.lblNonMohTypeOfTender.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblNonMohTypeOfTender.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNonMohTypeOfTender.Location = new System.Drawing.Point(407, 313);
            this.lblNonMohTypeOfTender.Name = "lblNonMohTypeOfTender";
            this.lblNonMohTypeOfTender.Size = new System.Drawing.Size(102, 15);
            this.lblNonMohTypeOfTender.TabIndex = 19;
            this.lblNonMohTypeOfTender.Text = "Type of Tender";
            // 
            // cmbTndrType
            // 
            this.cmbTndrType.FormattingEnabled = true;
            this.cmbTndrType.Location = new System.Drawing.Point(407, 333);
            this.cmbTndrType.Name = "cmbTndrType";
            this.cmbTndrType.Size = new System.Drawing.Size(319, 23);
            this.cmbTndrType.TabIndex = 11;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.DarkKhaki;
            this.label24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label24.Location = new System.Drawing.Point(407, 362);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(148, 15);
            this.label24.TabIndex = 54;
            this.label24.Text = "Budget Reference No ";
            // 
            // cmbBudjetRefNo
            // 
            this.cmbBudjetRefNo.FormattingEnabled = true;
            this.cmbBudjetRefNo.Location = new System.Drawing.Point(407, 381);
            this.cmbBudjetRefNo.Name = "cmbBudjetRefNo";
            this.cmbBudjetRefNo.Size = new System.Drawing.Size(319, 23);
            this.cmbBudjetRefNo.TabIndex = 13;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.DarkKhaki;
            this.label25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label25.Location = new System.Drawing.Point(3, 408);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(88, 15);
            this.label25.TabIndex = 58;
            this.label25.Text = "Provision No";
            // 
            // txtProvision
            // 
            this.txtProvision.Location = new System.Drawing.Point(3, 428);
            this.txtProvision.Name = "txtProvision";
            this.txtProvision.Size = new System.Drawing.Size(319, 21);
            this.txtProvision.TabIndex = 14;
            // 
            // lblBudget
            // 
            this.lblBudget.AutoSize = true;
            this.lblBudget.BackColor = System.Drawing.Color.DarkKhaki;
            this.lblBudget.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblBudget.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBudget.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblBudget.Location = new System.Drawing.Point(407, 408);
            this.lblBudget.Name = "lblBudget";
            this.lblBudget.Size = new System.Drawing.Size(108, 15);
            this.lblBudget.TabIndex = 60;
            this.lblBudget.Text = "Budget Amount ";
            // 
            // txtBudgetAmnt
            // 
            this.txtBudgetAmnt.Location = new System.Drawing.Point(407, 428);
            this.txtBudgetAmnt.Name = "txtBudgetAmnt";
            this.txtBudgetAmnt.Size = new System.Drawing.Size(319, 21);
            this.txtBudgetAmnt.TabIndex = 15;
            this.txtBudgetAmnt.Text = "0";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.DarkKhaki;
            this.label12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label12.Location = new System.Drawing.Point(3, 362);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(94, 15);
            this.label12.TabIndex = 55;
            this.label12.Text = "Ministry Code";
            // 
            // cmbMinistryCode
            // 
            this.cmbMinistryCode.FormattingEnabled = true;
            this.cmbMinistryCode.Location = new System.Drawing.Point(3, 381);
            this.cmbMinistryCode.Name = "cmbMinistryCode";
            this.cmbMinistryCode.Size = new System.Drawing.Size(319, 23);
            this.cmbMinistryCode.TabIndex = 12;
            // 
            // txtPrjnameArb
            // 
            this.txtPrjnameArb.Location = new System.Drawing.Point(407, 169);
            this.txtPrjnameArb.Multiline = true;
            this.txtPrjnameArb.Name = "txtPrjnameArb";
            this.txtPrjnameArb.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtPrjnameArb.Size = new System.Drawing.Size(319, 92);
            this.txtPrjnameArb.TabIndex = 7;
            // 
            // lblNonMohProjTitleAr
            // 
            this.lblNonMohProjTitleAr.AutoSize = true;
            this.lblNonMohProjTitleAr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblNonMohProjTitleAr.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNonMohProjTitleAr.Location = new System.Drawing.Point(407, 148);
            this.lblNonMohProjTitleAr.Name = "lblNonMohProjTitleAr";
            this.lblNonMohProjTitleAr.Size = new System.Drawing.Size(144, 15);
            this.lblNonMohProjTitleAr.TabIndex = 43;
            this.lblNonMohProjTitleAr.Text = "Project Title In Arabic\r\n";
            // 
            // lblNonMohTenderCommittee
            // 
            this.lblNonMohTenderCommittee.AutoSize = true;
            this.lblNonMohTenderCommittee.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblNonMohTenderCommittee.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNonMohTenderCommittee.Location = new System.Drawing.Point(3, 264);
            this.lblNonMohTenderCommittee.Name = "lblNonMohTenderCommittee";
            this.lblNonMohTenderCommittee.Size = new System.Drawing.Size(125, 15);
            this.lblNonMohTenderCommittee.TabIndex = 25;
            this.lblNonMohTenderCommittee.Text = "Tender Committee";
            // 
            // txtPrjCode
            // 
            this.txtPrjCode.Location = new System.Drawing.Point(407, 69);
            this.txtPrjCode.Name = "txtPrjCode";
            this.txtPrjCode.Size = new System.Drawing.Size(319, 21);
            this.txtPrjCode.TabIndex = 3;
            this.txtPrjCode.Leave += new System.EventHandler(this.txtPrjCode_Leave);
            // 
            // lblNonMohProjCode
            // 
            this.lblNonMohProjCode.AutoSize = true;
            this.lblNonMohProjCode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblNonMohProjCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNonMohProjCode.Location = new System.Drawing.Point(407, 49);
            this.lblNonMohProjCode.Name = "lblNonMohProjCode";
            this.lblNonMohProjCode.Size = new System.Drawing.Size(89, 15);
            this.lblNonMohProjCode.TabIndex = 2;
            this.lblNonMohProjCode.Text = "Project Code";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(141, 15);
            this.label2.TabIndex = 62;
            this.label2.Text = "Moazanah Project ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 15);
            this.label1.TabIndex = 47;
            this.label1.Text = "TenderNo";
            // 
            // cmbTypeOfContract
            // 
            this.cmbTypeOfContract.FormattingEnabled = true;
            this.cmbTypeOfContract.Location = new System.Drawing.Point(3, 333);
            this.cmbTypeOfContract.Name = "cmbTypeOfContract";
            this.cmbTypeOfContract.Size = new System.Drawing.Size(319, 23);
            this.cmbTypeOfContract.TabIndex = 10;
            // 
            // txtTenderNo
            // 
            this.txtTenderNo.Location = new System.Drawing.Point(3, 19);
            this.txtTenderNo.Name = "txtTenderNo";
            this.txtTenderNo.Size = new System.Drawing.Size(319, 21);
            this.txtTenderNo.TabIndex = 1;            
            // 
            // txtMoazanah
            // 
            this.txtMoazanah.Location = new System.Drawing.Point(3, 69);
            this.txtMoazanah.Name = "txtMoazanah";
            this.txtMoazanah.Size = new System.Drawing.Size(319, 21);
            this.txtMoazanah.TabIndex = 2;
            this.txtMoazanah.Leave += new System.EventHandler(this.txtMoazanah_Leave);
            // 
            // lblNonMohAffairs
            // 
            this.lblNonMohAffairs.AutoSize = true;
            this.lblNonMohAffairs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblNonMohAffairs.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNonMohAffairs.Location = new System.Drawing.Point(3, 97);
            this.lblNonMohAffairs.Name = "lblNonMohAffairs";
            this.lblNonMohAffairs.Size = new System.Drawing.Size(47, 15);
            this.lblNonMohAffairs.TabIndex = 21;
            this.lblNonMohAffairs.Text = "Affairs";
            // 
            // lblNonMohUserDept
            // 
            this.lblNonMohUserDept.AutoSize = true;
            this.lblNonMohUserDept.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblNonMohUserDept.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNonMohUserDept.Location = new System.Drawing.Point(407, 97);
            this.lblNonMohUserDept.Name = "lblNonMohUserDept";
            this.lblNonMohUserDept.Size = new System.Drawing.Size(116, 15);
            this.lblNonMohUserDept.TabIndex = 23;
            this.lblNonMohUserDept.Text = "User Department";
            // 
            // cmbAffairs
            // 
            this.cmbAffairs.FormattingEnabled = true;
            this.cmbAffairs.Location = new System.Drawing.Point(3, 119);
            this.cmbAffairs.Name = "cmbAffairs";
            this.cmbAffairs.Size = new System.Drawing.Size(319, 23);
            this.cmbAffairs.TabIndex = 5;
            this.cmbAffairs.SelectionChangeCommitted += new System.EventHandler(this.cmbAffairs_SelectionChangeCommitted);
            // 
            // cmbDept
            // 
            this.cmbDept.FormattingEnabled = true;
            this.cmbDept.Location = new System.Drawing.Point(407, 119);
            this.cmbDept.Name = "cmbDept";
            this.cmbDept.Size = new System.Drawing.Size(319, 23);
            this.cmbDept.TabIndex = 4;
            // 
            // frmProjectEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FloralWhite;
            this.ClientSize = new System.Drawing.Size(810, 557);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmProjectEdit";
            this.Text = "Project Details";
            this.Load += new System.EventHandler(this.frmProjectEdit_Load);
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblNonMohProjCode;
        private System.Windows.Forms.TextBox txtPrjnameArb;
        private System.Windows.Forms.TextBox txtPrjCode;
        private System.Windows.Forms.Label lblNonMohProjTitleAr;
        private System.Windows.Forms.Label lblNonMohFiscalYr;
        private System.Windows.Forms.Label lblNonMohProjTitleEn;
        private System.Windows.Forms.TextBox txtPrjnameEn;
        private System.Windows.Forms.Label lblNonMohTypeOfTender;
        private System.Windows.Forms.ComboBox cmbTndrType;
        private System.Windows.Forms.ComboBox cmbTndrCommitte;
        private System.Windows.Forms.Label lblNonMohAffairs;
        private System.Windows.Forms.ComboBox cmbDept;
        private System.Windows.Forms.Label lblNonMohUserDept;
        private System.Windows.Forms.ComboBox cmbAffairs;
        private System.Windows.Forms.Label lblNonMohTenderCommittee;
        private System.Windows.Forms.ComboBox cmbFiscalYear;
        private System.Windows.Forms.Button btnNonMohCancel;
        private System.Windows.Forms.ComboBox cmbTypeOfContract;
        private System.Windows.Forms.Button btnNonMohProceed;
        private System.Windows.Forms.Label lblNonlMohTypeOfProj;
        private System.Windows.Forms.TextBox txtTenderNo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbMinistryCode;
        private System.Windows.Forms.ComboBox cmbBudjetRefNo;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtProvision;
        private System.Windows.Forms.Label lblBudget;
        private System.Windows.Forms.TextBox txtBudgetAmnt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMoazanah;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
    }
}