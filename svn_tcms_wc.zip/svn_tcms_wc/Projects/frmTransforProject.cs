﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq; 
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Transactions;
using MDI_ParenrForm;
using TenderTrackingSystem;
using System.Net.Mail;
using System.DirectoryServices;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
using System.Text;


namespace MDI_ParenrForm.Projects
{
    public partial class frmTransforProject : Form
    {         
        private string strCon = ConfigurationManager.AppSettings["TCMSConnString"].ToString();        
        protected SqlConnection sqlConn = null;
        protected SqlCommand sqlCom = null;
        IList<string> userRightsColl = new List<string>();
        int _prjIDExist = 0; string _committee = string.Empty;
        string _tndrStatus = string.Empty;
        string _tndrType = string.Empty; string _prjCodeExisted = string.Empty;
        string _tenderNo = string.Empty;
        string _userName = string.Empty;
        string _fiscalYear = string.Empty;
        string _projTitle = string.Empty;
        int _newPrjID = 0;

        char chProjTransfered = ' ';
        public char ProjTransfered
        {
            get { return chProjTransfered; }
            set { chProjTransfered = value; }
        }

        char chProjReTendered = ' ';
        public char ProjReTender
        {
            get { return chProjReTendered; }
            set { chProjReTendered = value; }
        }
        
        public frmTransforProject(int prjID, string tndrType, string cmtName, IList<string> userRightsCollContacts, string tenderStatus, string strPrjCode, string strTenderNo, string userName, string fiscalYear, string strProjTitle)
        {
            InitializeComponent();
            userRightsColl = userRightsCollContacts;
            _prjIDExist = prjID;
            _committee = cmtName;
            _tndrType = tndrType;
            _tndrStatus = tenderStatus;
            _prjCodeExisted = strPrjCode;
            _tenderNo = strTenderNo;
            _newPrjID = GetMaxID("SELECT MAX(proj_id) from Projects");
            _userName = userName;
            _fiscalYear = fiscalYear;
            _projTitle = strProjTitle;
        }

        public int GetNewProjId()
        {
           return _newPrjID;         
        }
        int _maxPrjiD = 0;
        private int GetMaxID(string sqlQuery)
        {
            SqlConnection sqlCon = new SqlConnection(strCon);        
            sqlCon.Open();
            try
            {                 
                SqlCommand sqlCommand = new SqlCommand(sqlQuery, sqlCon);
                _maxPrjiD = Convert.ToInt16(sqlCommand.ExecuteScalar());
                _maxPrjiD = _maxPrjiD + 1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlCon.Close();
            }
            return _maxPrjiD;
        }

        string newTndrNo = null;         
        DataSet dsStg2 = new DataSet();
        DataSet dsStg2Bidders = new DataSet();
        DataSet dsStg3 = new DataSet();

        private void transforTenderDates_Stage2_TEMP()
        {
            string sqlQuery = "SELECT date_id, proj_id, stage_id, ts_receive_on, ts_issue_handling, ts_return_to_dept, ts_receive_from_dept, ts_pr_advertise, ts_tender_invitation, ts_closing_s1," +
            "ts_closing_s2, ts_modified_closing, ts_tender_issue, ts_receipt_no,co_id,employee_id,remarks,org_tender_validity,org_tenderbond_validity,org_tender_to_expire,org_tenderbond_to_expire," +
            "tender_validity_ext1,tender_validity_ext2,tenderbond_validity_ext1,tenderbond_validity_ext2,Tender_Issued,SN,create_date,update_date,create_user,update_user,Alert,Company_EmailID FROM TenderDatesInfo WHERE (proj_id = " + 1304 + ") AND (stage_id = 2) ORDER BY date_id asc";

            SqlConnection sqlConn = new SqlConnection(strCon);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataAdapter daStage2 = new SqlDataAdapter(sqlCom);
            daStage2.Fill(dsStg2);
            sqlConn.Close();
            if (dsStg2.Tables[0].Rows.Count > 0)
            {
                InsertTenderStageInfo_Temp(dsStg2);
            }
        }
        bool isException = false;
        private void button1_Click(object sender, EventArgs e)
        {
            CommonClass comCls = new CommonClass(_userName);
            string[] projData = new string[13];          
            projData[0] = _prjCodeExisted;
            projData[1] = _projTitle;
            projData[2] = null;
            projData[3] = _committee;
            projData[4] = _fiscalYear;
            projData[5] = null;
            projData[6] = null;
            projData[7] = _userName;
            projData[8] = _prjIDExist.ToString();
            projData[9] = _tndrType;
            projData[10] = _tenderNo;   //Tender Number
            projData[11] = _tndrStatus; //TndrStatus            
            projData[12] = _newPrjID.ToString();

            UserAuthentication emailAddAuth = new UserAuthentication(projData, cmbCommittee.Text, userRightsColl, grpBoxTenderType.Visible, rdbLimited.Checked, true);
            emailAddAuth.StartPosition = FormStartPosition.CenterParent;
            emailAddAuth.ShowDialog();
            //string tenderNum = emailAddAuth.TenderNum;
            //emailAddAuth.Close();
            //if(tenderNum!=null)
            //{
            //    btnAssignTender.Visible = false;
            //    lblTenderNo.Visible = true;
            //    txtTenderNo.Text = tenderNum;
            //}            
            
        }

        private void SendCompletedCallback(SmtpClient smtpclient, System.Net.Mail.MailMessage mail) //private static void SendCompletedCallback(object sender, AsyncCompletedEventArgs e
        {
            //try
            //{
                smtpclient.Send(mail);
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show("Exception occurred while sending the email notification to Engineering Services Department, Please inform network administrator about send email functionality not working", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            //}
            //finally
            //{
            //    mail.Dispose();
            //    mail = null;
            //    // smtpclient = null;
            //}
        }

         

        IList<string> userListColl = new List<string>();
        StringBuilder emailIds = new StringBuilder();
        private void UserList_ForAlert(int categryID, string committeeName)
        {            
            try
            {                 
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        string sqlQuery = "SELECT DISTINCT EmailAlertRecipients.user_id, USERS.email_address, USERS.user_name, EmailAlertCategory.AlertCategory, EmailAlertRecipients.alert_cat_id, " +
                         " Committee.committee_short_name FROM EmailAlertCategory INNER JOIN EmailAlertRecipients ON EmailAlertCategory.alert_cat_id = EmailAlertRecipients.alert_cat_id INNER JOIN " +
                         " USERS ON EmailAlertRecipients.user_id = USERS.user_id INNER JOIN Committee ON EmailAlertRecipients.committee_id = Committee.committee_id " +
                         " WHERE (EmailAlertRecipients.alert_cat_id = " + categryID + ") AND (USERS.email_address <> N'') AND (Committee.committee_short_name ='" + committeeName + "')";
                         
                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                emailIds.Append(dr[1].ToString()+";");
                                //if (!userListColl.Contains(strData))
                                //    userListColl.Add(strData);
                            }
                            dr.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE DATES records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                isException = true;
            }
        }
        public Boolean GetUserInformation4rmActiveDirectory(string userId, string Domain, ref string DisplayName, ref string Email)
        {
            Boolean chkUserExist = false;
            try
            {
                string filter = string.Format("(&(ObjectClass={0})(sAMAccountName={1}))", "person", userId);

                DirectoryEntry activeDirectoryaddress = new DirectoryEntry("LDAP://" + Domain, null, null, AuthenticationTypes.Secure);
                DirectorySearcher searcher = new DirectorySearcher(activeDirectoryaddress);
                searcher.SearchScope = SearchScope.Subtree;

                searcher.Filter = filter;
                SearchResult result = searcher.FindOne();
                DirectoryEntry directoryEntry = result.GetDirectoryEntry();

                DisplayName = directoryEntry.Properties["displayName"][0].ToString();
                Email = directoryEntry.Properties["mail"][0].ToString();                 

                if (Email != null)
                {
                    chkUserExist = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Sorry unable to get your mail id from outlook", "ASHGHAL - EBSD");
            }

            return chkUserExist;
        }


        private void insertStatementParameters(SqlCommand cmd, DataTable dtTenderDatesInfoData, int loopCtr, int _dateId, char stageId)
        {
            if (stageId=='1')
                cmd.Parameters.AddWithValue("@stageId", 1);
            else if (stageId == '2')
                cmd.Parameters.AddWithValue("@stageId", 2);
            else if (stageId == '3')
                cmd.Parameters.AddWithValue("@stageId", 3);

            cmd.Parameters.AddWithValue("@projId", _newPrjID);
            cmd.Parameters.AddWithValue("@dateId", _dateId);

            if (dtTenderDatesInfoData.Rows[loopCtr][1] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ptd_receive_on", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][1]));
            else
                cmd.Parameters.AddWithValue("@ptd_receive_on", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][2] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ptd_purpose", dtTenderDatesInfoData.Rows[loopCtr][2].ToString());
            else
                cmd.Parameters.AddWithValue("@ptd_purpose", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][3] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ptd_assign_qs", dtTenderDatesInfoData.Rows[loopCtr][3].ToString());
            else
                cmd.Parameters.AddWithValue("@ptd_assign_qs", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][4] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ptd_sent_for_rev", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][4].ToString()));
            else
                cmd.Parameters.AddWithValue("@ptd_sent_for_rev", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][5] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ptd_qs_working_status", dtTenderDatesInfoData.Rows[loopCtr][5].ToString());
            else
                cmd.Parameters.AddWithValue("@ptd_qs_working_status", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][6] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ptd_tendec_doc_cur_status", dtTenderDatesInfoData.Rows[loopCtr][6].ToString());
            else
                cmd.Parameters.AddWithValue("@ptd_tendec_doc_cur_status", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][7] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ptd_forwarded_to_dep", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][7]));
            else
                cmd.Parameters.AddWithValue("@ptd_forwarded_to_dep", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][8] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ts_receive_on", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][8]));
            else
                cmd.Parameters.AddWithValue("@ts_receive_on", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][9] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ts_issue_handling", dtTenderDatesInfoData.Rows[loopCtr][9].ToString());
            else
                cmd.Parameters.AddWithValue("@ts_issue_handling", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][10] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ts_return_to_dept", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][10]));
            else
                cmd.Parameters.AddWithValue("@ts_return_to_dept", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][11] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ts_receive_from_dept", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][11]));
            else
                cmd.Parameters.AddWithValue("@ts_receive_from_dept", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][12] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ts_pr_advertise", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][12]));
            else
                cmd.Parameters.AddWithValue("@ts_pr_advertise", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][13] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ts_tender_invitation", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][13]));
            else
                cmd.Parameters.AddWithValue("@ts_tender_invitation", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][14] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ts_closing_s1", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][14]));
            else
                cmd.Parameters.AddWithValue("@ts_closing_s1", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][15] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ts_closing_s2", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][15]));
            else
                cmd.Parameters.AddWithValue("@ts_closing_s2", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][16] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ts_modified_closing", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][16]));
            else
                cmd.Parameters.AddWithValue("@ts_modified_closing", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][17] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ts_tender_issue", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][17]));
            else
                cmd.Parameters.AddWithValue("@ts_tender_issue", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][18] != DBNull.Value)
            {
                if (dtTenderDatesInfoData.Rows[loopCtr][18].ToString() != "")
                    cmd.Parameters.AddWithValue("@ts_receipt_no", dtTenderDatesInfoData.Rows[loopCtr][18].ToString());
            }
            else
                cmd.Parameters.AddWithValue("@ts_receipt_no", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][19] != DBNull.Value)
                cmd.Parameters.AddWithValue("@eval_tender_opening", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][19]));
            else
                cmd.Parameters.AddWithValue("@eval_tender_opening", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][20] != DBNull.Value)
                cmd.Parameters.AddWithValue("@eval_doc_receive_from_cd", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][20]));
            else
                cmd.Parameters.AddWithValue("@eval_doc_receive_from_cd", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][21] != DBNull.Value)
                cmd.Parameters.AddWithValue("@eval_tech_sent1", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][21]));
            else
                cmd.Parameters.AddWithValue("@eval_tech_sent1", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][22] != DBNull.Value)
                cmd.Parameters.AddWithValue("@eval_tech_receive1", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][22]));
            else
                cmd.Parameters.AddWithValue("@eval_tech_receive1", DBNull.Value);
        
                if (dtTenderDatesInfoData.Rows[loopCtr][23] != DBNull.Value)
                    cmd.Parameters.AddWithValue("@org_tender_validity", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][23]));
                else
                    cmd.Parameters.AddWithValue("@org_tender_validity", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][24] != DBNull.Value)
                    cmd.Parameters.AddWithValue("@org_tenderbond_validity", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][24]));
                else
                    cmd.Parameters.AddWithValue("@org_tenderbond_validity", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][25] != DBNull.Value)
                {
                    if (dtTenderDatesInfoData.Rows[loopCtr][25].ToString() != "")
                        cmd.Parameters.AddWithValue("@org_tender_to_expire", Convert.ToInt16(dtTenderDatesInfoData.Rows[loopCtr][25]));
                    else
                        cmd.Parameters.AddWithValue("@org_tender_to_expire", DBNull.Value);
                }
                else
                    cmd.Parameters.AddWithValue("@org_tender_to_expire", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][26] != DBNull.Value)
                {
                    if (dtTenderDatesInfoData.Rows[loopCtr][26].ToString() != "")
                        cmd.Parameters.AddWithValue("@org_tenderbond_to_expire", Convert.ToInt16(dtTenderDatesInfoData.Rows[loopCtr][26]));
                    else
                        cmd.Parameters.AddWithValue("@org_tenderbond_to_expire", DBNull.Value);
                }
                else
                    cmd.Parameters.AddWithValue("@org_tenderbond_to_expire", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][27] != DBNull.Value)
                    cmd.Parameters.AddWithValue("@tender_validity_ext1", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][27]));
                else
                    cmd.Parameters.AddWithValue("@tender_validity_ext1", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][28] != DBNull.Value)
                    cmd.Parameters.AddWithValue("@tender_validity_ext2", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][28]));
                else
                    cmd.Parameters.AddWithValue("@tender_validity_ext2", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][29] != DBNull.Value)
                    cmd.Parameters.AddWithValue("@tenderbond_validity_ext1", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][29]));
                else
                    cmd.Parameters.AddWithValue("@tenderbond_validity_ext1", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][30] != DBNull.Value)
                    cmd.Parameters.AddWithValue("@tenderbond_validity_ext2", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][30]));
                else
                    cmd.Parameters.AddWithValue("@tenderbond_validity_ext2", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][31] != DBNull.Value)
                {
                    if (dtTenderDatesInfoData.Rows[loopCtr][31].ToString() != "")
                        cmd.Parameters.AddWithValue("@eval_no_of_meetings", Convert.ToInt16(dtTenderDatesInfoData.Rows[loopCtr][31]));
                    else
                        cmd.Parameters.AddWithValue("@eval_no_of_meetings", DBNull.Value);
                }
                else
                    cmd.Parameters.AddWithValue("@eval_no_of_meetings", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][32] != DBNull.Value)
                {
                    if (dtTenderDatesInfoData.Rows[loopCtr][32].ToString() != "")
                        cmd.Parameters.AddWithValue("@remarks", dtTenderDatesInfoData.Rows[loopCtr][32].ToString());
                    else
                        cmd.Parameters.AddWithValue("@remarks", DBNull.Value);
                }
                else
                    cmd.Parameters.AddWithValue("@remarks", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][33] != DBNull.Value)
                {
                    if (dtTenderDatesInfoData.Rows[loopCtr][33].ToString() != "")
                        cmd.Parameters.AddWithValue("@staff_In_Charge", dtTenderDatesInfoData.Rows[loopCtr][33].ToString());
                    else
                        cmd.Parameters.AddWithValue("@staff_In_Charge", DBNull.Value);
                }
                else
                    cmd.Parameters.AddWithValue("@staff_In_Charge", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][34] != DBNull.Value)
                    cmd.Parameters.AddWithValue("@fromDate", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][34]));
                else
                    cmd.Parameters.AddWithValue("@fromDate", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][35] != DBNull.Value)
                    if (dtTenderDatesInfoData.Rows[loopCtr][35].ToString() != "")
                        cmd.Parameters.AddWithValue("@toDate", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][35]));
                    else
                        cmd.Parameters.AddWithValue("@toDate", DBNull.Value);
                else
                    cmd.Parameters.AddWithValue("@toDate", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][36] != DBNull.Value)
                {
                    if (dtTenderDatesInfoData.Rows[loopCtr][36].ToString() != "")
                        cmd.Parameters.AddWithValue("@employee_id", Convert.ToInt32(dtTenderDatesInfoData.Rows[loopCtr][36]));
                    else
                        cmd.Parameters.AddWithValue("@employee_id", DBNull.Value);
                }
                else
                    cmd.Parameters.AddWithValue("@employee_id", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][37] != DBNull.Value)
                {
                    if (dtTenderDatesInfoData.Rows[loopCtr][37].ToString() != "")
                        cmd.Parameters.AddWithValue("@co_id", Convert.ToInt32(dtTenderDatesInfoData.Rows[loopCtr][37]));
                    else
                        cmd.Parameters.AddWithValue("@co_id", DBNull.Value);
                }
                else
                    cmd.Parameters.AddWithValue("@co_id", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][38] != DBNull.Value)
                    cmd.Parameters.AddWithValue("@create_date", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][38]));
                else
                    cmd.Parameters.AddWithValue("@create_date", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][39] != DBNull.Value)
                    cmd.Parameters.AddWithValue("@update_date", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][39]));
                else
                    cmd.Parameters.AddWithValue("@update_date", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][40] != DBNull.Value)
                {
                    if (dtTenderDatesInfoData.Rows[loopCtr][40].ToString() != "")
                        cmd.Parameters.AddWithValue("@create_user", dtTenderDatesInfoData.Rows[loopCtr][40].ToString());
                    else
                        cmd.Parameters.AddWithValue("@create_user", DBNull.Value);
                }
                else
                    cmd.Parameters.AddWithValue("@create_user", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][41] != DBNull.Value)
                {
                    if (dtTenderDatesInfoData.Rows[loopCtr][41].ToString() != "")
                        cmd.Parameters.AddWithValue("@update_user", dtTenderDatesInfoData.Rows[loopCtr][41].ToString());
                    else
                        cmd.Parameters.AddWithValue("@update_user", DBNull.Value);
                }
                else
                    cmd.Parameters.AddWithValue("@update_user", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][42] != DBNull.Value)
                {
                    if (dtTenderDatesInfoData.Rows[loopCtr][42].ToString() != "")
                        cmd.Parameters.AddWithValue("@alert", Convert.ToInt16(dtTenderDatesInfoData.Rows[loopCtr][42]));
                    else
                        cmd.Parameters.AddWithValue("@alert", DBNull.Value);
                }
                else
                    cmd.Parameters.AddWithValue("@alert", DBNull.Value);           

            if (stageId == '1' || stageId == '2')
            {
                if (dtTenderDatesInfoData.Rows[loopCtr][43] != DBNull.Value)
                    cmd.Parameters.AddWithValue("@eval_com_sent1", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][43]));
                else
                    cmd.Parameters.AddWithValue("@eval_com_sent1", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][44] != DBNull.Value)
                    cmd.Parameters.AddWithValue("@eval_com_receive1", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][44]));
                else
                    cmd.Parameters.AddWithValue("@eval_com_receive1", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][45] != DBNull.Value)
                    cmd.Parameters.AddWithValue("@eval_award_approval", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][45]));
                else
                    cmd.Parameters.AddWithValue("@eval_award_approval", DBNull.Value);
                
            }
            

        }
        private void UpdateMoazanahProjectID()
        {
            string sqlUpdate = "Update Projects Set moazanah_proj_id_new = @mozID Where Proj_id = @prjID";
            using (SqlConnection sqlConn = new SqlConnection(strCon))
            {
                sqlConn.Open();
                using (SqlCommand sqlCom = new SqlCommand(sqlUpdate, sqlConn))
                {
                    sqlCom.Parameters.AddWithValue("@prjID", _prjIDExist);
                    sqlCom.Parameters.AddWithValue("@mozID", DBNull.Value);                    
                    sqlCom.ExecuteNonQuery();
                }
                sqlConn.Close();
            }
        }
        private void transforProjectsInfo(string prjPrifix, string statusType, string reTenderNo)
        {
            DataSet dsProjects = new DataSet();
            string sqlQuery = "Select proj_id,project_code,project_newname_en,committee_id, " +
                        " FYID, Affair_id, department_id, contract_type_id, tender_type_id, project_newname_en,project_name_ar,stage_id, " +
                        " SelectPrj,Tender_Status_id,[Ministry_Code],[Budget_Reference_No],[Provision_Number],moazanah_proj_id_new,tender_no From Projects Where proj_id = " + _prjIDExist +"";
            using (SqlConnection sqlConn = new SqlConnection(strCon))
            {
                sqlConn.Open();
                using (SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn))
                {                    
                    SqlDataAdapter daPrj = new SqlDataAdapter(sqlCom);
                    daPrj.Fill(dsProjects);
                }
                sqlConn.Close();
            }
            InsertProjectsInfo(dsProjects, prjPrifix, statusType, reTenderNo);            
        }
        private int GetStatus_ID()
        {
            int cmtID =0;
            string sqlUpdate = "SELECT committee_id FROM Committee WHERE (committee_short_name = '" + cmbCommittee.Text + "')";
            using (SqlConnection sqlConn = new SqlConnection(strCon))
            {
                sqlConn.Open();
                using (SqlCommand sqlCom = new SqlCommand(sqlUpdate, sqlConn))
                {
                     cmtID = Convert.ToInt16(sqlCom.ExecuteScalar());
                }
                sqlConn.Close();
            }
            return cmtID;
        }
        string currentProjCode = null;
        private void InsertProjectsInfo(DataSet dsProj, string prjCodePrefix, string _statusType, string reTenderNo)
        {              
            DAL dalObj = new DAL();
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    int _getcmtID = 0;
                    sqlConn.Open();
                    for (int i = 0; i < dsProj.Tables[0].Rows.Count; i++)
                    {
                        // DataRow dRow = ds.Tables[0].Rows[i][0];

                        if (_statusType.Contains("Transfer"))
                        {
                            _getcmtID = GetStatus_ID();
                        }

                        string insertQuery = "INSERT INTO PROJECTS(proj_id,project_code, project_newname_en,committee_id, " +
                             " FYID, Affair_id, department_id, contract_type_id, tender_type_id, project_name_en,project_name_ar,stage_id,SelectPrj,Tender_Status_id,[Ministry_Code],[Budget_Reference_No],[Provision_Number],moazanah_proj_id_new,tender_no,dummyfield,create_date," +
                             "create_user) " +
                             " VALUES(@prjID,@PrjCode,@PrjTitleEnNew,@CmtId,@FiscalID,@AffairID,@UserDept,@TypeOfPrj,@TypeOfTndr,@PrjTitleEn, @PrjTitleArb,@StageID,@SelPrj,@TndrStatusId,@MinistryCode,@BudgetRefNo,@ProvisionNo,@moazanah_id,@tndrNO,@dummy_field,@createDate," +
                             "@createUser)";

                        using (SqlCommand cmd = new SqlCommand(insertQuery, sqlConn))
                        {
                            cmd.Parameters.AddWithValue("@prjID", _newPrjID);

                            // Modified as per faisal request on Dec 30th 2013 By Sreedhar
                            // Modified by Varun on Jan 29 2013
                            // Modified by Varun on Aug 12 2014
                            if (!(_statusType.Contains("Transfer")))
                            {
                                currentProjCode = dsProj.Tables[0].Rows[i][1].ToString();
                            }
                            else
                            {
                                currentProjCode = dsProj.Tables[0].Rows[i][1].ToString() + prjCodePrefix;
                            }

                            //currentProjCode = dsProj.Tables[0].Rows[i][1].ToString();
                            cmd.Parameters.AddWithValue("@PrjCode", currentProjCode);

                            cmd.Parameters.AddWithValue("@PrjTitleEnNew", dsProj.Tables[0].Rows[i][2].ToString());

                            if (_statusType.Contains("Transfer"))
                            {
                                cmd.Parameters.AddWithValue("@CmtId", _getcmtID);
                                if (dsProj.Tables[0].Rows[i][13].ToString() == "")
                                {
                                    cmd.Parameters.AddWithValue("@StageID", 1);
                                    cmd.Parameters.AddWithValue("@TndrStatusId", 1);
                                }
                                else if (Convert.ToInt32(dsProj.Tables[0].Rows[i][13].ToString()) >= 4)
                                {
                                    cmd.Parameters.AddWithValue("@StageID", 3); //3==Tender Evaluation & Award
                                    cmd.Parameters.AddWithValue("@TndrStatusId", 3); //3==Technical Evaluation
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@StageID", dsProj.Tables[0].Rows[i][11].ToString());
                                    cmd.Parameters.AddWithValue("@TndrStatusId", dsProj.Tables[0].Rows[i][13].ToString());  
                                }
                            }
                            else
                            {
                                cmd.Parameters.AddWithValue("@CmtId", Convert.ToInt16(dsProj.Tables[0].Rows[i][3]));
                                cmd.Parameters.AddWithValue("@StageID", 1);
                                cmd.Parameters.AddWithValue("@TndrStatusId", 1);
                            }                            
                            
                           
                            cmd.Parameters.AddWithValue("@FiscalID", Convert.ToInt16(dsProj.Tables[0].Rows[i][4]));

                            cmd.Parameters.AddWithValue("@AffairID", Convert.ToInt16(dsProj.Tables[0].Rows[i][5]));
                            cmd.Parameters.AddWithValue("@UserDept", Convert.ToInt16(dsProj.Tables[0].Rows[i][6]));
                            cmd.Parameters.AddWithValue("@TypeOfPrj", Convert.ToInt16(dsProj.Tables[0].Rows[i][7]));
                            cmd.Parameters.AddWithValue("@TypeOfTndr", Convert.ToInt16(dsProj.Tables[0].Rows[i][8]));
                            cmd.Parameters.AddWithValue("@PrjTitleEn", dsProj.Tables[0].Rows[i][9]);
                            cmd.Parameters.AddWithValue("@PrjTitleArb", dsProj.Tables[0].Rows[i][10]);
                         
                            cmd.Parameters.AddWithValue("@SelPrj", 1);                            
                            cmd.Parameters.AddWithValue("@MinistryCode", dsProj.Tables[0].Rows[i][14]);
                            cmd.Parameters.AddWithValue("@BudgetRefNo", dsProj.Tables[0].Rows[i][15]);
                            if (dsProj.Tables[0].Rows[i][16].ToString() != "")
                                cmd.Parameters.AddWithValue("@ProvisionNo", dsProj.Tables[0].Rows[i][16]);
                            else
                                cmd.Parameters.AddWithValue("@ProvisionNo", DBNull.Value);

                            cmd.Parameters.AddWithValue("@moazanah_id", dsProj.Tables[0].Rows[i][17]);

                            if (!_statusType.Contains("Transfer"))
                            {
                                string newTndrCode = null;
                                if (reTenderNo != null)
                                {
                                    if (reTenderNo.Contains("R"))
                                    {
                                        //newTndrCode = dsProj.Tables[0].Rows[0][18].ToString().Trim().Replace("-R", "");
                                        //newTndrCode = newTndrCode + prjCodePrefix;
                                        cmd.Parameters.AddWithValue("@tndrNO", reTenderNo);
                                    }
                                    else
                                    {
                                        newTndrCode = dsProj.Tables[0].Rows[i][18].ToString() + prjCodePrefix;
                                        cmd.Parameters.AddWithValue("@tndrNO", newTndrCode);
                                    }
                                }
                                else
                                    cmd.Parameters.AddWithValue("@tndrNO", DBNull.Value);                                
                            }
                            else
                                cmd.Parameters.AddWithValue("@tndrNO", DBNull.Value);

                            cmd.Parameters.AddWithValue("@dummy_field", System.DateTime.Now);
                            cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                            cmd.Parameters.AddWithValue("@createUser", _userName);


                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                    }
                    sqlConn.Close();
                }
            }
            catch (Exception ex)
            { 
                MessageBox.Show("Error occurred while inserting projects info" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void transforTenderDates_Stage1()
        {
            string sqlQuery = "SELECT date_id, proj_id, stage_id, ptd_receive_on, ptd_purpose, ptd_assign_qs, ptd_sent_for_rev, ptd_qs_working_status, ptd_tendec_doc_cur_status, " +
            " ptd_forwarded_to_dep,remarks,create_date,update_date,create_user,update_user,Alert FROM TenderDatesInfo WHERE (proj_id = " + _prjIDExist + ") AND (stage_id = 1)";

            SqlConnection sqlConn = new SqlConnection(strCon);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            DataSet dsStg1 = new DataSet();
            SqlDataAdapter daStage1 = new SqlDataAdapter(sqlCom);
            daStage1.Fill(dsStg1);
            sqlConn.Close();
            if (dsStg1.Tables[0].Rows.Count > 0)
            {                
                InsertDocumentPreparationInfo(dsStg1);
            }             
        }
        
        private void transforTenderDates_Stage2()
        {
            string sqlQuery = "SELECT date_id, proj_id, stage_id, ts_receive_on, ts_issue_handling, ts_return_to_dept, ts_receive_from_dept, ts_pr_advertise, ts_tender_invitation, ts_closing_s1," +
            "ts_closing_s2, ts_modified_closing, ts_tender_issue, ts_receipt_no,co_id,employee_id,remarks,org_tender_validity,org_tenderbond_validity,org_tender_to_expire,org_tenderbond_to_expire," +
            "tender_validity_ext1,tender_validity_ext2,tenderbond_validity_ext1,tenderbond_validity_ext2,Tender_Issued,SN,create_date,update_date,create_user,update_user,Alert,Company_EmailID FROM TenderDatesInfo WHERE (proj_id = " + _prjIDExist + ") AND (stage_id = 2) "+
            "AND (ts_tender_issue IS NULL)"; //and ts_closing_s1 is NULL and ts_closing_s2 is NULL

            SqlConnection sqlConn = new SqlConnection(strCon);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);            
            SqlDataAdapter daStage2 = new SqlDataAdapter(sqlCom);
            daStage2.Fill(dsStg2);
            sqlConn.Close();
            if (dsStg2.Tables[0].Rows.Count > 0)
            {                 
                InsertTenderStageInfo(dsStg2,false);
            }

            sqlQuery = "SELECT date_id, proj_id, stage_id, ts_receive_on, ts_issue_handling, ts_return_to_dept, ts_receive_from_dept, ts_pr_advertise, ts_tender_invitation, ts_closing_s1," +
            "ts_closing_s2, ts_modified_closing, ts_tender_issue, ts_receipt_no,co_id,employee_id,remarks,org_tender_validity,org_tenderbond_validity,org_tender_to_expire,org_tenderbond_to_expire," +
            "tender_validity_ext1,tender_validity_ext2,tenderbond_validity_ext1,tenderbond_validity_ext2,Tender_Issued,SN,create_date,update_date,create_user,update_user,Alert,Company_EmailID FROM TenderDatesInfo WHERE (proj_id = " + _prjIDExist + ") AND (stage_id = 2) " +
            "AND (ts_tender_issue IS not NULL)"; //and ts_closing_s1 is NULL and ts_closing_s2 is NULL

            sqlConn = new SqlConnection(strCon);
            sqlConn.Open();
            sqlCom = new SqlCommand(sqlQuery, sqlConn);
            daStage2 = new SqlDataAdapter(sqlCom);
            daStage2.Fill(dsStg2Bidders);
            sqlConn.Close();
            if (dsStg2Bidders.Tables[0].Rows.Count > 0)
            {
                InsertTenderStageInfo(dsStg2Bidders,true);
            }
        }
        private void transforTenderDates_Stage3()
        {
            string sqlQuery = "SELECT date_id, proj_id, stage_id, eval_tender_opening, eval_tender_doc_receive_from_cd, eval_tech_sent1, eval_tech_receive1,remarks," +
            "create_date,update_date,create_user,update_user,Alert FROM TenderDatesInfo WHERE (proj_id = " + _prjIDExist + ") AND (stage_id = 3)";

            SqlConnection sqlConn = new SqlConnection(strCon);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);             
            SqlDataAdapter daStage3 = new SqlDataAdapter(sqlCom);
            daStage3.Fill(dsStg3);
            sqlConn.Close();
            if (dsStg3.Tables[0].Rows.Count > 0)
            {                 
                InsertTenderEvaluationData(dsStg3);
            }
        }
        
        private void transfor_ProjectCost()
        {
            string sqlQuery = "update ProjectCost set proj_id =" + _newPrjID + " WHERE (proj_id =" + _prjIDExist + ") AND (stage_id = 4) ";                     
            SqlConnection sqlConn = new SqlConnection(strCon);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            sqlCom.ExecuteNonQuery();          
        }

        private void UpdateProjectStatus(int statusID)
        {
            SqlConnection sqlConn = new SqlConnection(strCon);
            sqlConn.Open();
            string insertQuery = "UPDATE PROJECTS SET Tender_Status_id = @tndtStatus,moazanah_proj_id_new = @MoazID WHERE proj_id = @prjID";
            using (SqlCommand cmd = new SqlCommand(insertQuery, sqlConn))
            {
                cmd.Parameters.AddWithValue("@prjID", _prjIDExist);
                cmd.Parameters.AddWithValue("@tndtStatus", statusID);
                cmd.Parameters.AddWithValue("@MoazID", DBNull.Value); 
                int exUpdated = cmd.ExecuteNonQuery();
                cmd.Parameters.Clear();
            }            
        }
        private int MaxDateID()
        {
            int dateId = 0;
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"SELECT MAX(DATE_ID) FROM TenderDatesInfo";
                        dateId = Convert.ToInt16(cmd.ExecuteScalar());
                        dateId = dateId + 1;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            return dateId;
        }
        private void InsertTenderStageInfo(DataSet stg2Ds,bool isBidder)
        {

            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;                         
                        int totRowsCount = stg2Ds.Tables[0].Rows.Count;
                        for (int i = 0; i < totRowsCount; i++)
                        {
                            dateID = MaxDateID();
                            //if (stg2Ds.Tables[0].Rows[0][9].ToString() != "")   // Tender Closing date 
                            //{

                                if (!isBidder)
                                {
                                    cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,ts_receive_on,ts_issue_handling,ts_return_to_dept, " +
                                    " ts_receive_from_dept,ts_pr_advertise,ts_tender_invitation,ts_closing_s1,ts_closing_s2,ts_modified_closing,remarks,org_tender_validity," +
                                    "org_tenderbond_validity,org_tender_to_expire,org_tenderbond_to_expire,tender_validity_ext1,tender_validity_ext2,tenderbond_validity_ext1,tenderbond_validity_ext2,create_date,update_date,create_user,update_user,Alert,Company_EmailID) VALUES " +
                                    "(@dateId,@projId,@stageId,@receiveOn,@issueHandling,@returnDept,@receivedFromDept,@advertisement,@invitation,@closingDate1,@closingDate2,@tsModifyDate,@Remarks," +
                                    "@orgTenderValidity,@orgTenderbondValidity,@orgTenderToExpire,@orgTenderbondExpire,@tenderValidityExt1,@tenderValidityExt2,@tenderbondValidityExt1,@tenderbondValidityExt2,@createDate,@updateDate,@createUser,@updateUser,@alert,@companyEmailID)";
                                }
                                else
                                {
                                    cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,ts_tender_issue, " +
                                    " ts_receipt_no,co_id,employee_id,remarks,Tender_Issued,SN,create_date,update_date,create_user,update_user,Alert,Company_EmailID) VALUES " +
                                    "(@dateId,@projId,@stageId,@issueTndrDate,@receiptNo,@coID,@empID,@Remarks,@tenderIssued,@sn,@createDate,@updateDate,@createUser,@updateUser,@alert,@companyEmailID)";
                                }

                                cmd.Parameters.AddWithValue("@stageId", 2);

                                cmd.Parameters.AddWithValue("@projId", _newPrjID);

                                if (!isBidder)
                                {
                                    cmd.Parameters.AddWithValue("@receiveOn", stg2Ds.Tables[0].Rows[i][3]);

                                    if (stg2Ds.Tables[0].Rows[i][4].ToString() != "")
                                        cmd.Parameters.AddWithValue("@issueHandling", stg2Ds.Tables[0].Rows[i][4]);
                                    else
                                        cmd.Parameters.AddWithValue("@issueHandling", DBNull.Value);

                                    if (stg2Ds.Tables[0].Rows[i][5].ToString() != "")
                                        cmd.Parameters.AddWithValue("@returnDept", stg2Ds.Tables[0].Rows[i][5]);
                                    else
                                        cmd.Parameters.AddWithValue("@returnDept", DBNull.Value);

                                    if (stg2Ds.Tables[0].Rows[i][6].ToString() != "")
                                        cmd.Parameters.AddWithValue("@receivedFromDept", stg2Ds.Tables[0].Rows[i][6]);
                                    else
                                        cmd.Parameters.AddWithValue("@receivedFromDept", DBNull.Value);

                                    if (stg2Ds.Tables[0].Rows[i][7].ToString() != "")
                                        cmd.Parameters.AddWithValue("@advertisement", stg2Ds.Tables[0].Rows[i][7]);
                                    else
                                        cmd.Parameters.AddWithValue("@advertisement", DBNull.Value);

                                    if (stg2Ds.Tables[0].Rows[i][8].ToString() != "")
                                        cmd.Parameters.AddWithValue("@invitation", stg2Ds.Tables[0].Rows[i][8]);
                                    else
                                        cmd.Parameters.AddWithValue("@invitation", DBNull.Value);

                                    if (stg2Ds.Tables[0].Rows[0][9].ToString() != "")
                                        cmd.Parameters.AddWithValue("@closingDate1", stg2Ds.Tables[0].Rows[i][9]);
                                    else
                                        cmd.Parameters.AddWithValue("@closingDate1", DBNull.Value);

                                    if (stg2Ds.Tables[0].Rows[i][10].ToString() != "")
                                        cmd.Parameters.AddWithValue("@closingDate2", stg2Ds.Tables[0].Rows[i][10]);
                                    else
                                        cmd.Parameters.AddWithValue("@closingDate2", DBNull.Value);

                                    if (stg2Ds.Tables[0].Rows[i][11].ToString() != "")
                                        cmd.Parameters.AddWithValue("@tsModifyDate", stg2Ds.Tables[0].Rows[i][11]);
                                    else
                                        cmd.Parameters.AddWithValue("@tsModifyDate", DBNull.Value);
                                }
                                else
                                {
                                    if (stg2Ds.Tables[0].Rows[i][12].ToString() != "")
                                        cmd.Parameters.AddWithValue("@issueTndrDate", stg2Ds.Tables[0].Rows[i][12]);
                                    else
                                        cmd.Parameters.AddWithValue("@issueTndrDate", DBNull.Value);

                                    if (stg2Ds.Tables[0].Rows[i][13].ToString() != "")
                                        cmd.Parameters.AddWithValue("@receiptNo", stg2Ds.Tables[0].Rows[i][13]);
                                    else
                                        cmd.Parameters.AddWithValue("@receiptNo", DBNull.Value);

                                    if (stg2Ds.Tables[0].Rows[i][14].ToString() != "")
                                        cmd.Parameters.AddWithValue("@coID", stg2Ds.Tables[0].Rows[i][14]);
                                    else
                                        cmd.Parameters.AddWithValue("@coID", DBNull.Value);

                                    if (stg2Ds.Tables[0].Rows[i][15].ToString() != "")
                                        cmd.Parameters.AddWithValue("@empID", stg2Ds.Tables[0].Rows[i][15]);
                                    else
                                        cmd.Parameters.AddWithValue("@empID", DBNull.Value);
                                }

                                if (!isBidder)
                                {
                                    if (stg2Ds.Tables[0].Rows[i][16].ToString() == "")
                                        cmd.Parameters.AddWithValue("@Remarks", " **Note: This tender was formerly Assigned to " + _committee + " with assigned Tender No.  " + _tenderNo);
                                    else
                                        cmd.Parameters.AddWithValue("@Remarks", stg2Ds.Tables[0].Rows[i][16] + " **Note: This tender was formerly Assigned to " + _committee + " with assigned Tender No.  " + _tenderNo);                                    
                                }
                                else
                                    cmd.Parameters.AddWithValue("@Remarks", stg2Ds.Tables[0].Rows[i][16].ToString());

                                cmd.Parameters.AddWithValue("@dateId", dateID);

                                if (!isBidder)
                                {
                                    if (stg2Ds.Tables[0].Rows[i][17].ToString() != "")
                                        cmd.Parameters.AddWithValue("@orgTenderValidity", stg2Ds.Tables[0].Rows[i][17]);
                                    else
                                        cmd.Parameters.AddWithValue("@orgTenderValidity", DBNull.Value);

                                    if (stg2Ds.Tables[0].Rows[i][18].ToString() != "")
                                        cmd.Parameters.AddWithValue("@orgTenderbondValidity", stg2Ds.Tables[0].Rows[i][18]);
                                    else
                                        cmd.Parameters.AddWithValue("@orgTenderbondValidity", DBNull.Value);

                                    if (stg2Ds.Tables[0].Rows[i][19] != DBNull.Value)
                                        if (stg2Ds.Tables[0].Rows[i][19].ToString() != "")
                                            cmd.Parameters.AddWithValue("@orgTenderToExpire", Convert.ToInt16(stg2Ds.Tables[0].Rows[i][19]));
                                        else
                                            cmd.Parameters.AddWithValue("@orgTenderToExpire", DBNull.Value);
                                    else
                                        cmd.Parameters.AddWithValue("@orgTenderToExpire", DBNull.Value);

                                    if (stg2Ds.Tables[0].Rows[i][20] != DBNull.Value)
                                        if (stg2Ds.Tables[0].Rows[i][20].ToString() != "")
                                            cmd.Parameters.AddWithValue("@orgTenderbondExpire", Convert.ToInt16(stg2Ds.Tables[0].Rows[i][20]));
                                        else
                                            cmd.Parameters.AddWithValue("@orgTenderbondExpire", DBNull.Value);
                                    else
                                        cmd.Parameters.AddWithValue("@orgTenderbondExpire", DBNull.Value);

                                    if (stg2Ds.Tables[0].Rows[i][21] != DBNull.Value)
                                        if (stg2Ds.Tables[0].Rows[i][21].ToString() != "")
                                            cmd.Parameters.AddWithValue("@tenderValidityExt1", stg2Ds.Tables[0].Rows[i][21]);
                                        else
                                            cmd.Parameters.AddWithValue("@tenderValidityExt1", DBNull.Value);
                                    else
                                        cmd.Parameters.AddWithValue("@tenderValidityExt1", DBNull.Value);

                                    if (stg2Ds.Tables[0].Rows[i][22] != DBNull.Value)
                                        if (stg2Ds.Tables[0].Rows[i][22].ToString() != "")
                                            cmd.Parameters.AddWithValue("@tenderValidityExt2", stg2Ds.Tables[0].Rows[i][22]);
                                        else
                                            cmd.Parameters.AddWithValue("@tenderValidityExt2", DBNull.Value);
                                    else
                                        cmd.Parameters.AddWithValue("@tenderValidityExt2", DBNull.Value);

                                    if (stg2Ds.Tables[0].Rows[i][23] != DBNull.Value)
                                        if (stg2Ds.Tables[0].Rows[i][23].ToString() != "")
                                            cmd.Parameters.AddWithValue("@tenderbondValidityExt1", stg2Ds.Tables[0].Rows[i][23]);
                                        else
                                            cmd.Parameters.AddWithValue("@tenderbondValidityExt1", DBNull.Value);
                                    else
                                        cmd.Parameters.AddWithValue("@tenderbondValidityExt1", DBNull.Value);

                                    if (stg2Ds.Tables[0].Rows[i][24] != DBNull.Value)
                                        if (stg2Ds.Tables[0].Rows[i][24].ToString() != "")
                                            cmd.Parameters.AddWithValue("@tenderbondValidityExt2", stg2Ds.Tables[0].Rows[i][24]);
                                        else
                                            cmd.Parameters.AddWithValue("@tenderbondValidityExt2", DBNull.Value);
                                    else
                                        cmd.Parameters.AddWithValue("@tenderbondValidityExt2", DBNull.Value);
                                }
                                else
                                {
                                    if (stg2Ds.Tables[0].Rows[i][25] != DBNull.Value)
                                        if (stg2Ds.Tables[0].Rows[i][25].ToString() != "")
                                            cmd.Parameters.AddWithValue("@tenderIssued", stg2Ds.Tables[0].Rows[i][25]);
                                        else
                                            cmd.Parameters.AddWithValue("@tenderIssued", DBNull.Value);
                                    else
                                        cmd.Parameters.AddWithValue("@tenderIssued", DBNull.Value);

                                    if (stg2Ds.Tables[0].Rows[i][26] != DBNull.Value)
                                        if (stg2Ds.Tables[0].Rows[i][26].ToString() != "")
                                            cmd.Parameters.AddWithValue("@sn", Convert.ToInt16(stg2Ds.Tables[0].Rows[i][26]));
                                        else
                                            cmd.Parameters.AddWithValue("@sn", DBNull.Value);
                                    else
                                        cmd.Parameters.AddWithValue("@sn", DBNull.Value);
                                }              
                                cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                                                               
                                cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                                cmd.Parameters.AddWithValue("@createUser", _userName);
                                cmd.Parameters.AddWithValue("@updateUser", _userName);

                                if (stg2Ds.Tables[0].Rows[i][31] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][31].ToString() != "")
                                        cmd.Parameters.AddWithValue("@alert", stg2Ds.Tables[0].Rows[i][31]);
                                    else
                                        cmd.Parameters.AddWithValue("@alert", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@alert", DBNull.Value);

                                // Added by Varun on 08 May 2014 for copying the newly added column data
                                if (stg2Ds.Tables[0].Rows[i][32] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][32].ToString() != "")
                                        cmd.Parameters.AddWithValue("@companyEmailID", stg2Ds.Tables[0].Rows[i][32]);
                                    else
                                        cmd.Parameters.AddWithValue("@companyEmailID", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@companyEmailID", DBNull.Value);

                                int exUpdated = cmd.ExecuteNonQuery();
                                cmd.Parameters.Clear();
                                 
                            //}
                            //else
                            //    i = stg2Ds.Tables[0].Rows.Count;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while copying the records." + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void frmTransforProject_Load(object sender, EventArgs e)
        {
            if (_tndrStatus.Equals("10"))
            {
                cmbCommittee.Items.Clear();
                if (_committee.Equals("ITC"))
                {
                    cmbCommittee.Items.Add("STC");
                    cmbCommittee.Items.Add("GTC");
                    //commented by Varun on 11/08/14
                    //cmbCommittee.Items.Add("U&EWTC");
                    cmbCommittee.Items.Add("EUWC");
                    cmbCommittee.Items.Add("MRPSC");
                }
                else if (_committee.Equals("STC"))
                {
                    cmbCommittee.Items.Add("ITC");
                    cmbCommittee.Items.Add("GTC");
                    //commented by Varun on 11/08/14
                    //cmbCommittee.Items.Add("U&EWTC");
                    cmbCommittee.Items.Add("EUWC");
                }
                else if (_committee.Equals("WPC"))
                {
                    cmbCommittee.Items.Add("STC");
                    cmbCommittee.Items.Add("ITC");
                    cmbCommittee.Items.Add("GTC");
                    //commented by Varun on 11/08/14
                    //cmbCommittee.Items.Add("U&EWTC");
                    cmbCommittee.Items.Add("EUWC");
                }
                else if (_committee.Equals("MRPSC"))
                {                     
                    cmbCommittee.Items.Add("GTC");                     
                }
                else if (_committee.Equals("GTC"))
                {
                    //commented by Varun on 11/08/14
                    //cmbCommittee.Items.Add("U&EWTC");
                    cmbCommittee.Items.Add("ITC");
                    cmbCommittee.Items.Add("STC");
                    cmbCommittee.Items.Add("EUWC");                             
                }
                else if (_committee.Equals("EUWC"))
                {
                    cmbCommittee.Items.Add("ITC");
                    cmbCommittee.Items.Add("STC");
                    cmbCommittee.Items.Add("GTC");                     
                }
            }
            else if (_tndrStatus.Equals("9"))
            {
                this.Text = "Re-Tender Project";
                lblCommitteName.Visible = false; 
                cmbCommittee.Visible = false;
                grpBoxTenderType.Visible = true;
            }
        }
         
       
        int dateID = 0;
        private void InsertDocumentPreparationInfo(DataSet stg1Ds)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    sqlConn.Open();
                    int totRows = stg1Ds.Tables[0].Rows.Count;
                    for (int i = 0; i < totRows; i++)
                    {
                        dateID = MaxDateID();
                        string insertQuery = "INSERT INTO TenderDatesInfo(date_id,proj_id, stage_id, ptd_receive_on, ptd_purpose, ptd_assign_qs," +
                        " ptd_sent_for_rev, ptd_qs_working_status, ptd_tendec_doc_cur_status,ptd_forwarded_to_dep, remarks,create_date,update_date,create_user,update_user,Alert) VALUES " +
                        " (@dateId,@projId,@stageId,@PTDreceiveOn,@PTDPurpose,@PTDassignQs,@PTDForReview,@PTDQsStatus,@PTDdocStatus,@PTDfrwdDept,@PTDRemarks,@createDate,@updateDate,@createUser,@updateUser,@alert)";

                        SqlCommand cmd = new SqlCommand(insertQuery, sqlConn);
                        cmd.Parameters.AddWithValue("@dateId", dateID);
                        cmd.Parameters.AddWithValue("@projId", _newPrjID);
                        cmd.Parameters.AddWithValue("@stageId", 1);

                        if (stg1Ds.Tables[0].Rows[i][3].ToString() != "")
                            cmd.Parameters.AddWithValue("@PTDreceiveOn", stg1Ds.Tables[0].Rows[i][3]);
                        else
                            cmd.Parameters.AddWithValue("@PTDreceiveOn", DBNull.Value);

                        if (stg1Ds.Tables[0].Rows[i][4].ToString() != "")
                            cmd.Parameters.AddWithValue("@PTDPurpose", stg1Ds.Tables[0].Rows[i][4].ToString());
                        else
                            cmd.Parameters.AddWithValue("@PTDPurpose", DBNull.Value);

                        if (stg1Ds.Tables[0].Rows[i][5].ToString() != "")
                            cmd.Parameters.AddWithValue("@PTDassignQs", stg1Ds.Tables[0].Rows[i][5].ToString());
                        else
                            cmd.Parameters.AddWithValue("@PTDassignQs", DBNull.Value);

                        if (stg1Ds.Tables[0].Rows[i][6].ToString() != "")
                            cmd.Parameters.AddWithValue("@PTDForReview", stg1Ds.Tables[0].Rows[i][6]);
                        else
                            cmd.Parameters.AddWithValue("@PTDForReview", DBNull.Value);

                        if (stg1Ds.Tables[0].Rows[i][7].ToString() != "")
                            cmd.Parameters.AddWithValue("@PTDQsStatus", stg1Ds.Tables[0].Rows[i][7].ToString());
                        else
                            cmd.Parameters.AddWithValue("@PTDQsStatus", DBNull.Value);

                        if (stg1Ds.Tables[0].Rows[i][8].ToString() != "")
                            cmd.Parameters.AddWithValue("@PTDdocStatus", stg1Ds.Tables[0].Rows[i][8].ToString());
                        else
                            cmd.Parameters.AddWithValue("@PTDdocStatus", DBNull.Value);

                        if (stg1Ds.Tables[0].Rows[i][9].ToString() != "")
                            cmd.Parameters.AddWithValue("@PTDfrwdDept", stg1Ds.Tables[0].Rows[i][9]);
                        else
                            cmd.Parameters.AddWithValue("@PTDfrwdDept", DBNull.Value);

                        cmd.Parameters.AddWithValue("@PTDRemarks", stg1Ds.Tables[0].Rows[i][10].ToString()); // + "**Note: This tender was formerly Assigned to "  + _committee + " with assigned Tender No. PWA/ITC/039/2011-12"
                        cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@createUser", _userName);
                        cmd.Parameters.AddWithValue("@updateUser", _userName);

                        if (stg1Ds.Tables[0].Rows[i][15] != DBNull.Value)
                            if (stg1Ds.Tables[0].Rows[i][15].ToString() != "")
                                cmd.Parameters.AddWithValue("@alert", stg1Ds.Tables[0].Rows[i][15]);
                            else
                                cmd.Parameters.AddWithValue("@alert", DBNull.Value);
                        else
                            cmd.Parameters.AddWithValue("@alert", DBNull.Value);

                        cmd.ExecuteNonQuery();
                        
                        //MessageBox.Show("Tender Document Preparation Data Added Successfully!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while copying the records." + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {                
            }
        }
        //private void InsertTenderPreparationInfo(DataSet stg2Ds)
        //{
        //    try
        //    {
        //        using (SqlConnection sqlConn = new SqlConnection(strCon))
        //        {
        //            using (SqlCommand cmd = new SqlCommand())
        //            {
        //                sqlConn.Open();
        //                cmd.Connection = sqlConn;
        //                int stgeId = 0;
        //                stgeId = 2;

        //                for (int i = 0; i < stg2Ds.Tables[0].Rows.Count; i++)
        //                {
        //                    int dateID = MaxDateID();

        //                    cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,ts_receive_on,ts_issue_handling,ts_return_to_dept, " +
        //                    " ts_receive_from_dept,ts_pr_advertise,ts_tender_invitation,ts_closing_s1,ts_closing_s2,ts_modified_closing,ts_tender_issue,ts_receipt_no,co_id,employee_id,remarks) VALUES " +
        //                    " (@dateId,@projId,@stageId,@receiveOn,@issueHandling,@returnDept,@receivedFromDept,@advertisement,@invitation,@closingDate,@closingDate2,@tsModifyDate,@issueTndrDate,@receiptNo,@coID,@empID,@Remarks)";

        //                    cmd.Parameters.AddWithValue("@stageId", stgeId);
        //                    cmd.Parameters.AddWithValue("@projId", maxPrjiD);
        //                    cmd.Parameters.AddWithValue("@receiveOn", stg2Ds.Tables[0].Rows[i][3]);

        //                    if (stg2Ds.Tables[0].Rows[i][4].ToString() != "")
        //                        cmd.Parameters.AddWithValue("@issueHandling", stg2Ds.Tables[0].Rows[i][4]);
        //                    else
        //                        cmd.Parameters.AddWithValue("@issueHandling", DBNull.Value);

        //                    if (stg2Ds.Tables[0].Rows[i][5].ToString() != "")
        //                        cmd.Parameters.AddWithValue("@returnDept", stg2Ds.Tables[0].Rows[i][5]);
        //                    else
        //                        cmd.Parameters.AddWithValue("@returnDept", DBNull.Value);

        //                    if (stg2Ds.Tables[0].Rows[i][6].ToString() != "")
        //                        cmd.Parameters.AddWithValue("@receivedFromDept", stg2Ds.Tables[0].Rows[i][6]);
        //                    else
        //                        cmd.Parameters.AddWithValue("@receivedFromDept", DBNull.Value);

        //                    if (stg2Ds.Tables[0].Rows[i][7].ToString() != "")
        //                        cmd.Parameters.AddWithValue("@advertisement", stg2Ds.Tables[0].Rows[i][7]);
        //                    else
        //                        cmd.Parameters.AddWithValue("@advertisement", DBNull.Value);

        //                    if (stg2Ds.Tables[0].Rows[i][8].ToString() != "")
        //                        cmd.Parameters.AddWithValue("@invitation", stg2Ds.Tables[0].Rows[i][8]);
        //                    else
        //                        cmd.Parameters.AddWithValue("@invitation", DBNull.Value);

        //                    if (stg2Ds.Tables[0].Rows[i][9].ToString() != "")
        //                        cmd.Parameters.AddWithValue("@closingDate", stg2Ds.Tables[0].Rows[i][9]);
        //                    else
        //                        cmd.Parameters.AddWithValue("@closingDate", DBNull.Value);

        //                    if (stg2Ds.Tables[0].Rows[i][10].ToString() != "")
        //                        cmd.Parameters.AddWithValue("@closingDate2", stg2Ds.Tables[0].Rows[i][10]);
        //                    else
        //                        cmd.Parameters.AddWithValue("@closingDate2", DBNull.Value);

        //                    if (stg2Ds.Tables[0].Rows[i][11].ToString() != "")
        //                        cmd.Parameters.AddWithValue("@tsModifyDate", stg2Ds.Tables[0].Rows[i][11]);
        //                    else
        //                        cmd.Parameters.AddWithValue("@tsModifyDate", DBNull.Value);

        //                    if (stg2Ds.Tables[0].Rows[i][12].ToString() != "")
        //                        cmd.Parameters.AddWithValue("@issueTndrDate", stg2Ds.Tables[0].Rows[i][12]);
        //                    else
        //                        cmd.Parameters.AddWithValue("@issueTndrDate", DBNull.Value);

        //                    if (stg2Ds.Tables[0].Rows[i][13].ToString() != "")
        //                        cmd.Parameters.AddWithValue("@receiptNo", stg2Ds.Tables[0].Rows[i][13]);
        //                    else
        //                        cmd.Parameters.AddWithValue("@receiptNo", DBNull.Value);

        //                    if (stg2Ds.Tables[0].Rows[i][14].ToString() != "")
        //                        cmd.Parameters.AddWithValue("@coID", stg2Ds.Tables[0].Rows[i][14]);
        //                    else
        //                        cmd.Parameters.AddWithValue("@coID", DBNull.Value);

        //                    if (stg2Ds.Tables[0].Rows[i][15].ToString() != "")
        //                        cmd.Parameters.AddWithValue("@empID", stg2Ds.Tables[0].Rows[i][15]);
        //                    else
        //                        cmd.Parameters.AddWithValue("@empID", DBNull.Value);

        //                    cmd.Parameters.AddWithValue("@Remarks", stg2Ds.Tables[0].Rows[i][16] + " **Note: This tender was formerly Assigned to " + _committee + " with assigned Tender No.  " + _tenderNo);
                            
        //                    cmd.Parameters.AddWithValue("@dateId", dateID);

        //                    int exUpdated = cmd.ExecuteNonQuery();
        //                    cmd.Parameters.Clear();
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //    }
        //}


        private void InsertTenderEvaluationData(DataSet stg3Ds)
        {
            int totRowCount = stg3Ds.Tables[0].Rows.Count;
            for (int i = 0; i < totRowCount; i++)
            {                
                try
                {
                    using (SqlConnection sqlConn = new SqlConnection(strCon))
                    {
                        using (SqlCommand cmd = new SqlCommand())
                        {
                            sqlConn.Open();
                            cmd.Connection = sqlConn;                            
                            dateID = MaxDateID();
                            cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,eval_tender_opening,eval_tender_doc_receive_from_cd, " +
                            " eval_tech_sent1,eval_tech_receive1,remarks,create_date,update_date,create_user,update_user,Alert) " +
                            " VALUES(@dateId,@projId,@stageId,@evltendrReq,@fromCd,@senttoTech,@recfromtech,@remarksTE,@createDate,@updateDate,@createUser,@updateUser,@alert)";
                            
                            cmd.Parameters.AddWithValue("@dateId", dateID);
                            cmd.Parameters.AddWithValue("@projId", _newPrjID);
                            cmd.Parameters.AddWithValue("@stageId", 3);                           

                            if (stg3Ds.Tables[0].Rows[i][3].ToString() != "")
                                cmd.Parameters.AddWithValue("@evltendrReq", stg3Ds.Tables[0].Rows[i][3]);
                            else
                                cmd.Parameters.AddWithValue("@evltendrReq", DBNull.Value);

                            if (stg3Ds.Tables[0].Rows[i][4].ToString() != "")
                                cmd.Parameters.AddWithValue("@fromCd", stg3Ds.Tables[0].Rows[i][4]);
                            else
                                cmd.Parameters.AddWithValue("@fromCd", DBNull.Value);

                            if (stg3Ds.Tables[0].Rows[i][5].ToString() != "")
                                cmd.Parameters.AddWithValue("@senttoTech", stg3Ds.Tables[0].Rows[i][5]);
                            else
                                cmd.Parameters.AddWithValue("@senttoTech", DBNull.Value);

                            if (stg3Ds.Tables[0].Rows[i][6].ToString() != "")
                                cmd.Parameters.AddWithValue("@recfromtech", stg3Ds.Tables[0].Rows[i][6]);
                            else
                                cmd.Parameters.AddWithValue("@recfromtech", DBNull.Value);

                            if (i == 0)
                            {
                                if (stg3Ds.Tables[0].Rows[i][7].ToString() != "")
                                    cmd.Parameters.AddWithValue("@remarksTE", stg3Ds.Tables[0].Rows[i][7].ToString() + " **Note: This tender was formerly Assigned to " + _committee + " with assigned Tender No.  " + _tenderNo);
                                else
                                    cmd.Parameters.AddWithValue("@remarksTE", " **Note: This tender was formerly Assigned to " + _committee + " with assigned Tender No.  " + _tenderNo);                                
                            }
                            else
                                cmd.Parameters.AddWithValue("@remarksTE", stg3Ds.Tables[0].Rows[i][7].ToString());

                            cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                            cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                            cmd.Parameters.AddWithValue("@createUser", _userName);
                            cmd.Parameters.AddWithValue("@updateUser", _userName);

                            if (stg3Ds.Tables[0].Rows[i][12] != DBNull.Value)
                                if (stg3Ds.Tables[0].Rows[i][12].ToString() != "")
                                    cmd.Parameters.AddWithValue("@alert", stg3Ds.Tables[0].Rows[i][12]);
                                else
                                    cmd.Parameters.AddWithValue("@alert", DBNull.Value);
                            else
                                cmd.Parameters.AddWithValue("@alert", DBNull.Value);

                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                            
                           // MessageBox.Show("Tender Evaluation & Award data added Succesfully");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while copying the records." + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }            
        private void UpdateDocumentProjectID()
        {
            //string sqlQuery = "SELECT project_id FROM DOCUMENTS WHERE PROJ_ID = " +  _prjCodeExisted + " and STAGE_ID = 1";

            string sqlQuery = "UPDATE DOCUMENTS SET project_id =@projId FROM DOCUMENTS WHERE PROJ_ID = " + _prjCodeExisted + " and STAGE_ID = 1";
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn; 
                        cmd.CommandText = sqlQuery;

                        cmd.Parameters.AddWithValue("@projId", _newPrjID);
                        //cmd.Parameters.AddWithValue("@stageId", stage_Id);

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();                       
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while UPDATING DOCUMENTS", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void cmbCommittee_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbCommittee.Text == "Re-Tender")
            {
                grpBoxTenderType.Visible = true;
            }
        }


        private void UpdateProjectCost(DataSet ds_Cost)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        int stgeId = 0;
                        stgeId = 4;

                        for (int i = 0; i < ds_Cost.Tables[0].Rows.Count; i++)
                        {
                            int _costID = MaxCostID();

                            cmd.CommandText = @"INSERT INTO ProjectCost(stage_id, proj_id, budgeted_cost, estimated_cost, tender_bond, doc_fee, Remarks) VALUES " +
                            " (@stageId,@projId,@budgeted_cost,@estimated_cost,@tender_bond,@doc_fee,@Remarks)";

                            //cmd.Parameters.AddWithValue("@cost_item_id", _costID);
                            cmd.Parameters.AddWithValue("@stageId", stgeId);
                            cmd.Parameters.AddWithValue("@projId", _newPrjID);
                           
                            if (ds_Cost.Tables[0].Rows[i][3].ToString() != "")
                                cmd.Parameters.AddWithValue("@budgeted_cost", ds_Cost.Tables[0].Rows[i][3]);
                            else
                                cmd.Parameters.AddWithValue("@budgeted_cost", DBNull.Value);

                            if (ds_Cost.Tables[0].Rows[i][4].ToString() != "")
                                cmd.Parameters.AddWithValue("@estimated_cost", ds_Cost.Tables[0].Rows[i][4]);
                            else
                                cmd.Parameters.AddWithValue("@estimated_cost", DBNull.Value);

                            if (ds_Cost.Tables[0].Rows[i][5].ToString() != "")
                                cmd.Parameters.AddWithValue("@tender_bond", ds_Cost.Tables[0].Rows[i][5]);
                            else
                                cmd.Parameters.AddWithValue("@tender_bond", DBNull.Value);

                            if (ds_Cost.Tables[0].Rows[i][6].ToString() != "")
                                cmd.Parameters.AddWithValue("@doc_fee", ds_Cost.Tables[0].Rows[i][6]);
                            else
                                cmd.Parameters.AddWithValue("@doc_fee", DBNull.Value);

                            if (ds_Cost.Tables[0].Rows[i][7].ToString() != "")
                                cmd.Parameters.AddWithValue("@Remarks", ds_Cost.Tables[0].Rows[i][7] + " **Note: This tender was formerly Assigned to " + _committee + " with assigned Tender No.  " + _tenderNo);
                            else
                                cmd.Parameters.AddWithValue("@Remarks", " **Note: This tender was formerly Assigned to " + _committee + " with assigned Tender No.  " + _tenderNo);

                         
                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private int MaxCostID()
        {
            int costID = 0;
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"SELECT MAX(Cost_item_ID) FROM ProjectCost";
                        costID = Convert.ToInt16(cmd.ExecuteScalar());
                        costID = costID + 1;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            return costID;
        }

        private void UpdateDocumnts_ProjectID()
        {
            SqlConnection sqlConn = new SqlConnection(strCon);
            sqlConn.Open();
            //doc_type_id<>2 Added by Varun on 04 Feb 2014 Based on req. from Adonis
            string insertQuery = "UPDATE DOCUMENTS SET Proj_ID =  " + _newPrjID + " WHERE Proj_ID = " + _prjIDExist + " and doc_type_id<>2";  
            using (SqlCommand cmd = new SqlCommand(insertQuery, sqlConn))
            {
                int exUpdated = cmd.ExecuteNonQuery();
                cmd.Parameters.Clear();
            }
            sqlConn.Close();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            transforTenderDates_Stage2_TEMP();
        }


        private void InsertTenderStageInfo_Temp(DataSet stg2Ds)
        {


            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        int stgeId = 0;
                        stgeId = 2;
                        int totRowsCount = stg2Ds.Tables[0].Rows.Count;
                        for (int i = 0; i < totRowsCount; i++)
                        {
                            dateID = MaxDateID();
                            if (stg2Ds.Tables[0].Rows[0][9].ToString() != "")   // Tender Closing date 
                            {

                                if (i == 0)
                                    cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,ts_receive_on,ts_issue_handling,ts_return_to_dept, " +
                                    " ts_receive_from_dept,ts_pr_advertise,ts_tender_invitation,ts_closing_s1,ts_closing_s2,ts_modified_closing,ts_tender_issue,ts_receipt_no,co_id,employee_id,remarks,org_tender_validity," +
                                    "org_tenderbond_validity,org_tender_to_expire,org_tenderbond_to_expire,tender_validity_ext1,tender_validity_ext2,tenderbond_validity_ext1,tenderbond_validity_ext2,Tender_Issued,SN,create_date,update_date,create_user,update_user,Alert,Company_EmailID) VALUES " +
                                    "(@dateId,@projId,@stageId,@receiveOn,@issueHandling,@returnDept,@receivedFromDept,@advertisement,@invitation,@closingDate,@closingDate2,@tsModifyDate,@issueTndrDate,@receiptNo,@coID,@empID,@Remarks," +
                                    "@orgTenderValidity,@orgTenderbondValidity,@orgTenderToExpire,@orgTenderbondExpire,@tenderValidityExt1,@tenderValidityExt2,@tenderbondValidityExt1,@tenderbondValidityExt2,@tenderIssued,@sn,@createDate,@updateDate,@createUser,@updateUser,@alert,@companyEmailID)";
                                else if (i >= 1)
                                    cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,ts_receive_on,ts_issue_handling,ts_return_to_dept, " +
                                    " ts_receive_from_dept,ts_pr_advertise,ts_tender_invitation,ts_closing_s2,ts_modified_closing,ts_tender_issue,ts_receipt_no,co_id,employee_id,remarks,org_tender_validity,org_tenderbond_validity," +
                                    "org_tender_to_expire,org_tenderbond_to_expire,tender_validity_ext1,tender_validity_ext2,tenderbond_validity_ext1,tenderbond_validity_ext2,Tender_Issued,SN,create_date,update_date,create_user,update_user,Alert,Company_EmailID) VALUES " +
                                    "(@dateId,@projId,@stageId,@receiveOn,@issueHandling,@returnDept,@receivedFromDept,@advertisement,@invitation,@closingDate2,@tsModifyDate,@issueTndrDate,@receiptNo,@coID,@empID,@Remarks," +
                                    "@orgTenderValidity,@orgTenderbondValidity,@orgTenderToExpire,@orgTenderbondExpire,@tenderValidityExt1,@tenderValidityExt2,@tenderbondValidityExt1,@tenderbondValidityExt2,@tenderIssued,@sn,@createDate,@updateDate,@createUser,@updateUser,@alert,@companyEmailID)";

                                cmd.Parameters.AddWithValue("@stageId", stgeId);

                                cmd.Parameters.AddWithValue("@projId", 1465);


                                cmd.Parameters.AddWithValue("@receiveOn", stg2Ds.Tables[0].Rows[i][3]);

                                if (stg2Ds.Tables[0].Rows[i][4].ToString() != "")
                                    cmd.Parameters.AddWithValue("@issueHandling", stg2Ds.Tables[0].Rows[i][4]);
                                else
                                    cmd.Parameters.AddWithValue("@issueHandling", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][5].ToString() != "")
                                    cmd.Parameters.AddWithValue("@returnDept", stg2Ds.Tables[0].Rows[i][5]);
                                else
                                    cmd.Parameters.AddWithValue("@returnDept", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][6].ToString() != "")
                                    cmd.Parameters.AddWithValue("@receivedFromDept", stg2Ds.Tables[0].Rows[i][6]);
                                else
                                    cmd.Parameters.AddWithValue("@receivedFromDept", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][7].ToString() != "")
                                    cmd.Parameters.AddWithValue("@advertisement", stg2Ds.Tables[0].Rows[i][7]);
                                else
                                    cmd.Parameters.AddWithValue("@advertisement", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][8].ToString() != "")
                                    cmd.Parameters.AddWithValue("@invitation", stg2Ds.Tables[0].Rows[i][8]);
                                else
                                    cmd.Parameters.AddWithValue("@invitation", DBNull.Value);

                                if (i == 0)
                                {
                                    if (stg2Ds.Tables[0].Rows[i][9].ToString() != "")
                                        cmd.Parameters.AddWithValue("@closingDate", stg2Ds.Tables[0].Rows[i][9]);
                                }

                                if (stg2Ds.Tables[0].Rows[i][10].ToString() != "")
                                    cmd.Parameters.AddWithValue("@closingDate2", stg2Ds.Tables[0].Rows[i][10]);
                                else
                                    cmd.Parameters.AddWithValue("@closingDate2", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][11].ToString() != "")
                                    cmd.Parameters.AddWithValue("@tsModifyDate", stg2Ds.Tables[0].Rows[i][11]);
                                else
                                    cmd.Parameters.AddWithValue("@tsModifyDate", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][12].ToString() != "")
                                    cmd.Parameters.AddWithValue("@issueTndrDate", stg2Ds.Tables[0].Rows[i][12]);
                                else
                                    cmd.Parameters.AddWithValue("@issueTndrDate", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][13].ToString() != "")
                                    cmd.Parameters.AddWithValue("@receiptNo", stg2Ds.Tables[0].Rows[i][13]);
                                else
                                    cmd.Parameters.AddWithValue("@receiptNo", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][14].ToString() != "")
                                    cmd.Parameters.AddWithValue("@coID", stg2Ds.Tables[0].Rows[i][14]);
                                else
                                    cmd.Parameters.AddWithValue("@coID", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][15].ToString() != "")
                                    cmd.Parameters.AddWithValue("@empID", stg2Ds.Tables[0].Rows[i][15]);
                                else
                                    cmd.Parameters.AddWithValue("@empID", DBNull.Value);

                                if (i == 0)
                                {
                                    if (stg2Ds.Tables[0].Rows[i][16].ToString() == "")
                                        cmd.Parameters.AddWithValue("@Remarks", " **Note: This tender was formerly Assigned to " + "STC" + " with assigned Tender No.  " + "PWA/STC/050/2013-2014");
                                    else
                                        cmd.Parameters.AddWithValue("@Remarks", stg2Ds.Tables[0].Rows[i][16] + " **Note: This tender was formerly Assigned to " + "STC" + " with assigned Tender No.  " + "PWA/STC/050/2013-2014");
                                }
                                else
                                    cmd.Parameters.AddWithValue("@Remarks", stg2Ds.Tables[0].Rows[i][16].ToString());

                                cmd.Parameters.AddWithValue("@dateId", dateID);

                                if (stg2Ds.Tables[0].Rows[i][17].ToString() != "")
                                    cmd.Parameters.AddWithValue("@orgTenderValidity", stg2Ds.Tables[0].Rows[i][17]);
                                else
                                    cmd.Parameters.AddWithValue("@orgTenderValidity", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][18].ToString() != "")
                                    cmd.Parameters.AddWithValue("@orgTenderbondValidity", stg2Ds.Tables[0].Rows[i][18]);
                                else
                                    cmd.Parameters.AddWithValue("@orgTenderbondValidity", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][19] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][19].ToString() != "")
                                        cmd.Parameters.AddWithValue("@orgTenderToExpire", Convert.ToInt16(stg2Ds.Tables[0].Rows[i][19]));
                                    else
                                        cmd.Parameters.AddWithValue("@orgTenderToExpire", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@orgTenderToExpire", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][20] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][20].ToString() != "")
                                        cmd.Parameters.AddWithValue("@orgTenderbondExpire", Convert.ToInt16(stg2Ds.Tables[0].Rows[i][20]));
                                    else
                                        cmd.Parameters.AddWithValue("@orgTenderbondExpire", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@orgTenderbondExpire", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][21] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][21].ToString() != "")
                                        cmd.Parameters.AddWithValue("@tenderValidityExt1", stg2Ds.Tables[0].Rows[i][21]);
                                    else
                                        cmd.Parameters.AddWithValue("@tenderValidityExt1", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@tenderValidityExt1", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][22] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][22].ToString() != "")
                                        cmd.Parameters.AddWithValue("@tenderValidityExt2", stg2Ds.Tables[0].Rows[i][22]);
                                    else
                                        cmd.Parameters.AddWithValue("@tenderValidityExt2", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@tenderValidityExt2", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][23] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][23].ToString() != "")
                                        cmd.Parameters.AddWithValue("@tenderbondValidityExt1", stg2Ds.Tables[0].Rows[i][23]);
                                    else
                                        cmd.Parameters.AddWithValue("@tenderbondValidityExt1", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@tenderbondValidityExt1", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][24] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][24].ToString() != "")
                                        cmd.Parameters.AddWithValue("@tenderbondValidityExt2", stg2Ds.Tables[0].Rows[i][24]);
                                    else
                                        cmd.Parameters.AddWithValue("@tenderbondValidityExt2", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@tenderbondValidityExt2", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][25] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][25].ToString() != "")
                                        cmd.Parameters.AddWithValue("@tenderIssued", stg2Ds.Tables[0].Rows[i][25]);
                                    else
                                        cmd.Parameters.AddWithValue("@tenderIssued", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@tenderIssued", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][26] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][26].ToString() != "")
                                        cmd.Parameters.AddWithValue("@sn", Convert.ToInt16(stg2Ds.Tables[0].Rows[i][26]));
                                    else
                                        cmd.Parameters.AddWithValue("@sn", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@sn", DBNull.Value);

                                cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now);

                                cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                                cmd.Parameters.AddWithValue("@createUser", _userName);
                                cmd.Parameters.AddWithValue("@updateUser", _userName);

                                if (stg2Ds.Tables[0].Rows[i][31] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][31].ToString() != "")
                                        cmd.Parameters.AddWithValue("@alert", stg2Ds.Tables[0].Rows[i][31]);
                                    else
                                        cmd.Parameters.AddWithValue("@alert", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@alert", DBNull.Value);

                                // Added by Varun on 08 May 2014 for copying the newly added column data
                                if (stg2Ds.Tables[0].Rows[i][32] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][32].ToString() != "")
                                        cmd.Parameters.AddWithValue("@companyEmailID", stg2Ds.Tables[0].Rows[i][32]);
                                    else
                                        cmd.Parameters.AddWithValue("@companyEmailID", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@companyEmailID", DBNull.Value);

                                int exUpdated = cmd.ExecuteNonQuery();
                                cmd.Parameters.Clear();

                            }
                            else
                                i = stg2Ds.Tables[0].Rows.Count;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while copying the records." + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

    }
}
