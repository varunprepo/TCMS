﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using TenderTrackingSystem;
using MDI_ParenrForm.Projects;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;
using MDI_ParenrForm;
using System.Diagnostics;
using System.Net.Mail;


namespace MDI_ParenrForm.Projects
{
    public partial class frmBidderInfo : Form
    {
        protected SqlConnection sqlConn;        
        protected SqlDataReader sqlDtReader;
        SqlCommand sqlCom = null;
        
        private string strCon = ConfigurationManager.AppSettings["TCMSConnString"].ToString();
        int _prjID = 0;
        string _prjCode = string.Empty;
        string _prjTitle = string.Empty;
        string _tenderNo = string.Empty;
        IList<string> userRightsColl = new List<string>();
        string selectedCompany = string.Empty;
        string _userName = string.Empty;
        char _chCheckCircular = ' ';
        char _chCheckShortList = ' ';
        string _tenderBond = null;
        string _documentFee = null;
        string _tenderIssueDate = null;        
        string _strEligibleTenderTypes = null;
        char _chFirstRun = 'N';
        clsTs_Stage clsForTS = null;
        string mTypeOfTender = null;
        int _circularCnt = 0;

        //Modified By Varun on 16th Feb 2014 replace prAdvDate by tenderIssueDate based on Riyas request
        public frmBidderInfo(IList<string> userRightsCollPrjState, int projID, string prjCode, string prjTitle, string tenderNo, string strSelectedCompanies, string user, string tenderBond, string documentFee, string tenderIssueDate, char chCheckShortList, string strEligibleTenderTypes,char chFirstRun, string typeOfTender,Int16 noOfExt)
        {
            InitializeComponent();             
            _prjID = projID;
            txtProjectCode.Text = prjCode;
            txtTenderTitle.Text = prjTitle;
            txtTenderNo.Text = tenderNo;
            userRightsColl = userRightsCollPrjState;
            selectedCompany = strSelectedCompanies;
            _userName = user;
            _tenderBond = tenderBond;
            _documentFee = documentFee;
            //Modified By Varun on 16th Feb 2014 replace prAdvDate by tenderIssueDate based on Riyas request
            _tenderIssueDate = tenderIssueDate;
            _strEligibleTenderTypes = strEligibleTenderTypes;            
            getTenderCloseInfo();             
            clsForTS = new clsTs_Stage(_userName);
            _circularCnt = clsForTS.GetCircularCount(projID);
            comCls = new CommonClass(_userName);
            mTypeOfTender = comCls.GetTypeOfTender(typeOfTender);
            if (_circularCnt != 0)
            {
                _chCheckCircular = 'C';
                DAL dalObj = new DAL();
                DataTable dtNoOfCirculars = dalObj.GetDataFromDB("NoOfCirculars","select CircularNo from Documents where proj_id = " + _prjID + " and doc_type_id=2 and stage_id = 2 and doc_category_id=1").DefaultView.ToTable(true, "CircularNo");
                int rowCounter =0;
                while (rowCounter < dtNoOfCirculars.Rows.Count)
                {
                    cmbCircularNo.Items.Add(dtNoOfCirculars.Rows[rowCounter][0].ToString());
                    rowCounter++;
                }
                //dalObj.populateCircularCmbBox(, cmbCircularNo);
                cmbCircularNo.Visible = true;
                btnEmailCirculars.Visible = true;
            }
            else
                _chCheckCircular = 'O';

            _chCheckShortList = chCheckShortList;
            _chFirstRun = chFirstRun;
            if (chCheckShortList == 'V')
            {                
                CreateBiddersData(_chCheckCircular, chCheckShortList);
                if (userRightsColl.Count != 0)
                {
                    btnDeleteFromShortList.Visible = false;
                }
                if (_chCheckCircular == 'O')
                {                    
                    cmbCircularNo.Visible = false;
                    lblCircularNo.Visible = false;
                    dgViewCircularInfo.Visible = false;                   
                }
            }
            else if (chCheckShortList == 'S')
            {
                cmbCircularNo.Visible = false;
                lblCircularNo.Visible = false;
                if (userRightsColl.Count != 0)
                {
                    if (userRightsColl.Contains("43"))
                    {
                        btnEmailCirculars.Visible = false;
                    }
                    btnDeleteBidder.Visible = false;
                    btnExportToPdf.Visible = false;
                }
                CreateBiddersData(_chCheckCircular, chCheckShortList);                                                
            }          
            else if(chCheckShortList == '3')
            {
                //btnBidEdit.Visible = false;
                if (userRightsColl.Count != 0)
                {
                    btnDeleteBidder.Visible = false;
                    btnExportToPdf.Visible = false;
                    btnDeleteFromShortList.Text = "Delete From Bidders List";
                }
                CreateBiddersData(_chCheckCircular, chCheckShortList);                                                               
            }          
            
        }

        CommonClass comCls = null;
        private void dgViewBidders_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = e.RowIndex;
            int colIndex = e.ColumnIndex;
            if (rowIndex != -1)
            {
                try
                {
                   
                    if (dgViewBidders.ColumnCount == 18)
                    {
                        if (colIndex == 9)
                        {
                            comCls = new CommonClass(_userName);
                            //modified by Varun
                            comCls.CreateOutlookEmail(dgViewBidders.Rows[rowIndex].Cells[9].Value.ToString(), null,txtTenderNo.Text);
                        }
                        else if (colIndex == 10)
                        {
                            if (userRightsColl.Contains("42"))
                            {
                                MessageBox.Show("You have no privilege,Contact administrator");
                                return;
                            }

                            int docId = Convert.ToInt16(dgViewBidders.Rows[rowIndex].Cells[15].Value);
                            int circularNo = Convert.ToInt16(dgViewBidders.Rows[rowIndex].Cells[16].Value);
                            int dateId = Convert.ToInt16(dgViewBidders.Rows[rowIndex].Cells[14].Value);
                            int projId = Convert.ToInt16(dgViewBidders.Rows[rowIndex].Cells[17].Value);

                            if (Convert.ToBoolean(((DataGridViewCheckBoxCell)(dgViewBidders.Rows[rowIndex].Cells[10])).EditingCellFormattedValue) == true)
                            {
                                using (SqlConnection sqlConn = new SqlConnection(strCon))
                                {
                                    clsDatabase clsObj = new clsDatabase(_userName);
                                    DateTime? docIssueDate = null;
                                    if (dgViewBidders.Rows[rowIndex].Cells[11].Value != DBNull.Value)
                                    {
                                        docIssueDate = Convert.ToDateTime(dgViewBidders.Rows[rowIndex].Cells[11].Value);
                                        clsObj.ExecuteNonQuery("update documents set CircularIssued=1, doc_issue_date='" + docIssueDate + "' where doc_id=" + docId + " and CircularNo =" + circularNo + " AND (stage_id = 2) AND (doc_type_id = 2) and (proj_id = " + _prjID + ")", sqlConn); //" and proj_id=" + projId + "                                  
                                    }
                                    else
                                    {
                                        clsObj.ExecuteNonQuery("update documents set CircularIssued=1, doc_issue_date='" + System.DateTime.Now + "' where doc_id=" + docId + " and CircularNo =" + circularNo + " AND (stage_id = 2) AND (doc_type_id = 2) and (proj_id = " + _prjID + ")", sqlConn); //" and proj_id=" + projId +                                        
                                    }

                                    //comCls = new CommonClass(_userName);
                                    //if (dgViewBidders.Rows[rowIndex].Cells[1].Value == "")
                                    //{
                                    //    int iSNo = comCls.GetMaxInfo("SELECT MAX(sn) FROM TenderDatesInfo WHERE proj_id=" + projId, 'Y');
                                    //    clsObj.ExecuteNonQuery("update TenderDatesInfo set sn=" + iSNo + " where date_id=" + dateId + " and proj_id=" + projId + " AND (stage_id = 2)", sqlConn); //" and proj_id=" + projId + "                                                                      
                                    //}

                                }
                            }
                            else if (Convert.ToBoolean(((DataGridViewCheckBoxCell)(dgViewBidders.Rows[rowIndex].Cells[10])).EditingCellFormattedValue) == false)
                            {
                                using (SqlConnection sqlConn = new SqlConnection(strCon))
                                {

                                    clsDatabase clsObj = new clsDatabase(_userName);
                                    int exeResult = clsObj.ExecuteNonQuery("update documents set CircularIssued=0,doc_issue_date=Null where doc_id=" + docId + " and CircularNo =" + circularNo + " AND (stage_id = 2) AND (doc_type_id = 2) and (proj_id = " + _prjID + ")", sqlConn); //+ " and proj_id=" + projId + " AND (stage_id = 2) AND (doc_type_id = 2)"                                                                                                              
                                    //comCls.ReNumberSNCol(projId, strCon);

                                }
                            }
                            // By Varun Based Faisal request not to refresh the gridview when CollectionFile is checked or unchecked
                            //comCls = new CommonClass(_userName);
                            //BindingSource bindSource = (BindingSource)dgViewBidders.DataSource;
                            //DataTable dtViewBidders = (DataTable)bindSource.DataSource;
                            //comCls.LoadCircularOrNonCircularData(2, 'Y', dgViewBidders, _prjID, cmbCircularNo, lblCircularNo, dtViewBidders, 'N', _chCheckShortList);
                        }
                        else if (colIndex == 12)
                        {
                            if (userRightsColl.Contains("42"))
                            {
                                MessageBox.Show("You have no privilege,Contact administrator");
                                return;
                            }

                            int docId = Convert.ToInt16(dgViewBidders.Rows[rowIndex].Cells[15].Value);
                            int circularNo = Convert.ToInt16(dgViewBidders.Rows[rowIndex].Cells[16].Value);                             

                            if (Convert.ToBoolean(((DataGridViewCheckBoxCell)(dgViewBidders.Rows[rowIndex].Cells[12])).EditingCellFormattedValue) == true)
                            {
                                using (SqlConnection sqlConn = new SqlConnection(strCon))
                                {
                                    clsDatabase clsObj = new clsDatabase(_userName);
                                    clsObj.ExecuteNonQuery("update documents set CollectionFile=1 where doc_id=" + docId + " and CircularNo =" + circularNo + " AND (stage_id = 2) AND (doc_type_id = 2) and (proj_id = " + _prjID + ")", sqlConn); //" and proj_id=" + projId + "                                                                      
                                }
                            }
                            else if (Convert.ToBoolean(((DataGridViewCheckBoxCell)(dgViewBidders.Rows[rowIndex].Cells[12])).EditingCellFormattedValue) == false)
                            {
                                using (SqlConnection sqlConn = new SqlConnection(strCon))
                                {
                                    clsDatabase clsObj = new clsDatabase(_userName);
                                    int exeResult = clsObj.ExecuteNonQuery("update documents set CollectionFile=0 where doc_id=" + docId + " and CircularNo =" + circularNo + " AND (stage_id = 2) AND (doc_type_id = 2) and (proj_id = " + _prjID + ")", sqlConn); //+ " and proj_id=" + projId + " AND (stage_id = 2) AND (doc_type_id = 2)"                                                                                                                                                   
                                }
                            }
                            // By Varun on Jan 29 14 Based Faisal request not to refresh the gridview when CollectionFile is checked or unchecked
                            //comCls = new CommonClass(_userName);
                            //BindingSource bindSource = (BindingSource)dgViewBidders.DataSource;
                            //DataTable dtViewBidders = (DataTable)bindSource.DataSource;
                            //comCls.LoadCircularOrNonCircularData(2, 'Y', dgViewBidders, _prjID, cmbCircularNo, lblCircularNo, dtViewBidders, 'C', _chCheckShortList);
                        }
                    }
                    else if (colIndex == 7 && (_chCheckShortList == 'S' || _chCheckShortList == '3') && dgViewBidders.Rows[rowIndex].Cells[7].ReadOnly==false)
                    {
                        int dateId = Convert.ToInt16(dgViewBidders.Rows[rowIndex].Cells[11].Value);
                        int projId = Convert.ToInt16(dgViewBidders.Rows[rowIndex].Cells[12].Value);

                        if (Convert.ToBoolean(((DataGridViewCheckBoxCell)(dgViewBidders.Rows[rowIndex].Cells[7])).EditingCellFormattedValue) == true)
                        {
                            using (SqlConnection sqlConn = new SqlConnection(strCon))
                            {

                                clsDatabase clsObj = new clsDatabase(_userName);
                                DateTime? docIssueDate = null;
                                comCls = new CommonClass(_userName);
                                int iSNo = 0;
                                //if (dgViewBidders.Rows[rowIndex].Cells[1].Value.ToString() == "")
                                iSNo = comCls.GetMaxInfo("SELECT MAX(sn) FROM TenderDatesInfo WHERE proj_id=" + projId, 'Y');

                                if (dgViewBidders.Rows[rowIndex].Cells[8].Value != DBNull.Value)
                                {
                                    docIssueDate = Convert.ToDateTime(dgViewBidders.Rows[rowIndex].Cells[8].Value);
                                    if (iSNo != 0)
                                        clsObj.ExecuteNonQuery("update TenderDatesInfo set Tender_Issued = 1, ts_tender_issue='" + docIssueDate + "',sn=" + iSNo + " where date_id=" + dateId + " and proj_Id =" + projId + " AND (stage_id = 2)", sqlConn);
                                    else
                                        clsObj.ExecuteNonQuery("update TenderDatesInfo set Tender_Issued=1, ts_tender_issue='" + docIssueDate + "' where date_id=" + dateId + " and proj_Id =" + projId + " AND (stage_id = 2)", sqlConn); //" and proj_id=" + projId + "                                  
                                }
                                else
                                {
                                    if (iSNo != 0)
                                        clsObj.ExecuteNonQuery("update TenderDatesInfo set Tender_Issued=1, ts_tender_issue='" + System.DateTime.Now + "',sn=" + iSNo + " where date_id=" + dateId + " and proj_Id =" + projId + " AND (stage_id = 2)", sqlConn); //" and proj_id=" + projId +
                                    else
                                        clsObj.ExecuteNonQuery("update TenderDatesInfo set Tender_Issued=1, ts_tender_issue='" + System.DateTime.Now + "' where date_id=" + dateId + " and proj_Id =" + projId + " AND (stage_id = 2)", sqlConn); //" and proj_id=" + projId +
                                }
                                clsObj.ExecuteNonQuery("update TenderDatesInfo set Company_EmailID='" + dgViewBidders.Rows[rowIndex].Cells[6].Value + "' where date_id=" + dateId, sqlConn); //" and proj_id=" + projId +

                                //sqlConn = new SqlConnection(
                                sqlConn.Open();
                                if (clsObj.ExecuteReader("SELECT doc_id FROM DOCUMENTS WHERE (proj_id = " + projId + " ) and (stage_id = 2) AND (date_id IS NULL) AND (CircularNo IS NOT NULL)", sqlConn)) 
                                {
                                    using (SqlCommand cmd = new SqlCommand())
                                    {
                                        //sqlConn.Open();
                                        cmd.Connection = sqlConn;
                                        //cmd.CommandText = "select Contacts.co_id,Contacts.employee_id from Contacts join COMPANY on COMPANY.co_id = Contacts.co_id where COMPANY.co_name='" + dgViewBidders.Rows[rowIndex].Cells[2].Value.ToString() + "'";
                                        cmd.CommandText = "SELECT tdf.co_id, tdf.employee_id" +
                                        " FROM TenderDatesInfo AS tdf INNER JOIN " +
                                        "COMPANY AS cmp ON cmp.co_id = tdf.co_id INNER JOIN " +
                                        "Contacts AS cts ON tdf.employee_id = cts.employee_id " +
                                        "WHERE tdf.date_id =" + dateId;
                                        sqlDtReader = cmd.ExecuteReader();
                                        sqlDtReader.Read();
                                        Int16 coID = 0;
                                        Int16 empID = 0;
                                        coID = Convert.ToInt16(sqlDtReader[0]);
                                        empID = Convert.ToInt16(sqlDtReader[1]);
                                        sqlDtReader.Close();
                                        if (coID != 0 && empID != 0)
                                        {
                                            comCls = new CommonClass(_userName);
                                            comCls.InsertRecordsInDocumentsTable(projId, cmd, dateId, sqlConn, comCls, coID, empID);
                                        }
                                        cmd.Dispose();
                                    }
                                    sqlConn.Close();
                                }
                                sqlConn.Close();
                            }
                        }
                        else if (Convert.ToBoolean(((DataGridViewCheckBoxCell)(dgViewBidders.Rows[rowIndex].Cells[7])).EditingCellFormattedValue) == false)
                        {
                            using (SqlConnection sqlConn = new SqlConnection(strCon))
                            {
                                clsDatabase clsObj = new clsDatabase(_userName);
                                int exeResult = clsObj.ExecuteNonQuery("update TenderDatesInfo set Tender_Issued=0,ts_tender_issue=Null,sn=null where date_id=" + dateId + " and proj_Id =" + projId + " AND (stage_id = 2)", sqlConn); //+ " and proj_id=" + projId + " AND (stage_id = 2) AND (doc_type_id = 2)"
                                comCls = new CommonClass(_userName);
                                comCls.ReNumberSNCol(projId, strCon, _chCheckShortList);
                                exeResult = clsObj.ExecuteNonQuery("delete from DOCUMENTS where date_id=" + dateId + " and proj_Id =" + projId + " AND (stage_id = 2)", sqlConn); //+ " and proj_id=" + projId + " AND (stage_id = 2) AND (doc_type_id = 2)"                                                         
                                clsObj.ExecuteNonQuery("update TenderDatesInfo set Company_EmailID='' where date_id=" + dateId, sqlConn); //" and proj_id=" + projId +
                            }
                        }
                        // By Varun on Jan 29 14 Based Faisal request not to refresh the gridview when CollectionFile is checked or unchecked
                        //comCls = new CommonClass(_userName);
                        //BindingSource bindSource = (BindingSource)dgViewBidders.DataSource;
                        //DataTable dtViewBidders = (DataTable)bindSource.DataSource;
                        //if(_chCheckShortList == 'S')
                        //    comCls.LoadCircularOrNonCircularData(3, 'N', dgViewBidders, projId, cmbCircularNo, lblCircularNo, dtViewBidders, 'N', _chCheckShortList);
                        //else if (_chCheckShortList == '3' && _chCheckCircular=='C')
                        //    comCls.LoadCircularOrNonCircularData(2, 'N', dgViewBidders, projId, cmbCircularNo, lblCircularNo, dtViewBidders, 'N', _chCheckShortList);
                        //else if (_chCheckShortList == '3' && _chCheckCircular == 'O')
                        //    comCls.LoadCircularOrNonCircularData(1, 'N', dgViewBidders, projId, cmbCircularNo, lblCircularNo, dtViewBidders, 'N', _chCheckShortList);                                                 

                    }
                    else if (dgViewBidders.ColumnCount == 13 && colIndex == 6)
                    {                       
                         comCls = new CommonClass(_userName);
                         //modified by Varun
                         comCls.CreateOutlookEmail(dgViewBidders.Rows[rowIndex].Cells[6].Value.ToString(), null,txtTenderNo.Text);                      
                    }
                    else if (dgViewBidders.ColumnCount == 13 && colIndex == 9) //&& _chCheckShortList=='3' && _chCheckCircular=='O'
                    {                        
                         comCls = new CommonClass(_userName);
                         //modified by Varun
                         comCls.CreateOutlookEmail(dgViewBidders.Rows[rowIndex].Cells[9].Value.ToString(), null,txtTenderNo.Text);                       
                    }
                    else if (dgViewBidders.ColumnCount == 13 && e.ColumnIndex == 2)
                    {
                        try
                        {
                            
                            frmIssueTenderInfo frmEditProject = null;
                            char chCheckShortList = 'N';


                            if ((_chCheckShortList == '3' || _chCheckShortList == 'S') && dgViewBidders.Rows[rowIndex].Cells[1].Value.ToString() == "")
                            {
                                frmEditProject = new frmIssueTenderInfo(userRightsColl, dgViewBidders.Rows[rowIndex].Cells[11].Value + "," + dgViewBidders.Rows[rowIndex].Cells[12].Value, txtTenderNo.Text, txtTenderTitle.Text, true, selectedCompany, _userName, 'Y', _chCheckShortList, null, null);
                                chCheckShortList = 'Y';
                            }
                            else if ((_chCheckShortList == '3' || _chCheckShortList == 'S') && dgViewBidders.Rows[rowIndex].Cells[1].Value.ToString() != "")
                            {
                                frmEditProject = new frmIssueTenderInfo(userRightsColl, dgViewBidders.Rows[rowIndex].Cells[11].Value + "," + dgViewBidders.Rows[rowIndex].Cells[12].Value, txtTenderNo.Text, txtTenderTitle.Text, true, selectedCompany, _userName, 'Y', _chCheckShortList, null, null);
                                chCheckShortList = 'Y';
                            }
                            else if (dgViewBidders.Rows[rowIndex].Cells[1].Value.ToString() == "")
                            {
                                frmEditProject = new frmIssueTenderInfo(userRightsColl, dgViewBidders.Rows[rowIndex].Cells[11].Value + "," + dgViewBidders.Rows[rowIndex].Cells[12].Value, txtTenderNo.Text, txtTenderTitle.Text, true, selectedCompany, _userName, 'N', _chCheckShortList, null, null);
                                chCheckShortList = 'N';
                            }
                            else if (dgViewBidders.Rows[rowIndex].Cells[1].Value.ToString() != "")
                            {
                                frmEditProject = new frmIssueTenderInfo(userRightsColl, dgViewBidders.Rows[rowIndex].Cells[11].Value + "," + dgViewBidders.Rows[rowIndex].Cells[12].Value, txtTenderNo.Text, txtTenderTitle.Text, true, selectedCompany, _userName, 'N', _chCheckShortList, null, null);
                                chCheckShortList = 'N';
                            }

                            frmEditProject.StartPosition = FormStartPosition.CenterParent;
                            frmEditProject.ShowDialog();
                            CommonClass comCls = new CommonClass(_userName);
                            BindingSource bindSource = (BindingSource)dgViewBidders.DataSource;
                            DataTable dtViewBidders = (DataTable)bindSource.DataSource;
                            if (CommonClass.isSaved == 'Y')
                            {
                                if(chCheckShortList == 'N')
                                    comCls.LoadCircularOrNonCircularData(1, 'N', dgViewBidders, _prjID, cmbCircularNo, lblCircularNo, dtViewBidders, 'N','V');
                                else if(_chCheckShortList == '3' && _chCheckCircular=='C')
                                    comCls.LoadCircularOrNonCircularData(2, 'N', dgViewBidders, _prjID, cmbCircularNo, lblCircularNo, dtViewBidders, 'N', _chCheckShortList);
                                else if (_chCheckShortList == '3' && _chCheckCircular == 'O')
                                    comCls.LoadCircularOrNonCircularData(1, 'N', dgViewBidders, _prjID, cmbCircularNo, lblCircularNo, dtViewBidders, 'N', _chCheckShortList);
                                else if (_chCheckShortList == 'S')
                                    comCls.LoadCircularOrNonCircularData(3, 'N', dgViewBidders, _prjID, cmbCircularNo, lblCircularNo, dtViewBidders, 'N', _chCheckShortList);                                 
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while Updating the records", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }                 
            }
        }

        // Varun
        CreateCheckBox chkBox1 = null;
        CreateCheckBox chkBox2 = null;
        CreateCheckBox chkBox3 = null;
        CheckBox headerCheckBox1 = null;
        CheckBox headerCheckBox2 = null;
        CheckBox headerCheckBox3 = null;
        DataTable finalDt = null;
        private void CreateBiddersData(char chCheckCircular, char chCheckShortList)
        {
            headerCheckBox1 = new CheckBox();
            chkBox1 = new CreateCheckBox(dgViewBidders, headerCheckBox1);
            chkBox1.AddHeaderCheckBox();
            CalendarColumn dateCol = null;
            DataGridViewCheckBoxColumn col0 = new DataGridViewCheckBoxColumn();
            if (chCheckCircular == 'C' && chCheckShortList!='S')
            {
                headerCheckBox2 = new CheckBox();
                chkBox2 = new CreateCheckBox(dgViewBidders, headerCheckBox2, 'S');

                headerCheckBox3 = new CheckBox();
                chkBox3 = new CreateCheckBox(dgViewBidders, headerCheckBox3, 'S');
                //chkBox2.AddHeaderCheckBox2();                                
            }

            var col1 = default(DataGridViewTextBoxColumn);
            var col2 = default(DataGridViewTextBoxColumn);
            var col3 = default(DataGridViewTextBoxColumn);
            var col4 = default(DataGridViewTextBoxColumn);
            var col5 = default(DataGridViewTextBoxColumn);
            var col6 = default(DataGridViewTextBoxColumn);
            var col7 = default(DataGridViewTextBoxColumn);
            var col8 = default(DataGridViewTextBoxColumn);
            var col9 = default(DataGridViewLinkColumn);
            var col10 = default(DataGridViewCheckBoxColumn);
            var col11 = default(DataGridViewTextBoxColumn);
            var col12 = default(DataGridViewTextBoxColumn);
            var col13 = default(DataGridViewTextBoxColumn);
            var col14 = default(DataGridViewTextBoxColumn);
            var col15 = default(DataGridViewTextBoxColumn);
            var col16 = default(DataGridViewCheckBoxColumn);
            var col17 = default(DataGridViewTextBoxColumn);
            var col18 = default(DataGridViewTextBoxColumn);
            var col19 = default(DataGridViewLinkColumn);
            var col20 = default(DataGridViewCheckBoxColumn);

            if (chCheckCircular == 'C' && (chCheckShortList == 'V'| chCheckShortList == '3'))
            {
                col1 = new DataGridViewTextBoxColumn();
                col2 = new DataGridViewTextBoxColumn();
                col3 = new DataGridViewTextBoxColumn();
                col4 = new DataGridViewTextBoxColumn();
                col5 = new DataGridViewTextBoxColumn();
                col6 = new DataGridViewTextBoxColumn();
                col7 = new DataGridViewTextBoxColumn();
                col8 = new DataGridViewTextBoxColumn();
                col9 = new DataGridViewLinkColumn();
                col10 = new DataGridViewCheckBoxColumn();                
                col11 = new DataGridViewTextBoxColumn();
                col20 = new DataGridViewCheckBoxColumn();
                col12 = new DataGridViewTextBoxColumn();
                col13 = new DataGridViewTextBoxColumn();
                col14 = new DataGridViewTextBoxColumn();
                col15 = new DataGridViewTextBoxColumn();
                dateCol = new CalendarColumn();
                dgViewBidders.Columns.AddRange(new DataGridViewColumn[] { col0, col1, col2, col3, col4, col5, col6, col7, col8, col9, col10, dateCol, col20, col11, col12, col13, col14, col15 });
            }

            else if (chCheckCircular == 'O' && (chCheckShortList == 'V' | chCheckShortList == '3'))
            {
                col1 = new DataGridViewTextBoxColumn();
                col2 = new DataGridViewTextBoxColumn();
                col3 = new DataGridViewTextBoxColumn();
                col4 = new DataGridViewTextBoxColumn();
                col5 = new DataGridViewTextBoxColumn();
                col6 = new DataGridViewTextBoxColumn();
                col7 = new DataGridViewTextBoxColumn();
                col8 = new DataGridViewTextBoxColumn();
                col9 = new DataGridViewLinkColumn();
                col11 = new DataGridViewTextBoxColumn();
                col12 = new DataGridViewTextBoxColumn();
                col13 = new DataGridViewTextBoxColumn();
                dgViewBidders.Columns.AddRange(new DataGridViewColumn[] { col0, col1, col2, col3, col4, col5, col6, col7, col8, col9, col11, col12, col13 });
            }
            else if (chCheckShortList == 'S')
            {
                col1 = new DataGridViewTextBoxColumn();
                col19 = new DataGridViewLinkColumn();
                col3 = new DataGridViewTextBoxColumn();
                col7 = new DataGridViewTextBoxColumn();
                col8 = new DataGridViewTextBoxColumn();
                col9 = new DataGridViewLinkColumn();
                col16 = new DataGridViewCheckBoxColumn();
                dateCol = new CalendarColumn();
                col17 = new DataGridViewTextBoxColumn();
                col18 = new DataGridViewTextBoxColumn();
                col12 = new DataGridViewTextBoxColumn();
                col13 = new DataGridViewTextBoxColumn();                 
                dgViewBidders.Columns.AddRange(new DataGridViewColumn[] { col0, col1, col19, col3, col7, col8, col9, col16, dateCol, col17, col18, col12, col13});
            }

            dgViewBidders.AutoGenerateColumns = false;
            dgViewBidders.AllowUserToAddRows = false;
            dgViewBidders.AutoResizeColumns();

            col0.Name = "chkBxSelect1";
            col0.DataPropertyName = "Select";
            col0.HeaderText = "";
            col0.Width = 20;

            col1.Name = "SN";
            col1.DataPropertyName = "SN";
            col1.Width = 20;
            col1.HeaderText = "SN";

            if ((chCheckCircular == 'C' || chCheckCircular == 'O') && (chCheckShortList == 'V' | chCheckShortList == '3'))
            {
                col2.DataPropertyName = "CompanyName";
                col2.HeaderText = "Company Name";
                col2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
                col2.ReadOnly = true;
            }
            else
            {
                col19.DataPropertyName = "CompanyName";
                col19.HeaderText = "Company Name";
                col19.Resizable = System.Windows.Forms.DataGridViewTriState.True;
                col19.ReadOnly = true;
                //col1.Width = 30;              
            }

            col3.DataPropertyName = "Nationality";
            col3.HeaderText = "Nationality";
            col3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            col3.ReadOnly = true;
            //col3.Width = 15;

            if ((chCheckCircular == 'C' || chCheckCircular == 'O') && (chCheckShortList == 'V' | chCheckShortList == '3'))
            {
                col4.DataPropertyName = "DateOfIssue";
                col4.HeaderText = "Issued Date";
                col4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
                col4.ReadOnly = true;

                col5.DataPropertyName = "ReceiptNo";
                col5.HeaderText = "Receipt No.";
                col5.Resizable = System.Windows.Forms.DataGridViewTriState.True;                

                col6.DataPropertyName = "FaxNo";
                col6.HeaderText = "Fax No.";
                col6.Resizable = System.Windows.Forms.DataGridViewTriState.True;
                col6.ReadOnly = true;
            }

            //if (chCheckCircular == 'C' || chCheckCircular == 'O' || chCheckShortList == 'S')
            //{
                col7.DataPropertyName = "TelNo";
                col7.HeaderText = "Tel. No.";
                col7.Resizable = System.Windows.Forms.DataGridViewTriState.True;
                col7.ReadOnly = true;

                col8.DataPropertyName = "MobileNo";
                col8.HeaderText = "Mobile No";
                col8.Resizable = System.Windows.Forms.DataGridViewTriState.True;
                col8.ReadOnly = true;

                col9.DataPropertyName = "EmailAddress";
                col9.HeaderText = "Email Address";
                col9.Resizable = System.Windows.Forms.DataGridViewTriState.True;
                col9.ReadOnly = true;
            //}

            if (chCheckCircular == 'C' && (chCheckShortList == 'V' | chCheckShortList == '3'))
            {
                col10.Name = "chkBxSelect2";
                col10.DataPropertyName = "CircularIssued";
                col10.HeaderText = "Circular Issued";
                col10.Width = 45;

                dateCol.DataPropertyName = "DocIssueDate";
                dateCol.HeaderText = "Circular Issue Date";
                //dateCol.Width = 40;

                col20.Name = "chkBxSelect3";
                col20.DataPropertyName = "CollectionFile";
                col20.HeaderText = "Collection File";
                col20.Width = 45;

            }
            if (chCheckShortList == 'S')
            {
                col16.Name = "chkBxSelect2";
                col16.DataPropertyName = "TenderIssued";
                col16.HeaderText = "Tender Issued";
                col16.Width = 45;

                dateCol.DataPropertyName = "TenderIssuedDate";
                dateCol.HeaderText = "Date of Issue";

                col17.DataPropertyName = "ReceiptNo";
                col17.HeaderText = "Receipt No.";
                col17.Resizable = System.Windows.Forms.DataGridViewTriState.True;

                col18.DataPropertyName = "Remarks";
                col18.HeaderText = "Remarks";
                col18.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            }

            if ((chCheckCircular == 'O' || chCheckCircular == 'C') && (chCheckShortList == 'V' | chCheckShortList == '3'))
            {
                col11.DataPropertyName = "Remarks";
                col11.HeaderText = "Remarks";
                col11.Resizable = System.Windows.Forms.DataGridViewTriState.True;
                // col6.Width = 30;
            }

            if (chCheckCircular == 'O' | chCheckShortList == 'S' | chCheckShortList == '3')
            {
                col12.DataPropertyName = "BidDateID";
                col12.HeaderText = "BidDateID";
                col12.ReadOnly = true;

                col13.DataPropertyName = "ProjId";
                col13.HeaderText = "ProjId";
                col13.ReadOnly = true;
            }

            if (chCheckCircular == 'C' && (chCheckShortList == 'V' | chCheckShortList == '3'))
            {
                col12.DataPropertyName = "BidDateID";
                col12.HeaderText = "BidDateID";
                col12.ReadOnly = true;

                col13.DataPropertyName = "DocId";
                col13.HeaderText = "DocId";
                col13.ReadOnly = true;

                col14.DataPropertyName = "CircularNo";
                col14.HeaderText = "CircularNo";
                col14.ReadOnly = true;

                col15.DataPropertyName = "ProjId";
                col15.HeaderText = "ProjId";
                col15.ReadOnly = true;

            }
            CommonClass comCls = new CommonClass(_userName);
            if (finalDt == null)
            {
                finalDt = new DataTable("BiddersInfo");
                
                finalDt.Columns.Add("");
                finalDt.Columns.Add("SN");
                finalDt.Columns.Add("CompanyName");
                finalDt.Columns.Add("Nationality");
            
                if ((chCheckCircular == 'C' || chCheckCircular == 'O') && (chCheckShortList == 'V' | chCheckShortList == '3'))
                {
                    finalDt.Columns.Add("DateOfIssue");
                    finalDt.Columns.Add("ReceiptNo");
                    finalDt.Columns.Add("FaxNo");
                }
                
                finalDt.Columns.Add("TelNo");
                finalDt.Columns.Add("MobileNo");
                finalDt.Columns.Add("EmailAddress");
                 
                if (chCheckShortList == 'S')
                {
                    finalDt.Columns.Add("TenderIssued");
                    finalDt.Columns.Add("TenderIssuedDate");
                    finalDt.Columns.Add("ReceiptNo");
                }
                if (chCheckCircular == 'C' && (chCheckShortList == 'V' | chCheckShortList == '3'))
                {
                    finalDt.Columns.Add("CircularIssued");
                    finalDt.Columns.Add("DocIssueDate");
                    finalDt.Columns.Add("CollectionFile");
                }
                 
                finalDt.Columns.Add("Remarks");
                finalDt.Columns.Add("BidDateID");

                if (chCheckCircular == 'C' && (chCheckShortList == 'V' | chCheckShortList == '3'))
                {
                    finalDt.Columns.Add("DocId");
                    finalDt.Columns.Add("CircularNo");
                }
                //if (chCheckCircular == 'C' || chCheckCircular == 'O' || chCheckShortList == 'S')
                    finalDt.Columns.Add("ProjId");
                 
            }
            finalDt.AcceptChanges();
            if (chCheckCircular == 'C' && chCheckShortList == 'V')
                comCls.LoadCircularOrNonCircularData(2, 'N', dgViewBidders, _prjID, cmbCircularNo, lblCircularNo, finalDt,_chFirstRun,'V');
            else if (chCheckCircular == 'O' && chCheckShortList == 'V')
                comCls.LoadCircularOrNonCircularData(1, 'N', dgViewBidders, _prjID, cmbCircularNo, lblCircularNo, finalDt, _chFirstRun,'V');
            else if (chCheckShortList == 'S')
                comCls.LoadCircularOrNonCircularData(3, 'N', dgViewBidders, _prjID, cmbCircularNo, lblCircularNo, finalDt, _chFirstRun,chCheckShortList);
            else if (chCheckShortList == '3' && chCheckCircular=='C')
                comCls.LoadCircularOrNonCircularData(2, 'N', dgViewBidders, _prjID, cmbCircularNo, lblCircularNo, finalDt, _chFirstRun, chCheckShortList);
            else if (chCheckShortList == '3' && chCheckCircular == 'O')
                comCls.LoadCircularOrNonCircularData(1, 'N', dgViewBidders, _prjID, cmbCircularNo, lblCircularNo, finalDt, _chFirstRun, chCheckShortList);

            headerCheckBox1.KeyUp += new KeyEventHandler(chkBox1.HeaderCheckBox_KeyUp);
            headerCheckBox1.MouseClick += new MouseEventHandler(chkBox1.HeaderCheckBox_MouseClick);

            if (chCheckCircular == 'C' || chCheckShortList == 'S')
            {
                CalendarEditingControl calEditCtrl = new CalendarEditingControl();
                calEditCtrl.DGControl = dgViewBidders;                 
                calEditCtrl.CmbCtrl = cmbCircularNo;
                calEditCtrl.CheckShortList = chCheckShortList;
                calEditCtrl.CheckIsCircular = chCheckCircular;
            }
            //dgViewBidders.CellValueChanged += new DataGridViewCellEventHandler(chkBox1.dgvSelectAll_CellValueChanged);
            dgViewBidders.CurrentCellDirtyStateChanged += new EventHandler(chkBox1.dgvSelectAll_CurrentCellDirtyStateChanged);
            dgViewBidders.CellPainting += new DataGridViewCellPaintingEventHandler(chkBox1.dgvSelectAll_CellPainting);
            dgViewBidders.CellFormatting += dgViewBidders_CellFormatting;
            
            dgViewBidders.EditingControlShowing += new DataGridViewEditingControlShowingEventHandler(
            dgViewBidders_EditingIssueTenderSNColumn);

            dgViewBidders.EditingControlShowing += new DataGridViewEditingControlShowingEventHandler(
                dgViewBidders_EditingShortListReceiptColumn);

            dgViewBidders.EditingControlShowing += new DataGridViewEditingControlShowingEventHandler(
                    dgViewBidders_EditingShortListRemarksColumn);

            dgViewBidders.EditingControlShowing += new DataGridViewEditingControlShowingEventHandler(
                    dgViewBidders_EditingIssueTenderRemarksColumn);

            if (chCheckCircular == 'C' && (chCheckShortList == 'V' | chCheckShortList == '3') && cmbCircularNo.Items.Count!=0)
            {
                var col0CirInfo = new DataGridViewTextBoxColumn();
                var col1CirInfo = new DataGridViewTextBoxColumn();
                var col2CirInfo = new DataGridViewTextBoxColumn();
                var col3CirInfo = new DataGridViewCheckBoxColumn();
                var col4CirInfo = new DataGridViewTextBoxColumn();

                dgViewCircularInfo.Columns.AddRange(new DataGridViewColumn[] { col0CirInfo, col1CirInfo, col2CirInfo, col3CirInfo, col4CirInfo });

                dgViewCircularInfo.AutoGenerateColumns = false;
                dgViewCircularInfo.AllowUserToAddRows = false;
                //dgViewCircularInfo.AllowUserToResizeColumns = true;
                dgViewCircularInfo.AutoResizeColumns();

                col0CirInfo.DataPropertyName = "CircularNo";
                col0CirInfo.HeaderText = "CircularNo";
                col0CirInfo.MinimumWidth = 2;
                col0CirInfo.Resizable = System.Windows.Forms.DataGridViewTriState.True;

                col1CirInfo.DataPropertyName = "doc_issue_date";
                col1CirInfo.HeaderText = "Date Of Issue";
                col1CirInfo.MinimumWidth = 5;
                col1CirInfo.Resizable = System.Windows.Forms.DataGridViewTriState.True;

                col2CirInfo.DataPropertyName = "subject";
                col2CirInfo.HeaderText = "Subject";
                col2CirInfo.MinimumWidth = 5;
                col2CirInfo.Resizable = System.Windows.Forms.DataGridViewTriState.True;

                col3CirInfo.DataPropertyName = "CircularIssued";
                col3CirInfo.HeaderText = "Received At Ground Floor";
                col3CirInfo.MinimumWidth = 2;
                col3CirInfo.Resizable = System.Windows.Forms.DataGridViewTriState.True;

                col4CirInfo.DataPropertyName = "Remarks";
                col4CirInfo.HeaderText = "Remarks";
                col4CirInfo.MinimumWidth = 5;
                col4CirInfo.Resizable = System.Windows.Forms.DataGridViewTriState.True;

                dgViewCircularInfo.EditingControlShowing += new DataGridViewEditingControlShowingEventHandler(
                dgViewCircularInfo_EditingControlShowing);
                //circularInfoDt = new DataTable("ProjIDCircularInfo");
                //circularInfoDt.Columns.Add("CircularNo");
                //circularInfoDt.Columns.Add("doc_issue_date");
                //circularInfoDt.Columns.Add("subject");
                //circularInfoDt.Columns.Add("CircularIssued");
                //circularInfoDt.Columns.Add("Remarks");
                //circularInfoDt.AcceptChanges();

                LoadProjIDCircularInfo();

            }

        }        

        static TextBox txSN = null;
        void dgViewBidders_EditingIssueTenderSNColumn(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            if (this.dgViewBidders.CurrentCell.ColumnIndex == 1)
            //the column you want to add event for, I take the first column for example
            {

                txSN = e.Control as TextBox;
                if (txSN != null)
                {
                    txSN.Leave -= new EventHandler(txSN_Leave);
                    txSN.Leave += new EventHandler(txSN_Leave);
                }

            }
        }

        delegate void DelegateUpdateDataGridView();
        void txSN_Leave(object sender, EventArgs e)
        {
            if (this.dgViewBidders.CurrentCell.ColumnIndex == 1)
            //the column you want to add event for, I take the first column for example
            {
                try
                {
                    if (txSN.Text != "")
                    {
                        int iSN = 0;
                        try
                        {
                            iSN = Convert.ToInt32(txSN.Text);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Please enter only integer values in SN column", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }


                        using (SqlConnection sqlConn = new SqlConnection(strCon))
                        {                             
                                clsDatabase clsObj = new clsDatabase(_userName);
                                int executeResult = 0;
                                if (_chCheckCircular == 'C' && (_chCheckShortList=='V' ||_chCheckShortList == '3'))
                                    executeResult = clsObj.ExecuteNonQuery("update TenderDatesInfo set SN=" + iSN + " where proj_id=" + _prjID + " AND (stage_id = 2) and date_id =" + Convert.ToInt16(dgViewBidders.Rows[dgViewBidders.CurrentCell.RowIndex].Cells[14].Value), sqlConn);
                                else
                                    executeResult = clsObj.ExecuteNonQuery("update TenderDatesInfo set SN=" + iSN + " where proj_id=" + _prjID + " AND (stage_id = 2) and date_id =" + Convert.ToInt16(dgViewBidders.Rows[dgViewBidders.CurrentCell.RowIndex].Cells[11].Value), sqlConn);                                
                        }
                        dgViewCircularInfo.BeginInvoke(new DelegateUpdateDataGridView(UpdateViewBiddersGridView));
                    }
                    else
                    {
                        using (SqlConnection sqlConn = new SqlConnection(strCon))
                        {
                            
                                clsDatabase clsObj = new clsDatabase(_userName);
                                int executeResult = 0;
                                if (_chCheckCircular == 'C' && (_chCheckShortList == 'V'||_chCheckShortList == '3'))
                                    executeResult = clsObj.ExecuteNonQuery("update TenderDatesInfo set SN=null where proj_id=" + _prjID + " AND (stage_id = 2) and date_id =" + Convert.ToInt16(dgViewBidders.Rows[dgViewBidders.CurrentCell.RowIndex].Cells[14].Value), sqlConn);
                                else
                                    executeResult = clsObj.ExecuteNonQuery("update TenderDatesInfo set SN=null where proj_id=" + _prjID + " AND (stage_id = 2) and date_id =" + Convert.ToInt16(dgViewBidders.Rows[dgViewBidders.CurrentCell.RowIndex].Cells[11].Value), sqlConn);
                                 
                        }
                        dgViewCircularInfo.BeginInvoke(new DelegateUpdateDataGridView(UpdateViewBiddersGridView));
                    }
                    txSN.Leave -= new EventHandler(txSN_Leave);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while Updating the records", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void UpdateViewBiddersGridView()
        {
            if (comCls==null)
                comCls = new CommonClass(_userName);
            BindingSource bindSource = (BindingSource)dgViewBidders.DataSource;
            DataTable dtViewBidders = (DataTable)bindSource.DataSource;
            if (_chCheckCircular == 'C' && _chCheckShortList == 'V')
                comCls.LoadCircularOrNonCircularData(2, 'N', dgViewBidders, _prjID, cmbCircularNo, lblCircularNo, dtViewBidders, 'N', 'V');
            else if (_chCheckCircular == 'O' && _chCheckShortList == 'V')
                comCls.LoadCircularOrNonCircularData(1, 'N', dgViewBidders, _prjID, null, null, dtViewBidders, 'N', 'V');
            else if (_chCheckShortList == 'S')
                comCls.LoadCircularOrNonCircularData(3, 'N', dgViewBidders, _prjID, null, null, dtViewBidders, 'N', 'S');            
            else if (_chCheckShortList == '3' && _chCheckCircular == 'C')
                comCls.LoadCircularOrNonCircularData(2, 'N', dgViewBidders, _prjID, cmbCircularNo, lblCircularNo, dtViewBidders, 'N', '3');
            else if (_chCheckShortList == '3' && _chCheckCircular == 'O')
                comCls.LoadCircularOrNonCircularData(1, 'N', dgViewBidders, _prjID, cmbCircularNo, lblCircularNo, dtViewBidders, 'N', '3');

        }

        TextBox txReceiptNo = null;
        void dgViewBidders_EditingShortListReceiptColumn(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            //the column you want to add event for
            if (this.dgViewBidders.CurrentCell.ColumnIndex == 9)
            {
                txReceiptNo = e.Control as TextBox;
                if (txReceiptNo != null)
                {
                    txReceiptNo.Leave -= new EventHandler(txShortListReceiptNo_Leave);
                    txReceiptNo.Leave += new EventHandler(txShortListReceiptNo_Leave);
                }
            }
        }

        TextBox txtIssueTenderRemarks = null;
        void dgViewBidders_EditingIssueTenderRemarksColumn(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            //the column you want to add event for
            if (this.dgViewBidders.CurrentCell.ColumnIndex == 13)
            {
                txtIssueTenderRemarks = e.Control as TextBox;
                if (txtIssueTenderRemarks != null)
                {
                    txtIssueTenderRemarks.Leave -= new EventHandler(txtIssueTenderRemarks_Leave);
                    txtIssueTenderRemarks.Leave += new EventHandler(txtIssueTenderRemarks_Leave);
                }
            }
        }

        void txtIssueTenderRemarks_Leave(object sender, EventArgs e)
        {
            //the column you want to add event for
            if (this.dgViewBidders.CurrentCell.ColumnIndex == 13)
            {
                try
                {
                    if (txtIssueTenderRemarks.Text != "")
                    {
                        using (SqlConnection sqlConn = new SqlConnection(strCon))
                        {
                            clsDatabase clsObj = new clsDatabase(_userName);
                            int executeResult = 0;
                            executeResult = clsObj.ExecuteNonQuery("update TenderDatesInfo set remarks='" + txtIssueTenderRemarks.Text + "' where proj_id=" + _prjID + " AND (stage_id = 2) and date_id =" + Convert.ToInt16(dgViewBidders.Rows[dgViewBidders.CurrentCell.RowIndex].Cells[14].Value), sqlConn);
                        }
                        dgViewBidders.BeginInvoke(new DelegateUpdateDataGridView(UpdateViewBiddersGridView));
                    }
                    else
                    {
                        using (SqlConnection sqlConn = new SqlConnection(strCon))
                        {
                            clsDatabase clsObj = new clsDatabase(_userName);
                            int executeResult = 0;
                            executeResult = clsObj.ExecuteNonQuery("update TenderDatesInfo set remarks=NULL where proj_id=" + _prjID + " AND (stage_id = 2) and date_id =" + Convert.ToInt16(dgViewBidders.Rows[dgViewBidders.CurrentCell.RowIndex].Cells[14].Value), sqlConn);
                        }
                        dgViewBidders.BeginInvoke(new DelegateUpdateDataGridView(UpdateViewBiddersGridView));
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while Updating the record", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        void txShortListReceiptNo_Leave(object sender, EventArgs e)
        {
            //the column you want to add event for
            if (this.dgViewBidders.CurrentCell.ColumnIndex == 9)
            {
                try
                {
                    if (txReceiptNo.Text != "")
                    {
                        using (SqlConnection sqlConn = new SqlConnection(strCon))
                        {                         
                           clsDatabase clsObj = new clsDatabase(_userName);
                           int executeResult = 0;
                           executeResult = clsObj.ExecuteNonQuery("update TenderDatesInfo set ts_receipt_no='" + txReceiptNo.Text + "' where proj_id=" + _prjID + " AND (stage_id = 2) and date_id =" + Convert.ToInt16(dgViewBidders.Rows[dgViewBidders.CurrentCell.RowIndex].Cells[11].Value), sqlConn);                                
                        }
                        dgViewBidders.BeginInvoke(new DelegateUpdateDataGridView(UpdateViewBiddersGridView));
                    }
                    else
                    {
                        using (SqlConnection sqlConn = new SqlConnection(strCon))
                        {
                            clsDatabase clsObj = new clsDatabase(_userName);
                            int executeResult = 0;
                            executeResult = clsObj.ExecuteNonQuery("update TenderDatesInfo set ts_receipt_no=NULL where proj_id=" + _prjID + " AND (stage_id = 2) and date_id =" + Convert.ToInt16(dgViewBidders.Rows[dgViewBidders.CurrentCell.RowIndex].Cells[11].Value), sqlConn);
                        }
                        dgViewBidders.BeginInvoke(new DelegateUpdateDataGridView(UpdateViewBiddersGridView));
                    }
                    txReceiptNo.Leave -= new EventHandler(txShortListReceiptNo_Leave);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while Updating the records", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        TextBox txtShortListRemarks = null;
        void dgViewBidders_EditingShortListRemarksColumn(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            if (this.dgViewBidders.CurrentCell.ColumnIndex == 10)
            //the column you want to add event for, I take the first column for example
            {

                txtShortListRemarks = e.Control as TextBox;
                if (txtShortListRemarks != null)
                {
                    txtShortListRemarks.Leave -= new EventHandler(txtShortListRemarks_Leave);
                    txtShortListRemarks.Leave += new EventHandler(txtShortListRemarks_Leave);
                }
            }

        }

        void txtShortListRemarks_Leave(object sender, EventArgs e)
        {
            //the column you want to add event for
            if (this.dgViewBidders.CurrentCell.ColumnIndex == 10)
            {
                try
                {
                    if (txtShortListRemarks.Text != "")
                    {
                        using (SqlConnection sqlConn = new SqlConnection(strCon))
                        {
                            clsDatabase clsObj = new clsDatabase(_userName);
                            int executeResult = 0;
                            executeResult = clsObj.ExecuteNonQuery("update TenderDatesInfo set remarks='" + txtShortListRemarks.Text + "' where proj_id=" + _prjID + " AND (stage_id = 2) and date_id =" + Convert.ToInt16(dgViewBidders.Rows[dgViewBidders.CurrentCell.RowIndex].Cells[11].Value), sqlConn);
                        }
                        dgViewBidders.BeginInvoke(new DelegateUpdateDataGridView(UpdateViewBiddersGridView));
                    }
                    else
                    {
                        using (SqlConnection sqlConn = new SqlConnection(strCon))
                        {
                            clsDatabase clsObj = new clsDatabase(_userName);
                            int executeResult = 0;
                            executeResult = clsObj.ExecuteNonQuery("update TenderDatesInfo set remarks=NULL where proj_id=" + _prjID + " AND (stage_id = 2) and date_id =" + Convert.ToInt16(dgViewBidders.Rows[dgViewBidders.CurrentCell.RowIndex].Cells[11].Value), sqlConn);
                        }
                        dgViewBidders.BeginInvoke(new DelegateUpdateDataGridView(UpdateViewBiddersGridView));
                    }                       
                    
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while Updating the record", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        TextBox txRemarks = null;        
        void dgViewCircularInfo_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            if (this.dgViewCircularInfo.CurrentCell.ColumnIndex == 4)
                //the column you want to add event for, I take the first column for example
            {

                txRemarks = e.Control as TextBox;
                if (txRemarks != null)
                {
                    txRemarks.Leave -= new EventHandler(txRemarks_Leave); 
                    txRemarks.Leave +=new EventHandler(txRemarks_Leave);                    
                }
                
            }
           
        }

        //delegate void DelegateUpdateDataGridView();        
        void txRemarks_Leave(object sender, EventArgs e)
        {           
            try
            {                
                string strRemarks = txRemarks.Text;
                if (txRemarks.Text != "")
                {
                    using (SqlConnection sqlConn = new SqlConnection(strCon))
                    {
                        clsDatabase clsObj = new clsDatabase("");
                        int executeResult = clsObj.ExecuteNonQuery("update documents set remarks='" + strRemarks + "' where proj_id=" + _prjID + " and circularNo =" + Convert.ToInt16(dgViewCircularInfo.Rows[dgViewCircularInfo.CurrentCell.RowIndex].Cells[0].Value) + " AND (stage_id = 2) AND (doc_type_id = 2) and date_id is null", sqlConn);
                    }
                    dgViewCircularInfo.BeginInvoke(new DelegateUpdateDataGridView(UpdateDataGridView));
                }
                else
                {
                    using (SqlConnection sqlConn = new SqlConnection(strCon))
                    {
                        clsDatabase clsObj = new clsDatabase("");
                        int executeResult = clsObj.ExecuteNonQuery("update documents set remarks=NULL where proj_id=" + _prjID + " and circularNo =" + Convert.ToInt16(dgViewCircularInfo.Rows[dgViewCircularInfo.CurrentCell.RowIndex].Cells[0].Value) + " AND (stage_id = 2) AND (doc_type_id = 2) and date_id is null", sqlConn);
                    }
                    dgViewCircularInfo.BeginInvoke(new DelegateUpdateDataGridView(UpdateDataGridView));
                }                
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the records","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }            
        }
        private void UpdateDataGridView()
        {
            LoadProjIDCircularInfo();
        }

        
        private void LoadProjIDCircularInfo()
        {
            BindingSource myBindingSource = null;
            try
            {
                if (dgViewCircularInfo != null)
                    dgViewCircularInfo.DataSource = null;             
            

                DAL dalObj = new DAL();                

                string sqlQuery = "SELECT CircularNo, Replace(CONVERT(nvarchar,doc_issue_date,106),' ','-') As doc_issue_date, subject, CircularIssued, remarks " +
                "from DOCUMENTS WHERE (proj_id = " + _prjID + ") and CircularNo is not NULL AND (stage_id = 2) AND (doc_type_id = 2) and date_id is null";

                DataTable dtCircularsInfo = dalObj.GetDataFromDB("CircularsInfo", sqlQuery); //.DefaultView.ToTable(true, "CircularNo");
                
                //sqlCom = new SqlCommand(sqlQuery, sqlConn);
                //sqlDtReader = sqlCom.ExecuteReader();
                //while (sqlDtReader.Read())
                //{
                //    DataRow dr = circularInfoDt.NewRow();
                //    dr[0] = sqlDtReader[0].ToString();   //CircularNo
                //    dr[1] = Convert.ToDateTime(sqlDtReader[1]).ToString("dd/MMM/yyyy");   //doc_issue_date 
                //    dr[2] = sqlDtReader[2].ToString();   //subject  
                //    dr[3] = sqlDtReader[3];   //CircularIssued                     
                //    dr[4] = sqlDtReader[4];   //remarks                     
                //    circularInfoDt.Rows.Add(dr);
                //    circularInfoDt.AcceptChanges();
                //}
                //sqlDtReader.Close();

                //int rowCounter = 0;
                //while (sqlDtReader.Read())
                //{
                //    DataRow dr = circularInfoDt.NewRow();
                //     dr[0] = sqlDtReader[0].ToString();   //CircularNo
                ////    dr[1] = Convert.ToDateTime(sqlDtReader[1]).ToString("dd/MMM/yyyy");   //doc_issue_date 
                ////    dr[2] = sqlDtReader[2].ToString();   //subject  
                ////    dr[3] = sqlDtReader[3];   //CircularIssued                     
                ////    dr[4] = sqlDtReader[4];   //remarks                     
                ////    circularInfoDt.Rows.Add(dr);
                ////    circularInfoDt.AcceptChanges();
                //    dtCircularsInfo
                //    rowCounter++;
                //}
                myBindingSource = new BindingSource(dtCircularsInfo, null);                 
                dgViewCircularInfo.DataSource = myBindingSource;                 
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
             
        }
       
        private void getTenderCloseInfo()
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();

                        string sqlQuery = "SELECT date_id, proj_id, stage_id, ts_closing_s1, ts_modified_closing FROM TenderDatesInfo WHERE (proj_id = " + _prjID + ") AND (stage_id = 2) AND (ts_tender_issue IS NULL)";
                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        int iCnt = 0;
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                if (iCnt ==0)
                                if (dr[3].ToString()!= "")
                                     txtClosingDate.Text = Convert.ToDateTime(dr[3]).ToString("dd/MMM/yyyy");
                                if (dr[4].ToString() != "")
                                    txtModifiedDate.Text = Convert.ToDateTime(dr[4]).ToString("dd/MMM/yyyy");

                                iCnt = iCnt + 1;
                            }
                        }
                        cmd.Dispose();
                    }
                    sqlConn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void dgView_KeyDown(object sender, KeyEventArgs e)
        {
            int iCnt = 0;
            for (int iCounter = 0; iCounter < dgViewBidders.RowCount; iCounter++)
            {
                DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgViewBidders.Rows[iCounter].Cells[0];

                if (chkactive.Value != null)
                {
                    if (chkactive.Value.ToString().ToLower() == "true")
                        iCnt = iCnt + 1;
                }
            }
            if (iCnt > 1)
            {
                MessageBox.Show("Please click the checkbox of the record you wish to Edit or Delete", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (e.KeyCode == Keys.Delete)
            {
                DialogResult dlgResult = DialogResult.Yes;
                dlgResult = MessageBox.Show(" Are you sure want to delete this Bidder info?", "Delete Bidder Info", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (dlgResult.ToString() == "Yes")
                {                  

                    List<int> lstObj = new List<int>();                    
                    int bidDateID = 0;
                    for (int iCounter = 0; iCounter < dgViewBidders.RowCount; iCounter++)
                    {
                        DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgViewBidders.Rows[iCounter].Cells[0];
                        if (chkactive.Value != null)
                        {
                            if (chkactive.Value.ToString().ToLower() == "true")
                            {
                                bidDateID = Convert.ToInt16(dgViewBidders.Rows[iCounter].Cells[11].Value);
                                try
                                {
                                    using (SqlConnection sqlConn = new SqlConnection(strCon))
                                    {
                                        sqlConn.Open();
                                        using (SqlCommand sqlCom = new SqlCommand("Delete from TenderDatesInfo where Date_ID =" + bidDateID + "", sqlConn))
                                        {
                                            sqlCom.ExecuteNonQuery();
                                            MessageBox.Show("Record deleted Successfully");
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show("You have no privilege to delete this project,Contact administrator", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    sqlConn.Close();
                                    return;
                                }
                                finally
                                {
                                    sqlConn.Close();
                                }
                                lstObj.Add(iCounter);
                            }
                        }
                    }
                    short sClear = 0;
                    if (dgViewBidders.Rows.Count == lstObj.Count)
                    {
                        dgViewBidders.Rows.RemoveAt(lstObj[0]);
                        sClear = 1;
                    }
                    if (sClear != 1)
                    {
                        for (int iCounter = 0; iCounter < lstObj.Count; iCounter++)
                        {
                            if (iCounter == 0)
                                dgViewBidders.Rows.RemoveAt(lstObj[iCounter]);
                            if (iCounter != 0)
                                dgViewBidders.Rows.RemoveAt(lstObj[iCounter] - 1);
                        }
                    }                   
                     
                }
            }
        }

        private Boolean CheckBiddersExistInContracts(int bidID)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    sqlConn.Open();
                    using (SqlCommand sqlCom = new SqlCommand("SELECT * from Contractors where bidder_ID =" + bidID + "", sqlConn))
                    {
                       SqlDataReader dr = sqlCom.ExecuteReader();
                       if (dr.HasRows)
                       {
                           return true;
                       }                        
                    }
                }
            }
            catch (Exception ex)
            {                
            }
            finally
            {
                sqlConn.Close();
            }
            return false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int iCnt = 0;
            for (int iCounter = 0; iCounter < dgViewBidders.RowCount; iCounter++)
            {
                DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgViewBidders.Rows[iCounter].Cells[0];
                if (chkactive.Value != null)
                {
                    if (chkactive.Value.ToString().ToLower() == "true")
                        iCnt = iCnt + 1;
                }
            }
            if (iCnt > 1)
            {
                MessageBox.Show("Please click the checkbox of the record you wish to Delete", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            DialogResult dlgResult = DialogResult.Yes;
            dlgResult = MessageBox.Show("Are you sure want to delete this Bidder info?", "Delete Bidder Info", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (dlgResult.ToString() == "Yes")
            {             

                List<int> lstObj = new List<int>();
                int bidDateID = 0;
                for (int iCounter = 0; iCounter < dgViewBidders.RowCount; iCounter++)
                {
                    DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgViewBidders.Rows[iCounter].Cells[0];
                    if (chkactive.Value != null)
                    {
                        if (chkactive.Value.ToString().ToLower() == "true")
                        {
                            bidDateID = Convert.ToInt16(dgViewBidders.Rows[iCounter].Cells[7].Value);

                            
                            //CheckBiddersExistInContracts(bidDateID);
                            try
                            {
                                using (SqlConnection sqlConn = new SqlConnection(strCon))
                                {
                                    sqlConn.Open();
                                    using (SqlCommand sqlCom = new SqlCommand("Delete from TenderDatesInfo where Date_ID =" + bidDateID + "", sqlConn))
                                    {
                                        sqlCom.ExecuteNonQuery();
                                        MessageBox.Show("Record deleted Successfully");
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("You have no privilege to delete this project,Contact administrator", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                sqlConn.Close();
                                return;
                            }
                            finally
                            {
                                sqlConn.Close();
                            }                             
                        }
                    }
                }
                short sClear = 0;
                if (dgViewBidders.Rows.Count == lstObj.Count)
                {
                    dgViewBidders.Rows.RemoveAt(lstObj[0]);
                    sClear = 1;
                }
                if (sClear != 1)
                {
                    for (int iCounter = 0; iCounter < lstObj.Count; iCounter++)
                    {
                        if (iCounter == 0)
                            dgViewBidders.Rows.RemoveAt(lstObj[iCounter]);
                        if (iCounter != 0)
                            dgViewBidders.Rows.RemoveAt(lstObj[iCounter] - 1);
                    }
                }                 
            }
        }

        private int checkGridViewSelection()
        {
            int iCnt = 0;
            for (int iCounter = 0; iCounter < dgViewBidders.RowCount; iCounter++)
            {
                DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgViewBidders.Rows[iCounter].Cells[0];

                if (chkactive.Value != null)
                {
                    if (chkactive.Value.ToString().ToLower() == "true")
                        iCnt = iCnt + 1;
                }
            }   
            if (iCnt > 1)
            {
                MessageBox.Show("Please select only one record to edit");
                return iCnt;
            }
            else if (iCnt == 0)
            {
                MessageBox.Show("Please check the checkbox of the record you wish to Edit", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return iCnt;
            }                    
                
            return iCnt;
        }

        private string getSelectedBidderInfo(char isCircular, char checkShortList)
        {
            string bidID = "";
            string projID = "";
            string remarks = "";            

            for (int iCounter = 0; iCounter < dgViewBidders.RowCount; iCounter++)
            {
                DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgViewBidders.Rows[iCounter].Cells[0];
                if (chkactive.Value != null)
                {
                    if (chkactive.Value.ToString().ToLower() == "true")
                    {
                        if (isCircular == 'C' && (checkShortList == 'V' || checkShortList == '3'))
                        {
                            remarks = dgViewBidders.Rows[iCounter].Cells[13].Value.ToString();
                            bidID = dgViewBidders.Rows[iCounter].Cells[14].Value.ToString();
                            projID = dgViewBidders.Rows[iCounter].Cells[17].Value.ToString();
                            
                        }
                        else if (isCircular == 'C' && checkShortList == 'S')
                        {
                            remarks = dgViewBidders.Rows[iCounter].Cells[10].Value.ToString();
                            bidID = dgViewBidders.Rows[iCounter].Cells[11].Value.ToString();
                            projID = dgViewBidders.Rows[iCounter].Cells[12].Value.ToString();
                            
                        }
                        else if (isCircular == 'O')
                        {
                            remarks = dgViewBidders.Rows[iCounter].Cells[10].Value.ToString();
                            bidID = dgViewBidders.Rows[iCounter].Cells[11].Value.ToString();
                            projID = dgViewBidders.Rows[iCounter].Cells[12].Value.ToString();                            
                        }
                    }
                }
            }
            return bidID + "," + projID + "," + remarks;
        }

        
        private void btnBidEdit_Click(object sender, EventArgs e)
        {
            if (userRightsColl.Contains("42"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }
            int countChkSelection = checkGridViewSelection();
            if (countChkSelection > 1 || countChkSelection == 0)
                return;
            string strValues = getSelectedBidderInfo(_chCheckCircular, _chCheckShortList);
            
          
            frmIssueTenderInfo frmEditProject = null;
            if (_chCheckShortList=='V')
                frmEditProject = new frmIssueTenderInfo(userRightsColl, strValues, txtTenderNo.Text, txtTenderTitle.Text, true, selectedCompany, _userName, 'N', _chCheckShortList, null, null);
            else
                frmEditProject = new frmIssueTenderInfo(userRightsColl, strValues, txtTenderNo.Text, txtTenderTitle.Text, true, selectedCompany, _userName, 'Y', _chCheckShortList, txtProjectCode.Text, _documentFee);
            frmEditProject.StartPosition = FormStartPosition.CenterParent;
            frmEditProject.ShowDialog();
            CommonClass comCls = new CommonClass(_userName);
            BindingSource bindSource = (BindingSource)dgViewBidders.DataSource;
            DataTable dtViewBidders = (DataTable)bindSource.DataSource;
            if (CommonClass.isSaved == 'Y' && _chCheckCircular == 'C' && _chCheckShortList == 'V')
                comCls.LoadCircularOrNonCircularData(2, 'N', dgViewBidders, _prjID, cmbCircularNo, lblCircularNo, dtViewBidders,'N','V');
            else if (CommonClass.isSaved == 'Y' && _chCheckCircular == 'O' && _chCheckShortList == 'V')
                comCls.LoadCircularOrNonCircularData(1, 'N', dgViewBidders, _prjID, cmbCircularNo, lblCircularNo, dtViewBidders,'N','V');
            else if (CommonClass.isSaved == 'Y' && _chCheckShortList == 'S' && _chCheckCircular == 'O')
                comCls.LoadCircularOrNonCircularData(3, 'N', dgViewBidders, _prjID, cmbCircularNo, lblCircularNo, dtViewBidders,'N','S');
            else if (CommonClass.isSaved == 'Y' && _chCheckShortList == 'S' && _chCheckCircular == 'C')
                comCls.LoadCircularOrNonCircularData(3, 'N', dgViewBidders, _prjID, cmbCircularNo, lblCircularNo, dtViewBidders, 'N', 'S');
            else if (CommonClass.isSaved == 'Y' && _chCheckShortList == '3' && _chCheckCircular == 'C')
                comCls.LoadCircularOrNonCircularData(2, 'N', dgViewBidders, _prjID, cmbCircularNo, lblCircularNo, dtViewBidders, 'N', '3');
            else if (CommonClass.isSaved == 'Y' && _chCheckShortList == '3' && _chCheckCircular == 'O')
                comCls.LoadCircularOrNonCircularData(1, 'N', dgViewBidders, _prjID, cmbCircularNo, lblCircularNo, dtViewBidders, 'N', '3');
        }       

        private void dgViewCircularInfo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = e.RowIndex;
            int colIndex = e.ColumnIndex;
            if (rowIndex != -1)

                if (rowIndex!= -1)

            try
            {
                if (colIndex == 3)
                {

                    if (userRightsColl.Contains("42"))
                    {
                        MessageBox.Show("You have no privilege,Contact administrator");
                        return;
                    }

                    int circularNo = Convert.ToInt16(dgViewCircularInfo.Rows[rowIndex].Cells[0].Value);
                    //int circularNo = Convert.ToInt16(dgViewCircularInfo.Rows[rowIndex].Cells[0].Value);

                    if (Convert.ToBoolean(((DataGridViewCheckBoxCell)(dgViewCircularInfo.Rows[rowIndex].Cells[3])).EditingCellFormattedValue) == true)
                    {
                        using (SqlConnection sqlConn = new SqlConnection(strCon))
                        {
                             
                                clsDatabase clsObj = new clsDatabase("");
                                int exeResult = clsObj.ExecuteNonQuery("update documents set CircularIssued=1 where CircularNo=" + circularNo + " and proj_id=" + _prjID + " AND (stage_id = 2) AND (doc_type_id = 2) and date_id is null", sqlConn);
                                 
                        }                                               
                    }
                    else
                    {
                        using (SqlConnection sqlConn = new SqlConnection(strCon))
                        {
                            
                                clsDatabase clsObj = new clsDatabase("");
                                int exeResult = clsObj.ExecuteNonQuery("update documents set CircularIssued=0 where CircularNo=" + circularNo + " and proj_id=" + _prjID + " AND (stage_id = 2) AND (doc_type_id = 2) and date_id is null", sqlConn);
                                 
                        }
                    }
                } 
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        string circularSubject = string.Empty;
        private string getSubject()
        {
            int selInx = cmbCircularNo.SelectedIndex;

            for (int i = 0; i < dgViewCircularInfo.Rows.Count; i++)
			{
                circularSubject = dgViewCircularInfo.Rows[selInx].Cells[2].Value.ToString();
			}
            return circularSubject;
        }

        private void btnEmailCirculars_Click(object sender, EventArgs e)
        {
           // circularSubject = getSubject();
            try
            {
                int iCnt = 0;
                for (int iCounter = 0; iCounter < dgViewBidders.RowCount; iCounter++)
                {
                    DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgViewBidders.Rows[iCounter].Cells[0];
                    if (chkactive.Value != null)
                    {
                        if (chkactive.Value.ToString().ToLower() == "true")
                            iCnt = iCnt + 1;
                    }
                }
                string selectQuery = null;
                Int16 circularNo = 0;
                if (cmbCircularNo.SelectedIndex != -1)
                {
                    circularNo = Convert.ToInt16(cmbCircularNo.Items[cmbCircularNo.SelectedIndex]);
                }
                if (iCnt == 0)
                {

                    //Modified by Varun on 21/04/2014 based on change request of modifying the email address of the company and inserting it into TenderDatesInfo table and then retrieving from the same table instead of Company table
                    // this is only in case of non-short list companies view

                    selectQuery = "SELECT DISTINCT COMPANY.co_email_address" +
                    " FROM TenderDatesInfo INNER JOIN COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id LEFT OUTER JOIN Contacts ON TenderDatesInfo.employee_id = Contacts.employee_id LEFT OUTER JOIN " +
                    "DOCUMENTS ON TenderDatesInfo.date_id = DOCUMENTS.date_id WHERE (TenderDatesInfo.proj_id = " + _prjID + ") AND (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.ts_tender_issue IS NOT NULL) and " +
                    "(NOT (TenderDatesInfo.remarks LIKE '%regret%') OR TenderDatesInfo.remarks IS NULL)";//" +
                    //"and DOCUMENTS.CircularNo=" + circularNo;
                }
                else
                {
                    int bidDateID = 0;
                    short checkedCounter = 1;
                    StringBuilder bidDateIds = new StringBuilder();
                    for (int iCounter = 0; iCounter < dgViewBidders.RowCount; iCounter++)
                    {
                        DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgViewBidders.Rows[iCounter].Cells[0];
                        if (chkactive.Value != null)
                        {
                            if (chkactive.Value.ToString().ToLower() == "true")
                            {
                                if (dgViewBidders.ColumnCount == 18)                                
                                    bidDateID = Convert.ToInt32(dgViewBidders.Rows[iCounter].Cells[14].Value);
                                else
                                    bidDateID = Convert.ToInt32(dgViewBidders.Rows[iCounter].Cells[11].Value);
                                bidDateIds.Append(bidDateID);

                                if (checkedCounter < iCnt)
                                {
                                    checkedCounter++;
                                    bidDateIds.Append(",");
                                }
                            }
                        }
                    }
                    //Modified by Varun on 21/04/2014 based on change request of modifying the email address of the company and inserting it into TenderDatesInfo table and then retrieving from the same table instead of Company table
                    // this is only in case of non-short list companies view
                    if (circularNo != 0)
                    {
                        selectQuery = "SELECT DISTINCT COMPANY.co_email_address" +
                        " FROM TenderDatesInfo INNER JOIN COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id LEFT OUTER JOIN Contacts ON TenderDatesInfo.employee_id = Contacts.employee_id LEFT OUTER JOIN " +
                        "DOCUMENTS ON TenderDatesInfo.date_id = DOCUMENTS.date_id WHERE TenderDatesInfo.date_id in (" + bidDateIds.ToString() + ") AND (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.ts_tender_issue IS NOT NULL) and " +
                        "(DOCUMENTS.doc_type_id = 2) and DOCUMENTS.doc_category_id=1 and TenderDatesInfo.Tender_Issued=1 AND (NOT (TenderDatesInfo.remarks LIKE '%regret%') OR TenderDatesInfo.remarks IS NULL) " +
                        "and DOCUMENTS.CircularNo=" + circularNo;
                    }
                    else
                    {
                        selectQuery = "SELECT DISTINCT COMPANY.co_email_address" +
                        " FROM TenderDatesInfo INNER JOIN COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id LEFT OUTER JOIN Contacts ON TenderDatesInfo.employee_id = Contacts.employee_id LEFT OUTER JOIN " +
                        "DOCUMENTS ON TenderDatesInfo.date_id = DOCUMENTS.date_id WHERE TenderDatesInfo.date_id in (" + bidDateIds.ToString() + ") AND (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.ts_tender_issue IS NOT NULL) and " +
                        "(DOCUMENTS.doc_type_id = 2) and (DOCUMENTS.proj_id = " + _prjID + ") and DOCUMENTS.doc_category_id=1 and TenderDatesInfo.Tender_Issued=1 AND (NOT (TenderDatesInfo.remarks LIKE '%regret%') OR TenderDatesInfo.remarks IS NULL)";                        
                    }
                }

                //MailMessage mailMessage = new MailMessage();

                //mailMessage.From = new MailAddress(FindEmailIDOfTheUser(_userName));
                //mailMessage.To.Add(new MailAddress(ConfigurationManager.AppSettings["To"].ToString()));
                //mailMessage.Subject = "TCMS Alert: New Project is going to get created";
                //mailMessage.IsBodyHtml = true;


                //mailMessage.Body = "<html><body><i style='font-family:Calibri; font-size:15'>Dear Sir/Madam,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Tender & Contract Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>" +
                //"Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'> New " + _mohOrNonMohProjType + " Project having Project Code/ID: " + _mohOrNonMohPrjCode + " is about to get created</i><br /><br />" +
                //"<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation:</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now.ToString("dd/MMM/yyyy") + "</td></tr>" +
                //"</table><br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>TCMS Team</div></body></html>";

                //SmtpClient client = new SmtpClient();
                //client.EnableSsl = true;
                ////client.UseDefaultCredentials = true;
                //client.Credentials = new System.Net.NetworkCredential(ashghalUserName.Text.Trim(), password.Text);
                //ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                //client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                //client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                //client.Send(mailMessage);

                DAL dal = new DAL();
                DataTable dt = dal.GetDataFromDB("EmailAddresses", selectQuery);

                Microsoft.Office.Interop.Outlook._Application outlookApp = new Microsoft.Office.Interop.Outlook.Application();
                Microsoft.Office.Interop.Outlook._MailItem mailItem = (Microsoft.Office.Interop.Outlook._MailItem)outlookApp.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                if (circularNo != 0)
                {
                    mailItem.Subject = "Tender No. " + txtTenderNo.Text + " Circular No. " + circularNo; 
                }
                else
                {
                    mailItem.Subject = "Tender No. " + txtTenderNo.Text;
                }
                short rowCounter = 0;
                StringBuilder strBuild = new StringBuilder();
                while (rowCounter < dt.Rows.Count)
                {
                    strBuild.Append(dt.Rows[rowCounter][0].ToString());
                    strBuild.Replace(',', ';');
                    strBuild.Append(";");
                    rowCounter++;
                }
                mailItem.BCC = strBuild.ToString();
                mailItem.Display(false);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Document: Error occurred while trying to Create an Outlook Email, Please Install Microsoft Outlook software or configure it.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            //try
            //{         

            //    // creating Excel Application
            //    Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();


            //    // creating new WorkBook within Excel application
            //    Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);


            //    // creating new Excelsheet in workbook
            //    Microsoft.Office.Interop.Excel._Worksheet worksheet = null;

            //    // see the excel sheet behind the program
            //    app.Visible = true;

            //    // get the reference of first sheet. By default its name is Sheet1.
            //    // store its reference to worksheet
            //    worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Sheets["Sheet1"];
            //    worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.ActiveSheet;

            //    // changing the name of active sheet
            //    worksheet.Name = "Exported Form Bidder Info";

            //    //worksheet.get_Range("","");
 
            //    worksheet.Cells[1, 6] = "Tender Collection Summary";
            //    worksheet.get_Range("A1", "F1").Font.Bold = true;
            //    worksheet.Cells[4, 1] = "Project Code";
            //    worksheet.Cells[4, 3] = txtProjectCode.Text;
            //    worksheet.Cells[5, 1] = "Tender Title";
            //    worksheet.Cells[5, 3] = txtTenderTitle.Text;
            //    worksheet.Cells[6, 1] = "Tender No";
            //    worksheet.Cells[6, 3] = txtTenderNo.Text;
            //    worksheet.Cells[7, 1] = "Tender Closing Date";
            //    worksheet.Cells[7, 3] = txtClosingDate.Text;
            //    worksheet.Cells[8, 1] = "Modified Closing Date";
            //    worksheet.Cells[8, 3] = txtModifiedDate.Text;

            //    // storing header part in Excel
            //    for (int i = 1; i < dgViewBidders.Columns.Count-1; i++)
            //    {
            //        worksheet.Cells[10, i] = dgViewBidders.Columns[i].HeaderText;
            //    }

            //    Int16 innerCounter = 10;
            //    //Microsoft.Office.Interop.Excel.Range headerColumnRange = ("A2", "G2");                 
                
            //    // storing Each row and column value to excel sheet
            //    for (int i = 0; i < dgViewBidders.Rows.Count; i++)
            //    {
            //        innerCounter++;
            //        for (int j = 1; j < dgViewBidders.Columns.Count-1; j++)
            //        {                        
            //            Microsoft.Office.Interop.Excel.Range cellsRange = (Microsoft.Office.Interop.Excel.Range)worksheet.get_Range("A"+innerCounter,"E"+innerCounter);
            //            //cellsRange.WrapText = true;
            //            Microsoft.Office.Interop.Excel.Range specificCells = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[innerCounter,6];
            //            cellsRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignGeneral;
            //            //cellsRange.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
            //            specificCells.WrapText = true;
            //            specificCells.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignGeneral;
            //            //specificCells.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
            //            worksheet.Cells[innerCounter, j] = dgViewBidders.Rows[i].Cells[j].Value.ToString();                        
            //        }                    
            //    }



             //    workbook = app.Workbooks.Open(ConfigurationSettings.AppSettings["ExcelPath"].ToString(), 0, true, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "\t", false, false, 0, true, 1, 0);

             //    //xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

             //    // save the application                
             //    //workbook.SaveAs("h:\\StoreExcelSheet\\output.xls", Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

             //    // Exit from the application
             //    app.Quit();
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show("Exception while exporting the form into excel");
            //}

        }

        string FindEmailIDOfTheUser(string userName)
        {
            string emailID = null;
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();

                        string sqlQuery = "SELECT email_address FROM USERS WHERE (user_name = '" + userName + "')";

                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            if (dr.Read())
                            {
                                emailID = dr["email_address"].ToString();
                                //if (!userListColl.Contains(strData))                                    
                                //    userListColl.Add(strData);
                            }
                            dr.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while retrieving the user email from the database", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                emailID = null;
            }
            return emailID;
        }

        private void btnExportToPdf_Click(object sender, EventArgs e)
        {
            if (userRightsColl.Contains("44"))
            {
                MessageBox.Show("You have no privilege, Contact administrator");
                return;
            }
            CommonClass comCls = new CommonClass(_userName);
            int circularCnt = 0;
            if (cmbCircularNo.Visible == true)
                circularCnt = cmbCircularNo.Items.Count;
            short modifiedClosingDateCount = clsForTS.GetModifiedClosingDateCount(_prjID);             
            //Modified By Varun on 16th Feb 2014 replace prAdvDate by tenderIssueDate based on Riyas request
            //public string ExportToPDF(string strCon, SqlCommand sqlCom, DataGridView dgView, System.Data.DataView dv, string strTendrNo, string projCode, string strTendrTitle, int projID, string strClosingDate, string strModifiedDate, int totCircularNos, string tenderBond, string docFee, string tenderIssueDate, char isTenderExpiry, char isEmail, string strEligibleTenderTypes, string typeOfTender, Int16 noOfExtns, string[] companyInfo, int logoType, string collectedBy)
            comCls.ExportToPDF(strCon, sqlCom, dgViewBidders, null, txtTenderNo.Text, txtProjectCode.Text, txtTenderTitle.Text, _prjID, txtClosingDate.Text, txtModifiedDate.Text.Split(' ')[0].ToString(), circularCnt, _tenderBond, _documentFee, _tenderIssueDate, 'N', 'N', _strEligibleTenderTypes, mTypeOfTender, modifiedClosingDateCount, null, 1, "", 1, null, false,false);                          
//=======
//            comCls.ExportToPDF(strCon, sqlCom, dgViewBidders, null, txtTenderNo.Text, txtProjectCode.Text, txtTenderTitle.Text, _prjID, txtClosingDate.Text, txtModifiedDate.Text.Split(' ')[0].ToString(), circularCnt, _tenderBond, _documentFee, _tenderIssueDate, 'N', 'N', _strEligibleTenderTypes, mTypeOfTender, modifiedClosingDateCount, null, 1, "");                          
//>>>>>>> .r24
        }       

        private void btnDeleteBidder_Click(object sender, EventArgs e)
        {
            if (userRightsColl.Contains("42"))
            {
                MessageBox.Show("You have no privilege, Contact administrator");
                return;
            }

            int iCnt = 0;
            for (int iCounter = 0; iCounter < dgViewBidders.RowCount; iCounter++)
            {
                DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgViewBidders.Rows[iCounter].Cells[0];
                if (chkactive.Value != null)
                {
                    if (chkactive.Value.ToString().ToLower() == "true")
                        iCnt = iCnt + 1;
                }
            }
            if (iCnt > 1)
            {
                MessageBox.Show("Please select only one record to delete", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else if (iCnt == 0)
            {
                MessageBox.Show("Please click the checkbox of the record you wish to delete", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            DialogResult dlgResult = DialogResult.Yes;
            if(btnDeleteFromShortList.Visible == false)
                dlgResult = MessageBox.Show(" Are you sure you want to DELETE this Bidder?", "Delete Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            else
                dlgResult = MessageBox.Show(" Are you sure you want to DELETE this Short List?", "Delete Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (dlgResult.ToString() == "Yes")
            {  
                List<int> lstObj = new List<int>();
                int bidDateID = 0;
                int projID = 0;
                for (int iCounter = 0; iCounter < dgViewBidders.RowCount; iCounter++)
                {
                    DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgViewBidders.Rows[iCounter].Cells[0];
                    if (chkactive.Value != null)
                    {
                        if (chkactive.Value.ToString().ToLower() == "true")
                        {
                            if (dgViewBidders.ColumnCount == 18)
                            {
                                bidDateID = Convert.ToInt32(dgViewBidders.Rows[iCounter].Cells[14].Value);
                                projID = Convert.ToInt32(dgViewBidders.Rows[iCounter].Cells[17].Value);
                            }
                            else
                            {
                                bidDateID = Convert.ToInt32(dgViewBidders.Rows[iCounter].Cells[11].Value);
                                projID = Convert.ToInt32(dgViewBidders.Rows[iCounter].Cells[12].Value);
                            }
                            try
                            {
                                using (SqlConnection sqlConn = new SqlConnection(strCon))
                                {
                                    sqlConn.Open();
                                    using (SqlCommand sqlCom = new SqlCommand("Delete from Documents where Date_ID =" + bidDateID + " and (proj_id = " + _prjID + ")", sqlConn))
                                    {
                                        sqlCom.ExecuteNonQuery();
                                        sqlCom.Dispose();
                                    }
                                    using (SqlCommand sqlCom = new SqlCommand("Delete from TenderDatesInfo where Date_ID =" + bidDateID + " and (proj_id = " + _prjID + ")", sqlConn))
                                    {
                                        sqlCom.ExecuteNonQuery();
                                        sqlCom.Dispose();
                                    }
                                    MessageBox.Show("Record deleted Successfully");   
                                                                  
                                    comCls = new CommonClass(_userName);
                                    comCls.ReNumberSNCol(projID,strCon,'V');
                                    sqlConn.Close();
                                }
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("You have no privilege to delete this project,Contact administrator", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);                                
                                return;
                            } 
                            lstObj.Add(iCounter);
                        }
                    }
                }
                short sClear = 0;
                if (dgViewBidders.Rows.Count == lstObj.Count)
                {
                    dgViewBidders.Rows.RemoveAt(lstObj[0]);
                    sClear = 1;
                }
                if (sClear != 1)
                {
                    for (int iCounter = 0; iCounter < lstObj.Count; iCounter++)
                    {
                        if (iCounter == 0)
                            dgViewBidders.Rows.RemoveAt(lstObj[iCounter]);
                        if (iCounter != 0)
                            dgViewBidders.Rows.RemoveAt(lstObj[iCounter] - 1);
                    }
                }

                comCls = new CommonClass(_userName);
                BindingSource bindSource = (BindingSource)dgViewBidders.DataSource;
                DataTable dtViewBidders = (DataTable)bindSource.DataSource;        
                if(dgViewBidders.ColumnCount == 18)
                    comCls.LoadCircularOrNonCircularData(2, 'N', dgViewBidders, _prjID, cmbCircularNo, lblCircularNo, dtViewBidders,'N','V');
                else
                    comCls.LoadCircularOrNonCircularData(1, 'N', dgViewBidders, _prjID, cmbCircularNo, lblCircularNo, dtViewBidders,'N','V');
                       
            }
        }        

        private void cmbCircularNo_SelectionChangeCommitted(object sender, EventArgs e)
        {
            CommonClass comCls = new CommonClass(_userName);
            BindingSource bindSource = (BindingSource)dgViewBidders.DataSource;
            DataTable dtViewBidders = (DataTable)bindSource.DataSource;
            if (_chCheckCircular == 'C' && _chCheckShortList == 'V')
                comCls.LoadCircularOrNonCircularData(2, 'Y', dgViewBidders, _prjID, cmbCircularNo, lblCircularNo, dtViewBidders,'N','V');
            else if (_chCheckCircular == 'O' && _chCheckShortList == 'V')
                comCls.LoadCircularOrNonCircularData(1, 'Y', dgViewBidders, _prjID, cmbCircularNo, lblCircularNo, dtViewBidders, 'N', 'V');
            else if (_chCheckShortList == 'S')
                comCls.LoadCircularOrNonCircularData(3, 'Y', dgViewBidders, _prjID, null, null, dtViewBidders, 'N', 'S');
            else if (_chCheckShortList == '3')
                comCls.LoadCircularOrNonCircularData(2, 'Y', dgViewBidders, _prjID, cmbCircularNo, lblCircularNo, dtViewBidders, 'N', '3');
             
            CalendarEditingControl calEditCtrl = new CalendarEditingControl();
            calEditCtrl.CmbCtrl = cmbCircularNo;
        }

        private void btnDeleteFromShortList_Click(object sender, EventArgs e)
        {
            if (userRightsColl.Contains("42"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            int iCnt = 0;
            for (int iCounter = 0; iCounter < dgViewBidders.RowCount; iCounter++)
            {
                DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgViewBidders.Rows[iCounter].Cells[0];

                if (chkactive.Value != null)
                {
                    if (chkactive.Value.ToString().ToLower() == "true")
                        iCnt = iCnt + 1;
                }
            }
            if (iCnt > 1)
            {
                MessageBox.Show("Please Select Only One Record For Delete");
                return;
            }
            else if (iCnt == 0)
            {
                MessageBox.Show("Please click the checkbox of the record you wish to Delete", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            DialogResult dlgResult = DialogResult.Yes;
            dlgResult = MessageBox.Show(" Are you sure you want to DELETE the record from the Short List?", "Delete Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (dlgResult.ToString() == "Yes")
            {
                List<int> lstObj = new List<int>();
                int bidDateID = 0;
                int projID = 0;
                for (int iCounter = 0; iCounter < dgViewBidders.RowCount; iCounter++)
                {
                    DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgViewBidders.Rows[iCounter].Cells[0];
                    if (chkactive.Value != null)
                    {
                        if (chkactive.Value.ToString().ToLower() == "true")
                        {
                            if ((_chCheckShortList == '3' || _chCheckShortList == 'V') && _chCheckCircular == 'C')
                            {
                                bidDateID = Convert.ToInt32(dgViewBidders.Rows[iCounter].Cells[14].Value);
                                projID = Convert.ToInt32(dgViewBidders.Rows[iCounter].Cells[17].Value);
                            }
                            else
                            {
                                bidDateID = Convert.ToInt32(dgViewBidders.Rows[iCounter].Cells[11].Value);
                                projID = Convert.ToInt32(dgViewBidders.Rows[iCounter].Cells[12].Value);
                            }
                            
                            try
                            {
                                using (SqlConnection sqlConn = new SqlConnection(strCon))
                                {
                                    sqlConn.Open();
                                    using (SqlCommand sqlCom = new SqlCommand("Delete from Documents where Date_ID =" + bidDateID + " and (proj_id = " + _prjID + ")", sqlConn))
                                    {
                                        sqlCom.ExecuteNonQuery();
                                        sqlCom.Dispose();
                                    }
                                    using (SqlCommand sqlCom = new SqlCommand("Delete from TenderDatesInfo where Date_ID =" + bidDateID + " and (proj_id = " + _prjID + ")", sqlConn))
                                    {
                                        sqlCom.ExecuteNonQuery();                                         
                                        sqlCom.Dispose();
                                    }
                                    
                                    MessageBox.Show("Record deleted Successfully");
                                    comCls = new CommonClass(_userName);
                                    comCls.ReNumberSNCol(projID, strCon, _chCheckShortList);
                                    sqlConn.Close();
                                }
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("You have no privilege to delete this project,Contact administrator", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                return;
                            }
                            lstObj.Add(iCounter);
                        }
                    }
                }
                short sClear = 0;
                if (dgViewBidders.Rows.Count == lstObj.Count)
                {
                    dgViewBidders.Rows.RemoveAt(lstObj[0]);
                    sClear = 1;
                }
                if (sClear != 1)
                {
                    for (int iCounter = 0; iCounter < lstObj.Count; iCounter++)
                    {
                        if (iCounter == 0)
                            dgViewBidders.Rows.RemoveAt(lstObj[iCounter]);
                        if (iCounter != 0)
                            dgViewBidders.Rows.RemoveAt(lstObj[iCounter] - 1);
                    }
                }
                comCls = new CommonClass(_userName);
                BindingSource bindSource = (BindingSource)dgViewBidders.DataSource;
                DataTable dtViewBidders = (DataTable)bindSource.DataSource;
                if (_chCheckShortList == '3' && _chCheckCircular=='C')
                    comCls.LoadCircularOrNonCircularData(2, 'N', dgViewBidders, _prjID, cmbCircularNo, lblCircularNo, finalDt, _chFirstRun, _chCheckShortList);
                else if (_chCheckShortList == '3' && _chCheckCircular == 'O')
                    comCls.LoadCircularOrNonCircularData(1, 'N', dgViewBidders, _prjID, cmbCircularNo, lblCircularNo, finalDt, _chFirstRun, _chCheckShortList);
                else if (_chCheckShortList == 'S')
                    comCls.LoadCircularOrNonCircularData(3, 'N', dgViewBidders, _prjID, cmbCircularNo, lblCircularNo, finalDt, _chFirstRun, _chCheckShortList);
                 

            }
        }

        private void frmBidderInfo_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (dgViewBidders.ColumnCount == 17)
            {
                CalendarEditingControl calEditCtrl = new CalendarEditingControl();
                calEditCtrl.DGControl = null;
                calEditCtrl.CmbCtrl = null;
                calEditCtrl.CheckShortList = ' ';
                calEditCtrl.CheckIsCircular = ' ';
            }
        }

        private void frmBidderInfo_Load(object sender, EventArgs e)
        {
            try
            {                  
                clsDatabase clsDb = new clsDatabase(strCon);
                clsDb.ConnectDB();
                txtProjectType.Text = clsDb.ExecuteReader("select EligibleTenderTypes from PROJECTS where proj_id=" + _prjID);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while retrieving Project type", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }            
        }

        private void dgViewBidders_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.ColumnIndex == 10 && (_chCheckCircular == 'O' || _chCheckShortList=='S'))
            {
                object val = dgViewBidders.Rows[e.RowIndex].Cells[10].Value;
                if ((val != null) && !object.ReferenceEquals(val, DBNull.Value))
                {
                    ApplyRowFormatting(val, ref e);
                }
            }
            else if (e.ColumnIndex == 13 && _chCheckCircular == 'C')
            {
                object val = dgViewBidders.Rows[e.RowIndex].Cells[13].Value;
                if ((val != null) && !object.ReferenceEquals(val, DBNull.Value))
                {
                    ApplyRowFormatting(val, ref e);
                }
            }

        }
        private void ApplyRowFormatting(object val, ref System.Windows.Forms.DataGridViewCellFormattingEventArgs e)
        {
            if (val.ToString().ToLower().Contains("regret") || val.ToString().ToLower().Contains("declined"))
            {
                dgViewBidders.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.Yellow;
                e.Value = val;
                e.FormattingApplied = true;
            }
            else
            {
                dgViewBidders.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.Cornsilk;
                e.Value = val;
                e.FormattingApplied = true;
            }
        }

        int tableDataStartIdx = 17;
        private void btnReportInExcel_Click(object sender, EventArgs e)
        {              
            try
            {
                if (userRightsColl.Contains("44"))
                {
                    MessageBox.Show("You have no privilege, Contact administrator");
                    return;
                }
                //DataTable dtFinalTenderersInfo = (System.Data.DataTable)dgViewBidders.DataSource;
                BindingSource bindSource = (BindingSource)dgViewBidders.DataSource;
                DataTable dtViewBidders = (DataTable)bindSource.DataSource; 
                //if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                //{
                //    if (mIsWorkOrder)
                //    {
                //        if (mUserRightsColl.Contains("79"))
                //        {
                //            MessageBox.Show("You do not have permission to Export To Excel In Work Orders, Please contact the Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //            return;
                //        }
                //    }
                //    else
                //    {
                //        if (mUserRightsColl.Contains("81"))
                //        {
                //            MessageBox.Show("You do not have permission to Export To Excel In Tender Submission, Please contact the Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //            return;
                //        }
                //    }
                //}

                SaveFileDialog saveFileDialog1 = new SaveFileDialog();
                Microsoft.Office.Interop.Excel._Application app = null;
                Microsoft.Office.Interop.Excel._Workbook workbook = null;
                //if(!mIsWorkOrder)
                //{
                // commented by Varun on 08/Jun/15 saveFileDialog1.Filter = "Excel Path|*.xls|Excel Format|*.xlsx";

                saveFileDialog1.Filter = "Excel Path|*.xls|Excel Path|*.xlsx";
                saveFileDialog1.Title = "Save an Excel File";
                saveFileDialog1.ShowDialog();

                if (saveFileDialog1.FileName != "")
                {
                    // creating Excel Application
                    app = new Microsoft.Office.Interop.Excel.Application();

                    // creating new WorkBook within Excel application
                    workbook = app.Workbooks.Add(Type.Missing);

                    // creating new Excelsheet in workbook
                    Microsoft.Office.Interop.Excel._Worksheet worksheet = null;

                    // see the excel sheet behind the program
                    app.Visible = true;

                    // get the reference of first sheet. By default its name is Sheet1.
                    // store its reference to worksheet
                    worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Sheets["Sheet1"];
                    worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.ActiveSheet;

                    Microsoft.Office.Interop.Excel.Range formatRange = worksheet.UsedRange;
                    Microsoft.Office.Interop.Excel.Range formatA1CellRange = null;
                    Microsoft.Office.Interop.Excel.Range formatA1Cell = null;
                    Microsoft.Office.Interop.Excel.Range formatOtherCell = null;

                    formatA1CellRange = worksheet.get_Range("D1", "D1");
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[6, 10];
                    formatA1CellRange.ColumnWidth = 255;
                    //formatA1CellRange.Merge(true);

                    formatA1CellRange.FormulaR1C1 = "Tender Collection Summary";                     
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(196, 215, 155));
                    formatA1CellRange.Font.Size = 18;
                    formatA1CellRange.Font.Underline = true;

                    formatA1CellRange = worksheet.get_Range("B3", "B3");
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[2, 2];
                    formatA1CellRange.ColumnWidth = 20;
                    //formatA1CellRange.Merge(true);
                    formatA1CellRange.FormulaR1C1 = "Type of Tender";
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    //formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(255, 0,0));
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = false;

                    formatA1CellRange = worksheet.get_Range("C3", "C3");
                    formatA1CellRange.ColumnWidth = 5;
                    formatA1CellRange.FormulaR1C1 = ":";
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    //formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(255, 0, 0));
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = false;

                    formatA1CellRange = worksheet.get_Range("D3", "D3");
                    formatA1CellRange.ColumnWidth = 50;
                    formatA1CellRange.FormulaR1C1 = mTypeOfTender;
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    //formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(255, 0, 0));
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = true;                    

                    formatA1CellRange = worksheet.get_Range("B4", "B4");
                    formatA1CellRange.ColumnWidth = 20;
                    //formatA1CellRange.Merge(true);
                    formatA1CellRange.FormulaR1C1 = "Tender No.";
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    //formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(255, 0, 0));
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = false;

                    formatA1CellRange = worksheet.get_Range("C4", "C4");
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, 3];
                    formatA1CellRange.ColumnWidth = 5;                     
                    formatA1CellRange.FormulaR1C1 = ":";
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    //formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(255, 0, 0));
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = false;

                    formatA1CellRange = worksheet.get_Range("D4", "D4");
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, 3];
                    formatA1CellRange.ColumnWidth = 20;
                    formatA1CellRange.FormulaR1C1 = txtTenderNo.Text;
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    //formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(255, 0, 0));
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = true;

                    formatA1CellRange = worksheet.get_Range("B5", "B5");
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[2, 2];
                    formatA1CellRange.ColumnWidth = 20;
                    //formatA1CellRange.Merge(true);
                    formatA1CellRange.FormulaR1C1 = "Project Code";
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    //formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(255, 0, 0));
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = false;

                    formatA1CellRange = worksheet.get_Range("C5", "C5");
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, 3];
                    formatA1CellRange.ColumnWidth = 5;
                    formatA1CellRange.FormulaR1C1 = ":";
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";                     
                    formatA1CellRange.Font.Size = 13;
                    //formatA1CellRange.Font.Bold = true;

                    formatA1CellRange = worksheet.get_Range("D5", "D5");
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, 3];
                    formatA1CellRange.ColumnWidth = 40;
                    formatA1CellRange.FormulaR1C1 = txtProjectCode.Text;
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    //formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(255, 0, 0));
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = true;

                    formatA1CellRange = worksheet.get_Range("B6", "B6");
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[2, 2];
                    formatA1CellRange.ColumnWidth = 20;
                    //formatA1CellRange.Merge(true);
                    formatA1CellRange.FormulaR1C1 = "Tender Title";
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    //formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(255, 0, 0));
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = false;

                    formatA1CellRange = worksheet.get_Range("C6", "C6");
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, 3];
                    formatA1CellRange.ColumnWidth = 5;
                    formatA1CellRange.FormulaR1C1 = ":";
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = false;

                    formatA1CellRange = worksheet.get_Range("D6", "D6");
                    formatA1CellRange.RowHeight = 60;
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, 4];
                    //formatA1CellRange.Cells.Width = 100;
                    formatA1CellRange.ColumnWidth = 220;
                    formatA1CellRange.FormulaR1C1 = txtTenderTitle.Text;
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    //formatA1CellRange.Font.
                    //formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(255, 0, 0));
                    formatA1CellRange.WrapText = true;
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = true;  

                    //txtClosingDate.Text, txtModifiedDate.Text.Split(' ')[0].ToString(), circularCnt, _tenderBond, _documentFee, _tenderIssueDate,

                    formatA1CellRange = worksheet.get_Range("B7", "B7");
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[5, 4];
                    formatA1CellRange.ColumnWidth = 20;
                    //formatA1CellRange.Merge(true);
                    formatA1CellRange.FormulaR1C1 = "Tender Bond";
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    //formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(255, 0, 0));
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = false;

                    formatA1CellRange = worksheet.get_Range("C7", "C7");
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[5, 5];
                    formatA1CellRange.ColumnWidth = 5;
                    formatA1CellRange.FormulaR1C1 = ":";
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = false;

                    formatA1CellRange = worksheet.get_Range("D7", "D7");
                    //formatA1CellRange.Merge(true);
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[4, 11];
                    formatA1CellRange.ColumnWidth = 30;
                    formatA1CellRange.FormulaR1C1 = _tenderBond;
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    //formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(255, 0, 0));
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = true; 

                    formatA1CellRange = worksheet.get_Range("B8", "B8");
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[5, 4];
                    formatA1CellRange.ColumnWidth = 30;
                    //formatA1CellRange.Merge(true);
                    formatA1CellRange.FormulaR1C1 = "Date of Tender Announcement";
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    //formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(255, 0, 0));
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = false;

                    formatA1CellRange = worksheet.get_Range("C8", "C8");
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[5, 5];
                    formatA1CellRange.ColumnWidth = 5;
                    formatA1CellRange.FormulaR1C1 = ":";
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = false;

                    formatA1CellRange = worksheet.get_Range("D8", "D8");
                    //formatA1CellRange.Merge(true);
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[4, 11];
                    formatA1CellRange.ColumnWidth = 20;
                    formatA1CellRange.FormulaR1C1 = _tenderIssueDate;
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    //formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(255, 0, 0));
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = true;

                    formatA1CellRange = worksheet.get_Range("B9", "B9");
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[5, 4];
                    formatA1CellRange.ColumnWidth = 25;
                    //formatA1CellRange.Merge(true);
                    formatA1CellRange.FormulaR1C1 = "Document Fee";
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    //formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(255, 0, 0));
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = false;

                    formatA1CellRange = worksheet.get_Range("C9", "C9");
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[5, 5];
                    formatA1CellRange.ColumnWidth = 5;
                    formatA1CellRange.FormulaR1C1 = ":";
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = false;

                    formatA1CellRange = worksheet.get_Range("D9", "D9");
                    //formatA1CellRange.Merge(true);
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[4, 11];
                    formatA1CellRange.ColumnWidth = 20;
                    formatA1CellRange.FormulaR1C1 = _documentFee;
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    //formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(255, 0, 0));
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = true;

                    formatA1CellRange = worksheet.get_Range("B10", "B10");
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[5, 4];
                    formatA1CellRange.ColumnWidth = 25;
                    //formatA1CellRange.Merge(true);
                    formatA1CellRange.FormulaR1C1 = "Tender Closing Date";
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    //formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(255, 0, 0));
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = false;

                    formatA1CellRange = worksheet.get_Range("C10", "C10");
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[5, 5];
                    formatA1CellRange.ColumnWidth = 5;
                    formatA1CellRange.FormulaR1C1 = ":";
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = false;

                    formatA1CellRange = worksheet.get_Range("D10", "D10");
                    //formatA1CellRange.Merge(true);
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[4, 11];
                    formatA1CellRange.ColumnWidth = 20;
                    formatA1CellRange.FormulaR1C1 = txtClosingDate.Text;
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    //formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(255, 0, 0));
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = true;

                    formatA1CellRange = worksheet.get_Range("B11", "B11");
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[5, 4];
                    formatA1CellRange.ColumnWidth = 30;                     
                    formatA1CellRange.FormulaR1C1 = "Modified Closing Date";
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    //formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(255, 0, 0));
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = false;

                    formatA1CellRange = worksheet.get_Range("C11", "C11");
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[5, 5];
                    formatA1CellRange.ColumnWidth = 5;
                    formatA1CellRange.FormulaR1C1 = ":";
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = false;

                    formatA1CellRange = worksheet.get_Range("D11", "D11");
                    //formatA1CellRange.Merge(true);
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[4, 11];
                    formatA1CellRange.ColumnWidth = 20;
                    formatA1CellRange.FormulaR1C1 = txtModifiedDate.Text;
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    //formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(255, 0, 0));
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = true;

                    formatA1CellRange = worksheet.get_Range("B12", "B12");
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[5, 4];
                    formatA1CellRange.ColumnWidth =25;
                    formatA1CellRange.FormulaR1C1 = "No. of Extensions";
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    //formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(255, 0, 0));
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = false;

                    formatA1CellRange = worksheet.get_Range("C12", "C12");
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[5, 5];
                    formatA1CellRange.ColumnWidth = 5;
                    formatA1CellRange.FormulaR1C1 = ":";
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    formatA1CellRange.Font.Size = 13;
                    //formatA1CellRange.Font.Bold = false;

                    formatA1CellRange = worksheet.get_Range("D12", "D12");
                    //formatA1CellRange.Merge(true);
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[4, 11];
                    formatA1CellRange.ColumnWidth = 15;                     
                    formatA1CellRange.FormulaR1C1 = clsForTS.GetModifiedClosingDateCount(_prjID);
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    //formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(255, 0, 0));
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = true;

                    formatA1CellRange = worksheet.get_Range("B13", "B13");
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[5, 4];
                    formatA1CellRange.ColumnWidth = 20;
                    //formatA1CellRange.Merge(true);
                    formatA1CellRange.FormulaR1C1 = "No. of Circulars";
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    //formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(255, 0, 0));
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = false;

                    formatA1CellRange = worksheet.get_Range("C13", "C13");
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[5, 5];
                    formatA1CellRange.ColumnWidth = 5;
                    formatA1CellRange.FormulaR1C1 = ":";
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = false;

                    formatA1CellRange = worksheet.get_Range("D13", "D13");
                    //formatA1CellRange.Merge(true);
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[4, 11];
                    formatA1CellRange.ColumnWidth = 15;
                    formatA1CellRange.FormulaR1C1 = _circularCnt;
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    //formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(255, 0, 0));
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = true;

                    formatA1CellRange = worksheet.get_Range("B14", "B14");
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[5, 4];
                    formatA1CellRange.ColumnWidth = 30;
                    //formatA1CellRange.Merge(true);
                    formatA1CellRange.FormulaR1C1 = "Eligible To Tender";
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    //formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(255, 0, 0));
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = false;

                    formatA1CellRange = worksheet.get_Range("C14", "C14");
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[5, 5];
                    formatA1CellRange.ColumnWidth = 5;
                    formatA1CellRange.FormulaR1C1 = ":";
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = false;

                    formatA1CellRange = worksheet.get_Range("D14", "D14");
                    //formatA1CellRange.Merge(true);
                    //formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[4, 11];
                    formatA1CellRange.ColumnWidth = 20;
                    formatA1CellRange.FormulaR1C1 = _strEligibleTenderTypes;
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    //formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(255, 0, 0));
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = true;

                    
                    if (dgViewBidders.Rows.Count != 0)
                    {
                        int tableRowHeaderIdx = 16;
                        System.Drawing.Color color = Color.FromArgb(255, 204, 0);
                        // storing header part in Excel
                        for (int colCounter = 1; colCounter < 11; colCounter++)
                        {
                            if (colCounter == 1)
                            {
                                worksheet.Cells[tableRowHeaderIdx, colCounter] = dtViewBidders.Columns[colCounter].ToString();
                                formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[tableRowHeaderIdx, colCounter];
                                formatA1Cell.Font.Name = "Calibri";
                                formatA1Cell.Font.Size = "12";
                                formatA1Cell.Font.Bold = true;
                                formatA1Cell.WrapText = true;
                                formatA1Cell.ColumnWidth = 5;
                                formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                                //formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                            }
                            else if (colCounter == 2)
                            {
                                worksheet.Cells[tableRowHeaderIdx, colCounter] = dtViewBidders.Columns[colCounter].ToString();
                                formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[tableRowHeaderIdx, colCounter];                                         
                                formatA1Cell.Font.Name = "Calibri";
                                formatA1Cell.Font.Size = "12";
                                formatA1Cell.Font.Bold = true;
                                formatA1Cell.WrapText = true;
                                formatA1Cell.ColumnWidth = 25;
                                formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                                //formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                            }
                            else if (colCounter != 1 && colCounter != 2)
                            {
                                if (colCounter == 10)
                                {
                                    colCounter = 13;
                                    worksheet.Cells[tableRowHeaderIdx, 10] = dtViewBidders.Columns[colCounter].ToString();
                                    formatOtherCell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[tableRowHeaderIdx, 10];
                                }
                                else
                                {
                                    worksheet.Cells[tableRowHeaderIdx, colCounter] = dtViewBidders.Columns[colCounter].ToString();
                                    formatOtherCell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[tableRowHeaderIdx, colCounter];
                                }
                                        
                                formatOtherCell.Font.Name = "Calibri";
                                formatOtherCell.Font.Size = "12";
                                formatOtherCell.WrapText = true;
                                formatOtherCell.Font.Bold = true;
                                formatOtherCell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                                //formatOtherCell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                                if (colCounter == 3)
                                    formatOtherCell.ColumnWidth = 12;
                                if (colCounter == 4)
                                    formatOtherCell.ColumnWidth = 15;
                                if (colCounter == 5)
                                    formatOtherCell.ColumnWidth = 28;
                                if (colCounter == 6)
                                    formatOtherCell.ColumnWidth = 14;
                                if (colCounter == 7)
                                    formatOtherCell.ColumnWidth = 14;
                                if (colCounter == 8)
                                    formatOtherCell.ColumnWidth = 14;
                                if (colCounter == 9)
                                    formatOtherCell.ColumnWidth = 16;
                                if (colCounter == 13)
                                    formatOtherCell.ColumnWidth = 17;
                            }

                            SetBorderAroundCells(worksheet, tableRowHeaderIdx); // No. 16 is for Column header
                        }                                

                        //storing Each row and column value to excel sheet
                        for (int iRowCounter = 0; iRowCounter < dgViewBidders.Rows.Count; iRowCounter++)
                        {

                            SetBorderAroundCells(worksheet, iRowCounter + tableDataStartIdx);                                     
                            SetExcelCellFormatAndValue(formatRange,formatA1Cell,color,worksheet,iRowCounter,1,dtViewBidders.Rows[iRowCounter][1].ToString());                                        
                            SetExcelCellFormatAndValue(formatRange,formatA1Cell,color,worksheet,iRowCounter,2,dgViewBidders.Rows[iRowCounter].Cells[2].Value.ToString());
                            SetExcelCellFormatAndValue(formatRange,formatA1Cell,color,worksheet,iRowCounter,3,dgViewBidders.Rows[iRowCounter].Cells[3].Value.ToString());
                            SetExcelCellFormatAndValue(formatRange,formatA1Cell,color,worksheet,iRowCounter,4,dgViewBidders.Rows[iRowCounter].Cells[4].Value.ToString());
                            SetExcelCellFormatAndValue(formatRange,formatA1Cell,color,worksheet,iRowCounter,5,dgViewBidders.Rows[iRowCounter].Cells[5].Value.ToString());
                            SetExcelCellFormatAndValue(formatRange,formatA1Cell,color,worksheet,iRowCounter,6,dgViewBidders.Rows[iRowCounter].Cells[6].Value.ToString());
                            SetExcelCellFormatAndValue(formatRange,formatA1Cell,color,worksheet,iRowCounter,7,dgViewBidders.Rows[iRowCounter].Cells[7].Value.ToString());
                            SetExcelCellFormatAndValue(formatRange,formatA1Cell,color,worksheet,iRowCounter,8,dgViewBidders.Rows[iRowCounter].Cells[8].Value.ToString());
                            SetExcelCellFormatAndValue(formatRange,formatA1Cell,color,worksheet,iRowCounter,9,dgViewBidders.Rows[iRowCounter].Cells[9].Value.ToString());                                       
                            SetExcelCellFormatAndValue(formatRange, formatA1Cell, color, worksheet, iRowCounter, 10, dgViewBidders.Rows[iRowCounter].Cells[13].Value.ToString());                                                                                                                                                                 
                                     
                        }
                    }

                    formatA1CellRange = worksheet.get_Range("D" + (tableDataStartIdx + dgViewBidders.Rows.Count + 1), "D" + (tableDataStartIdx + dgViewBidders.Rows.Count + 1));                            
                    formatA1CellRange.ColumnWidth = 40;
                    formatA1CellRange.FormulaR1C1 = "This report is generated by TCMS dated :" + DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss");
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";                             
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = true;
                                                          
                    }
                     
                    // save the application
                    workbook.SaveAs(saveFileDialog1.FileName, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while creating the excel file", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        
        }

        private void SetBorderAroundCells(Microsoft.Office.Interop.Excel._Worksheet worksheet, int cellIdx)
        {
            for (int asciiCode = 65; asciiCode <= 74; asciiCode++)
            {
                char alphaBet = (char)asciiCode;
                worksheet.get_Range(alphaBet + (cellIdx).ToString(), alphaBet + (cellIdx).ToString()).Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeLeft].Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
                worksheet.get_Range(alphaBet + (cellIdx).ToString(), alphaBet + (cellIdx).ToString()).Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeTop].Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
                worksheet.get_Range(alphaBet + (cellIdx).ToString(), alphaBet + (cellIdx).ToString()).Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeRight].Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
                worksheet.get_Range(alphaBet + (cellIdx).ToString(), alphaBet + (cellIdx).ToString()).Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeBottom].Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
                worksheet.get_Range(alphaBet + (cellIdx).ToString(), alphaBet + (cellIdx).ToString()).RowHeight = 25;
                if (asciiCode == 74)
                    worksheet.get_Range(alphaBet + (cellIdx).ToString(), alphaBet + (cellIdx).ToString()).WrapText = true;
            }
        }

        private void SetExcelCellFormatAndValue(Microsoft.Office.Interop.Excel.Range formatRange, Microsoft.Office.Interop.Excel.Range formatA1Cell, System.Drawing.Color color,
        Microsoft.Office.Interop.Excel._Worksheet worksheet,int rowCounter, int colCounter,string value)
        {
            formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[tableDataStartIdx + rowCounter, colCounter];
            formatA1Cell.Font.Name = "Calibri";
            formatA1Cell.Font.Size = "12";
            //formatA1Cell.Font.Bold = true;
            formatA1Cell.WrapText = true;
            formatRange.RowHeight = 65;
            if (colCounter == 1)
            {
                formatA1Cell.ColumnWidth = 10;
            }
            else
            {
                formatA1Cell.ColumnWidth = 30;                
            }
            formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
            //if (colCounter == 5)
            //{
            //    formatA1Cell.NumberFormat = "Number";
            //}
            //formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
            worksheet.Cells[tableDataStartIdx + rowCounter, colCounter] = value;
        }


                  
    }
    
}
