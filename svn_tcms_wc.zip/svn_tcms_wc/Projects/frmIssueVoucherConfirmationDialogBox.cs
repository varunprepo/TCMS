﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MDI_ParenrForm.Projects
{
    public partial class frmIssueVoucherConfirmationDialogBox : Form
    {
        string mStrCon = null;
        string mTenderNo = null;
        string mCommitteeName = null;
        int mProjId = 0;
        int mNoOfDaysForClosing = 0;
        string mProjTitle = null;
        int mNoOfEnvelopes = 0;
        string[] mCompanyInfo = null;
        string mVersionNo = null;
        bool mIsWorkOrder = false;
        string mIsPrinted = null;
        clsDatabase mClsObj = null;
        string mWorkOrderSubID = null;
        string mNonWoRemarks = null;
        string mWoRemarks = null;
        string mCoId = null;
        string mBidderId = null;
        string mDeliveredBy = null;
        string mWorkOrderId = null;
        string mSelectedWorkOrderInfo = null;
        string mUserName = null;
        DataGridView mDataGridView = null;
        IList<string> mUserRightsColl = null;
        bool mIsHeadOfSection = false;
        bool mIsTenderClosingDateStage2 = false;
        public frmIssueVoucherConfirmationDialogBox(string strCon, string tenderNo, string committeeName, string projTitle, int noOfEnvelopes, string[] companyInfo, string versionNo, bool isWorkOrder,
            string isPrinted, ref MDI_ParenrForm.clsDatabase clsObj, string workOrderSubID, string nonWoRemarks, string woRemarks, string coOrBidderId, string deliveredBy, string workOrderId, ref DataGridView dgvTendererInfo, IList<string> userRightsColl,
            int projId, string selectedWorkOrderInfo, bool isHeadOfSection, string userName, int noOfDaysForClosing, bool isTenderClosingDateStage2)
        {
            InitializeComponent();
            mStrCon = strCon;
            mUserName = userName;
            mTenderNo = tenderNo;
            mCommitteeName = committeeName;
            mProjTitle = projTitle;
            mNoOfEnvelopes = noOfEnvelopes;
            mCompanyInfo = companyInfo;
            lblMessage.Text = "Are you sure in Issuing the Voucher to \n" + companyInfo[1].ToString()+"?";
            mIsWorkOrder = isWorkOrder;
            mIsPrinted = isPrinted;
            mClsObj = clsObj;
            mWorkOrderSubID = workOrderSubID;
            mNonWoRemarks = nonWoRemarks;
            mWoRemarks = woRemarks;
            if (isWorkOrder)
            {
                mCoId = companyInfo[14];
            }
            mBidderId  = coOrBidderId;
            mDeliveredBy = deliveredBy;
            mVersionNo = versionNo;
            mWorkOrderId = workOrderId;
            mDataGridView = dgvTendererInfo;
            mUserRightsColl = userRightsColl;
            mProjId = projId;
            mSelectedWorkOrderInfo = selectedWorkOrderInfo;
            mIsHeadOfSection = isHeadOfSection;
            mNoOfDaysForClosing = noOfDaysForClosing;
            mIsTenderClosingDateStage2 = isTenderClosingDateStage2;
        }

        delegate void DelegateUpdateDataGridView();

        private void btnYes_Click(object sender, EventArgs e)
        {
            CommonClass comCls = new CommonClass(mUserName);
            comCls.ExportToPDF(mStrCon, null, null, null, mTenderNo, mCommitteeName, mProjTitle, 0, null, null, mNoOfEnvelopes, null, null, null, 'T', 'N', null, null, 0, mCompanyInfo, 2, "", 1, mVersionNo, mIsWorkOrder, mIsTenderClosingDateStage2);
            mCompanyInfo[4] = "FC";       // Receipt Number
            mCompanyInfo[5] = "Print_File_Copy";
            comCls.ExportToPDF(mStrCon, null, null, null, mTenderNo, mCommitteeName, mProjTitle, 0, null, null, mNoOfEnvelopes, null, null, null, 'T', 'N', null, null, 0, mCompanyInfo, 2, "", 2, mVersionNo, mIsWorkOrder, mIsTenderClosingDateStage2);

            try
            {


                if (!mIsWorkOrder)
                {
                    if (!mIsTenderClosingDateStage2)
                    {
                        if (mIsPrinted == "")
                            mClsObj.ExecuteNonQuery("update TenderDatesInfo set TenderSubmittedTime = '" + System.DateTime.Now + "',printDeliveredBy = '" + mDeliveredBy + "', VersionNo=" + mVersionNo + ", PrintStatus='Submitted'," +
                            "NoOfEnvelopes='" + mNoOfEnvelopes + "',TenderSubmissionRemarks='" + mNonWoRemarks + "',eval_tendersubmission_stage = 1 where date_id =" + mBidderId);
                        else
                            mClsObj.ExecuteNonQuery("update TenderDatesInfo set TenderSubmittedTime = '" + System.DateTime.Now + "',printDeliveredBy = '" + mDeliveredBy + "', VersionNo=" + mVersionNo + ", PrintStatus='Re-Submitted'," +
                            "NoOfEnvelopes='" + mNoOfEnvelopes + "',TenderSubmissionRemarks='" + mNonWoRemarks + "',eval_tendersubmission_stage = 1 where date_id =" + mBidderId);
                    }
                    else
                    {
                        if (mIsPrinted == "")
                            mClsObj.ExecuteNonQuery("update TenderDatesInfo set TenderSubmittedTime = '" + System.DateTime.Now + "',printDeliveredBy = '" + mDeliveredBy + "', VersionNo=" + mVersionNo + ", PrintStatus='Submitted'," +
                            "NoOfEnvelopes='" + mNoOfEnvelopes + "',TenderSubmissionRemarks='" + mNonWoRemarks + "',Tender_Issued=1 where date_id =" + mCompanyInfo[3]);
                        else
                            mClsObj.ExecuteNonQuery("update TenderDatesInfo set TenderSubmittedTime = '" + System.DateTime.Now + "',printDeliveredBy = '" + mDeliveredBy + "', VersionNo=" + mVersionNo + ", PrintStatus='Re-Submitted'," +
                            "NoOfEnvelopes='" + mNoOfEnvelopes + "',TenderSubmissionRemarks='" + mNonWoRemarks + "',Tender_Issued=1 where date_id =" + mCompanyInfo[3]);

                    }

                }
                else
                {
                    if (mIsPrinted == "")
                    {
                        if (mWorkOrderSubID != "")
                            mClsObj.ExecuteNonQuery("update WorkOrderSubmissions set TenderSubmittedTime = '" + System.DateTime.Now + "',printDeliveredBy = '" + mDeliveredBy + "', VersionNo=" + mVersionNo + ", PrintStatus='Submitted'," +
                            "NoOfEnvelopes='" + mNoOfEnvelopes + "',TenderSubmissionRemarks='" + mWoRemarks + "',workOrderID =" + mWorkOrderId + ",bidder_Id=" + mBidderId + " where workOrderSubmissionID =" + mWorkOrderSubID);   //"                      
                        else
                            mClsObj.ExecuteNonQuery("update WorkOrderSubmissions set TenderSubmittedTime = '" + System.DateTime.Now + "',printDeliveredBy = '" + mDeliveredBy + "', VersionNo=" + mVersionNo + ", PrintStatus='Submitted'," +
                            "NoOfEnvelopes='" + mNoOfEnvelopes + "',TenderSubmissionRemarks='" + mWoRemarks + "' where workOrderID =" + mWorkOrderId + " and bidder_Id=" + mBidderId + " and co_id=" + mCoId); //+ " and proj_Id="+mProjId                                                           
                    }
                    else
                        mClsObj.ExecuteNonQuery("update WorkOrderSubmissions set TenderSubmittedTime = '" + System.DateTime.Now + "',printDeliveredBy = '" + mDeliveredBy + "', VersionNo=" + mVersionNo + ", PrintStatus='Re-Submitted'," +
                        "NoOfEnvelopes='" + mNoOfEnvelopes + "',TenderSubmissionRemarks='" + mWoRemarks + "',workOrderID =" + mWorkOrderId + ",bidder_Id=" + mBidderId + " where workOrderSubmissionID =" + mWorkOrderSubID); //bidder_Id=" + bidderId + "
                }

                mClsObj.DisconnectDB();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while updating the details of the company. Please inform to System Administrator.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            //mDataGridView.BeginInvoke(new DelegateUpdateDataGridView();
            comCls.Populate(ref mDataGridView, mUserRightsColl, mStrCon, mProjId, mSelectedWorkOrderInfo, mIsWorkOrder, mIsHeadOfSection, mNoOfDaysForClosing, mIsTenderClosingDateStage2);
            this.Close();
        }

        private void btnNo_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
