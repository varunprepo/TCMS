﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using MDI_ParenrForm;

namespace TenderTrackingSystem
{
    public partial class SentDocProperties : Form
    {
        //string strTableName = null;
        static int projId = 0;
        static short stageId = 0;
        static string tenderNo = null;

        string strPrjCode = string.Empty;
      
        DAL dalObj = null;
        static int _projId = 0;
        int _docId = 0; Int16 _stageID = 0;
        int _circularNo = 0;
        int _docType = 0;
        Boolean chkUpdateMode = false;
        IList<string> userRightsColl = new List<string>();
        string _userName = string.Empty;
        private string strCon = ConfigurationManager.AppSettings["TCMSConnString"].ToString();
        DataGridView _dgvTS_Sent = null;
        static char setUpdate = 'N';

        Boolean Chk_TFE_sentdoc = false;
        bool _isHeadOfSection = false;
        public SentDocProperties(IList<string> userRightsCollSent, int PrjID, string prjCode, int docId, Int16 stageID, string user, object circularNo, char update, bool isHeadOfSection)  // Edit Mode 
        {
            InitializeComponent();
            
            dalObj = new DAL();
            _projId = PrjID;
            strPrjCode = prjCode;
            _docId = docId;
            _stageID = stageID;
            chkUpdateMode = true;             
            userRightsColl = userRightsCollSent;
            setUpdate = update;
            _userName = user;
            _isHeadOfSection = isHeadOfSection;
            if (circularNo != "")
                _circularNo = Convert.ToInt32(circularNo);
             
            //if (userRightsColl.Contains("21"))
            //{
            //    MessageBox.Show("You have no privilege,Contact administrator");
            //    return;
            //}            
            
            //btnDelete.Visible = true;
            lblCircularNo.Text = "";                       
         }
        public SentDocProperties(IList<string> userRightsCollSent, int PrjID, Int16 stageID, string user )                 //int PrjID,string prjCode,int docId
        {
            InitializeComponent();

            dalObj = new DAL();
            _projId = PrjID;
            _stageID = stageID;

            userRightsColl = userRightsCollSent;
            //if (userRightsColl.Contains("20"))
            //{
            //    MessageBox.Show("You have no privilege,Contact administrator");
            //    return;
            //}

            _userName = user;
            
           // btnDelete.Visible = false;
            lblCircularNo.Text = "";
            //if (_stageID == 2)
            //    setCircularNo(_stageID);
            
        }
        public SentDocProperties(IList<string> userRightsCollSent, int docID, int Proj_ID, int docType, Int16 stageID, string user, object circularNo)
        {
            InitializeComponent();
            dalObj = new DAL();
            _projId = Proj_ID;           
            _docId = docID;
            if(docType!=0)
                _docType = docType;
            _stageID = stageID;
            chkUpdateMode = true;
            _userName = user;

            if (circularNo != "")
                _circularNo = Convert.ToInt16(circularNo);

            userRightsColl = userRightsCollSent;

            lblCircularNo.Text = "";
            this.txtSDactdays.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSDactdays_KeyDown);
            this.txtSDactdays.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSDactdays_KeyPress);
        }
        public SentDocProperties(IList<string> userRightsCollSent, int PrjID, Int16 stageID, string user,Boolean Chk_TFE_SentDoc)                 //int PrjID,string prjCode,int docId
        {
            InitializeComponent();

            dalObj = new DAL();
            _projId = PrjID;
            _stageID = stageID;
            userRightsColl = userRightsCollSent;           
            _userName = user;         
            lblCircularNo.Text = "";

            Chk_TFE_sentdoc = Chk_TFE_SentDoc;

        }
        
        byte[] attFile = null;
        string attFileName = string.Empty;

        public void populateSDPUploadFiles(ListBox lstBox, int paramProjId, short paramStageId, string paramTenderNo, string paramUserName)
        {
            for (int iCtrl = 0; iCtrl < lstBox.Items.Count; iCtrl++)
                this.lstSDPUploadedFiles.Items.Add(lstBox.Items[iCtrl].ToString());

            projId = paramProjId;
            stageId = paramStageId;
            tenderNo = paramTenderNo;
            userName = paramUserName;
        }
 
        string projStage = null;
        public string setProjectStages
        {
            get
            {
                return projStage;
            }
            set
            {
                this.projStage = value;
            }
        }
 
        private void btnSDPFileUpload_Click(object sender, EventArgs e)
        {
            addMultipleFiles(ref attFileName);
        }
        

        ImageList imageList1 = new ImageList();
        private void addMultipleFiles(ref string _fileName)
        {
            System.IO.FileStream fileStream = null;
            System.IO.BinaryReader binaryReader = null;
             
            byte[] buffer = null;
            //lstRDPUploadedFiles.Items.Clear();
            try
            {
                OpenFileDialog op1 = new OpenFileDialog();
                op1.Multiselect = true;
                op1.ShowDialog();
                long totBytes = 0;


                if (op1.FileNames.Count() != 0)
                {                     
                    SqlCommand sqlCommand = new SqlCommand();
                    sqlCommand.Connection = sqlConn;
                    foreach (string s in op1.FileNames)
                    {
                       if(s.Contains("."))
                       {                            
                            string[] strColl = s.Split('\\');
                            string fileName = strColl[strColl.Length - 1];
                            fileStream = new System.IO.FileStream(s, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                            binaryReader = new System.IO.BinaryReader(fileStream);
                            totBytes = new System.IO.FileInfo(s).Length;
                            buffer = binaryReader.ReadBytes((Int32)totBytes);                           

                            ListViewItem lstItem = new ListViewItem();

                            lstItem.Text = fileName;
                            lstItem.Tag = buffer;
                            lstSDPUploadedFiles.View = View.LargeIcon;

                            imageList1.ImageSize = new Size(32, 32);                             

                            lstSDPUploadedFiles.Items.Add(lstItem);    
                        }
                        else                    
                            MessageBox.Show("Attached filename does not contain file extension, Please attach files with extensions", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                    fileStream.Close();
                    fileStream.Dispose();
                    binaryReader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error While Uploading the images, try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            
        }
        private void btnSDPRemoveAttachment_Click(object sender, EventArgs e)
        {
            if (lstSDPUploadedFiles.Items.Count > 0 && lstSDPUploadedFiles.SelectedIndices.Count == 0)
                MessageBox.Show("No Item is selected, Please select an Item", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
            {
                 DialogResult dlgResult = DialogResult.Yes;             
                dlgResult = MessageBox.Show("Are you sure you want to DELETE this Document?", "Delete Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (dlgResult.ToString() == "Yes")
                {
                    lstSDPUploadedFiles.Items.Remove(lstSDPUploadedFiles.SelectedItems[0]);
                }

            }  
        }



        //Dictionary<int, string> existedSentAttachments = new Dictionary<int, string>();
        SqlConnection sqlConn = null;
        CommonClass comCls = null;
        private void LoadSentDocInfo()
        {             
            sqlConn = new SqlConnection(strCon);
            try
            {
                sqlConn.Open();

                string sqlQuery = null;
                if (_stageID == 2)
                {
                     sqlQuery = "SELECT docs.doc_category_id, docs.doc_type_id, docs.employee_id, docs.doc_status_id, docs.ref_no, docs.cross_ref_no, docs.subject, docs.doc_date, " +
                     " docs.doc_issue_date, docs.days_to_act, docs.no_need_to_reply, docs.remarks, docs.attFileName, docs.attFile, docCat.doc_category_name, " +
                     " docStatus.doc_status_name, docType.doc_type_name, cts.FirstName, cts.LastName, cmp.co_name, docs.CircularNo " +
                     " FROM  DOCUMENTS AS docs INNER JOIN DocumentCategory AS docCat ON docs.doc_category_id = docCat.doc_category_id INNER JOIN DocumentType AS docType ON docs.doc_type_id = docType.doc_type_id INNER JOIN " +
                     " DocumentStatus AS docStatus ON docs.doc_status_id = docStatus.doc_status_id INNER JOIN Contacts AS cts ON docs.employee_id = cts.employee_id INNER JOIN COMPANY AS cmp ON docs.co_id = cmp.co_id " +
                     " WHERE (docs.doc_id = " + _docId + " and proj_id =" + _projId + ")";
                }
                else if (_stageID != 2)
                {
                     sqlQuery = "SELECT docs.doc_category_id, docs.doc_type_id, docs.employee_id, docs.doc_status_id, docs.ref_no, docs.cross_ref_no, docs.subject, docs.doc_date, " +
                     " docs.doc_issue_date, docs.days_to_act, docs.no_need_to_reply, docs.remarks, docs.attFileName, docs.attFile, docCat.doc_category_name, " +
                     " docStatus.doc_status_name, docType.doc_type_name, cts.FirstName, cts.LastName, cmp.co_name " +
                     " FROM  DOCUMENTS AS docs INNER JOIN DocumentCategory AS docCat ON docs.doc_category_id = docCat.doc_category_id INNER JOIN DocumentType AS docType ON docs.doc_type_id = docType.doc_type_id INNER JOIN " +
                     " DocumentStatus AS docStatus ON docs.doc_status_id = docStatus.doc_status_id INNER JOIN Contacts AS cts ON docs.employee_id = cts.employee_id INNER JOIN COMPANY AS cmp ON docs.co_id = cmp.co_id " +
                     " WHERE (docs.doc_id = " + _docId + " and proj_id =" + _projId + ")";
                }
     
                SqlCommand sqlCommand = new SqlCommand(sqlQuery, sqlConn);
                SqlDataReader sqlReader = sqlCommand.ExecuteReader();
                comCls = new CommonClass(_userName);
                while (sqlReader.Read())
                {
                    //docID = Convert.ToInt16(sqlReader[0].ToString());
                    txtSDPRefNo.Text = sqlReader[4].ToString();
                    txtSDPSubject.Text = sqlReader[6].ToString();
                    cmbTypeOfDoc.Text = sqlReader[16].ToString();
                    if (cmbTypeOfDoc.Text != "Communication" && _stageID == 2) 
                    {
                        if (sqlReader[20].ToString() == "")
                            lblCircularNo.Text = comCls.GetMaxInfo("SELECT MAX(CircularNo) FROM DOCUMENTS where proj_id=" + _projId + " AND (date_id IS NULL) AND (doc_type_id = 2) AND (CircularNo IS NOT NULL)", 'N').ToString();
                        else
                            lblCircularNo.Text = sqlReader[20].ToString();                         
                    }
                    else
                    {
                        lblCircularNo.Text = "";                         
                    }
                    cmbSentDocRefNo.Text = sqlReader[5].ToString();
                    cmbSDPSentTo.Text = sqlReader[17].ToString() + " " + sqlReader[18].ToString();
                    txtSDactdays.Text = sqlReader[9].ToString();
                   // lstSDPUploadedFiles.Items.Add(sqlReader[13].ToString());

                    dtpSentdoc.Text = sqlReader[7].ToString();
                    dtpSentDocRec.Text = sqlReader[8].ToString();

                    if (sqlReader[12].ToString() != "")
                    {
                        ListViewItem lstItem = new ListViewItem();
                        lstItem.Text = sqlReader[12].ToString().Split(',')[0].ToString();                         
                        lstItem.Tag = (byte[])sqlReader[13];
                        lstFileCollSent.Items.Add(lstItem);
                    }
                    if (sqlReader[15].ToString() == "Closed")
                        chkBoxSDPNoResponse.Checked = true;
                    cmbSentStatus.Text = sqlReader[15].ToString();                    
                    cmbCompany.Text = sqlReader[19].ToString();                    

                }
                sqlReader.Close();
                sqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
             
            //existedSentAttachments.Clear();
            try
            {
                //sqlConn.Open();
                string sqlQuery = "SELECT attFile,attFileName FROM Attachments WHERE (doc_id = " + _docId + ")";

                SqlCommand sqlCommand = new SqlCommand(sqlQuery, sqlConn);
                SqlDataReader sqlReader = sqlCommand.ExecuteReader();
                if (sqlReader.HasRows)
                {
                    chkSaveemode = true;
                    while (sqlReader.Read())
                    {
                        //docID = Convert.ToInt16(sqlReader[2].ToString());

                        ListViewItem lstItem = new ListViewItem();
                        lstItem.Text = sqlReader[1].ToString();
                        if (sqlReader[0] != DBNull.Value)
                            lstItem.Tag = (byte[])sqlReader[0];                         
                        lstSDPUploadedFiles.Items.Add(lstItem);

                        //existedSentAttachments.Add(Convert.ToInt16(sqlReader[2].ToString()), sqlReader[1].ToString());
                    }
                }
                sqlReader.Close();


                //sqlQuery = "SELECT attFile,attFileName FROM Documents WHERE (doc_id = " + _docId + ")";

                //sqlCommand = new SqlCommand(sqlQuery, sqlConn);
                //sqlReader = sqlCommand.ExecuteReader();
                //while (sqlReader.HasRows)
                //{
                //    ListViewItem lstItem = new ListViewItem();
                //    lstItem.Text = sqlReader[1].ToString();
                //    if (sqlReader[0] != DBNull.Value)
                //        lstItem.Tag = (byte[])sqlReader[0];
                //    lstSDPUploadedFiles.Items.Add(lstItem);
                //}

                //sqlReader.Close();
                sqlCommand.Dispose();
                //attFile = getImage(ref attFileName); 
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }
        }         

        static string userName = "";         
        private void ReceiveDocumentInfo()
        {

        }
        private void btnSDPSubmit_Click(object sender, EventArgs e)
        {             
            //static int projId = 0;
            ProjectStages psObj = new ProjectStages(userRightsColl, "", projId, null,_userName, null, _isHeadOfSection);     //(1,1,null,null,userName);
            DAL dalObj = null;
            int docId = 0;
            int docCatId = 1;

            using (SqlConnection sqlConn = new SqlConnection(strCon))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = @"Select MAX(doc_id) FROM DOCUMENT";
                    sqlConn.Open();
                    cmd.Connection = sqlConn;
                    docId = Convert.ToInt32(cmd.ExecuteScalar());
                    docId = docId + 1;
                    sqlConn.Close();
                }
            }
            byte[] fileImage = attFile;
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        int stage_Id = 0;
                        stage_Id = 1;
                        string[] attFileColl = attFileName.Split('\\');
                        
                        string _fileName = attFileColl[attFileColl.Length - 1];
                        cmd.CommandText = @"Insert Into DOCUMENTS(doc_id,doc_category_id,doc_type_id, proj_id, stage_id, doc_status_id,ref_no,cross_ref_no,employee_id,doc_date,doc_issue_date, attfile,attFileName,days_to_act,subject,filepath)" +
                        " values(@docid,@doccatId,@doctypeId,@projId,@stageId,@docStatusId,@refNo,@crsRefNo,@empId,@docdate,@docIssuedate,@attFile,@attFileName,@daystoact,@Docsubject,@filepath)"; //,@File    //@days_to_act,
                        
                        cmd.Parameters.AddWithValue("@docid", docId);
                        cmd.Parameters.AddWithValue("@doccatId", 2);
                        cmd.Parameters.AddWithValue("@doctypeId", cmbTypeOfDoc.SelectedValue);
                        cmd.Parameters.AddWithValue("@projId", projId);
                        cmd.Parameters.AddWithValue("@stageId", stage_Id);
                        cmd.Parameters.AddWithValue("@docStatusId", cmbSentStatus.SelectedValue);
                        cmd.Parameters.AddWithValue("@refNo", txtSDPRefNo.Text.Trim());
                        cmd.Parameters.AddWithValue("@crsRefNo", cmbSentDocRefNo.Text);
                        cmd.Parameters.AddWithValue("@empId", cmbSDPSentTo.SelectedValue);
                        cmd.Parameters.AddWithValue("@docdate", dtpSentdoc.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@docIssuedate", dtpSentDocRec.Value.ToString("dd/MMM/yyyy"));

                        if (fileImage.Length == 0)
                        { 
                            cmd.Parameters.AddWithValue("@attFile", new byte[0]);
                        }
                        else
                        { 
                            cmd.Parameters.AddWithValue("@attFile", fileImage);
                            string specialChars = "`~!@#$%^&*(){}:<>?|[];";
                            foreach (char item in specialChars)
                            {
                                _fileName = _fileName.Replace(item.ToString(), "");
                            }
                        }
                        
                        cmd.Parameters.AddWithValue("@attFileName", _fileName);
                        cmd.Parameters.AddWithValue("@filepath", docId + "_" + txtSDPRefNo.Text.Trim());
                        if (txtSDactdays.Text != "")
                        { cmd.Parameters.AddWithValue("@daystoact", Convert.ToInt16(txtSDactdays.Text)); }
                        else
                        { cmd.Parameters.AddWithValue("@daystoact", 0); }
                        cmd.Parameters.AddWithValue("@Docsubject", txtSDPSubject.Text);
                        
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        MessageBox.Show("Received Document details added Succesfully");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE Sent Doc records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }                
        }
        private void chkBoxSDPCheckResponse_CheckedChanged(object sender, EventArgs e)
        {
            if (chkBoxSDPNoResponse.Checked == true)
            {
                txtSDactdays.Text = "";
            }

            //Based on Riyas Request on 20/Dec/2016 Doc Status will always remained closed
            //if ((chkBoxSDPNoResponse.Checked == true) & (txtSDactdays.Text == ""))
            //    cmbSentStatus.SelectedIndex = 3;
            //else if ((chkBoxSDPNoResponse.Checked == false) & (txtSDactdays.Text != ""))
            //    cmbSentStatus.SelectedIndex = 0;
            //else if ((chkBoxSDPNoResponse.Checked == false) & (txtSDactdays.Text == "")) 
                cmbSentStatus.SelectedIndex = 3;
        }
        private void SentDocProperties_Load(object sender, EventArgs e)
        {             
            DAL dalObj = new DAL();
            dalObj.PopulateComboBox(cmbTypeOfDoc, "Select doc_type_id,doc_type_name From [DocumentType]", "doc_type_id", "doc_type_name");
            cmbTypeOfDoc.SelectedIndex = 0;

            if (_stageID == 2 || _circularNo != 0)
                cmbTypeOfDoc.SelectedIndex = 1;
            else
                cmbTypeOfDoc.SelectedIndex = 0;


            string sqlQuery = @"SELECT co_id, co_name, block_listed FROM COMPANY ORDER BY co_name";
            if (_stageID == 2)
            {
                dalObj.PopulateComboBox(cmbSDPSentTo, "SELECT employee_id, FirstName + ' ' + LastName AS PersonName, ShortName, AuthorizedRep,co_id FROM Contacts Order by FirstName", "employee_id", "PersonName");
                cmbSDPSentTo.SelectedIndex = -1;
                
                gnrlCls.PopulateComboBox(cmbCompany, sqlQuery, "co_id", "co_name");
                cmbCompany.SelectedIndex = -1;
            }
            else
            {
                dalObj.PopulateComboBox(cmbSDPSentTo, "SELECT employee_id, FirstName + ' ' + LastName AS PersonName, ShortName, AuthorizedRep,co_id FROM Contacts where employee_id<>83 Order by FirstName", "employee_id", "PersonName");
                cmbSDPSentTo.SelectedIndex = -1;

                sqlQuery = @"SELECT co_id, co_name, block_listed FROM COMPANY where co_id<>425 ORDER BY co_name";
                gnrlCls.PopulateComboBox(cmbCompany, sqlQuery, "co_id", "co_name");
                cmbCompany.SelectedIndex = -1;

                if (Chk_TFE_sentdoc == true)
                txtSDPSubject.Text = "Technical & Financial Evaluation";
            }

            dalObj.PopulateComboBox(cmbSentStatus, "SELECT [DocumentStatus].[doc_status_id], [DocumentStatus].[doc_status_name] FROM [DocumentStatus] ORDER BY [doc_status_id]", "doc_status_id", "doc_status_name");
            cmbSentStatus.SelectedIndex = 3;

            dalObj.PopulateComboBox(cmbSentDocRefNo, "SELECT distinct doc_id,ref_no FROM Documents Where doc_category_id = 2 and Proj_id = " + _projId + "  and ref_no is not null and date_id is null", "doc_id", "ref_no");
            cmbSentDocRefNo.SelectedIndex = -1;            

            if (_docId!=0)
                LoadSentDocInfo();
            else if (_stageID == 2)
                setCircularNo(_stageID);
            else
            {       
                lblCircularNo.Text = "";
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Contacts.frmContactPerson contacts = new Contacts.frmContactPerson(userRightsColl, _userName,false);
            contacts.StartPosition = FormStartPosition.CenterParent;
            contacts.ShowDialog();
        }


                   
        
        Boolean chkSaveemode = false;
        string loadedFileInlist = string.Empty;
        //private void cmbSDPSentTo_EnterKeyPressed(object sender, KeyPressEventArgs e)
        //{
        //    if (e.KeyChar == 13)
        //    {
        //        if (cmbTypeOfDoc.Text == "Circular" && cmbSDPSentTo.Text != "All Bidders")
        //        {                    
        //            MessageBox.Show("Circular can not be issued to only one company, Please select All Bidders");
        //            cmbSDPSentTo.Text = "";
        //            cmbSDPSentTo.Focus();
        //            return;
        //        }
        //        else if (cmbTypeOfDoc.Text == "Communication" && cmbSDPSentTo.Text == "All Bidders")
        //        {
        //            MessageBox.Show("Communication can not be issued to All Bidders, Please select specific company");                     
        //            cmbSDPSentTo.Text = "";
        //            cmbSDPSentTo.Focus();
        //            return;
        //        }
        //        else                     
        //            populateCompanyCmb();

        //    }
        //}

        //Added by Varun on 01 Dec 2015
        private string CheckArabicCharactersInFileName(string fileName)
        {
            StringBuilder strBuildFileName = new StringBuilder();
            foreach (char c in fileName)
            {
                if (c >= 32 && c <= 126)
                {
                    strBuildFileName.Append(c);
                }

            }
            string fileNameWithoutSpace = strBuildFileName.ToString().Replace(" ", "").ToString();
            if (fileNameWithoutSpace.Split('.')[0].Length == 0)
                fileName = "FileName_With_Arabic_Text." + fileName.Split('.')[1];
            else
                fileName = fileNameWithoutSpace;
            return fileName;
        }

        private void btnRDPSubmit_Click(object sender, EventArgs e)
        {
            if (userRightsColl.Contains("21"))    //   * Edit Document Details
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }
            //if (cmbTypeOfDoc.Text == "Circular" && cmbSDPSentTo.Text != "All Bidders")
            //{
            //    MessageBox.Show("Circular can not be issued to only one company, Please select All Bidders");
            //    cmbSDPSentTo.Text = "";
            //    cmbSDPSentTo.Focus();
            //    return;
            //}
            //else if (cmbTypeOfDoc.Text == "Communication" && cmbSDPSentTo.Text == "All Bidders")
            //{
            //    MessageBox.Show("Communication can not be issued to All Bidders, Please select specific company");
            //    cmbSDPSentTo.Text = "";
            //    cmbSDPSentTo.Focus();
            //    return;
            //}
            if (cmbCompany.SelectedValue == null)
            {
                MessageBox.Show("Company Name can not be left blank, Please select a company name");
                cmbCompany.Focus();
                return;
            }
            if (chkUpdateMode == false)
            {
                if (lstFileCollSent.Items.Count != 0)
                {
                    SaveDocumentSentInfo();
                }
                else
                {
                    MessageBox.Show("File attachment cannot be blank. Please attach a file. Saving of the Received Document is not allowed without an attached file.");
                    lstFileCollSent.Focus();
                }
            }    
            else
            {

                if (lstFileCollSent.Items.Count != 0)
                {
                    if (ValidateSentDoc() == true)
                        UpdateDocumentSentInfo();
                }
                else
                {
                    MessageBox.Show("File attachment cannot be blank. Please attach a file. Saving of the Received Document is not allowed without an attached file.");
                    lstFileCollSent.Focus();
                }               
            }
             
        }
        private void UpdateDocumentSentInfo()
        {
            UpdateWithImage();

            //if (chkFile == true)
            //{
            //    UpdateWithImage();
            //}
            //else
            //{
            //    UpdateWithoutImage();
            //}            
        }
        private void UpdateWithImage()
        {
            string attFileName = string.Empty;
            string _fileName = null;
            string[] attFileColl = null;
            byte[] fileImage = null;            
            //StringBuilder strBuilder = new StringBuilder();
            if (strfileColl.Count > 0)
            {
                attFileName = strfileColl[0];
                fileImage = attFile;
                attFileColl = attFileName.Split('\\');
                _fileName = attFileColl[attFileColl.Length - 1];
            }
            else if (lstFileCollSent.Items.Count > 0)
            {
                _fileName = lstFileCollSent.Items[0].Text;
                fileImage = (byte[])lstFileCollSent.Items[0].Tag;
            }

            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        if (fileImage == null)
                        {
                            cmd.CommandText = @"UPDATE DOCUMENTS SET CircularNo=@circularNo, " +
                            " doc_type_id = @docTypeID,employee_id = @empID, " +
                            " doc_status_id = @docStatusId,ref_no = @refNo,cross_ref_no = @crsRefNo,subject = @Docsubject,doc_date =@docdate, " +
                            " doc_issue_date = @docIssuedate,days_to_act = @daystoact,attFilename = @att_FileName,co_id = @cmpID,update_date = @updateDate,update_user = @updateUser, " +
                            " filepath=@filepath Where doc_id = @docId";
                        }
                        else
                        {
                            cmd.CommandText = @"UPDATE DOCUMENTS SET CircularNo=@circularNo, " +
                           " doc_type_id = @docTypeID,employee_id = @empID, " +
                           " doc_status_id = @docStatusId,ref_no = @refNo,cross_ref_no = @crsRefNo,subject = @Docsubject,doc_date =@docdate, " +
                           " doc_issue_date = @docIssuedate,days_to_act = @daystoact,attFile = @attFile,attFilename = @att_FileName,co_id = @cmpID,update_date = @updateDate,update_user = @updateUser, " +
                           " filepath=@filepath Where doc_id = @docId";
                        }
                        
                        cmd.Connection = sqlConn;
                        cmd.Parameters.AddWithValue("@docId", _docId);                         
                        cmd.Parameters.AddWithValue("@docTypeID", cmbTypeOfDoc.SelectedValue);
                        if (Convert.ToInt16(cmbTypeOfDoc.SelectedValue) == 2 && lblCircularNo.Text != "")
                            cmd.Parameters.AddWithValue("@circularNo", Convert.ToInt16(lblCircularNo.Text));
                        else
                            cmd.Parameters.AddWithValue("@circularNo", DBNull.Value);                       
                        
                        cmd.Parameters.AddWithValue("@docStatusId", cmbSentStatus.SelectedValue);
                        cmd.Parameters.AddWithValue("@refNo", txtSDPRefNo.Text.Trim());
                        cmd.Parameters.AddWithValue("@crsRefNo", cmbSentDocRefNo.Text);
                        cmd.Parameters.AddWithValue("@empID", cmbSDPSentTo.SelectedValue);
                        cmd.Parameters.AddWithValue("@docdate", dtpSentdoc.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@docIssuedate", dtpSentDocRec.Value.ToString("dd/MMM/yyyy"));
                        
                        if (fileImage != null)
                        {
                            cmd.Parameters.AddWithValue("@attFile", fileImage);
                        }                        

                        if (_fileName!=null)
                        {
                            _fileName = CheckArabicCharactersInFileName(_fileName);
                            string specialChars = "`~!@#$%^&*(){}:<>?|[];";                             
                            foreach (char item in specialChars)
                            {
                                _fileName = _fileName.Replace(item.ToString(), "");
                            }
                            cmd.Parameters.AddWithValue("@att_FileName", _fileName);
                            cmd.Parameters.AddWithValue("@filepath", _docId + "_" + txtSDPRefNo.Text.Trim());
                        }
                        else
                        {
                            cmd.Parameters.AddWithValue("@att_FileName", DBNull.Value);
                            cmd.Parameters.AddWithValue("@filepath", DBNull.Value);
                        }
                         
                        if (txtSDactdays.Text != "")
                        { cmd.Parameters.AddWithValue("@daystoact", Convert.ToInt16(txtSDactdays.Text)); }
                        else
                        { cmd.Parameters.AddWithValue("@daystoact", 0); }
                        cmd.Parameters.AddWithValue("@Docsubject", txtSDPSubject.Text);
                        cmd.Parameters.AddWithValue("@cmpID", cmbCompany.SelectedValue);

                        cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@updateUser", _userName);

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        cmd.Dispose();

                        // Added By Varun for inserting the circular issued info to the existing bidders 

                        if (cmbTypeOfDoc.SelectedValue.ToString() == "2")
                        {
                            int docId = comCls.GetMaxInfo("Select MAX(doc_id) FROM DOCUMENTS", 'Y');
                            short dtRowCounter = 0;
                            DataTable dtDatesId = dalObj.GetDataFromDB("DateIds", "select date_id,co_id,employee_id from TenderDatesInfo WHERE (co_id IS NOT NULL and proj_id=" + _projId + " and Tender_Issued=1)");
                            while (dtRowCounter < dtDatesId.Rows.Count)
                            {
                                if (comCls.ExecuteReaderQuery("select doc_id from DOCUMENTS where date_id=" + dtDatesId.Rows[dtRowCounter][0] + " and proj_id=" + _projId, sqlConn) == 0)
                                {
                                    comCls.insertStatement(cmd, docId, Convert.ToInt32(dtDatesId.Rows[dtRowCounter][0]), Convert.ToInt16(cmbTypeOfDoc.SelectedValue), _projId,
                                    _stageID, Convert.ToInt16(cmbSentStatus.SelectedValue), txtSDPRefNo.Text.Trim(), cmbSentDocRefNo.Text, Convert.ToInt32(dtDatesId.Rows[dtRowCounter][2]),
                                    dtpSentdoc.Value.ToString("dd/MMM/yyyy"), dtpSentDocRec.Value.ToString("dd/MMM/yyyy"), null, _fileName, txtSDactdays.Text, txtSDPSubject.Text, 
                                    Convert.ToInt32(dtDatesId.Rows[dtRowCounter][1]), Convert.ToInt16(lblCircularNo.Text), 'C');
                                    exUpdated = cmd.ExecuteNonQuery();
                                    cmd.Parameters.Clear();
                                    docId += 1;
                                }
                                dtRowCounter++;
                            }
                        }
                        else
                        {
                            if(lblCircularNo.Text!="")
                                DeleteCirculars(Convert.ToInt16(lblCircularNo.Text), _projId);
                        }

                    }
                    using (SqlCommand command = new SqlCommand())
                    {
                        command.CommandText = @"DELETE FROM Attachments WHERE doc_Id = @docID";
                        command.Connection = sqlConn;
                        command.Parameters.AddWithValue("@docID", _docId);
                        int ex = command.ExecuteNonQuery();
                        command.Dispose();
                    }
                    
                    foreach (ListViewItem item in lstSDPUploadedFiles.Items)
                    {
                        using (SqlCommand command = new SqlCommand())
                        {
                            command.CommandText = @"INSERT INTO Attachments(attFileName, attFile,doc_ID,create_date,create_user,filepath) VALUES (@FileName, @File,@docID,@createDate,@createUser,@filepath)";
                            command.Connection = sqlConn;
                            item.Text = CheckArabicCharactersInFileName(item.Text);
                            string specialChars = "`~!@#$%^&*(){}:<>?|[];";
                            foreach (char fChar in specialChars)
                            {
                                item.Text = item.Text.Replace(fChar.ToString(), "");
                            }
                            command.Parameters.AddWithValue("@FileName", item.Text);
                            command.Parameters.AddWithValue("@File", item.Tag);
                            command.Parameters.AddWithValue("@docID", _docId);
                            command.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                            command.Parameters.AddWithValue("@createUser", _userName);
                            command.Parameters.AddWithValue("@filepath", _docId + "_" + item.Text);
                            int ex = command.ExecuteNonQuery();                                
                            command.Dispose();                                
                        }
                    } 
                }
                MessageBox.Show("Data Updated Successfully");
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
             
        }
         
        private void SaveDocumentSentInfo()
        {
            Boolean chkCntrls = ValidateSentDoc();
            if (chkCntrls == false)
                return;
            if (checkDuplicateRefNo() == false)
                return;             
            InsertSentDoc(Convert.ToInt16(cmbTypeOfDoc.SelectedValue));
        }
        

        private void InsertSentDoc(Int16 cmbSelection)
        {
            CommonClass comCls = new CommonClass(_userName);
            int docId = comCls.GetMaxInfo("Select MAX(doc_id) FROM DOCUMENTS", 'Y');
            byte[] fileImage = attFile;
            DataTable dtDatesId = null;
            int iSNo = 0;
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        StringBuilder strBuilder = new StringBuilder();

                        foreach (ListViewItem item in lstFileCollSent.Items)
                            strBuilder.Append(item.Text);

                        string fileName = null;
                        string specialChars = "`~!@#$%^&*(){}:<>?|[];";
                        if (strBuilder.Length != 0)
                        {
                            fileName = CheckArabicCharactersInFileName(strBuilder.ToString());
                            
                            foreach (char charVal in specialChars)
                            {
                                fileName = fileName.Replace(charVal.ToString(), "");
                            }
                        }
                        if (lstSDPUploadedFiles.Items.Count == 0)
                        {                      
                            if (cmbSelection == 1)
                            {
                                if (strBuilder.Length == 0)
                                    comCls.insertStatement(cmd, docId, 0, Convert.ToInt16(cmbTypeOfDoc.SelectedValue), _projId, _stageID, Convert.ToInt16(cmbSentStatus.SelectedValue), txtSDPRefNo.Text.Trim(), cmbSentDocRefNo.Text,
                                    Convert.ToInt16(cmbSDPSentTo.SelectedValue), dtpSentdoc.Value.ToString("dd/MMM/yyyy"), dtpSentDocRec.Value.ToString("dd/MMM/yyyy"), null, null, txtSDactdays.Text, txtSDPSubject.Text, Convert.ToInt16(cmbCompany.SelectedValue), circularNo, 'O');
                                else
                                    comCls.insertStatement(cmd, docId, 0, Convert.ToInt16(cmbTypeOfDoc.SelectedValue), _projId, _stageID, Convert.ToInt16(cmbSentStatus.SelectedValue), txtSDPRefNo.Text.Trim(), cmbSentDocRefNo.Text,
                                        Convert.ToInt16(cmbSDPSentTo.SelectedValue), dtpSentdoc.Value.ToString("dd/MMM/yyyy"), dtpSentDocRec.Value.ToString("dd/MMM/yyyy"), fileImage, fileName, txtSDactdays.Text, txtSDPSubject.Text, Convert.ToInt16(cmbCompany.SelectedValue), circularNo, 'O');
                                int exUpdated = cmd.ExecuteNonQuery();
                                cmd.Parameters.Clear();
                            }
                            else
                            {
                                dalObj = new DAL();
                                Int16 dtRowCounter = 0;
                                iSNo = gnrlCls.GetMaxInfo("SELECT MAX(sn) FROM TenderDatesInfo", 'Y');
                                if (strBuilder.Length == 0)          
                                {
                                    comCls.insertStatement(cmd, docId, 0, Convert.ToInt16(cmbTypeOfDoc.SelectedValue), _projId, _stageID, Convert.ToInt16(cmbSentStatus.SelectedValue), txtSDPRefNo.Text.Trim(), cmbSentDocRefNo.Text, Convert.ToInt16(cmbSDPSentTo.SelectedValue), dtpSentdoc.Value.ToString("dd/MMM/yyyy"), dtpSentDocRec.Value.ToString("dd/MMM/yyyy"),null,null, txtSDactdays.Text, txtSDPSubject.Text, Convert.ToInt16(cmbCompany.SelectedValue), circularNo, 'C');
                                }
                                else
                                {
                                    comCls.insertStatement(cmd, docId, 0, Convert.ToInt16(cmbTypeOfDoc.SelectedValue), _projId, _stageID, Convert.ToInt16(cmbSentStatus.SelectedValue), txtSDPRefNo.Text.Trim(), cmbSentDocRefNo.Text, Convert.ToInt16(cmbSDPSentTo.SelectedValue), dtpSentdoc.Value.ToString("dd/MMM/yyyy"), dtpSentDocRec.Value.ToString("dd/MMM/yyyy"), fileImage, fileName, txtSDactdays.Text, txtSDPSubject.Text, Convert.ToInt16(cmbCompany.SelectedValue), circularNo, 'C');
                                }
                                int exUpdated = cmd.ExecuteNonQuery();
                                cmd.Parameters.Clear();
                                if (_stageID == 2)
                                {
                                    dtDatesId = dalObj.GetDataFromDB("DateIds", "select date_id,co_id,employee_id from TenderDatesInfo WHERE (co_id IS NOT NULL and proj_id=" + _projId + " and Tender_Issued=1)");
                                    while (dtRowCounter < dtDatesId.Rows.Count)
                                    {
                                        docId += 1;
                                        comCls.insertStatement(cmd, docId, Convert.ToInt32(dtDatesId.Rows[dtRowCounter][0]), Convert.ToInt16(cmbTypeOfDoc.SelectedValue), _projId, _stageID, Convert.ToInt16(cmbSentStatus.SelectedValue), txtSDPRefNo.Text.Trim(), cmbSentDocRefNo.Text, Convert.ToInt32(dtDatesId.Rows[dtRowCounter][2]), dtpSentdoc.Value.ToString("dd/MMM/yyyy"), dtpSentDocRec.Value.ToString("dd/MMM/yyyy"), null,
                                        fileName, txtSDactdays.Text, txtSDPSubject.Text, Convert.ToInt32(dtDatesId.Rows[dtRowCounter][1]), circularNo, 'C');
                                        exUpdated = cmd.ExecuteNonQuery();
                                        cmd.Parameters.Clear();
                                        dtRowCounter++;
                                    }
                                }
                            }                    
                            MessageBox.Show("Sent Document details added Succesfully");
                            this.Close();
                      }
                      else
                      {

                          int initialDocID = 0;
                          if (cmbSelection == 1)
                          {
                              if (strBuilder.Length == 0)
                                  comCls.insertStatement(cmd, docId, 0, Convert.ToInt16(cmbTypeOfDoc.SelectedValue), _projId, _stageID, Convert.ToInt16(cmbSentStatus.SelectedValue), txtSDPRefNo.Text.Trim(), cmbSentDocRefNo.Text, Convert.ToInt16(cmbSDPSentTo.SelectedValue), dtpSentdoc.Value.ToString("dd/MMM/yyyy"), dtpSentDocRec.Value.ToString("dd/MMM/yyyy"), 
                                  null, null, txtSDactdays.Text, txtSDPSubject.Text, Convert.ToInt16(cmbCompany.SelectedValue), circularNo, 'O');
                              else
                                  comCls.insertStatement(cmd, docId, 0, Convert.ToInt16(cmbTypeOfDoc.SelectedValue), _projId, _stageID, Convert.ToInt16(cmbSentStatus.SelectedValue), txtSDPRefNo.Text.Trim(), cmbSentDocRefNo.Text, Convert.ToInt16(cmbSDPSentTo.SelectedValue), dtpSentdoc.Value.ToString("dd/MMM/yyyy"), dtpSentDocRec.Value.ToString("dd/MMM/yyyy"),
                                  fileImage, strBuilder.ToString(), txtSDactdays.Text, txtSDPSubject.Text, Convert.ToInt16(cmbCompany.SelectedValue), circularNo, 'O');
                               
                              int exUpdated = cmd.ExecuteNonQuery();
                              cmd.Parameters.Clear();
                              initialDocID = docId;
                          }
                          else
                          {
                              dalObj = new DAL();
                              Int16 dtRowCounter = 0;
                              if (strBuilder.Length == 0)
                                  comCls.insertStatement(cmd, docId, 0, Convert.ToInt16(cmbTypeOfDoc.SelectedValue), _projId, _stageID, Convert.ToInt16(cmbSentStatus.SelectedValue), txtSDPRefNo.Text.Trim(), cmbSentDocRefNo.Text, Convert.ToInt16(cmbSDPSentTo.SelectedValue), dtpSentdoc.Value.ToString("dd/MMM/yyyy"), dtpSentDocRec.Value.ToString("dd/MMM/yyyy"),
                                  null, null, txtSDactdays.Text, txtSDPSubject.Text, Convert.ToInt16(cmbCompany.SelectedValue), circularNo, 'C');
                              else
                                  comCls.insertStatement(cmd, docId, 0, Convert.ToInt16(cmbTypeOfDoc.SelectedValue), _projId, _stageID, Convert.ToInt16(cmbSentStatus.SelectedValue), txtSDPRefNo.Text.Trim(), cmbSentDocRefNo.Text, Convert.ToInt16(cmbSDPSentTo.SelectedValue), dtpSentdoc.Value.ToString("dd/MMM/yyyy"), dtpSentDocRec.Value.ToString("dd/MMM/yyyy"),
                                  fileImage,strBuilder.ToString(), txtSDactdays.Text, txtSDPSubject.Text, Convert.ToInt16(cmbCompany.SelectedValue), circularNo, 'C');
                              int exUpdated = cmd.ExecuteNonQuery();
                              cmd.Parameters.Clear();
                              initialDocID = docId;

                              if (_stageID == 2)
                              {
                                  dtDatesId = dalObj.GetDataFromDB("DateIds", "select date_id,co_id,employee_id from TenderDatesInfo WHERE (co_id IS NOT NULL) and proj_id=" + _projId);
                                  while (dtRowCounter < dtDatesId.Rows.Count)
                                  {
                                      docId += 1;
                                      comCls.insertStatement(cmd, docId, Convert.ToInt32(dtDatesId.Rows[dtRowCounter][0]), Convert.ToInt16(cmbTypeOfDoc.SelectedValue), _projId, _stageID, 
                                      Convert.ToInt16(cmbSentStatus.SelectedValue), txtSDPRefNo.Text.Trim(), cmbSentDocRefNo.Text, Convert.ToInt32(dtDatesId.Rows[dtRowCounter][2]), dtpSentdoc.Value.ToString("dd/MMM/yyyy"),
                                      dtpSentDocRec.Value.ToString("dd/MMM/yyyy"), null, null, txtSDactdays.Text, txtSDPSubject.Text, Convert.ToInt32(dtDatesId.Rows[dtRowCounter][1]), circularNo, 'C');
                                      exUpdated = cmd.ExecuteNonQuery();
                                      cmd.Parameters.Clear();
                                      dtRowCounter++;
                                  }
                              }
                             
                          }
                           

                          foreach (ListViewItem item in lstSDPUploadedFiles.Items)
                          {
                              using (SqlCommand command = new SqlCommand())
                              {
                                  command.CommandText = @"INSERT INTO Attachments(attFileName,attFile,doc_ID,create_date,create_user,filePath) VALUES (@FileName, @File,@docID,@createDate,@createUser,@filePath)";
                                  command.Connection = sqlConn;
                                  item.Text = CheckArabicCharactersInFileName(item.Text);
                                  specialChars = "`~!@#$%^&*(){}:<>?|[];";
                                  foreach (char charVal in specialChars)
                                  {
                                      item.Text = item.Text.Replace(charVal.ToString(), "");
                                  }
                                  command.Parameters.AddWithValue("@FileName", item.Text);
                                  command.Parameters.AddWithValue("@File", item.Tag);
                                  command.Parameters.AddWithValue("@docID", initialDocID);
                                  command.Parameters.AddWithValue("@filePath", initialDocID + "_" + item.Text);
                                  command.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                                  command.Parameters.AddWithValue("@createUser", _userName);

                                  command.ExecuteNonQuery();
                                  command.Dispose();
                              }
                          }

                          MessageBox.Show("Sent Document details added Succesfully");
                          this.Close();

                        }                       
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while saving the sent document details", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }     

        private Boolean ValidateSentDoc()
        {
            Boolean recDocChk = true;
            int sdActDaysLen = txtSDactdays.Text.Length;
            
            Int16 loopCounter = 0;
            if (chkBoxSDPNoResponse.Checked == false)
            {
                while (loopCounter < sdActDaysLen)
                {
                    if (!Char.IsDigit(txtSDactdays.Text, loopCounter))
                    {
                        MessageBox.Show("Only Numbers or Digits are allowed");
                        txtSDactdays.Text = "";
                        txtSDactdays.Focus();
                        recDocChk = false;
                        return recDocChk;
                    }
                    loopCounter++;
                }
            }
            if (Convert.ToInt16(cmbTypeOfDoc.SelectedValue) == 1)
            {
                if (cmbSDPSentTo.Text == "All Bidders")
                {
                    MessageBox.Show("Can not issue communication to All Bidders, Select a company");
                    cmbSDPSentTo.Focus();
                    recDocChk = false;
                    return recDocChk;
                }
            }
            if (txtSDPRefNo.Text.Trim() == "")
            {
                MessageBox.Show("Please enter the document ref no ");                 
                recDocChk = false;
                return recDocChk;
            }             

            if (txtSDPSubject.Text == "")
            {
                MessageBox.Show("Please enter the subject ");
                txtSDPSubject.Focus();
                recDocChk = false;
                return recDocChk;
            }
            if (dtpSentdoc.Checked == false)
            {
                MessageBox.Show("Please enter the date of document ");
                recDocChk = false;
                dtpSentdoc.Focus();
                return recDocChk;
            }
            if (dtpSentDocRec.Checked == false)
            {
                MessageBox.Show("Please enter the Date Sent");
                recDocChk = false;
                dtpSentDocRec.Focus();
                return recDocChk;
            }            
            if (cmbSDPSentTo.Text == "")
            {
                MessageBox.Show("Please select Sent To");
                cmbSDPSentTo.Focus();
                recDocChk = false;
                return recDocChk;
            }             
             
            return recDocChk;
        }        

        private void button6_Click(object sender, EventArgs e)
        {
            int maxCircularNo = 0;
            int totCirculars = 0;
            CommonClass comCls = new CommonClass(_userName);
            if (userRightsColl.Contains("22"))    //      * Delete Document
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }
            DialogResult dlgResult = DialogResult.Yes;             
            dlgResult = MessageBox.Show("Are you sure you want to DELETE this Document?", "Delete Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (dlgResult.ToString() == "Yes")
            {  
                if (_circularNo != 0)
                {
                    maxCircularNo = comCls.GetMaxInfo("SELECT MAX(CircularNo) FROM DOCUMENTS where proj_id=" + _projId + " and CircularNo is not NULL and date_id is NULL", 'N');
                    totCirculars = comCls.GetMaxInfo("SELECT Count(distinct(CircularNo)) FROM DOCUMENTS where proj_id=" + _projId + " and CircularNo is not NULL and date_id is NULL", 'N');
                    if (totCirculars > 1 && (maxCircularNo != _circularNo))                     
                        MessageBox.Show("Can not delete the older circular being issued");
                    else
                    {
                        DeleteCirculars(_circularNo,_projId);                         
                    }
                }
                else
                {
                    try
                    {
                        using (SqlConnection sqlConn = new SqlConnection(strCon))
                        {
                            using (SqlCommand cmd = new SqlCommand())
                            {
                                sqlConn.Open();
                                cmd.Connection = sqlConn;
                                cmd.CommandTimeout = 80;
                                cmd.CommandText = @"DELETE FROM DOCUMENTS Where doc_id=@docId and proj_id=@projId";
                                cmd.Parameters.AddWithValue("@docId", _docId);
                                cmd.Parameters.AddWithValue("@projId", _projId);
                                int exUpdated = cmd.ExecuteNonQuery();
                                cmd.Parameters.Clear();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error occurred while deleting the records.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }                    
                }
                DeleteAttachments();
            }            
        }
        private void DeleteCirculars(int circularNo, int projId)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandTimeout = 80;
                        cmd.CommandText = @"DELETE FROM DOCUMENTS Where CircularNo = @circularNo and proj_id=@projId";
                        cmd.Parameters.AddWithValue("@circularNo", circularNo);
                        cmd.Parameters.AddWithValue("@projId", _projId);
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                    sqlConn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while deleting the records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void DeleteAttachments()
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandTimeout = 80;
                        cmd.CommandText = @"DELETE FROM ATTACHMENTS Where doc_id=@docId";
                        cmd.Parameters.AddWithValue("@docId", _docId);
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        MessageBox.Show("Records deleted Successfully ");
                        this.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while deleting records of file attachments, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
 
        private void txtSDactdays_TextChanged(object sender, EventArgs e)
        {
            if (txtSDactdays.Text != "")
            {
                chkBoxSDPNoResponse.Checked = false;
            }

            //Based on Riyas Request on 20/Dec/2016 Doc Status will always remained closed
            //if ((chkBoxSDPNoResponse.Checked == true) & (txtSDactdays.Text == ""))
                cmbSentStatus.SelectedIndex = 3;
            //else if ((chkBoxSDPNoResponse.Checked == false) & (txtSDactdays.Text != ""))
            //    cmbSentStatus.SelectedIndex = 0;                                    
        }

        private void btnAddFile_Click(object sender, EventArgs e)
        {
            if (lstFileCollSent.Items.Count > 1)
            foreach (ListViewItem item in lstFileCollSent.Items)
            {
                if (item.Text == "")
                {
                    lstFileCollSent.Items.Clear();
                }
            }
            if (lstFileCollSent.Items.Count >= 1)
            {
                MessageBox.Show("You can add single file only");
                return;
            }
            string strString = string.Empty;
            if (lstFileCollSent.Items.Count > 1)
            {
                if (strString == lstFileCollSent.Items[0].ToString())
                {
                    lstFileCollSent.Items.RemoveAt(0);
                }
            }
                attFile = getImage(ref attFileName);          
        }



        IList<string> strfileColl = new List<string>();
        //Boolean chkFile = false;

        private byte[] getImage(ref string _fileName)
        {
            System.IO.FileStream fileStream = null;
            System.IO.BinaryReader binaryReader = null;
          
            byte[] buffer = null;
            //lstFileColl.Items.Clear();
            try
            {
                OpenFileDialog op1 = new OpenFileDialog();
                op1.Multiselect = false;
                op1.ShowDialog();
                long totBytes = 0;                                  
                if (op1.FileNames.Count() != 0)
                {
                    foreach (string sFile in op1.FileNames)
                    {
                        string[] strColl = sFile.Split('\\');
                        string strName = strColl[strColl.Length - 1];
                        if(strName.Contains("."))
                        {
                            fileStream = new System.IO.FileStream(sFile, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                            binaryReader = new System.IO.BinaryReader(fileStream);
                            totBytes = new System.IO.FileInfo(sFile).Length;
                            buffer = binaryReader.ReadBytes((Int32)totBytes);
                            strfileColl.Add(sFile);
                            ListViewItem lstItem = new ListViewItem();
                            lstItem.Text = strName;
                            lstItem.Tag = buffer;
                            lstFileCollSent.Items.Add(lstItem);                  
                            //chkFile = true;
                        }
                        else                    
                            MessageBox.Show("Attached filename does not contain file extension, Please attach files with extensions", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    fileStream.Close();
                    fileStream.Dispose();
                    binaryReader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error While Uploading the images, try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            return buffer;
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (lstFileCollSent.Items.Count > 0 && lstFileCollSent.SelectedIndices.Count == 0)
                MessageBox.Show("No Item is selected, Please select an Item", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
            {
               DialogResult dlgResult = DialogResult.Yes;             
                dlgResult = MessageBox.Show("Are you sure you want to DELETE this Document?", "Delete Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (dlgResult.ToString() == "Yes")
                {
                    foreach (ListViewItem item in lstFileCollSent.Items)
                    {
                        lstFileCollSent.Items.Remove(item);
                        lstFileCollSent.Items.Clear();

                        using (SqlCommand command = new SqlCommand())
                        {
                            sqlConn.Open();
                            command.CommandText = @"update DOCUMENTS set attFilename=null, attFile=null WHERE doc_Id = @docID and proj_id=@projID";
                            command.Connection = sqlConn;
                            command.Parameters.AddWithValue("@docID", _docId);
                            command.Parameters.AddWithValue("@projID", _projId);
                            command.ExecuteNonQuery();
                            command.Dispose();
                            sqlConn.Close();
                        }
                    }     
                }                          
            } 
        }

                
        private void dtpSentdoc_ValueChanged(object sender, EventArgs e)
        {
            dtpSentdoc.CustomFormat = "dd/MMM/yyyy";
            dtpSentdoc.Text = dtpSentdoc.Value.ToString("dd/MMM/yyy");
        }
        private void dtpSentDocRec_ValueChanged(object sender, EventArgs e)
        {
            dtpSentDocRec.CustomFormat = "dd/MMM/yyyy";
            dtpSentDocRec.Text = dtpSentDocRec.Value.ToString("dd/MMM/yyy");
        }         
        private void lstFileCollSent_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                foreach (ListViewItem item in lstFileCollSent.Items)
                {
                    if (item.Text.Equals(lstFileCollSent.SelectedItems[0].Text))
                    {
                        string sName = item.Text;
                        byte[] _image = (byte[])item.Tag;
                        byte[] byteArray = _image;
                        MemoryStream mstream = new MemoryStream();
                        mstream.Write(byteArray, 0, byteArray.Length);
                        mstream.Seek(0, SeekOrigin.Begin);
                        //Modified By Varun on 29th Jan 2014 for opening the file with a specific ext. and to preserve the real name of the file
                        string ext = sName.Substring(sName.ToString().LastIndexOf('.'));
                        StringBuilder strBuild = new StringBuilder();
                        var tempFilePath = Path.ChangeExtension(Path.GetTempFileName(), ext);
                        strBuild.Append(tempFilePath.Substring(0, tempFilePath.LastIndexOf('\\')).ToString());
                        strBuild.Append("\\"+lstFileCollSent.SelectedItems[0].Text);
                        if (File.Exists(strBuild.ToString()))
                            File.Delete(strBuild.ToString());
                        File.WriteAllBytes(strBuild.ToString(), byteArray);

                        Process.Start(strBuild.ToString());

                        mstream.Close();
                        return;
                    }
                }
            }             
            catch (Exception ex)
            {
                if(ex.Message.Contains("The process cannot access the file"))
                {
                    MessageBox.Show("Error occurred while opening the pdf file, the file is already opened, close the file and try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }       
        }
        private void lstSDPUploadedFiles_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                foreach (ListViewItem item in lstSDPUploadedFiles.Items)
                {
                    if (item.Text.Equals(lstSDPUploadedFiles.SelectedItems[0].Text))
                    {
                        string sName = item.Text;
                        byte[] _image = (byte[])item.Tag;

                        byte[] byteArray = _image;
                        MemoryStream mstream = new MemoryStream();
                        mstream.Write(byteArray, 0, byteArray.Length);

                        mstream.Seek(0, SeekOrigin.Begin);
                        //Modified By Varun on 29th Jan 2014 for opening the file with a specific ext. and to preserve the real name of the file
                        string ext = sName.Substring(sName.ToString().LastIndexOf('.'));
                        StringBuilder strBuild = new StringBuilder();
                        var tempFilePath = Path.ChangeExtension(Path.GetTempFileName(), ext);
                        strBuild.Append(tempFilePath.Substring(0, tempFilePath.LastIndexOf('\\')).ToString());
                        strBuild.Append("\\" + lstSDPUploadedFiles.SelectedItems[0].Text);
                        if (File.Exists(strBuild.ToString()))
                            File.Delete(strBuild.ToString());
                        File.WriteAllBytes(strBuild.ToString(), byteArray);


                        Process.Start(strBuild.ToString());

                        mstream.Close();
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                if(ex.Message.Contains("The process cannot access the file"))
                {
                    MessageBox.Show("Error occurred while opening the pdf file, the file is already opened, close the file and try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }
        private void lblSDPStatus_Click(object sender, EventArgs e)
        {

        }

        private void lblSDPDays_Click(object sender, EventArgs e)
        {

        }

        private void lblSDPRefNo_Click(object sender, EventArgs e)
        {

        }

        // Handle the KeyDown event to determine the type of character entered into the control. 
        private void txtSDactdays_KeyDown(object sender, KeyEventArgs e)
        {  
          
        
        }

        private void txtSDactdays_KeyPress(object sender, KeyEventArgs e)
        {
            if (Char.IsDigit(e.KeyData.ToString(), 0))
            {
                //if (Char.IsDigit(e.) == false And e.KeyChar <> Microsoft.VisualBasic.Chr(8)        And e.KeyChar <> Microsoft.VisualBasic.Chr(46) Or (InStr(sender.text, ".") > 0 And  e.KeyChar = Microsoft.VisualBasic.Chr(46)) 

                // Determine whether the keystroke is a number
                //if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9 || e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9 || e.KeyCode != Keys.Back || e.KeyCode != Keys.Space || Control.ModifierKeys == Keys.Shift)
                //{
                // A non-numerical keystroke was pressed. 
                // Set the flag to true and evaluate in KeyPress event.
                MessageBox.Show("Only Number or Digits are allowed");
                txtSDactdays.Text = "";
                txtSDactdays.Focus();
                return;
                //}  
            }

        }
         
        private void txtSDactdays_KeyPress(object sender, KeyPressEventArgs e)
        {
                       
        }

        private void dtpSentDocRec_Leave(object sender, EventArgs e)
        {
            if (dtpSentDocRec.Value < dtpSentdoc.Value)
            {
                MessageBox.Show("Date of Sent should not be less than date of document");
                dtpSentDocRec.Checked = false;
                dtpSentDocRec.Focus();
                return;
            }
        }

        private bool checkDuplicateRefNo()
        {
            bool isOk = true;
            if (txtSDPRefNo.Text.Trim() != "")
            {

                SqlConnection sqlConn = new SqlConnection(strCon);
                try
                {
                    sqlConn.Open();
                    string sqlQuery = "SELECT ref_no FROM DOCUMENTS WHERE (ref_no = '" + txtSDPRefNo.Text.Trim() + "' and proj_id=" + _projId + ")";

                    SqlCommand sqlCommand = new SqlCommand(sqlQuery, sqlConn);
                    SqlDataReader sqlReader = sqlCommand.ExecuteReader();
                    if (sqlReader.HasRows)
                    {
                        MessageBox.Show("Document Reference No. is already used in this project. Please check the document reference No.");
                        txtSDPRefNo.Focus();
                        isOk = false;
                        return isOk;
                    }
                }
                catch (Exception ex)
                {
                    string exMsg = ex.Message;
                }
                finally
                {
                    sqlConn.Close();
                }
            }
            return isOk;
        }
        private void txtSDPRefNo_Leave(object sender, EventArgs e)
        {
            if (checkDuplicateRefNo() == false)
                return;
        }         

        private void cmbCompany_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (CheckBlockListCompany() == true)
            {
                MessageBox.Show("Selected Company " + cmbCompany.Text + " is currently blocklisted", "Block Listed Company Info", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                cmbCompany.SelectedIndex = -1;
                return;
            }
            else
            {
                FillCompanyData();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
        
        private void btnCmpRef_Click(object sender, EventArgs e)
        {
            if (CheckBlockListCompany() == true)
            {
                MessageBox.Show("Selected Company " + cmbCompany.Text + " is currently blocklisted", "Block Listed Company Info", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                cmbCompany.SelectedIndex = -1;
                return;
            }
            else
            {
                FillCompanyData();
            } 

        }
        CommonClass gnrlCls = new CommonClass("");
        private void FillCompanyData()
        {
            //if (txtTenderNo.Text != "")
            //{
            //    string sqlQuery = "SELECT employee_id, FirstName + '  ' + LastName AS PersonName, ShortName, AuthorizedRep,co_id FROM Contacts WHERE (AuthorizedRep = 1) AND (co_id = " + cmbCompany.SelectedValue + ")";
            //    cmbRDPFrom.DataSource = null;
            //    gnrlCls.PopulateComboBox(cmbRDPFrom, sqlQuery, "employee_id", "PersonName");
            //}
            if (cmbSDPSentTo.Items.Count == 0)
            {
                string sqlQuery = "SELECT employee_id, FirstName + ' ' + LastName AS PersonName, ShortName, AuthorizedRep,co_id FROM Contacts WHERE employee_id =117";

                cmbSDPSentTo.DataSource = null;
                gnrlCls.PopulateComboBox(cmbSDPSentTo, sqlQuery, "employee_id", "PersonName");
                cmbSDPSentTo.SelectedIndex = 0;
            }
            else
            {
                string sqlQuery = "SELECT employee_id, FirstName + ' ' + LastName AS PersonName, ShortName, AuthorizedRep,co_id FROM Contacts WHERE (AuthorizedRep = 1) AND (co_id = " + cmbCompany.SelectedValue + ")";
                //cmbRDPFrom.DataSource = null;               
                //gnrlCls.PopulateComboBox(cmbRDPFrom, sqlQuery, "employee_id", "PersonName");

                cmbSDPSentTo.SelectedIndex = -1;
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    sqlConn.Open();
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        SqlDataReader dr = cmd.ExecuteReader();
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                cmbSDPSentTo.Text = dr[1].ToString();
                            }
                        }
                    }
                    sqlConn.Close();
                }

                if (cmbSDPSentTo.Text == "")
                {
                    string sqlQueryNew = "SELECT employee_id, FirstName + ' ' + LastName AS PersonName, ShortName, AuthorizedRep,co_id FROM Contacts WHERE (AuthorizedRep = 1) AND (co_id = 425)";
                    using (SqlConnection sqlConn = new SqlConnection(strCon))
                    {
                        sqlConn.Open();
                        using (SqlCommand cmd = new SqlCommand())
                        {
                            cmd.Connection = sqlConn;
                            cmd.CommandText = sqlQueryNew;
                            SqlDataReader dr = cmd.ExecuteReader();
                            if (dr.HasRows)
                            {
                                while (dr.Read())
                                {
                                    if (dr[1].ToString().Contains("Authorized"))
                                        cmbSDPSentTo.Text = dr[1].ToString();
                                }
                            }
                        }
                        sqlConn.Close();
                    }
                }
            }
        }
        private Boolean CheckBlockListCompany()
        {
            Boolean blkCmp = false;
            string sqlQuery = "SELECT block_listed From COMPANY WHERE Co_id = '" + cmbCompany.SelectedValue + "'";
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    sqlConn.Open();
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        blkCmp = Convert.ToBoolean(cmd.ExecuteScalar());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while reading company blocklist, Try again.", ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            return blkCmp;
        }

        private void cmbSDPSentTo_SelectionChangeCommitted(object sender, EventArgs e)
        {
            populateCompanyCmb();
        }

        private void populateCompanyCmb()
        {
            Int16 iRecChk = 0;
            string sqlQuery = "SELECT COMPANY.co_id, COMPANY.co_name, Contacts.employee_id " +
            " FROM COMPANY INNER JOIN Contacts ON COMPANY.co_id = Contacts.co_id " +
            " WHERE (Contacts.employee_id = '" + cmbSDPSentTo.SelectedValue + "')";
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    sqlConn.Open();
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                cmbCompany.Text = dr[1].ToString();
                                iRecChk = 1;
                            }
                            if (iRecChk == 0)
                            {
                                MessageBox.Show("Send to value does not exists in the system, try again or Add new contact");
                                cmbCompany.Focus();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while reading company blocklist, Try again.", ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        int circularNo = 0;
        private void setCircularNo(Int16 stageId)
        {
            if (lblCircularNo.Text == "")
            {
                CommonClass comCls = new CommonClass(_userName);
                circularNo = comCls.GetMaxInfo("SELECT MAX(CircularNo) FROM DOCUMENTS where proj_id =" + _projId + " AND (date_id IS NULL) AND (doc_type_id = 2) AND (CircularNo IS NOT NULL)", 'Y');
                lblCircularNo.Text = circularNo.ToString();
                lblCircularNo.Visible = true;
                cmbSDPSentTo.SelectedValue = 83;
                cmbCompany.SelectedValue = 425;
            }
            else
            {
                lblCircularNo.Visible = true;
                if (stageId == 2)
                {
                    cmbSDPSentTo.SelectedValue = 83;                     
                    cmbCompany.SelectedValue = 425;
                }
            }
        }

        private void cmbTypeOfDoc_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (Convert.ToInt16(cmbTypeOfDoc.SelectedValue) == 2 && (_stageID == 2))
            {
                setCircularNo(_stageID);                 
            }
            else if (_stageID == 2 && setUpdate == 'N')
            {
                //lblCircularNo.Text = "";                 
                lblCircularNo.Visible = false;
                cmbSDPSentTo.SelectedIndex = -1;
                cmbCompany.SelectedIndex = -1;
            }
            else if (_stageID == 2 && setUpdate == 'Y' && Convert.ToInt16(cmbTypeOfDoc.SelectedValue) == 1)
            {
                lblCircularNo.Visible = false;
                cmbSDPSentTo.SelectedIndex = -1;
                cmbCompany.SelectedIndex = -1;
            }
            else if (_stageID != 2 && setUpdate == 'N')
            {
                lblCircularNo.Visible = false;
                cmbSDPSentTo.SelectedIndex = -1;
                cmbCompany.SelectedIndex = -1;
            }
        }

        private void cmbTypeOfDoc_EnterKeyPressed(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                setCircularNo(_stageID);
            }
        }
        char lastChar = ' ';
        private void cmbSDPSentTo_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            string strToFind;

            // if first char
            if (lastChar == 0)
                strToFind = ch.ToString();
            else
                strToFind = lastChar.ToString() + ch;

            // set first char
            lastChar = ch;

            // find first item that exactly like strToFind
            int idx = cmbSDPSentTo.FindStringExact(strToFind);

            // if not found, find first item that start with strToFind
            if (idx == -1) idx = cmbSDPSentTo.FindString(strToFind);

            if (idx == -1) return;

            cmbSDPSentTo.SelectedIndex = idx;

            e.Handled = true;
        }
        private void cmbCompany_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            string strToFind;

            // if first char
            if (lastChar == 0)
                strToFind = ch.ToString();
            else
                strToFind = lastChar.ToString() + ch;

            // set first char
            lastChar = ch;

            // find first item that exactly like strToFind
            int idx = cmbCompany.FindStringExact(strToFind);

            // if not found, find first item that start with strToFind
            if (idx == -1) idx = cmbCompany.FindString(strToFind);

            if (idx == -1) return;

            cmbCompany.SelectedIndex = idx;

            e.Handled = true;

        }

        void comboBox1_GotFocus(object sender, EventArgs e)
        {
            // remove last char before select new item
            lastChar = (char)0;
        }

       

        

        //private void cmbSentStatus_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    if (cmbTypeOfDoc.Text == "Circular" && cmbSDPSentTo.Text != "All Bidders")
        //    {
        //        MessageBox.Show("Circular can not be issued to only one company, Please select All Bidders");
        //        cmbSDPSentTo.Focus();
        //        return;
        //    }
        //}
    }
}
