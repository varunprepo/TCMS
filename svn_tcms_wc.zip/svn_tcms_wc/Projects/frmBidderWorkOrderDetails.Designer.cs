﻿namespace MDI_ParenrForm.Projects
{
    partial class frmBidderWorkOrderDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label19 = new System.Windows.Forms.Label();
            this.txtWOAmount = new System.Windows.Forms.TextBox();
            this.lblContractAmt = new System.Windows.Forms.Label();
            this.mskTxtRecOfAwardDoc = new System.Windows.Forms.MaskedTextBox();
            this.dtpRecOfAwardDoc = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.mskTxtDistribution = new System.Windows.Forms.MaskedTextBox();
            this.mskTxtRcvdFromFinanceDeptForCommittment = new System.Windows.Forms.MaskedTextBox();
            this.mskTxtSentFinanceDeptForCommittment = new System.Windows.Forms.MaskedTextBox();
            this.mskTxtRcvdDeptSentPRSDForSign = new System.Windows.Forms.MaskedTextBox();
            this.mskTxtSentDeptForSign = new System.Windows.Forms.MaskedTextBox();
            this.mskTxtDateOfSignContract = new System.Windows.Forms.MaskedTextBox();
            this.textRemarks = new System.Windows.Forms.TextBox();
            this.grpBoxContractsProcess = new System.Windows.Forms.GroupBox();
            this.cmpName = new System.Windows.Forms.Label();
            this.mskTxtDueDateOfSubPBSign = new System.Windows.Forms.MaskedTextBox();
            this.lblRemarks = new System.Windows.Forms.Label();
            this.mskTxtNoticeSendSignContract = new System.Windows.Forms.MaskedTextBox();
            this.txtContractNo = new System.Windows.Forms.TextBox();
            this.mskTxtStartDateReceive = new System.Windows.Forms.MaskedTextBox();
            this.lblContractNo = new System.Windows.Forms.Label();
            this.mskTxtReqDeptStartDate = new System.Windows.Forms.MaskedTextBox();
            this.lblReqDeptStartDate = new System.Windows.Forms.Label();
            this.dtpReqDeptStartDate = new System.Windows.Forms.DateTimePicker();
            this.dtpDistribution = new System.Windows.Forms.DateTimePicker();
            this.lblStartDateReceive = new System.Windows.Forms.Label();
            this.lblDistribution = new System.Windows.Forms.Label();
            this.dtpStartDateReceive = new System.Windows.Forms.DateTimePicker();
            this.lblNoticeSendTendererSignContract = new System.Windows.Forms.Label();
            this.dtpNoticeSendSignContract = new System.Windows.Forms.DateTimePicker();
            this.dtpRcvdFromFinanceDeptForCommittment = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.lblRcvdFromFinanceDeptForCommittment = new System.Windows.Forms.Label();
            this.dtpDueDateOfSubPBSign = new System.Windows.Forms.DateTimePicker();
            this.lblDateOfSignContract = new System.Windows.Forms.Label();
            this.dtpDateOfSignContract = new System.Windows.Forms.DateTimePicker();
            this.dtpSentFinanceDeptForCommittment = new System.Windows.Forms.DateTimePicker();
            this.lblSentDeptForSign = new System.Windows.Forms.Label();
            this.lblSentFinanceDeptForCommittment = new System.Windows.Forms.Label();
            this.dtpSentDeptForSign = new System.Windows.Forms.DateTimePicker();
            this.lblRcvdDeptSentPRSDForSign = new System.Windows.Forms.Label();
            this.dtpRcvdDeptSentPRSDForSign = new System.Windows.Forms.DateTimePicker();
            this.btnBidderWOUpdate = new System.Windows.Forms.Button();
            this.close = new System.Windows.Forms.Button();
            this.grpBoxContractsProcess.SuspendLayout();
            this.SuspendLayout();
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label19.Location = new System.Drawing.Point(365, 69);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(30, 13);
            this.label19.TabIndex = 46;
            this.label19.Text = "QAR";
            // 
            // txtWOAmount
            // 
            this.txtWOAmount.Location = new System.Drawing.Point(245, 66);
            this.txtWOAmount.Name = "txtWOAmount";
            this.txtWOAmount.Size = new System.Drawing.Size(117, 20);
            this.txtWOAmount.TabIndex = 45;
            this.txtWOAmount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtWOAmount_KeyPress);
            this.txtWOAmount.Leave += new System.EventHandler(this.txtWOAmount_Leave);
            // 
            // lblContractAmt
            // 
            this.lblContractAmt.AutoSize = true;
            this.lblContractAmt.Location = new System.Drawing.Point(12, 66);
            this.lblContractAmt.Name = "lblContractAmt";
            this.lblContractAmt.Size = new System.Drawing.Size(101, 13);
            this.lblContractAmt.TabIndex = 44;
            this.lblContractAmt.Text = "Work Order Amount";
            // 
            // mskTxtRecOfAwardDoc
            // 
            this.mskTxtRecOfAwardDoc.Location = new System.Drawing.Point(246, 101);
            this.mskTxtRecOfAwardDoc.Name = "mskTxtRecOfAwardDoc";
            this.mskTxtRecOfAwardDoc.Size = new System.Drawing.Size(95, 20);
            this.mskTxtRecOfAwardDoc.TabIndex = 21;
            // 
            // dtpRecOfAwardDoc
            // 
            this.dtpRecOfAwardDoc.Checked = false;
            this.dtpRecOfAwardDoc.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpRecOfAwardDoc.Location = new System.Drawing.Point(245, 101);
            this.dtpRecOfAwardDoc.Name = "dtpRecOfAwardDoc";
            this.dtpRecOfAwardDoc.ShowCheckBox = true;
            this.dtpRecOfAwardDoc.Size = new System.Drawing.Size(119, 20);
            this.dtpRecOfAwardDoc.TabIndex = 20;
            this.dtpRecOfAwardDoc.Value = new System.DateTime(2015, 10, 15, 0, 0, 0, 0);
            this.dtpRecOfAwardDoc.ValueChanged += new System.EventHandler(this.dtpRecOfAwardDoc_ValueChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 104);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(152, 13);
            this.label7.TabIndex = 36;
            this.label7.Text = "Received Of Award Document";
            // 
            // mskTxtDistribution
            // 
            this.mskTxtDistribution.Location = new System.Drawing.Point(244, 530);
            this.mskTxtDistribution.Name = "mskTxtDistribution";
            this.mskTxtDistribution.Size = new System.Drawing.Size(97, 20);
            this.mskTxtDistribution.TabIndex = 41;
            // 
            // mskTxtRcvdFromFinanceDeptForCommittment
            // 
            this.mskTxtRcvdFromFinanceDeptForCommittment.Location = new System.Drawing.Point(244, 492);
            this.mskTxtRcvdFromFinanceDeptForCommittment.Name = "mskTxtRcvdFromFinanceDeptForCommittment";
            this.mskTxtRcvdFromFinanceDeptForCommittment.Size = new System.Drawing.Size(97, 20);
            this.mskTxtRcvdFromFinanceDeptForCommittment.TabIndex = 39;
            // 
            // mskTxtSentFinanceDeptForCommittment
            // 
            this.mskTxtSentFinanceDeptForCommittment.Location = new System.Drawing.Point(244, 453);
            this.mskTxtSentFinanceDeptForCommittment.Name = "mskTxtSentFinanceDeptForCommittment";
            this.mskTxtSentFinanceDeptForCommittment.Size = new System.Drawing.Size(97, 20);
            this.mskTxtSentFinanceDeptForCommittment.TabIndex = 37;
            // 
            // mskTxtRcvdDeptSentPRSDForSign
            // 
            this.mskTxtRcvdDeptSentPRSDForSign.Location = new System.Drawing.Point(245, 413);
            this.mskTxtRcvdDeptSentPRSDForSign.Name = "mskTxtRcvdDeptSentPRSDForSign";
            this.mskTxtRcvdDeptSentPRSDForSign.Size = new System.Drawing.Size(96, 20);
            this.mskTxtRcvdDeptSentPRSDForSign.TabIndex = 35;
            // 
            // mskTxtSentDeptForSign
            // 
            this.mskTxtSentDeptForSign.Location = new System.Drawing.Point(246, 365);
            this.mskTxtSentDeptForSign.Name = "mskTxtSentDeptForSign";
            this.mskTxtSentDeptForSign.Size = new System.Drawing.Size(95, 20);
            this.mskTxtSentDeptForSign.TabIndex = 33;
            // 
            // mskTxtDateOfSignContract
            // 
            this.mskTxtDateOfSignContract.Location = new System.Drawing.Point(245, 321);
            this.mskTxtDateOfSignContract.Name = "mskTxtDateOfSignContract";
            this.mskTxtDateOfSignContract.Size = new System.Drawing.Size(96, 20);
            this.mskTxtDateOfSignContract.TabIndex = 31;
            // 
            // textRemarks
            // 
            this.textRemarks.Location = new System.Drawing.Point(13, 629);
            this.textRemarks.Multiline = true;
            this.textRemarks.Name = "textRemarks";
            this.textRemarks.Size = new System.Drawing.Size(350, 43);
            this.textRemarks.TabIndex = 43;
            // 
            // grpBoxContractsProcess
            // 
            this.grpBoxContractsProcess.Controls.Add(this.cmpName);
            this.grpBoxContractsProcess.Controls.Add(this.label19);
            this.grpBoxContractsProcess.Controls.Add(this.txtWOAmount);
            this.grpBoxContractsProcess.Controls.Add(this.lblContractAmt);
            this.grpBoxContractsProcess.Controls.Add(this.mskTxtRecOfAwardDoc);
            this.grpBoxContractsProcess.Controls.Add(this.dtpRecOfAwardDoc);
            this.grpBoxContractsProcess.Controls.Add(this.label7);
            this.grpBoxContractsProcess.Controls.Add(this.mskTxtDistribution);
            this.grpBoxContractsProcess.Controls.Add(this.mskTxtRcvdFromFinanceDeptForCommittment);
            this.grpBoxContractsProcess.Controls.Add(this.mskTxtSentFinanceDeptForCommittment);
            this.grpBoxContractsProcess.Controls.Add(this.mskTxtRcvdDeptSentPRSDForSign);
            this.grpBoxContractsProcess.Controls.Add(this.mskTxtSentDeptForSign);
            this.grpBoxContractsProcess.Controls.Add(this.mskTxtDateOfSignContract);
            this.grpBoxContractsProcess.Controls.Add(this.textRemarks);
            this.grpBoxContractsProcess.Controls.Add(this.mskTxtDueDateOfSubPBSign);
            this.grpBoxContractsProcess.Controls.Add(this.lblRemarks);
            this.grpBoxContractsProcess.Controls.Add(this.mskTxtNoticeSendSignContract);
            this.grpBoxContractsProcess.Controls.Add(this.txtContractNo);
            this.grpBoxContractsProcess.Controls.Add(this.mskTxtStartDateReceive);
            this.grpBoxContractsProcess.Controls.Add(this.lblContractNo);
            this.grpBoxContractsProcess.Controls.Add(this.mskTxtReqDeptStartDate);
            this.grpBoxContractsProcess.Controls.Add(this.lblReqDeptStartDate);
            this.grpBoxContractsProcess.Controls.Add(this.dtpReqDeptStartDate);
            this.grpBoxContractsProcess.Controls.Add(this.dtpDistribution);
            this.grpBoxContractsProcess.Controls.Add(this.lblStartDateReceive);
            this.grpBoxContractsProcess.Controls.Add(this.lblDistribution);
            this.grpBoxContractsProcess.Controls.Add(this.dtpStartDateReceive);
            this.grpBoxContractsProcess.Controls.Add(this.lblNoticeSendTendererSignContract);
            this.grpBoxContractsProcess.Controls.Add(this.dtpNoticeSendSignContract);
            this.grpBoxContractsProcess.Controls.Add(this.dtpRcvdFromFinanceDeptForCommittment);
            this.grpBoxContractsProcess.Controls.Add(this.label1);
            this.grpBoxContractsProcess.Controls.Add(this.lblRcvdFromFinanceDeptForCommittment);
            this.grpBoxContractsProcess.Controls.Add(this.dtpDueDateOfSubPBSign);
            this.grpBoxContractsProcess.Controls.Add(this.lblDateOfSignContract);
            this.grpBoxContractsProcess.Controls.Add(this.dtpDateOfSignContract);
            this.grpBoxContractsProcess.Controls.Add(this.dtpSentFinanceDeptForCommittment);
            this.grpBoxContractsProcess.Controls.Add(this.lblSentDeptForSign);
            this.grpBoxContractsProcess.Controls.Add(this.lblSentFinanceDeptForCommittment);
            this.grpBoxContractsProcess.Controls.Add(this.dtpSentDeptForSign);
            this.grpBoxContractsProcess.Controls.Add(this.lblRcvdDeptSentPRSDForSign);
            this.grpBoxContractsProcess.Controls.Add(this.dtpRcvdDeptSentPRSDForSign);
            this.grpBoxContractsProcess.Location = new System.Drawing.Point(33, 20);
            this.grpBoxContractsProcess.Name = "grpBoxContractsProcess";
            this.grpBoxContractsProcess.Size = new System.Drawing.Size(412, 686);
            this.grpBoxContractsProcess.TabIndex = 61;
            this.grpBoxContractsProcess.TabStop = false;
            this.grpBoxContractsProcess.Text = "Contracts Process";
            // 
            // cmpName
            // 
            this.cmpName.AutoSize = true;
            this.cmpName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmpName.Location = new System.Drawing.Point(106, 30);
            this.cmpName.Name = "cmpName";
            this.cmpName.Size = new System.Drawing.Size(118, 16);
            this.cmpName.TabIndex = 48;
            this.cmpName.Text = "Company Name";
            // 
            // mskTxtDueDateOfSubPBSign
            // 
            this.mskTxtDueDateOfSubPBSign.Location = new System.Drawing.Point(246, 275);
            this.mskTxtDueDateOfSubPBSign.Name = "mskTxtDueDateOfSubPBSign";
            this.mskTxtDueDateOfSubPBSign.Size = new System.Drawing.Size(95, 20);
            this.mskTxtDueDateOfSubPBSign.TabIndex = 29;
            // 
            // lblRemarks
            // 
            this.lblRemarks.AutoSize = true;
            this.lblRemarks.Location = new System.Drawing.Point(12, 613);
            this.lblRemarks.Name = "lblRemarks";
            this.lblRemarks.Size = new System.Drawing.Size(49, 13);
            this.lblRemarks.TabIndex = 28;
            this.lblRemarks.Text = "Remarks";
            // 
            // mskTxtNoticeSendSignContract
            // 
            this.mskTxtNoticeSendSignContract.Location = new System.Drawing.Point(246, 230);
            this.mskTxtNoticeSendSignContract.Name = "mskTxtNoticeSendSignContract";
            this.mskTxtNoticeSendSignContract.Size = new System.Drawing.Size(95, 20);
            this.mskTxtNoticeSendSignContract.TabIndex = 27;
            // 
            // txtContractNo
            // 
            this.txtContractNo.Location = new System.Drawing.Point(244, 570);
            this.txtContractNo.Name = "txtContractNo";
            this.txtContractNo.Size = new System.Drawing.Size(117, 20);
            this.txtContractNo.TabIndex = 42;
            this.txtContractNo.Leave += new System.EventHandler(this.txtContractNo_Leave);
            // 
            // mskTxtStartDateReceive
            // 
            this.mskTxtStartDateReceive.Location = new System.Drawing.Point(245, 183);
            this.mskTxtStartDateReceive.Name = "mskTxtStartDateReceive";
            this.mskTxtStartDateReceive.Size = new System.Drawing.Size(96, 20);
            this.mskTxtStartDateReceive.TabIndex = 25;
            // 
            // lblContractNo
            // 
            this.lblContractNo.AutoSize = true;
            this.lblContractNo.Location = new System.Drawing.Point(12, 577);
            this.lblContractNo.Name = "lblContractNo";
            this.lblContractNo.Size = new System.Drawing.Size(67, 13);
            this.lblContractNo.TabIndex = 26;
            this.lblContractNo.Text = "Contract No.";
            // 
            // mskTxtReqDeptStartDate
            // 
            this.mskTxtReqDeptStartDate.Location = new System.Drawing.Point(246, 138);
            this.mskTxtReqDeptStartDate.Name = "mskTxtReqDeptStartDate";
            this.mskTxtReqDeptStartDate.Size = new System.Drawing.Size(95, 20);
            this.mskTxtReqDeptStartDate.TabIndex = 23;
            // 
            // lblReqDeptStartDate
            // 
            this.lblReqDeptStartDate.AutoSize = true;
            this.lblReqDeptStartDate.Location = new System.Drawing.Point(12, 142);
            this.lblReqDeptStartDate.Name = "lblReqDeptStartDate";
            this.lblReqDeptStartDate.Size = new System.Drawing.Size(161, 13);
            this.lblReqDeptStartDate.TabIndex = 6;
            this.lblReqDeptStartDate.Text = "Req. Dept. to Provide Start Date";
            // 
            // dtpReqDeptStartDate
            // 
            this.dtpReqDeptStartDate.Checked = false;
            this.dtpReqDeptStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpReqDeptStartDate.Location = new System.Drawing.Point(245, 138);
            this.dtpReqDeptStartDate.Name = "dtpReqDeptStartDate";
            this.dtpReqDeptStartDate.ShowCheckBox = true;
            this.dtpReqDeptStartDate.Size = new System.Drawing.Size(118, 20);
            this.dtpReqDeptStartDate.TabIndex = 22;
            this.dtpReqDeptStartDate.Value = new System.DateTime(2015, 10, 15, 0, 0, 0, 0);
            this.dtpReqDeptStartDate.ValueChanged += new System.EventHandler(this.dtpReqDeptStartDate_ValueChanged);
            // 
            // dtpDistribution
            // 
            this.dtpDistribution.Checked = false;
            this.dtpDistribution.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDistribution.Location = new System.Drawing.Point(244, 530);
            this.dtpDistribution.Name = "dtpDistribution";
            this.dtpDistribution.ShowCheckBox = true;
            this.dtpDistribution.Size = new System.Drawing.Size(118, 20);
            this.dtpDistribution.TabIndex = 40;
            this.dtpDistribution.Value = new System.DateTime(2015, 10, 15, 0, 0, 0, 0);
            this.dtpDistribution.ValueChanged += new System.EventHandler(this.dtpDistribution_ValueChanged);
            // 
            // lblStartDateReceive
            // 
            this.lblStartDateReceive.AutoSize = true;
            this.lblStartDateReceive.Location = new System.Drawing.Point(12, 184);
            this.lblStartDateReceive.Name = "lblStartDateReceive";
            this.lblStartDateReceive.Size = new System.Drawing.Size(98, 13);
            this.lblStartDateReceive.TabIndex = 8;
            this.lblStartDateReceive.Text = "Start Date Receive";
            // 
            // lblDistribution
            // 
            this.lblDistribution.AutoSize = true;
            this.lblDistribution.Location = new System.Drawing.Point(12, 537);
            this.lblDistribution.Name = "lblDistribution";
            this.lblDistribution.Size = new System.Drawing.Size(59, 13);
            this.lblDistribution.TabIndex = 24;
            this.lblDistribution.Text = "Distribution";
            // 
            // dtpStartDateReceive
            // 
            this.dtpStartDateReceive.Checked = false;
            this.dtpStartDateReceive.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpStartDateReceive.Location = new System.Drawing.Point(245, 183);
            this.dtpStartDateReceive.Name = "dtpStartDateReceive";
            this.dtpStartDateReceive.ShowCheckBox = true;
            this.dtpStartDateReceive.Size = new System.Drawing.Size(118, 20);
            this.dtpStartDateReceive.TabIndex = 24;
            this.dtpStartDateReceive.Value = new System.DateTime(2015, 10, 15, 0, 0, 0, 0);
            this.dtpStartDateReceive.ValueChanged += new System.EventHandler(this.dtpStartDateReceive_ValueChanged);
            // 
            // lblNoticeSendTendererSignContract
            // 
            this.lblNoticeSendTendererSignContract.AutoSize = true;
            this.lblNoticeSendTendererSignContract.Location = new System.Drawing.Point(12, 234);
            this.lblNoticeSendTendererSignContract.Name = "lblNoticeSendTendererSignContract";
            this.lblNoticeSendTendererSignContract.Size = new System.Drawing.Size(203, 13);
            this.lblNoticeSendTendererSignContract.TabIndex = 10;
            this.lblNoticeSendTendererSignContract.Text = "Notice Send to Tenderer to Sign Contract";
            // 
            // dtpNoticeSendSignContract
            // 
            this.dtpNoticeSendSignContract.Checked = false;
            this.dtpNoticeSendSignContract.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNoticeSendSignContract.Location = new System.Drawing.Point(246, 230);
            this.dtpNoticeSendSignContract.Name = "dtpNoticeSendSignContract";
            this.dtpNoticeSendSignContract.ShowCheckBox = true;
            this.dtpNoticeSendSignContract.Size = new System.Drawing.Size(118, 20);
            this.dtpNoticeSendSignContract.TabIndex = 26;
            this.dtpNoticeSendSignContract.Value = new System.DateTime(2015, 10, 15, 0, 0, 0, 0);
            this.dtpNoticeSendSignContract.ValueChanged += new System.EventHandler(this.dtpNoticeSendSignContract_ValueChanged);
            // 
            // dtpRcvdFromFinanceDeptForCommittment
            // 
            this.dtpRcvdFromFinanceDeptForCommittment.Checked = false;
            this.dtpRcvdFromFinanceDeptForCommittment.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpRcvdFromFinanceDeptForCommittment.Location = new System.Drawing.Point(245, 492);
            this.dtpRcvdFromFinanceDeptForCommittment.Name = "dtpRcvdFromFinanceDeptForCommittment";
            this.dtpRcvdFromFinanceDeptForCommittment.ShowCheckBox = true;
            this.dtpRcvdFromFinanceDeptForCommittment.Size = new System.Drawing.Size(118, 20);
            this.dtpRcvdFromFinanceDeptForCommittment.TabIndex = 38;
            this.dtpRcvdFromFinanceDeptForCommittment.Value = new System.DateTime(2015, 10, 15, 0, 0, 0, 0);
            this.dtpRcvdFromFinanceDeptForCommittment.ValueChanged += new System.EventHandler(this.dtpRcvdFromFinanceDeptForCommittment_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 279);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(177, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Due Date of Submission of PB Sign.";
            // 
            // lblRcvdFromFinanceDeptForCommittment
            // 
            this.lblRcvdFromFinanceDeptForCommittment.AutoSize = true;
            this.lblRcvdFromFinanceDeptForCommittment.Location = new System.Drawing.Point(12, 498);
            this.lblRcvdFromFinanceDeptForCommittment.Name = "lblRcvdFromFinanceDeptForCommittment";
            this.lblRcvdFromFinanceDeptForCommittment.Size = new System.Drawing.Size(161, 13);
            this.lblRcvdFromFinanceDeptForCommittment.TabIndex = 22;
            this.lblRcvdFromFinanceDeptForCommittment.Text = "Rcvd. From Finance Department";
            // 
            // dtpDueDateOfSubPBSign
            // 
            this.dtpDueDateOfSubPBSign.Checked = false;
            this.dtpDueDateOfSubPBSign.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDueDateOfSubPBSign.Location = new System.Drawing.Point(246, 275);
            this.dtpDueDateOfSubPBSign.Name = "dtpDueDateOfSubPBSign";
            this.dtpDueDateOfSubPBSign.ShowCheckBox = true;
            this.dtpDueDateOfSubPBSign.Size = new System.Drawing.Size(118, 20);
            this.dtpDueDateOfSubPBSign.TabIndex = 28;
            this.dtpDueDateOfSubPBSign.Value = new System.DateTime(2015, 10, 15, 0, 0, 0, 0);
            this.dtpDueDateOfSubPBSign.ValueChanged += new System.EventHandler(this.dtpDueDateOfSubPBSign_ValueChanged);
            // 
            // lblDateOfSignContract
            // 
            this.lblDateOfSignContract.AutoSize = true;
            this.lblDateOfSignContract.Location = new System.Drawing.Point(12, 326);
            this.lblDateOfSignContract.Name = "lblDateOfSignContract";
            this.lblDateOfSignContract.Size = new System.Drawing.Size(112, 13);
            this.lblDateOfSignContract.TabIndex = 14;
            this.lblDateOfSignContract.Text = "Date of Sign. Contract";
            // 
            // dtpDateOfSignContract
            // 
            this.dtpDateOfSignContract.Checked = false;
            this.dtpDateOfSignContract.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDateOfSignContract.Location = new System.Drawing.Point(246, 321);
            this.dtpDateOfSignContract.Name = "dtpDateOfSignContract";
            this.dtpDateOfSignContract.ShowCheckBox = true;
            this.dtpDateOfSignContract.Size = new System.Drawing.Size(118, 20);
            this.dtpDateOfSignContract.TabIndex = 30;
            this.dtpDateOfSignContract.Value = new System.DateTime(2015, 10, 15, 0, 0, 0, 0);
            this.dtpDateOfSignContract.ValueChanged += new System.EventHandler(this.dtpDateOfSignContract_ValueChanged);
            // 
            // dtpSentFinanceDeptForCommittment
            // 
            this.dtpSentFinanceDeptForCommittment.Checked = false;
            this.dtpSentFinanceDeptForCommittment.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpSentFinanceDeptForCommittment.Location = new System.Drawing.Point(244, 453);
            this.dtpSentFinanceDeptForCommittment.Name = "dtpSentFinanceDeptForCommittment";
            this.dtpSentFinanceDeptForCommittment.ShowCheckBox = true;
            this.dtpSentFinanceDeptForCommittment.Size = new System.Drawing.Size(118, 20);
            this.dtpSentFinanceDeptForCommittment.TabIndex = 36;
            this.dtpSentFinanceDeptForCommittment.Value = new System.DateTime(2015, 10, 15, 0, 0, 0, 0);
            this.dtpSentFinanceDeptForCommittment.ValueChanged += new System.EventHandler(this.dtpSentFinanceDeptForCommittment_ValueChanged);
            // 
            // lblSentDeptForSign
            // 
            this.lblSentDeptForSign.AutoSize = true;
            this.lblSentDeptForSign.Location = new System.Drawing.Point(12, 370);
            this.lblSentDeptForSign.Name = "lblSentDeptForSign";
            this.lblSentDeptForSign.Size = new System.Drawing.Size(109, 13);
            this.lblSentDeptForSign.TabIndex = 16;
            this.lblSentDeptForSign.Text = "Sent to Dept for Sign.";
            // 
            // lblSentFinanceDeptForCommittment
            // 
            this.lblSentFinanceDeptForCommittment.AutoSize = true;
            this.lblSentFinanceDeptForCommittment.Location = new System.Drawing.Point(10, 454);
            this.lblSentFinanceDeptForCommittment.Name = "lblSentFinanceDeptForCommittment";
            this.lblSentFinanceDeptForCommittment.Size = new System.Drawing.Size(189, 13);
            this.lblSentFinanceDeptForCommittment.TabIndex = 20;
            this.lblSentFinanceDeptForCommittment.Text = "Sent to Finance Dept. for Committment";
            // 
            // dtpSentDeptForSign
            // 
            this.dtpSentDeptForSign.Checked = false;
            this.dtpSentDeptForSign.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpSentDeptForSign.Location = new System.Drawing.Point(245, 365);
            this.dtpSentDeptForSign.Name = "dtpSentDeptForSign";
            this.dtpSentDeptForSign.ShowCheckBox = true;
            this.dtpSentDeptForSign.Size = new System.Drawing.Size(118, 20);
            this.dtpSentDeptForSign.TabIndex = 32;
            this.dtpSentDeptForSign.Value = new System.DateTime(2015, 10, 15, 0, 0, 0, 0);
            this.dtpSentDeptForSign.ValueChanged += new System.EventHandler(this.dtpSentDeptForSign_ValueChanged);
            // 
            // lblRcvdDeptSentPRSDForSign
            // 
            this.lblRcvdDeptSentPRSDForSign.AutoSize = true;
            this.lblRcvdDeptSentPRSDForSign.Location = new System.Drawing.Point(10, 413);
            this.lblRcvdDeptSentPRSDForSign.Name = "lblRcvdDeptSentPRSDForSign";
            this.lblRcvdDeptSentPRSDForSign.Size = new System.Drawing.Size(224, 13);
            this.lblRcvdDeptSentPRSDForSign.TabIndex = 18;
            this.lblRcvdDeptSentPRSDForSign.Text = "Rcvd. from Dept. and Sent to PRSD. for Sign.";
            // 
            // dtpRcvdDeptSentPRSDForSign
            // 
            this.dtpRcvdDeptSentPRSDForSign.Checked = false;
            this.dtpRcvdDeptSentPRSDForSign.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpRcvdDeptSentPRSDForSign.Location = new System.Drawing.Point(246, 413);
            this.dtpRcvdDeptSentPRSDForSign.Name = "dtpRcvdDeptSentPRSDForSign";
            this.dtpRcvdDeptSentPRSDForSign.ShowCheckBox = true;
            this.dtpRcvdDeptSentPRSDForSign.Size = new System.Drawing.Size(118, 20);
            this.dtpRcvdDeptSentPRSDForSign.TabIndex = 34;
            this.dtpRcvdDeptSentPRSDForSign.Value = new System.DateTime(2015, 10, 15, 0, 0, 0, 0);
            this.dtpRcvdDeptSentPRSDForSign.ValueChanged += new System.EventHandler(this.dtpRcvdDeptSentPRSDForSign_ValueChanged);
            // 
            // btnBidderWOUpdate
            // 
            this.btnBidderWOUpdate.BackColor = System.Drawing.Color.Maroon;
            this.btnBidderWOUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBidderWOUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBidderWOUpdate.ForeColor = System.Drawing.Color.White;
            this.btnBidderWOUpdate.Location = new System.Drawing.Point(118, 722);
            this.btnBidderWOUpdate.Name = "btnBidderWOUpdate";
            this.btnBidderWOUpdate.Size = new System.Drawing.Size(58, 24);
            this.btnBidderWOUpdate.TabIndex = 240;
            this.btnBidderWOUpdate.Text = "Update";
            this.btnBidderWOUpdate.UseVisualStyleBackColor = false;
            this.btnBidderWOUpdate.Click += new System.EventHandler(this.btnBidderWOUpdate_Click);
            // 
            // close
            // 
            this.close.BackColor = System.Drawing.Color.Maroon;
            this.close.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.close.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.close.ForeColor = System.Drawing.Color.White;
            this.close.Location = new System.Drawing.Point(219, 722);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(58, 24);
            this.close.TabIndex = 241;
            this.close.Text = "Close";
            this.close.UseVisualStyleBackColor = false;
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // frmBidderWorkOrderDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(479, 776);
            this.Controls.Add(this.close);
            this.Controls.Add(this.btnBidderWOUpdate);
            this.Controls.Add(this.grpBoxContractsProcess);
            this.Name = "frmBidderWorkOrderDetails";
            this.Text = "Bidder WorkOrder Details";
            this.grpBoxContractsProcess.ResumeLayout(false);
            this.grpBoxContractsProcess.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtWOAmount;
        private System.Windows.Forms.Label lblContractAmt;
        private System.Windows.Forms.MaskedTextBox mskTxtRecOfAwardDoc;
        private System.Windows.Forms.DateTimePicker dtpRecOfAwardDoc;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.MaskedTextBox mskTxtDistribution;
        private System.Windows.Forms.MaskedTextBox mskTxtRcvdFromFinanceDeptForCommittment;
        private System.Windows.Forms.MaskedTextBox mskTxtSentFinanceDeptForCommittment;
        private System.Windows.Forms.MaskedTextBox mskTxtRcvdDeptSentPRSDForSign;
        private System.Windows.Forms.MaskedTextBox mskTxtSentDeptForSign;
        private System.Windows.Forms.MaskedTextBox mskTxtDateOfSignContract;
        private System.Windows.Forms.TextBox textRemarks;
        private System.Windows.Forms.GroupBox grpBoxContractsProcess;
        private System.Windows.Forms.MaskedTextBox mskTxtDueDateOfSubPBSign;
        private System.Windows.Forms.Label lblRemarks;
        private System.Windows.Forms.MaskedTextBox mskTxtNoticeSendSignContract;
        private System.Windows.Forms.TextBox txtContractNo;
        private System.Windows.Forms.MaskedTextBox mskTxtStartDateReceive;
        private System.Windows.Forms.Label lblContractNo;
        private System.Windows.Forms.MaskedTextBox mskTxtReqDeptStartDate;
        private System.Windows.Forms.Label lblReqDeptStartDate;
        private System.Windows.Forms.DateTimePicker dtpReqDeptStartDate;
        private System.Windows.Forms.DateTimePicker dtpDistribution;
        private System.Windows.Forms.Label lblStartDateReceive;
        private System.Windows.Forms.Label lblDistribution;
        private System.Windows.Forms.DateTimePicker dtpStartDateReceive;
        private System.Windows.Forms.Label lblNoticeSendTendererSignContract;
        private System.Windows.Forms.DateTimePicker dtpNoticeSendSignContract;
        private System.Windows.Forms.DateTimePicker dtpRcvdFromFinanceDeptForCommittment;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblRcvdFromFinanceDeptForCommittment;
        private System.Windows.Forms.DateTimePicker dtpDueDateOfSubPBSign;
        private System.Windows.Forms.Label lblDateOfSignContract;
        private System.Windows.Forms.DateTimePicker dtpDateOfSignContract;
        private System.Windows.Forms.DateTimePicker dtpSentFinanceDeptForCommittment;
        private System.Windows.Forms.Label lblSentDeptForSign;
        private System.Windows.Forms.Label lblSentFinanceDeptForCommittment;
        private System.Windows.Forms.DateTimePicker dtpSentDeptForSign;
        private System.Windows.Forms.Label lblRcvdDeptSentPRSDForSign;
        private System.Windows.Forms.DateTimePicker dtpRcvdDeptSentPRSDForSign;
        private System.Windows.Forms.Button btnBidderWOUpdate;
        private System.Windows.Forms.Button close;
        private System.Windows.Forms.Label cmpName;
    }
}