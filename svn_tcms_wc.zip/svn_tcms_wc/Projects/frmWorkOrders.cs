﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace MDI_ParenrForm.Projects
{
    public partial class frmWorkOrders : Form
    {
        string _contractorNo = string.Empty;
        CommonClass cmnCls = null;
        int _bidID = 0;
        int _prjID = 0;        

        IList<string> mUserRightsColl = new List<string>();
        string _userName = string.Empty;        
        bool _isHeadOfSection = false;
        bool _isClickedFromPTD = false;
        string mProjectTitle = null;
        string mTenderNo = null;

        public frmWorkOrders(IList<string> userRightsCollContracts, int PrjID, string tenderNo,string projectTitle, string user, bool isHeadOfSection, bool isClickedFromPTD)
        {
            InitializeComponent();
            mUserRightsColl = userRightsCollContracts;
            mProjectTitle = projectTitle;             
            _userName = user;          
            _prjID = PrjID;
            _isHeadOfSection = isHeadOfSection;
            _isClickedFromPTD = isClickedFromPTD;
            mTenderNo = tenderNo;
            if (!mUserRightsColl.Contains("120"))
            {
                cmnCls = new CommonClass(user);
                cmnCls.CreateWorkOrderGridViewColumns(dgvWorkOrders, _prjID, 0);
            }
        }

        private void btnNewWorkOrder_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Count != 0 && _isHeadOfSection == false)
            {
                if (mUserRightsColl.Contains("73"))
                {
                    MessageBox.Show("Do not have access rights to create Work Order, Please contact the Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            frmNewWorkOrder frmNewWorkOrder = new frmNewWorkOrder(mUserRightsColl, _prjID, _userName, _isHeadOfSection, dgvWorkOrders);
            frmNewWorkOrder.StartPosition = FormStartPosition.CenterParent;
            frmNewWorkOrder.ShowDialog(); 
        }

        //private void dgvWorkOrders_CellContentClick(object sender, DataGridViewCellEventArgs e)
        //{
        //    if (mUserRightsColl.Count != 0 && _isHeadOfSection == false)
        //    {
        //        if (mUserRightsColl.Contains("76"))
        //        {
        //            MessageBox.Show("You do not have permission to View Contractors Details In Work Orders, Please contact the Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //            return;
        //        }
        //    }
        //    int rowIndex = e.RowIndex;
        //    int colIndex = e.ColumnIndex;
        //    try
        //    {
        //        if (rowIndex != -1)
        //        {
        //            if (colIndex == 1)
        //            {
        //                frmWorkOrderContractProcessDetails frmWOContract = null;
        //                string[] workOrderInfo = new string[14];
        //                workOrderInfo[0] = dgvWorkOrders.Rows[rowIndex].Cells[1].Value.ToString();
        //                workOrderInfo[1] = dgvWorkOrders.Rows[rowIndex].Cells[2].Value.ToString();
        //                workOrderInfo[2] = dgvWorkOrders.Rows[rowIndex].Cells[3].Value.ToString();
        //                workOrderInfo[3] = dgvWorkOrders.Rows[rowIndex].Cells[4].Value.ToString();
        //                workOrderInfo[4] = dgvWorkOrders.Rows[rowIndex].Cells[5].Value.ToString();
        //                workOrderInfo[5] = dgvWorkOrders.Rows[rowIndex].Cells[6].Value.ToString();
        //                workOrderInfo[6] = dgvWorkOrders.Rows[rowIndex].Cells[7].Value.ToString();
        //                workOrderInfo[7] = dgvWorkOrders.Rows[rowIndex].Cells[8].Value.ToString(); //Convert.ToDateTime(dgvWorkOrders.Rows[rowIndex].Cells[8].Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy")
        //                workOrderInfo[8] = dgvWorkOrders.Rows[rowIndex].Cells[9].Value.ToString();
        //                workOrderInfo[9] = dgvWorkOrders.Rows[rowIndex].Cells[10].Value.ToString();
        //                workOrderInfo[10] = dgvWorkOrders.Rows[rowIndex].Cells[11].Value.ToString();
        //                workOrderInfo[11] = dgvWorkOrders.Rows[rowIndex].Cells[12].Value.ToString();
        //                workOrderInfo[12] = dgvWorkOrders.Rows[rowIndex].Cells[13].Value.ToString();
        //                workOrderInfo[13] = dgvWorkOrders.Rows[rowIndex].Cells[14].Value.ToString();

        //                frmWOContract = new frmWorkOrderContractProcessDetails(mUserRightsColl, _userName, workOrderInfo, _prjID, dgvWorkOrders, _isHeadOfSection, mProjectTitle);
        //                frmWOContract.StartPosition = FormStartPosition.CenterParent;
        //                frmWOContract.ShowDialog();
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("Exception occurred while displaying the Work Orders", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //    }

        //} 

        private void dgvWorkOrders_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (mUserRightsColl.Count != 0 && _isHeadOfSection == false)
            {
                if (mUserRightsColl.Contains("76"))
                {
                    MessageBox.Show("You do not have permission to View Contractors Details In Work Orders, Please contact the Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            
                int rowIndex = e.RowIndex;
                int colIndex = e.ColumnIndex;
                try
                {
                    if (rowIndex != -1)
                    {
                        if (colIndex == 1)
                        {
                            frmWorkOrderContractProcessDetails frmWOContract = null;
                            string[] workOrderInfo = new string[18];
                            workOrderInfo[0] = dgvWorkOrders.Rows[rowIndex].Cells[1].Value.ToString();//workOrderNo
                            workOrderInfo[1] = dgvWorkOrders.Rows[rowIndex].Cells[2].Value.ToString();//workOrderTitle
                            workOrderInfo[2] = dgvWorkOrders.Rows[rowIndex].Cells[3].Value.ToString();//workOrderStatus
                            workOrderInfo[3] = dgvWorkOrders.Rows[rowIndex].Cells[4].Value.ToString();//ContractStatus
                            workOrderInfo[4] = dgvWorkOrders.Rows[rowIndex].Cells[5].Value.ToString();//contract_no
                            workOrderInfo[5] = dgvWorkOrders.Rows[rowIndex].Cells[6].Value.ToString();//moahzanah_ID
                            workOrderInfo[6] = dgvWorkOrders.Rows[rowIndex].Cells[8].Value.ToString();//workOrderID                       
                            workOrderInfo[7] = dgvWorkOrders.Rows[rowIndex].Cells[9].Value.ToString();//bidder_Id                         
                            workOrderInfo[8] = dgvWorkOrders.Rows[rowIndex].Cells[10].Value.ToString(); //workOrderIssueDate
                            workOrderInfo[9] = dgvWorkOrders.Rows[rowIndex].Cells[11].Value.ToString(); //workOrderClosingDate
                            workOrderInfo[10] = dgvWorkOrders.Rows[rowIndex].Cells[12].Value.ToString(); //tender_open_date
                            workOrderInfo[11] = dgvWorkOrders.Rows[rowIndex].Cells[13].Value.ToString(); //evaluation_report_datesend
                            workOrderInfo[12] = dgvWorkOrders.Rows[rowIndex].Cells[14].Value.ToString(); //techno_financial_totalworkdays
                            workOrderInfo[13] = dgvWorkOrders.Rows[rowIndex].Cells[15].Value.ToString(); //no_of_meetings
                            workOrderInfo[14] = dgvWorkOrders.Rows[rowIndex].Cells[16].Value.ToString(); //evaluation_report_daterecvd
                            workOrderInfo[15] = dgvWorkOrders.Rows[rowIndex].Cells[17].Value.ToString(); //tender_award_approvaldate
                            workOrderInfo[16] = dgvWorkOrders.Rows[rowIndex].Cells[18].Value.ToString(); //woAwardDate
                            workOrderInfo[17] = dgvWorkOrders.Rows[rowIndex].Cells[20].Value.ToString(); //woTenderEstimate
                            //workOrderInfo[16] = dgvWorkOrders.Rows[rowIndex].Cells[17].Value.ToString();
                            //workOrderInfo[17] = dgvWorkOrders.Rows[rowIndex].Cells[18].Value.ToString();
                            //workOrderInfo[18] = dgvWorkOrders.Rows[rowIndex].Cells[19].Value.ToString();
                            //workOrderInfo[19] = dgvWorkOrders.Rows[rowIndex].Cells[20].Value.ToString();
                            //workOrderInfo[20] = dgvWorkOrders.Rows[rowIndex].Cells[21].Value.ToString();
                            //workOrderInfo[21] = dgvWorkOrders.Rows[rowIndex].Cells[22].Value.ToString();
                            //workOrderInfo[22] = dgvWorkOrders.Rows[rowIndex].Cells[23].Value.ToString();
                            //workOrderInfo[23] = dgvWorkOrders.Rows[rowIndex].Cells[24].Value.ToString();
                            //workOrderInfo[24] = dgvWorkOrders.Rows[rowIndex].Cells[25].Value.ToString();
                            //workOrderInfo[25] = dgvWorkOrders.Rows[rowIndex].Cells[26].Value.ToString();
                            //workOrderInfo[26] = dgvWorkOrders.Rows[rowIndex].Cells[27].Value.ToString();
                            //workOrderInfo[27] = dgvWorkOrders.Rows[rowIndex].Cells[28].Value.ToString();
                            //workOrderInfo[28] = dgvWorkOrders.Rows[rowIndex].Cells[29].Value.ToString();
                            if (_isClickedFromPTD == false)
                            {
                                frmWOContract = new frmWorkOrderContractProcessDetails(mUserRightsColl, _userName, workOrderInfo, _prjID, dgvWorkOrders, _isHeadOfSection, mProjectTitle);
                                frmWOContract.StartPosition = FormStartPosition.CenterParent;
                                frmWOContract.ShowDialog();
                            }
                            else
                            {
                                frmWorkOrderIssueDate fwoi = new frmWorkOrderIssueDate(mUserRightsColl, _userName, workOrderInfo, _prjID, dgvWorkOrders, _isHeadOfSection, mProjectTitle);
                                fwoi.StartPosition = FormStartPosition.CenterParent;
                                fwoi.ShowDialog();
                            }
                        }
                        else if (colIndex == 7)
                        {

                            //CellButtonClick.Invoke(this, e);             

                            try
                            {
                                if (!mUserRightsColl.Contains("73"))
                                {
                                    UpdateMozanahID(dgvWorkOrders.Rows[e.RowIndex].Cells[6].Value.ToString(), dgvWorkOrders.Rows[e.RowIndex].Cells[8].Value.ToString());
                                    MessageBox.Show("Moazanah ID updated for the Work Order", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                                else
                                {
                                    MessageBox.Show("You do not have permission to Update the Contractors Details In Work Orders, Please contact the Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                                //if(projStg.ProjTransferedToComm=='Y' || Filtered ==' ')                     

                                //if (!userRightsColl.Contains("54"))
                                //{


                                //    //else if (Filtered!='Y')
                                //    //    FillAllProjectsInformation_CommitteWise(' ', filterQueryMain, Filtered);
                                //}

                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message);
                            }

                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Exception occurred while displaying the Work Orders", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }           
           
        }

        string connStr = ConfigurationManager.AppSettings["TCMSConnString"].ToString();
        private void UpdateMozanahID(string mozanahIDs, string workOrderId)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        cmd.CommandText = @"UPDATE WorkOrders SET moazanah_id=@moazanahProjId,update_date=@updateDate,update_user=@updateUser where workOrderID=@workOrderID";
                        if (mozanahIDs != "")
                        {
                            cmd.Parameters.AddWithValue("@moazanahProjId", mozanahIDs);
                        }
                        else
                        {
                            cmd.Parameters.AddWithValue("@moazanahProjId", System.DBNull.Value);
                        }
                        cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@updateUser", _userName);
                        cmd.Parameters.AddWithValue("@workOrderID", workOrderId);

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the TimeSpan, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }   

        private void btnWOTenderSubmission_Click(object sender, EventArgs e)
        {           

            int countChkSelection = checkGridViewSelection();
            if (countChkSelection > 1 || countChkSelection == 0)
                return;        
             
            frmTenderSubmission frmTndrSub = null;           
            if (mTenderNo.Contains("STC"))
                frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("STC", mTenderNo, mProjectTitle, _prjID, _userName, null, mUserRightsColl, checkedWorkOrderId.ToString(), workOrderProjTitle, _isHeadOfSection, true,false);
            else if (mTenderNo.Contains("GTC"))
                frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("GTC", mTenderNo, mProjectTitle, _prjID, _userName, null, mUserRightsColl, checkedWorkOrderId.ToString(), workOrderProjTitle, _isHeadOfSection, true, false);
            else if (mTenderNo.Contains("ITC"))
                frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("ITC", mTenderNo, mProjectTitle, _prjID, _userName, null, mUserRightsColl, checkedWorkOrderId.ToString(), workOrderProjTitle, _isHeadOfSection, true, false);
            else if (mTenderNo.Contains("MRPSC"))
                frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("MRPSC", mTenderNo, mProjectTitle, _prjID, _userName, null, mUserRightsColl, checkedWorkOrderId.ToString(), workOrderProjTitle, _isHeadOfSection, true, false);
            else if (mTenderNo.Contains("EUWC"))
                frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("EUWC", mTenderNo, mProjectTitle, _prjID, _userName, null, mUserRightsColl, checkedWorkOrderId.ToString(), workOrderProjTitle, _isHeadOfSection, true, false);
            else if (mTenderNo.Contains("NC"))
                frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("NC", mTenderNo, mProjectTitle, _prjID, _userName, null, mUserRightsColl, checkedWorkOrderId.ToString(), workOrderProjTitle, _isHeadOfSection, true, false);
            frmTndrSub.Text = "Work Order Submission Window";
            frmTndrSub.StartPosition = FormStartPosition.CenterParent;
            frmTndrSub.ShowDialog();            

        }

         
        StringBuilder checkedWorkOrderId = null;
        string workOrderProjTitle = null;
        private int checkGridViewSelection()
        {
            int iCnt = 0;             
            checkedWorkOrderId = new StringBuilder();
            for (int iCounter = 0; iCounter < dgvWorkOrders.RowCount; iCounter++)
            {
                DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgvWorkOrders.Rows[iCounter].Cells[0];

                if (chkactive.Value != null)
                {
                    if (chkactive.Value.ToString().ToLower() == "true")
                    {
                        workOrderProjTitle = dgvWorkOrders.Rows[iCounter].Cells[2].Value.ToString();
                        checkedWorkOrderId.Append(dgvWorkOrders.Rows[iCounter].Cells[1].Value + "," + Convert.ToDateTime(dgvWorkOrders.Rows[iCounter].Cells[11].Value).ToString("dd/MMM/yyyy") + "," + dgvWorkOrders.Rows[iCounter].Cells[8].Value);
                        iCnt = iCnt + 1;
                    }
                }
            }             
            if (iCnt == 0)
            {
                MessageBox.Show("Please check at least one checkbox against the Work Order for which you wish to Issue Voucher", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return iCnt;
            }

            if (iCnt > 1)
            {
                MessageBox.Show("At a time, Please check only one checkbox against the Work Order for which you wish to Issue Voucher", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return iCnt;
            }

            return iCnt;
        }

        //private void dgvWorkOrders_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        //{              

            //if (e.Control is Button)
            //{

            //    Button btn = e.Control as Button;

            //    btn.Click -= new EventHandler(btnUpdate_Click);

            //    btn.Click += new EventHandler(btnUpdate_Click);

            //}

        //}

        void btnUpdate_Click(object sender, EventArgs e)
        {
            UpdateMozanahID(dgvWorkOrders.Rows[dgvWorkOrders.CurrentCell.RowIndex].Cells[6].ToString(), dgvWorkOrders.Rows[dgvWorkOrders.CurrentCell.RowIndex].Cells[8].ToString());    
        }        
    }
}
