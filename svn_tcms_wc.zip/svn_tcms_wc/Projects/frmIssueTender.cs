﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace MDI_ParenrForm.Projects
{
    public partial class frmIssueTender : Form
    {
        int _ProjId = 0;
        public frmIssueTender(string PrjID)
        {
            InitializeComponent();
            _ProjId = Convert.ToInt16(PrjID);
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            int stgID = 0;
            stgID = 2;
            int dateID = 0;
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["BUDGETConnString"].ConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"SELECT MAX(date_id) FROM DATES";
                        dateID = Convert.ToInt16(cmd.ExecuteScalar());
                        dateID = dateID + 1;                          
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE DATES records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["BUDGETConnString"].ConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        cmd.CommandText = @"INSERT INTO DATES(date_id,proj_id,stage_id,ts_tender_issue,receipt_no,employee_id) VALUES(@dateId,@projId,@stageId,@tenderIssue,@tendrReceiptNo,@empId)";

                        cmd.Parameters.AddWithValue("@dateId", dateID);
                        cmd.Parameters.AddWithValue("@projId", _ProjId);
                        cmd.Parameters.AddWithValue("@stageId", stgID);
                        cmd.Parameters.AddWithValue("@tenderIssue", Convert.ToDateTime(dtpTenderIssueDate.Value).ToString("MM/dd/yyyy"));
                        cmd.Parameters.AddWithValue("@tendrReceiptNo", txtReceiptNo.Text);
                        cmd.Parameters.AddWithValue("@empId", cmbAuthorized.SelectedValue); 
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();

                        MessageBox.Show("Tender Issued data added Succesfully");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE DATES records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
