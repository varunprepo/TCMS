﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using DataGridViewAutoFilter;
using MDI_ParenrForm;
using MDI_ParenrForm.Projects;
using System.Text.RegularExpressions;
//using MDI_ParenrForm;
//using MDI_ParenrForm.Projects;
using System.DirectoryServices;
using MDI_ParenrForm.Admin;
using System.Net.Mail;
using System.Globalization;
using System.Threading;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security; 

namespace TenderTrackingSystem
{
    public partial class ProjectStages : Form
    {
        static Int32 projId = 0;
        static short _commId = 0;
        static short tenderTypeId = 0;
        static string strFiscalYr = null;
        static DateTime? dtCreateDate = null;

        Boolean chkProjectTrnsfor = false;
        Boolean chkOnHold = false;
        static string connStr = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();
        SqlConnection sqlConn = new SqlConnection(connStr);
        bool isOnLoad = false;
        //protected SqlConnection sqlCon;
        protected SqlCommand sqlCom;
        protected SqlDataReader sqlDtReader;
        char _chGetShortListed = ' ';
        clsStaffUpdate clsStaff = new clsStaffUpdate();


        //static string userName = null;
        string _prjCode = string.Empty;
        string proj_Title = string.Empty;
        int _projID = 0;
        string ministryCode = string.Empty;
        string budjetRefNo = string.Empty;
        string provisionNo = string.Empty;
        string tenderStatus = string.Empty;
        string _cmtName = string.Empty;
        string _tndrType = string.Empty;
        string _fiscalYear = string.Empty;
        string _profileName = null;
        string mSelectedTab = null;
        string mCommitteeShortName = null;
        IList<string> mUserRightsColl = new List<string>();
        CommonClass commCls = new CommonClass("");

        clsPtd_Stage clsForPTD = null;
        clsTs_Stage clsForTS = null;
        clsTE_Stage clsForTE = null;
        clsCP_Stage clsForCP = null;
        clsPostContract_Stage clspC = null;

        string _userName = string.Empty;
        bool mIsHeadOfSection = false;


        public ProjectStages(IList<string> userRightsCollPrjState, string profileName, int prjID, string committeeName, string user, string selectedTab, bool isHeadOfSection)
        {
            mUserRightsColl = userRightsCollPrjState;
            _userName = user;
            mIsHeadOfSection = isHeadOfSection;
            InitializeComponent();
            //dtpFE_daterecFin1.Value = Convert.ToDateTime(DateTime.Now.ToString());
            _projID = prjID;
            _profileName = profileName;
            ProjectId = prjID;
            mSelectedTab = selectedTab;
            mCommitteeShortName = committeeName; // Added by Varun on 18/May/2017
            lblContractNoDisplay.Visible = false;

            commCls.DisplayContractNumber(lblContractNoDisplay, lblContractNo, btnWorkOrder, btnWorkOrder2, prjID);
            FillProjectComboInfo();
            FillProjectInfo();

            if (msk_dtp_tsRecOn.Text == "" && msk_dtp_tsStage1.Text == "")
                btnIssueTender.Visible = true;
            if (_tndrType == "L" || _tndrType == "DO" || _tndrType == "LP")
                btnIssueTender.Text = "Add To ShortList";
            else
                btnIssueTender.Text = "Issue a Tender...";

            clsForPTD = new clsPtd_Stage(user);
            clsForTS = new clsTs_Stage(user);
            clsForTE = new clsTE_Stage(user);
            clsForCP = new clsCP_Stage(user, isHeadOfSection);
            clspC = new clsPostContract_Stage(user);

            if (txtTenderNo.Text == "")
                btnAssignTender.Visible = true;
            else
                lblTenderNo.Visible = true;

            dgvPC.DataError += new DataGridViewDataErrorEventHandler(dgvPC_DataError);
            dgvPC.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(dgvPC_CellValueChanged);
            dgvContracts.DataError += new DataGridViewDataErrorEventHandler(dgvContracts_DataError);
            dgvCpDataEntry.DataError += new DataGridViewDataErrorEventHandler(dgvCpDataEntry_DataError);
            // Added by Varun on 21 May 2014 for checking the duplicate ContractNo.
            dgvCpDataEntry.EditingControlShowing += new DataGridViewEditingControlShowingEventHandler(dgvCpDataEntry_EditingContractNoColumn);
            lblProjID.Text = _projID.ToString();

        }
        void dgvContracts_DataError(object sender, DataGridViewDataErrorEventArgs e)     //dgvContracts_DataError
        {
            e.Cancel = true;
        }
        void dgvCpDataEntry_DataError(object sender, DataGridViewDataErrorEventArgs e)     //dgvContracts_DataError
        {
            e.Cancel = true;
        }
        private void dgvPC_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {

        }

        // Added by Varun on 21 May 2014 for checking the duplicate ContractNo.
        TextBox txtContractNo = null;
        string currentBidderID = null;
        void dgvCpDataEntry_EditingContractNoColumn(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            if (mUserRightsColl.Contains("48") && mUserRightsColl.Contains("50"))     // 50 for DA
            {
                MessageBox.Show("You have no privilege to edit the Contract Number,Contact administrator");
                return;
            }
            if (this.dgvCpDataEntry.CurrentCell.ColumnIndex == 7)
            {
                txtContractNo = e.Control as TextBox;

                if (txtContractNo.Text != "")
                {
                    if (txtContractNo.Text.ToLower().Trim() != "framework")
                    {
                        currentBidderID = dgvCpDataEntry[9, dgvCpDataEntry.CurrentCell.RowIndex].Value.ToString();
                        txtContractNo.Leave -= new EventHandler(txtContractNo_Leave);
                        txtContractNo.Leave += new EventHandler(txtContractNo_Leave);
                    }
                }
            }
        }

        // Added by Varun on 21 May 2014 for checking the duplicate ContractNo.
        private void txtContractNo_Leave(object sender, EventArgs e)
        {
            if (txtContractNo.Text.Trim() != "" && txtContractNo.Text.ToLower().Trim() != "framework")
            {
                if (ValidateContractNo(txtContractNo.Text) == false)
                    txtContractNo.Focus();
            }
        }

        int finalProjId = 0;
        public int ProjectId
        {
            get { return finalProjId; }
            set { finalProjId = value; }
        }
        private void ProjectStages_Load(object sender, EventArgs e)
        {

            CultureInfo m_EnglishCulture = new CultureInfo("en-US", true);
            // set which culture to use
            //Thread.CurrentThread.CurrentUICulture = new CultureInfo("en-US");
            System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.CreateSpecificCulture("en-US");
            System.Threading.Thread.CurrentThread.CurrentUICulture = System.Threading.Thread.CurrentThread.CurrentCulture;

            dtpRecievedOn.Format = DateTimePickerFormat.Custom;

            if ((mUserRightsColl.Count != 0 && mUserRightsColl.Contains("111")))
            {
                btnExportToExcel.Visible = false;
            }

            if (mUserRightsColl.Contains("17"))
            {
                cmbMinistryCode.Enabled = false;
                cmbBudgetRef.Enabled = false;
                txtProvisionNo.Enabled = false;
            }

            if (txtTenderNo.Text == "")
                btnAssignTender.Visible = true;
            else
                lblTenderNo.Visible = true;


            if (mUserRightsColl.Contains("12"))
            {
                cmbTenderStatus.Enabled = false;
            }

            if (mUserRightsColl.Contains("38"))
            {
                btnPTD.Enabled = false;
                btnPtdDelete.Enabled = false;
                btnPtdClear.Enabled = false;
            }
            if (mUserRightsColl.Contains("40"))
            {
                btnTS.Enabled = false;
            }
            if (mUserRightsColl.Contains("42"))
            {
                btnIssueTender.Enabled = false;
            }
            if (mUserRightsColl.Contains("43"))
            {
                btnViewBidder.Enabled = false;
            }
            if (mUserRightsColl.Contains("44"))
            {
                btnExportToPdf.Enabled = false;
            }
            if (mUserRightsColl.Contains("46"))
            {
                btnTE_Save.Enabled = false;
            }
            if (mUserRightsColl.Contains("48"))
            {
                btnCP_Save.Enabled = false;
            }
            if (mUserRightsColl.Contains("69"))
            {
                btnViewShortList.Enabled = false;
            }
            if (mUserRightsColl.Contains("70"))
            {
                btnTenderSubmissionStage1.Enabled = false;
            }
            //if (mUserRightsColl.Contains("76"))
            if ((mUserRightsColl.Contains("73") || mUserRightsColl.Contains("120"))) //73-->Create Work Orders 120-->View Work Orders                
            {
                btnWorkOrder.Enabled = false;
                btnWorkOrder2.Enabled = false; 
            }
            
            if (mUserRightsColl.Contains("107"))
            {
                btnTenderSubmissionStg2.Enabled = false;
            }

            //if (!(cmbTenderStatus.Text.Equals("Tender Preparation") || cmbTenderStatus.Text.Equals("Tendering") ||
            //        cmbTenderStatus.Text.Equals("Technical Evaluation") || cmbTenderStatus.Text.Equals("Financial Evaluation") || 
            //        cmbTenderStatus.Text.Equals("Technical and Financial Evaluation")))
            //{
            if (mUserRightsColl.Count != 0)
            {
                if (cmbTenderStatus.SelectedValue != null) 
                {
                    // cmbTenderStatus.SelectedValue.ToString() == "13" || cmbTenderStatus.SelectedValue.ToString() == "14" || cmbTenderStatus.SelectedValue.ToString() == "15"
                    if (cmbTenderStatus.SelectedValue.ToString() == "7" || cmbTenderStatus.SelectedValue.ToString() == "8") //cmbTenderStatus.SelectedValue.ToString() == "6" || 6-Award, 7-Committed, 8-Cancelled, 13-NOA Issued, 14-Contract Signed, 15-Signature Processing
                    {
                        DisabledAllControls();
                    }
                }
            }
            //}             
            //else if (!(cmbTenderStatus.Text.Equals("Tender Preparation") || cmbTenderStatus.Text.Equals("Tendering") ||
            //    cmbTenderStatus.Text.Equals("Re-Tender")))
            //{
            //    //Added by Varun on 24-Nov-2015
            //    if (mUserRightsColl.Count != 0)
            //    {
            //        DisabledAllControls();
            //    }
            //}             

            if (mUserRightsColl.Count == 0)
            { 
                cmbTenderStatusChange.Visible = true;
                btnUpdateProjStatus.Visible = true;
            }

            EnableTabs_BasedOn_UserRights();

            saveChk = FillTenderStageInfo(ref dateID_Ts, ref mdfExistDate);
            FillTenderEvaluationInfo(ref dateID_TEA);

            PopulatingVariousStagesTabControlsOfProject();
            //commCls.FillGridSentDocsInfo(Convert.ToInt16(lblProjID.Text),ref dgvTS_Sent, 2);
            //commCls.FillGridReceivedDocsInfo(Convert.ToInt16(lblProjID.Text), ref dgvTS_Rec, 2);

            //dgvTS_Sent
        }

        //Added by Varun on 24-Nov-2015
        private void DisabledAllControls()
        {
            //for (int i = 0; i <= mUserRightsColl.Count; i++)
            //{
            //    MessageBox.Show(mUserRightsColl[i].ToString());
            //}       

            dtpRecievedOn.Enabled = false;
            msk_dtpRecievedOn.Enabled = false; 
            cmbPurpose.Enabled = false;
            cmbAssignedQs.Enabled = false;
            cmbQsWorkingStatus.Enabled = false;
            dtpReview.Enabled = false;
            msk_dtpReview.Enabled = false;
            cmbTenderDocStatus.Enabled = false;
            dtpFrwdDept.Enabled = false;
            msk_dtpFrwdDept.Enabled = false;
            txtRemarks.Enabled = false;
            btnPTD.Enabled = false;
            btnPtdDelete.Enabled = false;
            btnPtdClear.Enabled = false;
            dtp_tsRecOn.Enabled = false;
            msk_dtp_tsRecOn.Enabled = false;
            cmb_tstenderHandle.Enabled = false;
            dtp_tsReturnDept.Enabled = false;
            msk_dtp_tsReturnDept.Enabled = false;
            dtp_tsRecFromDept.Enabled = false;
            msk_dtp_tsRecFromDept.Enabled = false;
            dtp_tsAdvertisement.Enabled = false;
            msk_dtp_tsAdvertisement.Enabled = false;
            dtp_tsInvitation.Enabled = false;
            msk_dtp_tsInvitation.Enabled = false;
            dtp_tsStage1.Enabled = false;
            msk_dtp_tsStage1.Enabled = false;
            dtp_tsStage2.Enabled = false;
            msk_dtp_tsStage2.Enabled = false;
            dtp_tsModifiedDate_Stage1.Enabled = false;
            msk_dtp_tsModifiedDate_Stage1.Enabled = false;
            txt_tsRemarks.Enabled = false;
            btnIssueTender.Enabled = false;
            btnTS.Enabled = false;
            btnViewBidder.Enabled = false;
            btnExportToPdf.Enabled = false;
            btnViewShortList.Enabled = false;
            dtpEA_reqdate.Enabled = false;
            msk_dtpEA_reqdate.Enabled = false;
            dtpEA_recfromcd.Enabled = false;
            msk_dtpEA_recfromcd.Enabled = false;
            dtpTE_datesent1.Enabled = false;
            msk_dtpTE_datesent1.Enabled = false;
            txtTechEval1ProposedWorkDays.Enabled = false;
            dtpTE_daterec1.Enabled = false;
            msk_dtpTE_daterec1.Enabled = false;
            dtpFE_datesentfin1.Enabled = false;
            msk_dtpFE_datesentfin1.Enabled = false;
            txtFinEval1ProposedWorkDays.Enabled = false;
            dtpFE_daterecFin1.Enabled = false;
            msk_dtpFE_daterecFin1.Enabled = false;
            dtpEA_apprDate.Enabled = false;
            msk_dtpEA_apprDate.Enabled = false;
            txtEA_Noofmeetings.Enabled = false;
            txtTE_remarks.Enabled = false;
            btnTE_Save.Enabled = false;
            btnCntrSave.Enabled = false; //Modified by Varun on 01/Dec/2019
            btnDelete.Enabled = false;
            btnCP_Save.Enabled = false;
            btnPC_Save.Enabled = false;
            cmbTenderStatus.Enabled = false;            
        }

        //Added by Varun on 04 Feb 2014 based on Adonis req.
        bool isCpContractorSign = false;
        private void EnableTabs_BasedOn_UserRights()
        {

            bool isRemoved = false;
            string tabToRemove = "ptdTabPage";
            for (int i = 0; i < tabControl1.TabPages.Count; i++)
            {
                if (tabControl1.TabPages[i].Name.Equals(tabToRemove, StringComparison.OrdinalIgnoreCase))
                {
                    if (mUserRightsColl.Contains("37"))
                    {
                        tabControl1.TabPages.RemoveAt(i);
                        isRemoved = true;
                        break;
                    }
                }
            }

            lblProjID.Visible = false;
            if (!isRemoved)
            {
                string tabToFind = "ptdTabPage";
                for (int i = 0; i < tabControl1.TabPages.Count; i++)
                {
                    if (tabControl1.TabPages[i].Name.Equals(tabToFind, StringComparison.OrdinalIgnoreCase))
                    {
                        if (ptdCmbFillChk == false)
                        {
                            FillCombo_PTD();
                            ptdCmbFillChk = true;
                            FillPTDInformation();
                        }
                        break;
                    }
                }
            }

            string tabToRemoveNext = "tsTabPage";
            for (int i = 0; i < tabControl1.TabPages.Count; i++)
            {
                if (tabControl1.TabPages[i].Name.Equals(tabToRemoveNext, StringComparison.OrdinalIgnoreCase))
                {
                    if (mUserRightsColl.Contains("39"))
                    {
                        tabControl1.TabPages.RemoveAt(i);
                        break;
                    }
                    else
                    {
                        //Added by Varun on 04 Feb 2014 based on Adonis req.
                        clsDatabase clsDB = new clsDatabase(ConfigurationManager.AppSettings["TCMSConnString"].ToString());
                        clsDB.ConnectDB();
                        if (clsDB.ExecuteReader1("select proj_id from PROJECTS where Tender_Status_id in(7,14,15) and proj_id=" + _projID))
                            isCpContractorSign = true;
                        clsDB.DisconnectDB();
                    }
                }
            }

            string tabToRemove3 = "teaTabPage";
            for (int i = 0; i < tabControl1.TabPages.Count; i++)
            {
                if (tabControl1.TabPages[i].Name.Equals(tabToRemove3, StringComparison.OrdinalIgnoreCase))
                {
                    if (mUserRightsColl.Contains("45"))
                    {
                        tabControl1.TabPages.RemoveByKey(tabControl1.TabPages[i].Name);
                        //tabControl1.TabPages.RemoveAt(i);
                        break;
                    }
                }
            }

            if (mCommitteeShortName != null)
            {

                if (!mCommitteeShortName.Equals("PQ")) //Added by Varun on 18/05/2017 Riyas Req.
                {
                    RemoveTabsBasedOnAccessRights();
                }
                else
                {
                    string tabToRemoveCP = "cpTabPage";
                    for (int i = 0; i < tabControl1.TabPages.Count; i++)
                    {
                        if (tabControl1.TabPages[i].Name.Equals(tabToRemoveCP, StringComparison.OrdinalIgnoreCase))
                        {
                            tabControl1.TabPages.RemoveAt(i);
                            break;
                        }
                    }
                    string tabToRemovePC = "pcsTabPage";
                    for (int i = 0; i < tabControl1.TabPages.Count; i++)
                    {
                        if (tabControl1.TabPages[i].Name.Equals(tabToRemovePC, StringComparison.OrdinalIgnoreCase))
                        {
                            tabControl1.TabPages.RemoveAt(i);
                            break;
                        }
                    }
                }
            }
            else
            {
                RemoveTabsBasedOnAccessRights();
            }

            if (_tndrType.Equals("DO"))
            {
                string tabToFindCp = "cpTabPage";
                for (int i = 0; i < tabControl1.TabPages.Count; i++)
                {
                    if (tabControl1.TabPages[i].Name.Equals(tabToFindCp, StringComparison.OrdinalIgnoreCase))
                    {
                        tabControl1.TabPages[i].Text = "CONTRACT PROCESS (DIRECT AWARD )";
                        //lblAwardDate.Text = "Direct Award Approval Date";
                        //lblAwardDate.Size= new Size(90, 48);
                        //lblAwardDate.Margin = new Padding(7, 8, 7, 8);      //7, 8, 7, 8
                        btnDatesExtend.Visible = false;
                        break;
                    }
                }
            }
            else
            {
                btnDatesExtend.Visible = true;
            }
        }

        private void RemoveTabsBasedOnAccessRights()
        {
            string tabToRemoveCP = "cpTabPage";
            for (int i = 0; i < tabControl1.TabPages.Count; i++)
            {
                if (tabControl1.TabPages[i].Name.Equals(tabToRemoveCP, StringComparison.OrdinalIgnoreCase))
                {
                    if (mUserRightsColl.Contains("47") && mUserRightsColl.Contains("49"))                   //userRightsColl.Contains("49") ||
                    {
                        tabControl1.TabPages.RemoveAt(i);
                        break;
                    }
                }
            }
            string tabToRemovePC = "pcsTabPage";
            for (int i = 0; i < tabControl1.TabPages.Count; i++)
            {
                if (tabControl1.TabPages[i].Name.Equals(tabToRemovePC, StringComparison.OrdinalIgnoreCase))
                {
                    if (mUserRightsColl.Contains("51"))
                    {
                        tabControl1.TabPages.RemoveAt(i);
                        break;
                    }
                }
            }
        }

        private void FillProjectComboInfo()
        {
            commCls.PopulateComboBox(cmb_tstenderHandle, @"Select employee_id, shortname from Contacts where shortname is not null order by shortname asc", "employee_id", "shortname");
            commCls.PopulateComboBox(cmbMinistryCode, @"SELECT Ministry_id,[MinistryCode] as MinistryCode FROM [MinistryCodes] ORDER BY MinistryCode", "Ministry_id", "MinistryCode");
            commCls.PopulateComboBox(cmbBudgetRef, @"SELECT [BudgetRef_id] as BudRefID, [BudgetRefNumber] as BudgeRefCode FROM [BudgetReferenceCodes] ORDER BY BudgeRefCode", "BudRefID", "BudgeRefCode");
            if (mSelectedTab == "Deleted Projects")
                commCls.PopulateComboBox(cmbTenderStatus, @"Select Tender_Status_id,[Status_Name] as tsStatus from [TenderStatus] Where Tender_Status_id =16 Order By Tender_Status_id", "Tender_Status_id", "tsStatus");
            else
                commCls.PopulateComboBox(cmbTenderStatus, @"Select Tender_Status_id,[Status_Name] as tsStatus from [TenderStatus] Order By Tender_Status_id", "Tender_Status_id", "tsStatus"); //Where Tender_Status_id in(7,8,9,10,11,17)
            if (mUserRightsColl.Count == 0)
                commCls.PopulateComboBox(cmbTenderStatusChange, @"Select Tender_Status_id,[Status_Name] as tsStatus from [TenderStatus] Order By Tender_Status_id", "Tender_Status_id", "tsStatus");
        }

        private void FillProjectInfo()
        {
            try
            {
                DAL dalObj = new DAL();
                IEnumerable<object> iEnum = null;
                DataTable dtProject = dalObj.GetDataFromDB("Project", "SELECT proj_id,project_code,replace(project_newname_en,',',' ') as project_newname,tender_no,Ministry_Code,Budget_Reference_No," +
                "Provision_Number,committee_id,Affair_id,department_id,Tender_Status_id,FYID,tender_type_id from PROJECTS where proj_id=" + _projID);

                DataTable dtCommittee = dalObj.GetDataFromDB("Committee", "SELECT committee_id,committee_short_name,committee_name from Committee");
                DataTable dtAffairs = dalObj.GetDataFromDB("AFFAIRS", "SELECT Affair_id,Affairs_Name from AFFAIRS2");
                //DataTable dtStages = dalObj.GetDataFromDB("STAGES", "SELECT stage_id,Stage_Name from STAGES");
                DataTable dtDepartment1 = dalObj.GetDataFromDB("Department", "SELECT department_id,Department,newDepID from Department2");
                DataTable dtDepartment2 = dalObj.GetDataFromDB("Department1", "SELECT department_id,Department,newDepID from Department2");
                DataTable dtTenderTypes = dalObj.GetDataFromDB("TenderTypes", "SELECT tender_type_id,tender_type_name,tender_type_short_name from TenderTypes");
                DataTable dtTenderStatus = dalObj.GetDataFromDB("TenderStatus", "SELECT Tender_Status_id,Status_Name from TenderStatus");
                DataTable dtFiscalYear = dalObj.GetDataFromDB("FiscalYear", "SELECT FYID,FiscalYear from FiscalYear");

                iEnum = (from p in dtProject.AsEnumerable()
                         join cmt in dtCommittee.AsEnumerable() on p.Field<int>("committee_id") equals cmt.Field<int>("committee_id")
                         join tt in dtTenderTypes.AsEnumerable() on p.Field<int>("tender_type_id") equals tt.Field<int>("tender_type_id")
                         join fy in dtFiscalYear.AsEnumerable() on p.Field<int>("FYID") equals fy.Field<int>("FYID")
                         join ts in dtTenderStatus.AsEnumerable() on p.Field<int>("Tender_Status_id") equals ts.Field<int>("Tender_Status_id")
                         join dpt in dtDepartment1.AsEnumerable() on p.Field<int>("department_id") equals dpt.Field<int>("department_id")
                         join dpt1 in dtDepartment2.AsEnumerable() on dpt.Field<Int16>("newDepID") equals dpt1.Field<int>("department_id")
                         join aff in dtAffairs.AsEnumerable() on p.Field<int>("Affair_id") equals aff.Field<int>("Affair_id")
                         select new
                         {
                             ProjectId = p.Field<int>("proj_id"),
                             ProjectCode = p.Field<string>("project_code"),
                             ProjectTitle = p.Field<string>("project_newname"),
                             TenderNo = p.Field<string>("tender_no"),
                             CommitteeShortName = cmt.Field<string>("committee_short_name"),
                             CommitteeName = cmt.Field<string>("committee_name"),
                             FiscalYear = fy.Field<string>("FiscalYear"),
                             TenderTypeShortName = tt.Field<string>("tender_type_short_name"),
                             MinistryCode = p.Field<string>("Ministry_Code"),
                             BudgetReferenceNo = p.Field<string>("Budget_Reference_No"),
                             ProvisionNumber = p.Field<string>("Provision_Number"),
                             StatusName = ts.Field<string>("Status_Name"),
                             CommitteeId = p.Field<int>("committee_id"),
                             AffairsName = aff.Field<string>("Affairs_Name"),
                             UserDepartment = dpt1.Field<string>("Department")
                         }).ToList(); // AsEnumerable();//.ToList();


                foreach (object drProj in iEnum)
                {
                    //dr[1] = strProj;    //ProjectId
                    _prjCode = drProj.ToString().Split(',')[1].Split('=')[1].Trim();  //ProjectId
                    txtProjCode.Text = _prjCode;
                    proj_Title = drProj.ToString().Split(',')[2].Split('=')[1].Trim();  //ProjectCode
                    lblProjID.Text = drProj.ToString().Split(',')[0].Split('=')[1].Trim();
                    txtproj.Text = drProj.ToString().Split(',')[2].Split('=')[1].Trim();
                    txtTenderNo.Text = drProj.ToString().Split(',')[3].Split('=')[1].Trim();

                    txtProvisionNo.Text = drProj.ToString().Split(',')[10].Split('=')[1].Trim().Replace(" ", "-").Replace("/", "-").Replace(".", "-").Trim();
                    cmbMinistryCode.Text = drProj.ToString().Split(',')[8].Split('=')[1].Trim();
                    cmbBudgetRef.Text = drProj.ToString().Split(',')[9].Split('=')[1].Trim();
                    // Added by Varun on 3rd Nov 2015
                    if (mSelectedTab != null)
                    {
                        if (mSelectedTab == "Archives")
                        {
                            if (drProj.ToString().Split(',')[11].Split('=')[1].Trim() == "Cancelled" || drProj.ToString().Split(',')[11].Split('=')[1].Trim() == "Re-Tender" ||
                                drProj.ToString().Split(',')[11].Split('=')[1].Trim() == "Transferred To Other Committee" || drProj.ToString().Split(',')[11].Split('=')[1].Trim() == "On Hold")
                            {
                                txt_tsRemarks.Enabled = false;
                                txtTE_remarks.Enabled = false;
                            }
                        }
                    }
                    if (mSelectedTab != "Deleted Projects")
                        cmbTenderStatus.Text = drProj.ToString().Split(',')[11].Split('=')[1].Trim();
                    else
                        cmbTenderStatus.Text = "Revert Deleted Project";
                    _cmtName = drProj.ToString().Split(',')[4].Split('=')[1].Trim();
                    _tndrType = drProj.ToString().Split(',')[7].Split('=')[1].Trim();
                    _fiscalYear = drProj.ToString().Split(',')[6].Split('=')[1].Trim();
                    if (txtTenderNo.Text != "")
                    {
                        btnAssignTender.Visible = false;
                     //   string todaysDate = DateTime.Now.ToString("dd/MMM/yyyy").Split('/')[0] + "/" + DateTime.Now.ToString("dd/MMM/yyyy").Split('/')[1];
                     ////Added by Varun on 28/Nov/2018 For Setting the default Received Date Based on Tender No. Year (If Tender No. has generated
                     //   if (_fiscalYear.Contains("-"))
                     //   {
                     //       dtpRecievedOn.Value = Convert.ToDateTime(todaysDate + _fiscalYear.Split('-')[0]);
                     //   }
                     //   else
                     //   {
                     //       dtpRecievedOn.Value = Convert.ToDateTime(todaysDate + _fiscalYear);
                     //   }
                    }
                    _commId = Convert.ToSByte(drProj.ToString().Split(',')[12].Split('=')[1].Trim());
                    _userDept = drProj.ToString().Split(',')[14].Split('=')[1].Replace('}', ' ').Trim();
                    _AffairsName = drProj.ToString().Split(',')[13].Trim().Split('=')[1];

                }//For end

            } //Try End                            
            catch (Exception ex)
            {
                MessageBox.Show("Error While Reading Project Data" + ex.Message);
            }

        }

        #region   // For Prepare Tender Document Tab


        private void FillPTDInformation()
        {
            clsForPTD.CreateGridviewForPTD(dgvPTD, _projID);
            FillReceiveSentDocs();
        }
        private void FillReceiveSentDocs()
        {
            if (tabControl1.SelectedTab.Name == "ptdTabPage")
            {
                commCls.FillGridReceivedDocsInfo(_projID, ref dgvPTD_Rec, 1);
                commCls.FillGridSentDocsInfo(_projID,ref dgvPTD_Sent, 1);
            }
        }
        private void FillCombo_PTD()
        {
            cmbPurpose.Items.Add("Preparation");
            cmbPurpose.Items.Add("Review");
            cmbPurpose.Items.Add("Amendment");
            cmbPurpose.Items.Add("Re-Tender");
            cmbPurpose.Items.Add("Tender");

            cmbPurpose.SelectedIndex = -1;

            commCls.PopulateComboBox(cmbAssignedQs, "SELECT employee_id, shortname from Contacts where shortname is not null order by shortname asc", "employee_id", "shortname");
            cmbAssignedQs.SelectedIndex = -1;

            cmbQsWorkingStatus.Items.Add("On-going");
            cmbQsWorkingStatus.Items.Add("Completed");
            cmbQsWorkingStatus.Items.Add("On Hold");
            cmbQsWorkingStatus.SelectedIndex = -1;

            cmbTenderDocStatus.Items.Add("Approved");
            cmbTenderDocStatus.Items.Add("Disapproved");
            cmbTenderDocStatus.SelectedIndex = -1;
        }
        private void btnReceiveDoc_Click(object sender, EventArgs e)
        {
            if (!_profileName.Equals("VIEW ALL"))
            {
                if (mUserRightsColl.Contains("19"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }
                ReceivedDocProperties receivedDoc = new ReceivedDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), 1, _userName);
                receivedDoc.StartPosition = FormStartPosition.CenterParent;
                receivedDoc.ShowDialog();
                commCls.FillGridReceivedDocsInfo(Convert.ToInt16(lblProjID.Text),ref dgvPTD_Rec, 1);
            }
        }
        private void btnSentDoc_Click(object sender, EventArgs e)
        {
            if (_profileName != "VIEW ALL")
            {
                if (mUserRightsColl.Contains("19"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }
                SentDocProperties sentDocProp = new SentDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), 1, _userName);
                sentDocProp.StartPosition = FormStartPosition.CenterParent;
                sentDocProp.ShowDialog();
                commCls.FillGridSentDocsInfo(Convert.ToInt16(lblProjID.Text),ref dgvPTD_Sent, 1);
            }
        }
        private void dgvPTD_Rec_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (mUserRightsColl.Contains("20"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }
            int rowIndex = e.RowIndex;
            try
            {
                if (rowIndex != -1)
                {
                    if (dgvPTD_Rec.Rows[rowIndex].Cells[3].Value.ToString() != "")
                    {
                        int docId = Convert.ToInt32(dgvPTD_Rec.Rows[rowIndex].Cells[3].Value);
                        ReceivedDocProperties receivedDoc = new ReceivedDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), txtProjCode.Text, docId, 1, _userName);
                        receivedDoc.StartPosition = FormStartPosition.CenterParent;
                        receivedDoc.ShowDialog();
                        commCls.FillGridReceivedDocsInfo(Convert.ToInt16(lblProjID.Text),ref dgvPTD_Rec, 1);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void dgvPTD_Sent_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (mUserRightsColl.Contains("20"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            int rowIndex = e.RowIndex;

            try
            {
                if (rowIndex != -1)
                {
                    if (dgvPTD_Sent.Rows[rowIndex].Cells[0].Value.ToString() != "")
                    {
                        int docId = Convert.ToInt32(dgvPTD_Sent.Rows[rowIndex].Cells[0].Value);
                        SentDocProperties sentDoc = null;
                        if (dgvPTD_Sent.Rows[rowIndex].Cells[1].Value.ToString() != "")
                            sentDoc = new SentDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), txtProjCode.Text, docId, 1, _userName, dgvPTD_Sent.Rows[rowIndex].Cells[0].Value, 'Y', mIsHeadOfSection);
                        else
                            sentDoc = new SentDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), txtProjCode.Text, docId, 1, _userName, "", 'Y', mIsHeadOfSection);

                        sentDoc.StartPosition = FormStartPosition.CenterParent;
                        sentDoc.ShowDialog();

                        commCls.FillGridSentDocsInfo(Convert.ToInt16(lblProjID.Text),ref dgvPTD_Sent, 1);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region   // For Tender Stage Tab

        private void btnIssueTender_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
            {
                if (mUserRightsColl.Contains("70"))
                {
                    int hrCnt = System.DateTime.Now.Hour;
                    if (hrCnt >= 13)
                    {
                        if (btnIssueTender.Text == "Issue a Tender...")
                            MessageBox.Show("Issue a tender time is exceeded for the day, Please contact head of section", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show("Can not add to shortlist, time is exceeded for the day, Please contact head of section", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                }
            }

            if ((mUserRightsColl.Count != 0 || mUserRightsColl.Count == 0) && mIsHeadOfSection == false)
            {
                if (msk_dtp_tsStage1.Text.Trim() != "")
                {
                    DateTime start = new DateTime(1990, 1, 1);
                    if (msk_dtp_tsModifiedDate_Stage1.Text.Trim() != "")
                        start = Convert.ToDateTime(msk_dtp_tsModifiedDate_Stage1.Text);
                    else
                        start = Convert.ToDateTime(msk_dtp_tsStage1.Text);

                    DateTime end = new DateTime(1990, 1, 31);
                    end = System.DateTime.Now;

                    int dateCnt = Convert.ToInt16((start - end).Days);
                    if (dateCnt < 0)
                    {
                        if (btnIssueTender.Text == "Issue a Tender...")
                            MessageBox.Show("You can't Issue a tender after Tender Closing Date expired", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show("You can't add to shortlist after Tender Closing Date expired", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                }
            }

            if (btnIssueTender.Text == "Issue a Tender...")
            {
                if (mUserRightsColl.Contains("42"))
                {
                    MessageBox.Show("You have no privilege to Issue a Tender. Please Contact system administrator.");
                    return;
                }

                string strSelectedComp = commCls.chkAccessRightsAndSelectedCompanies('I', mUserRightsColl, txtTenderNo.Text, msk_dtp_tsStage1, chkLocal, chkInternational, chkJointVenture);
                if (strSelectedComp == "R")
                    return;

                //New parameter closing date added by Varun on 07/Jun/2015
                MDI_ParenrForm.Projects.frmIssueTenderInfo tenderInfo = new MDI_ParenrForm.Projects.frmIssueTenderInfo(mUserRightsColl, Convert.ToInt16(lblProjID.Text), txtTenderNo.Text, txtproj.Text, strSelectedComp, _userName, 'N', "Issue", _prjCode, txtDocumentFee.Text);
                tenderInfo.StartPosition = FormStartPosition.CenterParent;
                tenderInfo.ShowDialog();
            }
            else
            {
                if (mUserRightsColl.Contains("42"))
                {
                    MessageBox.Show("You have no privilege to Add Company in the Short List. Please Contact system administrator.");
                    return;
                }

                string strSelectedCompanies = string.Empty;
                strSelectedCompanies = commCls.chkAccessRightsAndSelectedCompanies('A', mUserRightsColl, txtTenderNo.Text, msk_dtp_tsStage1, chkLocal, chkInternational, chkJointVenture);
                if (strSelectedCompanies == "R")
                    return;
                //New parameter closing date added by Varun on 07/Jun/2015
                MDI_ParenrForm.Projects.frmAddToShortList addToShortList = new MDI_ParenrForm.Projects.frmAddToShortList(mUserRightsColl, Convert.ToInt16(lblProjID.Text), txtTenderNo.Text, txtproj.Text, strSelectedCompanies, _userName, msk_dtpEA_stage1.Text);
                addToShortList.StartPosition = FormStartPosition.CenterParent;
                addToShortList.ShowDialog();
            }
        }
        private void btnTS_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Contains("40"))       // For TS
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            int updDateID = 0;
            string tsReceivedDate = string.Empty;

            int statusID = 0;
            statusID = getStatusID(ProjectId);

            if (CheckDataExistForTenderStage(ref updDateID, ref tsReceivedDate) == true)
            {
                UpdateTenderStageInfo(updDateID);

                if (msk_dtp_tsModifiedDate_Stage1.Text != "")
                {
                    if (Convert.ToDateTime(msk_dtp_tsModifiedDate_Stage1.Text.Split(' ')[0]).ToString("dd/MMM/yyyy").CompareTo(Convert.ToDateTime(System.DateTime.Now.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy")) == 1)
                    {
                        if (statusID < 2)
                        {
                            UpdateStatusForClosingDate();
                            // added by Varun on 11/05/2015
                            FillProjectInfo();
                        }
                    }
                }
                else if (msk_dtp_tsStage1.Text != "")
                {
                    if (Convert.ToDateTime(msk_dtp_tsStage1.Text.Split(' ')[0]).ToString("dd/MMM/yyyy").CompareTo(Convert.ToDateTime(System.DateTime.Now.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy")) == 1)
                    {
                        // if (statusID < 2)
                        UpdateStatusForClosingDate();
                    }
                }

                if (msk_dtp_tsRecOn.Text != "")
                {
                    //string  dt = Convert.ToDateTime(tsReceivedDate); //.ToString("dd-MMM-yyyy");
                    //string dt1 = Convert.ToDateTime(tsReceivedDate); //.ToString("dd-MMM-yyyy");
                    if (tsReceivedDate != "")
                    {
                        if (Convert.ToDateTime(tsReceivedDate.Split(' ')[0]).ToString("dd/MMM/yyyy").CompareTo(Convert.ToDateTime(msk_dtp_tsRecOn.Text).ToString("dd/MMM/yyyy")) != 0)
                        {
                            if (statusID < 2)
                            {
                                UpdateStatusFor_ReceivedDate();
                                // added by Varun on 11/05/2015
                                FillProjectInfo();
                            }
                        }
                    }
                }
            }
            else
            {
                int dateID = MaxDateID();
                if (msk_dtp_tsRecOn.Text == "")
                { MessageBox.Show("Please select tender received date"); return; }

                InsertTenderStageInfo(dateID);
                clsForPTD.UpdateStageLevel(_projID);
                if (msk_dtp_tsModifiedDate_Stage1.Text != "")
                {
                    if (Convert.ToDateTime(msk_dtp_tsModifiedDate_Stage1.Text).CompareTo(Convert.ToDateTime(System.DateTime.Now.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy")) == -1)
                    {
                        UpdateStatusForClosingDate();
                        // added by Varun on 11/05/2015
                        FillProjectInfo();
                    }
                }
                else if (msk_dtp_tsStage1.Text != "")
                {
                    if (Convert.ToDateTime(msk_dtp_tsStage1.Text).CompareTo(Convert.ToDateTime(System.DateTime.Now.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy")) == -1)
                    {
                        UpdateStatusForClosingDate();
                        // added by Varun on 11/05/2015
                        FillProjectInfo();
                    }
                }
            }


        }

        private int MaxDateID()
        {
            SqlConnection sqlConn = null;
            int dateId = 0;
            try
            {
                using (sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"SELECT MAX(DATE_ID)+1 FROM TenderDatesInfo";
                        dateId = Convert.ToInt16(cmd.ExecuteScalar());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while reading Max Date, Try again.", ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {
                sqlConn.Close();
            }
            return dateId;
        }

        private int getStatusID(int projID)
        {
            string strQuery = "SELECT Tender_Status_id FROM projects WHERE (proj_id = " + projID + ")";
            int sttID = 0;
            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                    {
                        if (sqlDr.HasRows)
                        {
                            while (sqlDr.Read())
                            {
                                sttID = Convert.ToInt32(sqlDr[0].ToString());
                            }
                        }
                    }
                }
                sqlCn.Close();
            }
            return sttID;
        }

        private string getReceivedOnDate(int projID)
        {
            string strQuery = "SELECT ts_receive_on FROM tenderdatesinfo WHERE (proj_id = " + projID + ")";
            string dt_tsRecOn = string.Empty;
            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                    {
                        if (sqlDr.HasRows)
                        {
                            while (sqlDr.Read())
                            {
                                if (sqlDr[0].ToString() != "")
                                {
                                    dt_tsRecOn = sqlDr[0].ToString();
                                }
                            }
                        }
                    }
                }
                sqlCn.Close();
            }
            return dt_tsRecOn;
        }
        private void btnViewBidder_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Contains("43"))
            {
                MessageBox.Show("You have no privilege to View Bidders. Please Contact system administrator.");
                return;
            }

            string strSelectedCompanies = string.Empty;
            strSelectedCompanies = commCls.chkAccessRightsAndSelectedCompanies('V', mUserRightsColl, null, null, chkLocal, chkInternational, chkJointVenture);

            int _circularCnt = clsForTS.GetCircularCount(_projID);

            MDI_ParenrForm.Projects.frmBidderInfo frmbidders = null;
            //replace msk_dtp_tsAdvertisement.Text by msk_dtp_tsInvitation.Text based on Riyas request by Varun on 16 Feb 2014 
            if (_chGetShortListed == 'Y')
                frmbidders = new MDI_ParenrForm.Projects.frmBidderInfo(mUserRightsColl, _projID, txtProjCode.Text, txtproj.Text, txtTenderNo.Text, strSelectedCompanies, _userName, txtTenderBond.Text, txtDocumentFee.Text, msk_dtp_tsInvitation.Text, '3', strEligibleTenderTypes, 'Y', _tndrType, 1);
            else
                frmbidders = new MDI_ParenrForm.Projects.frmBidderInfo(mUserRightsColl, _projID, txtProjCode.Text, txtproj.Text, txtTenderNo.Text, strSelectedCompanies, _userName, txtTenderBond.Text, txtDocumentFee.Text, msk_dtp_tsInvitation.Text, 'V', strEligibleTenderTypes, 'Y', _tndrType, 1);

            frmbidders.StartPosition = FormStartPosition.CenterScreen;
            frmbidders.ShowDialog();
        }
        private void btnRecDocTS_Click(object sender, EventArgs e)
        {
            if (_profileName != "VIEW ALL")
            {
                if (mUserRightsColl.Contains("19"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }
                ReceivedDocProperties receivedDoc = new ReceivedDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), 2, _userName);
                receivedDoc.StartPosition = FormStartPosition.CenterParent;
                receivedDoc.ShowDialog();

                commCls.FillGridReceivedDocsInfo(Convert.ToInt16(lblProjID.Text), ref dgvTS_Rec, 2);
            }
        }
        private void btnSentDocTS_Click(object sender, EventArgs e)
        {
            if (_profileName != "VIEW ALL")
            {
                if (mUserRightsColl.Contains("19"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }
                SentDocProperties sentDocProp = new SentDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), 2, _userName);
                sentDocProp.StartPosition = FormStartPosition.CenterParent;
                sentDocProp.ShowDialog();
                commCls.FillGridSentDocsInfo(Convert.ToInt16(lblProjID.Text),ref dgvTS_Sent, 2);
                int _circularCnt = clsForTS.GetCircularCount(_projID);
                txtCircular.Text = _circularCnt.ToString();
            }
        }

        #endregion

        #region   // For Tender Stage Tab

        private void btnTE_Save_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Contains("46"))         // For TE
            {
                MessageBox.Show("You have no privilege, Contact Administrator");
                return;
            }

            if (DateSendFirstEvalValidation(dtpTE_datesent1, msk_dtpTE_datesent1, msk_dtpEA_recfromcd, "Technical Evaluation", true) && DateReceivedFirstEvalValidation(dtpTE_daterec1, msk_dtpTE_datesent1, msk_dtpTE_daterec1, "Technical Evaluation", true)
            && DateSendSecEvalValidation(dtpTE_datesent2, msk_dtpTE_datesent2, msk_dtpTE_datesent1, msk_dtpTE_daterec1, "Technical Evaluation", true) && DateReceivedSecEvalValidation(dtpTE_daterec2, msk_dtpTE_daterec2, msk_dtpTE_datesent1, msk_dtpTE_daterec1, "Technical Evaluation", true)
            && FinEvalReceivedDate(true) && DateReceivedSecEvalValidation(dtpFE_daterecFin2, msk_dtpFE_daterecFin2, msk_dtpFE_datesentfin1, msk_dtpFE_daterecFin1, "Financial Evaluation", true)
            && ValidateTenderAwardApprovalDate(dtpEA_apprDate, msk_dtpEA_apprDate, true))
            {

            }
            else
            {
                return;
            }
             

            if (msk_dtpEA_recfromcd.Text != "" && msk_dtpEA_stage1.Text != "")
            {
                if (Convert.ToDateTime(msk_dtpEA_recfromcd.Text).CompareTo(Convert.ToDateTime(msk_dtpEA_stage1.Text)) >= 0)
                {
                    MessageBox.Show("Doc Received From CD Date cannot be greater than or equal to Tender Closing Date");
                    return;
                }
            }
            if (msk_dtpEA_recfromcd.Text == "" && (msk_dtpTE_datesent1.Text != "" || msk_dtpTE_daterec1.Text != "" || msk_dtpFE_datesentfin1.Text != "" || msk_dtpFE_daterecFin1.Text != ""))
            {
                //if (Convert.ToDateTime(msk_dtpEA_recfromcd.Text).CompareTo(Convert.ToDateTime(msk_dtp_tsInvitation.Text)) < 0)
                //{
                MessageBox.Show("Doc Received From CD Date cannot be blank");
                return;
                //}
            }
            if(msk_dtpEA_stage1.Text == "")
            {
                MessageBox.Show("Tender Closing Date cannot be blank");
                return;
            }
            if(msk_dtp_tsInvitation.Text == "")
            {
                MessageBox.Show("Tender Issue Date under Tender Stage cannot be blank");
                return;
            }
            int statusID = getStatusID(ProjectId);

            if (CheckDataExistForTenderEvaluation() == true)
            {
                UpdateTenderEvaluationData();
                Get_original_TenderDates();

                if (msk_dtpTE_datesent1.Text != "" & msk_dtpFE_datesentfin1.Text == "")
                {
                    if (statusID < 3)
                    {
                        clsForTE.UpdateTenderStatusForEvaluationData(_projID);
                    }
                }
                else if (msk_dtpTE_datesent1.Text != "" & msk_dtpFE_datesentfin1.Text != "")
                {
                    if (msk_dtpTE_datesent1.Text.Equals(msk_dtpFE_datesentfin1.Text))
                    {
                        if (statusID < 3)
                        {
                            clsForTE.UpdateTenderStatusFor_Tech_and_EvaluationData(_projID);
                        }
                    }
                    else if (!msk_dtpTE_datesent1.Text.Equals(msk_dtpFE_datesentfin1.Text))
                    {
                        if (statusID < 5)
                        {
                            clsForTE.UpdateTenderStatusForFinancialData(_projID);
                        }
                    }
                }
                // added by Varun on 30/05/2016
                FillProjectInfo();

            }
            else
            {
                int dateId = 0;
                dateId = MaxDateID();

                //if (msk_dtpEA_reqdate.Text == "")
                //{
                //    MessageBox.Show("Please Select Tender Open Date");
                //    return;
                //}
                InsertTenderEvaluationData(dateId);

                Get_original_TenderDates();

                //Sree

                if (msk_dtpTE_datesent1.Text != "" & msk_dtpFE_datesentfin1.Text == "")
                {
                    clsForTE.UpdateTenderStatusForEvaluationData(_projID);
                }
                else if (msk_dtpTE_datesent1.Text != "" & msk_dtpFE_datesentfin1.Text != "")
                {
                    if (msk_dtpTE_datesent1.Text.Equals(msk_dtpFE_datesentfin1.Text))
                    {
                        clsForTE.UpdateTenderStatusFor_Tech_and_EvaluationData(_projID);
                    }
                    else if (!msk_dtpTE_datesent1.Text.Equals(msk_dtpFE_datesentfin1.Text))
                    {
                        clsForTE.UpdateTenderStatusForFinancialData(_projID);
                    }
                }

                if (msk_dtpEA_apprDate.Text != "")
                {
                    if (msk_dtpTE_datesent1.Text != "" & msk_dtpFE_datesentfin1.Text != "")
                    {
                        clsForTE.UpdateTenderStatusForAward(_projID);
                    }
                }
                // added by Varun on 30/05/2016
                FillProjectInfo();
            }
        }
        private void btnSent_TEA_Click(object sender, EventArgs e)
        {
            if (_profileName != "VIEW ALL")
            {
                if (mUserRightsColl.Contains("19"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }
                SentDocProperties sentDocProp = new SentDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), 3, _userName);
                sentDocProp.StartPosition = FormStartPosition.CenterParent;
                sentDocProp.ShowDialog();

                commCls.FillGridSentDocsInfo(Convert.ToInt16(lblProjID.Text),ref dgvTE_Sent, 3);
            }
        }
        private void btnRecDocTE_Click(object sender, EventArgs e)
        {
            if (_profileName != "VIEW ALL")
            {
                if (mUserRightsColl.Contains("19"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }

                ReceivedDocProperties receivedDoc = new ReceivedDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), 3, _userName);
                receivedDoc.StartPosition = FormStartPosition.CenterParent;
                receivedDoc.ShowDialog();

                commCls.FillGridReceivedDocsInfo(Convert.ToInt16(lblProjID.Text),ref dgvTE_Rec, 3);
            }
        }

        #endregion

        private void button8_Click(object sender, EventArgs e)
        {
            ReceivedDocProperties receivedDoc = new ReceivedDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), txtProjCode.Text, Convert.ToInt16(lblProjID.Text), 0, _userName);
            receivedDoc.StartPosition = FormStartPosition.CenterParent;
            receivedDoc.ShowDialog();
        }
        private void button7_Click(object sender, EventArgs e)
        {
            SentDocProperties sentDocProp = new SentDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), txtProjCode.Text, Convert.ToInt16(lblProjID.Text), 0, _userName, "", 'N', mIsHeadOfSection);
            sentDocProp.StartPosition = FormStartPosition.CenterParent;
            sentDocProp.ShowDialog();
        }

        private void btnSavePrj_Click(object sender, EventArgs e)
        {
            //for (int i = 0; i < dgvPTD.Rows.Count - 1; i++)
            //{
            //   Array MyArray =new Array[5];               
            //   string ProductA = dgvPTD.Rows[i].Cells[0].Value.ToString();
            //   string ProductB = dgvPTD.Rows[i].Cells[1].Value.ToString();
            //   string Productc = dgvPTD.Rows[i].Cells[2].Value.ToString();
            //   string Productd = dgvPTD.Rows[i].Cells[3].Value.ToString();

            //MyArray.Add(ClassPro);
            //}

            //class Database Access Object
            //for (int i = 0; i < Class.MyArray.Count; i++)
            //{
            //    string InsertTable = "insert into table_name values('" + Class.MyArray[i].ProductA + "', '" + Class.MyArray[i].ProductB + "' )";
            //} 
        }

        private void GridViewRefresh_PTD()
        {
            SqlConnection sqlConn = new SqlConnection(connStr);
            DataTable dtProject = null;
            string[] projRows = new string[8];
            try
            {
                sqlConn = new SqlConnection(connStr);
                sqlConn.Open();
                DAL dalObj = new DAL();
                dtProject = dalObj.GetDataFromDB("ProjectPTD", "SELECT date_id,proj_id, stage_id, ptd_receive_on, ptd_purpose, ptd_assign_qs, ptd_sent_for_rev, ptd_qs_working_status, ptd_tendec_doc_cur_status,ptd_forwarded_to_dep, remarks FROM TenderDatesInfo WHERE (stage_id = 1) AND (proj_id = " + Convert.ToInt16(lblProjID.Text) + " ) Order by date_id");

                DataTable finalDt = new DataTable("ProjectPTD");
                finalDt.Columns.Add("ReceivedOn");
                finalDt.Columns.Add("Purpose");
                finalDt.Columns.Add("AssignedQS");
                finalDt.Columns.Add("Review");
                finalDt.Columns.Add("QSWorkingStatus");
                finalDt.Columns.Add("TenderDocumentCurrentStatus");
                finalDt.Columns.Add("ForwardedToTenderDepartment");
                finalDt.Columns.Add("Remarks");
                finalDt.Columns.Add("DateID");

                finalDt.AcceptChanges();
                foreach (DataRow drProj in dtProject.Rows)
                {
                    DataRow dr = finalDt.NewRow();
                    if (drProj[3] != DBNull.Value)
                        dr[0] = Convert.ToDateTime(drProj[3]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture);//ToString("dd/MMM/yyyy");   //ReceivedOn
                    else
                        dr[0] = drProj[3];   //ReceivedOn

                    dr[1] = drProj[4];  //Purpose
                    dr[2] = drProj[5]; ;  //AssignedQS

                    if (drProj[6] != DBNull.Value)
                        dr[3] = Convert.ToDateTime(drProj[6]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture);//ToString("dd/MMM/yyyy");  //Review
                    else
                        dr[3] = drProj[6];

                    dr[4] = drProj[7];  //QSWorkingStatus
                    dr[5] = drProj[8];  //TenderDocumentCurrentStatus

                    if (drProj[9] != DBNull.Value)
                        dr[6] = Convert.ToDateTime(drProj[9]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture);//ToString("dd/MMM/yyyy");  //ForwardedToTenderDepartment
                    else
                        dr[6] = drProj[9];

                    dr[7] = drProj[10];  //Remarks
                    //dr[9] = drProj[1];  //proj_id
                    // dr[10] = drProj[0];  //stage_id
                    dr[8] = Convert.ToInt16(drProj[0]);   //dateID
                    finalDt.Rows.Add(dr);
                    finalDt.AcceptChanges();
                }
                BindingSource myBindingSource = new BindingSource(finalDt, null);
                dgvPTD.DataSource = myBindingSource;
                dgvPTD.DefaultCellStyle.WrapMode = DataGridViewTriState.True;

                //dgvPTD.ColumnHeadersDefaultCellStyle.Font = new Font(dgvPTD.Font, FontStyle.Bold);

                dgvPTD.EnableHeadersVisualStyles = false;
                dgvPTD.Columns[8].Visible = false;
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }
        }
        Boolean ptdCmbFillChk = false;
        Boolean saveChk = false;
        Boolean saveTEAChk = false;
        int dateID_TEA = 0;


        private Boolean FillTenderStageInfo(ref int dateiDofTS, ref string mdfExistDate)
        {
            Boolean statusChk = false;

            string strQuery = "SELECT  ts_receive_on,ts_issue_handling, ts_return_to_dept, ts_receive_from_dept, ts_pr_advertise, ts_tender_invitation, ts_closing_s1, ts_closing_s2, " +
            " ts_modified_closing,ts_modified_closing_s2, date_id, proj_id, stage_id,remarks FROM TenderDatesInfo WHERE (proj_id = " + Convert.ToInt16(lblProjID.Text) + ") AND (stage_id = 2) AND (ts_tender_issue is null) AND (co_ID is NULL)";

            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    sqlCmd.CommandTimeout = 80;
                    using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                    {
                        if (sqlDr.HasRows)
                        {
                            statusChk = true;
                            while (sqlDr.Read())
                            {
                                if (sqlDr[0].ToString() != "")
                                {
                                    DateTime dt_tsRecOn = Convert.ToDateTime(sqlDr[0].ToString());
                                    msk_dtp_tsRecOn.Text = dt_tsRecOn.ToString("dd/MMM/yyyy");
                                }

                                cmb_tstenderHandle.Text = sqlDr[1].ToString();

                                if (sqlDr[2].ToString() != "")
                                {
                                    DateTime dt_tsReturnDept = Convert.ToDateTime(sqlDr[2].ToString());
                                    msk_dtp_tsReturnDept.Text = dt_tsReturnDept.ToString("dd/MMM/yyyy");
                                }
                                if (sqlDr[3].ToString() != "")
                                {
                                    DateTime dt_tsRecFromDept = Convert.ToDateTime(sqlDr[3].ToString());
                                    msk_dtp_tsRecFromDept.Text = dt_tsRecFromDept.ToString("dd/MMM/yyyy");
                                }
                                if (sqlDr[4].ToString() != "")
                                {
                                    DateTime dt_tsAdvertisement = Convert.ToDateTime(sqlDr[4].ToString());
                                    msk_dtp_tsAdvertisement.Text = dt_tsAdvertisement.ToString("dd/MMM/yyyy");
                                }
                                if (sqlDr[5].ToString() != "")
                                {
                                    DateTime dt_tsInvitation = Convert.ToDateTime(sqlDr[5].ToString());
                                    msk_dtp_tsInvitation.Text = dt_tsInvitation.ToString("dd/MMM/yyyy");
                                }
                                if (sqlDr[6].ToString() != "")
                                {
                                    DateTime dt_tsStage1 = Convert.ToDateTime(sqlDr[6].ToString());
                                    msk_dtp_tsStage1.Text = dt_tsStage1.ToString("dd/MMM/yyyy");
                                }
                                if (sqlDr[7].ToString() != "")
                                {
                                    msk_dtp_tsStage2.Text = Convert.ToDateTime(sqlDr[7]).ToString("dd/MMM/yyyy");
                                }
                                if (sqlDr[8].ToString() != "")
                                {
                                    DateTime dt_tsModifiedDate = Convert.ToDateTime(sqlDr[8]);
                                    msk_dtp_tsModifiedDate_Stage1.Text = dt_tsModifiedDate.ToString("dd/MMM/yyyy");
                                    mdfExistDate = dt_tsModifiedDate.ToString("dd/MMM/yyyy");
                                }

                                if (sqlDr[9].ToString() != "")
                                {
                                    msk_dtp_tsModifiedDate_Stage2.Text = Convert.ToDateTime(sqlDr[9]).ToString("dd/MMM/yyyy"); // dt_tsModifiedDate_S2.ToString("dd/MMM/yyyy");                                                                          
                                }
                                // cmb_tstenderHandle.Text = sqlDr[11].ToString();

                                txt_tsRemarks.Text = sqlDr[13].ToString();
                                dateiDofTS = Convert.ToInt16(sqlDr[12]);
                            }
                        }
                    }
                }
                sqlCn.Close();
            }
            return statusChk;
        }
        //private List<string> FillTender_ModifiedDates()
        //{
        //    List<string> dateColl = new List<string>();
        //    //cmbTndrMdfColl.Items.Clear();

        //    string strQuery = "SELECT tndr_modifiedDate,proj_id, stage_id FROM tndr_ModifiedDates WHERE (proj_id = " + Convert.ToInt16(lblProjID.Text) + ") order by DateID";

        //    using (SqlConnection sqlCn = new SqlConnection(connStr))
        //    {
        //        sqlCn.Open();
        //        using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
        //        {
        //            using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
        //            {
        //                if (sqlDr.HasRows)
        //                {
        //                    while (sqlDr.Read())
        //                    {
        //                        if (sqlDr[0].ToString() != "")
        //                        {
        //                            DateTime dt_tsRecOn = Convert.ToDateTime(sqlDr[0].ToString());

        //                            //cmbTndrMdfColl.Items.Add(dt_tsRecOn.ToString("dd/MMM/yyyy"));
        //                        }
        //                    }
        //                }
        //            }
        //        }
        //        sqlCn.Close();
        //    }
        //    if (cmbTndrMdfColl.Items.Count != 0)
        //        lblDateCnt.Text = cmbTndrMdfColl.Items.Count.ToString();
        //    return dateColl;
        //}
        private void FillProjectCostDetailsOfTenderEvaluation()
        {
            string strQuery = "SELECT budgeted_cost,estimated_cost FROM PROJECTCOST WHERE proj_id = " + Convert.ToInt16(lblProjID.Text) + " and Stage_id = 4";
            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {

                    using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                    {
                        if (sqlDr.HasRows)
                        {
                            while (sqlDr.Read())
                            {
                                if (sqlDr[0].ToString() != "") //&& sqlDr[0].ToString() != "0.0000"
                                {
                                    txtBudjetAmnt.Text = string.Format("{0:#,##0.00}", double.Parse(sqlDr[0].ToString())); //#,##0
                                }
                                else
                                    txtBudjetAmnt.Text = "";

                                if (sqlDr[1].ToString() != "" && sqlDr[1].ToString() != "0.0000")
                                {
                                    txtEstimatedAmnt.Text = string.Format("{0:#,##0.00}", double.Parse(sqlDr[1].ToString())); //#,##0
                                }
                                else
                                    txtEstimatedAmnt.Text = "";

                            }
                        }
                    }
                }
                sqlCn.Close();
            }
        }
        private void FillProjectCostDetailsOfContractProcess()
        {
            string strQuery = "SELECT budgeted_cost,estimated_cost FROM PROJECTCOST WHERE proj_id = " + Convert.ToInt16(lblProjID.Text) + " and Stage_id = 4 ";
            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                    {
                        if (sqlDr.HasRows)
                        {
                            while (sqlDr.Read())
                            {
                                if (sqlDr[0].ToString() != "") //&& sqlDr[0].ToString() != "0.0000"
                                {
                                    txtCp_BudgetAmnt.Text = string.Format("{0:#,##0.00}", double.Parse(sqlDr[0].ToString()));
                                }
                                else
                                    txtCp_BudgetAmnt.Text = "";
                                if (sqlDr[1].ToString() != "")
                                {
                                    txtCp_EstimatedAmnt.Text = string.Format("{0:#,##0.00}", double.Parse(sqlDr[1].ToString()));
                                }
                                else
                                    txtCp_EstimatedAmnt.Text = "";
                            }
                        }
                    }
                }
                sqlCn.Close();
            }
        }
        private void FillProjectCostDetailsOfPostContract()
        {
            string strQuery = "SELECT budgeted_cost,estimated_cost FROM PROJECTCOST WHERE proj_id = " + Convert.ToInt16(lblProjID.Text) + " and Stage_id = 4";
            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                    {
                        if (sqlDr.HasRows)
                        {
                            while (sqlDr.Read())
                            {
                                if (sqlDr[0].ToString() != "")
                                {
                                    txtPC_BudjetAmnt.Text = string.Format("{0:#,##0.00}", double.Parse(sqlDr[0].ToString()));
                                }
                                else
                                    txtPC_BudjetAmnt.Text = "";
                                if (sqlDr[1].ToString() != "")
                                {
                                    txtPC_EstimatedAmnt.Text = string.Format("{0:#,##0.00}", double.Parse(sqlDr[1].ToString()));
                                }
                                else
                                    txtPC_EstimatedAmnt.Text = "";
                            }
                        }
                    }
                }
                sqlCn.Close();
            }
        }
        private void FillProjectCostDetailsOfTenderStage()
        {
            string strQuery = "SELECT tender_bond,doc_fee FROM PROJECTCOST WHERE proj_id = " + Convert.ToInt16(lblProjID.Text) + " and Stage_id = 4";
            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    sqlCmd.CommandTimeout = 80;
                    using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                    {
                        if (sqlDr.HasRows)
                        {
                            while (sqlDr.Read())
                            {
                                if (sqlDr[0].ToString() != "")
                                {
                                    txtTenderBond.Text = string.Format("{0:#,##0.00}", double.Parse((sqlDr[0]).ToString()));
                                }
                                if (sqlDr[1].ToString() != "")
                                {
                                    txtDocumentFee.Text = string.Format("{0:#,##0.00}", double.Parse((sqlDr[1]).ToString())); //Convert.ToDouble(sqlDr[1]).ToString();
                                }
                            }
                        }
                    }
                }
                sqlCn.Close();
            }
        }
        private Boolean FillTenderEvaluationInfo(ref int dateiDofTEA)
        {
            Boolean statusTEAChk = false;
            string strQuery = "SELECT eval_tender_opening,eval_tender_doc_receive_from_cd, eval_tech_sent1, eval_tech_receive1, eval_com_sent1, " +
            " eval_com_receive1, eval_tender_award_approval,tender_validity_ext1,tender_validity_ext2,tenderbond_validity_ext1,tenderbond_validity_ext2,date_id, proj_id, stage_id,eval_no_of_meetings,remarks,TPWD1,FPWD1,TPWD2,FPWD2, " +
            "eval_tech_sent2,eval_tech_receive2,eval_com_sent2,eval_com_receive2 FROM TenderDatesInfo WHERE (proj_id = " + Convert.ToInt16(lblProjID.Text) + ") AND (stage_id = 3)";

            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    sqlCmd.CommandTimeout = 80;
                    using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                    {

                        if (sqlDr.HasRows)
                        {
                            statusTEAChk = true;
                            while (sqlDr.Read())
                            {
                                if (sqlDr[3].ToString() != "")
                                {
                                    DateTime dt_EA_daterec = Convert.ToDateTime(sqlDr[3].ToString());
                                    msk_dtpTE_daterec1.Text = dt_EA_daterec.ToString("dd/MMM/yyyy");
                                }
                                else
                                {
                                    msk_dtpTE_daterec1.Text = "";
                                }
                                if (sqlDr["eval_tech_receive2"].ToString() != "")
                                {
                                    DateTime dt_EA_daterec2 = Convert.ToDateTime(sqlDr["eval_tech_receive2"].ToString());
                                    msk_dtpTE_daterec2.Text = dt_EA_daterec2.ToString("dd/MMM/yyyy");
                                }
                                else
                                {
                                    msk_dtpTE_daterec2.Text = "";
                                }
                                if (sqlDr[5].ToString() != "")
                                {
                                    DateTime dt_EA_daterecFin = Convert.ToDateTime(sqlDr[5].ToString());
                                    msk_dtpFE_daterecFin1.Text = dt_EA_daterecFin.ToString("dd/MMM/yyyy");
                                }
                                else
                                {
                                    msk_dtpFE_daterecFin1.Text = "";
                                }
                                if (sqlDr["eval_com_receive2"].ToString() != "")
                                {
                                    DateTime dt_EA_daterecFin2 = Convert.ToDateTime(sqlDr["eval_com_receive2"].ToString());
                                    msk_dtpFE_daterecFin2.Text = dt_EA_daterecFin2.ToString("dd/MMM/yyyy");
                                }
                                else
                                {
                                    msk_dtpFE_daterecFin2.Text = "";
                                }
                                if (sqlDr[2].ToString() != "")
                                {
                                    DateTime dt_EA_datesent = Convert.ToDateTime(sqlDr[2].ToString());
                                    msk_dtpTE_datesent1.Text = dt_EA_datesent.ToString("dd/MMM/yyyy");
                                }
                                else
                                {
                                    msk_dtpTE_datesent1.Text = ""; 
                                }
                                if (sqlDr["eval_tech_sent2"].ToString() != "")
                                {
                                    DateTime dt_EA_datesent2 = Convert.ToDateTime(sqlDr["eval_tech_sent2"].ToString());
                                    msk_dtpTE_datesent2.Text = dt_EA_datesent2.ToString("dd/MMM/yyyy");
                                }
                                else
                                {
                                    msk_dtpTE_datesent2.Text = "";
                                }
                                if (sqlDr[4].ToString() != "")
                                {
                                    DateTime dt_EA_datesentfin = Convert.ToDateTime(sqlDr[4].ToString());
                                    msk_dtpFE_datesentfin1.Text = dt_EA_datesentfin.ToString("dd/MMM/yyyy");
                                }
                                else
                                {
                                    msk_dtpFE_datesentfin1.Text = "";
                                }
                                if (sqlDr["eval_com_sent2"].ToString() != "")
                                {
                                    DateTime dt_EA_datesentfin2 = Convert.ToDateTime(sqlDr["eval_com_sent2"].ToString());
                                    msk_dtpFE_datesentfin2.Text = dt_EA_datesentfin2.ToString("dd/MMM/yyyy");
                                }
                                else
                                {
                                    msk_dtpFE_datesentfin2.Text = "";
                                }
                                if (sqlDr[1].ToString() != "")
                                {
                                    DateTime dt_EA_recfromcd = Convert.ToDateTime(sqlDr[1].ToString());
                                    msk_dtpEA_recfromcd.Text = dt_EA_recfromcd.ToString("dd/MMM/yyyy");
                                }
                                else
                                {
                                    msk_dtpEA_recfromcd.Text = "";
                                }
                                if (sqlDr[0].ToString() != "")
                                {
                                    DateTime dt_EA_reqdate = Convert.ToDateTime(sqlDr[0].ToString());
                                    msk_dtpEA_reqdate.Text = dt_EA_reqdate.ToString("dd/MMM/yyyy");
                                }
                                else
                                {
                                    msk_dtpEA_reqdate.Text = "";
                                }
                                if (sqlDr[6].ToString() != "")
                                {
                                    DateTime dt_EA_apprDate = Convert.ToDateTime(sqlDr[6].ToString());
                                    msk_dtpEA_apprDate.Text = dt_EA_apprDate.ToString("dd/MMM/yyyy");
                                }
                                else
                                {
                                    msk_dtpEA_apprDate.Text = "";
                                }
                                if (isCpContractorSign == false)
                                {
                                    if (sqlDr[7].ToString() != "")
                                    {
                                        DateTime dt_TV_FEdate = Convert.ToDateTime(sqlDr[7].ToString());
                                        msk_dtpTV_FEdate.Text = dt_TV_FEdate.ToString("dd/MMM/yyyy");
                                    }
                                    else
                                    {
                                        msk_dtpTV_FEdate.Text = "";
                                    }
                                    if (sqlDr[8].ToString() != "")
                                    {
                                        DateTime dt_TV_SEdate = Convert.ToDateTime(sqlDr[8].ToString());
                                        msk_dtpTV_SEdate.Text = dt_TV_SEdate.ToString("dd/MMM/yyyy");
                                    }
                                    else
                                    {
                                        msk_dtpTV_SEdate.Text = "";
                                    }
                                    if (sqlDr[9].ToString() != "")
                                    {
                                        DateTime dt_TBV_FEdate = Convert.ToDateTime(sqlDr[9].ToString());
                                        msk_dtpTBV_FEdate.Text = dt_TBV_FEdate.ToString("dd/MMM/yyyy");
                                    }
                                    else
                                    {
                                        msk_dtpTBV_FEdate.Text = "";
                                    }
                                    if (sqlDr[10].ToString() != "")
                                    {
                                        DateTime dt_TBV_SEdate = Convert.ToDateTime(sqlDr[10].ToString());
                                        msk_dtpTBV_SEdate.Text = dt_TBV_SEdate.ToString("dd/MMM/yyyy");
                                    }
                                    else
                                    {
                                        msk_dtpTBV_SEdate.Text = "";
                                    }
                                }
                                else
                                {
                                    msk_dtpTV_FEdate.Text = "";
                                    msk_dtpTV_SEdate.Text = "";
                                    msk_dtpTBV_FEdate.Text = "";
                                    msk_dtpTBV_SEdate.Text = "";
                                    txtTV_exipre.Text = "";
                                    txtTBV_exipre.Text = "";
                                }
                                txtEA_Noofmeetings.Text = sqlDr[14].ToString();

                                txtTE_remarks.Text = sqlDr[15].ToString();

                                txtTechEval1ProposedWorkDays.Text = sqlDr[16].ToString();
                                txtFinEval1ProposedWorkDays.Text = sqlDr[17].ToString();
                                txtTechEval2ProposedWorkDays.Text = sqlDr["TPWD2"].ToString();
                                txtFinEval2ProposedWorkDays.Text = sqlDr["FPWD2"].ToString();

                                dateiDofTEA = Convert.ToInt16(sqlDr[11].ToString());
                            }
                        }
                    }
                }
                sqlCn.Close();
            }
            return statusTEAChk;
        }
        private void ProjectStages_Paint(object sender, PaintEventArgs e)
        {
            tabControl1.DrawMode = TabDrawMode.OwnerDrawFixed;

        }
        private void tabControl1_DrawItem(object sender, DrawItemEventArgs e)
        {
            Graphics g = e.Graphics;
            Brush _TextBrush;

            TabPage _TabPage = tabControl1.TabPages[e.Index];
            Rectangle _TabBounds = tabControl1.GetTabRect(e.Index);
            if (e.State == DrawItemState.Selected)
            {
                _TextBrush = new SolidBrush(Color.Maroon);
                g.FillRectangle(Brushes.White, e.Bounds);
            }
            else
            {
                _TextBrush = new System.Drawing.SolidBrush(e.ForeColor);
            }

            Font _TabFont = new Font(e.Font.FontFamily, (float)7, FontStyle.Bold);   //, GraphicsUnit.Pixel
            StringFormat _StringFlags = new StringFormat();
            _StringFlags.Alignment = StringAlignment.Center;
            _StringFlags.LineAlignment = StringAlignment.Center;

            g.DrawString(tabControl1.TabPages[e.Index].Text, _TabFont, _TextBrush, _TabBounds, new StringFormat(_StringFlags));

            //PopulatingVariousStagesTabControlsOfProject();

        }
        private void button13_Click(object sender, EventArgs e)
        {
            Boolean statusChk = false;
            if (dtpRecievedOn.Checked == false)
            {
                MessageBox.Show("Please select Received On Date");
                return;
            }
            if (cmbPurpose.SelectedIndex == -1)
            {
                MessageBox.Show("Please Select Document Purpose");
                return;
            }

            SqlConnection sqlConn = new SqlConnection(connStr);
            int dateID = 0;
            sqlConn.Open();
            try
            {
                string sqlQuery = "SELECT MAX(date_id) from TenderDatesInfo";
                SqlCommand sqlCommand = new SqlCommand(sqlQuery, sqlConn);
                dateID = Convert.ToInt16(sqlCommand.ExecuteScalar());
                dateID = dateID + 1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlConn.Close();
            }
            try
            {
                sqlConn.Open();
                string insertQuery = "INSERT INTO TenderDatesInfo(date_id,proj_id, stage_id, ptd_receive_on, ptd_purpose, ptd_assign_qs," +
                " ptd_sent_for_rev, ptd_qs_working_status, ptd_tendec_doc_cur_status,ptd_forwarded_to_dep, remarks) VALUES " +
                " (" + dateID + "," + Convert.ToInt16(lblProjID.Text) + "," + 1 + ",'" + dtpRecievedOn.Value + "','" + cmbPurpose.SelectedItem.ToString() + "'," +
                " '" + cmbAssignedQs.SelectedItem.ToString() + "','" + dtpReview.Value + "','" + cmbQsWorkingStatus.SelectedItem.ToString() + "'," +
                " '" + cmbTenderDocStatus.SelectedItem.ToString() + "','" + dtpFrwdDept.Value + "','" + txtRemarks.Text + "')";

                SqlCommand sqlCommand = new SqlCommand(insertQuery, sqlConn);
                sqlCommand.ExecuteNonQuery();
                MessageBox.Show("Tender Document Preparation Data Added Successfully!");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlConn.Close();
            }
            dtpRecievedOn.Checked = false;
            dtpReview.Checked = false;
            dtpFrwdDept.Checked = false;

            cmbAssignedQs.SelectedIndex = -1;
            cmbPurpose.SelectedIndex = -1;
            cmbQsWorkingStatus.SelectedIndex = -1;
            cmbTenderDocStatus.SelectedIndex = -1;
            txtRemarks.Text = "";

            if (cmbQsWorkingStatus.Text == "Completed" & cmbTenderDocStatus.Text == "Approved")
            {
                statusChk = true;
            }
            if (statusChk == true)
            {
                try
                {
                    using (sqlConn = new SqlConnection(connStr))
                    {
                        using (SqlCommand cmd = new SqlCommand())
                        {
                            sqlConn.Open();
                            cmd.Connection = sqlConn;

                            cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]= 2 Where proj_id=@projId";
                            cmd.Parameters.AddWithValue("@projId", Convert.ToInt16(lblProjID.Text));
                            //cmd.Parameters.AddWithValue("@tenderSatus", dtp_tsRecOn.Value.ToString("dd/MMM/yyyy"));

                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            GridViewRefresh_PTD();
        }
        private void UpdateTenderStageInfo(int _upddateID_Ts)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        cmd.CommandText = @"UPDATE TenderDatesInfo SET " +
                        " ts_receive_on =@receiveOn,ts_issue_handling = @issueHandling," +
                        " ts_return_to_dept=@returnDept,ts_receive_from_dept = @receivedFromDept,ts_pr_advertise =@advertisement,ts_tender_invitation = @invitation, " +
                        " ts_closing_s1 = @closingDateS1, ts_closing_s2 = @closingDateS2,ts_modified_closing= @tsModifyDateS1,ts_modified_closing_s2=@tsModifyDateS2,Remarks =@tsRemarks,Update_Date = @UpdateDate,Update_User = @UpdateUser Where date_id = @dateId " +
                        "and stage_id = 2 AND (ts_tender_issue IS NULL)";

                        cmd.Parameters.AddWithValue("@dateId", _upddateID_Ts);
                        //cmd.Parameters.AddWithValue("@projId", Convert.ToInt16(lblProjID.Text));

                        //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings                                                                       
                        if (msk_dtp_tsRecOn.Text != "")
                            cmd.Parameters.AddWithValue("@receiveOn", Convert.ToDateTime(msk_dtp_tsRecOn.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@receiveOn", DBNull.Value);

                        if (cmb_tstenderHandle.SelectedIndex != -1 || cmb_tstenderHandle.Text != "")
                            cmd.Parameters.AddWithValue("@issueHandling", cmb_tstenderHandle.Text);
                        else
                            cmd.Parameters.AddWithValue("@issueHandling", DBNull.Value);

                        //Modified by Varun on 13/02/2014
                        if (msk_dtp_tsReturnDept.Text != "")
                            cmd.Parameters.AddWithValue("@returnDept", Convert.ToDateTime(msk_dtp_tsReturnDept.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@returnDept", DBNull.Value);

                        //Modified by Varun on 13/02/2014
                        if (msk_dtp_tsRecFromDept.Text != "")
                            cmd.Parameters.AddWithValue("@receivedFromDept", Convert.ToDateTime(msk_dtp_tsRecFromDept.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@receivedFromDept", DBNull.Value);

                        //Modified by Varun on 13/02/2014
                        if (msk_dtp_tsAdvertisement.Text != "")
                            cmd.Parameters.AddWithValue("@advertisement", Convert.ToDateTime(msk_dtp_tsAdvertisement.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@advertisement", DBNull.Value);

                        //Modified by Varun on 13/02/2014
                        if (msk_dtp_tsInvitation.Text != "")
                            cmd.Parameters.AddWithValue("@invitation", Convert.ToDateTime(msk_dtp_tsInvitation.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@invitation", DBNull.Value);

                        //Modified by Varun on 13/02/2014
                        if (msk_dtp_tsStage1.Text != "")
                            cmd.Parameters.AddWithValue("@closingDateS1", Convert.ToDateTime(msk_dtp_tsStage1.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@closingDateS1", DBNull.Value);

                        //Modified by Varun on 13/02/2014
                        if (msk_dtp_tsStage2.Text != "")
                            cmd.Parameters.AddWithValue("@closingDateS2", Convert.ToDateTime(msk_dtp_tsStage2.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@closingDateS2", DBNull.Value);

                        //Modified by Varun on 02/03/2017
                        if (msk_dtp_tsModifiedDate_Stage1.Text != "")
                            cmd.Parameters.AddWithValue("@tsModifyDateS1", Convert.ToDateTime(msk_dtp_tsModifiedDate_Stage1.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@tsModifyDateS1", DBNull.Value);

                        //Modified by Varun on 02/03/2017
                        if (msk_dtp_tsModifiedDate_Stage2.Text != "")
                            cmd.Parameters.AddWithValue("@tsModifyDateS2", Convert.ToDateTime(msk_dtp_tsModifiedDate_Stage2.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@tsModifyDateS2", DBNull.Value);

                        cmd.Parameters.AddWithValue("@tsRemarks", txt_tsRemarks.Text);


                        cmd.Parameters.AddWithValue("@UpdateDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@UpdateUser", _userName);

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        cmd.CommandText = @"UPDATE PROJECTS set last_Modified_Date=@UpdateDate,Update_User = @UpdateUser where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@UpdateDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@UpdateUser", _userName);
                        cmd.Parameters.AddWithValue("@projId", _projID);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Data Updated Successfully");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the data, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            if (msk_dtp_tsModifiedDate_Stage1.Text != "")
            {
                if (Check_ModifiedDateExist() == false)
                {
                    try
                    {
                        using (SqlConnection sqlConn = new SqlConnection(connStr))
                        {
                            using (SqlCommand cmd = new SqlCommand())
                            {
                                sqlConn.Open();
                                cmd.Connection = sqlConn;

                                cmd.CommandText = "INSERT INTO TNDR_MODIFIEDDATES(proj_id, stage_id, Tndr_ModifiedDate,Create_User,Create_Date) VALUES(@prjID,@stageID,@modifiedOn,@CreateUser,@CreateDate)";

                                cmd.Parameters.AddWithValue("@stageID", 2);
                                cmd.Parameters.AddWithValue("@prjID", Convert.ToInt16(lblProjID.Text));

                                if (msk_dtp_tsRecOn.Text != "")
                                    cmd.Parameters.AddWithValue("@modifiedOn", msk_dtp_tsModifiedDate_Stage1.Text);
                                else
                                    cmd.Parameters.AddWithValue("@modifiedOn", DBNull.Value);

                                cmd.Parameters.AddWithValue("@CreateDate", System.DateTime.Now);
                                cmd.Parameters.AddWithValue("@CreateUser", _userName);

                                int exUpdated = cmd.ExecuteNonQuery();
                                cmd.Parameters.Clear();

                                //MessageBox.Show("Data Updated Successfully");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error occurred while inserting the data, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }


            //Update Tender Handling By in Projects Table
            if (cmb_tstenderHandle.Text != "")
                clsStaff.update_TenderHandled(cmb_tstenderHandle.Text, Convert.ToInt16(lblProjID.Text));


            //if (!Convert.ToDateTime(mdfExistDate).ToString("dd/MMM/yyyy").Equals(msk_dtp_tsModifiedDate.Text))
            //{
            //    MessageBox.Show("Alert message for modified date " + " existed Date was " + mdfExistDate + " New Modified Date is  " + msk_dtp_tsModifiedDate.Text + "");
            //}
        }

        private Boolean Check_ModifiedDateExist()
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    sqlConn.Open();
                    SqlCommand sqlCom = new SqlCommand("SELECT Tndr_ModifiedDate FROM Tndr_ModifiedDates Where Tndr_ModifiedDate = '" + Convert.ToDateTime(msk_dtp_tsModifiedDate_Stage1.Text).ToString("dd/MMM/yyyy") + "'", sqlConn);
                    using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                    {
                        if (sqlReader.HasRows)
                        {
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while retrieving the data, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            return false;
        }
        private Boolean ValidateDatesOfTndrStage()
        {
            Boolean dateFormat = true;
            dateFormat = ValidateDate(msk_dtp_tsRecOn);
            dateFormat = ValidateDate(msk_dtp_tsReturnDept);
            dateFormat = ValidateDate(msk_dtp_tsRecFromDept);
            dateFormat = ValidateDate(msk_dtp_tsAdvertisement);
            dateFormat = ValidateDate(msk_dtp_tsInvitation);
            dateFormat = ValidateDate(msk_dtp_tsStage1);
            dateFormat = ValidateDate(msk_dtp_tsStage2);
            dateFormat = ValidateDate(msk_dtp_tsModifiedDate_Stage1);
            return dateFormat;
        }
        private void InsertTenderStageInfo(int _dateID)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,ts_receive_on,ts_issue_handling,ts_return_to_dept, " +
                        " ts_receive_from_dept,ts_pr_advertise,ts_tender_invitation,ts_closing_s1,ts_closing_s2,ts_modified_closing,ts_modified_closing_s2,Create_Date,Create_User) VALUES " +
                        " (@dateId,@projId,@stageId,@receiveOn,@issueHandling,@returnDept,@receivedFromDept,@advertisement,@invitation,@closingDateS1,@closingDateS2,@tsModifyDateS1, " +
                        "@tsModifyDateS2,@CreateDate,@CreateUser)";
                        // ,ts_modified_closing,ts_tender_issue
                        cmd.Parameters.AddWithValue("@stageId", 2);
                        cmd.Parameters.AddWithValue("@projId", Convert.ToInt16(lblProjID.Text));
                        cmd.Parameters.AddWithValue("@receiveOn", Convert.ToDateTime(msk_dtp_tsRecOn.Text + " " + DateTime.Now.ToLongTimeString()));
                        if (cmb_tstenderHandle.SelectedIndex != -1 || cmb_tstenderHandle.Text != "")
                            cmd.Parameters.AddWithValue("@issueHandling", cmb_tstenderHandle.Text);
                        else
                            cmd.Parameters.AddWithValue("@issueHandling", DBNull.Value);

                        //DateTime dtNull;
                        //DateTime.TryParseExact(dtp_tsReturnDept.Value.ToString(), "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out dtNull);

                        if (dtp_tsReturnDept.Checked == true)
                            cmd.Parameters.AddWithValue("@returnDept", msk_dtp_tsReturnDept.Text);
                        else
                            cmd.Parameters.AddWithValue("@returnDept", DBNull.Value);

                        if (dtp_tsRecFromDept.Checked == true)
                            cmd.Parameters.AddWithValue("@receivedFromDept", msk_dtp_tsRecFromDept.Text);
                        else
                            cmd.Parameters.AddWithValue("@receivedFromDept", DBNull.Value);

                        if (dtp_tsAdvertisement.Checked == true)
                            cmd.Parameters.AddWithValue("@advertisement", Convert.ToDateTime(msk_dtp_tsAdvertisement.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@advertisement", DBNull.Value);

                        if (dtp_tsInvitation.Checked == true)
                            cmd.Parameters.AddWithValue("@invitation", Convert.ToDateTime(msk_dtp_tsInvitation.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@invitation", DBNull.Value);

                        if (dtp_tsStage1.Checked == true)
                            cmd.Parameters.AddWithValue("@closingDateS1", Convert.ToDateTime(msk_dtp_tsStage1.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@closingDateS1", DBNull.Value);

                        if (dtp_tsStage2.Checked == true)
                            cmd.Parameters.AddWithValue("@closingDateS2", Convert.ToDateTime(msk_dtp_tsStage2.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@closingDateS2", DBNull.Value);

                        if (dtp_tsModifiedDate_Stage1.Checked == true)
                            cmd.Parameters.AddWithValue("@tsModifyDateS1", Convert.ToDateTime(msk_dtp_tsModifiedDate_Stage1.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@tsModifyDateS1", DBNull.Value);

                        if (dtp_tsModifiedDate_Stage2.Checked == true)
                            cmd.Parameters.AddWithValue("@tsModifyDateS2", Convert.ToDateTime(msk_dtp_tsModifiedDate_Stage2.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@tsModifyDateS2", DBNull.Value);

                        //cmd.Parameters.AddWithValue("@advertisement", dtp_tsRecOn.Value.ToString("dd/MMM/yyyy"));     //ts_modified_closing
                        //cmd.Parameters.AddWithValue("@invitation", dtp_tsRecOn.Value.ToString("dd/MMM/yyyy"));        //remarks
                        //cmd.Parameters.AddWithValue("@closingDate", dtp_tsRecOn.Value.ToString("dd/MMM/yyyy"));
                        //cmd.Parameters.AddWithValue("@closingDate2", dtp_tsRecOn.Value.ToString("dd/MMM/yyyy")); 

                        cmd.Parameters.AddWithValue("@CreateDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@CreateUser", _userName);

                        cmd.Parameters.AddWithValue("@dateId", _dateID);
                        cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        cmd.CommandText = @"UPDATE PROJECTS set last_Modified_Date=@UpdateDate,Update_User = @UpdateUser where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@UpdateDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@UpdateUser", _userName);
                        cmd.Parameters.AddWithValue("@projId", _projID);
                        cmd.ExecuteNonQuery();

                        MessageBox.Show("Entered Data Saved SuccessFully");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while performing operation in database.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }


            // Update Tender Handling By in Projects Table
            if (cmb_tstenderHandle.Text != "")
                clsStaff.update_TenderHandled(cmb_tstenderHandle.Text, Convert.ToInt16(lblProjID.Text));

        }
        private Boolean CheckDataExistForTenderStage(ref int _updDateID, ref string receivedDate)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    sqlConn.Open();
                    sqlCom = new SqlCommand("SELECT date_id,ts_receive_on FROM TenderDatesInfo Where Proj_id = " + _projID + " and Stage_id = 2 And ts_tender_issue IS NULL", sqlConn);
                    using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                    {
                        if (sqlReader.HasRows)
                        {
                            sqlReader.Read();
                            _updDateID = Convert.ToInt16(sqlReader[0]);
                            receivedDate = sqlReader[1].ToString();
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while retrieving the data, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            return false;
        }
        private Boolean CheckDataExistForTenderEvaluation()
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    sqlConn.Open();
                    sqlCom = new SqlCommand("SELECT * FROM TenderDatesInfo Where Proj_id = " + _projID + " and Stage_id = 3", sqlConn);
                    using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                    {
                        if (sqlReader.HasRows)
                        {
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while retrieving the data, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            return false;
        }
        private Boolean CheckDataExistForContractProcess()
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    sqlConn.Open();
                    sqlCom = new SqlCommand("SELECT * FROM TenderDatesInfo Where Proj_id = " + _projID + " and Stage_id = 4 and cp_tender_award != ''", sqlConn);
                    using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                    {
                        if (sqlReader.HasRows)
                        {
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while retrieving the data, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            return false;
        }

        int dateID_Ts = 0;



        private void UpdateStatusForClosingDate()
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]= 2,[stage_id]= 2 Where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@projId", Convert.ToInt16(lblProjID.Text));
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating project info, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void UpdateStatusFor_ReceivedDate()
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]= 2,[stage_id]= 2 Where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@projId", Convert.ToInt16(lblProjID.Text));
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void InsertTenderEvaluationData(int dateID)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        int stage_Id = 0;
                        stage_Id = 3;

                        //cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,eval_tender_opening,eval_tender_doc_receive_from_cd, " +
                        //" eval_tech_sent1,eval_tech_receive1,eval_com_sent1,eval_com_receive1,eval_tender_award_approval,eval_no_of_meetings,remarks,Create_Date,Create_User,TPWD1,FPWD1,eval_tech_sent2,eval_tech_receive2,eval_com_sent2,eval_com_receive2,TPWD2,FPWD2," +
                        //"eval_tech_tdr_rev_sent1,eval_tech_tdr_rev_receive1,eval_tech_tdr_rev_sent2,eval_tech_tdr_rev_receive2,TTRPWD1,TTRPWD2,eval_fin_tdr_rev_sent1,eval_fin_tdr_rev_receive1,eval_fin_tdr_rev_sent2,eval_fin_tdr_rev_receive2,TTRPWD1,TTRPWD2,eval_fin_tdr_rev_sent2," +
                        //"eval_fin_tdr_rev_receive2,FTRPWD1,FTRPWD2) VALUES(@dateId,@projId,@stageId,@evltendrReq,@fromCd,@senttoTech1,@recfromtech1,@sentFin1,@recFin1,@awardAppr,@NoOfMeetings,@TE_Remarks,@CreateDate,@CreateUser,@TPWD1,@FPWD1,@senttoTech2,@recfromtech2,@sentFin2,@recFin2,@TPWD2,@FPWD2," +
                        //"@evalTTRSent1,@evalTTRReceive1,@evalTTRsent2,evalTTRReceive2,@TTRPWD1,@TTRPWD2,@evalFTRSent1,@evalFTRReceive1,@evalFTRSent2,@evalFTRReceive2,@FTRPWD1,@FTRPWD2)";

                        cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,eval_tender_opening,eval_tender_doc_receive_from_cd, " +
                       " eval_tech_sent1,eval_tech_receive1,eval_com_sent1,eval_com_receive1,eval_tender_award_approval,eval_no_of_meetings,remarks,Create_Date,Create_User,TPWD1,FPWD1,eval_tech_sent2,eval_tech_receive2,eval_com_sent2,eval_com_receive2,TPWD2,FPWD2" +
                       ") VALUES(@dateId,@projId,@stageId,@evltendrReq,@fromCd,@senttoTech1,@recfromtech1,@sentFin1,@recFin1,@awardAppr,@NoOfMeetings,@TE_Remarks,@CreateDate,@CreateUser,@TPWD1,@FPWD1,@senttoTech2,@recfromtech2,@sentFin2,@recFin2,@TPWD2,@FPWD2)";

                        //tender_validity_ext1  tender_validity_ext2  // tenderbond_validity_ext1   tenderbond_validity_ext2  //org_tender_validity  //org_tenderbond_validity  //org_tenderbond_to_expire
                        cmd.Parameters.AddWithValue("@projId", Convert.ToInt16(lblProjID.Text));
                        cmd.Parameters.AddWithValue("@stageId", stage_Id);

                        if (msk_dtp_tsRecFromDept.Text != "")
                            cmd.Parameters.AddWithValue("@receivedFromDept", Convert.ToDateTime(msk_dtp_tsRecFromDept.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@receivedFromDept", DBNull.Value);

                        if (msk_dtpEA_reqdate.Text != "")
                            cmd.Parameters.AddWithValue("@evltendrReq", Convert.ToDateTime(msk_dtpEA_reqdate.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@evltendrReq", DBNull.Value);

                        if (msk_dtpEA_recfromcd.Text != "")
                            cmd.Parameters.AddWithValue("@fromCd", Convert.ToDateTime(msk_dtpEA_recfromcd.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@fromCd", DBNull.Value);

                        if (msk_dtpTE_datesent1.Text != "")
                            cmd.Parameters.AddWithValue("@senttoTech1", Convert.ToDateTime(msk_dtpTE_datesent1.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@senttoTech1", DBNull.Value);

                        if (msk_dtpTE_daterec1.Text != "")
                            cmd.Parameters.AddWithValue("@recfromtech1", Convert.ToDateTime(msk_dtpTE_daterec1.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@recfromtech1", DBNull.Value);

                        if (msk_dtpFE_datesentfin1.Text != "")
                            cmd.Parameters.AddWithValue("@sentFin1", Convert.ToDateTime(msk_dtpFE_datesentfin1.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@sentFin1", DBNull.Value);

                        if (msk_dtpFE_daterecFin1.Text != "")
                            cmd.Parameters.AddWithValue("@recFin1", Convert.ToDateTime(msk_dtpFE_daterecFin1.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@recFin1", DBNull.Value);

                        if (msk_dtpTE_datesent1.Text != "")
                            cmd.Parameters.AddWithValue("@senttoTech2", Convert.ToDateTime(msk_dtpTE_datesent2.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@senttoTech2", DBNull.Value);

                        if (msk_dtpTE_daterec2.Text != "")
                            cmd.Parameters.AddWithValue("@recfromtech2", Convert.ToDateTime(msk_dtpTE_daterec2.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@recfromtech2", DBNull.Value);

                        if (msk_dtpFE_datesentfin1.Text != "")
                            cmd.Parameters.AddWithValue("@sentFin2", Convert.ToDateTime(msk_dtpFE_datesentfin2.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@sentFin2", DBNull.Value);

                        if (msk_dtpFE_daterecFin1.Text != "")
                            cmd.Parameters.AddWithValue("@recFin2", Convert.ToDateTime(msk_dtpFE_daterecFin2.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@recFin2", DBNull.Value);

                        //if (msk_dtpTTR_datesent1.Text != "")
                        //    cmd.Parameters.AddWithValue("@evalTTRSent1", Convert.ToDateTime(msk_dtpTTR_datesent1.Text + " " + DateTime.Now.ToLongTimeString()));
                        //else
                            //cmd.Parameters.AddWithValue("@evalTTRSent1", DBNull.Value);

                        //if (msk_dtpTTR_daterec1.Text != "")
                        //    cmd.Parameters.AddWithValue("@evalTTRReceive1", Convert.ToDateTime(msk_dtpTTR_daterec1.Text + " " + DateTime.Now.ToLongTimeString()));
                        //else
                            //cmd.Parameters.AddWithValue("@evalTTRReceive1", DBNull.Value);

                        //if (msk_dtpTTR_datesent2.Text != "")
                        //    cmd.Parameters.AddWithValue("@evalTTRsent2", Convert.ToDateTime(msk_dtpTTR_datesent2.Text + " " + DateTime.Now.ToLongTimeString()));
                        //else
                            //cmd.Parameters.AddWithValue("@evalTTRsent2", DBNull.Value);

                        //if (msk_dtpTTR_daterec2.Text != "")
                        //    cmd.Parameters.AddWithValue("@evalTTRReceive2", Convert.ToDateTime(msk_dtpTTR_daterec2.Text + " " + DateTime.Now.ToLongTimeString()));
                        //else
                            //cmd.Parameters.AddWithValue("@evalTTRReceive2", DBNull.Value);

                        //if (txtTTR1ProposedWorkDays.Text != "")
                        //    cmd.Parameters.AddWithValue("@TTRPWD1", txtTTR1ProposedWorkDays.Text);
                        //else
                           //cmd.Parameters.AddWithValue("@TTRPWD1", DBNull.Value);

                        //if (txtTTR2ProposedWorkDays.Text != "")
                        //    cmd.Parameters.AddWithValue("@TTRPWD2", txtTTR2ProposedWorkDays.Text);
                        //else
                            //cmd.Parameters.AddWithValue("@TTRPWD2", DBNull.Value);

                        //if (msk_dtpFTR_datesent1.Text != "")
                        //    cmd.Parameters.AddWithValue("@evalFTRSent1", Convert.ToDateTime(msk_dtpFTR_datesent1.Text + " " + DateTime.Now.ToLongTimeString()));
                        //else
                            //cmd.Parameters.AddWithValue("@evalFTRSent1", DBNull.Value);

                        //if (msk_dtpFTR_daterec1.Text != "")
                        //    cmd.Parameters.AddWithValue("@evalFTRReceive1", Convert.ToDateTime(msk_dtpFTR_daterec1.Text + " " + DateTime.Now.ToLongTimeString()));
                        //else
                            //cmd.Parameters.AddWithValue("@evalFTRReceive1", DBNull.Value);

                        //if (msk_dtpFTR_datesent2.Text != "")
                        //    cmd.Parameters.AddWithValue("@evalFTRSent2", Convert.ToDateTime(msk_dtpFTR_datesent2.Text + " " + DateTime.Now.ToLongTimeString()));
                        //else
                            //cmd.Parameters.AddWithValue("@evalFTRSent2", DBNull.Value);

                        //if (msk_dtpFTR_daterec2.Text != "")
                        //    cmd.Parameters.AddWithValue("@evalFTRReceive2", Convert.ToDateTime(msk_dtpFTR_daterec2.Text + " " + DateTime.Now.ToLongTimeString()));
                        //else
                            //cmd.Parameters.AddWithValue("@evalFTRReceive2", DBNull.Value);

                        //if (txtFTR1ProposedWorkDays.Text != "")
                        //    cmd.Parameters.AddWithValue("@FTRPWD1", txtFTR1ProposedWorkDays.Text);
                        //else
                            //cmd.Parameters.AddWithValue("@FTRPWD1", DBNull.Value);

                        //if (txtFTR2ProposedWorkDays.Text != "")
                        //    cmd.Parameters.AddWithValue("@FTRPWD2", txtFTR2ProposedWorkDays.Text);
                        //else
                            //cmd.Parameters.AddWithValue("@FTRPWD2", DBNull.Value);

                        if (msk_dtpEA_apprDate.Text != "")
                            cmd.Parameters.AddWithValue("@awardAppr", Convert.ToDateTime(msk_dtpEA_apprDate.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@awardAppr", DBNull.Value);

                        if (txtEA_Noofmeetings.Text == "")
                            cmd.Parameters.AddWithValue("@NoOfMeetings", 0);
                        else
                            cmd.Parameters.AddWithValue("@NoOfMeetings", Convert.ToInt16(txtEA_Noofmeetings.Text));

                        cmd.Parameters.AddWithValue("@TE_Remarks", txtTE_remarks.Text);

                        cmd.Parameters.AddWithValue("@dateId", dateID);  //NoOfMeetings

                        cmd.Parameters.AddWithValue("@CreateDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@CreateUser", _userName);

                        if (txtTechEval1ProposedWorkDays.Text != "")
                            cmd.Parameters.AddWithValue("@TPWD1", txtTechEval1ProposedWorkDays.Text);
                        else
                            cmd.Parameters.AddWithValue("@TPWD1", DBNull.Value);

                        if (txtFinEval1ProposedWorkDays.Text != "")
                            cmd.Parameters.AddWithValue("@FPWD1", txtFinEval1ProposedWorkDays.Text);
                        else
                            cmd.Parameters.AddWithValue("@FPWD1", DBNull.Value);

                        if (txtTechEval1ProposedWorkDays.Text != "")
                            cmd.Parameters.AddWithValue("@TPWD2", txtTechEval2ProposedWorkDays.Text);
                        else
                            cmd.Parameters.AddWithValue("@TPWD2", DBNull.Value);

                        if (txtFinEval1ProposedWorkDays.Text != "")
                            cmd.Parameters.AddWithValue("@FPWD2", txtFinEval2ProposedWorkDays.Text);
                        else
                            cmd.Parameters.AddWithValue("@FPWD2", DBNull.Value);

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        cmd.CommandText = @"UPDATE PROJECTS set last_Modified_Date=@UpdateDate,Update_User = @UpdateUser where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@UpdateDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@UpdateUser", _userName);
                        cmd.Parameters.AddWithValue("@projId", _projID);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Tender Evaluation & Award data added Succesfully");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Inserting or Updating data, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void UpdateTenderEvaluationData()
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        cmd.CommandText = @"UPDATE TenderDatesInfo set Proj_Id=@projId,eval_tender_opening=@evltendrReq,eval_tender_doc_receive_from_cd=@fromCd,eval_tech_sent1=@senttoTech1,eval_tech_receive1=@recfromtech1," +
                        "eval_com_sent1=@sentFin1,eval_com_receive1=@recFin1,eval_tender_award_approval=@awardAppr,eval_no_of_meetings =@meetingCnt,remarks = @TE_Remarks,Update_Date = @UpdateDate,Update_User = @UpdateUser, " +
                        "TPWD1=@TPWD1,FPWD1=@FPWD1,TPWD2=@TPWD2,FPWD2=@FPWD2,eval_tech_sent2=@senttoTech2,eval_tech_receive2=@recfromtech2,eval_com_sent2=@sentFin2,eval_com_receive2=@recFin2,eval_tech_tdr_rev_sent1=@evalTTRSent1, " +
                        "eval_tech_tdr_rev_receive1=@evalTTRReceive1,eval_tech_tdr_rev_sent2=@evalTTRSent2,eval_tech_tdr_rev_receive2=@evalTTRReceive2,TTRPWD1=@TTRPWD1,TTRPWD2=@TTRPWD2,eval_fin_tdr_rev_sent1=@evalFTRSent1,eval_fin_tdr_rev_receive1=@evalFTRReceive1, " +
                        "eval_fin_tdr_rev_sent2=@evalFTRSent2,eval_fin_tdr_rev_receive2=@evalFTRReceive2,FTRPWD1=@FTRPWD1 where date_id=@dateId";

                        //tender_validity_ext1 =@ValidityExt1,tender_validity_ext2 =@ValidityExt2,tenderbond_validity_ext1 =@BondValidityExt1,tenderbond_validity_ext2 =@BondValidityExt2,

                        cmd.Parameters.AddWithValue("@projId", Convert.ToInt16(lblProjID.Text));
                        if (msk_dtp_tsRecFromDept.Text != "")
                            cmd.Parameters.AddWithValue("@receivedFromDept", Convert.ToDateTime(msk_dtp_tsRecFromDept.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@receivedFromDept", DBNull.Value);

                        if (msk_dtpEA_reqdate.Text != "")
                            cmd.Parameters.AddWithValue("@evltendrReq", Convert.ToDateTime(msk_dtpEA_reqdate.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@evltendrReq", DBNull.Value);

                        if (msk_dtpEA_recfromcd.Text != "")
                            cmd.Parameters.AddWithValue("@fromCd", Convert.ToDateTime(msk_dtpEA_recfromcd.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@fromCd", DBNull.Value);

                        if (msk_dtpTE_datesent1.Text != "")
                            cmd.Parameters.AddWithValue("@senttoTech1", Convert.ToDateTime(msk_dtpTE_datesent1.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@senttoTech1", DBNull.Value);

                        if (msk_dtpTE_daterec1.Text != "")
                            cmd.Parameters.AddWithValue("@recfromtech1", Convert.ToDateTime(msk_dtpTE_daterec1.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@recfromtech1", DBNull.Value);

                        if (msk_dtpFE_datesentfin1.Text != "")
                            cmd.Parameters.AddWithValue("@sentFin1", Convert.ToDateTime(msk_dtpFE_datesentfin1.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@sentFin1", DBNull.Value);

                        if (msk_dtpFE_daterecFin1.Text != "")
                            cmd.Parameters.AddWithValue("@recFin1", Convert.ToDateTime(msk_dtpFE_daterecFin1.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@recFin1", DBNull.Value);

                        if (msk_dtpTE_datesent2.Text != "")
                            cmd.Parameters.AddWithValue("@senttoTech2", Convert.ToDateTime(msk_dtpTE_datesent2.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@senttoTech2", DBNull.Value);

                        if (msk_dtpTE_daterec2.Text != "")
                            cmd.Parameters.AddWithValue("@recfromtech2", Convert.ToDateTime(msk_dtpTE_daterec2.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@recfromtech2", DBNull.Value);

                        if (msk_dtpFE_datesentfin2.Text != "")
                            cmd.Parameters.AddWithValue("@sentFin2", Convert.ToDateTime(msk_dtpFE_datesentfin2.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@sentFin2", DBNull.Value);

                        if (msk_dtpFE_daterecFin2.Text != "")
                            cmd.Parameters.AddWithValue("@recFin2", Convert.ToDateTime(msk_dtpFE_daterecFin2.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@recFin2", DBNull.Value);

                        //if (msk_dtpTTR_datesent1.Text != "")
                        //    cmd.Parameters.AddWithValue("@evalTTRSent1", Convert.ToDateTime(msk_dtpTTR_datesent1.Text + " " + DateTime.Now.ToLongTimeString()));
                        //else
                            cmd.Parameters.AddWithValue("@evalTTRSent1", DBNull.Value);

                        //if (msk_dtpTTR_daterec1.Text != "")
                        //    cmd.Parameters.AddWithValue("@evalTTRReceive1", Convert.ToDateTime(msk_dtpTTR_daterec1.Text + " " + DateTime.Now.ToLongTimeString()));
                        //else
                            cmd.Parameters.AddWithValue("@evalTTRReceive1", DBNull.Value);

                        //if (msk_dtpTTR_datesent2.Text != "")
                        //    cmd.Parameters.AddWithValue("@evalTTRSent2", Convert.ToDateTime(msk_dtpTTR_datesent2.Text + " " + DateTime.Now.ToLongTimeString()));
                        //else
                            cmd.Parameters.AddWithValue("@evalTTRSent2", DBNull.Value);

                        //if (msk_dtpTTR_daterec2.Text != "")
                        //    cmd.Parameters.AddWithValue("@evalTTRReceive2", Convert.ToDateTime(msk_dtpTTR_daterec2.Text + " " + DateTime.Now.ToLongTimeString()));
                        //else
                            cmd.Parameters.AddWithValue("@evalTTRReceive2", DBNull.Value);

                        //if (txtTTR1ProposedWorkDays.Text != "")
                        //    cmd.Parameters.AddWithValue("@TTRPWD1", txtTTR1ProposedWorkDays.Text);
                        //else
                            cmd.Parameters.AddWithValue("@TTRPWD1", DBNull.Value);

                        //if (txtTTR2ProposedWorkDays.Text != "")
                        //    cmd.Parameters.AddWithValue("@TTRPWD2", txtTTR2ProposedWorkDays.Text);
                        //else
                            cmd.Parameters.AddWithValue("@TTRPWD2", DBNull.Value);

                        //if (msk_dtpFTR_datesent1.Text != "")
                        //    cmd.Parameters.AddWithValue("@evalFTRSent1", Convert.ToDateTime(msk_dtpFTR_datesent1.Text + " " + DateTime.Now.ToLongTimeString()));
                        //else
                            cmd.Parameters.AddWithValue("@evalFTRSent1", DBNull.Value);

                        //if (msk_dtpFTR_daterec1.Text != "")
                        //    cmd.Parameters.AddWithValue("@evalFTRReceive1", Convert.ToDateTime(msk_dtpFTR_daterec1.Text + " " + DateTime.Now.ToLongTimeString()));
                        //else
                            cmd.Parameters.AddWithValue("@evalFTRReceive1", DBNull.Value);

                        //if (msk_dtpFTR_datesent2.Text != "")
                        //    cmd.Parameters.AddWithValue("@evalFTRSent2", Convert.ToDateTime(msk_dtpFTR_datesent2.Text + " " + DateTime.Now.ToLongTimeString()));
                        //else
                            cmd.Parameters.AddWithValue("@evalFTRSent2", DBNull.Value);

                        //if (msk_dtpFTR_daterec2.Text != "")
                        //    cmd.Parameters.AddWithValue("@evalFTRReceive2", Convert.ToDateTime(msk_dtpFTR_daterec2.Text + " " + DateTime.Now.ToLongTimeString()));
                        //else
                            cmd.Parameters.AddWithValue("@evalFTRReceive2", DBNull.Value);

                        //if (txtFTR1ProposedWorkDays.Text != "")
                        //    cmd.Parameters.AddWithValue("@FTRPWD1", txtFTR1ProposedWorkDays.Text);
                        //else
                            cmd.Parameters.AddWithValue("@FTRPWD1", DBNull.Value);

                        //if (txtFTR2ProposedWorkDays.Text != "")
                        //    cmd.Parameters.AddWithValue("@FTRPWD2", txtFTR2ProposedWorkDays.Text);
                        //else
                            cmd.Parameters.AddWithValue("@FTRPWD2", DBNull.Value);

                        if (msk_dtpEA_apprDate.Text != "")
                            cmd.Parameters.AddWithValue("@awardAppr", Convert.ToDateTime(msk_dtpEA_apprDate.Text + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@awardAppr", DBNull.Value);

                        if (txtEA_Noofmeetings.Text == "")
                            cmd.Parameters.AddWithValue("@meetingCnt", 0);
                        else
                            cmd.Parameters.AddWithValue("@meetingCnt", Convert.ToInt16(txtEA_Noofmeetings.Text));

                        cmd.Parameters.AddWithValue("@TE_Remarks", txtTE_remarks.Text);

                        cmd.Parameters.AddWithValue("@dateId", dateID_TEA);

                        cmd.Parameters.AddWithValue("@UpdateDate ", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@UpdateUser", _userName);

                        if (txtTechEval1ProposedWorkDays.Text != "")
                            cmd.Parameters.AddWithValue("@TPWD1", txtTechEval1ProposedWorkDays.Text);
                        else
                            cmd.Parameters.AddWithValue("@TPWD1", DBNull.Value);

                        if (txtFinEval1ProposedWorkDays.Text != "")
                            cmd.Parameters.AddWithValue("@FPWD1", txtFinEval1ProposedWorkDays.Text);
                        else
                            cmd.Parameters.AddWithValue("@FPWD1", DBNull.Value);

                        if (txtTechEval2ProposedWorkDays.Text != "")
                            cmd.Parameters.AddWithValue("@TPWD2", txtTechEval2ProposedWorkDays.Text);
                        else
                            cmd.Parameters.AddWithValue("@TPWD2", DBNull.Value);

                        if (txtFinEval2ProposedWorkDays.Text != "")
                            cmd.Parameters.AddWithValue("@FPWD2", txtFinEval2ProposedWorkDays.Text);
                        else
                            cmd.Parameters.AddWithValue("@FPWD2", DBNull.Value);

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        cmd.CommandText = @"UPDATE PROJECTS set last_Modified_Date=@UpdateDate,Update_User = @UpdateUser where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@UpdateDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@UpdateUser", _userName);
                        cmd.Parameters.AddWithValue("@projId", _projID);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Tender Evaluation & Award data updated Succesfully");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating dates, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void dateTimePicker39_ValueChanged(object sender, EventArgs e)
        {
            // dtpTBV_OrgDate.Text = dtpEA_stage2.Value.AddDays(90).ToString();
        }

        string _tndrTypeName = string.Empty;
        string _userDept = string.Empty;
        string _AffairsName = string.Empty;


        protected void assignTenderNo()
        {
            if (mUserRightsColl.Contains("41"))    //      * Assign Tender No.
            {
                MessageBox.Show("You have no privilege to assign Tender No. Please Contact system administrator.");
                return;
            }

            if (dgvPTD.Rows.Count == 0) //[0].Cells[0].Value == null
            {
                MessageBox.Show("Document Received Date cannot be blank. Cannot Assign Tender Number");
                return;
            }
            else if (dgvPTD.Rows.Count != 0)
            {
                var bindingSource = (BindingSource)dgvPTD.DataSource;
                DataTable dtPTD = (DataTable)bindingSource.DataSource;
                if (!(dtPTD.Rows[dtPTD.Rows.Count - 1]["TenderDocumentCurrentStatus"].ToString().ToLower().Equals("approved")) || dtPTD.Rows[dtPTD.Rows.Count - 1]["TenderDocumentCurrentStatus"].ToString().Trim().Equals(""))
                {
                    MessageBox.Show("You cannot assign Tender No. because Tender Document CurrentStatus in Prepare Document is not Approved");
                    return;
                }
            }
            try
            {
                // Test Email for checking the SMTP Server is up and running Added By Varun on 31st Jan 2016
                MailMessage mailMessage = new MailMessage();

                mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["From"].ToString());
                mailMessage.To.Add(new MailAddress(ConfigurationManager.AppSettings["To"].ToString()));
                mailMessage.Subject = "Test TCMS Alert: Tender No. was going to be assigned";
                mailMessage.IsBodyHtml = true;

                mailMessage.Body = "<html><body><i style='font-family:Calibri; font-size:15'>Dear Sir/Madam,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Tender & Contract Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>" +
                "Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'> New Tender No. </i><i style='font-family:Calibri; font-size:15'> has created and the details are as follows:-</i><br /><br />" +
                "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:Maroon;color:White;font-family:Calibri;font-size:18;font-weight:bold'>TENDER NO: </td>" +
                "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Code</i></td><td style='font-family:Calibri;font-size:15'>" + _prjCode + "</td></tr>" +
                "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Title</i></td><td style='font-family:Calibri;font-size:15'>" + proj_Title + "</td></tr>" +
                "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Type of Tender</i></td><td style='font-family:Calibri;font-size:15'>" + _tndrTypeName + "</td></tr>" +
                "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Tender Committee</i></td><td style='font-family:Calibri;font-size:15'>" + _cmtName + "</td></tr>" +
                "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Financial Year</i></td><td style='font-family:Calibri;font-size:15'>" + _fiscalYear + "</td></tr>" +       //+ "(" + _AffairsName + ")
                "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>User Dept.</i></td><td style='font-family:Calibri;font-size:15'>" + _userDept + " / " + _AffairsName + " </td></tr>" +
                "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                "</table><br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>TCMS Team</div></body></html>";

                //mailMessage.Body = "This is an automated alert from TCMS." + "\n" + "\n" + "Project Code     : " + _prjCode + "\n" + "Project Title    : " + proj_Title + "\n" +   "Type of Tender   : " + _tndrTypeName + " " +
                // "\n"  + "Tender Committee : " + _cmtName + " " +
                // "\n" +  "User Department  : " + _userDept + " " +
                // "\n" +  "Date Created     : " + System.DateTime.Now.ToString() + " " +
                //" \n" +  "\n" + "Tender No. " + strTenderNo + " was assigned to above project.";

                SmtpClient client = new SmtpClient();
                client.EnableSsl = true;
                //client.UseDefaultCredentials = true;
                client.Credentials = new System.Net.NetworkCredential(@"Ashghal\tcms", ConfigurationManager.AppSettings["emailPass"].ToString());
                ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                client.Send(mailMessage);
                //SendEmail myAction = new SendEmail(SendCompletedCallback);
                //myAction.BeginInvoke(client, mailMessage, null, null);

            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to assign Tender Number, Error occurred while sending the email notification to Tender Committee, Please inform them Personally", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                isException = true;
            }

            if (isException == false)
            {
                UserList_ForAlert(1);
                if (isException == false)
                {
                    if (emailIds.Length == 0)
                    {
                        MessageBox.Show("Information for Tender No.assignment is required to be sent to a user who handles " + _cmtName + " projects, " +
                          " but there is no identified user to receive the email. Please contact system administrator for information.");
                        return;
                    }

                    DialogResult dlgResult = DialogResult.No;
                    dlgResult = MessageBox.Show("Do you want to create new Tender Number. ", "Assign Tender No.", MessageBoxButtons.YesNo);

                    if (dlgResult.ToString() == "Yes")
                    {

                        string _prjCreaedOn = string.Empty;

                        CommonClass comCls = new CommonClass(_userName);

                        string strTenderNo = comCls.AssignTenderNo(mUserRightsColl, _projID, _tndrType, txtProjCode.Text, txtproj.Text, 'A', null, null, ref _tndrTypeName, ref _userDept, ref _prjCreaedOn, ref _AffairsName);
                        // Added by Varun on 10 Feb 2014 for checking the exception occurence and to stop sending email alerts if there is a problem in assigning the Tender No.
                        if (!strTenderNo.Contains("Exception"))
                        {
                            if (strTenderNo != "")
                            {
                                btnAssignTender.Visible = false;
                                lblTenderNo.Visible = true;
                                txtTenderNo.Text = strTenderNo;
                                //txtTenderNo.Enabled = false;
                            }


                            //string DisplayName = ""; string Email = ""; string Department = ""; string Title = "";                         
                            // AlertOnNewTenderNo(tenderNo, _projID.ToString(), "New Project");

                            string fromUser = null;
                            fromUser = comCls.getUserEmailID(_userName);

                            try
                            {
                                //if (GetUserInformation4rmActiveDirectory(fromUser, "ashghal.gov.qa", ref user_DisplayName, ref user_Email, ref  user_Department, ref user_Title) == true)
                                //{
                                //foreach (string strname in userListColl)
                                //{
                                // if (GetUserInformation4rmActiveDirectory(strname, "ashghal.gov.qa", ref DisplayName, ref Email, ref  Department, ref Title) == true)

                                MailMessage mailMessage = new MailMessage();
                                //mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["MailFrom"].ToString());

                                mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["From"].ToString());
                                mailMessage.To.Add(emailIds.ToString() + fromUser); //.Substring(0, emailIds.ToString().Length - 1)
                                if (!_tndrType.Equals("PQ"))
                                {
                                    mailMessage.Subject = "TCMS Alert: Tender No. " + strTenderNo + " was assigned";
                                }
                                else
                                {
                                    mailMessage.Subject = "TCMS Alert: Pre-Qualification No. " + strTenderNo + " was assigned";
                                }
                                mailMessage.IsBodyHtml = true;

                                string emailBodyText = null;

                                emailBodyText = "<html><body><i style='font-family:Calibri; font-size:15'>Dear Sir/Madam,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Tender & Contract Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>";
                                if (!_tndrType.Equals("PQ") && !_tndrType.Equals("A"))
                                {
                                    emailBodyText = emailBodyText + "Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'> New Tender No. " + strTenderNo + "</i><i style='font-family:Calibri; font-size:15'> has created and the details are as follows:-</i><br /><br />";
                                }
                                else if (_tndrType.Equals("PQ"))
                                {
                                    emailBodyText = emailBodyText + "Please be noted that</i><i style='color:Blue;font-family:Calibri; font-size:15'> New Pre-Qualification No. " + strTenderNo + "</i><i style='font-family:Calibri; font-size:15'> has created and the details are as follows:-</i><br /><br />";
                                }
                                else
                                {
                                    emailBodyText = emailBodyText + "Please be noted that</i><i style='color:#1F4E79;font-family:Calibri; font-size:15'> New Tender No. " + strTenderNo + "</i><i style='font-family:Calibri; font-size:15'> has created and the details are as follows:-</i><br /><br />";
                                }

                                if (!_tndrType.Equals("PQ") && !_tndrType.Equals("A"))
                                {
                                    emailBodyText = emailBodyText + "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:Maroon;color:White;font-family:Calibri;font-size:18;font-weight:bold'>TENDER No. : " + strTenderNo + "</td>" +
                                    "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Code</i></td><td style='font-family:Calibri;font-size:15'>" + _prjCode + "</td></tr>" +
                                    "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Title</i></td><td style='font-family:Calibri;font-size:15'>" + proj_Title + "</td></tr>" +
                                    "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Type of Tender</i></td><td style='font-family:Calibri;font-size:15'>" + _tndrTypeName + "</td></tr>" +
                                    "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Tender Committee</i></td><td style='font-family:Calibri;font-size:15'>" + _cmtName + "</td></tr>" +
                                    "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Financial Year</i></td><td style='font-family:Calibri;font-size:15'>" + _fiscalYear + "</td></tr>" +       //+ "(" + _AffairsName + ")
                                    "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>User Dept.</i></td><td style='font-family:Calibri;font-size:15'>" + _userDept + " / " + _AffairsName + " </td></tr>" +
                                    "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                                    "</table>";

                                }
                                else if (_tndrType.Equals("PQ"))
                                {
                                    emailBodyText = emailBodyText + "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:#A9A9A9;color:Black;font-family:Calibri;font-size:18;font-weight:bold'>PQ No. : " + strTenderNo + "</td>" +
                                    "</tr><tr><td style='font-family:Calibri;font-size:15'><i>Project Code</i></td><td style='font-family:Calibri;font-size:15'>" + _prjCode + "</td></tr>" +
                                    "<tr><td style='font-family:Calibri;font-size:15'><i>Project Title</i></td><td style='font-family:Calibri;font-size:15'>" + proj_Title + "</td></tr>" +
                                    "<tr><td style='font-family:Calibri;font-size:15'><i>Tender Committee</i></td><td style='font-family:Calibri;font-size:15'>" + _cmtName + "</td></tr>" +
                                    "<tr><td style='font-family:Calibri;font-size:15'><i>Financial Year</i></td><td style='font-family:Calibri;font-size:15'>" + _fiscalYear + "</td></tr>" +       //+ "(" + _AffairsName + ")
                                    "<tr><td style='font-family:Calibri;font-size:15'><i>User Dept.</i></td><td style='font-family:Calibri;font-size:15'>" + _AffairsName + " </td></tr>" +
                                    "<tr><td style='font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                                    "</table>";
                                }
                                else
                                {
                                    emailBodyText = emailBodyText + "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:#1F4E79;color:White;font-family:Calibri;font-size:18;font-weight:bold'>TENDER No. : " + strTenderNo + "</td>" +
                                    "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Code</i></td><td style='font-family:Calibri;font-size:15'>" + _prjCode + "</td></tr>" +
                                    "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Title</i></td><td style='font-family:Calibri;font-size:15'>" + proj_Title + "</td></tr>" +
                                    "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Type of Tender</i></td><td style='font-family:Calibri;font-size:15'>" + _tndrTypeName + "</td></tr>" +
                                    "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Tender Committee</i></td><td style='font-family:Calibri;font-size:15'>" + _cmtName + "</td></tr>" +
                                    "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Financial Year</i></td><td style='font-family:Calibri;font-size:15'>" + _fiscalYear + "</td></tr>" +       //+ "(" + _AffairsName + ")
                                    "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>User Dept.</i></td><td style='font-family:Calibri;font-size:15'>" + _userDept + " / " + _AffairsName + " </td></tr>" +
                                    "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                                    "</table>";
                                }

                                emailBodyText = emailBodyText + "<br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>TCMS Team</div></body></html>";

                                mailMessage.Body = emailBodyText;
                                //mailMessage.Body = "This is an automated alert from TCMS." + "\n" + "\n" + "Project Code     : " + _prjCode + "\n" + "Project Title    : " + proj_Title + "\n" +   "Type of Tender   : " + _tndrTypeName + " " +
                                // "\n"  + "Tender Committee : " + _cmtName + " " +
                                // "\n" +  "User Department  : " + _userDept + " " +
                                // "\n" +  "Date Created     : " + System.DateTime.Now.ToString() + " " +
                                //" \n" +  "\n" + "Tender No. " + strTenderNo + " was assigned to above project.";

                                SmtpClient client = new SmtpClient();
                                client.EnableSsl = true;
                                //client.UseDefaultCredentials = true;
                                client.Credentials = new System.Net.NetworkCredential(@"Ashghal\tcms", ConfigurationManager.AppSettings["emailPass"].ToString());
                                ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                                client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                                client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                                client.Send(mailMessage);
                                //SendEmail myAction = new SendEmail(SendCompletedCallback);
                                //myAction.BeginInvoke(client, mailMessage, null, null);

                                //}
                                //}
                                MessageBox.Show("Tender Alert E-mail send to the users", "Create Tender Number");
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Exception occurred while sending the email notification to Tender Committee, Please inform them Personally", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Error occurred while assigning Tender Number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                    }
                }
            }
            isException = false;
        }
        private void btnAssignTender_Click(object sender, EventArgs e)
        {
            string [] projData = new string[13];
            projData[0] = _prjCode;
            projData[1] = proj_Title;
            projData[2] = _tndrTypeName;
            projData[3] = _cmtName;
            projData[4] = _fiscalYear;
            projData[5] = _userDept;
            projData[6] = _AffairsName;
            projData[7] = _userName;
            projData[8] = _projID.ToString();
            projData[9] = _tndrType;
            projData[10] = null;   //Tender Number
            projData[11] = null;   //TndrStatus
            projData[12] = null;   //TndrStatus
             
            UserAuthentication emailAddAuth = new UserAuthentication(projData, null, mUserRightsColl, false, false, false);
            emailAddAuth.StartPosition = FormStartPosition.CenterParent;
            emailAddAuth.ShowDialog();
            string tenderNum = emailAddAuth.TenderNum;
            //emailAddAuth.Close();
            if(tenderNum!=null)
            {
                btnAssignTender.Visible = false;
                lblTenderNo.Visible = true;
                txtTenderNo.Text = tenderNum;
            }            
        }

        private void SendCompletedCallback(SmtpClient smtpclient, System.Net.Mail.MailMessage mail) //private static void SendCompletedCallback(object sender, AsyncCompletedEventArgs e
        {
            try
            {
                smtpclient.Send(mail);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while sending the email notification to Engineering Services Department, Please inform network administrator about send email functionality not working", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                isException = true;
            }
               
            //finally
            //{
            //    mail.Dispose();
            //    mail = null;
            //    // smtpclient = null;
            //}
        }

        private delegate void SendEmail(SmtpClient smtpclient, System.Net.Mail.MailMessage mail);

        bool isException = false;
        //IList<string> userListColl = new List<string>();
        StringBuilder emailIds = new StringBuilder();
        private void UserList_ForAlert(int categryID)
        {
            
            //userListColl.Clear();
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();

                        string sqlQuery = "SELECT DISTINCT EmailAlertRecipients.user_id, USERS.email_address, USERS.user_name, EmailAlertCategory.AlertCategory, EmailAlertRecipients.alert_cat_id, " +
                                             " Committee.committee_short_name FROM EmailAlertCategory INNER JOIN EmailAlertRecipients ON EmailAlertCategory.alert_cat_id = EmailAlertRecipients.alert_cat_id INNER JOIN " +
                                             " USERS ON EmailAlertRecipients.user_id = USERS.user_id INNER JOIN Committee ON EmailAlertRecipients.committee_id = Committee.committee_id " +
                                             " WHERE (EmailAlertRecipients.alert_cat_id = " + categryID + ") AND (USERS.email_address <> N'') AND (Committee.committee_short_name ='" + _cmtName + "')";

                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {                                 
                                emailIds.Append(dr[1].ToString() + ",");                                 
                                //if (!userListColl.Contains(strData))                                    
                                //    userListColl.Add(strData);
                            }                            
                            dr.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while retrieving the email ids of a particular committee.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                isException = true;
            }
        }

        //UserList();
        //string DisplayName = ""; string Email = ""; string Department = ""; string Title = "";

        //string user_DisplayName = ""; string user_Email = ""; string user_Department = ""; string user_Title = "";
        //if (GetUserInformation4rmActiveDirectory(_userName, "ashghal.gov.qa", ref user_DisplayName, ref user_Email, ref  user_Department, ref user_Title) == true)
        //{
        //    foreach (string strname in userColl)
        //    {
        //        if (GetUserInformation4rmActiveDirectory(strname, "ashghal.gov.qa", ref DisplayName, ref Email, ref  Department, ref Title) == true)
        //        {
        //            string mailSub = "Assigned New tenderNo " + tenderNo;
        //            string bodySub = " Mr " + user_DisplayName + " From " + user_Department + " Department " + " Assigned New TenderNo As-- " + tenderNo + " For ProjectCode " + txtProjCode.Text;
        //            string attBody = "TenderNo Created";
        //            string attpath = "C:\\Temp\\SrcFile.txt";
        //            sendEMailThroughOUTLOOK(Email, mailSub, bodySub, attBody, attpath);
        //        }
        //    }
        //}


        IList<string> userColl = new List<string>();
        private void UserList()
        {
            userColl.Clear();
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        string sqlQuery = "SELECT USER_ID,USER_NAME FROM USERS Where User_ID in (14,15,16)";
                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                string strData = dr[1].ToString();
                                userColl.Add(strData);
                            }
                            dr.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while retrieving the usernames.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public Boolean GetUserInformation4rmActiveDirectory(string userId, string Domain, ref string DisplayName, ref string Email, ref string Department, ref string Title)
        {
            Boolean chkUserExist = false;
            try
            {
                string filter = string.Format("(&(ObjectClass={0})(sAMAccountName={1}))", "person", userId);

                DirectoryEntry activeDirectoryaddress = new DirectoryEntry("LDAP://" + Domain, null, null, AuthenticationTypes.Secure);
                DirectorySearcher searcher = new DirectorySearcher(activeDirectoryaddress);
                searcher.SearchScope = SearchScope.Subtree;

                searcher.Filter = filter;
                SearchResult result = searcher.FindOne();
                DirectoryEntry directoryEntry = result.GetDirectoryEntry();

                DisplayName = directoryEntry.Properties["displayName"][0].ToString();
                Email = directoryEntry.Properties["mail"][0].ToString();
                Department = directoryEntry.Properties["department"][0].ToString();
                Title = directoryEntry.Properties["title"][0].ToString();

                if (Email != null)
                {
                    chkUserExist = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Sorry unable to get your mail id from outlook", "ASHGHAL - EBSD");
            }

            return chkUserExist;
        }
        public void sendEMailThroughOUTLOOK(string emailAddr, string mailSubject, string mailBody, string attachmentDisplayName, string attachmentpath)
        {
            try
            {
                // Create the Outlook application.
                Microsoft.Office.Interop.Outlook.Application oApp = new Microsoft.Office.Interop.Outlook.Application();
                // Create a new mail item.
                Microsoft.Office.Interop.Outlook.MailItem oMsg = (Microsoft.Office.Interop.Outlook.MailItem)oApp.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                // Set HTMLBody. 
                //add the body of the email
                oMsg.HTMLBody = mailBody;
                //Add an attachment.
                String sDisplayName = attachmentDisplayName;
                int iPosition = (int)oMsg.Body.Length + 1;
                int iAttachType = (int)Microsoft.Office.Interop.Outlook.OlAttachmentType.olByValue;
                //now attached the file
                Microsoft.Office.Interop.Outlook.Attachment oAttach = oMsg.Attachments.Add(attachmentpath, iAttachType, iPosition, sDisplayName);  //"C:\\Temp\\SrcFile.txt"
                //Subject line
                oMsg.Subject = mailSubject;
                // Add a recipient.
                Microsoft.Office.Interop.Outlook.Recipients oRecips = (Microsoft.Office.Interop.Outlook.Recipients)oMsg.Recipients;
                // Change the recipient in the next line if necessary.
                Microsoft.Office.Interop.Outlook.Recipient oRecip = (Microsoft.Office.Interop.Outlook.Recipient)oRecips.Add(emailAddr);
                // Microsoft.Office.Interop.Outlook.Recipient oRecip = (Microsoft.Office.Interop.Outlook.Recipient)oRecips.Add("svadakapuram@ashghal.gov.qa");

                oRecip.Resolve();
                // Send.
                oMsg.Send();
                // Clean up.
                oRecip = null;
                oRecips = null;
                oMsg = null;
                oApp = null;
            }//end of try block
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }//end of catch
        }
        private void button15_Click(object sender, EventArgs e)
        {
            int dateId = MaxDateID();
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        int stage_Id = 0;
                        stage_Id = 4;

                        //  cmd.CommandText = @"INSERT INTO DATES(date_id,proj_id,stage_id,cp_tender_award,cp_received_of_doc,cp_request_start_date,cp_start_date_receive,cp_notice_contractor_to_sign,cp_due_date_pb,cp_sent_dep_sign,cp_receive_dep_sent_prsd,cp_sent_fd_commit,cp_receive_fd_commit,cp_distribution) VALUES(@dateId,@projId,@stageId,@evltendrReq,@fromCd,@senttoTech,@recfromtech,@sentFin,@recFin,@awardAppr)";

                        cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,cp_tender_award,cp_received_of_doc,cp_request_start_date,cp_start_date_receive,cp_notice_contractor_to_sign,cp_due_date_pb) VALUES(@dateId,@projId,@stageId,@cptenderaward,@cpreceivedofdoc,@cprequeststartdate,@cpstartdatereceive,@cpnotice_contractortosign,@cpduedatepb)";

                        cmd.Parameters.AddWithValue("@projId", Convert.ToInt16(lblProjID.Text));
                        cmd.Parameters.AddWithValue("@stageId", stage_Id);
                        cmd.Parameters.AddWithValue("@cptenderaward", dtpEA_reqdate.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@cpreceivedofdoc", dtpEA_recfromcd.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@cprequeststartdate", dtpTE_datesent1.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@cpstartdatereceive", dtpTE_daterec1.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@cpnotice_contractortosign", dtpFE_datesentfin1.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@cpduedatepb", dtpFE_daterecFin1.Value.ToString("dd/MMM/yyyy"));

                        cmd.Parameters.AddWithValue("@cp_sent_dep_sign", dtpEA_apprDate.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@cp_receive_dep_sent_prsd", dtpFE_datesentfin1.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@cp_sent_fd_commit", dtpFE_daterecFin1.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@cp_receive_fd_commit", dtpEA_apprDate.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@cp_distribution", dtpEA_apprDate.Value.ToString("dd/MMM/yyyy"));

                        cmd.Parameters.AddWithValue("@dateId", dateId);

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        MessageBox.Show("Contract Process data added Succesfully");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Insert the Contract Process records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            clsForCP.UpdateTenderStatus_CP(_projID);
        }

        private void button16_Click(object sender, EventArgs e)
        {
            int dateId = MaxDateID();

            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        int stage_Id = 0;
                        stage_Id = 5;

                        //  cmd.CommandText = @"INSERT INTO DATES(date_id,proj_id,stage_id,cp_tender_award,cp_received_of_doc,cp_request_start_date,cp_start_date_receive,cp_notice_contractor_to_sign,cp_due_date_pb,cp_sent_dep_sign,cp_receive_dep_sent_prsd,cp_sent_fd_commit,cp_receive_fd_commit,cp_distribution) VALUES(@dateId,@projId,@stageId,@evltendrReq,@fromCd,@senttoTech,@recfromtech,@sentFin,@recFin,@awardAppr)";

                        cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,cp_tender_award,cp_received_of_doc,cp_request_start_date,cp_start_date_receive,cp_notice_contractor_to_sign,cp_due_date_pb) VALUES(@dateId,@projId,@stageId,@cptenderaward,@cpreceivedofdoc,@cprequeststartdate,@cpstartdatereceive,@cpnotice_contractortosign,@cpduedatepb)";

                        cmd.Parameters.AddWithValue("@projId", Convert.ToInt16(lblProjID.Text));
                        cmd.Parameters.AddWithValue("@stageId", stage_Id);
                        cmd.Parameters.AddWithValue("@cptenderaward", dtpEA_reqdate.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@cpreceivedofdoc", dtpEA_recfromcd.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@cprequeststartdate", dtpTE_datesent1.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@cpstartdatereceive", dtpTE_daterec1.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@cpnotice_contractortosign", dtpFE_datesentfin1.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@cpduedatepb", dtpFE_daterecFin1.Value.ToString("dd/MMM/yyyy"));

                        cmd.Parameters.AddWithValue("@dateId", dateId);

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        MessageBox.Show("Contract Process data added Succesfully");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE DATES records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void btnUpdate_TP_Click(object sender, EventArgs e)
        {
            if (lblDateID.Text == "label90")
            {
                MessageBox.Show("Please Click on Row Which you want to Update !");
                return;
            }
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        cmd.CommandText = @"UPDATE TenderDatesInfo set ptd_receive_on=@ptdreceivedate,ptd_purpose=@ptdpurpose,ptd_assign_qs=@ptdassignqs,ptd_sent_for_rev=@ptdReview," +
                        "ptd_qs_working_status=@ptdQsstatus,ptd_tendec_doc_cur_status=@ptdCurrentStatus,ptd_forwarded_to_dep=@ptdFrwdToDep where date_id=@dateId";

                        cmd.Parameters.AddWithValue("@ptdreceivedate", dtpRecievedOn.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@ptdpurpose", cmbPurpose.SelectedItem.ToString());
                        cmd.Parameters.AddWithValue("@ptdassignqs", cmbAssignedQs.SelectedItem.ToString());
                        cmd.Parameters.AddWithValue("@ptdReview", dtpReview.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@ptdQsstatus", cmbQsWorkingStatus.SelectedItem.ToString());
                        cmd.Parameters.AddWithValue("@ptdCurrentStatus", cmbTenderDocStatus.SelectedItem.ToString());
                        cmd.Parameters.AddWithValue("@ptdFrwdToDep", dtpFrwdDept.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@dateId", Convert.ToInt16(lblDateID.Text));

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        MessageBox.Show("Tender Preparation Values Updated Succesfully");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE DATES records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            GridViewRefresh_PTD();

        }

        Boolean chkUpdateStatus = false;
        private void dgvPTD_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {

            int rowIndex = Convert.ToInt16(dgvPTD.Rows[e.RowIndex].Index);
            for (int iCnt = 0; iCnt < dgvPTD.Rows.Count; iCnt++)
            {
                if (iCnt.Equals(rowIndex))
                {
                    chkUpdateStatus = true;

                    if (dgvPTD.Rows[iCnt].Cells[0].Value != DBNull.Value)
                    {
                        //dtpRecievedOn.CustomFormat = "dd/MMM/yyyy";
                        msk_dtpRecievedOn.Text = Convert.ToDateTime(dgvPTD.Rows[iCnt].Cells[0].Value).ToString("dd/MMM/yyyy");
                    }
                    else
                    {
                        msk_dtpRecievedOn.Text = "";
                    }


                    cmbPurpose.Text = Convert.ToString(dgvPTD.Rows[iCnt].Cells[1].Value);
                    cmbAssignedQs.Text = Convert.ToString(dgvPTD.Rows[iCnt].Cells[2].Value);

                    if (dgvPTD.Rows[iCnt].Cells[3].Value.ToString() != "")
                    {
                        //dtpReview.CustomFormat = "dd/MMM/yyyy";
                        msk_dtpReview.Text = Convert.ToDateTime(dgvPTD.Rows[iCnt].Cells[3].Value).ToString("dd/MMM/yyyy");
                    }
                    else
                    {
                        msk_dtpReview.Text = "";
                    }


                    cmbQsWorkingStatus.Text = Convert.ToString(dgvPTD.Rows[iCnt].Cells[4].Value);
                    cmbTenderDocStatus.Text = Convert.ToString(dgvPTD.Rows[iCnt].Cells[5].Value);
                    if (dgvPTD.Rows[iCnt].Cells[6].Value.ToString() != "")
                    {
                        //dtpFrwdDept.CustomFormat = "dd/MMM/yyyy";
                        msk_dtpFrwdDept.Text = Convert.ToDateTime(dgvPTD.Rows[iCnt].Cells[6].Value).ToString("dd/MMM/yyyy");
                    }
                    else
                    {
                        msk_dtpFrwdDept.Text = "";
                    }

                    txtRemarks.Text = Convert.ToString(dgvPTD.Rows[iCnt].Cells[7].Value);

                    lblDateID.Text = Convert.ToString(dgvPTD.Rows[iCnt].Cells[8].Value);
                }
            }
            // btnPTD.Enabled = false;
        }
        private void button22_Click(object sender, EventArgs e)
        {
            if (lblDateID.Text == "label90")
            {
                return;
            }
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"DELETE FROM TenderDatesInfo WHERE DATE_ID = " + Convert.ToInt16(lblDateID.Text) + " ";
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Record Deleted Successfully ");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE DATES records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            GridViewRefresh_PTD();
        }

        private void button23_Click(object sender, EventArgs e)
        {
            dtpRecievedOn.Checked = false;
            dtpReview.Checked = false;
            dtpFrwdDept.Checked = false;
            cmbAssignedQs.SelectedIndex = -1;
            cmbPurpose.SelectedIndex = -1;
            cmbQsWorkingStatus.SelectedIndex = -1;
            cmbTenderDocStatus.SelectedIndex = -1;
            txtRemarks.Text = "";
        }
        private void dtpEA_stage1_ValueChanged(object sender, EventArgs e)
        {
            //dtpTV_OrgDate.Text =  dtpEA_stage1.Value.AddDays(90).ToString();

            //if (dtpTV_OrgDate.Checked == true)
            //{
            //    int iDays = (System.DateTime.Now.Date - dtpTV_OrgDate.Value).Days;
            //    txtTV_exipre.Text = iDays.ToString();
            //}
            //if (dtpTBV_OrgDate.Checked == true)
            //{
            //    int iDays = (System.DateTime.Now.Date - dtpTBV_OrgDate.Value).Days;
            //    txtTBV_exipre.Text = iDays.ToString();
            //}
        }

        private void dtpTV_SEdate_ValueChanged(object sender, EventArgs e)
        {
            msk_dtpTV_SEdate.Focus();
            msk_dtpTV_SEdate.Text = dtpTV_SEdate.Value.ToString("dd-MMM-yyyy");
            //if (msk_dtpEA_reqdate.Text != "")
            //{
            //    msk_dtpTV_SEdate.Text = dtpTV_SEdate.Value.ToString("dd/MMM/yyyy");                
            //}
        }
        private void dtpTBV_SEdate_ValueChanged(object sender, EventArgs e)
        {
            //if (msk_dtpEA_stage1.Text != "")
            //{
            //    msk_dtpTBV_SEdate.Text = dtpTBV_SEdate.Value.ToString("dd/MMM/yyyy");                
            //}
            msk_dtpTBV_SEdate.Text = dtpTBV_SEdate.Value.ToString("dd-MMM-yyyy");
            msk_dtpTBV_SEdate.Focus();
        }
        private void dtpTV_FEdate_ValueChanged(object sender, EventArgs e)
        {
            //if (msk_dtpEA_reqdate.Text != "")
            //{
            //    msk_dtpTV_FEdate.Text = dtpTV_FEdate.Value.ToString("dd/MMM/yyyy");               
            //}
            msk_dtpTV_FEdate.Text = dtpTV_FEdate.Value.ToString("dd-MMM-yyyy");
            msk_dtpTV_FEdate.Focus();
        }
        private void dtpTBV_FEdate_ValueChanged(object sender, EventArgs e)
        {
            //if (msk_dtpEA_reqdate.Text != "")
            //{
            //    msk_dtpTBV_FEdate.Text = dtpTBV_FEdate.Value.ToString("dd/MMM/yyyy");             
            //}
            msk_dtpTBV_FEdate.Text = dtpTBV_FEdate.Value.ToString("dd-MMM-yyyy");
            msk_dtpTBV_FEdate.Focus();
        }

        private void fillStage6()
        {
            try
            {
                using (SqlConnection sqlCn = new SqlConnection(connStr))
                {
                    sqlCn.Open();
                    String insertData = "DELETE FROM TenderDatesInfo WHERE (stage_id = 6) AND (proj_id = " + _projID + ")";
                    SqlCommand cmd = new SqlCommand(insertData, sqlCn);
                    cmd.ExecuteNonQuery();
                    sqlCn.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            int dateID = 0;
            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                String readData = "SELECT MAX(DATE_ID) FROM TenderDatesInfo";
                SqlCommand cmd = new SqlCommand(readData, sqlCn);
                dateID = Convert.ToInt16(cmd.ExecuteScalar());
                dateID = dateID + 1;
                sqlCn.Close();
            }

            SqlConnection cn = new SqlConnection(connStr);
            cn.Open();
            SqlDataAdapter da = new SqlDataAdapter();
            for (int i = 0; i < dgvPC.Rows.Count - 1; i++)
            {
                if (dgvPC.Rows[i].Cells[0].Value != null)
                {
                    dateID = dateID + i;
                    String insertData = "INSERT INTO TenderDatesInfo(Date_ID, Proj_ID,stage_id,[Staff_In_Charge],FromDate,ToDate,Remarks,employee_id) VALUES (@dateId,@PrjId,@stgID, @staffName, @FromDate,@ToDate,@PC_Remarks,@empID)";
                    SqlCommand cmd = new SqlCommand(insertData, cn);

                    cmd.Parameters.AddWithValue("@dateId", dateID);
                    cmd.Parameters.AddWithValue("@PrjId", _projID);
                    cmd.Parameters.AddWithValue("@stgID", 6);
                    cmd.Parameters.AddWithValue("@empID", dgvPC.Rows[i].Cells[0].Value);
                    cmd.Parameters.AddWithValue("@staffName", dgvPC.Rows[i].Cells[0].Value);

                    if (dgvPC.Rows[i].Cells[1].Value.ToString() != "")
                    {
                        cmd.Parameters.AddWithValue("@FromDate", Convert.ToDateTime(dgvPC.Rows[i].Cells[1].Value).ToString("dd/MMM/yyyy"));
                    }
                    else
                        cmd.Parameters.AddWithValue("@FromDate", DBNull.Value);

                    if (dgvPC.Rows[i].Cells[2].Value.ToString() != "")
                    {
                        cmd.Parameters.AddWithValue("@ToDate", Convert.ToDateTime(dgvPC.Rows[i].Cells[2].Value).ToString("dd/MMM/yyyy"));
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("@ToDate", DBNull.Value);
                    }
                    // cmd.Parameters.AddWithValue("@PC_Remarks",txtPC_Remarks.Text);

                    if (dgvPC.Rows[i].Cells[3].Value != null)
                        cmd.Parameters.AddWithValue("@PC_Remarks", dgvPC.Rows[i].Cells[3].Value);
                    else
                        cmd.Parameters.AddWithValue("@PC_Remarks", DBNull.Value);
                    da.InsertCommand = cmd;
                    cmd.ExecuteNonQuery();
                }
            }
            cn.Close();

            MessageBox.Show("Data saved successfully.", "PostContract Data Entry", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void dtp_tsRecOn_ValueChanged(object sender, EventArgs e)
        {
            //dtp_tsRecOn.Value.ToString("dd/MMM/yyyy");
            //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            msk_dtp_tsRecOn.Text = Convert.ToDateTime(dtp_tsRecOn.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
            msk_dtp_tsRecOn.Focus();
        }
        private void dtp_tsReturnDept_ValueChanged(object sender, EventArgs e)
        {
            //msk_dtp_tsReturnDept.Text = dtp_tsReturnDept.Value.ToString("dd/MMM/yyyy");
            //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            msk_dtp_tsReturnDept.Text = Convert.ToDateTime(dtp_tsReturnDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
            dtp_tsReturnDept.Focus();
        }
        private void dtp_tsRecFromDept_ValueChanged(object sender, EventArgs e)
        {
            //dtp_tsRecFromDept.Focus();
            //msk_dtp_tsRecFromDept.Text = dtp_tsRecFromDept.Value.ToString("dd/MMM/yyyy");
            //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            msk_dtp_tsRecFromDept.Text = Convert.ToDateTime(dtp_tsRecFromDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");

        }
        private void dtp_tsAdvertisement_ValueChanged(object sender, EventArgs e)
        {
            dtp_tsAdvertisement.Focus();
            //msk_dtp_tsAdvertisement.Text = dtp_tsAdvertisement.Value.ToString("dd/MMM/yyyy");
            //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            msk_dtp_tsAdvertisement.Text = Convert.ToDateTime(dtp_tsAdvertisement.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");

        }
        private void dtp_tsInvitation_ValueChanged(object sender, EventArgs e)
        {
            //msk_dtp_tsInvitation.Text = dtp_tsInvitation.Value.ToString("dd/MMM/yyyy");
            //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            msk_dtp_tsInvitation.Text = Convert.ToDateTime(dtp_tsInvitation.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
            dtp_tsInvitation.Focus();
        }

        private void dtp_tsStage1_ValueChanged(object sender, EventArgs e)
        {
            //msk_dtp_tsStage1.Text = dtp_tsStage1.Value.ToString("dd/MMM/yyyy");
            //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            if (mUserRightsColl.Contains("40"))       // For TS
            {
                MessageBox.Show("You don't have edit rights on Tendering Satge, Contact administrator");
                return;
            }
            msk_dtp_tsStage1.Text = Convert.ToDateTime(dtp_tsStage1.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
            msk_dtp_tsStage1.Focus();
        }
        private void dtp_tsStage2_ValueChanged(object sender, EventArgs e)
        {
            //msk_dtp_tsStage2.Text = dtp_tsStage2.Value.ToString("dd/MMM/yyyy");
            //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            msk_dtp_tsStage2.Text = Convert.ToDateTime(dtp_tsStage2.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
            msk_dtp_tsStage2.Focus();
        }
        private void dtp_tsModifiedDate_Stage1_ValueChanged(object sender, EventArgs e)
        {
            if (mUserRightsColl.Contains("40"))       // For TS
            {
                MessageBox.Show("You don't have edit rights on Tendering Satge, Contact administrator");
                return;
            }
            //msk_dtp_tsModifiedDate.Text = dtp_tsModifiedDate.Value.ToString("dd/MMM/yyyy");
            //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            msk_dtp_tsModifiedDate_Stage1.Text = Convert.ToDateTime(dtp_tsModifiedDate_Stage1.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
            msk_dtp_tsModifiedDate_Stage1.Focus();
        }
        private void msk_dtp_tsReturnDept_Leave(object sender, EventArgs e)
        {
            if (msk_dtp_tsReturnDept.Text != "")
            {
                if (ValidateDate(msk_dtp_tsReturnDept) == false)
                {
                    msk_dtp_tsReturnDept.Text = "";
                    msk_dtp_tsReturnDept.Focus();
                }
            }
        }
        private void msk_dtp_tsRecFromDept_Leave(object sender, EventArgs e)
        {
            if (msk_dtp_tsRecFromDept.Text != "")
            {
                if (ValidateDate(msk_dtp_tsRecFromDept) == false)
                {
                    msk_dtp_tsRecFromDept.Text = "";
                    msk_dtp_tsRecFromDept.Focus();
                }
            }
        }
        private void msk_dtp_tsAdvertisement_Leave(object sender, EventArgs e)
        {
            if (msk_dtp_tsAdvertisement.Text != "")
            {
                if (ValidateDate(msk_dtp_tsAdvertisement) == false)
                {
                    msk_dtp_tsAdvertisement.Text = "";
                    msk_dtp_tsAdvertisement.Focus();
                }
            }
        }
        private void msk_dtp_tsInvitation_Leave(object sender, EventArgs e)
        {
            if (msk_dtp_tsInvitation.Text != "")
            {
                if (ValidateDate(msk_dtp_tsInvitation) == false)
                {
                    msk_dtp_tsInvitation.Text = "";
                    msk_dtp_tsInvitation.Focus();
                }
            }
        }
        private void msk_dtp_tsStage1_Leave(object sender, EventArgs e)
        {
            if (msk_dtp_tsStage1.Text != "")
            {
                if (ValidateDate(msk_dtp_tsStage1) == true)
                {
                    if (msk_dtp_tsRecOn.Text == "")
                    {
                        msk_dtp_tsStage1.Text = "";
                        msk_dtp_tsRecOn.Focus();
                        MessageBox.Show("Please update the date on '(For Tendering) Received On' before this field.");
                        return;
                    }
                    if (Convert.ToDateTime(msk_dtp_tsRecOn.Text) > Convert.ToDateTime(msk_dtp_tsStage1.Text))
                    {
                        msk_dtp_tsStage1.Text = "";
                        msk_dtp_tsStage1.Focus();

                        MessageBox.Show("Date entered is earlier than '(For Tendering) Received On'. Please check and revise your entry.");
                        return;
                    }
                }
                else
                {
                    msk_dtp_tsStage1.Text = "";
                    msk_dtp_tsStage1.Focus();
                }
            }
        }
        private void msk_dtp_tsStage2_Leave(object sender, EventArgs e)
        {
            if (msk_dtp_tsStage2.Text != "")
            {
                if (ValidateDate(msk_dtp_tsStage2) == false)
                {
                    if (msk_dtp_tsStage1.Text == "")
                    {
                        msk_dtp_tsStage2.Text = "";
                        msk_dtp_tsStage1.Focus();
                        MessageBox.Show("There is no date in Tender Closing Date Stage 1. Please update this prior to this field.");

                        return;
                    }
                    if (Convert.ToDateTime(msk_dtp_tsStage1.Text) > Convert.ToDateTime(msk_dtp_tsStage2.Text))
                    {
                        msk_dtp_tsStage2.Text = "";
                        msk_dtp_tsStage2.Focus();
                        MessageBox.Show("Stage 2 date should be greater than Stage 1 date");

                        return;
                    }
                }
            }
        }
        private void msk_dtp_tsModifiedDate_Leave(object sender, EventArgs e)
        {
            if (msk_dtp_tsModifiedDate_Stage1.Text != "")
            {
                if (ValidateDate(msk_dtp_tsModifiedDate_Stage1) != false)
                {
                    if (msk_dtp_tsStage1.Text == "")
                    {
                        msk_dtp_tsStage1.Focus();
                        MessageBox.Show("There is no date in Tender Closing Date Stage 1. Please update this prior to this field.");
                        msk_dtp_tsModifiedDate_Stage1.Text = "";
                        return;
                    }
                    if (Convert.ToDateTime(msk_dtp_tsStage1.Text) > Convert.ToDateTime(msk_dtp_tsModifiedDate_Stage1.Text))
                    {

                        msk_dtp_tsModifiedDate_Stage1.Focus();
                        MessageBox.Show("Date entered is less than 'Tender Closing Date'. Please check and revise your entry.");
                        msk_dtp_tsModifiedDate_Stage1.Text = "";
                        return;
                    }
                }
                else
                {
                    msk_dtp_tsModifiedDate_Stage1.Text = "";
                    msk_dtp_tsModifiedDate_Stage1.Focus();
                }
            }

            //if (msk_dtp_tsModifiedDate.Text != "" && !msk_dtp_tsModifiedDate.Text.Equals(_modifiedClosingDate))
            //  AlertMessageForTenderClosing(_modifiedClosingDate, msk_dtp_tsModifiedDate.Text);

        }
        private void AlertMessageForTenderClosing(string _modifiedDate, string _modified_NewDate)
        {

            UserList_ForAlert(2);

            if (emailIds.Length == 0)
            {
                MessageBox.Show("Information for Tender No.assignment is required to be sent to a user who handles " + _cmtName + " projects, " +
                  " but there is no identified user to receive the email. Please contact system administrator for information.");
                return;
            }


            // AlertOnNewTenderNo(tenderNo, _projID.ToString(), "New Project");
            CommonClass comCls = new CommonClass(_userName);
            string fromUser = null;
            fromUser = comCls.getUserEmailID(_userName);

            try
            {

                //foreach (string strname in userListColl)
                //{
                    // if (GetUserInformation4rmActiveDirectory(strname, "ashghal.gov.qa", ref DisplayName, ref Email, ref  Department, ref Title) == true)
                    //{
                        MailMessage mailMessage = new MailMessage();
                        mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["From"].ToString());                                                  
                        mailMessage.To.Add(emailIds.ToString().Substring(0,emailIds.ToString().Length-1));
                        mailMessage.Subject = "TCMS Alert: Tender Closing Date. " + _modifiedDate + " was modified";
                        // mailMessage.Body = "This is an automated alert from TCMS." + "\n" + "\n" + "Project Code: " + _prjCode + "\n" + "Project Title: " + proj_Title + "\n" + "\n" + "Tender No. " + strTenderNo + " was assigned to above project.";

                        mailMessage.Body = "This is an automated alert from Tender & Contract Management System." + "\n" + "\n" + "Project Code     : " + _prjCode + " " +
                          "\n" + "Project Title    : " + proj_Title + " " +
                           "\n" + "Tender Closing Existed Date : " + _modifiedDate + " " +
                            "\n" + "Tender Closing New Date : " + _modified_NewDate + " " +
                            //  "\n" + "Type of Tender   : " + _tndrTypeName + " " +
                            //"\n" + "Tender Committee : " + _cmtName + " " +
                            // "\n" + "User Department  : " + _userDept + " " +
                            // "\n" + "Date Created     : " + System.DateTime.Now.ToString() + " " +
                        " \n" + "\n" + " Tender Closing Date Was Modified.";


                        SmtpClient client = new SmtpClient();
                        client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                        client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                        client.Send(mailMessage);
                //    }

                //}
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception occurred while sending the email notification to Tender Committee, Please inform them Personally", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void dtpEA_recfromcd_ValueChanged(object sender, EventArgs e)
        {
            //dtpEA_recfromcd.Focus();
            //msk_dtpEA_recfromcd.Text = dtpEA_recfromcd.Value.ToString("dd/MMM/yyyy");
            //Modified by Varun on 13/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings                         
            //msk_dtpEA_recfromcd.Text = Convert.ToDateTime(dtpEA_recfromcd.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
            ReceivedFromCDDateEvaluation(dtpEA_recfromcd, msk_dtpEA_recfromcd, false);
        }

        private bool ReceivedFromCDDateEvaluation(DateTimePicker dtpDate, MaskedTextBox setDate, bool isSubmit)
        {
            bool isResult = true;
            if (isSubmit == false)
            {
                if (msk_dtpEA_reqdate.Text != "")
                {
                    if (Convert.ToDateTime(msk_dtpEA_reqdate.Text).CompareTo(Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture))) < 0)
                    {
                        MessageBox.Show("Doc Received From CD cannot be less than Tender Open Date");
                        msk_dtpEA_recfromcd.Focus();
                        isResult = false;
                    }
                    else
                    {
                        msk_dtpEA_recfromcd.Text = Convert.ToDateTime(dtpEA_recfromcd.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
                    }
                }
                else
                {
                    MessageBox.Show("Cannot enter date in Doc Received From CD when there are no date in Tender Open Date");
                    msk_dtpEA_recfromcd.Focus();
                    isResult = false;
                }
            }
            else
            {
                if (msk_dtpEA_reqdate.Text.Trim().Equals("") && !msk_dtpEA_recfromcd.Text.Trim().Equals(""))
                {
                    MessageBox.Show("Tender Open Date is blank while Doc Received From CD has date. Please enter date in Tender Open Date");
                    msk_dtpEA_recfromcd.Focus();
                    isResult = false;
                }

            }
            return isResult;
        }

        private void dtpEA_datesent_ValueChanged(object sender, EventArgs e)
        {
            msk_dtpTE_datesent1.Text = "";
            if(DateSendFirstEvalValidation(dtpTE_datesent1, msk_dtpTE_datesent1, msk_dtpEA_recfromcd, "Technical Evaluation", false))
            {
                if (!dtpTE_datesent1.Value.ToString().Contains("1900") && dtpTE_datesent1.Value.ToString().Trim() != "")
                {
                    msk_dtpTE_datesent1.Text = Convert.ToDateTime(dtpTE_datesent1.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
                }
            }
        }


        private void dtpEA_daterec_ValueChanged(object sender, EventArgs e)
        {
            msk_dtpTE_daterec1.Text = "";
            DateReceivedFirstEvalValidation(dtpTE_daterec1, msk_dtpTE_datesent1, msk_dtpTE_daterec1, "Technical Evaluation", false);
        }

        private bool DateSendFirstEvalValidation(DateTimePicker dtpDateSend, MaskedTextBox dateSend, MaskedTextBox dateReceived, string stageName, bool isSubmit)
        {
            bool isResult = true;
            //Modified by Varun on 13/02/2016 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            if (dateReceived.Text != "")
            {
                if (isSubmit == false)
                {
                    isResult = CheckPreviousStageDates(dtpDateSend, dateSend, dateReceived, stageName, "Send", "First", isSubmit);
                    if (isResult == false)
                    {
                        return isResult;
                    }

                    //isResult = ValidatingDateControls(dtpDateSend, dateSend, stageName, "First", "Send", isSubmit);
                    //if(dateSend.Text!="")
                    //{
                    //    dtpTE_daterec1.Value = Convert.ToDateTime(dateSend.Text);
                    //}
                    //ValidatingControlsWithSendDates(dtpDateSend, dateSend, stageName, "First", isSubmit);                      
                    //else
                    //{
                    //    //Modified by Varun on 13/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
                    //    if (isResult)
                    //    {
                    //        dateSend.Text = Convert.ToDateTime(dtpDateSend.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
                    //        isResult = true;
                    //        return isResult;
                    //    }
                    //    else
                    //    {
                    //        dateSend.Focus();
                    //    }
                    //}
                }
                else
                {
                    if (dateSend.Text.Trim() != "")
                    {
                        isResult = CheckPreviousStageDates(dtpDateSend, dateSend, dateReceived, stageName, "Send", "First", isSubmit);
                        if (isResult == false)
                        {
                            return isResult;
                        }
                        //isResult = ValidatingDateControls(dtpDateSend, dateSend, stageName, "First", "Send", isSubmit);
                    }
                }
            }
            //else if (isSubmit == true)
            //{
            //    //if (dateReceived.Text == "")
            //    //{
            //    //    if (dateSend.Text.Trim() != "")
            //    //    {

            //    //    }
            //    //}
            //}
            else if (isSubmit == false)
            {

                if (dtpDateSend.Name.Equals("dtpTE_datesent1"))
                {
                    MessageBox.Show("Cannot enter Technical Evaluation Send Date (First Evaluation) when there are no date in Doc Received From CD");
                    dateSend.Focus();
                    isResult = false;
                    return isResult;
                }
                else if (stageName.Equals("Financial Tender Review"))
                {
                    MessageBox.Show("Cannot enter Financial Tender Review Send Date (First Evaluation) when there are no date in Financial Evaluation Received Date");
                    dateSend.Focus();
                    isResult = false;
                    return isResult;
                    //MessageBox.Show(stageName + " Date Send (First Evaluation) cannot be less than Technical Evaluation Date Received (First Evaluation)"); Technical
                }
                else
                {
                    MessageBox.Show("Cannot enter Financial Evaluation Send Date (First Evaluation) when there are no date in Technical Tender Review Received Date");
                    dateSend.Focus();
                    isResult = false;
                    return isResult;
                }
                //MessageBox.Show(stageName + " Date Send (First Evaluation) cannot be less than Technical Tender Review Date Received (First Evaluation)");
                //dateSend.Text = Convert.ToDateTime(dtpDateSend.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");                 
            }
            return isResult;
        }

        private bool CheckPreviousStageDates(DateTimePicker dtpDate, MaskedTextBox dateSet, MaskedTextBox dateReceived, string stageName, string evalStagePosition, string dateType, bool isSubmit)
        {
            bool isResult = true;
            
            if (isSubmit == false)
            {
                if (msk_dtpEA_recfromcd.Text != "")
                {
                    if (dateSet.Text != "")
                    {
                        if (Convert.ToDateTime(dateSet.Text).CompareTo(Convert.ToDateTime(msk_dtpEA_recfromcd.Text)) < 0)
                        {
                            MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be less than Doc Received From CD Date");
                            dateSet.Focus();
                            isResult = false;
                            return isResult;
                        }
                        //else
                        //{
                        //    msk_dtpTE_datesent1.Text = dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture);
                        //}
                    }
                    //else
                    //{
                    //    msk_dtpTE_datesent1.Text = dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture);
                    //}
                }
                else
                {
                    MessageBox.Show("Cannot enter date in " + stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) because there is no date in Doc Received From CD Date");
                    isResult = false;
                    return isResult;
                }
                if (msk_dtpEA_reqdate.Text != "")
                {
                    if (msk_dtpTE_daterec1.Text != "")
                    {
                        if (!dtpDate.Value.ToString().Contains("1900") && dtpDate.Value.ToString().Trim()!="")
                        {
                            if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) < 0)
                            {
                                MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be less than Technical Evaluation Date Recieved");
                                dateSet.Focus();
                                isResult = false;
                                return isResult;
                            }
                        }
                    }
                    if (msk_dtpTE_datesent1.Text != "")
                    {
                        if (!dtpDate.Value.ToString().Contains("1900") && dtpDate.Value.ToString().Trim() != "")
                        {
                            if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_datesent1.Text)) < 0)
                            {
                                MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be less than Technical Evaluation Send Date");
                                dateSet.Focus();
                                isResult = false;
                                return isResult;
                            }
                        }
                    }
                    
                }
                else
                {
                    MessageBox.Show("Cannot enter date in " + stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) because there is no date in Tender Open Date");
                    isResult = false;
                    return isResult;
                }
            }
            else
            {
                if (msk_dtpEA_recfromcd.Text != "")
                {
                    if (dateSet.Text != "")
                    {
                        if (Convert.ToDateTime(dateSet.Text).CompareTo(Convert.ToDateTime(msk_dtpEA_recfromcd.Text)) < 0)
                        {
                            MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be less than Doc Received From CD Date");
                            dateSet.Focus();
                            isResult = false;
                            return isResult;
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Cannot enter date in " + stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) because there is no date in Doc Received From CD Date");
                    isResult = false;
                    return isResult;
                }
                if (msk_dtpEA_reqdate.Text != "")
                {
                    if (dateSet.Text != "")
                    {
                        if (Convert.ToDateTime(dateSet.Text).CompareTo(Convert.ToDateTime(msk_dtpEA_reqdate.Text)) < 0)
                        {
                            MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be less than Tender Open Date");
                            dateSet.Focus();
                            isResult = false;
                            return isResult;
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Cannot enter date in " + stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) because there is no date in Tender Open Date");
                    isResult = false;
                    return isResult;
                }
            }
            return isResult;
        }

        private bool DateReceivedFirstEvalValidation(DateTimePicker dtpDateReceived, MaskedTextBox dateSend, MaskedTextBox dateReceived, string stageName, bool isSubmit)
        {
            bool isResult = true;
            if (CheckBlankSendDatesOfTechnicalEvalStage() && CheckBlankSendDatesOfFinEvalStage()) //&& CheckBlankSendDatesOfTechnicalTenderReviewStage()
            {

            }
            else
            {
                return isResult = false;
            }
            if (isSubmit == false)
            {
                //Modified by Varun on 13/02/2016 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
                if (dateSend.Text.Trim() != "")
                {
                    isResult = CheckPreviousStageDates(dtpDateReceived, dateSend, dateReceived, stageName, "Received", "First", isSubmit);
                    if (isResult == false)
                    {
                        return isResult;
                    }

                    if (!dateSend.Text.Equals(""))
                    {
                        if (dateReceived.Text !="")
                        { 
                            if (Convert.ToDateTime(dateReceived.Text).CompareTo(Convert.ToDateTime(dateSend.Text)) < 0)
                            {
                                MessageBox.Show(stageName + " Received Date (First Evaluation) cannot be less than " + stageName + " Send Date (First Evaluation)");
                                dateReceived.Focus();
                                isResult = false;
                                return isResult;
                            }
                        }
                    }


                    if (!msk_dtpTE_datesent2.Text.Equals(""))
                    {
                        if (dtpDateReceived.Name.Equals("dtpTE_daterec1"))
                        {
                            if (dateReceived.Text != "")
                            {
                                if (Convert.ToDateTime(dateReceived.Text).CompareTo(Convert.ToDateTime(msk_dtpTE_datesent2.Text)) >= 0)
                                {
                                    MessageBox.Show(stageName + " Received Date (First Evaluation) cannot be greater than or equal to " + stageName + " Send Date (Second Evaluation)");
                                    dateReceived.Focus();
                                    isResult = false;
                                    return isResult;
                                }
                            }
                        }
                        else if (Convert.ToDateTime(dateReceived.Text).CompareTo(Convert.ToDateTime(msk_dtpTE_datesent2.Text)) < 0)
                        {
                            MessageBox.Show(stageName + " Received Date (First Evaluation) cannot be less than " + stageName + " Send Date (Second Evaluation)");
                            dateReceived.Focus();
                            isResult = false;
                            return isResult;
                        }
                    }

                    isResult = ValidatingDateControls(dtpDateReceived, dateReceived, stageName, "First", "Received", isSubmit);
                    //ValidatingDateControls(dtpDateReceived, dateReceived, stageName, "First", isSubmit);                   
                }
                else
                {
                    MessageBox.Show(stageName + " Date Received (First Evaluation) cannot be entered because " + stageName + " Date Send (First Evaluation) is blank");
                    isResult = false; 
                    return isResult;
                }
            }
            //else
            //{
            //    if (dateSend.Text.Trim() != "")  // && dateReceived.Text.Trim() != "")
            //    {
            //        isResult = CheckPreviousStageDates(dtpDateReceived, dateSend, dateReceived, stageName, "Received", "First", isSubmit);
            //        if (isResult == false)
            //        {
            //            return isResult;
            //        }

            //        if (dateSend.Text.Trim() != "")
            //        {
            //            if (dateReceived.Text != "")
            //            {
            //                if (Convert.ToDateTime(dateReceived.Text).CompareTo(Convert.ToDateTime(dateSend.Text)) < 0)
            //                {
            //                    MessageBox.Show(stageName + " Received Date (First Evaluation) cannot be less than " + stageName + " Send Date (First Evaluation)");
            //                    dateReceived.Focus();
            //                    isResult = false;
            //                    return isResult;
            //                }
            //            }

            //        }
            //        if (!msk_dtpTE_datesent2.Text.Equals(""))
            //        {
            //            if (dateReceived.Name.Equals("msk_dtpTTR_daterec1"))
            //            {
            //                if (Convert.ToDateTime(dateReceived.Text).CompareTo(Convert.ToDateTime(msk_dtpTE_datesent2.Text)) < 0)
            //                {
            //                    MessageBox.Show(stageName + " Received Date (First Evaluation) cannot be less than " + stageName + " Send Date (Second Evaluation)");
            //                    dateReceived.Focus();
            //                    isResult = false;
            //                    return isResult;
            //                }
            //            }
            //            else
            //            {
            //                if (dateReceived.Name.Equals("msk_dtpFTR_daterec1"))
            //                {
            //                    if (Convert.ToDateTime(msk_dtpTE_datesent2.Text).CompareTo(Convert.ToDateTime(dateReceived.Text)) > 0)
            //                    {
            //                        MessageBox.Show("Technical Evaluation Send Date (Second Evaluation) cannot be greater than " + stageName + " Received Date (First Evaluation)");
            //                        dateReceived.Focus();
            //                        isResult = false;
            //                        return isResult;
            //                    }
            //                }
            //                if (dateReceived.Name.Equals("msk_dtpFTR_daterec2"))
            //                {
            //                    if (Convert.ToDateTime(msk_dtpTE_datesent2.Text).CompareTo(Convert.ToDateTime(dateReceived.Text)) > 0)
            //                    {
            //                        MessageBox.Show("Technical Evaluation Send Date (Second Evaluation) cannot be greater than " + stageName + " Received Date (Second Evaluation)");
            //                        dateReceived.Focus();
            //                        isResult = false;
            //                        return isResult;
            //                    }
            //                }

            //            }
            //        }

            //        if (!msk_dtpTE_daterec2.Text.Equals("") && !msk_dtpTE_datesent2.Text.Equals(""))
            //        {
            //            if (dateReceived.Name.Equals("msk_dtpTTR_daterec1"))
            //            {
            //                if (Convert.ToDateTime(msk_dtpTE_daterec2.Text).CompareTo(Convert.ToDateTime(dateReceived.Text)) >= 0)
            //                {
            //                    MessageBox.Show(stageName + " Received Date (First Evaluation) cannot be greater than and equal to " + stageName + " Received Date (Second Evaluation)");
            //                    dateReceived.Focus();
            //                    isResult = false;
            //                    return isResult;
            //                }
            //            }
            //            else if (dateReceived.Name.Equals("msk_dtpTE_daterec1"))
            //            {
            //                if (Convert.ToDateTime(msk_dtpTE_daterec2.Text).CompareTo(Convert.ToDateTime(dateReceived.Text)) < 0)
            //                {
            //                    MessageBox.Show(stageName + " Received Date (First Evaluation) cannot be greater than and equal to " + stageName + " Received Date (Second Evaluation)");
            //                    dateReceived.Focus();
            //                    isResult = false;
            //                    return isResult;
            //                }
            //            }
            //            else if (Convert.ToDateTime(dateReceived.Text).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec2.Text)) < 0)
            //            {
            //                MessageBox.Show(stageName + " Received Date (First Evaluation) cannot be less than " + stageName + " Received Date (Second Evaluation)");
            //                dateReceived.Focus();
            //                isResult = false;
            //                return isResult;
            //            }
            //        }
            //        isResult = ValidatingDateControls(dtpDateReceived, dateReceived, stageName, "First", "Received", isSubmit);
            //        //ValidatingDateControls(dtpDateReceived, dateReceived, stageName, "First", isSubmit);

            //    }
            //    else
            //    {
            //        if (dateSend.Text.Trim().Equals("") && !dateReceived.Text.Trim().Equals(""))
            //        {
            //            MessageBox.Show("Cannot have date in " + stageName + " Date Received (First Evaluation) when there is no date in " + stageName + " Date Send (First Evaluation)");
            //            dateReceived.Focus();
            //            isResult = false;
            //            return isResult;
            //        }
            //        //if (!dateSend.Text.Trim().Equals("") && dateReceived.Text.Trim().Equals(""))
            //        //{
            //        //    MessageBox.Show("Cannot have date in " + stageName + " Date Send (First Evaluation) when there is no date in " + stageName + " Date Received (First Evaluation)");
            //        //    dateReceived.Focus();
            //        //    isResult = false;
            //        //    return isResult;
            //        //}
            //    }

            //}

            return isResult;
        }

        private bool TechTdrRevDateRecFirstEvalValidation()
        {
            bool isResult = true;
            //Modified by Varun on 13/02/2016 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            //if (msk_dtpTTR_datesent1.Text.Trim() != "")
            //{
            //    if (Convert.ToDateTime(dtpTTR_daterec1.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTTR_datesent1.Text)) < 0)
            //    {
            //        MessageBox.Show("Technical Tender Review Received Date (First Evaluation) cannot be less than Technical Tender Review Date Send (First Evaluation)");
            //        msk_dtpTTR_daterec1.Focus();
            //        isResult = false;
            //    }
            //    else
            //    {
            //        msk_dtpTTR_daterec1.Text = Convert.ToDateTime(dtpTTR_daterec1.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
            //    }
            //}
            //else
            //{
            //    msk_dtpTTR_daterec1.Focus();
            //    MessageBox.Show("Technical Tender Review Send date (First Evaluation) is blank cannot enter date in Technical Tender Review Received date (First Evaluation)");
            //    isResult = true;
            //}
            return isResult;
        }

        private bool CheckBlankSendDatesOfTechnicalEvalStage()
        {
            bool isResult = true;
            if (!msk_dtpTE_daterec1.Text.Equals("") && msk_dtpTE_datesent1.Text.Equals(""))
            {
                MessageBox.Show("There is a date in Technical Evaluation Received Date (First Evaluation), but no date in Technical Evaluation Send Date (First Evaluation). Please enter date in Technical Evaluation Send Date (First Evaluation)");
                msk_dtpTE_datesent1.Focus();
                isResult = false;
                return isResult;
            }
            else if (!msk_dtpTE_daterec2.Text.Equals("") && msk_dtpTE_datesent2.Text.Equals(""))
            {
                MessageBox.Show("There is a date in Technical Evaluation Received Date (Second Evaluation), but no date in Technical Evaluation Send Date (Second Evaluation). Please enter date in Technical Evaluation Send Date (Second Evaluation)");
                msk_dtpTE_datesent2.Focus();
                isResult = false;
                return isResult;
            }
            return isResult;
        }

        //private bool CheckBlankSendDatesOfTechnicalTenderReviewStage()
        //{
        //    bool isResult = true;
        //    if (!msk_dtpTTR_daterec1.Text.Equals("") && msk_dtpTTR_datesent1.Text.Equals(""))
        //    {
        //        MessageBox.Show("There is a date in Technical Tender Review Received Date (First Evaluation), but no date in Technical Tender Review Send Date (First Evaluation). Please enter date in Technical Tender Review Send Date (First Evaluation)");
        //        msk_dtpTTR_datesent1.Focus();
        //        isResult = false;
        //        return isResult;
        //    }
        //    else if (!msk_dtpTTR_daterec2.Text.Equals("") && msk_dtpTTR_datesent2.Text.Equals(""))
        //    {
        //        MessageBox.Show("There is a date in Technical Tender Review Received Date (Second Evaluation), but no date in Technical Tender Review Send Date (Second Evaluation). Please enter date in Technical Tender Review Send Date (Second Evaluation)");
        //        msk_dtpTTR_datesent2.Focus();
        //        isResult = false;
        //        return isResult;
        //    }
        //    return isResult;
        //}

        private bool CheckBlankSendDatesOfFinEvalStage()
        {
            bool isResult = true;
            if (!msk_dtpFE_daterecFin1.Text.Equals("") && msk_dtpFE_datesentfin1.Text.Equals(""))
            {
                MessageBox.Show("There is a date in Financial Evaluation Received Date (First Evaluation), but no date in Financial Evaluation Send Date (First Evaluation). Please enter date in Financial Evaluation Send Date (First Evaluation)");
                msk_dtpFE_datesentfin1.Focus();
                isResult = false;
                return isResult;
            }
            else if (!msk_dtpFE_daterecFin2.Text.Equals("") && msk_dtpFE_datesentfin2.Text.Equals(""))
            {
                MessageBox.Show("There is a date in Financial Evaluation Received Date (Second Evaluation), but no date in Financial Evaluation Send Date (Second Evaluation). Please enter date in Financial Evaluation Send Date (Second Evaluation)");
                msk_dtpFE_datesentfin2.Focus();
                isResult = false;
                return isResult;
            }
            return isResult;
        }

        private bool CheckBlankSendDatesOfFinTenderRevStage()
        {
            bool isResult = true;
            //if (!msk_dtpFTR_daterec1.Text.Equals("") && msk_dtpFTR_datesent1.Text.Equals(""))
            //{
            //    MessageBox.Show("There is a date in Financial Tender Review Received Date (First Evaluation), but no date in Financial Tender Review Send Date (First Evaluation). Please enter date in Financial Tender Review Send Date (First Evaluation)");
            //    msk_dtpFTR_datesent1.Focus();
            //    isResult = false;
            //    return isResult;
            //}
            //else if (!msk_dtpFTR_daterec2.Text.Equals("") && msk_dtpFTR_datesent2.Text.Equals(""))
            //{
            //    MessageBox.Show("There is a date in Financial Tender Review Received Date (Second Evaluation), but no date in Financial Tender Review Send Date (Second Evaluation). Please enter date in Financial Tender Review Send Date (Second Evaluation)");
            //    msk_dtpFTR_datesent2.Focus();
            //    isResult = false;
            //    return isResult;
            //}
            return isResult;
        }

        //dtpTTR_datesent1, msk_dtpTE_daterec1, msk_dtpTE_daterec2, "Technical Tender Review", "Technical Evaluation"
        private bool TenderRevDateSendFirstEvalValidation(DateTimePicker dpDateSend, MaskedTextBox dateSend, MaskedTextBox dateReceived1, MaskedTextBox dateReceived2, string currentStageName, string prevStageName, bool isSubmit)
        {
            bool isResult = true;
            bool isFirst = false;
            bool isSecond = false;
            string receivedDate = null;

            if (CheckBlankSendDatesOfTechnicalEvalStage())
            {

            }
            else
            {
                return isResult = false;
            }
            //Modified by Varun on 13/02/2016 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            if (dateReceived2.Text.Trim() != "")
            {
                receivedDate = dateReceived2.Text.Trim();
                isSecond = true;
            }
            else if (dateReceived1.Text.Trim() != "")
            {
                receivedDate = dateReceived1.Text.Trim();
                isFirst = true;
            }
            //else
            //{
            //    isResult = false;
            //}

            if (receivedDate != null)
            {
                if (isSubmit == false)
                {
                    isResult = CheckPreviousStageDates(dpDateSend, dateSend, dateReceived1, currentStageName, "Send", "First", isSubmit);
                    if (isResult == false)
                    {
                        return isResult;
                    }
                    if (Convert.ToDateTime(dpDateSend.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(receivedDate)) <= 0)
                    {
                        if (isSecond)
                        {
                            MessageBox.Show(currentStageName + " Send Date (First Evaluation) cannot be less than or equal to " + prevStageName + " Received Date (Second Evaluation)");
                            dateSend.Focus();
                            isResult = false;
                            return isResult;
                        }
                        else if (isFirst)
                        {
                            MessageBox.Show(currentStageName + " Send Date (First Evaluation) cannot be less than or equal to " + prevStageName + " Received Date (First Evaluation)");
                            dateSend.Focus();
                            isResult = false;
                            return isResult;
                        }
                    }


                    //if (dateSend.Text == "" && receivedDate != null)
                    //{
                    //    MessageBox.Show(currentStageName + " Send Date (First Evaluation) cannot have value when " + prevStageName + " Received Date (First Evaluation) is blank");
                    //    dateSend.Focus();
                    //    isResult = false;
                    //    return isResult;
                    //}
                    //isResult = ValidatingDateControls(dpDateSend, dateSend, currentStageName, "First", "Send", isSubmit);
                    //if (dateSend.Text != "")
                    //{
                    //    dtpTTR_daterec1.Value = Convert.ToDateTime(dateSend.Text).AddDays(1);
                    //    dtpTTR_daterec1.ResetText();
                    //    Control ctrl = new Control("msk_" + dtpTTR_daterec1.Name);
                    //    ctrl.Text = "";
                    //}
                    //ValidatingControlsWithSendDates(dpDateSend, dateSend, currentStageName, "First", isSubmit);                                
                }
                else
                {
                    //if (msk_dtpTTR_datesent1.Text.Trim() != "" && msk_dtpTTR_daterec1.Text.Trim() == "")
                    //{
                    //    MessageBox.Show("Technical Tender Review Received Date (First Evaluation) cannot be blank when there is a date in Technical Tender Review Send Date (First Evaluation)");
                    //    msk_dtpFE_daterecFin1.Focus();
                    //    isResult = false;
                    //    return isResult;
                    //}
                    if (dateSend.Text != "" && receivedDate != null)
                    {
                        isResult = CheckPreviousStageDates(dpDateSend, dateSend, dateReceived1, currentStageName, "Send", "First", isSubmit);
                        if (isResult == false)
                        {
                            return isResult;
                        }
                        if (Convert.ToDateTime(dateSend.Text).CompareTo(Convert.ToDateTime(receivedDate)) <= 0)
                        {
                            if (isSecond)
                            {
                                MessageBox.Show(currentStageName + " Send Date (First Evaluation) cannot be less than or equal to " + prevStageName + " Received Date (Second Evaluation)");
                                dateSend.Focus();
                                isResult = false;
                                return isResult;
                            }
                            else if (isFirst)
                            {
                                MessageBox.Show(currentStageName + " Send Date (First Evaluation) cannot be less than or equal to " + prevStageName + " Received Date (First Evaluation)");
                                dateSend.Focus();
                                isResult = false;
                                return isResult;
                            }
                        }
                        //isResult = ValidatingDateControls(dpDateSend, dateSend, currentStageName, "First", "Send", isSubmit);
                        //ValidatingControlsWithSendDates(dpDateSend, dateSend, currentStageName, "First", isSubmit);                        

                        //if (currentStageName.Equals("Technical Tender Review"))
                        //{
                        //    if (msk_dtpTTR_daterec1.Text != "")
                        //    {
                        //        if (Convert.ToDateTime(dateSend.Text).CompareTo(Convert.ToDateTime(msk_dtpTTR_daterec1.Text)) < 0)
                        //        {
                        //            MessageBox.Show(currentStageName + " Send Date (First Evaluation) cannot be less than or equal to " + currentStageName + " Received Date (First Evaluation)");
                        //            dateSend.Focus();
                        //            isResult = false;
                        //        }
                        //    }
                        //    if (msk_dtpTTR_datesent2.Text != "")
                        //    {
                        //        if (Convert.ToDateTime(dateSend.Text).CompareTo(Convert.ToDateTime(msk_dtpTTR_datesent2.Text)) <= 0)
                        //        {
                        //            MessageBox.Show(currentStageName + " Send Date (First Evaluation) cannot be less than or equal to " + currentStageName + " Send Date (Second Evaluation)");
                        //            dateSend.Focus();
                        //            isResult = false;
                        //        }
                        //    }
                        //    if (msk_dtpTTR_daterec2.Text != "")
                        //    {
                        //        if (Convert.ToDateTime(dateSend.Text).CompareTo(Convert.ToDateTime(msk_dtpTTR_daterec2.Text)) <= 0)
                        //        {
                        //            MessageBox.Show(currentStageName + " Send Date (First Evaluation) cannot be less than or equal to " + currentStageName + " Received Date (Second Evaluation)");
                        //            dateSend.Focus();
                        //            isResult = false;
                        //        }
                        //    }
                        //    else
                        //    {
                        //        dateSend.Text = Convert.ToDateTime(dateSend.Text).ToString("dd/MMM/yyyy");
                        //        isResult = true;
                        //    }
                        //}
                        //else if (currentStageName.Equals("Financial Tender Review"))
                        //{
                        //    if (msk_dtpFTR_daterec1.Text != "")
                        //    {
                        //        if (Convert.ToDateTime(dateSend.Text).CompareTo(Convert.ToDateTime(msk_dtpFTR_daterec1.Text)) < 0)
                        //        {
                        //            MessageBox.Show(currentStageName + " Send Date (First Evaluation) cannot be less than or equal to " + currentStageName + " Received Date (First Evaluation)");
                        //            dateSend.Focus();
                        //            isResult = false;
                        //        }
                        //    }
                        //    if (msk_dtpFTR_datesent2.Text != "")
                        //    {
                        //        if (Convert.ToDateTime(dateSend.Text).CompareTo(Convert.ToDateTime(msk_dtpFTR_datesent2.Text)) <= 0)
                        //        {
                        //            MessageBox.Show(currentStageName + " Send Date (First Evaluation) cannot be less than or equal to " + currentStageName + " Send Date (Second Evaluation)");
                        //            dateSend.Focus();
                        //            isResult = false;
                        //        }
                        //    }
                        //    if (msk_dtpFTR_daterec2.Text != "")
                        //    {
                        //        if (Convert.ToDateTime(dateSend.Text).CompareTo(Convert.ToDateTime(msk_dtpFTR_daterec2.Text)) <= 0)
                        //        {
                        //            MessageBox.Show(currentStageName + " Send Date (First Evaluation) cannot be less than or equal to " + currentStageName + " Received Date (Second Evaluation)");
                        //            dateSend.Focus();
                        //            isResult = false;
                        //        }
                        //    }
                        //    else
                        //    {
                        //        dateSend.Text = Convert.ToDateTime(dateSend.Text).ToString("dd/MMM/yyyy");
                        //        isResult = true;
                        //    }
                        //}
                    }
                    else
                    {
                        if (dateSend.Text != "" && receivedDate == null)
                        {
                            MessageBox.Show(currentStageName + " Send Date (First Evaluation) cannot have value when " + prevStageName + " Received Date (First Evaluation) is blank");
                            dateSend.Focus();
                            isResult = false;
                            return isResult;
                        }
                    }

                }
            }
            else
            {
                if (isSecond == false && dateSend.Text != "")
                {
                    MessageBox.Show(prevStageName + " Received Date (Second Evaluation) is blank cannot enter date in " + currentStageName + " Review Send date (First Evaluation)");
                    dateSend.Focus();
                    isResult = false;
                }
                else if (isFirst == false && dateSend.Text != "")
                {
                    MessageBox.Show(prevStageName + " Received Date (First Evaluation) is blank cannot enter date in " + currentStageName + " Review Send date (First Evaluation)");
                    dateSend.Focus();
                    isResult = false;
                }
            }
            return isResult;
        }

        //private bool TechTdrRevDateSendSecondEvalValidation()
        //{
        //    bool isResult = true;
        //    //Modified by Varun on 13/02/2016 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
        //    if (msk_dtpTTR_datesent1.Text.Trim() != "" && msk_dtpTTR_daterec1.Text.Trim() != "")
        //    {
        //        if (Convert.ToDateTime(dtpTTR_datesent2.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTTR_datesent1.Text)) <= 0)
        //        {
        //            MessageBox.Show("Technical Tender Review Send Date (Second Evaluation) cannot be less than or equal to Technical Tender Review Send Date (First Evaluation)");
        //            msk_dtpTTR_daterec1.Focus();
        //            isResult = false;
        //        }
        //        if (Convert.ToDateTime(dtpTTR_datesent2.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTTR_daterec1.Text)) <= 0)
        //        {
        //            MessageBox.Show("Technical Tender Review Send Date (Second Evaluation) cannot be less than or equal to Technical Tender Review Received Date (First Evaluation)");
        //            msk_dtpTTR_daterec1.Focus();
        //            isResult = false;
        //        }
        //        else
        //        {
        //            msk_dtpTTR_datesent2.Text = Convert.ToDateTime(dtpTTR_datesent2.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
        //        }
        //    }
        //    else
        //    {
        //        MessageBox.Show("Cannot enter Technical Tender Review Send Date (Second Evaluation) when there are no date in Technical Tender Review Send and Received Date (First Evaluation)");
        //        msk_dtpTTR_datesent1.Focus();
        //        isResult = false;
        //    }

        //    //if (dtpTTR_daterec1.Text.Trim() != "")
        //    //{
        //    //    if (Convert.ToDateTime(dtpTTR_datesent2.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(dtpTTR_daterec1.Text)) < 0)
        //    //    {
        //    //        MessageBox.Show("Technical Tender Review Send Date (Second Evaluation) cannot be less than Technical Tender Review Received Date (First Evaluation)");
        //    //        msk_dtpTTR_daterec1.Focus();
        //    //        isResult = false;
        //    //    }
        //    //}
        //    //else
        //    //{
        //    //    isResult = true;
        //    //}
        //    return isResult;
        //}

        private bool TechTdrRevDateSentFirstEvalValidation()
        {
            bool isResult = true;
            //Modified by Varun on 13/02/2016 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            if (msk_dtpTE_daterec1.Text.Trim() != "")
            {
                //if (Convert.ToDateTime(dtpTTR_daterec1.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) <= 0)
                //{
                //    MessageBox.Show("Technical Tender Review Date Sent (First Evaluation) cannot be less than or equal to Technical Evaluation Date Received (First Evaluation)");
                //    msk_dtpTTR_daterec1.Focus();
                //    isResult = false;
                //}
            }
            else
            {
                isResult = true;
            }
            return isResult;
        }

        private bool FinEvalDateRecFirstEvalValidation()
        {
            bool isResult = true;
            //Modified by Varun on 13/02/2016 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            if (msk_dtpFE_datesentfin1.Text.Trim() != "")
            {
                if (Convert.ToDateTime(dtpFE_daterecFin1.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFE_datesentfin1.Text)) < 0)
                {
                    MessageBox.Show("Financial Evaluation Date Received (First Evaluation) cannot be less than Financial Evaluation Date Send (First Evaluation)");
                    msk_dtpFE_daterecFin1.Focus();
                    isResult = false;
                }
            }
            else
            {
                isResult = true;
            }
            return isResult;
        }
        

        private bool FinEvalDateSendSecondEvalValidation()
        {
            bool isResult = true;
            //Modified by Varun on 13/02/2016 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            if (msk_dtpTE_daterec2.Text.Trim() != "")
            {
                if (Convert.ToDateTime(dtpFE_datesentfin2.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec2.Text)) < 0)
                {
                    MessageBox.Show("Financial Evaluation Date Send (Second Evaluation) cannot be less than Technical Evaluation Date Received (Second Evaluation)");
                    msk_dtpFE_datesentfin2.Focus();
                    isResult = false;
                }
            }
            else
            {
                isResult = true;
            }
            return isResult;
        }
         

        private bool FinEvalDateSendFirstEvalValidation()
        {
            bool isResult = true;
            //Modified by Varun on 13/02/2016 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            if (msk_dtpTE_datesent1.Text.Trim() != "")
            {
                if (Convert.ToDateTime(dtpFE_datesentfin1.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_datesent1.Text)) < 0)
                {
                    MessageBox.Show("Financial Evaluation Date Send (First Evaluation) cannot be less than Technical Evaluation Date Send (First Evaluation)");
                    msk_dtpFE_datesentfin1.Focus();
                    isResult = false;
                }
            }
            else
            {
                isResult = true;
            }
            return isResult;
        }
        


        //private bool DateSendFirstEval(bool isSubmit)
        //{
        //    bool isResult = true;
        //    if (msk_dtpTTR_daterec2.Text != "")
        //    {
        //        if (Convert.ToDateTime(dtpFE_datesentfin1.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTTR_daterec2.Text)) <= 0)
        //        {
        //            MessageBox.Show("Financial Evaluation Date Send (First Evaluation) cannot be less than Technical Tender Review Date Received (Second Evaluation)");
        //            msk_dtpFE_datesentfin1.Focus();
        //            isResult = false;
        //        }
        //        isResult = DateSendFirstEvalValidation(dtpFE_datesentfin1, msk_dtpFE_datesentfin1, msk_dtpTTR_daterec2, "Financial Evaluation", isSubmit);
        //    }
        //    else if (msk_dtpTTR_daterec1.Text != "")
        //    {
        //        if (Convert.ToDateTime(dtpFE_datesentfin1.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTTR_daterec2.Text)) <= 0)
        //        {
        //            MessageBox.Show("Financial Evaluation Date Send (First Evaluation) cannot be less than Technical Tender Review Date Received (First Evaluation)");
        //            msk_dtpFE_datesentfin1.Focus();
        //            isResult = false;
        //        }
        //        isResult = DateSendFirstEvalValidation(dtpFE_datesentfin1, msk_dtpFE_datesentfin1, msk_dtpTTR_daterec1, "Financial Evaluation", isSubmit);
        //    }
        //    else if(!isSubmit)
        //    {
        //        MessageBox.Show("Cannot enter Financial Evaluation Send Date (First Evaluation) when there are no date in Technical Tender Review Received Date (First Evaluation)");
        //        msk_dtpFE_datesentfin1.Focus();
        //        isResult = false;
        //        //DateSendFirstEvalValidation(dtpFE_datesentfin1, msk_dtpFE_datesentfin1, null, "Financial Evaluation");
        //    }
        //    return isResult;
        //}

        private bool DateSendFinEvalFirstEval(bool isSubmit, MaskedTextBox dateTTRRec1, MaskedTextBox dateTTRRec2, DateTimePicker dateFinEvalSend1, MaskedTextBox setDateFinEvalSend)
        {
            bool isResult = true;
            if (isSubmit == false)
            {
                if (dateTTRRec2.Text != "")
                {
                    isResult = CheckPreviousStageDates(dateFinEvalSend1, setDateFinEvalSend, msk_dtpFE_daterecFin1, "Financial Evaluation", "Send", "Second", isSubmit);
                    if (isResult == false)
                    {
                        return isResult;
                    }


                    if (Convert.ToDateTime(dateFinEvalSend1.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(dateTTRRec2.Text)) <= 0)
                    {
                        MessageBox.Show("Financial Evaluation Send Date (Second Evaluation) cannot be less than Technical Tender Review Received Date (Second Evaluation)");
                        setDateFinEvalSend.Focus();
                        isResult = false;
                        return isResult;
                    }


                    isResult = DateSendFirstEvalValidation(dateFinEvalSend1, setDateFinEvalSend, msk_dtpFE_daterecFin1, "Financial Evaluation", isSubmit);
                }
                else if (dateTTRRec1.Text != "")
                {
                    isResult = CheckPreviousStageDates(dateFinEvalSend1, setDateFinEvalSend, msk_dtpFE_daterecFin1, "Financial Evaluation", "Send", "Second", isSubmit);
                    if (isResult == false)
                    {
                        return isResult;
                    }

                    if (Convert.ToDateTime(dateFinEvalSend1.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(dateTTRRec1.Text)) <= 0)
                    {
                        MessageBox.Show("Financial Evaluation Send Date (Second Evaluation) cannot be less than Technical Tender Review Received Date (First Evaluation)");
                        setDateFinEvalSend.Focus();
                        isResult = false;
                        return isResult;
                    }

                    isResult = DateSendFirstEvalValidation(dateFinEvalSend1, setDateFinEvalSend, msk_dtpFE_daterecFin1, "Financial Evaluation", isSubmit);
                }
                else
                {
                    MessageBox.Show("Cannot enter Financial Evaluation Send Date (Second Evaluation) when there are no date in Technical Tender Review Received Date (First Evaluation)");
                    setDateFinEvalSend.Focus();
                    isResult = false;
                    return isResult;
                }
            }
            else
            {
                //if (msk_dtpFE_datesentfin1.Text.Trim() != "" && msk_dtpFE_daterecFin1.Text.Trim() == "")
                //{
                //    MessageBox.Show("Financial Evaluation Received Date (First Evaluation) cannot be blank when there is a date in Financial Evaluation Send Date (First Evaluation)");
                //    msk_dtpFE_daterecFin1.Focus();
                //    isResult = false;
                //    return isResult;
                //}
                if (dateTTRRec2.Text != "")
                {
                    isResult = CheckPreviousStageDates(dateFinEvalSend1, setDateFinEvalSend, msk_dtpFE_daterecFin1, "Financial Evaluation", "Send", "Second", isSubmit);
                    if (isResult == false)
                    {
                        return isResult;
                    }
                    //if (msk_dtpEA_apprDate.Text != "")
                    //{
                    //    if (dateTTRRec2.Text.Equals(""))
                    //    {
                    //        MessageBox.Show("Technical Tender Review Received Date (Second Evaluation) cannot be blank when there is a date in Tender Award Approval Date");
                    //        dateTTRRec1.Focus();
                    //        isResult = false;
                    //        return isResult;
                    //    }                        
                    //}

                    if (!setDateFinEvalSend.Text.Equals("") && !dateTTRRec2.Text.Equals(""))
                    {
                        if (Convert.ToDateTime(setDateFinEvalSend.Text).CompareTo(Convert.ToDateTime(dateTTRRec2.Text)) <= 0)
                        {
                            MessageBox.Show("Financial Evaluation Send Date (Second Evaluation) cannot be less than Technical Tender Review Received Date (Second Evaluation)");
                            setDateFinEvalSend.Focus();
                            isResult = false;
                            return isResult;
                        }
                    }
                    isResult = DateSendFirstEvalValidation(dateFinEvalSend1, setDateFinEvalSend, msk_dtpFE_daterecFin1, "Financial Evaluation", isSubmit);
                }
                else if (dateTTRRec1.Text != "")
                {
                    isResult = CheckPreviousStageDates(dateFinEvalSend1, setDateFinEvalSend, msk_dtpFE_daterecFin1, "Financial Evaluation", "Send", "Second", isSubmit);
                    if (isResult == false)
                    {
                        return isResult;
                    }
                    if (msk_dtpEA_apprDate.Text != "")
                    {
                        if (dateTTRRec1.Text.Equals(""))
                        {
                            MessageBox.Show("Technical Tender Review Received Date (First Evaluation) cannot be blank when there is a date in Tender Award Approval Date");
                            dateTTRRec1.Focus();
                            isResult = false;
                            return isResult;
                        }
                    }

                    if (!setDateFinEvalSend.Text.Equals("") && !dateTTRRec1.Text.Equals(""))
                    {
                        if (Convert.ToDateTime(setDateFinEvalSend.Text).CompareTo(Convert.ToDateTime(dateTTRRec1.Text)) <= 0)
                        {
                            MessageBox.Show("Financial Evaluation Send Date (Second Evaluation) cannot be less than Technical Tender Review Received Date (First Evaluation)");
                            setDateFinEvalSend.Focus();
                            isResult = false;
                            return isResult;
                        }
                    }

                    isResult = DateSendFirstEvalValidation(dateFinEvalSend1, setDateFinEvalSend, msk_dtpFE_daterecFin1, "Financial Evaluation", isSubmit);
                }
                else
                {
                    MessageBox.Show("Cannot enter Financial Evaluation Send Date (Second Evaluation) when there are no date in Technical Tender Review Received Date (First Evaluation)");
                    setDateFinEvalSend.Focus();
                    isResult = false;
                    return isResult;
                }
            }

            return isResult;
        }


        private void dtpEA_datesentfin_ValueChanged(object sender, EventArgs e)
        {
            //msk_dtpFE_datesentfin1.Text = "";
            //DateSendFinEvalFirstEval(false, msk_dtpTTR_daterec1, msk_dtpTTR_daterec2, dtpFE_datesentfin1, msk_dtpFE_datesentfin1);
            //DateSendFirstEval(false);
            if (FinEvalDateSendFirstEvalValidation())
            {

                //Modified by Varun on 13/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             

                msk_dtpFE_datesentfin1.Text = Convert.ToDateTime(dtpFE_datesentfin1.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
            }
             
        }

        private bool FinEvalReceivedDate(bool isSubmit)
        {
            bool isFirst = false;
            bool isSecond = false;
            bool isResult = true;
            if (CheckBlankSendDatesOfTechnicalEvalStage()) // && CheckBlankSendDatesOfTechnicalTenderReviewStage())
            {                
                if (msk_dtpFE_datesentfin1.Text!="" && !dtpFE_daterecFin1.Value.ToString().Contains("1900") && dtpFE_daterecFin1.Value.ToString().Trim() != "")
                {
                    msk_dtpFE_daterecFin1.Text = Convert.ToDateTime(dtpFE_daterecFin1.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
                }
            }
            else
            {
                return isResult = false; 
            }
            if (isSubmit == false)
            {
                //if (msk_dtpTTR_daterec2.Text != "")
                //{
                //    isResult = CheckPreviousStageDates(dtpFE_daterecFin1, msk_dtpFE_datesentfin1, msk_dtpFE_daterecFin1, "Financial Evaluation", "Received", "First", isSubmit);
                //    if (isResult == false)
                //    {
                //        return isResult;
                //    }
                //    if (msk_dtpTTR_daterec2.Text != "")
                //    {
                //        if (Convert.ToDateTime(dtpFE_daterecFin1.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTTR_daterec2.Text)) < 0)
                //        {
                //            MessageBox.Show("Financial Evaluation Received Date (First Evaluation) cannot be less than Technical Tender Review Received Date (Second Evaluation)");
                //            dtpFE_daterecFin1.Focus();
                //            isResult = false;
                //            isSecond = true;
                //            return isResult;
                //        }
                //        else
                //        {
                //            isResult = DateReceivedFirstEvalValidation(dtpFE_daterecFin1, msk_dtpFE_datesentfin1, msk_dtpFE_daterecFin1, "Financial Evaluation", isSubmit);
                //        }
                //    }
                //}
                //else if (msk_dtpTTR_daterec1.Text != "")
                //{
                //    isResult = CheckPreviousStageDates(dtpFE_daterecFin1, msk_dtpFE_datesentfin1, msk_dtpFE_daterecFin1, "Financial Evaluation", "Received", "First", isSubmit);
                //    if (isResult == false)
                //    {
                //        return isResult;
                //    }
                //    if (Convert.ToDateTime(dtpFE_daterecFin1.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTTR_daterec1.Text)) < 0)
                //    {
                //        MessageBox.Show("Financial Evaluation Received Date (First Evaluation) cannot be less than Technical Tender Review Received Date (First Evaluation)");
                //        dtpFE_daterecFin1.Focus();
                //        isResult = false;
                //        isFirst = true;
                //        return isResult;
                //    }
                //    else
                //    {
                //        isResult = DateReceivedFirstEvalValidation(dtpFE_daterecFin1, msk_dtpFE_datesentfin1, msk_dtpFE_daterecFin1, "Financial Evaluation", isSubmit);
                //    }
                //}
                //else
                //{
                //    if (isSecond == false)
                //    {
                //        MessageBox.Show("Cannot enter Financial Evaluation Received Date (First Evaluation) when there are no date in Technical Tender Review Received Date (Second Evaluation)");
                //        msk_dtpFE_daterecFin1.Focus();
                //        isResult = false;
                //        return isResult;
                //    }
                //    else if (isFirst == false)
                //    {
                //        MessageBox.Show("Cannot enter Financial Evaluation Received Date (First Evaluation) when there are no date in Technical Tender Review Received Date (First Evaluation)");
                //        msk_dtpFE_daterecFin1.Focus();
                //        isResult = false;
                //        return isResult;
                //    }
                //    //DateSendFirstEvalValidation(dtpFE_datesentfin1, msk_dtpFE_datesentfin1, null, "Financial Evaluation");
                //}
            }
            else
            {
                //if (msk_dtpTTR_daterec2.Text != "")
                //{
                //    isResult = CheckPreviousStageDates(dtpFE_daterecFin1, msk_dtpFE_datesentfin1, msk_dtpFE_daterecFin1, "Financial Evaluation", "Received", "First", isSubmit);
                //    if (isResult == false)
                //    {
                //        return isResult;
                //    }
                //    if (msk_dtpFE_daterecFin1.Text != "")
                //    {
                //        if (Convert.ToDateTime(msk_dtpFE_daterecFin1.Text).CompareTo(Convert.ToDateTime(msk_dtpTTR_daterec2.Text)) <= 0)
                //        {
                //            MessageBox.Show("Financial Evaluation Received Date (First Evaluation) cannot be less than Technical Tender Review Received Date (Second Evaluation)");
                //            msk_dtpFE_daterecFin1.Focus();
                //            isResult = false;
                //            return isResult;
                //        }
                //        else
                //        {
                //            isResult = DateSendFirstEvalValidation(dtpFE_daterecFin1, msk_dtpFE_datesentfin1, msk_dtpFE_daterecFin1, "Financial Evaluation", isSubmit);
                //        }
                //    }
                //}
                //else if (msk_dtpTTR_daterec1.Text != "")
                //{
                //    isResult = CheckPreviousStageDates(dtpFE_daterecFin1, msk_dtpFE_datesentfin1, msk_dtpFE_daterecFin1, "Financial Evaluation", "Received", "First", isSubmit);
                //    if (isResult == false)
                //    {
                //        return isResult;
                //    }
                //    if (msk_dtpFE_daterecFin1.Text != "")
                //    {
                //        if (Convert.ToDateTime(msk_dtpFE_daterecFin1.Text).CompareTo(Convert.ToDateTime(msk_dtpTTR_daterec1.Text)) <= 0)
                //        {
                //            MessageBox.Show("Financial Evaluation Received Date (First Evaluation) cannot be less than Technical Tender Review Received Date (First Evaluation)");
                //            msk_dtpFE_daterecFin1.Focus();
                //            isResult = false;
                //            return isResult;
                //        }
                //        else
                //        {
                //            isResult = DateSendFirstEvalValidation(dtpFE_daterecFin1, msk_dtpFE_datesentfin1, msk_dtpFE_daterecFin1, "Financial Evaluation", isSubmit);
                //        }
                //    }
                //}
                //else
                //{
                //    MessageBox.Show("Cannot enter Financial Evaluation Received Date (First Evaluation) when there are no date in Technical Tender Review Received Date (First Evaluation)");
                //    msk_dtpFE_daterecFin1.Focus();
                //    isResult = false;
                //    return isResult;
                //}
            }

            return isResult;
        }


        private void dtpEA_daterecFin_ValueChanged(object sender, EventArgs e)
        {
            //"Financial Evaluation"
            DateReceivedFirstEvalValidation(dtpTE_daterec1, msk_dtpTE_datesent1, msk_dtpTE_daterec1, "Technical Evaluation",false);
            //msk_dtpFE_daterecFin1.Text = "";
            FinEvalReceivedDate(false);

        }
        private void dtpEA_apprDate_ValueChanged(object sender, EventArgs e)
        {
            msk_dtpEA_apprDate.Focus();
            msk_dtpEA_apprDate.Text = "";
            //Modified by Varun on 13/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            msk_dtpEA_apprDate.Text = Convert.ToDateTime(dtpEA_apprDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
            ValidateTenderAwardApprovalDate(dtpEA_apprDate, msk_dtpEA_apprDate, false);
        }


        private void msk_dtpTV_FEdate_Leave(object sender, EventArgs e)
        {
            // msk_dtpTV_FEdate.Text = dtpTV_FEdate.Value.ToString("dd/MMM/yyyy");
            //if (msk_dtpTV_FEdate.Text != "")   

            if (msk_dtpTV_FEdate.Text != "")
            {
                if (ValidateDate(msk_dtpTV_FEdate) == false)
                {
                    msk_dtpTV_FEdate.Text = "";
                    msk_dtpTV_FEdate.Focus();
                    return;
                }
                // Modified on jan 28th by Sreedhar //Modified by Varun on 04 Feb 2014 based on Adonis req.
                if (msk_dtpTV_SEdate.Text == "" && msk_dtpTV_OrgDate.Text != "" && isCpContractorSign == false)
                {
                    if (Convert.ToDateTime(msk_dtpTV_OrgDate.Text) > Convert.ToDateTime(msk_dtpTV_FEdate.Text))
                    {
                        MessageBox.Show("Extension Date should be greater than Original Date");
                        msk_dtpTV_FEdate.Text = "";
                        msk_dtpTV_FEdate.Focus();
                        return;
                    }

                    if (msk_dtpTV_FEdate.Text != "")
                    {
                        int iDays = (Convert.ToDateTime(msk_dtpTV_FEdate.Text) - System.DateTime.Now.Date).Days;
                        txtTV_exipre.Text = iDays.ToString();
                    }
                }
            }
            //Modified by Varun on 04 Feb 2014 based on Adonis req.
            if (msk_dtpTV_FEdate.Text != "" && isCpContractorSign == false)
            {
                int iDays = (Convert.ToDateTime(msk_dtpTV_FEdate.Text) - System.DateTime.Now.Date).Days;
                txtTV_exipre.Text = iDays.ToString();
            }
            //Modified by Varun on 04 Feb 2014 based on Adonis req.
            if (txtTV_exipre.Text != "" && isCpContractorSign == false)
                clsForTS.UpdateTV_FirstExtension(msk_dtpTV_FEdate.Text, _projID, Convert.ToInt16(txtTV_exipre.Text));

        }
        private void msk_dtpTBV_FEdate_Leave(object sender, EventArgs e)
        {

            // if (msk_dtpTBV_FEdate.Text != "")
            //UpdateTBV_FirstExtension(msk_dtpTBV_FEdate.Text);

            if (msk_dtpTBV_FEdate.Text != "")
            {
                if (ValidateDate(msk_dtpTBV_FEdate) == false)
                {
                    msk_dtpTBV_FEdate.Text = "";
                    msk_dtpTBV_FEdate.Focus();
                    return;
                }
            }

            //Modified by Varun on 04 Feb 2014 based on Adonis req.

            if (msk_dtpTBV_FEdate.Text != "" && isCpContractorSign == false)

                if (msk_dtpTBV_SEdate.Text == "" & msk_dtpTBV_OrgDate.Text != "")
                {
                    if (Convert.ToDateTime(msk_dtpTBV_OrgDate.Text) > Convert.ToDateTime(msk_dtpTBV_FEdate.Text))
                    {
                        MessageBox.Show("Extension Date Should be greater than Original Date");
                        msk_dtpTBV_FEdate.Text = "";
                        msk_dtpTBV_FEdate.Focus();
                        return;
                    }
                    if (msk_dtpTBV_FEdate.Text != "")
                    {
                        int iDays = (Convert.ToDateTime(msk_dtpTBV_FEdate.Text) - System.DateTime.Now.Date).Days;
                        txtTBV_exipre.Text = iDays.ToString();
                    }
                }
            //Modified by Varun on 04 Feb 2014 based on Adonis req.
            if (msk_dtpTBV_SEdate.Text == "" && isCpContractorSign == false)
            {
                if (msk_dtpTBV_FEdate.Text != "")
                {
                    int iDays = (Convert.ToDateTime(msk_dtpTBV_FEdate.Text) - System.DateTime.Now.Date).Days;
                    txtTBV_exipre.Text = iDays.ToString();
                }
            }

            if (txtTBV_exipre.Text != "" && isCpContractorSign == false)
                clsForTS.UpdateTBV_FirstExtension(msk_dtpTBV_FEdate.Text, _projID, Convert.ToInt16(txtTBV_exipre.Text));

        }
        private void msk_dtpTV_SEdate_Leave(object sender, EventArgs e)
        {
            //if (msk_dtpTV_FEdate.Text != "")
            //  UpdateTV_LastExtension(msk_dtpTV_SEdate.Text);

            if (msk_dtpTV_SEdate.Text != "")
            {
                if (ValidateDate(msk_dtpTV_SEdate) == false)
                {
                    msk_dtpTV_SEdate.Text = "";
                    msk_dtpTV_SEdate.Focus();
                    return;
                }
            }
            //Modified by Varun on 04 Feb 2014 based on Adonis req.
            if (msk_dtpTV_FEdate.Text != "" && isCpContractorSign == false)
            {
                if (msk_dtpTV_SEdate.Text != "")
                {
                    if (Convert.ToDateTime(msk_dtpTV_FEdate.Text) > Convert.ToDateTime(msk_dtpTV_SEdate.Text))
                    {
                        MessageBox.Show("Extension Date Should be greater than Original Date");
                        msk_dtpTV_SEdate.Text = "";
                        msk_dtpTV_SEdate.Focus();
                        return;
                    }
                    //if (msk_dtpTBV_FEdate.Text != "")
                    //{
                    int iDays = (Convert.ToDateTime(msk_dtpTV_SEdate.Text) - System.DateTime.Now.Date).Days;
                    txtTV_exipre.Text = iDays.ToString();
                    //}
                }
            }
            else
            {
                MessageBox.Show("First Extension date should not be null", "Null Value", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                msk_dtpTV_SEdate.Text = "";
                msk_dtpTV_FEdate.Focus();
                return;
            }
            //Modified by Varun on 04 Feb 2014 based on Adonis req.
            if (msk_dtpTV_SEdate.Text != "" && isCpContractorSign == false)
            {
                int iDays = (Convert.ToDateTime(msk_dtpTV_SEdate.Text) - System.DateTime.Now.Date).Days;
                txtTV_exipre.Text = iDays.ToString();
            }
            //Modified by Varun on 04 Feb 2014 based on Adonis req.
            if (txtTV_exipre.Text != "" && isCpContractorSign == false)
                clsForTS.UpdateTV_LastExtension(msk_dtpTV_SEdate.Text, _projID, Convert.ToInt16(txtTV_exipre.Text));

        }
        private void msk_dtpTBV_SEdate_Leave(object sender, EventArgs e)
        {
            //if (msk_dtpTBV_SEdate.Text != "")
            //UpdateTBV_LastExtension(msk_dtpTBV_SEdate.Text);

            if (msk_dtpTBV_SEdate.Text != "")
            {
                if (ValidateDate(msk_dtpTBV_SEdate) == false)
                {
                    msk_dtpTBV_SEdate.Text = "";
                    msk_dtpTBV_SEdate.Focus();
                    return;
                }
            }

            //Modified by Varun on 04 Feb 2014 based on Adonis req.            
            if (msk_dtpTBV_FEdate.Text != "" && isCpContractorSign == false)
            {
                if (msk_dtpTBV_SEdate.Text != "")
                {
                    if (Convert.ToDateTime(msk_dtpTBV_FEdate.Text) > Convert.ToDateTime(msk_dtpTBV_SEdate.Text))
                    {
                        MessageBox.Show("Extension Date Should be greater than Original Date");
                        msk_dtpTBV_SEdate.Text = "";
                        msk_dtpTBV_SEdate.Focus();
                        return;
                    }
                    if (msk_dtpTBV_SEdate.Text != "")
                    {
                        int iDays = (Convert.ToDateTime(msk_dtpTBV_SEdate.Text) - System.DateTime.Now.Date).Days;
                        txtTBV_exipre.Text = iDays.ToString();
                    }
                }
            }
            else
            {
                msk_dtpTBV_SEdate.Text = "";
            }
            //Modified by Varun on 04 Feb 2014 based on Adonis req.            
            if (msk_dtpTBV_SEdate.Text != "" && isCpContractorSign == false)
            {
                int iDays = (Convert.ToDateTime(msk_dtpTBV_SEdate.Text) - System.DateTime.Now.Date).Days;
                txtTBV_exipre.Text = iDays.ToString();
            }
            //Modified by Varun on 04 Feb 2014 based on Adonis req.            
            if (txtTBV_exipre.Text != "" && isCpContractorSign == false)
                clsForTS.UpdateTBV_LastExtension(msk_dtpTBV_SEdate.Text, _projID, Convert.ToInt16(txtTBV_exipre.Text));

        }
        private void msk_dtpEA_reqdate_Leave(object sender, EventArgs e)
        {
            if (msk_dtpEA_reqdate.Text.Trim() != "")
            {
                if (ValidateDate(msk_dtpEA_reqdate) == true)
                {
                    if (isCpContractorSign == false)
                    {
                        DateTime dt_dtpEA_reqdate = Convert.ToDateTime(msk_dtpEA_reqdate.Text, CultureInfo.InvariantCulture);
                        msk_dtpTV_OrgDate.Text = dt_dtpEA_reqdate.AddDays(90).ToString("dd/MMM/yyyy");
                        msk_dtpTBV_OrgDate.Text = dt_dtpEA_reqdate.AddDays(120).ToString("dd/MMM/yyyy");

                        // Added by Varun on 5 Feb 2014 for Update tenderValidityDate and tenderBondValidityDate
                        if (msk_dtpTV_OrgDate.Text != "")
                            Update_tenderValidityDate(tndrDate_ID);
                        if (msk_dtpTBV_OrgDate.Text != "")
                            Update_tender_BondValidityDate(tndrDate_ID);

                        TE_Validate(tndrDate_ID);
                        if (msk_dtpEA_reqdate.Text != "")
                        {
                            if (msk_dtpEA_stage1.Text == "")
                            {
                                msk_dtpEA_reqdate.Text = "";
                                msk_dtpEA_reqdate.Focus();
                                MessageBox.Show("Tender Closing Date in Tender Stage is not updated. Please Update this prior to this field.");
                                return;
                            }
                            //Modified by Varun on 04 Feb 2014 based on Adonis req.  
                            if (msk_dtpEA_stage1.Text != "" & msk_dtpEA_reqdate.Text != "")
                            {
                                if (Convert.ToDateTime(msk_dtpEA_reqdate.Text) < Convert.ToDateTime(msk_dtpEA_stage1.Text))
                                {
                                    MessageBox.Show("Date entered is earlier than Tender Closing Date. Please check and revise your entry.");
                                    msk_dtpEA_reqdate.Text = "";
                                    //msk_dtpEA_reqdate.Focus();
                                    return;
                                }
                            }
                        }
                    }
                }
                 
            }
             
        }
        private void msk_dtpTV_FEdate_TextChanged(object sender, EventArgs e)
        {
            //UpdateTV_FirstExtension(msk_dtpTV_FEdate.Text);
        }
        private void msk_dtpEA_reqdate_TextChanged(object sender, EventArgs e)
        {
            Control ctrl = sender as Control;
            if (ValidateDate(ctrl) == true)
            {
                //Modified by Varun on 04 Feb 2014 based on Adonis req.  
                if (msk_dtpEA_reqdate.Text != "")
                {
                    if (isCpContractorSign == false)
                    {
                        //msk_dtpEA_reqdate.Text = dtpEA_reqdate.Value.ToString("dd/MMM/yyyy");
                        DateTime dt_dtpEA_reqdate = Convert.ToDateTime(msk_dtpEA_reqdate.Text, CultureInfo.InvariantCulture);

                        msk_dtpTV_OrgDate.Text = dt_dtpEA_reqdate.AddDays(90).ToString("dd/MMM/yyyy");

                        //if (msk_dtpEA_closeDate.Text != "")
                        //{
                        //    DateTime dt_dtpEA_Modifydate = Convert.ToDateTime(msk_dtpEA_closeDate.Text);
                        //    msk_dtpTBV_OrgDate.Text = dt_dtpEA_Modifydate.AddDays(120).ToString("dd/MMM/yyyy");
                        //}
                        //else if (msk_dtpEA_stage1.Text != "")
                        //{
                        //    DateTime dt_dtpEA_stage1 = Convert.ToDateTime(msk_dtpEA_stage1.Text);
                        //    msk_dtpTBV_OrgDate.Text = dt_dtpEA_stage1.AddDays(120).ToString("dd/MMM/yyyy");
                        //}

                        int iDays = (Convert.ToDateTime(msk_dtpTV_OrgDate.Text) - System.DateTime.Now.Date).Days;
                        //int iDaysBond = (Convert.ToDateTime(msk_dtpTBV_OrgDate.Text) - System.DateTime.Now.Date).Days;
                        txtTV_exipre.Text = iDays.ToString();
                        //txtTBV_exipre.Text = iDaysBond.ToString();
                    }
                }
                else
                {

                    msk_dtpTV_OrgDate.Text = "";
                    msk_dtpTBV_OrgDate.Text = "";
                }
            }

        }
        private void btnPTD_Click(object sender, EventArgs e)
        {
            if (_profileName!="VIEW ALL")
            {
                if (chkUpdateStatus == false)
                {
                    if (msk_dtpRecievedOn.Text == "")
                    {
                        MessageBox.Show("Please select Received On Date");
                        msk_dtpRecievedOn.Focus();
                        return;
                    }
                    else if (cmbPurpose.Text == "")
                    {
                        MessageBox.Show("Please select Purpose");
                        cmbPurpose.Focus();
                        return;
                    }
                    else if (cmbAssignedQs.Text == "")
                    {
                        MessageBox.Show("Please select AssignedQs");
                        cmbAssignedQs.Focus();
                        return;
                    }
                    else if (cmbQsWorkingStatus.Text == "")
                    {
                        MessageBox.Show("Please select Qs Working Status");
                        cmbQsWorkingStatus.Focus();
                        return;
                    }
                    //else if (msk_dtpReview.Text == "")
                    //{
                    //    MessageBox.Show("Please select Sent to department for review with comments");
                    //    msk_dtpReview.Focus();
                    //    return;
                    //}
                    else if (cmbTenderDocStatus.Text == "")
                    {
                        MessageBox.Show("Please select Tender Document Current Status");
                        cmbTenderDocStatus.Focus();
                        return;
                    }
                    else if (msk_dtpFrwdDept.Text == "")
                    {
                        MessageBox.Show("Please select Forward To Department");
                        msk_dtpFrwdDept.Focus();
                        return;
                    }

                    int dateID = MaxDateID();
                    InsertTenderPreparationInfo(dateID);

                    if (cmbQsWorkingStatus.Text == "Completed" & cmbTenderDocStatus.Text == "Approved" & msk_dtpFrwdDept.Text != "")
                    {

                        // Update the Stage and Status from PTD to TS and Tendering
                        clsForPTD.UpdateFromTPtoTS(_projID);

                        //dalObj.populateCmbBox("Select [Tender Status],[Tender Statsus Short Name] From [Status of Tender] WHERE [Tender Status] != 'Cancelled' and [Tender Status] != 'Re-Tender' ", cmbTenderStatus);
                        cmbTenderStatus.SelectedIndex = 1;
                        // added by Varun on 11/05/2015
                        FillProjectInfo();
                    }

                    GridViewRefresh_PTD();
                    msk_dtpRecievedOn.Text = "";
                    msk_dtpReview.Text = "";
                    msk_dtpFrwdDept.Text = "";

                    cmbAssignedQs.SelectedIndex = -1;
                    cmbPurpose.SelectedIndex = -1;
                    cmbQsWorkingStatus.SelectedIndex = -1;
                    cmbTenderDocStatus.SelectedIndex = -1;
                    txtRemarks.Text = "";
                }
                else
                {
                    UpdateTenderPreparationInfo();
                    GridViewRefresh_PTD();
                }
            }            

        }
        private void InsertTenderPreparationInfo(int _dateID)
        {
            if (msk_dtpRecievedOn.Text == "")
            {
                MessageBox.Show("Please select received on date");
                msk_dtpRecievedOn.Focus();
                return;
            }

            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    sqlConn.Open();
                    string insertQuery = "INSERT INTO TenderDatesInfo(date_id,proj_id, stage_id, ptd_receive_on, ptd_purpose, ptd_assign_qs," +
                    " ptd_sent_for_rev, ptd_qs_working_status, ptd_tendec_doc_cur_status,ptd_forwarded_to_dep, remarks,Create_Date,Create_User) VALUES " +
                    " (@dateId,@projId,@stageId,@PTDreceiveOn,@PTDPurpose,@PTDassignQs,@PTDForReview,@PTDQsStatus,@PTDdocStatus,@PTDfrwdDept,@PTDRemarks,@CreateDate,@CreateUser)";

                    SqlCommand cmd = new SqlCommand(insertQuery, sqlConn);
                    cmd.Parameters.AddWithValue("@dateId", _dateID);
                    cmd.Parameters.AddWithValue("@projId", Convert.ToInt32(lblProjID.Text));
                    cmd.Parameters.AddWithValue("@stageId", 1);

                    //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings 
                    if (msk_dtpRecievedOn.Text != "")
                        cmd.Parameters.AddWithValue("@PTDreceiveOn", Convert.ToDateTime(msk_dtpRecievedOn.Text + " " + DateTime.Now.Hour + ":" + DateTime.Now.Minute + ":" + DateTime.Now.Second)); //Convert.ToDateTime(msk_dtpRecievedOn.Text).ToString("dd/MMM/yyyy")
                    else
                        cmd.Parameters.AddWithValue("@PTDreceiveOn", DBNull.Value);

                    if (cmbPurpose.SelectedIndex != -1)
                        cmd.Parameters.AddWithValue("@PTDPurpose", cmbPurpose.SelectedItem.ToString());
                    else
                        cmd.Parameters.AddWithValue("@PTDPurpose", DBNull.Value);

                    if (cmbTenderDocStatus.SelectedIndex != -1)
                        cmd.Parameters.AddWithValue("@PTDdocStatus", cmbTenderDocStatus.SelectedItem.ToString());
                    else
                        cmd.Parameters.AddWithValue("@PTDdocStatus", DBNull.Value);

                    if (cmbAssignedQs.SelectedIndex != -1)
                        cmd.Parameters.AddWithValue("@PTDassignQs", cmbAssignedQs.Text.ToString());
                    else
                        cmd.Parameters.AddWithValue("@PTDassignQs", DBNull.Value);

                    string[] formats = { "dd/MMM/yyyy hh:mm:ss tt", "dd-MMM-yyyy hh:mm:ss tt" };
                    DateTime value;
                    DateTime.TryParseExact(msk_dtpReview.Text, formats, CultureInfo.InvariantCulture, DateTimeStyles.None, out value);
                    //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings 
                    if (msk_dtpReview.Text != "")
                        cmd.Parameters.AddWithValue("@PTDForReview", Convert.ToDateTime(msk_dtpReview.Text)); //.ToString("dd/MMM/yyyy")
                    else
                        cmd.Parameters.AddWithValue("@PTDForReview", DBNull.Value);

                    if (cmbQsWorkingStatus.SelectedIndex != -1)
                        cmd.Parameters.AddWithValue("@PTDQsStatus", cmbQsWorkingStatus.SelectedItem.ToString());
                    else
                        cmd.Parameters.AddWithValue("@PTDQsStatus", DBNull.Value);

                    //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings 
                    if (msk_dtpFrwdDept.Text != "")
                        cmd.Parameters.AddWithValue("@PTDfrwdDept", Convert.ToDateTime(msk_dtpFrwdDept.Text));//.ToString("dd/MMM/yyyy")
                    else
                        cmd.Parameters.AddWithValue("@PTDfrwdDept", DBNull.Value);

                    cmd.Parameters.AddWithValue("@PTDRemarks", txtRemarks.Text);

                    cmd.Parameters.AddWithValue("@CreateDate", System.DateTime.Now);
                    cmd.Parameters.AddWithValue("@CreateUser", _userName);

                    cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();                    

                    cmd.CommandText = @"UPDATE PROJECTS set last_Modified_Date=@UpdateDate,Update_User = @UpdateUser where proj_id=@projId";
                    cmd.Parameters.AddWithValue("@UpdateDate", System.DateTime.Now);                     
                    cmd.Parameters.AddWithValue("@UpdateUser", _userName);
                    cmd.Parameters.AddWithValue("@projId", _projID);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Tender Document Preparation Data Added Successfully");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while performing operation with the database", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlConn.Close();
            }

            //For update Assigned QS in Projects Table
            clsStaff.update_AssignedQs(cmbAssignedQs.Text.ToString(), projId);

        }

        public string ConvertDateCalendar(DateTime DateConv, string Calendar, string DateLangCulture)
        {
            System.Globalization.DateTimeFormatInfo DTFormat;
            DateLangCulture = DateLangCulture.ToLower();
            /// We can't have the hijri date writen in English. We will get a runtime error - LAITH - 11/13/2005 1:01:45 PM -

            if (Calendar == "Hijri" && DateLangCulture.StartsWith("en-"))
            {
                DateLangCulture = "ar-sa";
            }

            /// Set the date time format to the given culture - LAITH - 11/13/2005 1:04:22 PM -
            DTFormat = new System.Globalization.CultureInfo(DateLangCulture, false).DateTimeFormat;

            /// Set the calendar property of the date time format to the given calendar - LAITH - 11/13/2005 1:04:52 PM -
            switch (Calendar)
            {
                case "Hijri":
                    DTFormat.Calendar = new System.Globalization.HijriCalendar();
                    break;

                case "Gregorian":
                    DTFormat.Calendar = new System.Globalization.GregorianCalendar();
                    break;

                default:
                    return "";
            }

            /// We format the date structure to whatever we want - LAITH - 11/13/2005 1:05:39 PM -
            DTFormat.ShortDatePattern = "dd/MM/yyyy";
            return (DateConv.Date.ToString("f", DTFormat));
        }

        private void UpdateTenderPreparationInfo()
        {
            //string[] allFormats ={"yyyy/MM/dd hh:mm:ss tt","yyyy/M/d hh:mm:ss tt",
            //"dd/MM/yyyy hh:mm:ss tt","d/M/yyyy hh:mm:ss tt",
            //"dd/M/yyyy hh:mm:ss tt","d/MM/yyyy hh:mm:ss tt","yyyy-MM-dd hh:mm:ss tt",
            //"yyyy-M-d hh:mm:ss tt","dd-MM-yyyy hh:mm:ss tt","d-M-yyyy hh:mm:ss tt",
            //"dd-M-yyyy hh:mm:ss tt","d-MM-yyyy hh:mm:ss tt","yyyy MM dd hh:mm:ss tt",
            //"yyyy M d hh:mm:ss tt","dd MM yyyy hh:mm:ss tt","d M yyyy hh:mm:ss tt",
            //"dd M yyyy hh:mm:ss tt","d MM yyyy hh:mm:ss tt"};

            //string[] allFormats ={"yyyy/MM/dd","yyyy/M/d",
            //    "dd/MM/yyyy","d/M/yyyy",
            //    "dd/M/yyyy","d/MM/yyyy","yyyy-MM-dd",
            //    "yyyy-M-d","dd-MM-yyyy","d-M-yyyy",
            //    "dd-M-yyyy","d-MM-yyyy","yyyy MM dd",
            //    "yyyy M d","dd MM yyyy","d M yyyy",
            //    "dd M yyyy","d MM yyyy","MM/dd/yyyy"};


            //CultureInfo enCul = new CultureInfo("en-US");
            //CultureInfo arCul = new CultureInfo("ar-SA");
            //arCul.DateTimeFormat.Calendar = new System.Globalization.HijriCalendar();
            //DateTime tempDate = DateTime.ParseExact(msk_dtpReview.Text, allFormats, arCul.DateTimeFormat, DateTimeStyles.AllowWhiteSpaces);

            //string strDate = ConvertDateCalendar(msk_dtpReview.Text, "Gregorian", "en-US"); 
            //DateTime tempDate = DateTime.ParseExact(msk_dtpReview.Text, allFormats,
            //enCul.DateTimeFormat, DateTimeStyles.AllowWhiteSpaces);

            if (lblDateID.Text == "")
            {
                MessageBox.Show("Please Click on Row Which you want to Update !");
                return;
            }

            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        cmd.CommandText = @"UPDATE TenderDatesInfo set ptd_receive_on=@PTDreceiveOn,ptd_purpose=@PTDPurpose,ptd_assign_qs=@PTDassignQs,ptd_sent_for_rev=@PTDForReview," +
                        "ptd_qs_working_status=@PTDQsStatus,ptd_tendec_doc_cur_status=@PTDdocStatus,ptd_forwarded_to_dep=@PTDfrwdDept, remarks = @PTDRemarks,Update_Date = @UpdateDate,Update_User = @UpdateUser where date_id=@dateId";

                        cmd.Parameters.AddWithValue("@dateId", Convert.ToInt16(lblDateID.Text));
                        //cmd.Parameters.AddWithValue("@projId", Convert.ToInt16(lblProjID.Text));
                        cmd.Parameters.AddWithValue("@stageId", 1);

                        //.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString()
                        //Modified by Varun on 12/02/2014 for updating dates when the regional settings of the system is Arabic, this will work for en-US settings                          
                        if (msk_dtpRecievedOn.Text != "")
                            cmd.Parameters.AddWithValue("@PTDreceiveOn", Convert.ToDateTime(msk_dtpRecievedOn.Text + " " + DateTime.Now.ToLongTimeString())); //.ToString("dd/MMM/yyyy")
                        else
                            cmd.Parameters.AddWithValue("@PTDreceiveOn", DBNull.Value);
                        if (cmbPurpose.SelectedIndex != -1)
                            cmd.Parameters.AddWithValue("@PTDPurpose", cmbPurpose.SelectedItem.ToString());
                        else
                            cmd.Parameters.AddWithValue("@PTDPurpose", DBNull.Value);

                        if (cmbAssignedQs.SelectedIndex != -1 || cmbAssignedQs.Text.ToString() != "")
                            cmd.Parameters.AddWithValue("@PTDassignQs", cmbAssignedQs.Text.ToString());
                        else
                            cmd.Parameters.AddWithValue("@PTDassignQs", DBNull.Value);

                        //Modified by Varun on 12/02/2014 for updating dates when the regional settings of the system is Arabic, this will work for en-US settings                          
                        if (msk_dtpReview.Text != "")
                            cmd.Parameters.AddWithValue("@PTDForReview", Convert.ToDateTime(msk_dtpReview.Text + " " + DateTime.Now.ToLongTimeString())); //.ToString("dd/MMM/yyyy")
                        else
                            cmd.Parameters.AddWithValue("@PTDForReview", DBNull.Value);

                        if (cmbQsWorkingStatus.SelectedIndex != -1)
                            cmd.Parameters.AddWithValue("@PTDQsStatus", cmbQsWorkingStatus.SelectedItem.ToString());
                        else
                            cmd.Parameters.AddWithValue("@PTDQsStatus", DBNull.Value);

                        if (cmbTenderDocStatus.SelectedIndex != -1)
                            cmd.Parameters.AddWithValue("@PTDdocStatus", cmbTenderDocStatus.SelectedItem.ToString());
                        else
                            cmd.Parameters.AddWithValue("@PTDdocStatus", DBNull.Value);

                        //Modified by Varun on 12/02/2014 for updating dates when the regional settings of the system is Arabic, this will work for en-US settings                          
                        if (msk_dtpFrwdDept.Text != "")
                            cmd.Parameters.AddWithValue("@PTDfrwdDept", Convert.ToDateTime(msk_dtpFrwdDept.Text + " " + DateTime.Now.ToLongTimeString())); //.ToString("dd/MMM/yyyy")
                        else
                            cmd.Parameters.AddWithValue("@PTDfrwdDept", DBNull.Value);

                        cmd.Parameters.AddWithValue("@PTDRemarks", txtRemarks.Text);

                        cmd.Parameters.AddWithValue("@UpdateDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@UpdateUser", _userName);

                        cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        cmd.CommandText = @"UPDATE PROJECTS set Tender_Status_id = @status, last_Modified_Date=@UpdateDate,Update_User = @UpdateUser where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@UpdateDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@status", 1);
                        cmd.Parameters.AddWithValue("@UpdateUser", _userName);
                        cmd.Parameters.AddWithValue("@projId", _projID);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Tender Preparation Values Updated Succesfully");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }


            // Update AssihgnedQs value in Projects Table
            int rowCnt = dgvPTD.Rows.Count - 1;

            if (lblGridIndex.Text != "")
            {
                if (rowCnt == Convert.ToInt16(lblGridIndex.Text))
                    clsStaff.update_AssignedQs(cmbAssignedQs.Text.ToString(), _projID);
            }

            ClearTP();
        }

        private void dtpRecievedOn_ValueChanged(object sender, EventArgs e)
        {
            if (msk_dtpReview.Text != "")
            {
                if (Convert.ToDateTime(dtpRecievedOn.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpReview.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                {
                    MessageBox.Show("Received On Date cannot be greater than or equal to Sent to department for review with comments");
                    msk_dtpRecievedOn.Focus();
                    return;
                }
            }
            else if (msk_dtpFrwdDept.Text != "")
            {
                if (Convert.ToDateTime(dtpRecievedOn.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFrwdDept.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                {
                    MessageBox.Show("Received On Date cannot be greater than or equal to Forward To Department");
                    msk_dtpRecievedOn.Focus();
                    return;
                }
            }

            //msk_dtpRecievedOn.Text = Convert.ToDateTime(dtpRecievedOn.Value).ToString("dd/MMM/yyyy");                          
            //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings 
            msk_dtpRecievedOn.Text = Convert.ToDateTime(dtpRecievedOn.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");// ToString();             

        }
        private void dtpReview_ValueChanged(object sender, EventArgs e)
        {
            if (msk_dtpRecievedOn.Text.Trim() == "")
            {
                MessageBox.Show("Please select Received On Date");
                msk_dtpRecievedOn.Focus();
                return;
            }

            if (msk_dtpRecievedOn.Text != "")
            {
                if (Convert.ToDateTime(dtpReview.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpRecievedOn.Text)) <= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                {
                    MessageBox.Show("Sent to department for review with comments cannot be less than or equal to Received On Date");
                    msk_dtpReview.Focus();
                    return;
                }
            }
            if (msk_dtpFrwdDept.Text != "")
            {
                if (Convert.ToDateTime(dtpReview.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFrwdDept.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                {
                    MessageBox.Show("Sent to department for review with comments cannot be greater than or equal to Forward To Department");
                    msk_dtpReview.Focus();
                    return;
                }
            }
            //msk_dtpReview.Text = Convert.ToDateTime(dtpReview.Value).ToString("dd/MMM/yyyy");
            msk_dtpReview.Text = Convert.ToDateTime(dtpReview.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");

        }
        private void dtpFrwdDept_ValueChanged(object sender, EventArgs e)
        {
            // dtpFrwdDept.CustomFormat = "dd/MMM/yyyy";                    
            //msk_dtpFrwdDept.Text = Convert.ToDateTime(dtpFrwdDept.Value).ToString("dd/MMM/yyyy");

            if (msk_dtpRecievedOn.Text.Trim() == "")
            {
                MessageBox.Show("Please select Received On Date");
                msk_dtpRecievedOn.Focus();
                return;
            }
            if (msk_dtpReview.Text != "")
            {
                if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpReview.Text)) <= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                {
                    MessageBox.Show("Forward To Department date cannot be less than or equal to Sent to department for review with comments");
                    msk_dtpFrwdDept.Focus();
                    return;
                }
            }
            if (msk_dtpRecievedOn.Text != "")
            {
                if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpRecievedOn.Text)) <= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                {
                    MessageBox.Show("Forward To Department date cannot be less than or equal to Received On date");
                    msk_dtpFrwdDept.Focus();
                    return;
                }
            }
            if (msk_dtp_tsRecOn.Text != "")
            {
                if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtp_tsRecOn.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                {
                    MessageBox.Show("Forward To Department date cannot be greater than or equal to Receive On Date (Of Tendering Stage)");
                    msk_dtpFrwdDept.Focus();
                    return;
                }
            }
            if (msk_dtp_tsReturnDept.Text != "")
            {
                if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtp_tsReturnDept.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                {
                    MessageBox.Show("Forward To Department date cannot be greater than or equal to Returned To Department Date (Of Tendering Stage)");
                    msk_dtpFrwdDept.Focus();
                    return;
                }
            }

            if (msk_dtp_tsRecFromDept.Text != "")
            {
                if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtp_tsRecFromDept.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                {
                    MessageBox.Show("Forward To Department date cannot be greater than or equal to Received From Department Date (Of Tendering Stage)");
                    msk_dtpFrwdDept.Focus();
                    return;
                }
            }

            if (msk_dtp_tsAdvertisement.Text != "")
            {
                if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtp_tsAdvertisement.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                {
                    MessageBox.Show("Forward To Department date cannot be greater than or equal to Sent to Public Relations Department For Advertisement (Of Tendering Stage)");
                    msk_dtpFrwdDept.Focus();
                    return;
                }
            }

            if (msk_dtp_tsInvitation.Text != "")
            {
                if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtp_tsInvitation.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                {
                    MessageBox.Show("Forward To Department date cannot be greater than or equal to Tender Issue Date (Of Tendering Stage)");
                    msk_dtpFrwdDept.Focus();
                    return;
                }
            }

            if (msk_dtp_tsStage1.Text != "")
            {
                if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtp_tsStage1.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                {
                    MessageBox.Show("Forward To Department date cannot be greater than or equal to Tender Closing Date Stage 1 (Of Tendering Stage)");
                    msk_dtpFrwdDept.Focus();
                    return;
                }
            }

            if (msk_dtp_tsStage2.Text != "")
            {
                if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtp_tsStage2.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                {
                    MessageBox.Show("Forward To Department date cannot be greater than or equal to Tender Closing Date Stage 2 (Of Tendering Stage)");
                    msk_dtpFrwdDept.Focus();
                    return;
                }
            }

            if (msk_dtp_tsModifiedDate_Stage1.Text != "")
            {
                if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtp_tsModifiedDate_Stage1.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                {
                    MessageBox.Show("Forward To Department date cannot be greater than or equal to Modified Closing Date Stage 1 (Of Tendering Stage)");
                    msk_dtpFrwdDept.Focus();
                    return;
                }
            }

            if (msk_dtp_tsModifiedDate_Stage2.Text != "")
            {
                if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtp_tsModifiedDate_Stage2.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                {
                    MessageBox.Show("Forward To Department date cannot be greater than or equal to Modified Closing Date Stage 2 (Of Tendering Stage)");
                    msk_dtpFrwdDept.Focus();
                    return;
                }
            }

            if (msk_dtpEA_reqdate.Text != "")
            {
                if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpEA_reqdate.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                {
                    MessageBox.Show("Forward To Department date cannot be greater than or equal to Tender Open Date (Of Tender Evaluation and Award Stage)");
                    msk_dtpFrwdDept.Focus();
                    return;
                }
            }

            if (msk_dtpEA_recfromcd.Text != "")
            {
                if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpEA_recfromcd.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                {
                    MessageBox.Show("Forward To Department date cannot be greater than or equal to Doc Received From CD (Of Tender Evaluation and Award Stage)");
                    msk_dtpFrwdDept.Focus();
                    return;
                }
            }

            if (msk_dtpTE_daterec1.Text != "")
            {
                if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                {
                    MessageBox.Show("Forward To Department date cannot be greater than or equal to Technical Evaluation Received Date (First Evaluation) (Of Tender Evaluation and Award Stage)");
                    msk_dtpFrwdDept.Focus();
                    return;
                }
            }
            if (msk_dtpTE_datesent2.Text != "")
            {
                if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_datesent2.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                {
                    MessageBox.Show("Forward To Department date cannot be greater than or equal to Technical Evaluation Send Date (Second Evaluation) (Of Tender Evaluation and Award Stage)");
                    msk_dtpFrwdDept.Focus();
                    return;
                }
            }

            if (msk_dtpTE_daterec2.Text != "")
            {
                if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec2.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                {
                    MessageBox.Show("Forward To Department date cannot be greater than or equal to Technical Evaluation Received Date (Second Evaluation) (Of Tender Evaluation and Award Stage)");
                    msk_dtpFrwdDept.Focus();
                    return;
                }
            }

            //if (msk_dtpTTR_datesent1.Text.Trim() != "")
            //{
            //    if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTTR_datesent1.Text)) >= 0)
            //    {
            //        MessageBox.Show("Forward To Department date cannot be greater than or equal to Technical Tender Review Send Date (First Evaluation) (Of Tender Evaluation and Award Stage)");
            //        msk_dtpFrwdDept.Focus();
            //        return;
            //    }

            //}
            //if (msk_dtpTTR_daterec1.Text.Trim() != "")
            //{
            //    if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTTR_daterec1.Text)) >= 0)
            //    {
            //        MessageBox.Show("Forward To Department date cannot be greater than or equal to Technical Tender Review Received Date (First Evaluation) (Of Tender Evaluation and Award Stage)");
            //        msk_dtpFrwdDept.Focus();
            //        return;
            //    }

            //}
            //if (msk_dtpTTR_datesent2.Text.Trim() != "")
            //{
            //    if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTTR_datesent2.Text)) >= 0)
            //    {
            //        MessageBox.Show("Forward To Department date cannot be greater than or equal to Technical Tender Review Send Date (Second Evaluation) (Of Tender Evaluation and Award Stage)");
            //        msk_dtpFrwdDept.Focus();
            //        return;
            //    }
            //}
            //if (msk_dtpTTR_daterec2.Text.Trim() != "")
            //{
            //    if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTTR_daterec2.Text)) >= 0)
            //    {
            //        MessageBox.Show("Forward To Department date cannot be greater than or equal to Technical Tender Review Received Date (Second Evaluation) (Of Tender Evaluation and Award Stage)");
            //        msk_dtpFrwdDept.Focus();
            //        return;
            //    }
            //}
            //}
            //if (stageName.Equals("Technical Tender Review"))
            //{

            //if (msk_dtpTTR_datesent1.Text.Trim() != "")
            //{
            //    if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTTR_datesent1.Text)) >= 0)
            //    {
            //        MessageBox.Show("Forward To Department date cannot be greater than or equal to Technical Tender Review Send Date (First Evaluation) (Of Tender Evaluation and Award Stage)");
            //        msk_dtpFrwdDept.Focus();
            //        return;
            //    }

            //}

            //if (msk_dtpTTR_daterec1.Text.Trim() != "")
            //{
            //    if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTTR_daterec1.Text)) >= 0)
            //    {
            //        MessageBox.Show("Forward To Department date cannot be greater than or equal to Technical Tender Review Received Date (First Evaluation) (Of Tender Evaluation and Award Stage)");
            //        msk_dtpFrwdDept.Focus();
            //        return;
            //    }

            //}

            //if (msk_dtpTTR_datesent2.Text.Trim() != "")
            //{
            //    if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTTR_datesent2.Text)) >= 0)
            //    {
            //        MessageBox.Show("Forward To Department date cannot be greater than or equal to Technical Tender Review Send Date (Second Evaluation) (Of Tender Evaluation and Award Stage)");
            //        msk_dtpFrwdDept.Focus();
            //        return;
            //    }
            //}
            //if (msk_dtpTTR_daterec2.Text.Trim() != "")
            //{
            //    if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTTR_daterec2.Text)) >= 0)
            //    {
            //        MessageBox.Show("Forward To Department date cannot be greater than or equal to Technical Tender Review Received Date (Second Evaluation) (Of Tender Evaluation and Award Stage)");
            //        msk_dtpFrwdDept.Focus();
            //        return;
            //    }
            //}
            //}
            //if (stageName.Equals("Technical Evaluation") || stageName.Equals("Financial Evaluation"))
            //{
            if (msk_dtpFE_daterecFin1.Text != "")
            {
                if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFE_daterecFin1.Text)) >= 0)
                {

                    MessageBox.Show("Forward To Department date cannot be greater than or equal to Financial Evaluation Received Date (First Evaluation) (Of Tender Evaluation and Award Stage)");
                    msk_dtpFrwdDept.Focus();
                    return;
                }
            }
            if (msk_dtpFE_datesentfin1.Text != "")
            {
                if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFE_datesentfin1.Text)) >= 0)
                {
                    MessageBox.Show("Forward To Department date cannot be greater than or equal to Financial Evaluation Send Date (First Evaluation) (Of Tender Evaluation and Award Stage)");
                    msk_dtpFrwdDept.Focus();
                    return;
                }
            }
            if (msk_dtpFE_daterecFin2.Text != "")
            {
                if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFE_daterecFin2.Text)) >= 0)
                {
                    MessageBox.Show("Forward To Department date cannot be greater than or equal to Financial Evaluation Received Date (Second Evaluation) (Of Tender Evaluation and Award Stage)");
                    msk_dtpFrwdDept.Focus();
                    return;
                }
            }
            //}
            //if (stageName.Equals("Financial Evaluation"))
            //{
            //if (msk_dtpFTR_datesent1.Text != "")
            //{
            //    if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFTR_datesent1.Text)) >= 0)
            //    {
            //        MessageBox.Show("Forward To Department date cannot be greater than or equal to Financial Tender Review Send Date (First Evaluation) (Of Tender Evaluation and Award Stage)");
            //        msk_dtpFrwdDept.Focus();
            //        return;
            //    }
            //}
            //if (msk_dtpFTR_daterec1.Text != "")
            //{
            //    if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFTR_daterec1.Text)) <= 0)
            //    {
            //        MessageBox.Show("Forward To Department date cannot be greater than or equal to Financial Tender Review Received Date (First Evaluation) (Of Tender Evaluation and Award Stage)");
            //        msk_dtpFrwdDept.Focus();
            //        return;
            //    }
            //}
            //if (msk_dtpFTR_datesent2.Text != "")
            //{
            //    if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFTR_datesent2.Text)) <= 0)
            //    {
            //        MessageBox.Show("Forward To Department date cannot be greater than or equal to Financial Tender Review Send Date (Second Evaluation) (Of Tender Evaluation and Award Stage)");
            //        msk_dtpFrwdDept.Focus();
            //        return;
            //    }
            //}
            //if (msk_dtpFTR_daterec2.Text != "")
            //{
            //    if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFTR_daterec2.Text)) <= 0)
            //    {
            //        MessageBox.Show("Forward To Department date cannot be greater than or equal to Financial Tender Review Received Date (Second Evaluation) (Of Tender Evaluation and Award Stage)");
            //        msk_dtpFrwdDept.Focus();
            //        return;
            //    }
            //}

            if (msk_dtpEA_apprDate.Text != "")
            {
                if (Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpEA_apprDate.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                {
                    MessageBox.Show("Forward To Department date cannot be greater than or equal to Tender Award Approval Date (Of Tender Evaluation and Award Stage)");
                    msk_dtpFrwdDept.Focus();
                    return;
                }
            }


            msk_dtpFrwdDept.Text = Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
            //if (Convert.ToDateTime(dtpFrwdDept.Value.ToString()).CompareTo(Convert.ToDateTime(dtpRecievedOn.Value.ToString())) >= 0)
            //    msk_dtpFrwdDept.Text = Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
            //else
            //{
            //    MessageBox.Show("Forward To Department date cannot be less than Received On date");
            //    msk_dtpFrwdDept.Focus();
            //}

        }
        private void dtpRecievedOn_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Delete)
            {
                if (sender is DateTimePicker)
                {
                    dtpRecievedOn.CustomFormat = " ";
                }
            }
        }
        private void dtpReview_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Delete)
            {
                if (sender is DateTimePicker)
                {
                    dtpReview.CustomFormat = " ";
                }
            }
        }
        private void dtpFrwdDept_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Delete)
            {
                if (sender is DateTimePicker)
                {
                    dtpFrwdDept.CustomFormat = " ";
                }
            }
        }
        private void button22_Click_1(object sender, EventArgs e)
        {
            if (_profileName!="VIEW ALL")            
            {
                if (lblDateID.Text == "")
                {
                    return;
                }
                try
                {
                    using (SqlConnection sqlConn = new SqlConnection(connStr))
                    {
                        using (SqlCommand cmd = new SqlCommand())
                        {
                            sqlConn.Open();
                            cmd.Connection = sqlConn;
                            cmd.CommandText = @"DELETE FROM TenderDatesInfo WHERE DATE_ID = " + Convert.ToInt16(lblDateID.Text) + " ";
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Record Deleted Successfully");
                        }
                    }
                    ClearTP();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                GridViewRefresh_PTD();
            }             
        }
        private void ClearTP()
        {
            msk_dtpRecievedOn.Text = "";
            msk_dtpReview.Text = "";
            msk_dtpFrwdDept.Text = "";
            cmbAssignedQs.SelectedIndex = -1;
            cmbPurpose.SelectedIndex = -1;
            cmbQsWorkingStatus.SelectedIndex = -1;
            cmbAssignedQs.Text = "";
            cmbTenderDocStatus.SelectedIndex = -1;
            txtRemarks.Text = "";
            lblDateID.Text = "";
            chkUpdateStatus = false;
        }
        private void button23_Click_1(object sender, EventArgs e)
        {
            if (_profileName != "VIEW ALL")
            {
                ClearTP();
            }             
        }
        private void dtpRecievedOn_FormatChanged(object sender, EventArgs e)
        {
            dtpRecievedOn.CustomFormat = "dd/MMM/yyyy";
        }


        private void dgvTE_Sent_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (mUserRightsColl.Contains("20"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            int rowIndex = e.RowIndex;
            try
            {
                if (rowIndex != -1)
                {

                    if (dgvTE_Sent.Rows[rowIndex].Cells[0].Value.ToString() != "")
                    {
                        int docId = Convert.ToInt32(dgvTE_Sent.Rows[rowIndex].Cells[0].Value);
                        SentDocProperties sendDoc = null;
                        if (dgvTE_Sent.Rows[rowIndex].Cells[1].Value.ToString() != "")
                            sendDoc = new SentDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), txtProjCode.Text, docId, 3, _userName, dgvTE_Sent.Rows[rowIndex].Cells[0].Value, 'Y', mIsHeadOfSection);
                        else
                            sendDoc = new SentDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), txtProjCode.Text, docId, 3, _userName, "", 'Y', mIsHeadOfSection);
                        sendDoc.StartPosition = FormStartPosition.CenterParent;
                        sendDoc.ShowDialog();

                        commCls.FillGridSentDocsInfo(Convert.ToInt16(lblProjID.Text),ref dgvTE_Sent, 3);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void dgvTE_Rec_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (mUserRightsColl.Contains("20"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            int rowIndex = e.RowIndex;
            try
            {
                if (rowIndex != -1)
                {
                    if (dgvTE_Rec.Rows[rowIndex].Cells[3].Value.ToString() != "")
                    {
                        int docId = Convert.ToInt32(dgvTE_Rec.Rows[rowIndex].Cells[3].Value);
                        ReceivedDocProperties receivedDoc = new ReceivedDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), txtProjCode.Text, docId, 3, _userName);
                        receivedDoc.StartPosition = FormStartPosition.CenterParent;
                        receivedDoc.ShowDialog();

                        commCls.FillGridReceivedDocsInfo(Convert.ToInt16(lblProjID.Text),ref dgvTE_Rec, 3);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void dgvTS_Rec_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (mUserRightsColl.Contains("20"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            int rowIndex = e.RowIndex;
            try
            {
                if (rowIndex != -1)
                {
                    if (dgvTS_Rec.Rows[rowIndex].Cells[3].Value.ToString() != "")
                    {
                        int docId = Convert.ToInt32(dgvTS_Rec.Rows[rowIndex].Cells[3].Value);
                        ReceivedDocProperties receivedDoc = new ReceivedDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), txtProjCode.Text, docId, 2, _userName);
                        receivedDoc.StartPosition = FormStartPosition.CenterParent;
                        receivedDoc.ShowDialog();
                        commCls.FillGridReceivedDocsInfo(Convert.ToInt16(lblProjID.Text),ref dgvTS_Rec, 2);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void dgvTS_Sent_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (mUserRightsColl.Contains("20"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            int rowIndex = e.RowIndex;
            try
            {
                if (rowIndex != -1)
                {
                    if (dgvTS_Sent.Rows[rowIndex].Cells[0].Value.ToString() != "")
                    {
                        int docId = Convert.ToInt32(dgvTS_Sent.Rows[rowIndex].Cells[0].Value);
                        SentDocProperties sentDoc = new SentDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), txtProjCode.Text, docId, 2, _userName, dgvTS_Sent.Rows[rowIndex].Cells[1].Value, 'Y', mIsHeadOfSection);
                        sentDoc.StartPosition = FormStartPosition.CenterParent;
                        sentDoc.ShowDialog();
                        commCls.FillGridSentDocsInfo(Convert.ToInt16(lblProjID.Text),ref dgvTS_Sent, 2);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void dgvCP_Sent_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (mUserRightsColl.Contains("20"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            int rowIndex = e.RowIndex;
            try
            {
                if (rowIndex != -1)
                {
                    if (dgvCP_Sent.Rows[rowIndex].Cells[0].Value.ToString() != "")
                    {
                        int docId = Convert.ToInt32(dgvCP_Sent.Rows[rowIndex].Cells[0].Value);
                        SentDocProperties sentDoc = new SentDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), txtProjCode.Text, docId, 4, _userName, dgvCP_Sent.Rows[rowIndex].Cells[1].Value, 'Y', mIsHeadOfSection);
                        sentDoc.StartPosition = FormStartPosition.CenterParent;
                        sentDoc.ShowDialog();
                        commCls.FillGridSentDocsInfo(Convert.ToInt16(lblProjID.Text),ref dgvCP_Sent, 4);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void cmbTenderDocStatus_Leave(object sender, EventArgs e)
        {
            if (cmbQsWorkingStatus.SelectedIndex == -1)
            {
                cmbQsWorkingStatus.Focus();
                MessageBox.Show("Please Select QsWorking Status");
                cmbTenderDocStatus.SelectedIndex = -1;
                return;
            }
            else
            {
                if (cmbTenderDocStatus.Text.Equals("Approved"))
                {
                    cmbQsWorkingStatus.SelectedIndex = 1; //Completed
                }
            }
        }
        private void msk_dtpEA_datesent_Leave(object sender, EventArgs e)
        {
            if (msk_dtpTE_datesent1.Text != "")
            {
                if (ValidateDate(msk_dtpTE_datesent1) == false)
                {
                    msk_dtpTE_datesent1.Text = "";
                    msk_dtpTE_datesent1.Focus();
                    return;
                }

                if (msk_dtpEA_stage1.Text == "")
                {
                    msk_dtpTE_datesent1.Text = "";
                    msk_dtpTE_datesent1.Focus();
                    MessageBox.Show("Tender Closing Date in Tender Stage is not updated. Please Update this prior to this field.");
                    return;
                }
                if (msk_dtpEA_stage1.Text != "")
                {
                    if (Convert.ToDateTime(msk_dtpTE_datesent1.Text) < Convert.ToDateTime(msk_dtpEA_stage1.Text))
                    {
                        msk_dtpEA_stage2.Text = "";
                        msk_dtpEA_stage2.Focus();
                        MessageBox.Show("Date entered is earlier than Tender Closing Date. Please check and revise your entry.");
                        return;
                    }
                }
            }
        }
        private void msk_dtpEA_daterec_Leave(object sender, EventArgs e)
        {
            if (msk_dtpTE_daterec1.Text.Trim() != "")
            {
                if (ValidateDate(msk_dtpTE_daterec1) == false)
                {
                    msk_dtpTE_daterec1.Text = "";
                    msk_dtpTE_daterec1.Focus();
                    return;
                }

                if (msk_dtpTE_datesent1.Text == "")
                {
                    msk_dtpTE_daterec1.Text = "";
                    msk_dtpTE_daterec1.Focus();
                    MessageBox.Show("Update the Sent Date before updating this field.");
                    return;
                }
                if (Convert.ToDateTime(msk_dtpTE_datesent1.Text) > Convert.ToDateTime(msk_dtpTE_daterec1.Text))
                {
                    msk_dtpTE_daterec1.Text = "";
                    msk_dtpTE_daterec1.Focus();
                    MessageBox.Show("Date entered is earlier than Date Sent. Please check and revise your entry.");
                    return;
                }
            }
            //else
            //{
            //    msk_dtpTE_daterec1.Text = "01/Jan/1900";
            //}  
        }
        private void msk_dtpEA_datesentfin_Leave(object sender, EventArgs e)
        {
            if (msk_dtpFE_datesentfin1.Text.Trim() != "")
            {
                if (msk_dtpEA_stage1.Text != "")
                {
                    if (Convert.ToDateTime(msk_dtpFE_datesentfin1.Text) < Convert.ToDateTime(msk_dtpEA_stage1.Text))
                    {
                        msk_dtpFE_datesentfin1.Text = "";
                        msk_dtpFE_datesentfin1.Focus();
                        MessageBox.Show("Financial Evaluation Date Send cannot be less than Tender Award Approval Date.");
                        return;
                    }
                }
            }
            //else
            //{
            //    msk_dtpFE_datesentfin1.Text = "01/Jan/1900";
            //}             
                
            //if (msk_dtpEA_closeDate.Text != "")
            //{
            //    if (Convert.ToDateTime(msk_dtpEA_datesentfin.Text) < Convert.ToDateTime(msk_dtpEA_stage1.Text))
            //    {
            //        msk_dtpEA_datesentfin.Text = "";
            //        msk_dtpEA_datesentfin.Focus();
            //        MessageBox.Show("Date entered is earlier than Closing Date. Please check and revise your entry.");
            //        return;
            //    }
            //}                
             
        }
        private void msk_dtpEA_daterecFin_Leave(object sender, EventArgs e)
        {
            if (msk_dtpFE_daterecFin1.Text.Trim() != "")
            {
                if (ValidateDate(msk_dtpFE_daterecFin1) == false)
                {
                    msk_dtpFE_daterecFin1.Text = "";
                    msk_dtpFE_daterecFin1.Focus();
                    return;
                }
                if (msk_dtpFE_datesentfin1.Text == "")
                {
                    msk_dtpFE_daterecFin1.Text = "";
                    msk_dtpFE_datesentfin1.Focus();
                    MessageBox.Show("Update the Sent Date before updating this field");
                    return;
                }
                if (Convert.ToDateTime(msk_dtpFE_datesentfin1.Text) > Convert.ToDateTime(msk_dtpFE_daterecFin1.Text))
                {
                    msk_dtpFE_daterecFin1.Text = "";
                    msk_dtpFE_daterecFin1.Focus();
                    MessageBox.Show("Financial Evaluation Date Received cannot be less than Financial Evaluation Date Send. Please check and revise your entry.");
                    return;
                }
            }
            //else
            //{
            //    msk_dtpFE_daterecFin1.Text = "01/Jan/1900";
            //}
        }
        private void msk_dtpEA_apprDate_Leave(object sender, EventArgs e)
        {
            if (msk_dtpEA_apprDate.Text.Trim() != "")
            {
                if (ValidateDate(msk_dtpEA_apprDate) == false)
                {
                    msk_dtpEA_apprDate.Text = "";
                    msk_dtpEA_apprDate.Focus();
                    return;
                }
                if (msk_dtpTE_daterec1.Text == "")
                {
                    msk_dtpEA_apprDate.Text = "";
                    msk_dtpEA_apprDate.Focus();
                    MessageBox.Show("Update Date Received for Financial Evaluation before entering data in the field.");
                    return;
                }
                if (Convert.ToDateTime(msk_dtpTE_daterec1.Text) > Convert.ToDateTime(msk_dtpEA_apprDate.Text))
                {
                    msk_dtpEA_apprDate.Text = "";
                    msk_dtpEA_apprDate.Focus();
                    MessageBox.Show("Date entered is earlier than Technical Evaluation Received date. Please Check and revise your entry. ");
                    return;
                }
            }
             
        }

        private void msk_dtpFrwdDept_Leave(object sender, EventArgs e)
        {
            //Control ctrl = sender as Control;
            //if (ValidateDate(ctrl) == false)
            //{
            //    msk_dtpFrwdDept.Text = "";
            //    msk_dtpFrwdDept.Focus();
            //    return;
            //}

            //if (msk_dtpFrwdDept.Text != "")
            //{
            //    if (Convert.ToDateTime(msk_dtpRecievedOn.Text) > Convert.ToDateTime(msk_dtpFrwdDept.Text))
            //    {
            //        msk_dtpFrwdDept.Text = "";
            //        msk_dtpFrwdDept.Focus();
            //        MessageBox.Show("The date entered cannot be less than the date in 'Received On'.Please check the date");
            //        return;
            //    }
            //if (cmbQsWorkingStatus.SelectedIndex == -1)
            //{
            //    msk_dtpFrwdDept.Text = "";
            //    cmbQsWorkingStatus.Focus();
            //    MessageBox.Show("Please update 'QS Working Status' before entering a date.");
            //    return;
            //}
            //if (cmbTenderDocStatus.SelectedIndex == -1)
            //{
            //    msk_dtpFrwdDept.Text = "";
            //    cmbTenderDocStatus.Focus();
            //    MessageBox.Show("Please update 'Tender Document Current Status' before entering a date.");
            //    return;
            //}

            //}
        }


        private void GetTenderStageClosingDates()
        {
            SqlConnection sqlConn = new SqlConnection(connStr);
            sqlConn.Open();
            sqlCom = new SqlCommand("SELECT ts_closing_s1,ts_closing_s2,ts_modified_closing,ts_modified_closing_s2 FROM TenderDatesInfo Where proj_id = " + _projID + " and stage_id = 2 AND (ts_tender_issue IS NULL)", sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            if (sqlReader.HasRows)
            {
                sqlReader.Read();

                if (sqlReader[0].ToString() != "")
                {
                    DateTime dt_dtpEA_stage1 = Convert.ToDateTime(sqlReader[0].ToString());
                    msk_dtpEA_stage1.Text = dt_dtpEA_stage1.ToString("dd-MMM-yyyy", CultureInfo.InvariantCulture);
                }
                if (sqlReader[1].ToString() != "")
                {
                    DateTime dt_dtpEA_stage2 = Convert.ToDateTime(sqlReader[1].ToString());
                    msk_dtpEA_stage2.Text = dt_dtpEA_stage2.ToString("dd-MMM-yyyy", CultureInfo.InvariantCulture);
                }
                if (sqlReader[2].ToString() != "")
                {
                    DateTime dt_dtpEA_closeDate = Convert.ToDateTime(sqlReader[2].ToString());
                    msk_dtpEA_closeDate.Text = dt_dtpEA_closeDate.ToString("dd-MMM-yyyy", CultureInfo.InvariantCulture);
                }
                if (sqlReader[3].ToString() != "")
                {
                    DateTime dt_dtpEA_closeDate_s2 = Convert.ToDateTime(sqlReader[3].ToString());
                    msk_dtpEA_closeDate_Stage2.Text = dt_dtpEA_closeDate_s2.ToString("dd-MMM-yyyy", CultureInfo.InvariantCulture);
                }
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        bool bblink = true;
        private void timer1_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (txtTenderNo.Text != "")
            {
                if (bblink)
                {
                    txtTenderNo.BackColor = Color.Blue;
                    txtTenderNo.ForeColor = Color.Red;
                }
                else
                {
                    txtTenderNo.BackColor = Color.Red;
                    txtTenderNo.ForeColor = Color.Blue;
                }
            }
            bblink = !bblink;
        }

        private void TE_AdminRigts()
        {
            if (mUserRightsColl.Contains("35"))
            {
                lblTE_bdgtAmt.Visible = false;
                lblTE_estimateAmnt.Visible = false;

                txtBudjetAmnt.Visible = false;
                txtEstimatedAmnt.Visible = false;
            }
            else
            {
                if (mUserRightsColl.Contains("36"))
                {
                    lblBondAmt.Visible = true;
                    lblDocAmt.Visible = true;
                    txtBudjetAmnt.Enabled = false;
                    txtEstimatedAmnt.Enabled = false;
                }
                else
                {
                    lblBondAmt.Visible = true;
                    lblDocAmt.Visible = true;
                    txtBudjetAmnt.Visible = true;
                    txtEstimatedAmnt.Visible = true;
                }
            }

        }
        private void TE_Validate(int dateId)
        {
            if (msk_dtpEA_reqdate.Text != "" && isCpContractorSign == false)
            {
                DateTime dt_dtpEA_OpenDate = Convert.ToDateTime(msk_dtpEA_reqdate.Text, CultureInfo.InvariantCulture);
                msk_dtpTV_OrgDate.Text = dt_dtpEA_OpenDate.AddDays(90).ToString("dd/MMM/yyyy");

                int iDays = 0;
                if (msk_dtpTV_SEdate.Text != "")
                {
                    iDays = (Convert.ToDateTime(msk_dtpTV_SEdate.Text) - System.DateTime.Now.Date).Days;
                    txtTV_exipre.Text = iDays.ToString();
                }
                else if (msk_dtpTV_FEdate.Text != "")
                {
                    iDays = (Convert.ToDateTime(msk_dtpTV_FEdate.Text) - System.DateTime.Now.Date).Days;
                    txtTV_exipre.Text = iDays.ToString();
                }
                else if (msk_dtpTV_OrgDate.Text != "")
                {
                    iDays = (Convert.ToDateTime(msk_dtpTV_OrgDate.Text) - System.DateTime.Now.Date).Days;
                    txtTV_exipre.Text = iDays.ToString();
                }
                clsForTS.UpdateTV_Original_Extension(iDays, tndrDate_ID);
            }

            if (msk_dtpEA_closeDate.Text != "" && isCpContractorSign == false)
            {
                DateTime dt_dtpEA_closeDate = Convert.ToDateTime(msk_dtpEA_closeDate.Text);
                msk_dtpTBV_OrgDate.Text = dt_dtpEA_closeDate.AddDays(120).ToString("dd/MMM/yyyy");

                int iDays = 0;
                if (msk_dtpTBV_SEdate.Text != "")
                {
                    iDays = (Convert.ToDateTime(msk_dtpTBV_SEdate.Text) - System.DateTime.Now.Date).Days;
                    txtTBV_exipre.Text = iDays.ToString();
                }
                else if (msk_dtpTBV_FEdate.Text != "")
                {
                    iDays = (Convert.ToDateTime(msk_dtpTBV_FEdate.Text) - System.DateTime.Now.Date).Days;
                    txtTBV_exipre.Text = iDays.ToString();
                }
                else if (msk_dtpTBV_OrgDate.Text != "")
                {
                    iDays = (Convert.ToDateTime(msk_dtpTBV_OrgDate.Text) - System.DateTime.Now.Date).Days;
                    txtTBV_exipre.Text = iDays.ToString();
                }
                clsForTS.UpdateTBV_Original_Extension(iDays, tndrDate_ID);
            }
            else if (msk_dtpEA_stage1.Text != "" && isCpContractorSign == false)
            {
                DateTime dt_dtpEA_stgeDate = Convert.ToDateTime(msk_dtpEA_stage1.Text);
                msk_dtpTBV_OrgDate.Text = dt_dtpEA_stgeDate.AddDays(120).ToString("dd/MMM/yyyy");

                int iDays = 0;
                if (msk_dtpTBV_SEdate.Text != "")
                {
                    iDays = (Convert.ToDateTime(msk_dtpTBV_SEdate.Text) - System.DateTime.Now.Date).Days;
                    txtTBV_exipre.Text = iDays.ToString();
                }
                else if (msk_dtpTBV_FEdate.Text != "")
                {
                    iDays = (Convert.ToDateTime(msk_dtpTBV_FEdate.Text) - System.DateTime.Now.Date).Days;
                    txtTBV_exipre.Text = iDays.ToString();
                }
                else if (msk_dtpTBV_OrgDate.Text != "")
                {
                    iDays = (Convert.ToDateTime(msk_dtpTBV_OrgDate.Text) - System.DateTime.Now.Date).Days;
                    txtTBV_exipre.Text = iDays.ToString();
                }
                clsForTS.UpdateTBV_Original_Extension(iDays, tndrDate_ID);
            }
        }

        private void TS_Validate()
        {
            if (mUserRightsColl.Contains("35"))
            {
                lblBondAmt.Visible = false;
                lblDocAmt.Visible = false;

                txtTenderBond.Visible = false;
                txtDocumentFee.Visible = false;
            }
            else
            {
                if (mUserRightsColl.Contains("36"))
                {
                    lblBondAmt.Visible = true;
                    lblDocAmt.Visible = true;
                    txtTenderBond.Enabled = false;
                    txtDocumentFee.Enabled = false;
                }
                else
                {
                    lblBondAmt.Visible = true;
                    lblDocAmt.Visible = true;
                    txtTenderBond.Visible = true;
                    txtDocumentFee.Visible = true;
                }
            }

            if (txtTenderNo.Text != "")
            {
                btnAssignTender.Visible = false;
            }
            else
            {
                btnAssignTender.Visible = true;
            }
        }

        private void CP_AdminRights()
        {
            if (mUserRightsColl.Contains("35"))
            {
                lblCP_bdgtAmnt.Visible = false;
                lblCP_estimateAmnt.Visible = false;

                txtCp_BudgetAmnt.Visible = false;
                txtCp_EstimatedAmnt.Visible = false;
            }
            else
            {
                if (mUserRightsColl.Contains("36"))
                {
                    lblCP_bdgtAmnt.Visible = true;
                    lblCP_estimateAmnt.Visible = true;
                    txtCp_BudgetAmnt.Enabled = false;
                    txtCp_EstimatedAmnt.Enabled = false;
                }
                else
                {
                    lblCP_bdgtAmnt.Visible = true;
                    lblCP_estimateAmnt.Visible = true;
                    txtCp_BudgetAmnt.Visible = true;
                    txtCp_EstimatedAmnt.Visible = true;
                }
            }
        }
        private void PC_AdminRights()
        {
            if (mUserRightsColl.Contains("35"))
            {
                lblPC_bdgtAmnt.Visible = false;
                lblPc_EstAmnt.Visible = false;

                txtPC_BudjetAmnt.Visible = false;
                txtPC_EstimatedAmnt.Visible = false;
            }
            else
            {
                if (mUserRightsColl.Contains("36"))
                {
                    lblPC_bdgtAmnt.Visible = true;
                    lblPc_EstAmnt.Visible = true;
                    txtPC_BudjetAmnt.Enabled = false;
                    txtPC_EstimatedAmnt.Enabled = false;
                }
                else
                {
                    lblPC_bdgtAmnt.Visible = true;
                    lblPc_EstAmnt.Visible = true;
                    txtPC_BudjetAmnt.Visible = true;
                    txtPC_EstimatedAmnt.Visible = true;
                }
            }
        }
        private void getEligibleTypes(ref bool isOnLoad)
        {
            try
            {
                clsDatabase clsDb = new clsDatabase(connStr);
                clsDb.ConnectDB();
                strEligibleTenderTypes = clsDb.ExecuteReader("select EligibleTenderTypes from PROJECTS where proj_id=" + _projID);
                clsDb.DisconnectDB();
                short loopCounter = 0;
                if (strEligibleTenderTypes != "")
                {
                    string[] strArrayTenderTypes = strEligibleTenderTypes.Split(',');
                    if (strArrayTenderTypes.Length > 0)
                    {
                        chkLocal.Checked = false;
                        chkInternational.Checked = false;
                        chkJointVenture.Checked = false;
                        while (loopCounter < strArrayTenderTypes.Length)
                        {
                            if (strArrayTenderTypes[loopCounter].ToString() == "Local")
                                chkLocal.Checked = true;

                            else if (strArrayTenderTypes[loopCounter].ToString() == "International")
                                chkInternational.Checked = true;

                            else if (strArrayTenderTypes[loopCounter].ToString() == "Joint Venture")
                                chkJointVenture.Checked = true;

                            loopCounter++;
                        }
                    }
                    else
                    {
                        if (strEligibleTenderTypes == "Local")
                            chkLocal.Checked = true;
                        else if (strEligibleTenderTypes == "International")
                            chkInternational.Checked = true;
                        else if (strEligibleTenderTypes == "Joint Venture")
                            chkJointVenture.Checked = true;

                    }
                }
                isOnLoad = true;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while retrieving Project type", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void PopulatingVariousStagesTabControlsOfProject()
        {
            // Direct Award Approval Date
            DAL dataLyr = new DAL();
            if (tabControl1.SelectedTab.Name == "ptdTabPage")
            {
                //if ((!mUserRightsColl.Contains("78") && (!mUserRightsColl.Contains("75"))))
                if (!mUserRightsColl.Contains("120"))
                {
                    btnWorkOrderInPTD.Visible = true;
                }                
                commCls.FillGridReceivedDocsInfo(_projID,ref dgvPTD_Rec, 1);
                commCls.FillGridSentDocsInfo(_projID,ref dgvPTD_Sent, 1);
            }
            else if (tabControl1.SelectedTab.Name == "tsTabPage")
            {
                TS_Validate();
                saveChk = false;

                saveChk = FillTenderStageInfo(ref dateID_Ts, ref mdfExistDate);     //Sree

                //FillTender_ModifiedDates();

                if (msk_dtp_tsRecOn.Text == "" && msk_dtp_tsStage1.Text == "")
                {
                    btnIssueTender.Visible = true;
                }

                FillProjectCostDetailsOfTenderStage();

                int _bidCnt = clsForTS.GetbidderCount(_projID);
                if (_bidCnt != 0)
                {
                    btnViewBidder.Visible = true;
                    btnExportToPdf.Visible = true;
                    lblTotCircularIssued.Visible = true;
                    lblTotNoBidders.Visible = true;
                    txtCircular.Visible = true;
                    txt_bidders.Visible = true;
                } 

                if (_tndrType == "L" || _tndrType == "DO" || _tndrType == "P") // || _tndrType == "PT"
                {
                    _chGetShortListed = 'Y';
                    int _totShortListCount = clsForTS.GetShortListCount(_projID);
                    if (_totShortListCount != 0)
                    {
                        btnViewShortList.Visible = true;
                        lblCompaniesInShortList.Visible = true;
                        txtTotCompInShortList.Visible = true;
                        txtTotCompInShortList.Text = _totShortListCount.ToString();
                    }
                    else
                    {
                        btnViewShortList.Visible = false;
                        lblCompaniesInShortList.Visible = false;
                        txtTotCompInShortList.Visible = false;
                        txtTotCompInShortList.Visible = false;
                    }
                }

                int _circularCnt = clsForTS.GetCircularCount(_projID);

                txt_bidders.Text = _bidCnt.ToString();
                txtCircular.Text = _circularCnt.ToString();

                getEligibleTypes(ref isOnLoad);

                commCls.FillGridReceivedDocsInfo(_projID,ref dgvTS_Rec, 2);
                commCls.FillGridSentDocsInfo(_projID,ref dgvTS_Sent, 2);

                // Added by sreedhar on jan 26th 2014

                getData(ProjectId);

                if ((_userName.Equals("ceba_sjoy")) || (_userName.Equals("ceba_mfaisal")) || (_userName.Equals("ebsd_svadakapuram")) || (_userName.Equals("ceba_mriyas")))
                {
                    txtCmpType.Visible = true;
                    lbltype.Visible = true;
                    btnClk.Visible = true;
                }

            }
            else if (tabControl1.SelectedTab.Name == "teaTabPage")
            {
                EnableTabs_BasedOn_UserRights(); // Added by Varun on 6 Feb 2014 for checking if Tender_Status_id is (7,14,15) if yes then do not calculate and display expiry days

                TE_AdminRigts();
                saveTEAChk = false;

                if (!mCommitteeShortName.Equals("PQ"))
                {
                    FillCp_ContractsInformation();                 //Sree
                }
                else
                {
                    dgvCntrStage3.Visible = false;
                }
                saveTEAChk = FillTenderEvaluationInfo(ref dateID_TEA);
                FillProjectCostDetailsOfTenderEvaluation();
                GetTenderStageClosingDates();
                Get_original_TenderDates();
                if (msk_dtpEA_stage2.Text != "")
                {
                    btnTenderSubmissionStg2.Visible = true;
                }

                if (mUserRightsColl.Contains("70") && txtTenderNo.Text != "")
                {
                    btnTenderSubmissionStage1.Visible = false;
                }
                else if (!(mUserRightsColl.Contains("70")) && txtTenderNo.Text != "")
                {
                    btnTenderSubmissionStage1.Visible = true;
                    //btnWOTenderSubmission.Visible = true;
                }
                else if (mUserRightsColl.Count == 0 && txtTenderNo.Text != "") //Added by Varun on 16 May 2014 based on new TenderSubmission requirement                                 
                {
                    btnTenderSubmissionStage1.Visible = true;
                    //btnWOTenderSubmission.Visible = true;
                }
                else
                {
                    btnTenderSubmissionStage1.Visible = false;
                }
                //if ((msk_dtpEA_stage1.Text != "" && Convert.ToDateTime(msk_dtpEA_stage1.Text) <= Convert.ToDateTime(DateTime.Now.ToShortDateString())) || (msk_dtpEA_closeDate.Text != "" && Convert.ToDateTime(msk_dtpEA_closeDate.Text) <= Convert.ToDateTime(DateTime.Now.ToShortDateString())))



                if (isCpContractorSign == false)
                {
                    GetExtendDates();   // Function read Validate extend dates                     
                    TE_Validate(tndrDate_ID);
                    //GetTenderExpiryDays_UpdateDays(tndrDate_ID);
                }
                //Get_original_TenderDates();

                commCls.FillGridReceivedDocsInfo(_projID,ref dgvTE_Rec, 3);
                commCls.FillGridSentDocsInfo(_projID,ref dgvTE_Sent, 3);

            }
            else if (tabControl1.SelectedTab.Name == "cpTabPage")
            {
                CP_AdminRights();
                FillContractsProcessData();
                commCls.FillGridReceivedDocsInfo(_projID,ref dgvCP_Rec, 4);
                commCls.FillGridSentDocsInfo(_projID,ref dgvCP_Sent, 4);
                FillProjectCostDetailsOfContractProcess();

            }
            else if (tabControl1.SelectedTab.Name == "pcsTabPage")
            {
                PC_AdminRights();
                if (dgvPC_Contracts.ColumnCount > 0)
                    clspC.refreshPCContracts_Data(dgvPC_Contracts, _projID);
                else
                    clspC.FillPostContractInformation(dgvPC_Contracts, _projID);

                if (dgvPC.ColumnCount == 0)
                {
                    clspC.CreatePostContractGridColumns(dgvPC);
                    clspC.FillPostContractsData(dgvPC, _projID);
                }
                else
                    clspC.FillPostContractsData(dgvPC, _projID);


                //if (dgvPC.Rows.Count != 0)
                //txtPC_Remarks.Text = dgvPC.Rows[0].Cells[3].Value.ToString();

                dgvPC_Contracts.Columns[8].Visible = false;

                FillProjectCostDetailsOfPostContract();
            }
        }

        string mdfExistDate = string.Empty;

        private void tabControl1_MouseClick(object sender, MouseEventArgs e)           //sree
        {
            PopulatingVariousStagesTabControlsOfProject();
        }

        int tndrDate_ID = 0;
        private void Get_original_TenderDates()
        {
            // if (msk_dtpTV_OrgDate.Text != "")

            DateTime? validityDate;
            validityDate = null;

            DateTime? bondValidityDate;
            bondValidityDate = null;

            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {

                sqlConn.Open();
                SqlCommand sqlCom = new SqlCommand("SELECT org_tender_validity,org_tenderbond_validity,date_ID FROM TenderDatesInfo Where proj_id = " + _projID + " and stage_id = 2 and ts_tender_issue is null", sqlConn);
                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    if (sqlReader.HasRows)
                    {
                        while (sqlReader.Read())
                        {
                            if (sqlReader[0].ToString() != "")
                            {
                                validityDate = Convert.ToDateTime(sqlReader[0].ToString());
                                msk_dtpTV_OrgDate.Text = validityDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture);
                                //msk_dtpTV_FEdate.Text = dt_dtpEA_TV_FstExt.ToString("dd/MMM/yyyy");
                            }
                            if (sqlReader[1].ToString() != "")
                            {
                                bondValidityDate = Convert.ToDateTime(sqlReader[1].ToString());
                                msk_dtpTBV_OrgDate.Text = bondValidityDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture);
                            }

                            tndrDate_ID = Convert.ToInt16(sqlReader[2].ToString());
                        }
                    }
                }
            }
            // Delete the code which will update the tender bond validity dates, because not required to retrieve and then update by Varun 5 Feb 2014

        }
        private void Update_tenderValidityDate(int _dateID_vldty)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"UPDATE TenderDatesInfo SET [org_tender_validity]= @originalValidityDate Where date_id=@dateId";
                        cmd.Parameters.AddWithValue("@dateId", _dateID_vldty);
                        cmd.Parameters.AddWithValue("@originalValidityDate", Convert.ToDateTime(msk_dtpTV_OrgDate.Text));
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void Update_tender_BondValidityDate(int _dateID_Bondvldty)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"UPDATE TenderDatesInfo SET [org_tenderbond_validity]= @originalBondValidityDate Where date_id=@dateId";
                        cmd.Parameters.AddWithValue("@dateId", _dateID_Bondvldty);
                        cmd.Parameters.AddWithValue("@originalBondValidityDate", Convert.ToDateTime(msk_dtpTBV_OrgDate.Text));
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void GetExtendDates()
        {
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                sqlConn.Open();
                SqlCommand sqlCom = new SqlCommand("SELECT tender_validity_ext1,tender_validity_ext2,tenderbond_validity_ext1,tenderbond_validity_ext2 FROM TenderDatesInfo Where proj_id = " + _projID + " and stage_id = 2 and ts_tender_issue is null", sqlConn);
                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    if (sqlReader.HasRows)
                    {
                        while (sqlReader.Read())
                        {
                            if (sqlReader[0].ToString() != "")
                            {
                                DateTime dt_dtpEA_TV_FstExt = Convert.ToDateTime(sqlReader[0].ToString());
                                msk_dtpTV_FEdate.Text = dt_dtpEA_TV_FstExt.ToString("dd/MMM/yyyy");
                            }
                            if (sqlReader[1].ToString() != "")
                            {
                                DateTime dt_dtpEA_TV_LstExt = Convert.ToDateTime(sqlReader[1].ToString());
                                msk_dtpTV_SEdate.Text = dt_dtpEA_TV_LstExt.ToString("dd/MMM/yyyy");
                            }
                            if (sqlReader[2].ToString() != "")
                            {
                                DateTime dt_dtpEA_TBV_FstExt = Convert.ToDateTime(sqlReader[2].ToString());
                                msk_dtpTBV_FEdate.Text = dt_dtpEA_TBV_FstExt.ToString("dd/MMM/yyyy");
                            }
                            if (sqlReader[3].ToString() != "")
                            {
                                DateTime dt_dtpEA_TBV_LstExt = Convert.ToDateTime(sqlReader[3].ToString());
                                msk_dtpTBV_SEdate.Text = dt_dtpEA_TBV_LstExt.ToString("dd/MMM/yyyy");
                            }
                        }
                    }
                }
            }
        }


        private void GetTenderExpiryDays_UpdateDays(int dateID)
        {
            if (msk_dtpTV_OrgDate.Text != "" && isCpContractorSign == false)
            {
                // Modified by Varun on 05 Feb 2014 because txtTBV_exipre.Text==""
                if (txtTBV_exipre.Text != "")
                {
                    int expiryDays = Convert.ToInt16(txtTV_exipre.Text);
                    // modified function params by Varun on 05 Feb 2014 because projId not required
                    // commented by varun on 5 Feb 2014 because no need to update immediately after retrieving
                    clsForTS.UpdateTV_Original_Extension(expiryDays, dateID);
                }

            }
            if (msk_dtpTBV_OrgDate.Text != "" && isCpContractorSign == false)
            {
                // Modified by Varun on 05 Feb 2014 because txtTBV_exipre.Text==""
                if (txtTBV_exipre.Text != "")
                {
                    int bond_ExpiryDays = Convert.ToInt16(txtTBV_exipre.Text);
                    // modified function params by Varun on 05 Feb 2014 because projId not required
                    // commented by varun on 5 Feb 2014 because no need to update immediately after retrieving
                    clsForTS.UpdateTBV_Original_Extension(bond_ExpiryDays, dateID);
                }
            }
        }




        private void txtTenderBond_Leave(object sender, EventArgs e)
        {
            if (txtTenderBond.Text != "")
            {
                if (clsForTE.CheckProjectCostDataExist(_projID) == false)
                {
                    clsForTS.InsertTS_TenderBond_ProjectCostData(txtTenderBond.Text, _projID);
                }
                else
                {
                    clsForTS.UpdateTS_TenderBond_ProjectCostData(txtTenderBond.Text, _projID);
                }
                txtTenderBond.Text = string.Format("{0:#,##0.00}", double.Parse(txtTenderBond.Text));
            }
            else
            {
                clsForTS.UpdateTS_TenderBond_ProjectCostData(txtTenderBond.Text, _projID);
            }
        }


        private void txtDocumentFree_Leave(object sender, EventArgs e)
        {
            if (txtDocumentFee.Text != "")
            {
                if (clsForTE.CheckProjectCostDataExist(_projID) == false)
                {
                    clsForTS.InsertTS_DocFee_ProjectCostData(txtDocumentFee.Text, _projID);
                }
                else
                {
                    clsForTS.UpdateTS_DocFee_ProjectCostData(txtDocumentFee.Text, _projID);
                }
                txtDocumentFee.Text = string.Format("{0:#,##0.00}", double.Parse(txtDocumentFee.Text));
            }
            else
                clsForTS.UpdateTS_DocFee_ProjectCostData(txtDocumentFee.Text, _projID);
        }



        private bool nonNumberEntered = false;

        private void btnPC_Click(object sender, EventArgs e)
        {

            if (mUserRightsColl.Contains("52"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            //Added by Varun on 27 Dec 2015
            if (dgvPC.Rows[0].Cells[0].Value != null)
                fillStage6(); // For PostContract Stage                       
            else
                MessageBox.Show("Staff Incharge cannot be left blank");

        }

        private void txtPC_BudjetAmnt_Leave(object sender, EventArgs e)
        {
            if (txtPC_BudjetAmnt.Text != "")
            {
                if (clsForTE.CheckProjectCostDataExist(_projID) == false)
                {
                    clsForTE.InsertTE_Budget_ProjectCostData(txtPC_BudjetAmnt.Text, _projID);
                }
                else
                {
                    clsForTE.UpdateTE_BudgetAmount_ProjectCostData(txtPC_BudjetAmnt.Text, _projID);
                }
                txtPC_BudjetAmnt.Text = string.Format("{0:#,##0.00}", double.Parse(txtPC_BudjetAmnt.Text));
            }
            else
                clsForTE.UpdateTE_BudgetAmount_ProjectCostData(txtPC_BudjetAmnt.Text, _projID);
        }
        private void txtPC_EstimatedAmnt_Leave(object sender, EventArgs e)
        {
            if (txtPC_EstimatedAmnt.Text != "")
            {
                if (clsForTE.CheckProjectCostDataExist(_projID) == false)
                {
                    clsForTE.InsertTE_Estimate_ProjectCostData(txtPC_EstimatedAmnt.Text, _projID);
                }
                else
                {
                    clsForTE.UpdateTE_Estimate_ProjectCostData(txtPC_EstimatedAmnt.Text, _projID);
                }
                txtPC_EstimatedAmnt.Text = string.Format("{0:#,##0.00}", double.Parse(txtPC_EstimatedAmnt.Text));
            }
            else
                clsForTE.UpdateTE_Estimate_ProjectCostData(txtPC_EstimatedAmnt.Text, _projID);
        }
        private void btnRecCp_Click(object sender, EventArgs e)
        {
            if (_profileName != "VIEW ALL")
            {
                if (mUserRightsColl.Contains("19"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }
                ReceivedDocProperties receivedDoc = new ReceivedDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), 4, _userName);
                receivedDoc.StartPosition = FormStartPosition.CenterParent;
                receivedDoc.ShowDialog();
                commCls.FillGridReceivedDocsInfo(Convert.ToInt16(lblProjID.Text), ref dgvCP_Rec, 4);
            }
        }
        private void btnSentCp_Click(object sender, EventArgs e)
        {
            if (_profileName != "VIEW ALL")
            {
                if (mUserRightsColl.Contains("19"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }
                SentDocProperties sentDocProp = new SentDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), 4, _userName);
                sentDocProp.StartPosition = FormStartPosition.CenterParent;
                sentDocProp.ShowDialog();
                commCls.FillGridSentDocsInfo(Convert.ToInt16(lblProjID.Text),ref dgvCP_Sent, 4);
            }
        }

        private void txtCp_BudgetAmnt_Leave(object sender, EventArgs e)
        {
            if (txtCp_BudgetAmnt.Text != "")
            {
                if (clsForTE.CheckProjectCostDataExist(_projID) == false)
                {
                    clsForTE.InsertTE_Budget_ProjectCostData(txtCp_BudgetAmnt.Text, _projID);
                }
                else
                {
                    clsForTE.UpdateTE_BudgetAmount_ProjectCostData(txtCp_BudgetAmnt.Text, _projID);
                }
                txtCp_BudgetAmnt.Text = string.Format("{0:#,##0.00}", double.Parse(txtCp_BudgetAmnt.Text));
            }
            else
                clsForTE.UpdateTE_BudgetAmount_ProjectCostData(txtCp_BudgetAmnt.Text, _projID);
        }
        private void txtCp_EstimatedAmnt_Leave(object sender, EventArgs e)
        {
            if (txtCp_EstimatedAmnt.Text != "")
            {
                if (clsForTE.CheckProjectCostDataExist(_projID) == false)
                {
                    clsForTE.InsertTE_Estimate_ProjectCostData(txtCp_EstimatedAmnt.Text, _projID);
                }
                else
                {
                    clsForTE.UpdateTE_Estimate_ProjectCostData(txtCp_EstimatedAmnt.Text, _projID);
                }
                txtCp_EstimatedAmnt.Text = string.Format("{0:#,##0.00}", double.Parse(txtCp_EstimatedAmnt.Text));
            }
            else
                clsForTE.UpdateTE_Estimate_ProjectCostData(txtCp_EstimatedAmnt.Text, _projID);
        }

        #region           // For PostContracts Data

        private void FillPostContractStaffData()
        {
            DataSet ds = new DataSet();
            string strQuery = "";
            strQuery = "Select employee_id,ShortName From Contacts Where ShortName <> '' order by shortname asc";
            try
            {
                using (SqlConnection sqlCn = new SqlConnection(connStr))
                {
                    sqlCn.Open();
                    using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                    {
                        SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                        sqlda.Fill(ds);
                    }
                }
            }
            catch (Exception ex)
            {

            }
            DataGridViewComboBoxColumn colCboxCategory = new DataGridViewComboBoxColumn();
            colCboxCategory.HeaderText = "Successfull Bidder";
            colCboxCategory.Width = 90;
            colCboxCategory.Name = "colBoc";
            colCboxCategory.DataSource = ds.Tables[0];
            colCboxCategory.ValueMember = "ShortName";
            colCboxCategory.DisplayMember = "ShortName";

            dgvPC.Columns.Add(colCboxCategory);

            CalendarColumn colFromDate = new CalendarColumn();
            colFromDate.HeaderText = "From Date";
            this.dgvPC.Columns.Add(colFromDate);

            CalendarColumn colTodDate = new CalendarColumn();
            colTodDate.HeaderText = "To Date";
            this.dgvPC.Columns.Add(colTodDate);

            DataSet ds1 = new DataSet();
            string strQuery1 = "";
            strQuery1 = "Select StaffInCharge,FromDate,ToDate From TenderDatesInfo Where Proj_ID = " + _projID + " and Stage_ID= 6 and employee_id IS NOT NULL";
            try
            {
                using (SqlConnection sqlCn = new SqlConnection(connStr))
                {
                    sqlCn.Open();
                    using (SqlCommand sqlCmd = new SqlCommand(strQuery1, sqlCn))
                    {
                        SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);

                        sqlda.Fill(ds1);
                    }
                }
            }
            catch (Exception ex)
            {

            }
            dgvPC.AllowUserToAddRows = false;

            dgvPC.Columns[0].DataPropertyName = "StaffIncharge";
            dgvPC.Columns[1].DataPropertyName = "FromDate";
            dgvPC.Columns[2].DataPropertyName = "ToDate";

            //  dataGridView1.Columns[3].DataPropertyName = "bidder_id";
            dgvPC.DataSource = ds1.Tables[0];
        }
        void dgvPC_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            e.Cancel = true;
        }
        private void txtPC_BudjetAmnt_KeyDown(object sender, KeyEventArgs e)
        {
            nonNumberEntered = false;
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            {
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    if ((e.KeyCode != Keys.Back) & (e.KeyCode != Keys.Enter))
                    {
                        nonNumberEntered = true;
                    }
                }
            }


            //nonNumberEntered = false;
            //if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            //{
            //    if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
            //    {
            //        if ((e.KeyCode != Keys.Back) & (e.KeyCode != Keys.Enter))
            //        {
            //            nonNumberEntered = true;
            //        }
            //    }
            //}
        }

        private void txtPC_EstimatedAmnt_KeyDown(object sender, KeyEventArgs e)
        {
            nonNumberEntered = false;
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            {
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    if ((e.KeyCode != Keys.Back) & (e.KeyCode != Keys.Enter))
                    {
                        nonNumberEntered = true;
                    }
                }
            }
        }

        #endregion

        private void txtBudjetAmnt_KeyDown(object sender, KeyPressEventArgs e)
        {

            nonNumberEntered = false;


            //if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            //{
            //    if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
            //    {
            //        if ((e.KeyCode != Keys.Back) & (e.KeyCode != Keys.Enter) & e.KeyValue == 190)
            //        {
            //            nonNumberEntered = true;
            //        }
            //    }
            //}

            //if (txtBudjetAmnt.Text != "")
            //{
            //    Regex re = new Regex(@"^(0|(-?(((0|[1-9]\d*)\.\d+)|([1-9]\d*))))$");
            //    if (re.IsMatch(txtBudjetAmnt.Text) == false)
            //    {
            //        MessageBox.Show("Please enter double value only");
            //        txtBudjetAmnt.Text = "";
            //    }
            //}
        }


        # region

        // ================ Contract Process Tab Data Function==============================================================================================


        private void Status_ContractProcess()
        {
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    if (sqlConn.State == ConnectionState.Closed)
                        sqlConn.Open();
                    cmd.Connection = sqlConn;
                    cmd.CommandText = @"Update Projects set Tender_Status_id = @status,stage_id = @stgID where proj_id=@projId";
                    cmd.Parameters.AddWithValue("@projId", Convert.ToInt16(lblProjID.Text));
                    cmd.Parameters.AddWithValue("@status", 7);
                    cmd.Parameters.AddWithValue("@stgID", 4);

                    cmd.Parameters.AddWithValue("@update_date", DateTime.Now.ToString());
                    //cmd.Parameters.AddWithValue("@update_user", "");

                    int exUpdated = cmd.ExecuteNonQuery();

                    cmd.Parameters.Clear();
                }
            }
        }

        private void btnCP_Save_Click(object sender, EventArgs e)
        {
            // CPMultipleRecords_InsertUpdate();
            //CP_Contract_InsertUpdate(dgvContracts);
            CommonClass commCls = null;
            if (mUserRightsColl.Contains("48") && mUserRightsColl.Contains("50"))     // 50 for DA
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            if (dgvContracts.Rows[0].Cells[0].Value == null)
                return;
            if (dgvCpDataEntry.Rows[0].Cells[0].Value == null)
                return;

            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        if (sqlConn.State == ConnectionState.Closed)
                            sqlConn.Open();
                        cmd.Connection = sqlConn;
                        clsForCP.UpdateContractsData(dgvContracts, cmd, sqlConn, ProjectId);

                        clsForCP.UpdateContractsMultipleData(dgvCpDataEntry, dgvContracts, cmd, sqlConn, ProjectId, lblContractNoDisplay);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while performing operation with the database.", ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            int stsID = getStatusID(ProjectId);
            Boolean chkCommit = false;
            Boolean chkStatus = false;
            foreach (DataGridViewRow row in this.dgvCpDataEntry.Rows)
            {
                if (row.Cells[7].Value != null || row.Cells[7].Value.ToString() != "")
                {
                    string strVal = row.Cells[7].Value.ToString();
                    if (strVal != "")
                    {
                        if (!cmbTenderStatus.Text.Equals("Committed"))
                        {
                            clsForCP.Status_Commit(7, ProjectId.ToString());
                            // added by Varun on 11/05/2015
                            FillProjectInfo();
                        }
                        else
                        {
                            chkCommit = true;  // committed
                            commCls = new CommonClass(_userName);
                            commCls.DisplayContractNumber(lblContractNoDisplay, lblContractNo, btnWorkOrder, btnWorkOrder2, _projID);
                        }

                        return;
                    }
                    else
                    {
                        string cellVal2 = string.Empty; string cellVal3 = string.Empty; string cellVal4 = string.Empty; string cellVal1 = string.Empty;
                        cellVal2 = row.Cells[2].Value.ToString();
                        cellVal3 = row.Cells[3].Value.ToString();
                        cellVal4 = row.Cells[4].Value.ToString();
                        cellVal1 = row.Cells[1].Value.ToString();

                        if (cellVal2 != "" || cellVal3 != "" || cellVal4 != "")
                        {
                            if (stsID <= 15)
                            {
                                clsForCP.Status_Commit(15, ProjectId.ToString());
                                chkStatus = true;
                                // added by Varun on 11/05/2015
                                FillProjectInfo();
                            }
                        }
                        else if (cellVal1 != "")
                        {
                            if (stsID <= 14)
                            {
                                clsForCP.Status_Commit(14, ProjectId.ToString());
                                chkStatus = true;
                                // added by Varun on 11/05/2015
                                FillProjectInfo();
                            }
                        }
                    }
                }

            }
            foreach (DataGridViewRow row in this.dgvContracts.Rows)
            {
                string cellVal7 = string.Empty; string cellVal5 = string.Empty;
                cellVal7 = row.Cells[7].Value.ToString();
                cellVal5 = row.Cells[5].Value.ToString();

                if (chkCommit == false)
                {
                    if (chkStatus == false)
                    {
                        if (cellVal7 != "")
                        {
                            if (stsID <= 13)
                            {
                                clsForCP.Status_Commit(13, ProjectId.ToString());
                                // added by Varun on 11/05/2015
                                FillProjectInfo();
                            }
                        }
                        else if (cellVal5 != "")
                        {
                            if (stsID <= 12)
                            {
                                clsForCP.Status_Commit(12, ProjectId.ToString());
                                // added by Varun on 11/05/2015
                                FillProjectInfo();
                            }
                        }
                    }
                }
            }
            commCls = new CommonClass(_userName);
            commCls.DisplayContractNumber(lblContractNoDisplay, lblContractNo, btnWorkOrder,btnWorkOrder2, _projID);

        }

        private void FillContractsProcessData()
        {
            //Added by Varun for clearing the rows
            //dgvContracts.Rows.Clear();
            //dgvContracts.AllowUserToAddRows = false;

            if (dgvContracts.ColumnCount == 0)
            {
                clsForCP.CreateColumnsForCP_Contractors(ref dgvContracts, _projID);
            }

            clsForCP.FillContractsGrid(ref dgvContracts, _projID);


            if (dgvCpDataEntry.ColumnCount == 0)
            {
                clsForCP.CreateColumnsForCP_ContractorsMultiple(dgvCpDataEntry, _projID);
            }
            clsForCP.FillContractsGrid_Multiple(dgvCpDataEntry, _projID);

            //dgvCpDataEntry.AllowUserToAddRows = false;
        }
        //public void FillCP_ContractsGrid(DataGridView dgvCpDataEntry, int cp_PrjID)
        //{
        //    if (dgvCpDataEntry.ColumnCount == 0)
        //        CreateColumnsForCP_ContractsData(dgvCpDataEntry);

        //    string strQuery = "";
        //    strQuery = "SELECT COMPANY.co_name,TenderDatesInfo.cp_sent_dep_sign, TenderDatesInfo.cp_receive_dep_sent_prsd, TenderDatesInfo.cp_sent_fd_commit, " +
        //               " TenderDatesInfo.cp_receive_fd_commit, TenderDatesInfo.cp_distribution, TenderDatesInfo.remarks, TenderDatesInfo.StaffInCharge AS staff, " +
        //               " TenderDatesInfo.date_id, TenderDatesInfo.cp_received_of_doc, TenderDatesInfo.cp_request_start_date, TenderDatesInfo.cp_start_date_receive, " +
        //               " TenderDatesInfo.cp_notice_contractor_to_sign, TenderDatesInfo.cp_due_date_pb, TenderDatesInfo.Tndr_BidID, TenderDatesInfo.Tndr_BidName " +
        //               " FROM  TenderDatesInfo INNER JOIN COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id INNER JOIN " +
        //               " CONTRACTORS ON TenderDatesInfo.Tndr_BidID = CONTRACTORS.bidder_id WHERE (TenderDatesInfo.proj_id = " + cp_PrjID + ") AND (TenderDatesInfo.stage_id = 4)";

        //    //strQuery = "select cp_sent_dep_sign,cp_receive_dep_sent_prsd,cp_sent_fd_commit,cp_receive_fd_commit,cp_distribution,remarks," +
        //    //    " [StaffInCharge] as staff,date_id,cp_received_of_doc,cp_request_start_date,cp_start_date_receive,cp_notice_contractor_to_sign, " +
        //    //" cp_due_date_pb,Tndr_BidID,Tndr_BidName from TenderDatesInfo WHERE (proj_id = " + cp_PrjID + ") AND (stage_id = 4)";

        //    using (SqlConnection sqlCn = new SqlConnection(connStr))
        //    {
        //        sqlCn.Open();
        //        using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
        //        {
        //            SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
        //            DataSet ds = new DataSet();
        //            sqlda.Fill(ds);
        //            dgvCpDataEntry.AllowUserToAddRows = false;

        //            dgvCpDataEntry.Columns[0].DataPropertyName = "Tndr_Bidname";
        //            dgvCpDataEntry.Columns[1].DataPropertyName = "cp_sent_dep_sign";
        //            dgvCpDataEntry.Columns[2].DataPropertyName = "cp_receive_dep_sent_prsd";
        //            dgvCpDataEntry.Columns[3].DataPropertyName = "cp_sent_fd_commit";
        //            dgvCpDataEntry.Columns[4].DataPropertyName = "cp_receive_fd_commit";
        //            dgvCpDataEntry.Columns[5].DataPropertyName = "cp_distribution";
        //            dgvCpDataEntry.Columns[6].DataPropertyName = "remarks";
        //            dgvCpDataEntry.Columns[7].DataPropertyName = "staff";
        //            dgvCpDataEntry.Columns[8].DataPropertyName = "date_id";

        //            dgvCpDataEntry.Columns[9].DataPropertyName = "cp_received_of_doc";
        //            dgvCpDataEntry.Columns[10].DataPropertyName = "cp_request_start_date";
        //            dgvCpDataEntry.Columns[11].DataPropertyName = "cp_start_date_receive";
        //            dgvCpDataEntry.Columns[12].DataPropertyName = "cp_notice_contractor_to_sign";
        //            dgvCpDataEntry.Columns[13].DataPropertyName = "cp_due_date_pb";
        //            dgvCpDataEntry.Columns[14].DataPropertyName = "Tndr_BidID";


        //            dgvCpDataEntry.DataSource = ds.Tables[0];
        //            dgvCpDataEntry.AllowUserToAddRows = true;
        //        }
        //        sqlCn.Close();
        //    }

        //    dgvCpDataEntry.Columns[7].Visible = false;


        //    try
        //    {
        //        for (int i = 0; i < dgvCpDataEntry.Rows.Count; i++)
        //        {
        //            if (i == (dgvCpDataEntry.Rows.Count - 1))
        //            {
        //                dgvCpDataEntry.Rows[i].Cells[1].Value = "";
        //                dgvCpDataEntry.Rows[i].Cells[2].Value = "";
        //                dgvCpDataEntry.Rows[i].Cells[3].Value = "";
        //                dgvCpDataEntry.Rows[i].Cells[4].Value = "";
        //                dgvCpDataEntry.Rows[i].Cells[5].Value = "";

        //                // dgvCpDataEntry.Rows[i].Cells[5].Value = "";

        //                dgvCpDataEntry.Rows[i].Cells[7].Value = "";
        //                dgvCpDataEntry.Rows[i].Cells[8].Value = "";
        //                dgvCpDataEntry.Rows[i].Cells[9].Value = "";
        //                dgvCpDataEntry.Rows[i].Cells[10].Value = "";
        //                dgvCpDataEntry.Rows[i].Cells[11].Value = "";

        //                dgvCpDataEntry.Rows[i].Cells[12].Value = "";
        //                dgvCpDataEntry.Rows[i].Cells[13].Value = "";
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }
        //}


        //clsCP_Stage clsCp = new clsCP_Stage("", mIsHeadOfSection);
        private void CPMultipleRecords_InsertUpdate()
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        if (sqlConn.State == ConnectionState.Closed)
                            sqlConn.Open();
                        cmd.Connection = sqlConn;

                        clsForCP.CPMultipleRecords_Insert_Update(dgvCpDataEntry, sqlConn, cmd, _projID);

                        // MessageBox.Show("Contract Process data added Succesfully");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE DATES StaffIncharge records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            clsForCP.FillCP_MultiplerecordsDara(dgvCpDataEntry, _projID);      //DataGridView dgvCpDataEntry,int cp_PrjID
        }
        private void FillCp_ContractsInformation()
        {
            //Modified By Varun on 16 Feb 2014
            dgvCntrStage3.Columns.Clear();
            //if (dgvCntrStage3.Columns.Count == 0)

            clsForCP.CreateColumnsForCP_Contracors_TE(dgvCntrStage3, _projID);
            //clsForCP.CreateColumnsForCP_Contracors(dgvContractsTemp, _projID);
            //FillCP_ContractsData();
            clsForCP.FillContractsGrid_TE(dgvCntrStage3, _projID, 0);
            dgvCntrStage3.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
        }
        private void CP_Contract_InsertUpdate(DataGridView dgvCntr, bool isHeadOfSection)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        if (sqlConn.State == ConnectionState.Closed)
                            sqlConn.Open();
                        cmd.Connection = sqlConn;
                        clsForCP.CP_Contracts_Insert_UpdateData(dgvCntr, cmd, _projID, isHeadOfSection);
                        //tabControl1.TabPages[3].Focus();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the Contracts records, Try again.", ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void dgvCP_Rec_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (mUserRightsColl.Contains("20"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            int rowIndex = e.RowIndex;
            try
            {
                if (rowIndex != -1)
                {
                    if (dgvCP_Rec.Rows[rowIndex].Cells[3].Value.ToString() != "")
                    {
                        int docId = Convert.ToInt32(dgvCP_Rec.Rows[rowIndex].Cells[3].Value);
                        ReceivedDocProperties receivedDoc = new ReceivedDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), txtProjCode.Text, docId, 4, _userName);
                        receivedDoc.StartPosition = FormStartPosition.CenterParent;
                        receivedDoc.ShowDialog();

                        commCls.FillGridReceivedDocsInfo(Convert.ToInt16(lblProjID.Text),ref dgvCP_Rec, 4);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void txtDA_BdjtAmnt_KeyDown(object sender, KeyEventArgs e)
        {
            nonNumberEntered = false;
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            {
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    if ((e.KeyCode != Keys.Back) & (e.KeyCode != Keys.Enter))
                    {
                        nonNumberEntered = true;
                    }
                }
            }
        }
        private void txtDA_EstimateAmnt_KeyDown(object sender, KeyEventArgs e)
        {
            nonNumberEntered = false;
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            {
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    if ((e.KeyCode != Keys.Back) & (e.KeyCode != Keys.Enter))
                    {
                        nonNumberEntered = true;
                    }
                }
            }
        }
        private void txtCp_BudgetAmnt_KeyDown(object sender, KeyEventArgs e)
        {
            nonNumberEntered = false;
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            {
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    if ((e.KeyCode != Keys.Back) & (e.KeyCode != Keys.Enter))
                    {
                        nonNumberEntered = true;
                    }
                }
            }
        }
        private void txtCp_EstimatedAmnt_KeyDown(object sender, KeyEventArgs e)
        {
            nonNumberEntered = false;
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            {
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    if ((e.KeyCode != Keys.Back) & (e.KeyCode != Keys.Enter))
                    {
                        nonNumberEntered = true;
                    }
                }
            }
        }
        //Added By Varun
        //private void dgvContracts_CellValidated(object sender, DataGridViewCellEventArgs e)
        //{
        //    // the cells under the column of index 1 are going to display
        //    //the property of a complex type
        //    if (dgvContracts.CurrentCell.GetType() == typeof(DataGridViewComboBoxCell))
        //    {
        //        DataGridViewCell cell =
        //        dgvContracts.Rows[e.RowIndex].Cells[e.ColumnIndex];
        //        cell.Value = newEnteredValue;
        //        cell.Selected = true;
        //        dgvContracts.CurrentCell.DataGridView.EndEdit(DataGridViewDataErrorContexts.Commit);
        //    }
        //}
        //Object newEnteredValue = null;
        //private void dgvContracts_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        //{
        //    if (e.ColumnIndex == 3)
        //    {
        //        if (dgvContracts.CurrentCell.IsInEditMode)
        //        {
        //            if (dgvContracts.CurrentCell.GetType() ==
        //            typeof(DataGridViewComboBoxCell))
        //            {
        //                DataGridViewComboBoxCell cell =
        //                (DataGridViewComboBoxCell)dgvContracts.Rows[e.RowIndex].Cells[e.ColumnIndex];
        //                cell.Items.Add(e.FormattedValue);
        //                cell.Selected = true;
        //                newEnteredValue = e.FormattedValue;

        //            }
        //        }
        //    }
        //}

        //void combo_ConfirmSelectionChange(object sender, EventArgs e)
        //{
        //if (dgvCpDataEntry.CurrentCell.ColumnIndex != col_ConfirmCmb.Index) return;

        //ComboBox combo = sender as ComboBox;
        //if (combo == null) return;

        //MessageBox.Show(combo.SelectedText);// returns Null for the first time
        //}
        //private void dgvContracts_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        //{
        //    ////if (e.Control is ComboBox)
        //    ////{
        //    ////    ComboBox comboBox = e.Control as ComboBox;
        //    ////    comboBox.SelectedIndexChanged += LastColumnComboSelectionChanged;
        //    ////}
        //}
        //private void LastColumnComboSelectionChanged(object sender, EventArgs e)
        //{   
        //    var currentcell = dgvContracts.CurrentCellAddress;
        //    var sendingCB = sender as DataGridViewComboBoxEditingControl;
        //    DataGridViewComboBoxCell cel = (DataGridViewComboBoxCell)dgvContracts.Rows[currentcell.Y].Cells[0];
        //    if (sendingCB.SelectedValue != null)
        //    {
        //        cel.Value = sendingCB.SelectedValue.ToString();
        //        if (cel.Value.ToString() != "" & cel.Value.ToString() != "System.Data.DataRowView")
        //        {
        //            string _cmpName = FilldgvComboValue(Convert.ToInt16(cel.Value));

        //            dgvContracts.Rows[currentcell.Y].Cells[1].Value = _cmpName;
        //        }
        //    }

        //   // DataGridViewTextBoxCell celText = (DataGridViewTextBoxCell)dgvContracts.Rows[currentcell.Y].Cells[1];

        //}

        //int iCnt = 0;
        //private void dgvContracts_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        //{
        //    iCnt = iCnt + 1;
        //    DataGridView dgv = sender as DataGridView;


        //    if (dgv.CurrentCell != null)
        //    {

        //        if (dgv.CurrentCell.ColumnIndex == 0)
        //        {
        //            // ComboBox comboBox = e.Control as ComboBox;
        //            if (e.RowIndex >= 0) //check if combobox column
        //            {
        //                object selectedValue = dgvContracts.Rows[dgv.CurrentCell.RowIndex].Cells[dgv.CurrentCell.ColumnIndex].Value;

        //                if (selectedValue is int)
        //                {

        //                    string _cmpName = clsForCP.FillComapany_dgvComboValue(Convert.ToInt16(selectedValue));

        //                    dgvContracts.Rows[dgv.CurrentCell.RowIndex].Cells[dgv.CurrentCell.ColumnIndex + 1].Value = _cmpName;


        //                }
        //            }
        //        }

        //    }

        //}


        private void dgvContracts_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {

            //Commented By Varun
            //if (dgvContracts.IsCurrentCellDirty)
            //{
            //    dgvContracts.CommitEdit(DataGridViewDataErrorContexts.Commit);
            //}

            //Added By Varun
            DataGridViewColumn col = dgvContracts.Columns[dgvContracts.CurrentCell.ColumnIndex];
            if (col is DataGridViewComboBoxColumn)
            {
                dgvContracts.CommitEdit(DataGridViewDataErrorContexts.Commit);
            }
        }

        private void dgvContracts_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            //ComboBox cb = e.Control as ComboBox;
            //if (cb != null)
            //{
            //    // first remove event handler to keep from attaching multiple:
            //    cb.SelectedIndexChanged -= new EventHandler(cb_SelectedIndexChanged);

            //    // now attach the event handler
            //    cb.SelectedIndexChanged += new EventHandler(cb_SelectedIndexChanged);
            //}


            //Added By Varun
            ComboBox cb = e.Control as ComboBox;
            if (cb != null)
            {
                ComboBox comboBox = e.Control as ComboBox;
                if (comboBox != null)
                {
                    ((ComboBox)e.Control).DropDownStyle = ComboBoxStyle.DropDown;
                    return;
                }
            }
        }

        void cb_SelectedIndexChanged(object sender, EventArgs e)
        {
            // MessageBox.Show("Selected index changed");
        }

        #endregion

        char chProjTransfered = ' ';
        public char ProjTransferedToComm
        {
            get { return chProjTransfered; }
            set { chProjTransfered = value; }
        }

        char chProjReTendered = ' ';
        public char ProjReTendered
        {
            get { return chProjReTendered; }
            set { chProjReTendered = value; }
        }

        private void cmbTenderStatus_SelectionChangeCommitted(object sender, EventArgs e)
        {
            chkOnHold = false;

            if (cmbTenderStatus.SelectedValue.ToString() == "10")           // Transferred To Other Committee
            {
                if (txtTenderNo.Text != "")
                {
                    //if (_cmtName.Equals("EUWC"))
                    //{
                    //    MessageBox.Show("Not Transferable");
                    //    return;
                    //}                    
                    //else 
                    if (_cmtName.Equals("NC"))
                    {
                        MessageBox.Show("Not Transferable");
                        return;
                    }
                    frmTransforProject transforProject = new frmTransforProject(_projID, _tndrType, _cmtName, mUserRightsColl, cmbTenderStatus.SelectedValue.ToString(), txtProjCode.Text, txtTenderNo.Text, _userName, _fiscalYear, txtproj.Text);
                    transforProject.StartPosition = FormStartPosition.CenterParent;
                    transforProject.ShowDialog();
                    chkProjectTrnsfor = true;
                    ProjTransferedToComm = transforProject.ProjTransfered;

                    //Updated by Varun
                    if (ProjTransferedToComm == 'Y')
                    {
                        ProjectId = transforProject.GetNewProjId();
                        this.Close();
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Tender Status. Tender No. is not yet assigned for this project");
                    return;
                }
            }
            if (cmbTenderStatus.SelectedValue.ToString() == "9")            // Re-Tender
            {
                if (txtTenderNo.Text != "")
                {
                    frmTransforProject transforProject = new frmTransforProject(_projID, _tndrType, _cmtName, mUserRightsColl, cmbTenderStatus.SelectedValue.ToString(), txtProjCode.Text, txtTenderNo.Text, _userName, _fiscalYear, txtproj.Text); //+ "-" + (Convert.ToInt16(DateTime.Today.ToString().Split('/')[2].Split(' ')[0].ToString()) + 1).ToString()
                    transforProject.StartPosition = FormStartPosition.CenterParent;
                    transforProject.ShowDialog();
                    this.Close();
                    ProjReTendered = transforProject.ProjReTender;
                    chkProjectTrnsfor = true;
                }
                else
                {
                    MessageBox.Show("Invalid Tender Status. Tender No. is not yet assigned for this project");
                    return;
                }
            }
            if (cmbTenderStatus.SelectedValue.ToString() == "11")           // On Hold
            {
                chkOnHold = true;
                Status_Onhold();
            }
            if (cmbTenderStatus.SelectedValue.ToString() == "8")            // Cancelled
            {
                try
                {
                    // Test Email for checking the SMTP Server is up and running Added By Varun on 31st Jan 2016
                    MailMessage mailMessage = new MailMessage();

                    mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["From"].ToString());
                    mailMessage.To.Add(new MailAddress(ConfigurationManager.AppSettings["To"].ToString()));
                    mailMessage.Subject = "Test TCMS Alert: Tender Cancelled with Tender No. " + txtTenderNo.Text;
                    mailMessage.IsBodyHtml = true;

                    mailMessage.Body = "<html><body><i style='font-family:Calibri; font-size:15'>Dear Sir/Madam,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Tender & Contract Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>" +
                    "Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'> Tender No. " + txtTenderNo.Text + "</i><i style='font-family:Calibri; font-size:15'> has been cancelled by " + _cmtName + " dated on " + System.DateTime.Now.ToString("dd-MMM-yyyy HH:mm:ss tt") + "</i><br /><br />" +
                    "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:Red;color:White;font-family:Calibri;font-size:18;font-weight:bold'>TENDER NO: " + txtTenderNo.Text + "</td>" +
                    "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Code</i></td><td style='font-family:Calibri;font-size:15'>" + _prjCode + "</td></tr>" +
                    "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Title</i></td><td style='font-family:Calibri;font-size:15'>" + proj_Title + "</td></tr>" +
                    "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Tender Committee</i></td><td style='font-family:Calibri;font-size:15'>" + _cmtName + "</td></tr>" +
                    "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Financial Year</i></td><td style='font-family:Calibri;font-size:15'>" + _fiscalYear + "</td></tr>" +       //+ "(" + _AffairsName + ")
                    "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>User Dept.</i></td><td style='font-family:Calibri;font-size:15'>" + _userDept + " / " + _AffairsName + " </td></tr>" +
                    "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now.ToString("dd-MMM-yyyy HH:mm:ss tt") + "</td></tr>" +
                    "</table><br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>TCMS Team</div></body></html>";


                    SmtpClient client = new SmtpClient();
                    client.EnableSsl = true;                     
                    client.Credentials = new System.Net.NetworkCredential(@"Ashghal\tcms", ConfigurationManager.AppSettings["emailPass"].ToString());
                    ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                    client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                    client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                    client.Send(mailMessage);

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Cannot perform Cancel operation, Exception occurred while sending the email notification to Tender Committee, Please inform them Personally", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                emailIds.Clear();
                UserList_ForAlert(1);

                if (emailIds.Length == 0)
                {
                    MessageBox.Show("Information for Tender Cancelation is required to be sent to a user who handles " + _cmtName + " projects, " +
                      " but there is no identified user to receive the email. Please contact system administrator for information.");
                    return;
                }

                DialogResult dlgResult = DialogResult.No;
                dlgResult = MessageBox.Show("This project shall be sent to Archives if you set the status to Cancelled.  Are you sure want to Cancel this project.", "Tender Status Changing", MessageBoxButtons.YesNo);

                if (dlgResult.ToString() == "Yes")
                {
                    using (SqlConnection sqlConn = new SqlConnection(connStr))
                    {
                        using (SqlCommand cmd = new SqlCommand())
                        {
                            if (sqlConn.State == ConnectionState.Closed)
                                sqlConn.Open();
                            cmd.Connection = sqlConn;
                            cmd.CommandText = @"Update Projects set Tender_Status_id = @status,update_date=@update_date,update_user=@update_user where proj_id=@projId";
                            cmd.Parameters.AddWithValue("@projId", _projID);
                            cmd.Parameters.AddWithValue("@status", 8);
                            cmd.Parameters.AddWithValue("@update_date", DateTime.Now.ToString());
                            cmd.Parameters.AddWithValue("@update_user", _userName);

                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();

                            // Added by Varun on 3rd Nov 2015
                            cmd.CommandText = @"Update TenderDatesInfo set remarks = @remarks,update_date=@update_date,update_user=@update_user where proj_id=@projId and ts_tender_issue is NULL and stage_id=2";
                            cmd.Parameters.AddWithValue("@projId", _projID);
                            cmd.Parameters.AddWithValue("@remarks", "This tender was cancelled by " + _userName + " Dated " + DateTime.Now.ToString());
                            cmd.Parameters.AddWithValue("@update_date", DateTime.Now.ToString());
                            cmd.Parameters.AddWithValue("@update_user", _userName);
                            exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();

                            cmd.CommandText = @"Update TenderDatesInfo set remarks = @remarks,update_date=@update_date,update_user=@update_user where proj_id=@projId and stage_id=3";
                            cmd.Parameters.AddWithValue("@projId", _projID);
                            cmd.Parameters.AddWithValue("@remarks", "This tender was cancelled by " + _userName + " Dated " + DateTime.Now.ToString());
                            cmd.Parameters.AddWithValue("@update_date", DateTime.Now.ToString());
                            cmd.Parameters.AddWithValue("@update_user", _userName);
                            exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                    }
                    MessageBox.Show("Cancellation of the Project was successful. The record was sent to Archives.");


                    //string DisplayName = ""; string Email = ""; string Department = ""; string Title = "";                     
                    // AlertOnNewTenderNo(tenderNo, _projID.ToString(), "New Project");

                    CommonClass comCls = new CommonClass(_userName);
                    string fromUser = null;
                    fromUser = comCls.getUserEmailID(_userName);
                    // Added by Varun on 3rd Nov 2015
                    string tenderTypeFullName = null;
                    if (_tndrType == "L")
                        tenderTypeFullName = "Limited";
                    else if (_tndrType == "DO")
                        tenderTypeFullName = "Direct Order";
                    else if (_tndrType == "LP")
                        tenderTypeFullName = "Limited Practice";
                    else if (_tndrType == "PQ")
                        tenderTypeFullName = "Pre-Qualification Practice";
                    else
                        tenderTypeFullName = "Public Tender";

                    try
                    {
                        //if (GetUserInformation4rmActiveDirectory(fromUser, "ashghal.gov.qa", ref user_DisplayName, ref user_Email, ref  user_Department, ref user_Title) == true)
                        //{
                        //foreach (string strname in userListColl)
                        //{

                            // if (GetUserInformation4rmActiveDirectory(strname, "ashghal.gov.qa", ref DisplayName, ref Email, ref  Department, ref Title) == true)

                            MailMessage mailMessage = new MailMessage();
                            //mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["MailFrom"].ToString());

                            mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["From"].ToString());
                            mailMessage.To.Add(emailIds.ToString() + fromUser); //.Substring(0, emailIds.ToString().Length - 1)
                            mailMessage.Subject = "TCMS Alert: Tender Cancelled with Tender No. " + txtTenderNo.Text;
                            mailMessage.IsBodyHtml = true; 

                            mailMessage.Body = "<html><body><i style='font-family:Calibri; font-size:15'>Dear Sir/Madam,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Tender & Contract Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>" +
                            "Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'> Tender No. " + txtTenderNo.Text + "</i><i style='font-family:Calibri; font-size:15'> has been cancelled by " + _cmtName + " dated on " + System.DateTime.Now.ToString("dd-MMM-yyyy HH:mm:ss tt") + "</i><br /><br />" +
                            "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:Red;color:White;font-family:Calibri;font-size:18;font-weight:bold'>TENDER NO: " + txtTenderNo.Text + "</td>" +
                            "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Code</i></td><td style='font-family:Calibri;font-size:15'>" + _prjCode + "</td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Title</i></td><td style='font-family:Calibri;font-size:15'>" + proj_Title + "</td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Type of Tender</i></td><td style='font-family:Calibri;font-size:15'>" + tenderTypeFullName + "</td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Tender Committee</i></td><td style='font-family:Calibri;font-size:15'>" + _cmtName + "</td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Financial Year</i></td><td style='font-family:Calibri;font-size:15'>" + _fiscalYear + "</td></tr>" +       //+ "(" + _AffairsName + ")
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>User Dept.</i></td><td style='font-family:Calibri;font-size:15'>" + _userDept + " / " + _AffairsName + " </td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now.ToString("dd-MMM-yyyy HH:mm:ss tt") + "</td></tr>" +
                            "</table><br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>TCMS Team</div></body></html>";

                            //mailMessage.Body = "This is an automated alert from TCMS." + "\n" + "\n" + "Project Code     : " + _prjCode + "\n" + "Project Title    : " + proj_Title + "\n" +   "Type of Tender   : " + _tndrTypeName + " " +
                            // "\n"  + "Tender Committee : " + _cmtName + " " +
                            // "\n" +  "User Department  : " + _userDept + " " +
                            // "\n" +  "Date Created     : " + System.DateTime.Now.ToString() + " " +
                            //" \n" +  "\n" + "Tender No. " + strTenderNo + " was assigned to above project.";

                            SmtpClient client = new SmtpClient();
                            client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                            client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                            client.Send(mailMessage);
                        //}


                        //}
                        MessageBox.Show("Tender Alert E-mail send to the users", "Create Tender Number");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Exception occurred while sending the email notification to Tender Committee, Please inform them Personally", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }

                }
            }
            if (cmbTenderStatus.SelectedValue.ToString() == "1")           // Tender Preparation
            {
                UpdateStatus("Tender Preparation", 1);
                chkProjectTrnsfor = true;
            }
            if (cmbTenderStatus.SelectedValue.ToString() == "2")           // Tendering
            {
                UpdateStatus("Tendering", 2);
                chkProjectTrnsfor = true;
            }
            if (cmbTenderStatus.SelectedValue.ToString() == "3")           // Technical Evaluation
            {
                UpdateStatus("Technical Evaluation", 3);
                chkProjectTrnsfor = true;
            }
            if (cmbTenderStatus.SelectedValue.ToString() == "4")           // Financial Evaluation
            {
                UpdateStatus("Financial Evaluation", 4);
                chkProjectTrnsfor = true;
            }
            if (cmbTenderStatus.SelectedValue.ToString() == "5")           //Technical and Financial Evaluation
            {
                UpdateStatus("Technical and Financial Evaluation", 5);
                chkProjectTrnsfor = true;
            }
            if (cmbTenderStatus.SelectedValue.ToString() == "6")           //Award
            {
                UpdateStatus("Award", 6);
                chkProjectTrnsfor = true;
            }
            if (cmbTenderStatus.SelectedValue.ToString() == "7")           //Committed
            {
                UpdateStatus("Committed", 7);
                chkProjectTrnsfor = true;
            }

            if (cmbTenderStatus.SelectedValue.ToString() == "12")           //Start Date Requested
            {
                UpdateStatus("Start Date Requested", 12);
                chkProjectTrnsfor = true;
            }
            if (cmbTenderStatus.SelectedValue.ToString() == "13")           //NOA Issued
            {
                UpdateStatus("NOA Issued", 13);
                chkProjectTrnsfor = true;
            }

            if (cmbTenderStatus.SelectedValue.ToString() == "14")           //Contract Signed
            {
                UpdateStatus("Contract Signed", 14);
                chkProjectTrnsfor = true;
            }

            if (cmbTenderStatus.SelectedValue.ToString() == "15")           //Signature Processing
            {
                UpdateStatus("Signature Processing", 15);
                chkProjectTrnsfor = true;
            }
            if (cmbTenderStatus.SelectedValue.ToString() == "16")           // Revert Deleted Project
            {
                UpdateStatus("Revert Deleted Project", 16);
                chkProjectTrnsfor = true;
            }
            if (cmbTenderStatus.SelectedValue.ToString() == "17")           // Archive
            {
                UpdateStatus("Archive", 17);
                chkProjectTrnsfor = true;
            }
            if (cmbTenderStatus.SelectedValue.ToString() == "18")           // Delete Project
            {
                UpdateStatus("Delete Project", 18);
                chkProjectTrnsfor = true;
            }
        }
        private void Status_Onhold()
        {
            DialogResult dlgResult = DialogResult.No;
            dlgResult = MessageBox.Show("Entering and editing of data for this project will be disabled if you set tender status to 'On Hold' . Are you sure you want to put the tender 'On Hold' ? ", " On-Hold confirmation ", MessageBoxButtons.YesNo);

            if (dlgResult.ToString() == "Yes")
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        if (sqlConn.State == ConnectionState.Closed)
                            sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"Update Projects set Tender_Status_id = @status where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@projId", _projID);
                        cmd.Parameters.AddWithValue("@status", 11);
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();

                        // Added by Varun on 5th Nov 2015
                        cmd.CommandText = @"select proj_id from TenderDatesInfo where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@projId", _projID);
                        SqlDataReader sqlDtReader = cmd.ExecuteReader();
                        if (sqlDtReader.Read())
                        {
                            sqlDtReader.Close();
                            cmd.Parameters.Clear();
                            cmd.CommandText = @"Update TenderDatesInfo set remarks = @remarks,update_date=@update_date,update_user=@update_user where proj_id=@projId and ts_tender_issue is NULL and stage_id=2";
                            cmd.Parameters.AddWithValue("@projId", _projID);
                            cmd.Parameters.AddWithValue("@remarks", "This tender status was set on Hold by " + _userName + " Dated " + DateTime.Now.ToString());
                            cmd.Parameters.AddWithValue("@update_date", DateTime.Now.ToString());
                            cmd.Parameters.AddWithValue("@update_user", _userName);
                            exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();

                            cmd.CommandText = @"Update TenderDatesInfo set remarks = @remarks,update_date=@update_date,update_user=@update_user where proj_id=@projId and stage_id=3";
                            cmd.Parameters.AddWithValue("@projId", _projID);
                            cmd.Parameters.AddWithValue("@remarks", "This tender status was set on Hold by " + _userName + " Dated " + DateTime.Now.ToString());
                            cmd.Parameters.AddWithValue("@update_date", DateTime.Now.ToString());
                            cmd.Parameters.AddWithValue("@update_user", _userName);
                            exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                        else
                        {

                            sqlDtReader.Close();
                            int dateID = MaxDateID();
                            sqlCom = new SqlCommand();
                            sqlCom.Connection = sqlConn;
                            sqlCom.CommandText = @"insert into TenderDatesInfo(proj_id,date_id,stage_id,remarks,update_date,update_user) values(" + _projID + "," + dateID + ",2,'This tender status was set on Hold by " + _userName + " Dated " + DateTime.Now.ToString() + "','" + DateTime.Now.ToString() + "','" +
                            _userName + "')";
                            sqlCom.ExecuteNonQuery();
                            sqlCom.Parameters.Clear();

                            dateID = MaxDateID();
                            sqlCom = new SqlCommand();
                            sqlCom.Connection = sqlConn;
                            sqlCom.CommandText = @"insert into TenderDatesInfo(proj_id,date_id,stage_id,remarks,update_date,update_user) values(" + _projID + "," + dateID + ",3,'This tender status was set on Hold by " + _userName + " Dated " + DateTime.Now.ToString() + "','" + DateTime.Now.ToString() + "','" +
                            _userName + "')";
                            sqlCom.ExecuteNonQuery();
                            sqlCom.Parameters.Clear();
                        }
                    }
                }
                txt_tsRemarks.Enabled = false;
                txtTE_remarks.Enabled = false;

                MessageBox.Show("Tendering of the project is now On Hold");

                //tabControl1.Enabled = false;
            }
        }
        private void UpdateStatus(string statusName, int statusID)
        {
            DialogResult dlgResult = DialogResult.No;
            if (statusID != 16)
                dlgResult = MessageBox.Show("Are you sure want to update this project status to " + statusName, "Tender Status Changing", MessageBoxButtons.YesNo);
            else
                dlgResult = MessageBox.Show("Are you sure want to undo the project deletion", "Undo Project Deletion", MessageBoxButtons.YesNo);

            if (dlgResult.ToString() == "Yes")
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        if (sqlConn.State == ConnectionState.Closed)
                            sqlConn.Open();
                        cmd.Connection = sqlConn;
                        //Modified by Varun on 15-Nov-2015 and 11-Jan-2016
                        if (statusID == 16) // Revert Deleted Project
                        {
                            cmd.CommandText = @"Update Projects set Tender_Status_id = @status,isDeleted=@isDeleted,stage_id=@stage_id,update_user='" + _userName + "',update_date='" + DateTime.Now.ToString() + "' where proj_id=@projId";
                            cmd.Parameters.AddWithValue("@projId", _projID);
                            cmd.Parameters.AddWithValue("@status", 1);
                            cmd.Parameters.AddWithValue("@isDeleted", 0);
                            cmd.Parameters.AddWithValue("@stage_id", 1); //Prepare Tender Doc Stage
                        }
                        else if (statusID == 18) // Delete Project
                        {
                            cmd.CommandText = @"Update Projects set Tender_Status_id = @status,isDeleted=@isDeleted,tender_no=@tenderNo,update_user='" + _userName + "',update_date='" + DateTime.Now.ToString() + "' where proj_id=@projId";
                            cmd.Parameters.AddWithValue("@projId", _projID);
                            cmd.Parameters.AddWithValue("@status", statusID);
                            cmd.Parameters.AddWithValue("@isDeleted", 1);
                            cmd.Parameters.AddWithValue("@tenderNo", DBNull.Value);                            
                        }
                        else
                        {
                            cmd.CommandText = @"Update Projects set Tender_Status_id = @status,stage_id=@stage_id,update_user='" + _userName + "',update_date='" + DateTime.Now.ToString() + "' where proj_id=@projId";
                            cmd.Parameters.AddWithValue("@projId", _projID);
                            cmd.Parameters.AddWithValue("@status", statusID);
                            if (statusID == 1)
                            {
                                cmd.Parameters.AddWithValue("@stage_id", 1); //1==Prepare Tender Documents
                            }
                            else if (statusID == 2)
                            {
                                cmd.Parameters.AddWithValue("@stage_id", 2); //2==Tendering Stage
                            }
                            else if (statusID == 3 || statusID == 4 || statusID == 5)
                            {
                                cmd.Parameters.AddWithValue("@stage_id", 3); //3==Tender Evaluation & Award
                            }
                            else if (statusID == 6 || statusID == 12 || statusID == 13 || statusID == 14)
                            {
                                cmd.Parameters.AddWithValue("@stage_id", 4); //4==Contracts Process
                            }                            
                            else if (statusID == 7)
                            {
                                cmd.Parameters.AddWithValue("@stage_id", 6); //6==Post Contract Stage
                            }
                        }

                        cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();

                    }
                }
                
                chkProjectTrnsfor = true;
            }
        }



        private void dgvCpDataEntry_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {
            try
            {
                for (int i = 0; i < dgvCpDataEntry.Rows.Count; i++)
                {
                    if (i == (dgvCpDataEntry.Rows.Count - 1))
                    {
                        dgvCpDataEntry.Rows[i].Cells[0].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[1].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[2].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[3].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[4].Value = "";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dgvPTD_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (mUserRightsColl.Contains("38"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            if (e.RowIndex != -1)
            {

                int rowIndex = Convert.ToInt16(dgvPTD.Rows[e.RowIndex].Index);
                for (int iCnt = 0; iCnt < dgvPTD.Rows.Count; iCnt++)
                {
                    if (iCnt.Equals(rowIndex))
                    {
                        chkUpdateStatus = true;

                        if (dgvPTD.Rows[iCnt].Cells[0].Value != DBNull.Value)
                        {
                            //dtpRecievedOn.CustomFormat = "dd/MMM/yyyy";
                            //Modified by Varun on 13th Feb 2014 for displaying arabic as well as gregorian date in the textbox
                            //Convert.ToDateTime(dtpRecievedOn.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString()
                            msk_dtpRecievedOn.Text = Convert.ToDateTime(dgvPTD.Rows[iCnt].Cells[0].Value).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture); //Convert.ToDateTime(.ToString("dd/MMM/yyyy")
                        }
                        else
                        {
                            msk_dtpRecievedOn.Text = "";
                        }


                        cmbPurpose.Text = dgvPTD.Rows[iCnt].Cells[1].Value.ToString();
                        cmbAssignedQs.Text = dgvPTD.Rows[iCnt].Cells[2].Value.ToString();

                        if (dgvPTD.Rows[iCnt].Cells[3].Value.ToString() != "")
                        {
                            //dtpReview.CustomFormat = "dd/MMM/yyyy";
                            //Modified by Varun on 13th Feb 2014 for displaying arabic as well as gregorian date in the textbox
                            msk_dtpReview.Text = Convert.ToDateTime(dgvPTD.Rows[iCnt].Cells[3].Value).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture);//"dd/MMM/yyyy");
                        }
                        else
                        {
                            msk_dtpReview.Text = "";
                        }


                        cmbQsWorkingStatus.Text = dgvPTD.Rows[iCnt].Cells[4].Value.ToString();
                        cmbTenderDocStatus.Text = dgvPTD.Rows[iCnt].Cells[5].Value.ToString();
                        if (dgvPTD.Rows[iCnt].Cells[6].Value.ToString() != "")
                        {
                            //dtpFrwdDept.CustomFormat = "dd/MMM/yyyy";
                            //Modified by Varun on 13th Feb 2014 for displaying arabic as well as gregorian date in the textbox
                            msk_dtpFrwdDept.Text = Convert.ToDateTime(dgvPTD.Rows[iCnt].Cells[6].Value).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture);//"dd/MMM/yyyy");
                        }
                        else
                        {
                            msk_dtpFrwdDept.Text = "";
                        }
                        txtRemarks.Text = dgvPTD.Rows[iCnt].Cells[7].Value.ToString();
                        lblDateID.Text = dgvPTD.Rows[iCnt].Cells[8].Value.ToString();

                        lblGridIndex.Text = e.RowIndex.ToString();

                        if (dgvPTD.Rows[iCnt].Cells[5].Value.ToString() == "Approved")
                        {
                            if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                            {
                                //msk_dtpRecievedOn.Enabled = false;
                                //dtpRecievedOn.Enabled = false;
                                //cmbPurpose.Enabled = false;
                                //cmbAssignedQs.Enabled = false;
                                //cmbQsWorkingStatus.Enabled = false;
                                //msk_dtpReview.Enabled = false;
                                //dtpReview.Enabled = false;
                                //cmbTenderDocStatus.Enabled = false;
                                //msk_dtpFrwdDept.Enabled = false;
                                //dtpFrwdDept.Enabled = false;
                                //txtRemarks.Enabled = true;
                                //btnPTD.Enabled = true;
                                //if (msk_dtpRecievedOn.Text != "")
                                //{
                                //    msk_dtpRecievedOn.Enabled = false;
                                //    dtpRecievedOn.Enabled = false;
                                //}
                                //else
                                //{
                                    msk_dtpRecievedOn.Enabled = true;
                                    dtpRecievedOn.Enabled = true;
                                //}

                                //if (cmbPurpose.Text != "")
                                //{
                                //    cmbPurpose.Enabled = false;
                                //}
                                //else
                                //{
                                    cmbPurpose.Enabled = true;
                                //}

                                //if (cmbAssignedQs.Text != "")
                                //{
                                //    cmbAssignedQs.Enabled = false;
                                //}
                                //else
                                //{
                                    cmbAssignedQs.Enabled = true;
                                //}

                                //if (cmbPurpose.Text != "")
                                //{
                                //    cmbPurpose.Enabled = false;
                                //}
                                //else
                                //{
                                    cmbPurpose.Enabled = true;
                                //}

                                //if (msk_dtpReview.Text != "")
                                //{
                                //    msk_dtpReview.Enabled = false;
                                //    dtpReview.Enabled = false;
                                //}
                                //else
                                //{
                                    msk_dtpReview.Enabled = true;
                                    dtpReview.Enabled = true;
                                //}

                                //if(cmbQsWorkingStatus.Text != "")
                                //{
                                //    cmbQsWorkingStatus.Enabled = false;
                                //}
                                //else
                                //{
                                    cmbQsWorkingStatus.Enabled = true;
                                //} 

                                //if (cmbTenderDocStatus.Text != "")
                                //{
                                //    cmbTenderDocStatus.Enabled = false;
                                //}
                                //else
                                //{
                                    cmbTenderDocStatus.Enabled = true;
                                //}

                                //if (msk_dtpReview.Text != "")
                                //{
                                //    msk_dtpFrwdDept.Enabled = false;
                                //    dtpFrwdDept.Enabled = false;
                                //}
                                //else
                                //{
                                    msk_dtpFrwdDept.Enabled = true;
                                    dtpFrwdDept.Enabled = true;
                                //}

                                //if (txtRemarks.Text != "")
                                //{
                                //    txtRemarks.Enabled = false;
                                //}
                                //else
                                //{
                                    txtRemarks.Enabled = true;
                                //}

                                btnPTD.Enabled = true;
                            }
                        }
                        else
                        {
                            if (!msk_dtpRecievedOn.Enabled)
                            {
                                msk_dtpRecievedOn.Enabled = true;
                                dtpRecievedOn.Enabled = true;
                                cmbPurpose.Enabled = true;
                                cmbAssignedQs.Enabled = true;
                                cmbQsWorkingStatus.Enabled = true; 
                                msk_dtpReview.Enabled = true;
                                dtpReview.Enabled = true;
                                cmbTenderDocStatus.Enabled = true;
                                msk_dtpFrwdDept.Enabled = true;
                                dtpFrwdDept.Enabled = true;
                                txtRemarks.Enabled = true;
                            }
                        }
                    }
                }
            }
        }

        private void txtEstimatedAmnt_Leave(object sender, EventArgs e)
        {
            if (txtEstimatedAmnt.Text != "")
            {
                if (clsForTE.CheckProjectCostDataExist(_projID) == false)
                {
                    clsForTE.InsertTE_Estimate_ProjectCostData(txtEstimatedAmnt.Text, _projID);
                }
                else
                {
                    clsForTE.UpdateTE_Estimate_ProjectCostData(txtEstimatedAmnt.Text, _projID);
                }
                txtEstimatedAmnt.Text = string.Format("{0:#,##0.00}", double.Parse(txtEstimatedAmnt.Text));//#,##0}
            }
            else
                clsForTE.UpdateTE_Estimate_ProjectCostData(txtEstimatedAmnt.Text, _projID);
        }
        private void txtBudjetAmnt_Leave(object sender, EventArgs e)
        {
            if (txtBudjetAmnt.Text != "")
            {
                if (clsForTE.CheckProjectCostDataExist(_projID) == false)
                {
                    clsForTE.InsertTE_Budget_ProjectCostData(txtBudjetAmnt.Text, _projID);
                }
                else
                {
                    clsForTE.UpdateTE_BudgetAmount_ProjectCostData(txtBudjetAmnt.Text, _projID);
                }
                txtBudjetAmnt.Text = string.Format("{0:#,##0.00}", double.Parse(txtBudjetAmnt.Text));
            }
            else
                clsForTE.UpdateTE_BudgetAmount_ProjectCostData(txtBudjetAmnt.Text, _projID);
        }
        private void dtpEA_reqdate_ValueChanged(object sender, EventArgs e)
        {
            //msk_dtpEA_reqdate.Text = Convert.ToDateTime(dtpEA_reqdate.Value).ToString("dd/MMM/yyyy");
            //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            msk_dtpEA_reqdate.Text = Convert.ToDateTime(dtpEA_reqdate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
            msk_dtpEA_reqdate.Focus();
        }

        private void txtEA_Noofmeetings_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }

        private void txtEA_Noofmeetings_KeyDown(object sender, KeyEventArgs e)
        {
            nonNumberEntered = false;
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            {
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    if ((e.KeyCode != Keys.Back) & (e.KeyCode != Keys.Enter))
                    {
                        nonNumberEntered = true;
                    }
                }
            }
        }
        private void txtBudjetAmnt_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }
        private void txtEstimatedAmnt_KeyDown(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }

        //Added by Varun on 11th May 2014 Modified the Validation process for checking the numerics and decimals in the textboxes where only these inputs are expected 
        private void ValidateNumericAndDecimalInput(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != 8 && e.KeyChar != 13) //&& e.KeyChar.ToString().Contains('.').ToString().Length>=2
            {
                nonNumberEntered = true;
            }
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                nonNumberEntered = true;
                e.Handled = true;
            }

            if (nonNumberEntered == true)
            {
                MessageBox.Show("Please enter number only...");
                e.Handled = true;
            }

            nonNumberEntered = false;
        }

        private void txtEstimatedAmnt_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }
        private void txtCp_BudgetAmnt_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }
        private void txtCp_EstimatedAmnt_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }
        private void txtPC_BudjetAmnt_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }

        private void txtPC_EstimatedAmnt_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }

        private void dgvContracts_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {
            try
            {
                for (int i = 0; i < dgvContracts.Rows.Count; i++)
                {
                    if (i == (dgvContracts.Rows.Count - 1))
                    {
                        //dgvContracts.Rows[i].Cells[0].Value = "";
                        //dgvContracts.Rows[i].Cells[1].Value = "";
                        //dgvContracts.Rows[i].Cells[2].Value = "";
                        dgvContracts.Rows[i].Cells[3].Value = "";
                        //dgvContracts.Rows[i].Cells[4].Value = "";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cmbPurpose_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (msk_dtpRecievedOn.Text == "")
            {
                MessageBox.Show("Please Select Received On Date", "Received On Date", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cmbPurpose.SelectedIndex = -1;
                msk_dtpRecievedOn.Focus();
                return;
            }
        }

        // Added by Varun on 21 May 2014 for checking the duplicate ContractNo.
        public bool ValidateContractNo(string contractNo)
        {
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                sqlConn.Open();
                SqlCommand sqlCom = new SqlCommand(@"select contract_no from [CONTRACTORS] where contract_no = @cntrNo and bidder_id<>" + currentBidderID, sqlConn);
                contractNo = contractNo.Replace(" ", "").Replace("-", "/");
                while (Regex.Match(contractNo, "/0").Success)
                    contractNo = contractNo.Replace("/0", "/");
                sqlCom.Parameters.AddWithValue("@cntrNo", contractNo.ToUpper());
                sqlDtReader = sqlCom.ExecuteReader();
                if (sqlDtReader.HasRows)
                {
                    if (sqlDtReader.Read())
                    {
                        MessageBox.Show("Entered ContractNo. already assigned to some other bidder, Please enter a unique ContractNo.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return false;
                    }
                }
                else
                {
                    // Added on 30/05/2016 by Varun
                    sqlDtReader.Close();
                    txtContractNo.Text = contractNo.ToUpper();
                    try
                    {
                        using (SqlCommand cmd = new SqlCommand())
                        {
                            cmd.Connection = sqlConn;
                            //If user updates or assign  the Contract number Tender status should become Committed and Stage ID or current stage should become Post Contract Stage
                            cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]= 7 , [stage_id]= 6 Where proj_id=@projId";
                            cmd.Parameters.AddWithValue("@projId", _projID);
                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error occurred while Updating project status, Try again.", ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                sqlDtReader.Close();
                sqlCom = null;
                sqlConn.Close();
            }
            return true;
        }
        public bool ValidateDate(Control ctrl)
        {
            if (string.IsNullOrEmpty(ctrl.Text))
            {
                return false;
            }
            else
            {
                return true;
            }

        }

        private void msk_dtpRecievedOn_Leave(object sender, EventArgs e)
        {
            if (msk_dtpRecievedOn.Text != "")
            {
                Control ctrl = sender as Control;
                Boolean chkDate = ValidateDate(ctrl);

                if (chkDate == false)
                {
                    msk_dtpRecievedOn.Text = "";
                    msk_dtpRecievedOn.Focus();
                    return;
                }
            }

        }

        private void msk_dtpReview_Leave(object sender, EventArgs e)
        {
            Control ctrl = sender as Control;
            if (ValidateDate(ctrl) == false)
            {
                msk_dtpReview.Text = "";
                msk_dtpReview.Focus();
                return;
            }
        }


        private void msk_dtp_tsRecOn_Leave(object sender, EventArgs e)
        {
            if (msk_dtp_tsRecOn.Text != "")
            {
                if (ValidateDate(msk_dtp_tsRecOn) == false)
                {
                    msk_dtp_tsRecOn.Text = "";
                    msk_dtp_tsRecOn.Focus();
                    return;
                }
            }
        }

        private void msk_dtpEA_recfromcd_Leave(object sender, EventArgs e)
        {
            if (msk_dtpEA_recfromcd.Text.Trim() != "")
            {
                if (ValidateDate(msk_dtpEA_recfromcd) == false)
                {
                    msk_dtpEA_recfromcd.Text = "";
                    msk_dtpEA_recfromcd.Focus();
                    return;
                }
            }            
        }


        //Boolean chkdgvContracts = false;
        //private void dgvContracts_CellClick(object sender, DataGridViewCellEventArgs e)
        //{
        //    chkdgvContracts = true;
        //}

        private void txtTenderBond_KeyDown(object sender, KeyEventArgs e)
        {
            nonNumberEntered = false;
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            {
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    if ((e.KeyCode != Keys.Back) & (e.KeyCode != Keys.Enter))
                    {
                        nonNumberEntered = true;
                    }
                }
            }
        }

        private void txtTenderBond_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (nonNumberEntered == true)
            {
                MessageBox.Show("Please enter number only...");
                e.Handled = true;
            }
        }

        private void txtDocumentFree_KeyDown(object sender, KeyEventArgs e)
        {
            nonNumberEntered = false;
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9) //|| e.KeyCode == Keys.Decimal
            {
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    if ((e.KeyCode != Keys.Back) & (e.KeyCode != Keys.Enter))
                    {
                        nonNumberEntered = true;
                    }
                }
            }
        }
        private void txtDocumentFree_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }

        private void msk_dtpTV_FEdate_ModifiedChanged(object sender, EventArgs e)
        {
            //Modified by Varun on 04 Feb 2014 based on Adonis req.

            if (msk_dtpTV_FEdate.Text != "")
            {
                if (ValidateDate(msk_dtpTV_FEdate) == false)
                {
                    msk_dtpTV_FEdate.Text = "";
                    msk_dtpTV_FEdate.Focus();
                    return;
                }
                if (msk_dtpTV_SEdate.Text == "" && msk_dtpTV_OrgDate.Text != "" && isCpContractorSign == false)
                {
                    if (Convert.ToDateTime(msk_dtpTV_OrgDate.Text) > Convert.ToDateTime(msk_dtpTV_FEdate.Text))
                    {
                        MessageBox.Show("Extension Date should be greater than Original Date");
                        msk_dtpTV_FEdate.Text = "";
                        msk_dtpTV_FEdate.Focus();
                        return;
                    }

                    if (msk_dtpTV_FEdate.Text != "")
                    {
                        int iDays = (Convert.ToDateTime(msk_dtpTV_FEdate.Text) - System.DateTime.Now.Date).Days;
                        txtTV_exipre.Text = iDays.ToString();
                    }
                }
            }
            if (msk_dtpTV_FEdate.Text != "" && isCpContractorSign == false)
            {
                int iDays = (Convert.ToDateTime(msk_dtpTV_FEdate.Text) - System.DateTime.Now.Date).Days;
                txtTV_exipre.Text = iDays.ToString();
            }
        }

        private void msk_dtpTV_SEdate_TextChanged(object sender, EventArgs e)
        {
            //UpdateTV_FirstExtension(msk_dtpTV_FEdate.Text);
        }

        private void msk_dtpTV_FEdate_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Modified by Varun on 04 Feb 2014 based on Adonis req.

            if (msk_dtpTV_FEdate.Text != "")
            {
                if (ValidateDate(msk_dtpTV_FEdate) == false)
                {
                    msk_dtpTV_FEdate.Text = "";
                    msk_dtpTV_FEdate.Focus();
                    return;
                }
                if (msk_dtpTV_SEdate.Text == "" && isCpContractorSign == false)
                {
                    if (Convert.ToDateTime(msk_dtpTV_OrgDate.Text) > Convert.ToDateTime(msk_dtpTV_FEdate.Text))
                    {
                        MessageBox.Show("Extension Date should be greater than Original Date");
                        msk_dtpTV_FEdate.Text = "";
                        msk_dtpTV_FEdate.Focus();
                        return;
                    }

                    if (msk_dtpTV_FEdate.Text != "")
                    {
                        int iDays = (Convert.ToDateTime(msk_dtpTV_FEdate.Text) - System.DateTime.Now.Date).Days;
                        txtTV_exipre.Text = iDays.ToString();
                    }
                }
            }
            //Modified by Varun on 04 Feb 2014 based on Adonis req.
            if (msk_dtpTV_FEdate.Text != "" && isCpContractorSign == false)
            {
                int iDays = (Convert.ToDateTime(msk_dtpTV_FEdate.Text) - System.DateTime.Now.Date).Days;
                txtTV_exipre.Text = iDays.ToString();
            }
        }




        private void btnDatesExtend_Click(object sender, EventArgs e)
        {
            frmExtDatesInfo tenderDatesExtend = new frmExtDatesInfo(_projID);
            // tenderDatesExtend.StartPosition = FormStartPosition.CenterParent;
            tenderDatesExtend.ShowDialog();
        }

        private void dgvPC_Contracts_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //if (userRightsColl.Contains("38"))
            //{
            //    MessageBox.Show("You have no privilege,Contact administrator");
            //    return;
            //}            
            //Modified by Varun on 30 Jan 2014 based on Sridher request
            int rowIndex = e.RowIndex;
            int colIndex = e.ColumnIndex;
            try
            {
                if (rowIndex != -1)
                {
                    if (colIndex == 0)
                    {
                        int bidId = Convert.ToInt16(dgvPC_Contracts.Rows[rowIndex].Cells[8].Value);
                        frmContractsEntry cntrEntry = null;
                        //if (dgvPC_Contracts.Rows[rowIndex].Cells[2].Value.ToString().ToLower() != "framework")
                        //{
                        cntrEntry = new frmContractsEntry(mUserRightsColl, bidId, _projID, null, _userName, mIsHeadOfSection, txtproj.Text, null, null, null);
                        //}
                        //else if (dgvPC_Contracts.Rows[rowIndex].Cells[2].Value.ToString().ToLower() == "framework")
                        //{
                        //    cntrEntry = new frmContractsEntry(mUserRightsColl, bidId, _projID, dgvPC_Contracts.Rows[rowIndex].Cells[9].Value.ToString(), _userName, mIsHeadOfSection, txtproj.Text, txtTenderNo.Text, msk_dtpEA_closeDate.Text, msk_dtpEA_stage1.Text);
                        //}

                        cntrEntry.StartPosition = FormStartPosition.CenterParent;
                        cntrEntry.ShowDialog();
                        clspC.refreshPCContracts_Data(dgvPC_Contracts, _projID);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void btnCntrSave_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Contains("46"))         // For TE
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            int statusID = getStatusID(ProjectId);           // statusID = 7 for contractProcess

            CP_Contract_InsertUpdate(dgvCntrStage3, mIsHeadOfSection);

            //tabControl1.SelectedIndex = 3;


            foreach (DataGridViewRow row in this.dgvCntrStage3.Rows)
            {
                if (row.Cells[4].Value != null)
                {
                    if (row.Cells[4].Value.ToString() != "")
                    {
                        if (statusID < 7)
                        {
                            clsCP_Stage clsCP = new clsCP_Stage(_userName, mIsHeadOfSection);
                            clsCP.Status_Award(6, lblProjID.Text);

                            // added by Varun on 11/05/2015                             
                            FillProjectInfo();
                            // Attempted by Varun on 11/05/2015 for refreshing the All Projects GridView but its not working, let user click on refresh button to do it manually
                            //TMS_MainView tmsMainView = new TMS_MainView(_userName);                                                
                        }
                    }
                }
            }
        }
        private void dgvCntrStage3_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvCntrStage3.IsCurrentCellDirty)
            {
                DataGridView dgv = sender as DataGridView;
                if (dgv.CurrentCell != null)
                {
                    if (dgv.CurrentCell.ColumnIndex == 0)
                    {
                        // ComboBox comboBox = e.Control as ComboBox;
                        if (e.RowIndex >= 0) //check if combobox column
                        {
                            object selectedValue = dgvCntrStage3.Rows[dgv.CurrentCell.RowIndex].Cells[dgv.CurrentCell.ColumnIndex].Value;

                            if (selectedValue is int)
                            {
                                string _cmpName = clsForCP.FillComapany_dgvComboValue(Convert.ToInt16(selectedValue));
                                dgvCntrStage3.Rows[dgv.CurrentCell.RowIndex].Cells[dgv.CurrentCell.ColumnIndex + 1].Value = _cmpName;
                            }
                        }
                        // comboBox.SelectedIndexChanged += LastColumnComboSelectionChanged;
                    }

                }
            }
            // suspendEventCellValueChanged = false;
        }

        //private void dgvCntrStage3_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        //{
        //    string CurrentRow = e.Row.Cells[5].Value.ToString();
        //    if (CurrentRow != null)
        //    {
        //        string sqlUpdate = "Delete from Contractors where Bidder_ID = @bidID";
        //        using (SqlConnection sqlCn = new SqlConnection(connStr))
        //        {
        //            sqlCn.Open();
        //            using (SqlCommand sqlCmd = new SqlCommand(sqlUpdate, sqlCn))
        //            {
        //                sqlCmd.Parameters.AddWithValue("@bidID", CurrentRow);
        //                sqlCmd.ExecuteNonQuery();
        //            }
        //            sqlCn.Close();
        //        }
        //    }
        //    DataGridView dgv = (DataGridView)sender;
        //    dgv.EditMode = DataGridViewEditMode.EditOnEnter;
        //    //ChkBidderProjectCostExist(CurrentRow);
        //}
        private void ChkBidderProjectCostExist(string CurrentRowData)
        {
            int _bidID = 0;
            string sqlQuery = "SELECT bidder_id from ProjectCost Where Bidder_ID = CurrentRowData";
            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(sqlQuery, sqlCn))
                {
                    using (SqlDataReader dr = sqlCmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                _bidID = Convert.ToInt16(dr[0]);
                            }
                        }
                    }
                }
                sqlCn.Close();
            }
            if (_bidID != 0)
            {
                string sqlUpdate = "Delete from ProjectCost where Bidder_ID = @bidID";
                using (SqlConnection sqlCn = new SqlConnection(connStr))
                {

                    sqlCn.Open();
                    using (SqlCommand sqlCmd = new SqlCommand(sqlUpdate, sqlCn))
                    {
                        sqlCmd.Parameters.AddWithValue("@bidID", _bidID);
                        sqlCmd.ExecuteNonQuery();
                    }
                    sqlCn.Close();
                }
            }
        }
        private void btnMinistry_Click(object sender, EventArgs e)
        {
            frmNewCodes frmMinCodes = new frmNewCodes();
            frmMinCodes.StartPosition = FormStartPosition.CenterScreen;
            frmMinCodes.ShowDialog();
        }
        private void btnBudgetRef_Click(object sender, EventArgs e)
        {
            frmNewCodes frmMinCodes = new frmNewCodes();
            frmMinCodes.StartPosition = FormStartPosition.CenterScreen;
            frmMinCodes.ShowDialog();
        }
        private void txtProvisionNo_Leave(object sender, EventArgs e)
        {
            if (txtProvisionNo.Text != "")
            {
                txtProvisionNo.Text.Trim().Replace(" ", "-").Replace("/", "-").Replace(".", "-");
                string[] provisionNoArray = null;
                bool isWrong = true;
                if (txtProvisionNo.Text.Contains("-"))
                {
                    provisionNoArray = txtProvisionNo.Text.Split('-');
                    int totalArrayIndex = 0;
                    while (totalArrayIndex < provisionNoArray.Length)
                    {
                        if (totalArrayIndex == 0)
                        {
                            if (provisionNoArray[totalArrayIndex].Length > 4)
                                isWrong = false;
                        }
                        else if (totalArrayIndex == 1)
                        {
                            if (provisionNoArray[totalArrayIndex].Length > 2)
                                isWrong = false;
                        }
                        else if (totalArrayIndex == 2)
                        {
                            if (provisionNoArray[totalArrayIndex].Length > 4)
                                isWrong = false;
                        }
                        totalArrayIndex++;
                    }
                }
                else
                    isWrong = false;

                if (isWrong == false)
                {
                    MessageBox.Show("Provision Number must be in the xxxx-xx-xxxx format");
                    return;
                }

                if (isWrong == true && provisionNoArray != null)
                {
                    if (provisionNoArray.Length < 3)
                    {
                        MessageBox.Show("Provision Number must be in the xxxx-xx-xxxx format");
                        return;
                    }
                }
                else if (isWrong == true && provisionNoArray == null)
                {
                    MessageBox.Show("Provision Number must be in the xxxx-xx-xxxx format");
                    return;
                }

                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        if (sqlConn.State == ConnectionState.Closed)
                            sqlConn.Open();

                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"Update Projects set Provision_Number = @ProvNumber where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@projId", Convert.ToInt16(lblProjID.Text));
                        cmd.Parameters.AddWithValue("@ProvNumber", txtProvisionNo.Text);
                        int exUpdated = cmd.ExecuteNonQuery();

                        cmd.Parameters.Clear();
                    }
                }
            }
        }

        private bool UpdateMinistryCode()
        {
            bool isTrue = false;
            if (cmbMinistryCode.Text != "")
            {
                if (cmbMinistryCode.Text.Length > 5)
                {
                    MessageBox.Show("Cannot enter more than five characters in the Ministry Code");
                    cmbMinistryCode.Focus();
                    return isTrue;
                }
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        if (sqlConn.State == ConnectionState.Closed)
                            sqlConn.Open();

                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"Update Projects set Ministry_Code = @Minstry_Code where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@projId", Convert.ToInt16(lblProjID.Text));
                        cmd.Parameters.AddWithValue("@Minstry_Code", cmbMinistryCode.Text);
                        int exUpdated = cmd.ExecuteNonQuery();

                        cmd.Parameters.Clear();
                        isTrue = true;
                    }
                }
            }
            else
                isTrue = true;
            return isTrue;
        }
        private bool UpdateBudgetCode()
        {
            bool isTrue = true;
            if (cmbBudgetRef.Text.Length > 7)
            {
                MessageBox.Show("Cannot enter more than seven characters in the Budget Ref No.");
                cmbBudgetRef.Focus();
                isTrue = false;
                return isTrue;
            }
            else
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        if (sqlConn.State == ConnectionState.Closed)
                            sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"Update Projects set Budget_Reference_No = @BudgetCode where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@projId", Convert.ToInt16(lblProjID.Text));
                        cmd.Parameters.AddWithValue("@BudgetCode", cmbBudgetRef.Text);
                        int exUpdated = cmd.ExecuteNonQuery();

                        cmd.Parameters.Clear();
                        isTrue = true;
                    }
                }
            }
            return isTrue;
        }
        private void btnExportToPdf_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Contains("44"))
            {
                MessageBox.Show("You have no privilege to View Tender Collection Summary Report. Please Contact system administrator.");
                return;
            }
            CommonClass comCls = new CommonClass(_userName);
            DataTable dtViewBidders = null;
            dtViewBidders = comCls.LoadCircularOrNonCircularData(0, 'N', null, _projID, null, null, null, 'N', _chGetShortListed);
            int circularCnt = clsForTS.GetCircularCount(_projID);
            short modifiedClosingDateCount = clsForTS.GetModifiedClosingDateCount(_projID);
            //Modified By Varun on 16th Feb 2014 replace prAdvDate by tenderIssueDate based on Riyas request

            // comCls.ExportToPDF(connStr, sqlCom, null, dtViewBidders.DefaultView, txtTenderNo.Text, txtProjCode.Text, txtproj.Text, _projID, msk_dtp_tsStage1.Text, msk_dtp_tsModifiedDate.Text.Split(' ')[0].ToString(), circularCnt, txtTenderBond.Text, txtDocumentFee.Text, msk_dtp_tsInvitation.Text, 'N', 'N', strEligibleTenderTypes, _tndrType, modifiedClosingDateCount, null, ref outTenderSubmissionDateAndTime,1,""); //msk_dtp_tsAdvertisement

            comCls.ExportToPDF(connStr, sqlCom, null, dtViewBidders.DefaultView, txtTenderNo.Text, txtProjCode.Text, txtproj.Text, _projID, msk_dtp_tsStage1.Text, msk_dtp_tsModifiedDate_Stage1.Text.Split(' ')[0].ToString(), circularCnt, txtTenderBond.Text, txtDocumentFee.Text, msk_dtp_tsInvitation.Text, 'N', 'N', strEligibleTenderTypes, _tndrType, modifiedClosingDateCount, null, 1, "", 1, null, false, false); //msk_dtp_tsAdvertisement
            //>>>>>>> .r21
        }
        private void btnViewShortList_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Contains("69"))
            {
                MessageBox.Show("You have no privilege to View Short List. Please Contact system administrator.");
                return;
            }

            string strSelectedCompanies = string.Empty;
            strSelectedCompanies = commCls.chkAccessRightsAndSelectedCompanies('S', mUserRightsColl, null, null, chkLocal, chkInternational, chkJointVenture);
            if (strSelectedCompanies == "R")
                return;
            //Modified By Varun on 16th Feb 2014 replace msk_dtp_tsAdvertisement by tenderIssueDate based on Riyas request
            MDI_ParenrForm.Projects.frmBidderInfo frmbidders = new MDI_ParenrForm.Projects.frmBidderInfo(mUserRightsColl, _projID, txtProjCode.Text, txtproj.Text, txtTenderNo.Text, strSelectedCompanies, _userName, txtTenderBond.Text, txtDocumentFee.Text, msk_dtp_tsInvitation.Text, 'S', strEligibleTenderTypes, 'Y', _tndrType, 1);
            frmbidders.Text = "ShortList Information Window";
            Control[] ctrlColl = frmbidders.Controls.Find("groupBox1", false);
            ctrlColl[0].Text = "ShortList Information";
            frmbidders.StartPosition = FormStartPosition.CenterScreen;
            frmbidders.ShowDialog();
        }

        // Added By Varun

        // For update combo value
        Object newEnteredValue = null;
        private void dgvContracts_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            if (e.ColumnIndex == 3)
            {
                if (dgvContracts.CurrentCell.IsInEditMode)
                {
                    if (dgvContracts.CurrentCell.GetType() == typeof(DataGridViewComboBoxCell))
                    {
                        DataGridViewComboBoxCell cell =
                        (DataGridViewComboBoxCell)dgvContracts.Rows[e.RowIndex].Cells[e.ColumnIndex];
                        cell.Value = e.FormattedValue;
                        cell.Selected = true;
                        newEnteredValue = e.FormattedValue;
                    }
                }
            }
        }
        // Added By Varun

        // For update combo value
        private void dgvContracts_CellValidated(object sender, DataGridViewCellEventArgs e)
        {
            // the cells under the column of index 1 are going to display
            //the property of a complex type
            if (dgvContracts.CurrentCell.GetType() == typeof(DataGridViewComboBoxCell))
            {
                DataGridViewCell cell = dgvContracts.Rows[e.RowIndex].Cells[e.ColumnIndex];
                cell.Value = newEnteredValue;
                cell.Selected = true;
                dgvContracts.CurrentCell.DataGridView.EndEdit(DataGridViewDataErrorContexts.Commit);
            }

        }

        clsDatabase dalCls = new clsDatabase("");
        string strEligibleTenderTypes = null;

        private void grpEligibleCompaniesCheckBoxes_CheckedChanged(object sender, EventArgs e)
        {
            if (isOnLoad != false)
            {
                StringBuilder strBuild = new StringBuilder();
                var checked_boxes = grpEligibleCompanies.Controls.OfType<CheckBox>().Where(c => c.Checked);
                foreach (CheckBox cbx in checked_boxes)
                {

                    if (cbx.Text == "Local")
                    {
                        if (strBuild.Length != 0)
                            strBuild.Append(",Local");
                        else
                            strBuild.Append("Local");
                    }
                    if (cbx.Text == "International")
                    {
                        if (strBuild.Length != 0)
                            strBuild.Append(",International");
                        else
                            strBuild.Append("International");
                    }
                    if (cbx.Text == "Joint Venture")
                    {
                        if (strBuild.Length != 0)
                            strBuild.Append(",Joint Venture");
                        else
                            strBuild.Append("Joint Venture");
                    }
                }
                try
                {
                    clsDatabase clsDb = new clsDatabase(connStr);
                    clsDb.ConnectDB();
                    strEligibleTenderTypes = strBuild.ToString();
                    clsDb.ExecuteNonQuery("update PROJECTS set EligibleTenderTypes='" + strBuild.ToString() + "' where proj_id=" + _projID);
                    clsDb.DisconnectDB();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while updating eligible tender types", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void txtTenderBond_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }
        private void txtTenderBond_KeyDown_1(object sender, KeyEventArgs e)
        {
            nonNumberEntered = false;
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9) //|| e.KeyCode == Keys.Decimal
            {
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    if ((e.KeyCode != Keys.Back) & (e.KeyCode != Keys.Enter))
                    {
                        nonNumberEntered = true;
                    }
                }
            }
            if (txtTenderBond.Text == "")
            {
                if ((e.KeyData != Keys.Back) & (e.KeyCode != Keys.Enter))
                {
                    if (clsForTE.CheckProjectCostDataExist(_projID) == false)
                    {
                        clsForTS.InsertTS_TenderBond_ProjectCostData(txtTenderBond.Text, _projID);
                    }
                    else
                    {
                        clsForTS.UpdateTS_TenderBond_ProjectCostData(txtTenderBond.Text, _projID);
                    }
                }
            }
        }
        private void InsertData()
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"INSERT INTO ProjectTypes(prjID,prjType,Create_Date,Create_User) VALUES " +
                        " (@projId,@prjType,@CreateDate,@CreateUser)";

                        cmd.Parameters.AddWithValue("@projId", ProjectId);
                        cmd.Parameters.AddWithValue("@prjType", txtCmpType.Text.Trim());
                        cmd.Parameters.AddWithValue("@CreateDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@CreateUser", _userName);
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void UpdateData(string updateVal)
        {
            string strVal = txtCmpType.Text;
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"Update ProjectTypes SET prjType = @prjType,Update_Date = @UpdateDate,Update_User = @UpdateUser where prjID = @projId";
                        cmd.Parameters.AddWithValue("@projId", ProjectId);
                        cmd.Parameters.AddWithValue("@prjType", updateVal);
                        cmd.Parameters.AddWithValue("@UpdateDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@UpdateUser", _userName);
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private Boolean getData(int prjID)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = "SELECT prjType FROM ProjectTypes where prjID = " + prjID + "";
                        cmd.CommandTimeout = 80;
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                txtCmpType.Text = dr[0].ToString();
                                return true;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            return false;
        }
        // Functionality added by sreedhar on Jan 21st 14 for faisal request
        private void button1_Click(object sender, EventArgs e)
        {
            string strVal = string.Empty;
            strVal = txtCmpType.Text;

            if (getData(ProjectId) == false)
            {
                InsertData();
                getData(ProjectId);
            }
            else
            {
                UpdateData(strVal);
                getData(ProjectId);
            }
        }

        // Added by Varun on 23/02/14 for formatting the amount
        private void dgvContracts_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.ColumnIndex == 1)
            {
                object val = dgvContracts.Rows[e.RowIndex].Cells[1].Value;
                if ((val != null) && !object.ReferenceEquals(val, DBNull.Value))
                {
                    e.Value = string.Format("{0:#,##0.00}", double.Parse(dgvContracts.Rows[e.RowIndex].Cells[1].Value.ToString()));//#,##0
                }
            }
        }

        frmTenderSubmission frmTndrSub = null;
        private void btnGenerateReceipt_Click(object sender, EventArgs e)
        {

            //commCls.ExportToPDF(strCon,sqlCom,null,null,txtTenderNo.Text,_prjCode,proj_Title,_projID,null,null,0,null,txtDocumentFee.Text,
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (_profileName != "VIEW ALL")
            {
                if (mUserRightsColl.Contains("19"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }

                SentDocProperties sentDocProp = new SentDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), 3, _userName, true);
                sentDocProp.StartPosition = FormStartPosition.CenterParent;
                sentDocProp.ShowDialog();

                commCls.FillGridSentDocsInfo(Convert.ToInt16(lblProjID.Text),ref dgvTE_Sent, 3);
            }
        }

        private void txtTechEvalProposedWorkDays_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }

        private void txtFinEvalProposedWorkDays_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Contains("46"))
            {
                MessageBox.Show("You have no privilege, Contact administrator");
                return;
            }

            int iCnt = 0;
            for (int iCounter = 0; iCounter < dgvCntrStage3.RowCount; iCounter++)
            {
                DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgvCntrStage3.Rows[iCounter].Cells[0];
                if (chkactive.Value != null)
                {
                    if (chkactive.Value.ToString().ToLower() == "true")
                        iCnt = iCnt + 1;
                }
            }
            if (iCnt > 1)
            {
                MessageBox.Show("Please select only one record to delete", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else if (iCnt == 0)
            {
                MessageBox.Show("Please click the checkbox of the record you wish to delete", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            DialogResult dlgResult = DialogResult.Yes;
            dlgResult = MessageBox.Show(" Are you sure you want to DELETE the record?", "Delete Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (dlgResult.ToString() == "Yes")
            {
                clsForCP = new clsCP_Stage(_userName, mIsHeadOfSection);
                for (int iCounter = 0; iCounter < dgvCntrStage3.RowCount; iCounter++)
                {
                    DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgvCntrStage3.Rows[iCounter].Cells[0];
                    if (chkactive.Value != null)
                    {
                        if (chkactive.Value.ToString().ToLower() == "true")
                        {
                            string sqlUpdate = "Delete from Contractors where Bidder_ID = @bidID and proj_id=@projId";
                            using (SqlConnection sqlCn = new SqlConnection(connStr))
                            {
                                sqlCn.Open();
                                using (SqlCommand sqlCmd = new SqlCommand(sqlUpdate, sqlCn))
                                {
                                    sqlCmd.Parameters.AddWithValue("@bidID", dgvCntrStage3.Rows[iCounter].Cells[5].Value);
                                    sqlCmd.Parameters.AddWithValue("@projId", dgvCntrStage3.Rows[iCounter].Cells[6].Value);
                                    sqlCmd.ExecuteNonQuery();
                                }
                                sqlCn.Close();
                                bool isUpdated = false;
                                if (msk_dtpTE_datesent1.Text != "" & msk_dtpFE_datesentfin1.Text == "")
                                {
                                    clsForCP.FillContractsGrid_TE(dgvCntrStage3, _projID, 3);
                                    isUpdated = true;
                                }
                                else if (msk_dtpTE_datesent1.Text != "" & msk_dtpFE_datesentfin1.Text != "")
                                {
                                    if (Convert.ToDateTime(msk_dtpTE_datesent1.Text.ToString()).CompareTo(Convert.ToDateTime(msk_dtpFE_datesentfin1.Text.ToString())) == 0)
                                    {
                                        clsForCP.FillContractsGrid_TE(dgvCntrStage3, _projID, 3);
                                        isUpdated = true;
                                    }
                                    else if (Convert.ToDateTime(msk_dtpTE_datesent1.Text.ToString()).CompareTo(Convert.ToDateTime(msk_dtpFE_datesentfin1.Text.ToString())) != 0)
                                    {
                                        clsForCP.FillContractsGrid_TE(dgvCntrStage3, _projID, 5);
                                        isUpdated = true;
                                    }
                                }

                                if (isUpdated)
                                    FillProjectInfo();
                            }
                        }
                    }
                }
            }

        }

        private void btnSaveMinistry_Click(object sender, EventArgs e)
        {
            UpdateMinistryCode();
        }

        private void btnBudgetRefNo_Click(object sender, EventArgs e)
        {
            UpdateBudgetCode();
        }

        private void btnWOTenderSubmission_Click(object sender, EventArgs e)
        {

        }

        private void btnWorkOrder_Click(object sender, EventArgs e)
        {
            frmWorkOrders frmWorkOrders = null;
            frmWorkOrders = new MDI_ParenrForm.Projects.frmWorkOrders(mUserRightsColl, _projID, txtTenderNo.Text, txtproj.Text, _userName, mIsHeadOfSection,false);
            frmWorkOrders.StartPosition = FormStartPosition.CenterParent;
            frmWorkOrders.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Count != 0)         // For TE
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }
            if (cmbTenderStatusChange.SelectedValue == null)
            {
                MessageBox.Show("Please select a Tender Status");
                cmbTenderStatusChange.Focus();
                return;
            }
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        if (cmbTenderStatusChange.SelectedValue.ToString().Equals("1") || cmbTenderStatusChange.SelectedValue.ToString().Equals("2") || cmbTenderStatusChange.SelectedValue.ToString().Equals("3") || cmbTenderStatusChange.SelectedValue.ToString().Equals("4") || cmbTenderStatusChange.SelectedValue.ToString().Equals("5") ||
                            cmbTenderStatusChange.SelectedValue.ToString().Equals("6"))
                        {
                            if (cmbTenderStatusChange.SelectedValue.ToString().Equals("1"))
                            {
                                cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]=" + cmbTenderStatusChange.SelectedValue + ",stage_id=1,update_user='" + _userName + "',update_date='" + DateTime.Now.ToString() + "' Where proj_id=@projId"; //1==Prepare Tender Documents
                            }
                            else if (cmbTenderStatusChange.SelectedValue.ToString().Equals("2"))
                            {
                                cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]=" + cmbTenderStatusChange.SelectedValue + ",stage_id=2,update_user='" + _userName + "',update_date='" + DateTime.Now.ToString() + "' Where proj_id=@projId"; //2==Tendering Stage
                            }
                            else if (cmbTenderStatusChange.SelectedValue.ToString().Equals("3") || cmbTenderStatusChange.SelectedValue.ToString().Equals("4") || cmbTenderStatusChange.SelectedValue.ToString().Equals("5"))
                            {
                                cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]=" + cmbTenderStatusChange.SelectedValue + ",stage_id=3,update_user='" + _userName + "',update_date='" + DateTime.Now.ToString() + "' Where proj_id=@projId"; //3==Tender Evaluation & Award
                            }
                            else if (cmbTenderStatusChange.SelectedValue.ToString().Equals("6"))
                            {
                                cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]=" + cmbTenderStatusChange.SelectedValue + ",stage_id=4,update_user='" + _userName + "',update_date='" + DateTime.Now.ToString() + "' Where proj_id=@projId"; //4==Contracts Process
                            }                            
                            
                        }

                        if (cmbTenderStatusChange.SelectedValue.ToString() == "7")
                        {
                            cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]=" + cmbTenderStatusChange.SelectedValue + ",stage_id=6,update_user='" + _userName + "',update_date='" + DateTime.Now.ToString() + "' Where proj_id=@projId";
                        }
                        else if (cmbTenderStatusChange.SelectedValue.ToString() == "16")
                        {
                            cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]=" + cmbTenderStatusChange.SelectedValue + ",isDeleted=0,update_user='" + _userName + "',update_date='" + DateTime.Now.ToString() + "' Where proj_id=@projId";
                        }
                        else if (cmbTenderStatusChange.SelectedValue.ToString() == "17")
                        {
                            cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]=" + cmbTenderStatusChange.SelectedValue + ",update_user='" + _userName + "',update_date='" + DateTime.Now.ToString() + "' Where proj_id=@projId";
                        }
                        else if (cmbTenderStatusChange.SelectedValue.ToString() == "18")
                        {                            
                            cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]=" + cmbTenderStatusChange.SelectedValue + ",isDeleted=1,tender_no='',update_user='" + _userName + "',update_date='" + DateTime.Now.ToString() + "' Where proj_id=@projId";
                        }
                        cmd.Parameters.AddWithValue("@projId", _projID);
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        MessageBox.Show("Tender Status updated successfully");
                    }

                }
                FillProjectInfo();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private bool ValidateTenderAwardApprovalDate(DateTimePicker dtpDate, MaskedTextBox setDate, bool isSubmit)
        {
            bool isResult = true;
            if (isSubmit == false)
            {
                if (CheckBlankSendDatesOfTechnicalEvalStage() && CheckBlankSendDatesOfFinEvalStage()
                && CheckBlankSendDatesOfFinTenderRevStage()) //&& CheckBlankSendDatesOfTechnicalTenderReviewStage()
                {

                }
                else
                {
                    return isResult = false;
                }
                //if (stageName.Equals("Technical Evaluation")) //|| !stageName.Equals("Financial Tender Review") || !stageName.Equals("Financial Evaluation")
                //{
                if (msk_dtpTE_daterec1.Text != "")
                {
                    if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) < 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                    {
                        MessageBox.Show("Tender Award Approval Date cannot be less than Technical Evaluation Received Date (First Evaluation)");
                        setDate.Focus();
                        isResult = false;
                        return isResult;
                    }
                }
                if (msk_dtpTE_datesent2.Text != "")
                {
                    if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_datesent2.Text)) < 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                    {
                        MessageBox.Show("Tender Award Approval Date cannot be less than Technical Evaluation Send Date (Second Evaluation)");
                        setDate.Focus();
                        isResult = false;
                        return isResult;
                    }
                }

                if (msk_dtpTE_daterec2.Text != "")
                {
                    if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec2.Text)) < 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                    {
                        MessageBox.Show("Tender Award Approval Date cannot be less than Technical Evaluation Received Date (Second Evaluation)");
                        setDate.Focus();
                        isResult = false;
                        return isResult;
                    }
                }

                //if (msk_dtpTTR_datesent1.Text.Trim() != "")
                //{
                //    if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTTR_datesent1.Text)) <= 0)
                //    {
                //        MessageBox.Show("Tender Award Approval Date cannot be less than and equal to Technical Tender Review Send Date (First Evaluation)");
                //        setDate.Focus();
                //        isResult = false;
                //        return isResult;
                //    }

                //}
                //if (msk_dtpTTR_daterec1.Text.Trim() != "")
                //{
                //    if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTTR_daterec1.Text)) <= 0)
                //    {
                //        MessageBox.Show("Tender Award Approval Date cannot be less than and equal to Technical Tender Review Received Date (First Evaluation)");
                //        setDate.Focus();
                //        isResult = false;
                //        return isResult;
                //    }

                //}
                //if (msk_dtpTTR_datesent2.Text.Trim() != "")
                //{
                //    if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTTR_datesent2.Text)) <= 0)
                //    {
                //        MessageBox.Show("Tender Award Approval Date cannot be less than and equal to Technical Tender Review Send Date (Second Evaluation)");
                //        setDate.Focus();
                //        isResult = false;
                //        return isResult;
                //    }
                //}
                //if (msk_dtpTTR_daterec2.Text.Trim() != "")
                //{
                //    if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTTR_daterec2.Text)) <= 0)
                //    {
                //        MessageBox.Show("Tender Award Approval Date cannot be less than and equal to Technical Tender Review Received Date (Second Evaluation)");
                //        setDate.Focus();
                //        isResult = false;
                //        return isResult;
                //    }
                //}
                ////}
                ////if (stageName.Equals("Technical Tender Review"))
                ////{

                //if (msk_dtpTTR_datesent1.Text.Trim() != "")
                //{
                //    if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTTR_datesent1.Text)) <= 0)
                //    {
                //        MessageBox.Show("Tender Award Approval Date cannot be less than and equal to Technical Tender Review Send Date (First Evaluation)");
                //        setDate.Focus();
                //        isResult = false;
                //        return isResult;
                //    }

                //}

                //if (msk_dtpTTR_daterec1.Text.Trim() != "")
                //{
                //    if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTTR_daterec1.Text)) <= 0)
                //    {
                //        MessageBox.Show("Tender Award Approval Date cannot be less than and equal to Technical Tender Review Received Date (First Evaluation)");
                //        setDate.Focus();
                //        isResult = false;
                //        return isResult;
                //    }

                //}

                //if (msk_dtpTTR_datesent2.Text.Trim() != "")
                //{
                //    if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTTR_datesent2.Text)) <= 0)
                //    {
                //        MessageBox.Show("Tender Award Approval Date cannot be less than and equal to Technical Tender Review Send Date (Second Evaluation)");
                //        setDate.Focus();
                //        isResult = false;
                //        return isResult;
                //    }
                //}
                //if (msk_dtpTTR_daterec2.Text.Trim() != "")
                //{
                //    if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTTR_daterec2.Text)) <= 0)
                //    {
                //        MessageBox.Show("Tender Award Approval Date cannot be less than and equal to Technical Tender Review Received Date (Second Evaluation)");
                //        setDate.Focus();
                //        isResult = false;
                //        return isResult;
                //    }
                //}
                //}
                //if (stageName.Equals("Technical Evaluation") || stageName.Equals("Financial Evaluation"))
                //{
                if (msk_dtpFE_daterecFin1.Text != "")
                {
                    if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFE_daterecFin1.Text)) < 0)
                    {

                        MessageBox.Show("Tender Award Approval Date cannot be less than Financial Evaluation Received Date (First Evaluation)");
                        setDate.Focus();
                        isResult = false;
                        return isResult;
                    }
                }
                if (msk_dtpFE_datesentfin1.Text != "")
                {
                    if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFE_datesentfin1.Text)) < 0)
                    {
                        MessageBox.Show("Tender Award Approval Date cannot be less than Financial Evaluation Send Date (First Evaluation)");
                        setDate.Focus();
                        isResult = false;
                        return isResult;
                    }
                }
                if (msk_dtpFE_daterecFin2.Text != "")
                {
                    if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFE_daterecFin2.Text)) < 0)
                    {
                        MessageBox.Show("Tender Award Approval Date cannot be less than Financial Evaluation Received Date (Second Evaluation)");
                        setDate.Focus();
                        isResult = false;
                        return isResult;
                    }
                }
                //}
                //if (stageName.Equals("Financial Evaluation"))
                //{
                //if (msk_dtpFTR_datesent1.Text != "")
                //{
                //    if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFTR_datesent1.Text)) <= 0)
                //    {
                //        MessageBox.Show("Tender Award Approval Date cannot be less than and equal to Financial Tender Review Send Date (First Evaluation)");
                //        setDate.Focus();
                //        isResult = false;
                //        return isResult;
                //    }
                //}
                //if (msk_dtpFTR_daterec1.Text != "")
                //{
                //    if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFTR_daterec1.Text)) <= 0)
                //    {
                //        MessageBox.Show("Tender Award Approval Date cannot be less than and equal to Financial Tender Review Received Date (First Evaluation)");
                //        setDate.Focus();
                //        isResult = false;
                //        return isResult;
                //    }
                //}
                //if (msk_dtpFTR_datesent2.Text != "")
                //{
                //    if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFTR_datesent2.Text)) <= 0)
                //    {
                //        MessageBox.Show("Tender Award Approval Date cannot be less than and equal to Financial Tender Review Send Date (Second Evaluation)");
                //        setDate.Focus();
                //        isResult = false;
                //        return isResult;
                //    }
                //}
                //if (msk_dtpFTR_daterec2.Text != "")
                //{
                //    if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFTR_daterec2.Text)) >= 0)
                //    {
                //        MessageBox.Show("Tender Award Approval Date cannot be less than and equal to Financial Tender Review Received Date (Second Evaluation)");
                //        setDate.Focus();
                //        isResult = false;
                //        return isResult;
                //    }
                //}

                //}
                //else if (dtpDateReceived.Name.Equals("msk_dtpFE_daterecFin1"))
                //{              

                //Modified by Varun on 13/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
                if (isResult != false)
                {
                    if (dtpDate.Value.ToString().Trim() != "")
                    {
                        setDate.Text = Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
                        isResult = true;
                        return isResult;
                    }
                }
                else
                {
                    setDate.Focus();
                }

            }
            else
            {
                if (setDate.Text.Trim() != "")
                {
                    CheckBlankSendDatesOfTechnicalEvalStage();
                    //CheckBlankSendDatesOfTechnicalTenderReviewStage();
                    CheckBlankSendDatesOfFinEvalStage();
                    CheckBlankSendDatesOfFinTenderRevStage();
                    if (msk_dtpTE_daterec1.Text != "")
                    {
                        if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) < 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                        {
                            MessageBox.Show("Tender Award Approval Date cannot be less than Technical Evaluation Received Date (First Evaluation)"); //and equal to
                            setDate.Focus();
                            isResult = false;
                            return isResult;
                        }
                    }
                    if (msk_dtpTE_datesent2.Text != "")
                    {
                        if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpTE_datesent2.Text)) < 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                        {
                            MessageBox.Show("Tender Award Approval Date cannot be less than Technical Evaluation Send Date (Second Evaluation)"); //and equal to
                            setDate.Focus();
                            isResult = false;
                            return isResult;
                        }
                    }

                    if (msk_dtpTE_daterec2.Text != "")
                    {
                        if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec2.Text)) < 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                        {
                            MessageBox.Show("Tender Award Approval Date cannot be less than Technical Evaluation Received Date (Second Evaluation)"); //and equal to
                            setDate.Focus();
                            isResult = false;
                            return isResult;
                        }
                    }

                    //if (msk_dtpTTR_datesent1.Text.Trim() != "")
                    //{
                    //    if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpTTR_datesent1.Text)) <= 0)
                    //    {
                    //        MessageBox.Show("Tender Award Approval Date cannot be less than and equal to Technical Tender Review Send Date (First Evaluation)");
                    //        setDate.Focus();
                    //        isResult = false;
                    //        return isResult;
                    //    }

                    //}
                    //if (msk_dtpTTR_daterec1.Text.Trim() != "")
                    //{
                    //    if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpTTR_daterec1.Text)) <= 0)
                    //    {
                    //        MessageBox.Show("Tender Award Approval Date cannot be less than and equal to Technical Tender Review Received Date (First Evaluation)");
                    //        setDate.Focus();
                    //        isResult = false;
                    //        return isResult;
                    //    }

                    //}
                    //if (msk_dtpTTR_datesent2.Text.Trim() != "")
                    //{
                    //    if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpTTR_datesent2.Text)) <= 0)
                    //    {
                    //        MessageBox.Show("Tender Award Approval Date cannot be less than and equal to Technical Tender Review Send Date (Second Evaluation)");
                    //        setDate.Focus();
                    //        isResult = false;
                    //        return isResult;
                    //    }
                    //}
                    //if (msk_dtpTTR_daterec2.Text.Trim() != "")
                    //{
                    //    if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpTTR_daterec2.Text)) <= 0)
                    //    {
                    //        MessageBox.Show("Tender Award Approval Date cannot be less than and equal to Technical Tender Review Received Date (Second Evaluation)");
                    //        setDate.Focus();
                    //        isResult = false;
                    //        return isResult;
                    //    }
                    //}
                    //}
                    //if (stageName.Equals("Technical Tender Review"))
                    //{

                    //if (msk_dtpTTR_datesent1.Text.Trim() != "")
                    //{
                    //    if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpTTR_datesent1.Text)) <= 0)
                    //    {
                    //        MessageBox.Show("Tender Award Approval Date cannot be less than and equal to Technical Tender Review Send Date (First Evaluation)");
                    //        setDate.Focus();
                    //        isResult = false;
                    //        return isResult;
                    //    }

                    //}

                    //if (msk_dtpTTR_daterec1.Text.Trim() != "")
                    //{
                    //    if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpTTR_daterec1.Text)) <= 0)
                    //    {
                    //        MessageBox.Show("Tender Award Approval Date cannot be less than and equal to Technical Tender Review Received Date (First Evaluation)");
                    //        setDate.Focus();
                    //        isResult = false;
                    //        return isResult;
                    //    }

                    //}

                    //if (msk_dtpTTR_datesent2.Text.Trim() != "")
                    //{
                    //    if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpTTR_datesent2.Text)) <= 0)
                    //    {
                    //        MessageBox.Show("Tender Award Approval Date cannot be less than and equal to Technical Tender Review Send Date (Second Evaluation)");
                    //        setDate.Focus();
                    //        isResult = false;
                    //        return isResult;
                    //    }
                    //}
                    //if (msk_dtpTTR_daterec2.Text.Trim() != "")
                    //{
                    //    if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpTTR_daterec2.Text)) <= 0)
                    //    {
                    //        MessageBox.Show("Tender Award Approval Date cannot be less than and equal to Technical Tender Review Received Date (Second Evaluation)");
                    //        setDate.Focus();
                    //        isResult = false;
                    //        return isResult;
                    //    }
                    //}
                    //}
                    //if (stageName.Equals("Technical Evaluation") || stageName.Equals("Financial Evaluation"))
                    //{
                    if (msk_dtpFE_daterecFin1.Text != "")
                    {
                        if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpFE_daterecFin1.Text)) < 0)
                        {

                            MessageBox.Show("Tender Award Approval Date cannot be less than Financial Evaluation Received Date (First Evaluation)"); //and equal to
                            setDate.Focus();
                            isResult = false;
                            return isResult;
                        }
                    }
                    if (msk_dtpFE_datesentfin1.Text != "")
                    {
                        if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpFE_datesentfin1.Text)) < 0)
                        {
                            MessageBox.Show("Tender Award Approval Date cannot be less than Financial Evaluation Send Date (First Evaluation)"); //and equal to
                            setDate.Focus();
                            isResult = false;
                            return isResult;
                        }
                    }
                    if (msk_dtpFE_daterecFin2.Text != "")
                    {
                        if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpFE_daterecFin2.Text)) < 0)
                        {
                            MessageBox.Show("Tender Award Approval Date cannot be less than Financial Evaluation Received Date (Second Evaluation)"); //and equal to
                            setDate.Focus();
                            isResult = false;
                            return isResult;
                        }
                    }
                    //}
                    //if (stageName.Equals("Financial Evaluation"))
                    //{
                    //if (msk_dtpFTR_datesent1.Text != "")
                    //{
                    //    if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpFTR_datesent1.Text)) <= 0)
                    //    {
                    //        MessageBox.Show("Tender Award Approval Date cannot be less than and equal to Financial Tender Review Send Date (First Evaluation)");
                    //        setDate.Focus();
                    //        isResult = false;
                    //        return isResult;
                    //    }
                    //}
                    //if (msk_dtpFTR_daterec1.Text != "")
                    //{
                    //    if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpFTR_daterec1.Text)) <= 0)
                    //    {
                    //        MessageBox.Show("Tender Award Approval Date cannot be less than and equal to Financial Tender Review Received Date (First Evaluation)");
                    //        setDate.Focus();
                    //        isResult = false;
                    //        return isResult;
                    //    }
                    //}
                    //if (msk_dtpFTR_datesent2.Text != "")
                    //{
                    //    if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpFTR_datesent2.Text)) <= 0)
                    //    {
                    //        MessageBox.Show("Tender Award Approval Date cannot be less than and equal to Financial Tender Review Send Date (Second Evaluation)");
                    //        setDate.Focus();
                    //        isResult = false;
                    //        return isResult;
                    //    }
                    //}
                    //if (msk_dtpFTR_daterec2.Text != "")
                    //{
                    //    if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpFTR_daterec2.Text)) <= 0)
                    //    {
                    //        MessageBox.Show("Tender Award Approval Date cannot be less than and equal to Financial Tender Review Received Date (Second Evaluation)");
                    //        setDate.Focus();
                    //        isResult = false;
                    //        return isResult;
                    //    }
                    //}
                    //else
                    //{
                    //Modified by Varun on 13/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
                    if (isResult != false)
                    {
                        if (setDate.Text.Contains("1900"))
                        {
                            setDate.Text = Convert.ToDateTime(setDate.Text).ToString("dd/MMM/yyyy");
                            isResult = true;
                            return isResult;
                        }
                    }
                    else
                    {
                        setDate.Focus();
                    }
                    //}
                }
            }
            //else
            //{
            //    //Modified by Varun on 13/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            //    setReceivedDate.Text = Convert.ToDateTime(dtpDateReceived.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
            //    isResult = true;
            //}
            //}
            //else if (dtpDateReceived.Name.Equals("dtpTTR_daterec1"))
            //{



            return isResult;
        }

        private bool ValidateDatesRelatedToTTR(DateTimePicker dtpDate, MaskedTextBox setDate, string stageName, string evalStagePosition, string dateType, bool isSubmit)
        {
            bool isResult = true;
            if (isSubmit == false)
            {
                //if (msk_dtpTTR_datesent1.Text.Trim() != "")
                //{
                //    if (!msk_dtpTTR_datesent1.Name.Equals("msk_" + dtpDate.Name))
                //    {
                //        if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTTR_datesent1.Text)) >= 0)
                //        {
                //            MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Technical Tender Review Send Date (First Evaluation)");
                //            setDate.Focus();
                //            isResult = false;
                //            return isResult;
                //        }
                //    }

                //}
                //if (msk_dtpTTR_daterec1.Text.Trim() != "")
                //{
                //    if (!msk_dtpTTR_daterec1.Name.Equals("msk_" + dtpDate.Name))
                //    {
                //        if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTTR_daterec1.Text)) >= 0)
                //        {
                //            MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Technical Tender Review Received Date (First Evaluation)");
                //            setDate.Focus();
                //            isResult = false;
                //            return isResult;
                //        }
                //    }
                //}
                //if (msk_dtpTTR_datesent2.Text.Trim() != "")
                //{
                //    if (!msk_dtpTTR_datesent2.Name.Equals("msk_" + dtpDate.Name))
                //    {
                //        if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTTR_datesent2.Text)) >= 0)
                //        {
                //            MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Technical Tender Review Send Date (Second Evaluation)");
                //            setDate.Focus();
                //            isResult = false;
                //            return isResult;
                //        }
                //    }
                //}
                //if (msk_dtpTTR_daterec2.Text.Trim() != "")
                //{
                //    if (!msk_dtpTTR_daterec2.Name.Equals("msk_" + dtpDate.Name))
                //    {
                //        if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTTR_daterec2.Text)) >= 0)
                //        {
                //            MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than or equal to Technical Tender Review Received Date (Second Evaluation)");
                //            setDate.Focus();
                //            isResult = false;
                //            return isResult;
                //        }
                //    }
                //}
            }
            else
            {
                //if (msk_dtpTTR_datesent1.Text.Trim() != "")
                //{
                //    if (!msk_dtpTTR_datesent1.Name.Equals(setDate.Name))
                //    {
                //        if (!stageName.Equals("Technical Tender Review"))
                //        {
                //            if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpTTR_datesent1.Text)) >= 0)
                //            {
                //                MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Technical Tender Review Send Date (First Evaluation)");
                //                setDate.Focus();
                //                isResult = false;
                //                return isResult;
                //            }
                //        }
                //        else
                //        {
                //            if (Convert.ToDateTime(msk_dtpTTR_datesent1.Text).CompareTo(Convert.ToDateTime(setDate.Text)) >= 0)
                //            {
                //                MessageBox.Show(stageName + " Send Date (First Evaluation) cannot be greater than and equal to " + stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation)");
                //                setDate.Focus();
                //                isResult = false;
                //                return isResult;
                //            }
                //        }
                //    }
                //}
                //if (msk_dtpTTR_daterec1.Text.Trim() != "")
                //{
                //    if (!msk_dtpTTR_daterec1.Name.Equals(setDate.Name))
                //    {
                //        if (setDate.Name.Equals("msk_dtpTTR_datesent2"))
                //        {
                //            if (Convert.ToDateTime(msk_dtpTTR_daterec1.Text).CompareTo(Convert.ToDateTime(setDate.Text)) >= 0)
                //            {
                //                MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Technical Tender Review Received Date (First Evaluation)");
                //                setDate.Focus();
                //                isResult = false;
                //                return isResult;
                //            }
                //        }
                //        else if (setDate.Name.Equals("msk_dtpTTR_daterec2"))
                //        {
                //            if (Convert.ToDateTime(msk_dtpTTR_daterec1.Text).CompareTo(Convert.ToDateTime(setDate.Text)) >= 0)
                //            {
                //                MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Technical Tender Review Received Date (First Evaluation)");
                //                setDate.Focus();
                //                isResult = false;
                //                return isResult;
                //            }
                //        }
                //        else
                //        {
                //            if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpTTR_daterec1.Text)) >= 0)
                //            {
                //                MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Technical Tender Review Received Date (First Evaluation)");
                //                setDate.Focus();
                //                isResult = false;
                //                return isResult;
                //            }
                //        }
                //    }
                //    else
                //    {
                //        if (Convert.ToDateTime(msk_dtpTTR_daterec1.Text).CompareTo(Convert.ToDateTime(setDate.Text)) >= 0)
                //        {
                //            //MessageBox.Show(stageName + " Received Date (First Evaluation) cannot be greater than and equal to " + stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation)");
                //            //setDate.Focus();
                //            //isResult = false;
                //            //return isResult;
                //        }
                //    }

                //}
                //if (msk_dtpTTR_datesent2.Text.Trim() != "")
                //{
                //    if (!msk_dtpTTR_datesent2.Name.Equals(setDate.Name))
                //    {
                //        if (!msk_dtpTTR_datesent2.Name.Equals(setDate.Name))
                //        {
                //            if (setDate.Name.Equals("msk_dtpTTR_daterec2"))
                //            {
                //                if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpTTR_datesent2.Text)) < 0)
                //                {
                //                    MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be less than Technical Tender Review Send Date (Second Evaluation)");
                //                    setDate.Focus();
                //                    isResult = false;
                //                    return isResult;
                //                }
                //            }
                //        }
                //    }
                //}
                //if (msk_dtpTTR_daterec2.Text.Trim() != "")
                //{
                //    if (!msk_dtpTTR_daterec2.Name.Equals(setDate.Name))
                //    {
                //        if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpTTR_daterec2.Text)) > 0)
                //        {
                //            MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than or equal to Technical Tender Review Received Date (Second Evaluation)");
                //            setDate.Focus();
                //            isResult = false;
                //            return isResult;
                //        }
                //    }
                //}
            }
            return isResult;
        }

        private bool ValidatingDateControls(DateTimePicker dtpDate, MaskedTextBox setDate, string stageName, string evalStagePosition, string dateType, bool isSubmit)
        {
            bool isResult = true;
            if (isSubmit == false)
            {

                if (stageName.Equals("Technical Evaluation")) //|| !stageName.Equals("Financial Tender Review") || !stageName.Equals("Financial Evaluation")
                {
                    //if (msk_dtpTE_daterec1.Text != "")
                    //{
                    //    if (!msk_dtpTE_daterec1.Name.Equals("msk_" + dtpDate.Name))
                    //    {
                    //        if (dtpDate.Name.Equals("dtpTE_datesent1"))
                    //        {
                    //            if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                    //            {
                    //                MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than Technical Evaluation Received Date (First Evaluation)");
                    //                setDate.Focus();
                    //                isResult = false;
                    //                return isResult;
                    //            }
                    //        }
                    //        else
                    //        {
                    //            if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) <= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                    //            {
                    //                MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be less than or equal to Technical Evaluation Received Date (First Evaluation)");
                    //                setDate.Focus();
                    //                isResult = false;
                    //                return isResult;
                    //            }
                    //        }
                    //    }
                    //}
                    //else
                    //{
                    //    MessageBox.Show("Cannot enter date in "+stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) because Technical Evaluation Received Date (First Evaluation) is blank");
                    //    return isResult==false;
                    //}

                    if (msk_dtpTE_datesent2.Text != "")
                    {
                        //if (!msk_dtpTE_datesent2.Name.Equals("msk_" + dtpDate.Name))
                        //{
                        //    if (!msk_dtpTE_daterec2.Name.Equals("msk_" + dtpDate.Name))
                        //    {
                        //        if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_datesent2.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                        //        {
                        //            if (dtpDate.Name.Equals("dtpTE_datesent1") || dtpDate.Name.Equals("dtpTE_daterec1"))
                        //            {
                        //                if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_datesent2.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                        //                {
                        //                    MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Technical Evaluation Send Date (Second Evaluation)");
                        //                }
                        //            }
                        //            else
                        //            {
                        //                MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than Technical Evaluation Send Date (Second Evaluation)");
                        //            }
                        //            setDate.Focus();
                        //            isResult = false;
                        //            return isResult;
                        //        }
                        //    }
                        //    else
                        //    {
                        //        if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_datesent2.Text)) < 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                        //        {
                        //            MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be less than Technical Evaluation Send Date (Second Evaluation)");
                        //            setDate.Focus();
                        //            isResult = false;
                        //            return isResult;
                        //        }
                        //    }
                        //}
                    }
                    else
                    {
                        //if (msk_dtpTE_datesent2.Name.Equals("msk_" + dtpDate.Name))
                        //{                           
                        //    msk_dtpTE_datesent2.Text = dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture);                            
                        //}
                        //else
                        //{
                            //MessageBox.Show("Cannot enter date in " + stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) because Technical Evaluation Send Date (" + evalStagePosition + " Evaluation) is blank");
                            //return isResult == false;
                        //}
                    }

                    if (msk_dtpTE_daterec2.Text != "")
                    {
                        //if (!msk_dtpTE_daterec2.Name.Equals("msk_" + dtpDate.Name))
                        //{
                        //    if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec2.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                        //    {
                        //        if (dtpDate.Name.Equals("dtpTE_datesent1") || dtpDate.Name.Equals("dtpTE_daterec1"))
                        //        {
                        //            if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec2.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                        //            {
                        //                MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Technical Evaluation Received Date (Second Evaluation)");
                        //            }
                        //        }
                        //        else
                        //        {
                        //            MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than Technical Evaluation Send Date (Second Evaluation)");
                        //        }
                        //        setDate.Focus();
                        //        isResult = false;
                        //        return isResult;
                        //    }
                        //}
                    }
                    //isResult = ValidateDatesRelatedToTTR(dtpDate, setDate, stageName, evalStagePosition, dateType, isSubmit);
                    if (isResult == false)
                    {
                        return isResult;
                    }
                }

                if (stageName.Equals("Technical Evaluation") || stageName.Equals("Financial Evaluation") || stageName.Equals("Technical Tender Review"))
                {
                    if (msk_dtpFE_daterecFin1.Text != "")
                    {
                        if (!msk_dtpFE_daterecFin1.Name.Equals("msk_" + dtpDate.Name))
                        {
                            if (("msk_" + dtpDate.Name).Equals("msk_dtpFE_daterecFin2"))
                            {
                                if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFE_daterecFin1.Text)) < 0)
                                {
                                    //if (dtpDate.Name.Equals("dtpFE_datesentfin1") || dtpDate.Name.Equals("dtpFE_daterecFin1"))
                                    //{
                                    //    if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFE_daterecFin1.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                                    //    {
                                    MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be less than or equal to Financial Evaluation Received Date (First Evaluation)");
                                    //    }
                                    //}
                                    //else
                                    //{
                                    //    MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than Financial Evaluation Received Date (First Evaluation)");
                                    //}

                                    setDate.Focus();
                                    isResult = false;
                                    return isResult;
                                }
                            }
                            else if (("msk_" + dtpDate.Name).Equals("msk_dtpFE_datesentfin2"))
                            {
                                if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFE_daterecFin1.Text)) < 0)
                                {
                                    //if (dtpDate.Name.Equals("dtpFE_datesentfin1") || dtpDate.Name.Equals("dtpFE_daterecFin1"))
                                    //{
                                    //    if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFE_daterecFin1.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                                    //    {
                                    MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be less than or equal to Financial Evaluation Received Date (First Evaluation)");
                                    //    }
                                    //}
                                    //else
                                    //{
                                    //    MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than Financial Evaluation Received Date (First Evaluation)");
                                    //}

                                    setDate.Focus();
                                    isResult = false;
                                    return isResult;
                                }
                            }
                            else
                            {
                                if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFE_daterecFin1.Text)) > 0)
                                {
                                    if (dtpDate.Name.Equals("dtpFE_datesentfin1") || dtpDate.Name.Equals("dtpFE_daterecFin1"))
                                    {
                                        if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFE_daterecFin1.Text)) > 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                                        {
                                            MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than Financial Evaluation Received Date (First Evaluation)"); //and equal to
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than Financial Evaluation Received Date (First Evaluation)");
                                    }

                                    setDate.Focus();
                                    isResult = false;
                                    return isResult;
                                }
                            }
                        }
                    }
                    if (msk_dtpFE_datesentfin1.Text != "")
                    {
                        //if (!msk_dtpFE_datesentfin1.Name.Equals("msk_" + dtpDate.Name))
                        //{
                        //    if (("msk_" + dtpDate.Name).Equals("msk_dtpFE_daterecFin2"))
                        //    {
                        //        if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFE_datesentfin1.Text)) <= 0)
                        //        {
                        //            //if (dtpDate.Name.Equals("dtpFE_datesentfin1") || dtpDate.Name.Equals("dtpFE_daterecFin1"))
                        //            //{
                        //            //    if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFE_datesentfin1.Text)) > 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                        //            //    {
                        //            //        MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than Financial Evaluation Send Date (First Evaluation)");
                        //            //    }
                        //            //}
                        //            //else
                        //            //{
                        //            MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be less than or equal to Financial Evaluation Send Date (First Evaluation)");
                        //            //}

                        //            setDate.Focus();
                        //            isResult = false;
                        //            return isResult;
                        //        }
                        //    }
                        //    else if (("msk_" + dtpDate.Name).Equals("msk_dtpFE_datesentfin2"))
                        //    {
                        //        if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFE_datesentfin1.Text)) <= 0)
                        //        {
                        //            //if (dtpDate.Name.Equals("dtpFE_datesentfin1") || dtpDate.Name.Equals("dtpFE_daterecFin1"))
                        //            //{
                        //            //    if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFE_daterecFin1.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                        //            //    {
                        //            MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be less than or equal to Financial Evaluation Received Date (First Evaluation)");
                        //            //    }
                        //            //}
                        //            //else
                        //            //{
                        //            //    MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than Financial Evaluation Received Date (First Evaluation)");
                        //            //}

                        //            setDate.Focus();
                        //            isResult = false;
                        //            return isResult;
                        //        }
                        //    }
                        //    else
                        //    {
                        //        if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFE_datesentfin1.Text)) >= 0)
                        //        {
                        //            if (dtpDate.Name.Equals("dtpFE_datesentfin1") || dtpDate.Name.Equals("dtpFE_daterecFin1"))
                        //            {
                        //                if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFE_datesentfin1.Text)) > 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                        //                {
                        //                    MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than Financial Evaluation Send Date (First Evaluation)");
                        //                }
                        //            }
                        //            else
                        //            {
                        //                MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Financial Evaluation Send Date (First Evaluation)");
                        //            }

                        //            setDate.Focus();
                        //            isResult = false;
                        //            return isResult;
                        //        }
                        //    }
                        //}
                    }
                    if (msk_dtpFE_daterecFin2.Text != "")
                    {
                        //if (!msk_dtpFE_daterecFin2.Name.Equals("msk_" + dtpDate.Name))
                        //{
                        //    if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFE_daterecFin2.Text)) >= 0)
                        //    {
                        //        MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than or equal to Financial Evaluation Received Date (Second Evaluation)");
                        //        setDate.Focus();
                        //        isResult = false;
                        //        return isResult;
                        //    }
                        //}
                    }
                }
                if (stageName.Equals("Financial Evaluation") || stageName.Equals("Financial Tender Review"))
                {
                    //if (msk_dtpFTR_datesent1.Text != "")
                    //{
                    //    if (!msk_dtpFTR_datesent1.Name.Equals("msk_" + dtpDate.Name))
                    //    {
                    //        if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFTR_datesent1.Text)) >= 0)
                    //        {
                    //            MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than or equal to Financial Tender Review Send Date (First Evaluation)");
                    //            setDate.Focus();
                    //            isResult = false;
                    //            return isResult;
                    //        }
                    //    }
                    //}
                    //if (msk_dtpFTR_daterec1.Text != "")
                    //{
                    //    if (!msk_dtpFTR_daterec1.Name.Equals("msk_" + dtpDate.Name))
                    //    {
                    //        if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFTR_daterec1.Text)) >= 0)
                    //        {
                    //            MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Financial Tender Review Received Date (First Evaluation)");
                    //            setDate.Focus();
                    //            isResult = false;
                    //            return isResult;
                    //        }
                    //    }
                    //}
                    //if (msk_dtpFTR_datesent2.Text != "")
                    //{
                    //    if (!msk_dtpFTR_datesent2.Name.Equals("msk_" + dtpDate.Name))
                    //    {
                    //        if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFTR_datesent2.Text)) >= 0)
                    //        {
                    //            MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Financial Tender Review Send Date (Second Evaluation)");
                    //            setDate.Focus();
                    //            isResult = false;
                    //            return isResult;
                    //        }
                    //    }
                    //}
                    //if (msk_dtpFTR_daterec2.Text != "")
                    //{
                    //    if (!msk_dtpTE_daterec1.Name.Equals("msk_" + dtpDate.Name))
                    //    {
                    //        if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFTR_daterec2.Text)) >= 0)
                    //        {
                    //            MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Financial Tender Review Received Date (Second Evaluation)");
                    //            setDate.Focus();
                    //            isResult = false;
                    //            return isResult;
                    //        }
                    //    }
                    //}
                    if (msk_dtpEA_apprDate.Text != "")
                    {
                        //if (!msk_dtpEA_apprDate.Name.Equals("msk_" + dtpDate.Name))
                        //{
                        //    if (Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpEA_apprDate.Text)) >= 0)
                        //    {
                        //        MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Tender Award Approval Date");
                        //        setDate.Focus();
                        //        isResult = false;
                        //        return isResult;
                        //    }
                        //}
                    }
                }
                //else if (dtpDateReceived.Name.Equals("msk_dtpFE_daterecFin1"))
                //{              

                //Modified by Varun on 13/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
                if (isResult != false)
                {
                    if (!dtpDate.Value.ToString().Contains("1900") && dtpDate.Value.ToString().Trim() != "")
                    {
                        setDate.Text = Convert.ToDateTime(dtpDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
                    }
                    
                    //if (msk_dtpFTR_datesent1.Text != "")
                    //{
                    //    dtpFTR_daterecFin1.Value = Convert.ToDateTime(msk_dtpFTR_datesent1.Text);
                    //}
                    isResult = true;
                    return isResult;
                }
                else
                {
                    setDate.Focus();
                }

            }
            else
            {
                if (setDate.Text.Trim() != "")
                {
                    if (stageName.Equals("Technical Evaluation")) //|| !stageName.Equals("Financial Tender Review") || !stageName.Equals("Financial Evaluation")
                    {
                        if (msk_dtpTE_daterec1.Text != "")
                        {
                            if (!msk_dtpTE_daterec1.Name.Equals(setDate.Name))
                            {
                                //if (setDate.Name.Equals("msk_dtpTE_datesent1"))
                                //{
                                //    if (Convert.ToDateTime(msk_dtpTE_daterec1.Text).CompareTo(Convert.ToDateTime(setDate.Text)) < 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                                //    {
                                //        MessageBox.Show(stageName + " Received Date (" + evalStagePosition + " Evaluation) cannot be less than Technical Evaluation " + dateType + " Date (First Evaluation)");
                                //        setDate.Focus();
                                //        isResult = false;
                                //        return isResult;
                                //    }
                                //}
                                //else if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) < 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                                //{
                                //    MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be less than Technical Evaluation Received Date (First Evaluation)");
                                //    setDate.Focus();
                                //    isResult = false;
                                //    return isResult;
                                //}
                            }
                        }
                        //else
                        //{
                        //    MessageBox.Show("Cannot enter date in " + stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) because Technical Evaluation Received Date (First Evaluation) is blank");
                        //    return isResult = false;
                        //}

                        if (msk_dtpTE_datesent2.Text != "")
                        {
                            if (!msk_dtpTE_datesent2.Name.Equals(setDate.Name))
                            {
                                if (setDate.Name.Equals("msk_dtpTE_daterec2"))
                                {
                                    //if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpTE_datesent2.Text)) <= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                                    //{
                                    //    if (setDate.Name.Equals("msk_dtpTE_datesent1") || setDate.Name.Equals("msk_dtpTE_daterec1"))
                                    //    {
                                    //        if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpTE_datesent2.Text)) <= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                                    //        {
                                    //            MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be less than and equal to Technical Evaluation Send Date (Second Evaluation)");
                                    //        }
                                    //    }
                                    //    else
                                    //    {
                                    //        MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be less than Technical Evaluation Send Date (Second Evaluation)");
                                    //    }
                                    //    setDate.Focus();
                                    //    isResult = false;
                                    //    return isResult;
                                    //}
                                }
                                else
                                {
                                    if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpTE_datesent2.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                                    {
                                        //if (dtpDate.Name.Equals("dtpTE_datesent1") || dtpDate.Name.Equals("dtpTE_daterec1"))
                                        //{
                                        //    if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpTE_datesent2.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                                        //    {
                                        //        MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Technical Evaluation Send Date (Second Evaluation)");
                                        //    }
                                        //}
                                        //else
                                        //{
                                        //    MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than Technical Evaluation Send Date (Second Evaluation)");
                                        //}
                                        //setDate.Focus();
                                        //isResult = false;
                                        //return isResult;
                                    }
                                }
                            }
                        }

                        if (msk_dtpTE_daterec2.Text != "")
                        {
                            //if (!msk_dtpTE_daterec2.Name.Equals(setDate.Name))
                            //{
                            //    if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec2.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                            //    {
                            //        if (dtpDate.Name.Equals("dtpTE_datesent1") || dtpDate.Name.Equals("dtpTE_daterec1"))
                            //        {
                            //            if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec2.Text)) >= 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                            //            {
                            //                MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Technical Evaluation Received Date (Second Evaluation)");
                            //            }
                            //        }
                            //        else
                            //        {
                            //            //MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than Technical Evaluation Received Date (Second Evaluation)");
                            //        }
                            //        setDate.Focus();
                            //        isResult = false;
                            //        return isResult;
                            //    }
                            //}
                        }

                        isResult = ValidateDatesRelatedToTTR(dtpDate, setDate, stageName, evalStagePosition, dateType, isSubmit);
                        if (isResult == false)
                        {
                            return isResult;
                        }
                        //if (msk_dtpTTR_datesent1.Text.Trim() != "")
                        //{
                        //    if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpTTR_datesent1.Text)) >= 0)
                        //    {
                        //        MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Technical Tender Review Send Date (First Evaluation)");
                        //        setDate.Focus();
                        //        isResult = false;
                        //        return isResult;
                        //    }

                        //}
                        //if (msk_dtpTTR_daterec1.Text.Trim() != "")
                        //{
                        //    if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpTTR_daterec1.Text)) >= 0)
                        //    {
                        //        MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Technical Tender Review Received Date (First Evaluation)");
                        //        setDate.Focus();
                        //        isResult = false;
                        //        return isResult;
                        //    }

                        //}
                        //if (msk_dtpTTR_datesent2.Text.Trim() != "")
                        //{
                        //    if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpTTR_datesent2.Text)) >= 0)
                        //    {
                        //        MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Technical Tender Review Send Date (Second Evaluation)");
                        //        setDate.Focus();
                        //        isResult = false;
                        //        return isResult;
                        //    }
                        //}
                        //if (msk_dtpTTR_daterec2.Text.Trim() != "")
                        //{
                        //    if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpTTR_daterec2.Text)) >= 0)
                        //    {
                        //        MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than or equal to Technical Tender Review Received Date (Second Evaluation)");
                        //        setDate.Focus();
                        //        isResult = false;
                        //        return isResult;
                        //    }
                        //}
                    }

                    if (stageName.Equals("Technical Tender Review"))
                    {
                        isResult = ValidateDatesRelatedToTTR(dtpDate, setDate, stageName, evalStagePosition, dateType, isSubmit);
                        if (isResult == false)
                        {
                            return isResult;
                        }
                    }
                    //}
                    //else if (dtpDateReceived.Name.Equals("msk_dtpFE_daterecFin1"))
                    //{
                    if (stageName.Equals("Technical Evaluation") || stageName.Equals("Financial Evaluation"))
                    {

                        if (msk_dtpFE_datesentfin1.Text.Trim() != "")
                        {
                            if (!msk_dtpFE_datesentfin1.Name.Equals(setDate.Name))
                            {
                                //if (setDate.Name.Equals("msk_dtpFE_datesentfin2") || setDate.Name.Equals("msk_dtpFE_daterecFin2"))
                                //{
                                //    if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpFE_datesentfin1.Text)) <= 0)
                                //    {
                                //        MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be less than and equal to Financial Evaluation Send Date (First Evaluation)");
                                //        setDate.Focus();
                                //        isResult = false;
                                //        return isResult;
                                //    }
                                //}
                                //else if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpFE_datesentfin1.Text)) >= 0)
                                //{
                                //    MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Financial Evaluation Send Date (First Evaluation)");
                                //    setDate.Focus();
                                //    isResult = false;
                                //    return isResult;
                                //}
                            }
                        }
                        if (msk_dtpFE_daterecFin1.Text.Trim() != "")
                        {
                            if (!msk_dtpFE_daterecFin1.Name.Equals(setDate.Name))
                            {
                                //if (setDate.Name.Equals("msk_dtpFE_datesentfin2") || setDate.Name.Equals("msk_dtpFE_daterecFin2"))
                                //{
                                //    if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpFE_datesentfin1.Text)) <= 0)
                                //    {
                                //        MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be less than and equal to Financial Evaluation Send Date (First Evaluation)");
                                //        setDate.Focus();
                                //        isResult = false;
                                //        return isResult;
                                //    }
                                //}
                                //else if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpFE_daterecFin1.Text)) >= 0)
                                //{
                                //    MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Financial Evaluation Received Date (First Evaluation)");
                                //    setDate.Focus();
                                //    isResult = false;
                                //    return isResult;
                                //}
                            }
                        }
                        if (msk_dtpFE_datesentfin2.Text.Trim() != "")
                        {
                            if (!msk_dtpFE_datesentfin2.Name.Equals(setDate.Name))
                            {
                                //if (setDate.Name.Equals("msk_dtpFE_datesentfin2") || setDate.Name.Equals("msk_dtpFE_daterecFin2"))
                                //{
                                //    if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpFE_datesentfin2.Text)) < 0)
                                //    {
                                //        MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Financial Evaluation Send Date (Second Evaluation)");
                                //        setDate.Focus();
                                //        isResult = false;
                                //        return isResult;
                                //    }
                                //}
                                //if (setDate.Name.Equals("msk_dtpFE_datesentfin1"))
                                //{
                                //    if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpFE_datesentfin2.Text)) >= 0)
                                //    {
                                //        MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Financial Evaluation Send Date (Second Evaluation)");
                                //        setDate.Focus();
                                //        isResult = false;
                                //        return isResult;
                                //    }
                                //}
                                //if (setDate.Name.Equals("msk_dtpFE_daterecFin2"))
                                //{
                                //    if (Convert.ToDateTime(msk_dtpFE_datesentfin2.Text).CompareTo(Convert.ToDateTime(setDate.Text)) >= 0)
                                //    {
                                //        MessageBox.Show(stageName + " Received Date (" + evalStagePosition + " Evaluation) cannot be greater than Financial Evaluation " + dateType + " Date (Second Evaluation)");
                                //        setDate.Focus();
                                //        isResult = false;
                                //        return isResult;
                                //    }
                                //}
                                //else if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpFE_datesentfin2.Text)) >= 0)
                                //{
                                //    MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Financial Evaluation Send Date (Second Evaluation)");
                                //    setDate.Focus();
                                //    isResult = false;
                                //    return isResult;
                                //}
                            }
                        }
                        if (msk_dtpFE_daterecFin2.Text.Trim() != "")
                        {
                            //if (!msk_dtpFE_daterecFin2.Name.Equals(setDate.Name))
                            //{
                            //    if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpFE_daterecFin2.Text)) > 0)
                            //    {
                            //        MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than Financial Evaluation Received Date (Second Evaluation)");
                            //        setDate.Focus();
                            //        isResult = false;
                            //        return isResult;
                            //    }
                            //}
                        }
                    }

                    if (stageName.Equals("Financial Evaluation")) //|| stageName.Equals("Financial Tender Review")
                    {
                        //if (msk_dtpFTR_datesent1.Text != "")
                        //{
                        //    if (!msk_dtpFTR_datesent1.Name.Equals(setDate.Name))
                        //    {
                        //        if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpFTR_datesent1.Text)) > 0)
                        //        {
                        //            MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than Financial Technical Review Send Date (First Evaluation)");
                        //            setDate.Focus();
                        //            isResult = false;
                        //            return isResult;
                        //        }
                        //    }
                        //}
                        //if (msk_dtpFTR_daterec1.Text != "")
                        //{
                        //    if (!msk_dtpFTR_daterec1.Name.Equals(setDate.Name))
                        //    {
                        //        if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpFTR_daterec1.Text)) > 0)
                        //        {
                        //            MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than Financial Technical Review Received Date (First Evaluation)");
                        //            setDate.Focus();
                        //            isResult = false;
                        //            return isResult;
                        //        }
                        //    }
                        //}
                        //if (msk_dtpFTR_datesent2.Text != "")
                        //{
                        //    if (!msk_dtpFTR_datesent2.Name.Equals(setDate.Name))
                        //    {
                        //        if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpFTR_datesent2.Text)) > 0)
                        //        {
                        //            MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than Financial Technical Review Send Date (Second Evaluation)");
                        //            setDate.Focus();
                        //            isResult = false;
                        //            return isResult;
                        //        }
                        //    }
                        //}
                        //if (msk_dtpFTR_daterec2.Text != "")
                        //{
                        //    if (!msk_dtpFTR_daterec2.Name.Equals(setDate.Name))
                        //    {
                        //        if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpFTR_daterec2.Text)) > 0)
                        //        {
                        //            MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than Financial Technical Review Received Date (Second Evaluation)");
                        //            setDate.Focus();
                        //            isResult = false;
                        //            return isResult;
                        //        }
                        //    }
                        //}
                        if (msk_dtpEA_apprDate.Text != "")
                        {
                            if (!msk_dtpEA_apprDate.Name.Equals(setDate.Name))
                            {
                                //if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpEA_apprDate.Text)) >= 0)
                                //{
                                //    MessageBox.Show(stageName + " " + dateType + " Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Tender Award Approval Date (Second Evaluation)");
                                //    setDate.Focus();
                                //    isResult = false;
                                //    return isResult;
                                //}
                            }
                        }
                    }
                    //else
                    //{
                    //Modified by Varun on 13/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
                    //if (isResult != false)
                    //{
                    //    setDate.Text = Convert.ToDateTime(setDate.Text).ToString("dd/MMM/yyyy");
                    //    isResult = true;
                    //    return isResult;
                    //}
                    //else
                    //{
                    //    setDate.Focus();
                    //}
                    //}
                }
            }
            //else
            //{
            //    //Modified by Varun on 13/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            //    setReceivedDate.Text = Convert.ToDateTime(dtpDateReceived.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
            //    isResult = true;
            //}
            //}
            //else if (dtpDateReceived.Name.Equals("dtpTTR_daterec1"))
            //{



            return isResult;
        }

        private bool ValidatingControlsWithSendDates(DateTimePicker dtpDateSend, MaskedTextBox setDate, string stageName, string evalStagePosition, bool isSubmit)
        {
            bool isResult = true;

            if (isSubmit == false)
            {
                //if (Convert.ToDateTime(dtpDateSend.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(dateReceived.Text)) < 0)
                //{
                //    MessageBox.Show(stageName + " Send Date (First Evaluation) cannot be less than Doc Received From CD Date");
                //    dateSend.Focus();
                //    isResult = false;
                //    return isResult;
                //}
                if (stageName.Equals("Technical Evaluation")) //|| !stageName.Equals("Financial Tender Review") || !stageName.Equals("Financial Evaluation")
                {
                    if (msk_dtpTE_daterec1.Text != "")
                    {
                        if (Convert.ToDateTime(dtpDateSend.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                        {
                            MessageBox.Show(stageName + " Send Date (" + evalStagePosition + " Evaluation) cannot be greater than Technical Evaluation Received Date (First Evaluation)");
                            setDate.Focus();
                            isResult = false;
                            return isResult;
                        }
                    }
                    if (msk_dtpTE_datesent2.Text != "")
                    {
                        if (Convert.ToDateTime(dtpDateSend.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_datesent2.Text)) > 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                        {
                            if (dtpDateSend.Name.Equals("dtpTE_datesent1") || dtpDateSend.Name.Equals("dtpTE_daterec1"))
                            {
                                if (Convert.ToDateTime(dtpDateSend.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_datesent2.Text)) > 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                                {
                                    MessageBox.Show(stageName + " Send Date (" + evalStagePosition + " Evaluation) cannot be greater than Technical Evaluation Send Date (Second Evaluation)"); //and equal to
                                }
                            }
                            else
                            {
                                MessageBox.Show(stageName + " Send Date (" + evalStagePosition + " Evaluation) cannot be greater than Technical Evaluation Send Date (Second Evaluation)");
                            }
                            setDate.Focus();
                            isResult = false;
                            return isResult;
                        }
                    }

                    if (msk_dtpTE_daterec2.Text != "")
                    {
                        if (Convert.ToDateTime(dtpDateSend.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec2.Text)) > 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                        {
                            if (dtpDateSend.Name.Equals("dtpTE_datesent1") || dtpDateSend.Name.Equals("dtpTE_daterec1"))
                            {
                                if (Convert.ToDateTime(dtpDateSend.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec2.Text)) > 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                                {
                                    MessageBox.Show(stageName + " Send Date (" + evalStagePosition + " Evaluation) cannot be greater than Technical Evaluation Received Date (Second Evaluation)"); //and equal to
                                }
                            }
                            else
                            {
                                MessageBox.Show(stageName + " Send Date (" + evalStagePosition + " Evaluation) cannot be greater than Technical Evaluation Send Date (Second Evaluation)");
                            }
                            setDate.Focus();
                            isResult = false;
                            return isResult;
                        }
                    }
                }
                if (stageName.Equals("Technical Evaluation") || stageName.Equals("Financial Evaluation"))
                {
                    if (msk_dtpFE_daterecFin1.Text != "")
                    {
                        if (Convert.ToDateTime(dtpDateSend.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFE_daterecFin1.Text)) > 0)
                        {
                            MessageBox.Show(stageName + " Send Date (" + evalStagePosition + " Evaluation) cannot be greater than Financial Evaluation Received Date (First Evaluation)"); //and equal to
                            setDate.Focus();
                            isResult = false;
                            return isResult;
                        }
                    }
                    if (msk_dtpFE_datesentfin1.Text != "")
                    {
                        if (Convert.ToDateTime(dtpDateSend.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFE_datesentfin1.Text)) > 0)
                        {
                            MessageBox.Show(stageName + " Send Date (" + evalStagePosition + " Evaluation) cannot be greater than Financial Evaluation Send Date (First Evaluation)"); //and equal to
                            setDate.Focus();
                            isResult = false;
                            return isResult;
                        }
                    }
                    if (msk_dtpFE_daterecFin2.Text != "")
                    {
                        if (Convert.ToDateTime(dtpDateSend.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFE_daterecFin2.Text)) > 0)
                        {
                            MessageBox.Show(stageName + " Send Date (" + evalStagePosition + " Evaluation) cannot be greater than Financial Evaluation Received Date (Second Evaluation)"); //and equal to
                            setDate.Focus();
                            isResult = false;
                            return isResult;
                        }
                    }
                }
                if (stageName.Equals("Financial Evaluation"))
                {
                    //if (msk_dtpFTR_datesent1.Text != "")
                    //{
                    //    if (Convert.ToDateTime(dtpDateSend.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFTR_datesent1.Text)) >= 0)
                    //    {
                    //        MessageBox.Show(stageName + " Send Date (" + evalStagePosition + " Evaluation) cannot be greater than or equal to Financial Tender Review Send Date (First Evaluation)");
                    //        setDate.Focus();
                    //        isResult = false;
                    //        return isResult;
                    //    }
                    //}
                    //if (msk_dtpFTR_daterec1.Text != "")
                    //{
                    //    if (Convert.ToDateTime(dtpDateSend.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFTR_daterec1.Text)) >= 0)
                    //    {
                    //        MessageBox.Show(stageName + " Send Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Financial Tender Review Received Date (First Evaluation)");
                    //        setDate.Focus();
                    //        isResult = false;
                    //        return isResult;
                    //    }
                    //}
                    //if (msk_dtpFTR_datesent2.Text != "")
                    //{
                    //    if (Convert.ToDateTime(dtpDateSend.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFTR_datesent2.Text)) >= 0)
                    //    {
                    //        MessageBox.Show(stageName + " Send Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Financial Tender Review Send Date (Second Evaluation)");
                    //        setDate.Focus();
                    //        isResult = false;
                    //        return isResult;
                    //    }
                    //}
                    //if (msk_dtpFTR_daterec2.Text != "")
                    //{
                    //    if (Convert.ToDateTime(dtpDateSend.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFTR_daterec2.Text)) >= 0)
                    //    {
                    //        MessageBox.Show(stageName + " Send Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Financial Tender Review Received Date (Second Evaluation)");
                    //        setDate.Focus();
                    //        isResult = false;
                    //        return isResult;
                    //    }
                    //}
                    if (msk_dtpEA_apprDate.Text != "")
                    {
                        if (Convert.ToDateTime(dtpDateSend.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpEA_apprDate.Text)) > 0)
                        {
                            MessageBox.Show(stageName + " Send Date (" + evalStagePosition + " Evaluation) cannot be greater than Tender Award Approval Date"); //and equal to
                            setDate.Focus();
                            isResult = false;
                            return isResult;
                        }
                    }
                }
                //Modified by Varun on 13/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
                if (isResult)
                {
                    setDate.Text = Convert.ToDateTime(dtpDateSend.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
                    isResult = true;
                    return isResult;
                }
                else
                {
                    setDate.Focus();
                }

            }
            else
            {
                if (setDate.Text.Trim() != "")
                {
                    //if (Convert.ToDateTime(dateSend.Text).CompareTo(Convert.ToDateTime(dateReceived.Text)) < 0)
                    //{
                    //    MessageBox.Show(stageName + " Send Date (First Evaluation) cannot be less than Doc Received From CD Date");
                    //    dateSend.Focus();
                    //    isResult = false;
                    //    return isResult;
                    //}
                    if (stageName.Equals("Technical Evaluation")) //|| !stageName.Equals("Financial Tender Review") || !stageName.Equals("Financial Evaluation")
                    {
                        if (msk_dtpTE_daterec1.Text != "")
                        {
                            if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                            {
                                MessageBox.Show(stageName + " Send Date (" + evalStagePosition + " Evaluation) cannot be greater than Technical Evaluation Received Date (First Evaluation)");
                                setDate.Focus();
                                isResult = false;
                                return isResult;
                            }
                        }
                        if (msk_dtpTE_datesent2.Text != "")
                        {
                            if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpTE_datesent2.Text)) > 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                            {
                                MessageBox.Show(stageName + " Send Date (" + evalStagePosition + " Evaluation) cannot be greater than Technical Evaluation Send Date (Second Evaluation)");
                                setDate.Focus();
                                isResult = false;
                                return isResult;
                            }
                        }
                        if (msk_dtpTE_daterec2.Text != "")
                        {
                            if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec2.Text)) > 0) //Convert.ToDateTime(Convert.ToDateTime(dtpDateSend.Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpTE_daterec1.Text)) > 0)
                            {
                                MessageBox.Show(stageName + " Send Date (" + evalStagePosition + " Evaluation) cannot be greater than Technical Evaluation Received Date (Second Evaluation)");
                                setDate.Focus();
                                isResult = false;
                                return isResult;
                            }
                        }
                    }

                    if (stageName.Equals("Technical Evaluation") || stageName.Equals("Financial Evaluation"))
                    {
                        if (msk_dtpFE_daterecFin1.Text != "")
                        {
                            if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpFE_daterecFin1.Text)) > 0)
                            {
                                MessageBox.Show(stageName + " Send Date (" + evalStagePosition + " Evaluation) cannot be greater than Financial Evaluation Received Date (First Evaluation)"); //and equal to
                                setDate.Focus();
                                isResult = false;
                                return isResult;
                            }
                        }
                        if (msk_dtpFE_datesentfin1.Text != "")
                        {
                            if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpFE_datesentfin1.Text)) > 0)
                            {
                                MessageBox.Show(stageName + " Send Date (" + evalStagePosition + " Evaluation) cannot be greater than Financial Evaluation Send Date (First Evaluation)"); //and equal to
                                setDate.Focus();
                                isResult = false;
                                return isResult;
                            }
                        }
                        if (msk_dtpFE_daterecFin2.Text != "")
                        {
                            if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpFE_daterecFin2.Text)) > 0)
                            {
                                MessageBox.Show(stageName + " Send Date (" + evalStagePosition + " Evaluation) cannot be greater than Financial Evaluation Received Date (Second Evaluation)"); //and equal to
                                setDate.Focus();
                                isResult = false;
                                return isResult;
                            }
                        }
                    }
                    if (stageName.Equals("Financial Evaluation"))
                    {
                        //if (msk_dtpFTR_datesent1.Text != "")
                        //{
                        //    if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpFTR_datesent1.Text)) >= 0)
                        //    {
                        //        MessageBox.Show(stageName + " Send Date (" + evalStagePosition + " Evaluation) cannot be greater than or equal to Financial Tender Review Send Date (First Evaluation)");
                        //        setDate.Focus();
                        //        isResult = false;
                        //        return isResult;
                        //    }
                        //}
                        //if (msk_dtpFTR_daterec1.Text != "")
                        //{
                        //    if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpFTR_daterec1.Text)) >= 0)
                        //    {
                        //        MessageBox.Show(stageName + " Send Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Financial Tender Review Received Date (First Evaluation)");
                        //        setDate.Focus();
                        //        isResult = false;
                        //        return isResult;
                        //    }
                        //}
                        //if (msk_dtpFTR_datesent2.Text != "")
                        //{
                        //    if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpFTR_datesent2.Text)) >= 0)
                        //    {
                        //        MessageBox.Show(stageName + " Send Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Financial Tender Review Send Date (Second Evaluation)");
                        //        setDate.Focus();
                        //        isResult = false;
                        //        return isResult;
                        //    }
                        //}
                        //if (msk_dtpFTR_daterec2.Text != "")
                        //{
                        //    if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpFTR_daterec2.Text)) >= 0)
                        //    {
                        //        MessageBox.Show(stageName + " Send Date (" + evalStagePosition + " Evaluation) cannot be greater than and equal to Financial Tender Review Received Date (Second Evaluation)");
                        //        setDate.Focus();
                        //        isResult = false;
                        //        return isResult;
                        //    }
                        //}
                        if (msk_dtpEA_apprDate.Text != "")
                        {
                            if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(msk_dtpEA_apprDate.Text)) > 0)
                            {
                                MessageBox.Show(stageName + " Send Date (" + evalStagePosition + " Evaluation) cannot be greater than Tender Award Approval Date"); //and equal to
                                setDate.Focus();
                                isResult = false;
                                return isResult;
                            }
                        }
                    }
                    //Modified by Varun on 13/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
                    if (isResult)
                    {
                        setDate.Text = Convert.ToDateTime(setDate.Text).ToString("dd/MMM/yyyy");
                        isResult = true;
                        return isResult;
                    }
                    else
                    {
                        setDate.Focus();
                    }

                }
            }
            //}
            //}
            return isResult;
        }

        private bool DateSendSecEvalValidation(DateTimePicker dtpDateSend, MaskedTextBox setDate, MaskedTextBox dateSend, MaskedTextBox dateReceived, string stageName, bool isSubmit)
        {
            bool isResult = true;
            //Control dateSendFill = new Control("msk" + dtpDateSend.Name);
            if (dateSend.Text.Trim() != "" && dateReceived.Text.Trim() != "")
            {
                //Modified by Varun on 02/05/2016 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings  
                //if (stageName.Equals("Technical Tender Review"))
                //{
                //    if (msk_dtpTE_daterec1.Text =="")
                //    {
                //        MessageBox.Show("Cannot enter " + stageName + " Send Date (Second Evaluation) when there are no date in Technical Evaluation Received Date (First Evaluation)");
                //        setDate.Focus();
                //        isResult = false;
                //    }
                //    else if (msk_dtpTE_daterec2.Text == "")
                //    {
                //        MessageBox.Show("Cannot enter " + stageName + " Send Date (Second Evaluation) when there are no date in Technical Evaluation Received Date (Second Evaluation)");
                //        setDate.Focus();
                //        isResult = false;
                //    }
                //}
                //else if (stageName.Equals("Financial Tender Review"))
                //{
                //    if (msk_dtpFE_daterecFin1.Text == "")
                //    {
                //        MessageBox.Show("Cannot enter " + stageName + " Send Date (Second Evaluation) when there are no date in Financial Evaluation Received Date (First Evaluation)");
                //        setDate.Focus();
                //        isResult = false;
                //    }
                //    else if (msk_dtpFE_daterecFin2.Text == "")
                //    {
                //        MessageBox.Show("Cannot enter " + stageName + " Send Date (Second Evaluation) when there are no date in Financial Evaluation Received Date (Second Evaluation)");
                //        setDate.Focus();
                //        isResult = false;
                //    }
                //}

                if (isSubmit == false)
                {
                    isResult = CheckPreviousStageDates(dtpDateSend, dateSend, dateReceived, stageName, "Send", "Second", isSubmit);
                    if (isResult == false)
                    {
                        return isResult;
                    }

                    if (Convert.ToDateTime(dtpDateSend.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(dateSend.Text)) < 0)
                    {
                        MessageBox.Show(stageName + " Send Date (Second Evaluation) cannot be less than " + stageName + " Send Date (First Evaluation)"); //and equal to
                        setDate.Focus();
                        isResult = false;
                        return isResult;
                    }

                    if (Convert.ToDateTime(dtpDateSend.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(dateReceived.Text)) < 0)
                    {
                        MessageBox.Show(stageName + " Send Date (Second Evaluation) cannot be less than " + stageName + " Received Date (First Evaluation)"); //and equal to
                        setDate.Focus();
                        isResult = false;
                        return isResult;
                    }

                    isResult = ValidatingDateControls(dtpDateSend, setDate, stageName, "Second", "Send", isSubmit);
                    //ValidatingControlsWithSendDates(dtpDateSend, setDate, stageName, "Second", isSubmit);
                }
                else
                {
                    //if (stageName.Equals("Technical Tender Review"))
                    //{
                    if (setDate.Text != "")
                    {
                        isResult = CheckPreviousStageDates(dtpDateSend, setDate, dateReceived, stageName, "Send", "Second", isSubmit);
                        if (isResult == false)
                        {
                            return isResult;
                        }

                        if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(dateSend.Text)) < 0)
                        {
                            MessageBox.Show(stageName + " Send Date (Second Evaluation) cannot be less than " + stageName + " Send Date (First Evaluation)"); //and equal to
                            setDate.Focus();
                            isResult = false;
                            return isResult;
                        }

                        //else if (Convert.ToDateTime(dtpDateSend.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(dateReceived.Text)) <= 0)
                        //{
                        //    MessageBox.Show(stageName + " Date Send (Second Evaluation) cannot be less than " + stageName + " Date Send (First Evaluation)");
                        //    setDate.Focus();
                        //    isResult = false;
                        //}
                        //if (dtpDateSend.Name.Equals("dtpTE_datesent2"))
                        //{

                        if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(dateReceived.Text)) < 0)
                        {
                            MessageBox.Show(stageName + " Send Date (Second Evaluation) cannot be less than " + stageName + " Received Date (First Evaluation)"); //and equal to
                            setDate.Focus();
                            isResult = false;
                            return isResult;
                        }

                        //isResult = ValidatingDateControls(dtpDateSend, setDate, stageName, "Second", "Send", isSubmit);

                    }
                }


            }
            else if (isSubmit == false)
            {
                MessageBox.Show("Cannot enter " + stageName + " Send Date (Second Evaluation) when there are no date in " + stageName + " Send and Received Date (First Evaluation)");
                setDate.Focus();
                isResult = false;
                return isResult;
            }
            else if (isSubmit)
            {

                if (dateSend.Text.Trim() == "" && dateReceived.Text.Trim() != "")
                {
                    MessageBox.Show("Cannot enter Send Date (Second Evaluation) of " + stageName + " because " + stageName + " Send Date (First Evaluation) is blank");
                }
            }
            return isResult;
        }
        

        private void dtpEA_datesent2_ValueChanged(object sender, EventArgs e)
        {
            msk_dtpTE_datesent2.Text = "";
            if(DateSendSecEvalValidation(dtpTE_datesent2, msk_dtpTE_datesent2, msk_dtpTE_datesent1, msk_dtpTE_daterec1, "Technical Evaluation", false))
            {
                if (!dtpTE_datesent2.Value.ToString().Contains("1900") && dtpTE_datesent2.Value.ToString().Trim() != "")
                {
                    msk_dtpTE_datesent2.Text = Convert.ToDateTime(dtpTE_datesent2.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
                }                
            }
        }

        private void dtpEA_daterec2_ValueChanged(object sender, EventArgs e)
        {
            msk_dtpTE_daterec2.Text = "";
            DateReceivedSecEvalValidation(dtpTE_daterec2, msk_dtpTE_daterec2, msk_dtpTE_datesent1, msk_dtpTE_daterec1, "Technical Evaluation", false);
        }

        private bool DateReceivedSecEvalValidation(DateTimePicker dtpDateReceived, MaskedTextBox setDate, MaskedTextBox dateSend, MaskedTextBox dateReceived, string stageName, bool isSubmit)
        {
            bool isResult = true;
            if (CheckBlankSendDatesOfTechnicalEvalStage() && CheckBlankSendDatesOfFinEvalStage()) //CheckBlankSendDatesOfTechnicalTenderReviewStage() &&
            {

            }
            else
            {
                return isResult = false;
            }

            if (dateSend.Text.Trim() != "") //&& dateReceived.Text.Trim() != ""
            {

                if (!isSubmit)
                {
                    isResult = CheckPreviousStageDates(dtpDateReceived, dateSend, dateReceived, stageName, "Received", "Second", isSubmit);
                    if (isResult == false)
                    {
                        return isResult;
                    }

                    //if (dateSend.Text.Trim() != "")
                    //{
                    if (Convert.ToDateTime(dtpDateReceived.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(dateSend.Text)) < 0)
                    {
                        MessageBox.Show(stageName + " Received Date (Second Evaluation) cannot be less than " + stageName + " Send Date (First Evaluation)");
                        setDate.Focus();
                        isResult = false;
                        return isResult;
                    }
                    //}
                    //else
                    //{
                    //    MessageBox.Show(stageName + " Received Date (Second Evaluation) cannot be entered because " + stageName + " Send Date (First Evaluation) is blank");
                    //    return isResult = false;
                    //}

                    if (dateReceived.Text.Trim() != "")
                    {
                        if (Convert.ToDateTime(dtpDateReceived.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(dateReceived.Text)) < 0)
                        {
                            MessageBox.Show(stageName + " Received Date (Second Evaluation) cannot be less than " + stageName + " Received Date (First Evaluation)");
                            setDate.Focus();
                            isResult = false;
                            return isResult;
                        }
                        else
                        {
                            isResult = ValidatingDateControls(dtpDateReceived, setDate, stageName, "Second", "Received", isSubmit);
                        }
                    }
                    else
                    {
                        MessageBox.Show(stageName + " Received Date (Second Evaluation) cannot be entered because " + stageName + " Received Date (First Evaluation) is blank");
                        return isResult = false;
                    }
                }
                else
                {
                    if (setDate.Text != "")
                    {
                        isResult = CheckPreviousStageDates(dtpDateReceived, setDate, dateReceived, stageName, "Received", "Second", isSubmit);
                        if (isResult == false)
                        {
                            return isResult;
                        }

                        if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(dateSend.Text)) <= 0)
                        {
                            MessageBox.Show(stageName + " Received Date (Second Evaluation) cannot be less than or equal to " + stageName + " Send Date (First Evaluation)");
                            setDate.Focus();
                            isResult = false;
                            return isResult;
                        }

                        if (Convert.ToDateTime(setDate.Text).CompareTo(Convert.ToDateTime(dateReceived.Text)) <= 0)
                        {
                            MessageBox.Show(stageName + " Date Received (Second Evaluation) cannot be less than or equal to " + stageName + " Date Received (First Evaluation)");
                            setDate.Focus();
                            isResult = false;
                            return isResult;
                        }
                        else
                        {
                            //isResult = ValidatingDateControls(dtpDateReceived, setDate, stageName, "Second", "Received", isSubmit);
                        }

                    }

                }
            }
            else
            {
                if (dateSend.Text.Trim() == "" && dateReceived.Text.Trim() != "")
                {
                    MessageBox.Show(stageName + " Send Date (First Evaluation) cannot be blank when there is a value in Received Date (First Evaluation). Please enter date in Technical Evaluation Send Date (Second Evaluation)");
                    setDate.Focus();
                    isResult = false;
                }
                //else if (dateSend.Text.Trim() == "" && dateReceived.Text.Trim() != "")
                //{
                //    MessageBox.Show(stageName + " Send Date (First Evaluation) cannot be blank when there is a value in Received Date (First Evaluation). Please enter date in Technical Evaluation Send Date (Second Evaluation)");
                //    setDate.Focus();
                //    isResult = false;
                //}

            }
            return isResult;
        }

        private bool SecFinEvalDateSendFirstFinEvalRecDateValidation()
        {
            bool isResult = true;
            //Modified by Varun on 13/02/2016 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            if (msk_dtpFE_daterecFin1.Text.Trim() != "")
            {
                if (Convert.ToDateTime(dtpFE_datesentfin2.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFE_daterecFin1.Text)) < 0)
                {
                    MessageBox.Show("Financial Evaluation Date Send (Second Evaluation) cannot be less than Financial Evaluation Date Received (First Evaluation)");
                    msk_dtpFE_datesentfin2.Focus();
                    isResult = false;
                }
            }
            else
            {
                isResult = true;
            }
            return isResult;
        }
        

        private bool SecFinEvalDateSendRecEvalValidation()
        {
            bool isResult = true;
            //Modified by Varun on 13/02/2016 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            if (msk_dtpFE_datesentfin1.Text.Trim() != "")
            {
                if (Convert.ToDateTime(dtpFE_datesentfin2.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFE_datesentfin1.Text)) < 0)
                {
                    MessageBox.Show("Financial Evaluation Date Send (Second Evaluation) cannot be less than Financial Evaluation Date Send (First Evaluation)");
                    msk_dtpFE_datesentfin2.Focus();
                    isResult = false;
                }
            }
            else
            {
                isResult = true;
            }
            return isResult;
        }
        

        private void dtpEA_datesentfin2_ValueChanged(object sender, EventArgs e)
        {
            //msk_dtpFE_datesentfin2.Text = "";
            //DateSendFinEvalFirstEval(false, msk_dtpTTR_daterec1, msk_dtpTTR_daterec2, dtpFE_datesentfin2, msk_dtpFE_datesentfin2);
            FinEvalDateSendSecondEvalValidation();
            SecFinEvalDateSendFirstFinEvalRecDateValidation();       
            FinEvalDateSendRecSecEvalValidation();
            if (!msk_dtpFE_datesentfin2.Text.Contains("1900") && dtpFE_datesentfin2.Value.ToString().Trim() != "")
            {
                msk_dtpFE_datesentfin2.Text = Convert.ToDateTime(dtpFE_datesentfin2.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
            }             
        }

        private bool FinEvalDateRecSecEvalValidation()
        {
            bool isResult = true;
            if (msk_dtpFE_daterecFin1.Text.Trim() != "")
            {
                if (Convert.ToDateTime(dtpFE_daterecFin2.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).CompareTo(Convert.ToDateTime(msk_dtpFE_daterecFin1.Text)) < 0)
                {
                    MessageBox.Show("Financial Evaluation Date Send (Second Evaluation) cannot be less than Financial Evaluation Date Send (First Evaluation)");
                    msk_dtpFE_daterecFin2.Focus();
                    return isResult;
                }
            }
            //else if (msk_dtpFE_datesentfin2.Text.Trim() == "" && dtpFE_daterecFin2.Text.Trim() != "")
            //{
            //    MessageBox.Show("Financial Evaluation Date Send (First Evaluation) cannot be blank while there is a date in Financial Evaluation Received Date (First Evaluation)");
            //    msk_dtpFE_datesentfin1.Focus();
            //    isResult = false;
            //}
            else
            {
                isResult = true;
            }
            return isResult;
        }

        private bool FinEvalDateSendRecSecEvalValidation()
        {
            bool isResult = true;
            if (msk_dtpFE_datesentfin2.Text.Trim() != "" && msk_dtpFE_daterecFin2.Text.Trim() !="")
            {
                if (Convert.ToDateTime(msk_dtpFE_daterecFin2.Text).CompareTo(Convert.ToDateTime(msk_dtpFE_datesentfin2.Text)) < 0)
                {
                    MessageBox.Show("Financial Evaluation Date Received (Second Evaluation) cannot be less than Financial Evaluation Date Send (Second Evaluation)");
                    msk_dtpFE_daterecFin2.Focus();
                    isResult = false;
                }
            }
            else
            {
                isResult = true;
            }
            return isResult;
        }
         
         

        private void dtpEA_daterecFin2_ValueChanged(object sender, EventArgs e)
        {
            //msk_dtpFE_daterecFin2.Text = "";
            DateReceivedSecEvalValidation(dtpFE_daterecFin2, msk_dtpFE_daterecFin2, msk_dtpFE_datesentfin1, msk_dtpFE_daterecFin1, "Financial Evaluation", false);
            //Modified by Varun on 13/02/2016 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings                          
            FinEvalDateSendRecSecEvalValidation();
            if (!msk_dtpFE_daterecFin2.Text.Contains("1900") && !msk_dtpFE_daterecFin2.Text.Trim().Contains(""))
            {
                msk_dtpFE_daterecFin2.Text = Convert.ToDateTime(dtpFE_daterecFin2.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
            }
        }

        private void btnTenderSubmissionStage1_Click(object sender, EventArgs e)
        {
            if (txtTenderNo.Text != "")
            {
                if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                {
                    if (mUserRightsColl.Contains("70"))
                    {
                        MessageBox.Show("Do not have access rights to open Tender Submission, Please contact Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                }

                string tenderClosingDate = "";

                if (msk_dtpEA_closeDate.Text != "")
                    tenderClosingDate = msk_dtpEA_closeDate.Text;
                else
                    tenderClosingDate = msk_dtpEA_stage1.Text;

                if (tenderClosingDate != "")
                {
                    if (txtTenderNo.Text.Contains("STC"))
                        frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("STC", txtTenderNo.Text, proj_Title, _projID, _userName, tenderClosingDate, mUserRightsColl, null, null, mIsHeadOfSection, false, false);
                    else if (txtTenderNo.Text.Contains("GTC"))
                        frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("GTC", txtTenderNo.Text, proj_Title, _projID, _userName, tenderClosingDate, mUserRightsColl, null, null, mIsHeadOfSection, false, false);
                    else if (txtTenderNo.Text.Contains("ITC"))
                        frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("ITC", txtTenderNo.Text, proj_Title, _projID, _userName, tenderClosingDate, mUserRightsColl, null, null, mIsHeadOfSection, false, false);
                    else if (txtTenderNo.Text.Contains("MRPSC"))
                        frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("MRPSC", txtTenderNo.Text, proj_Title, _projID, _userName, tenderClosingDate, mUserRightsColl, null, null, mIsHeadOfSection, false, false);
                    else if (txtTenderNo.Text.Contains("EUWC"))
                        frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("EUWC", txtTenderNo.Text, proj_Title, _projID, _userName, tenderClosingDate, mUserRightsColl, null, null, mIsHeadOfSection, false, false);
                    else if (txtTenderNo.Text.Contains("PQ"))
                        frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("PQ", txtTenderNo.Text, proj_Title, _projID, _userName, tenderClosingDate, mUserRightsColl, null, null, mIsHeadOfSection, false, false);
                    else if (txtTenderNo.Text.Contains("NC"))
                        frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("NC", txtTenderNo.Text, proj_Title, _projID, _userName, tenderClosingDate, mUserRightsColl, null, null, mIsHeadOfSection, false, false);
                    frmTndrSub.StartPosition = FormStartPosition.CenterParent;
                    frmTndrSub.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Cannot open the Tender Submission, when there is no Tender Closing Date", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Cannot open the Tender Submission, when there is no Tender Number assigned to the project", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnTenderSubmissionStg2_Click(object sender, EventArgs e)
        {
            if (txtTenderNo.Text != "")
            {
                if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                {
                    if (mUserRightsColl.Contains("107"))
                    {
                        MessageBox.Show("Do not have access rights to open Tender Submission, Please contact Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                }

                string tenderClosingDate = "";

                if (msk_dtpEA_closeDate_Stage2.Text != "")
                {
                    tenderClosingDate = msk_dtpEA_closeDate_Stage2.Text;
                }
                else if (msk_dtpEA_stage2.Text != "")
                {
                    tenderClosingDate = msk_dtpEA_stage2.Text;
                }

                if (tenderClosingDate != "")
                {
                    if (txtTenderNo.Text.Contains("STC"))
                        frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("STC", txtTenderNo.Text, proj_Title, _projID, _userName, tenderClosingDate, mUserRightsColl, null, null, mIsHeadOfSection, false, true);
                    else if (txtTenderNo.Text.Contains("GTC"))
                        frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("GTC", txtTenderNo.Text, proj_Title, _projID, _userName, tenderClosingDate, mUserRightsColl, null, null, mIsHeadOfSection, false, true);
                    else if (txtTenderNo.Text.Contains("ITC"))
                        frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("ITC", txtTenderNo.Text, proj_Title, _projID, _userName, tenderClosingDate, mUserRightsColl, null, null, mIsHeadOfSection, false, true);
                    else if (txtTenderNo.Text.Contains("MRPSC"))
                        frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("MRPSC", txtTenderNo.Text, proj_Title, _projID, _userName, tenderClosingDate, mUserRightsColl, null, null, mIsHeadOfSection, false, true);
                    else if (txtTenderNo.Text.Contains("EUWC"))
                        frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("EUWC", txtTenderNo.Text, proj_Title, _projID, _userName, tenderClosingDate, mUserRightsColl, null, null, mIsHeadOfSection, false, true);
                    else if (txtTenderNo.Text.Contains("NC"))
                        frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("NC", txtTenderNo.Text, proj_Title, _projID, _userName, tenderClosingDate, mUserRightsColl, null, null, mIsHeadOfSection, false, true);
                    frmTndrSub.StartPosition = FormStartPosition.CenterParent;
                    frmTndrSub.ShowDialog();
                }
            }
            else
            {
                MessageBox.Show("Cannot open the Tender Submission, when there is no Tender Number assigned to the project", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void dtp_tsModifiedDate_Stage2_ValueChanged(object sender, EventArgs e)
        {
            msk_dtp_tsModifiedDate_Stage2.Text = Convert.ToDateTime(dtp_tsModifiedDate_Stage2.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
            msk_dtp_tsModifiedDate_Stage2.Focus();
        }

        private void btnExportToExcel_Click(object sender, EventArgs e)
        {
            try
            {

                if ((mUserRightsColl.Count == 0 || !mUserRightsColl.Contains("111")))
                {

                    SaveFileDialog saveFileDialog1 = new SaveFileDialog();
                    Microsoft.Office.Interop.Excel._Application app = null;
                    Microsoft.Office.Interop.Excel._Workbook workbook = null;

                    // commented by Varun on 16/Jul/17 saveFileDialog1.Filter = "Excel Path|*.xls|Excel Format|*.xlsx";

                    saveFileDialog1.Filter = "Excel Path|*.xls|Excel Path|*.xlsx";
                    saveFileDialog1.Title = "Save an Excel File";
                    saveFileDialog1.ShowDialog();

                    if (saveFileDialog1.FileName != "")
                    {
                        // creating Excel Application
                        app = new Microsoft.Office.Interop.Excel.Application();

                        // creating new WorkBook within Excel application
                        workbook = app.Workbooks.Add(Type.Missing);

                        // creating new Excelsheet in workbook
                        Microsoft.Office.Interop.Excel._Worksheet worksheet = null;

                        // see the excel sheet behind the program
                        app.Visible = true;

                        // get the reference of first sheet. By default its name is Sheet1.
                        // store its reference to worksheet
                        worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Sheets["Sheet1"];
                        worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.ActiveSheet;

                        Microsoft.Office.Interop.Excel.Range formatRange = worksheet.UsedRange;
                        Microsoft.Office.Interop.Excel.Range formatA1CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA3CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatB3CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatC3CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA4CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatB4CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatC4CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA5CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatB5CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatC5CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA6CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatB6CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatC6CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA8CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA9CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD9CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE9CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA10CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD10CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE10CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA11CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD11CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE11CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA12CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD12CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE12CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA13CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD13CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE13CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA15CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA16CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD16CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE16CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA17CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD17CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE17CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA18CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD18CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE18CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA19CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD19CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE19CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA20CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD20CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE20CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA21CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD21CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE21CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA22CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD22CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE22CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA23CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD23CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE23CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA25CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA26CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD26CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE26CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA27CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD27CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE27CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA28CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD28CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE28CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA29CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD29CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE29CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA30CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD30CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE30CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA31CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD31CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE31CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA32CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD32CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE32CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA33CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD33CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE33CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA34CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD34CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE34CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA35CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD35CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE35CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA37CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA38CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD38CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE38CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA39CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD39CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE39CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA40CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD40CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE40CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA41CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD41CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE41CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA42CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD42CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE42CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA43CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD43CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE43CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA44CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD44CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE44CellRange = null;

                        Microsoft.Office.Interop.Excel.Range formatA45CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatD45CellRange = null;
                        Microsoft.Office.Interop.Excel.Range formatE45CellRange = null;

                        formatA1CellRange = worksheet.get_Range("A1", "C1");

                        formatA1CellRange.Merge(true);

                        formatA1CellRange.FormulaR1C1 = "Project Specific Tender & Contracts Summary";

                        formatA1CellRange.Font.Name = "Calibri (Body)";
                        formatA1CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(0, 0, 0));
                        formatA1CellRange.Font.Size = 11;
                        formatA1CellRange.Font.Bold = true;
                        formatA1CellRange.Font.Underline = true;
                        formatA1CellRange.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.White);
                        worksheet.get_Range("A1", "C1").Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeLeft].Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
                        worksheet.get_Range("A1", "C1").Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeTop].Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
                        worksheet.get_Range("A1", "C1").Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeRight].Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
                        worksheet.get_Range("A1", "C1").Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeBottom].Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;

                        for (int counter = 3; counter <= 45; counter++)
                        {
                            for (int asciiCode = 65; asciiCode <= 67; asciiCode++)
                            {
                                char alphaBet = (char)asciiCode;
                                worksheet.get_Range(alphaBet + (counter).ToString(), alphaBet + (counter).ToString()).Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeLeft].Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
                                worksheet.get_Range(alphaBet + (counter).ToString(), alphaBet + (counter).ToString()).Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeTop].Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
                                worksheet.get_Range(alphaBet + (counter).ToString(), alphaBet + (counter).ToString()).Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeRight].Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
                                worksheet.get_Range(alphaBet + (counter).ToString(), alphaBet + (counter).ToString()).Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeBottom].Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
                                //worksheet.get_Range(alphaBet + (counter).ToString(), alphaBet + (counter).ToString()).RowHeight = 25;                                                             
                            }
                        }

                        formatA3CellRange = worksheet.get_Range("A3", "A3");
                        formatA3CellRange.ColumnWidth = 50;
                        formatA3CellRange.Font.Name = "Calibri (Body)";
                        formatA3CellRange.Font.Size = 11;
                        formatA3CellRange.FormulaR1C1 = "Tender No.";

                        formatB3CellRange = worksheet.get_Range("B3", "B3");
                        formatB3CellRange.ColumnWidth = 15;

                        formatB3CellRange.Font.Name = "Calibri (Body)";
                        formatB3CellRange.Font.Size = 11;
                        formatB3CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatB3CellRange.Font.Bold = true;
                        formatB3CellRange.FormulaR1C1 = ":";
                        formatB3CellRange.ColumnWidth = 15;

                        formatC3CellRange = worksheet.get_Range("C3", "C3");
                        formatC3CellRange.ColumnWidth = 50;
                        formatC3CellRange.Font.Name = "Calibri (Body)";
                        formatC3CellRange.Font.Size = 11;
                        if (txtTenderNo.Text != "")
                        {
                            formatC3CellRange.FormulaR1C1 = txtTenderNo.Text;
                        }
                        else
                        {
                            formatC3CellRange.FormulaR1C1 = "TBA";
                        }

                        formatA4CellRange = worksheet.get_Range("A4", "A4");
                        formatA4CellRange.ColumnWidth = 50;
                        formatA4CellRange.Font.Name = "Calibri (Body)";
                        formatA4CellRange.Font.Size = 11;
                        formatA4CellRange.FormulaR1C1 = "Project Title";

                        formatB4CellRange = worksheet.get_Range("B4", "B4");
                        formatB4CellRange.ColumnWidth = 15;
                        formatB4CellRange.Font.Name = "Calibri (Body)";
                        formatB4CellRange.Font.Size = 11;
                        formatB4CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatB4CellRange.Font.Bold = true;
                        formatB4CellRange.FormulaR1C1 = ":";
                        formatB4CellRange.ColumnWidth = 15;

                        formatC4CellRange = worksheet.get_Range("C4", "C4");
                        formatC4CellRange.ColumnWidth = 50;
                        formatC3CellRange.Font.Name = "Calibri (Body)";
                        formatC4CellRange.Font.Size = 11;
                        formatC4CellRange.FormulaR1C1 = txtproj.Text;

                        formatA5CellRange = worksheet.get_Range("A5", "A5");
                        formatA5CellRange.Font.Name = "Calibri (Body)";
                        formatA5CellRange.Font.Size = 11;
                        formatA5CellRange.FormulaR1C1 = "Project Code";

                        formatB5CellRange = worksheet.get_Range("B5", "B5");
                        formatB5CellRange.Font.Name = "Calibri (Body)";
                        formatB5CellRange.Font.Size = 11;
                        formatB5CellRange.ColumnWidth = 15;
                        formatB5CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatB5CellRange.Font.Bold = true;
                        formatB5CellRange.FormulaR1C1 = ":";
                        formatB5CellRange.ColumnWidth = 15;

                        formatC5CellRange = worksheet.get_Range("C5", "C5");
                        formatC5CellRange.ColumnWidth = 50;
                        formatC5CellRange.Font.Name = "Calibri (Body)";
                        formatC5CellRange.Font.Size = 11;
                        formatC5CellRange.FormulaR1C1 = txtProjCode.Text;

                        formatA6CellRange = worksheet.get_Range("A6", "A6");
                        formatA6CellRange.ColumnWidth = 50;
                        formatA6CellRange.Font.Name = "Calibri (Body)";
                        formatA6CellRange.Font.Size = 11;
                        formatA6CellRange.FormulaR1C1 = "Contract No.";

                        formatB6CellRange = worksheet.get_Range("B6", "B6");
                        formatB6CellRange.Font.Name = "Calibri (Body)";
                        formatB6CellRange.Font.Size = 11;
                        formatB6CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatB6CellRange.Font.Bold = true;
                        formatB6CellRange.FormulaR1C1 = ":";
                        formatB6CellRange.ColumnWidth = 15;

                        formatC6CellRange = worksheet.get_Range("C6", "C6");
                        formatC6CellRange.Font.Name = "Calibri (Body)";
                        formatC6CellRange.ColumnWidth = 50;
                        formatC6CellRange.Font.Size = 11;
                        if (lblContractNoDisplay.Text != "")
                        {
                            formatC6CellRange.FormulaR1C1 = lblContractNoDisplay.Text;
                        }
                        else
                        {
                            formatC6CellRange.FormulaR1C1 = "TBA";
                        }


                        formatA8CellRange = worksheet.get_Range("A8", "C8");
                        formatA8CellRange.Merge(true);
                        formatA8CellRange.Font.Name = "Calibri (Body)";
                        formatA8CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatA8CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(196, 189, 151));
                        formatA8CellRange.Font.Size = 11;
                        formatA8CellRange.Font.Bold = true;
                        formatA8CellRange.Font.Underline = true;
                        formatA8CellRange.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Black);
                        formatA8CellRange.FormulaR1C1 = "Prepare Tender Document";

                        formatA9CellRange = worksheet.get_Range("A9", "A9");
                        formatA9CellRange.Font.Name = "Calibri (Body)";
                        formatA9CellRange.Font.Size = 11;
                        formatA9CellRange.ColumnWidth = 50;
                        formatA9CellRange.FormulaR1C1 = "Date of Received from Dept.";

                        formatD9CellRange = worksheet.get_Range("B9", "B9");
                        formatD9CellRange.Font.Name = "Calibri (Body)";
                        formatD9CellRange.Font.Size = 11;
                        formatD9CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD9CellRange.Font.Bold = true;
                        formatD9CellRange.FormulaR1C1 = ":";
                        formatD9CellRange.ColumnWidth = 15;

                        formatE9CellRange = worksheet.get_Range("C9", "C9");
                        formatE9CellRange.Font.Name = "Calibri (Body)";
                        formatE9CellRange.ColumnWidth = 50;
                        formatE9CellRange.Font.Size = 11;
                        formatE9CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        if (dgvPTD.RowCount > 0)
                        {
                            formatE9CellRange.FormulaR1C1 = dgvPTD.Rows[0].Cells[0].Value;
                        }

                        formatA10CellRange = worksheet.get_Range("A10", "A10");
                        formatA10CellRange.Font.Name = "Calibri (Body)";
                        formatA10CellRange.Font.Size = 11;
                        formatA10CellRange.ColumnWidth = 50;
                        formatA10CellRange.FormulaR1C1 = "QS Name";

                        formatD10CellRange = worksheet.get_Range("B10", "B10");
                        formatD10CellRange.Font.Name = "Calibri (Body)";
                        formatD10CellRange.Font.Size = 11;
                        formatD10CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD10CellRange.Font.Bold = true;
                        formatD10CellRange.FormulaR1C1 = ":";
                        formatD10CellRange.ColumnWidth = 15;

                        formatE10CellRange = worksheet.get_Range("C10", "C10");
                        formatE10CellRange.Font.Name = "Calibri (Body)";
                        formatE10CellRange.ColumnWidth = 50;
                        formatE10CellRange.Font.Size = 11;

                        if (dgvPTD.RowCount > 0)
                        {
                            formatE10CellRange.FormulaR1C1 = dgvPTD.Rows[0].Cells[2].Value;
                        }

                        formatA11CellRange = worksheet.get_Range("A11", "A11");
                        formatA11CellRange.Font.Name = "Calibri (Body)";
                        formatA11CellRange.Font.Size = 11;
                        formatA11CellRange.ColumnWidth = 50;
                        formatA11CellRange.FormulaR1C1 = "QS Completed on";

                        formatD11CellRange = worksheet.get_Range("B11", "B11");
                        formatD11CellRange.Font.Name = "Calibri (Body)";
                        formatD11CellRange.Font.Size = 11;
                        formatD11CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD11CellRange.Font.Bold = true;
                        formatD11CellRange.FormulaR1C1 = ":";
                        formatD11CellRange.ColumnWidth = 15;

                        formatE11CellRange = worksheet.get_Range("C11", "C11");
                        formatE11CellRange.Font.Name = "Calibri (Body)";
                        formatE11CellRange.ColumnWidth = 50;
                        formatE11CellRange.Font.Size = 11;
                        formatE11CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;

                        if (dgvPTD.RowCount > 0)
                        {
                            formatE11CellRange.FormulaR1C1 = dgvPTD.Rows[0].Cells[6].Value;
                        }

                        formatA12CellRange = worksheet.get_Range("A12", "A12");
                        formatA12CellRange.Font.Name = "Calibri (Body)";
                        formatA12CellRange.Font.Size = 11;
                        formatA12CellRange.ColumnWidth = 50;
                        formatA12CellRange.FormulaR1C1 = "Document Status";

                        formatD12CellRange = worksheet.get_Range("B12", "B12");
                        formatD12CellRange.Font.Name = "Calibri (Body)";
                        formatD12CellRange.Font.Size = 11;
                        formatD12CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD12CellRange.Font.Bold = true;
                        formatD12CellRange.FormulaR1C1 = ":";
                        formatD12CellRange.ColumnWidth = 15;

                        formatE12CellRange = worksheet.get_Range("C12", "C12");
                        formatE12CellRange.Font.Name = "Calibri (Body)";
                        formatE12CellRange.ColumnWidth = 50;
                        formatE12CellRange.Font.Size = 11;

                        if (dgvPTD.RowCount > 0)
                        {
                            formatE12CellRange.FormulaR1C1 = dgvPTD.Rows[0].Cells[5].Value;
                        }

                        formatA13CellRange = worksheet.get_Range("A13", "A13");
                        formatA13CellRange.Font.Name = "Calibri (Body)";
                        formatA13CellRange.Font.Size = 11;
                        formatA13CellRange.ColumnWidth = 50;
                        formatA13CellRange.FormulaR1C1 = "Total Days taken";

                        formatD13CellRange = worksheet.get_Range("B13", "B13");
                        formatD13CellRange.Font.Name = "Calibri (Body)";
                        formatD13CellRange.Font.Size = 11;
                        formatD13CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD13CellRange.Font.Bold = true;
                        formatD13CellRange.FormulaR1C1 = ":";
                        formatD13CellRange.ColumnWidth = 15;

                        formatE13CellRange = worksheet.get_Range("C13", "C13");
                        formatE13CellRange.Font.Name = "Calibri (Body)";
                        formatE13CellRange.ColumnWidth = 50;
                        formatE13CellRange.Font.Size = 11;
                        formatE13CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        if (dgvPTD.RowCount > 0)
                        {
                            if (dgvPTD.Rows[0].Cells[6].Value.ToString() != "" && dgvPTD.Rows[0].Cells[0].Value.ToString() != "")
                            {
                                formatE13CellRange.FormulaR1C1 = (Convert.ToDateTime(dgvPTD.Rows[0].Cells[6].Value.ToString()) - Convert.ToDateTime(dgvPTD.Rows[0].Cells[0].Value.ToString())).Days;
                            }
                        }

                        formatA15CellRange = worksheet.get_Range("A15", "C15");
                        formatA15CellRange.Merge(true);
                        formatA15CellRange.Font.Name = "Calibri (Body)";
                        formatA15CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatA15CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(216, 228, 188));
                        formatA15CellRange.Font.Size = 11;
                        formatA15CellRange.Font.Bold = true;
                        formatA15CellRange.Font.Underline = true;
                        formatA15CellRange.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Black);
                        formatA15CellRange.FormulaR1C1 = "Tendering Stage";

                        formatA16CellRange = worksheet.get_Range("A16", "A16");
                        formatA16CellRange.Font.Name = "Calibri (Body)";
                        formatA16CellRange.Font.Size = 11;
                        formatA16CellRange.ColumnWidth = 50;
                        formatA16CellRange.FormulaR1C1 = "Received on for Tender";

                        formatD16CellRange = worksheet.get_Range("B16", "B16");
                        formatD16CellRange.Font.Name = "Calibri (Body)";
                        formatD16CellRange.Font.Size = 11;
                        formatD16CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD16CellRange.Font.Bold = true;
                        formatD16CellRange.FormulaR1C1 = ":";
                        formatD16CellRange.ColumnWidth = 15;

                        formatE16CellRange = worksheet.get_Range("C16", "C16");
                        formatE16CellRange.Font.Name = "Calibri (Body)";
                        formatE16CellRange.ColumnWidth = 50;
                        formatE16CellRange.Font.Size = 11;
                        formatE16CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;

                        string tsReceiveOn = null;
                        string tsHandledBy = null;
                        string sendToPRD = null;
                        string tdrIssueDate = null;
                        string tsModifiedClosingStg1 = null;
                        string tsModifiedClosingStg2 = null;
                        string tsClosingStg1 = null;
                        string tsClosingStg2 = null;
                        //string tsReturnToDept = null;

                        string strQuery = "SELECT ts_receive_on,ts_issue_handling,ts_return_to_dept,ts_tender_invitation, ts_modified_closing,ts_modified_closing_s2,ts_closing_s1, ts_closing_s2 " +
                        " FROM TenderDatesInfo WHERE (proj_id = " + lblProjID.Text + ") AND (stage_id = 2) AND (ts_tender_issue is null) AND (co_ID is NULL)";

                        SqlConnection sqlCn = new SqlConnection(connStr);
                        sqlCn.Open();
                        SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn);
                        SqlDataReader sqlDr = sqlCmd.ExecuteReader();

                        if (sqlDr.HasRows)
                        {
                            if (sqlDr.Read())
                            {

                                tsReceiveOn = sqlDr[0].ToString();
                                if (tsReceiveOn != "")
                                {
                                    DateTime dt_tsRecOn = Convert.ToDateTime(tsReceiveOn);
                                    tsReceiveOn = dt_tsRecOn.ToString("dd/MMM/yyyy");
                                }

                                tsHandledBy = sqlDr[1].ToString();
                                sendToPRD = sqlDr[2].ToString();
                                if (sendToPRD != "")
                                {
                                    DateTime dt_tsRetToDept = Convert.ToDateTime(sendToPRD);
                                    sendToPRD = dt_tsRetToDept.ToString("dd/MMM/yyyy");
                                }

                                tdrIssueDate = sqlDr[3].ToString();
                                if (tdrIssueDate != "")
                                {
                                    DateTime dt_tdrIssueDate = Convert.ToDateTime(tdrIssueDate);
                                    tdrIssueDate = dt_tdrIssueDate.ToString("dd/MMM/yyyy");
                                }

                                tsModifiedClosingStg1 = sqlDr[4].ToString();
                                if (tsModifiedClosingStg1 != "")
                                {
                                    DateTime dt_ModifiedClosingStg1 = Convert.ToDateTime(tsModifiedClosingStg1);
                                    tsModifiedClosingStg1 = dt_ModifiedClosingStg1.ToString("dd/MMM/yyyy");
                                }

                                tsModifiedClosingStg2 = sqlDr[5].ToString();
                                if (tsModifiedClosingStg2 != "")
                                {
                                    DateTime dt_ModifiedClosingStg2 = Convert.ToDateTime(tsModifiedClosingStg2);
                                    tsModifiedClosingStg2 = dt_ModifiedClosingStg2.ToString("dd/MMM/yyyy");
                                }

                                tsClosingStg1 = sqlDr[6].ToString();
                                if (tsClosingStg1 != "")
                                {
                                    DateTime dt_tsClosingS1 = Convert.ToDateTime(tsClosingStg1);
                                    tsClosingStg1 = dt_tsClosingS1.ToString("dd/MMM/yyyy");
                                }

                                tsClosingStg2 = sqlDr[7].ToString();
                                if (tsClosingStg2 != "")
                                {
                                    DateTime dt_tsClosingS2 = Convert.ToDateTime(tsClosingStg2);
                                    tsClosingStg2 = dt_tsClosingS2.ToString("dd/MMM/yyyy");
                                }

                            }

                        }

                        sqlDr.Close();


                        if (tsReceiveOn != "")
                        {
                            formatE16CellRange.FormulaR1C1 = tsReceiveOn;
                        }

                        formatA17CellRange = worksheet.get_Range("A17", "A17");
                        formatA17CellRange.Font.Name = "Calibri (Body)";
                        formatA17CellRange.Font.Size = 11;
                        formatA17CellRange.ColumnWidth = 50;
                        formatA17CellRange.FormulaR1C1 = "Tender Handle by";

                        formatD17CellRange = worksheet.get_Range("B17", "B17");
                        formatD17CellRange.Font.Name = "Calibri (Body)";
                        formatD17CellRange.Font.Size = 11;
                        formatD17CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD17CellRange.Font.Bold = true;
                        formatD17CellRange.FormulaR1C1 = ":";
                        formatD17CellRange.ColumnWidth = 15;

                        formatE17CellRange = worksheet.get_Range("C17", "C17");
                        formatE17CellRange.Font.Name = "Calibri (Body)";
                        formatE17CellRange.ColumnWidth = 50;
                        formatE17CellRange.Font.Size = 11;
                        formatE17CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        if (tsHandledBy != "")
                        {
                            formatE17CellRange.FormulaR1C1 = tsHandledBy;
                        }

                        formatA18CellRange = worksheet.get_Range("A18", "A18");
                        formatA18CellRange.Font.Name = "Calibri (Body)";
                        formatA18CellRange.Font.Size = 11;
                        formatA18CellRange.ColumnWidth = 50;
                        formatA18CellRange.FormulaR1C1 = "Send to PRD";

                        formatD18CellRange = worksheet.get_Range("B18", "B18");
                        formatD18CellRange.Font.Name = "Calibri (Body)";
                        formatD18CellRange.Font.Size = 11;
                        formatD18CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD18CellRange.Font.Bold = true;
                        formatD18CellRange.FormulaR1C1 = ":";
                        formatD18CellRange.ColumnWidth = 15;

                        formatE18CellRange = worksheet.get_Range("C18", "C18");
                        formatE18CellRange.Font.Name = "Calibri (Body)";
                        formatE18CellRange.ColumnWidth = 50;
                        formatE18CellRange.Font.Size = 11;
                        formatE18CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        if (sendToPRD != "")
                        {
                            formatE18CellRange.FormulaR1C1 = sendToPRD;
                        }

                        formatA19CellRange = worksheet.get_Range("A19", "A19");
                        formatA19CellRange.Font.Name = "Calibri (Body)";
                        formatA19CellRange.Font.Size = 11;
                        formatA19CellRange.ColumnWidth = 50;
                        formatA19CellRange.FormulaR1C1 = "Tender Issue date";

                        formatD19CellRange = worksheet.get_Range("B19", "B19");
                        formatD19CellRange.Font.Name = "Calibri (Body)";
                        formatD19CellRange.Font.Size = 11;
                        formatD19CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD19CellRange.Font.Bold = true;
                        formatD19CellRange.FormulaR1C1 = ":";
                        formatD19CellRange.ColumnWidth = 15;

                        formatE19CellRange = worksheet.get_Range("C19", "C19");
                        formatE19CellRange.Font.Name = "Calibri (Body)";
                        formatE19CellRange.ColumnWidth = 50;
                        formatE19CellRange.Font.Size = 11;
                        formatE19CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        if (tdrIssueDate != "")
                        {
                            formatE19CellRange.FormulaR1C1 = tdrIssueDate;
                        }

                        formatA20CellRange = worksheet.get_Range("A20", "A20");
                        formatA20CellRange.Font.Name = "Calibri (Body)";
                        formatA20CellRange.Font.Size = 11;
                        formatA20CellRange.ColumnWidth = 50;
                        formatA20CellRange.FormulaR1C1 = "Tender Closing date";

                        formatD20CellRange = worksheet.get_Range("B20", "B20");
                        formatD20CellRange.Font.Name = "Calibri (Body)";
                        formatD20CellRange.Font.Size = 11;
                        formatD20CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD20CellRange.Font.Bold = true;
                        formatD20CellRange.FormulaR1C1 = ":";
                        formatD20CellRange.ColumnWidth = 15;

                        formatE20CellRange = worksheet.get_Range("C20", "C20");
                        formatE20CellRange.Font.Name = "Calibri (Body)";
                        formatE20CellRange.ColumnWidth = 50;
                        formatE20CellRange.Font.Size = 11;
                        formatE20CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        if (tsModifiedClosingStg2 != "")
                        {
                            formatE20CellRange.FormulaR1C1 = tsModifiedClosingStg2;
                        }
                        else if (tsClosingStg2 != "")
                        {
                            formatE20CellRange.FormulaR1C1 = tsClosingStg2;
                        }
                        else if (tsModifiedClosingStg1 != "")
                        {
                            formatE20CellRange.FormulaR1C1 = tsModifiedClosingStg1;
                        }
                        else if (tsClosingStg1 != "")
                        {
                            formatE20CellRange.FormulaR1C1 = tsClosingStg1;
                        }
                        else
                        {
                            formatE20CellRange.FormulaR1C1 = "TBA";
                        }


                        formatA21CellRange = worksheet.get_Range("A21", "A21");
                        formatA21CellRange.Font.Name = "Calibri (Body)";
                        formatA21CellRange.Font.Size = 11;
                        formatA21CellRange.ColumnWidth = 50;
                        formatA21CellRange.FormulaR1C1 = "No. of Circulars";

                        formatD21CellRange = worksheet.get_Range("B21", "B21");
                        formatD21CellRange.Font.Name = "Calibri (Body)";
                        formatD21CellRange.Font.Size = 11;
                        formatD21CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD21CellRange.Font.Bold = true;
                        formatD21CellRange.FormulaR1C1 = ":";
                        formatD21CellRange.ColumnWidth = 15;

                        formatE21CellRange = worksheet.get_Range("C21", "C21");
                        formatE21CellRange.Font.Name = "Calibri (Body)";
                        formatE21CellRange.ColumnWidth = 50;
                        formatE21CellRange.Font.Size = 11;
                        formatE21CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        string sqlquery = "SELECT COUNT(distinct(CircularNo)) as CircularCount FROM DOCUMENTS WHERE (doc_type_id = 2) and stage_id=2 AND (proj_id = " + lblProjID.Text + ") and (CircularNo is not NULL) and (date_id IS NULL)";
                        sqlCmd = new SqlCommand(sqlquery, sqlCn);
                        sqlDr = sqlCmd.ExecuteReader();
                        if (sqlDr.HasRows)
                        {
                            sqlDr.Read();
                            formatE21CellRange.FormulaR1C1 = sqlDr[0].ToString();
                            sqlDr.Close();
                        }
                        else
                        {
                            formatE21CellRange.FormulaR1C1 = "TBA";
                        }

                        DAL dalObj = new DAL();

                        DataTable dtTenderDatesInfo = dalObj.GetDataFromDB("TenderDatesInfo", "SELECT TenderDatesInfo.date_id,TenderDatesInfo.TenderSubmittedTime,TenderDatesInfo.stage_id,TenderDatesInfo.Tender_Issued " +
                        "FROM TenderDatesInfo INNER JOIN PROJECTS ON PROJECTS.proj_id = TenderDatesInfo.proj_id INNER JOIN COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id INNER JOIN TenderTypes ON PROJECTS.tender_type_id = TenderTypes.tender_type_id where TenderDatesInfo.proj_id=" + _projID);

                        formatA22CellRange = worksheet.get_Range("A22", "A22");
                        formatA22CellRange.Font.Name = "Calibri (Body)";
                        formatA22CellRange.Font.Size = 11;
                        formatA22CellRange.ColumnWidth = 50;
                        formatA22CellRange.FormulaR1C1 = "No. of Bidder Purchased";

                        formatD22CellRange = worksheet.get_Range("B22", "B22");
                        formatD22CellRange.Font.Name = "Calibri (Body)";
                        formatD22CellRange.Font.Size = 11;
                        formatD22CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD22CellRange.Font.Bold = true;
                        formatD22CellRange.FormulaR1C1 = ":";
                        formatD22CellRange.ColumnWidth = 15;

                        formatE22CellRange = worksheet.get_Range("C22", "C22");
                        formatE22CellRange.Font.Name = "Calibri (Body)";
                        formatE22CellRange.ColumnWidth = 50;
                        formatE22CellRange.Font.Size = 11;
                        formatE22CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;

                        if (dtTenderDatesInfo.Rows.Count > 0)
                        {

                            formatE22CellRange.FormulaR1C1 = (from t in dtTenderDatesInfo.AsEnumerable()
                                                             .Where(t => t["TenderSubmittedTime"] != null)
                                                              select t).ToList().Count;
                        }
                        else
                        {
                            formatE22CellRange.FormulaR1C1 = "TBA";
                        }

                        formatA23CellRange = worksheet.get_Range("A23", "A23");
                        formatA23CellRange.Font.Name = "Calibri (Body)";
                        formatA23CellRange.Font.Size = 11;
                        formatA23CellRange.ColumnWidth = 50;
                        formatA23CellRange.FormulaR1C1 = "No. of Bidder Submitted";

                        formatD23CellRange = worksheet.get_Range("B23", "B23");
                        formatD23CellRange.Font.Name = "Calibri (Body)";
                        formatD23CellRange.Font.Size = 11;
                        formatD23CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD23CellRange.Font.Bold = true;
                        formatD23CellRange.FormulaR1C1 = ":";
                        formatD23CellRange.ColumnWidth = 15;

                        formatE23CellRange = worksheet.get_Range("C23", "C23");
                        formatE23CellRange.Font.Name = "Calibri (Body)";
                        formatE23CellRange.ColumnWidth = 50;
                        formatE23CellRange.Font.Size = 11;
                        formatE23CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        if (dtTenderDatesInfo.Rows.Count > 0)
                        {
                            formatE23CellRange.FormulaR1C1 = (from t in dtTenderDatesInfo.AsEnumerable()
                                                             .Where(t => t["TenderSubmittedTime"] != null)
                                                              select t).ToList().Count;
                        }
                        else
                        {
                            formatE23CellRange.FormulaR1C1 = "TBA";
                        }

                        formatA25CellRange = worksheet.get_Range("A25", "C25");
                        formatA25CellRange.Merge(true);
                        formatA25CellRange.Font.Name = "Calibri (Body)";
                        formatA25CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatA25CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(183, 222, 232));
                        formatA25CellRange.Font.Size = 11;
                        formatA25CellRange.Font.Bold = true;
                        formatA25CellRange.Font.Underline = true;
                        formatA25CellRange.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Black);
                        formatA25CellRange.FormulaR1C1 = "Evaluation and Award";

                        formatA26CellRange = worksheet.get_Range("A26", "A26");
                        formatA26CellRange.Font.Name = "Calibri (Body)";
                        formatA26CellRange.Font.Size = 11;
                        formatA26CellRange.ColumnWidth = 50;
                        formatA26CellRange.FormulaR1C1 = "Tender Open Date";

                        formatD26CellRange = worksheet.get_Range("B26", "B26");
                        formatD26CellRange.Font.Name = "Calibri (Body)";
                        formatD26CellRange.Font.Size = 11;
                        formatD26CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD26CellRange.Font.Bold = true;
                        formatD26CellRange.FormulaR1C1 = ":";
                        formatD26CellRange.ColumnWidth = 15;

                        string evalTdrOpening = null;
                        string eval_tech_sent1 = null;
                        string eval_tech_sent2 = null;
                        string eval_tech_receive1 = null;
                        string eval_tech_receive2 = null;
                        string eval_com_sent1 = null;
                        string eval_com_sent2 = null;
                        string eval_com_receive1 = null;
                        string eval_com_receive2 = null;
                        string eval_tender_award_approval = null;
                        //string tec

                        strQuery = "SELECT eval_tender_opening,eval_tech_sent1,eval_tech_sent2,eval_tech_receive1,eval_tech_receive2,eval_com_sent1,eval_com_sent2, " +
                        " eval_com_receive1, eval_com_receive2, eval_tender_award_approval,tender_validity_ext1,tender_validity_ext2,tenderbond_validity_ext1,tenderbond_validity_ext2,date_id, proj_id, stage_id,eval_no_of_meetings,remarks, " +
                        " eval_tender_doc_receive_from_cd FROM TenderDatesInfo WHERE (proj_id = " + Convert.ToInt16(lblProjID.Text) + ") AND (stage_id = 3)";
                        sqlCmd = new SqlCommand(strQuery, sqlCn);

                        sqlDr = sqlCmd.ExecuteReader();
                        if (sqlDr.HasRows)
                        {
                            sqlDr.Read();
                            evalTdrOpening = sqlDr["eval_tender_opening"].ToString();
                            eval_tech_sent1 = sqlDr["eval_tech_sent1"].ToString();
                            eval_tech_sent2 = sqlDr["eval_tech_sent2"].ToString();
                            eval_tech_receive1 = sqlDr["eval_tech_receive1"].ToString();
                            eval_tech_receive2 = sqlDr["eval_tech_receive2"].ToString();
                            eval_com_sent1 = sqlDr["eval_com_sent1"].ToString();
                            eval_com_sent2 = sqlDr["eval_com_sent2"].ToString();
                            eval_com_receive1 = sqlDr["eval_com_receive1"].ToString();
                            eval_com_receive2 = sqlDr["eval_com_receive2"].ToString();
                            eval_tender_award_approval = sqlDr["eval_tender_award_approval"].ToString();
                            sqlDr.Close();
                        }

                        formatE26CellRange = worksheet.get_Range("C26", "C26");
                        formatE26CellRange.Font.Name = "Calibri (Body)";
                        formatE26CellRange.ColumnWidth = 50;
                        formatE26CellRange.Font.Size = 11;
                        formatE26CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;

                        if (evalTdrOpening != "")
                        {
                            DateTime dt_EvalTdrOpening = Convert.ToDateTime(evalTdrOpening);
                            formatE26CellRange.FormulaR1C1 = dt_EvalTdrOpening.ToString("dd/MMM/yyyy");
                        }
                        else
                        {
                            formatE26CellRange.FormulaR1C1 = "TBA";
                        }

                        formatA27CellRange = worksheet.get_Range("A27", "A27");
                        formatA27CellRange.Font.Name = "Calibri (Body)";
                        formatA27CellRange.Font.Size = 11;
                        formatA27CellRange.ColumnWidth = 50;
                        formatA27CellRange.FormulaR1C1 = "Technical Report Requested";

                        formatD27CellRange = worksheet.get_Range("B27", "B27");
                        formatD27CellRange.Font.Name = "Calibri (Body)";
                        formatD27CellRange.Font.Size = 11;
                        formatD27CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD27CellRange.Font.Bold = true;
                        formatD27CellRange.FormulaR1C1 = ":";
                        formatD27CellRange.ColumnWidth = 15;

                        formatE27CellRange = worksheet.get_Range("C27", "C27");
                        formatE27CellRange.Font.Name = "Calibri (Body)";
                        formatE27CellRange.ColumnWidth = 50;
                        formatE27CellRange.Font.Size = 11;
                        formatE27CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        if (eval_tech_sent2 != "")
                        {
                            DateTime dt_EvalTechSent2 = Convert.ToDateTime(eval_tech_sent2);
                            formatE27CellRange.FormulaR1C1 = dt_EvalTechSent2.ToString("dd/MMM/yyyy");
                        }
                        else if (eval_tech_sent1 != "")
                        {
                            DateTime dt_EvalTechSent1 = Convert.ToDateTime(eval_tech_sent1);
                            formatE27CellRange.FormulaR1C1 = dt_EvalTechSent1.ToString("dd/MMM/yyyy");
                        }
                        else
                        {
                            formatE27CellRange.FormulaR1C1 = "TBA";
                        }

                        formatA28CellRange = worksheet.get_Range("A28", "A28");
                        formatA28CellRange.Font.Name = "Calibri (Body)";
                        formatA28CellRange.Font.Size = 11;
                        formatA28CellRange.ColumnWidth = 50;
                        formatA28CellRange.FormulaR1C1 = "Technical Report Received";

                        formatD28CellRange = worksheet.get_Range("B28", "B28");
                        formatD28CellRange.Font.Name = "Calibri (Body)";
                        formatD28CellRange.Font.Size = 11;
                        formatD28CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD28CellRange.Font.Bold = true;
                        formatD28CellRange.FormulaR1C1 = ":";
                        formatD28CellRange.ColumnWidth = 15;

                        formatE28CellRange = worksheet.get_Range("C28", "C28");
                        formatE28CellRange.Font.Name = "Calibri (Body)";
                        formatE28CellRange.ColumnWidth = 50;
                        formatE28CellRange.Font.Size = 11;
                        formatE28CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;

                        formatA29CellRange = worksheet.get_Range("A29", "A29");
                        formatA29CellRange.Font.Name = "Calibri (Body)";
                        formatA29CellRange.Font.Size = 11;
                        formatA29CellRange.ColumnWidth = 50;
                        formatA29CellRange.FormulaR1C1 = "Total Days taken for Technical Report";

                        formatD29CellRange = worksheet.get_Range("B29", "B29");
                        formatD29CellRange.Font.Name = "Calibri (Body)";
                        formatD29CellRange.Font.Size = 11;
                        formatD29CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD29CellRange.Font.Bold = true;
                        formatD29CellRange.FormulaR1C1 = ":";
                        formatD29CellRange.ColumnWidth = 15;

                        formatE29CellRange = worksheet.get_Range("C29", "C29");
                        formatE29CellRange.Font.Name = "Calibri (Body)";
                        formatE29CellRange.ColumnWidth = 50;
                        formatE29CellRange.Font.Size = 11;
                        formatE29CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        if (eval_tech_receive2 != "")
                        {
                            DateTime dt_EvalTechReceive2 = Convert.ToDateTime(eval_tech_receive2);
                            formatE28CellRange.FormulaR1C1 = dt_EvalTechReceive2.ToString("dd/MMM/yyyy");
                            if (eval_tech_sent2 != "")
                            {
                                DateTime dt_EvalTechSent2 = Convert.ToDateTime(eval_tech_sent2);
                                formatE29CellRange.FormulaR1C1 = (dt_EvalTechReceive2 - dt_EvalTechSent2).Days;
                            }
                            else if (eval_tech_receive1 != "")
                            {
                                DateTime dt_EvalTechReceive1 = Convert.ToDateTime(eval_tech_receive1);
                                formatE28CellRange.FormulaR1C1 = dt_EvalTechReceive1.ToString("dd/MMM/yyyy");
                                if (eval_tech_sent1 != "")
                                {
                                    DateTime dt_EvalTechSent1 = Convert.ToDateTime(eval_tech_sent1);
                                    formatE29CellRange.FormulaR1C1 = (dt_EvalTechReceive1 - dt_EvalTechSent1).Days;
                                }
                            }
                        }
                        else if (eval_tech_receive1 != "")
                        {
                            DateTime dt_EvalTechReceive1 = Convert.ToDateTime(eval_tech_receive1);
                            formatE28CellRange.FormulaR1C1 = dt_EvalTechReceive1.ToString("dd/MMM/yyyy");
                            if (eval_tech_sent1 != "")
                            {
                                DateTime dt_EvalTechSent1 = Convert.ToDateTime(eval_tech_sent1);
                                formatE29CellRange.FormulaR1C1 = (dt_EvalTechReceive1 - dt_EvalTechSent1).Days;
                            }
                        }
                        else
                        {
                            formatE28CellRange.FormulaR1C1 = "TBA";
                            formatE29CellRange.FormulaR1C1 = "TBA";
                        }

                        formatA30CellRange = worksheet.get_Range("A30", "A30");
                        formatA30CellRange.Font.Name = "Calibri (Body)";
                        formatA30CellRange.Font.Size = 11;
                        formatA30CellRange.ColumnWidth = 50;
                        formatA30CellRange.FormulaR1C1 = "Financial Report Requested";

                        formatD30CellRange = worksheet.get_Range("B30", "B30");
                        formatD30CellRange.Font.Name = "Calibri (Body)";
                        formatD30CellRange.Font.Size = 11;
                        formatD30CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD30CellRange.Font.Bold = true;
                        formatD30CellRange.FormulaR1C1 = ":";
                        formatD30CellRange.ColumnWidth = 15;

                        formatE30CellRange = worksheet.get_Range("C30", "C30");
                        formatE30CellRange.Font.Name = "Calibri (Body)";
                        formatE30CellRange.ColumnWidth = 50;
                        formatE30CellRange.Font.Size = 11;
                        formatE30CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        if (eval_com_sent2 != "")
                        {
                            DateTime dt_FinEvalSent2 = Convert.ToDateTime(eval_com_sent2);
                            formatE30CellRange.FormulaR1C1 = dt_FinEvalSent2.ToString("dd/MMM/yyyy");
                        }
                        else if (eval_com_sent1 != "")
                        {
                            DateTime dt_FinEvalSent1 = Convert.ToDateTime(eval_com_sent1);
                            formatE30CellRange.FormulaR1C1 = dt_FinEvalSent1.ToString("dd/MMM/yyyy");
                        }
                        else
                        {
                            formatE30CellRange.FormulaR1C1 = "TBA";
                        }

                        formatA31CellRange = worksheet.get_Range("A31", "A31");
                        formatA31CellRange.Font.Name = "Calibri (Body)";
                        formatA31CellRange.Font.Size = 11;
                        formatA31CellRange.ColumnWidth = 50;
                        formatA31CellRange.FormulaR1C1 = "Financial Report Received";

                        formatD31CellRange = worksheet.get_Range("B31", "B31");
                        formatD31CellRange.Font.Name = "Calibri (Body)";
                        formatD31CellRange.Font.Size = 11;
                        formatD31CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD31CellRange.Font.Bold = true;
                        formatD31CellRange.FormulaR1C1 = ":";
                        formatD31CellRange.ColumnWidth = 15;

                        formatE31CellRange = worksheet.get_Range("C31", "C31");
                        formatE31CellRange.Font.Name = "Calibri (Body)";
                        formatE31CellRange.ColumnWidth = 50;
                        formatE31CellRange.Font.Size = 11;
                        formatE31CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;

                        formatA32CellRange = worksheet.get_Range("A32", "A32");
                        formatA32CellRange.Font.Name = "Calibri (Body)";
                        formatA32CellRange.Font.Size = 11;
                        formatA32CellRange.ColumnWidth = 50;
                        formatA32CellRange.FormulaR1C1 = "Total Days taken for Financial Report";

                        formatD32CellRange = worksheet.get_Range("B32", "B32");
                        formatD32CellRange.Font.Name = "Calibri (Body)";
                        formatD32CellRange.Font.Size = 11;
                        formatD32CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD32CellRange.Font.Bold = true;
                        formatD32CellRange.FormulaR1C1 = ":";
                        formatD32CellRange.ColumnWidth = 15;

                        formatE32CellRange = worksheet.get_Range("C32", "C32");
                        formatE32CellRange.Font.Name = "Calibri (Body)";
                        formatE32CellRange.ColumnWidth = 50;
                        formatE32CellRange.Font.Size = 11;
                        formatE32CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        if (eval_com_receive2 != "")
                        {
                            DateTime dt_FinEvalReceive2 = Convert.ToDateTime(eval_com_receive2);
                            formatE31CellRange.FormulaR1C1 = dt_FinEvalReceive2.ToString("dd/MMM/yyyy");
                            if (eval_com_sent2 != "")
                            {
                                DateTime dt_FinEvalSent2 = Convert.ToDateTime(eval_com_sent2);
                                formatE32CellRange.FormulaR1C1 = (dt_FinEvalReceive2 - dt_FinEvalSent2).Days;
                            }
                            else if (eval_com_receive1 != "")
                            {
                                DateTime dt_FinEvalReceive1 = Convert.ToDateTime(eval_com_receive1);
                                formatE31CellRange.FormulaR1C1 = dt_FinEvalReceive1.ToString("dd/MMM/yyyy");
                                if (eval_com_sent1 != "")
                                {
                                    DateTime dt_FinEvalSent1 = Convert.ToDateTime(eval_com_sent1);
                                    formatE32CellRange.FormulaR1C1 = (dt_FinEvalReceive1 - dt_FinEvalSent1).Days;
                                }
                                else
                                {
                                    formatE32CellRange.FormulaR1C1 = "TBA";
                                }
                            }
                        }
                        else if (eval_com_receive1 != "")
                        {
                            DateTime dt_FinEvalReceive1 = Convert.ToDateTime(eval_com_receive1);
                            formatE31CellRange.FormulaR1C1 = dt_FinEvalReceive1.ToString("dd/MMM/yyyy");
                            if (eval_com_sent1 != "")
                            {
                                DateTime dt_FinEvalSent1 = Convert.ToDateTime(eval_com_sent1);
                                formatE32CellRange.FormulaR1C1 = (dt_FinEvalReceive1 - dt_FinEvalSent1).Days;
                            }
                            else
                            {
                                formatE32CellRange.FormulaR1C1 = "TBA";
                            }
                        }
                        else
                        {
                            formatE32CellRange.FormulaR1C1 = "TBA";
                        }

                        formatA33CellRange = worksheet.get_Range("A33", "A33");
                        formatA33CellRange.Font.Name = "Calibri (Body)";
                        formatA33CellRange.Font.Size = 11;
                        formatA33CellRange.ColumnWidth = 50;
                        formatA33CellRange.FormulaR1C1 = "Tender Award approval date";

                        formatD33CellRange = worksheet.get_Range("B33", "B33");
                        formatD33CellRange.Font.Name = "Calibri (Body)";
                        formatD33CellRange.Font.Size = 11;
                        formatD33CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD33CellRange.Font.Bold = true;
                        formatD33CellRange.FormulaR1C1 = ":";
                        formatD33CellRange.ColumnWidth = 15;

                        formatE33CellRange = worksheet.get_Range("C33", "C33");
                        formatE33CellRange.Font.Name = "Calibri (Body)";
                        formatE33CellRange.ColumnWidth = 50;
                        formatE33CellRange.Font.Size = 11;
                        formatE33CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        if (eval_tender_award_approval != "")
                        {
                            DateTime dt_TenderAwardApprovalDate = Convert.ToDateTime(eval_tender_award_approval);
                            formatE33CellRange.FormulaR1C1 = dt_TenderAwardApprovalDate.ToString("dd/MMM/yyyy");
                        }
                        else
                        {
                            formatE33CellRange.FormulaR1C1 = "TBA";
                        }

                        formatA34CellRange = worksheet.get_Range("A34", "A34");
                        formatA34CellRange.Font.Name = "Calibri (Body)";
                        formatA34CellRange.Font.Size = 11;
                        formatA34CellRange.ColumnWidth = 50;
                        formatA34CellRange.FormulaR1C1 = "Award Date";

                        formatD34CellRange = worksheet.get_Range("B34", "B34");
                        formatD34CellRange.Font.Name = "Calibri (Body)";
                        formatD34CellRange.Font.Size = 11;
                        formatD34CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD34CellRange.Font.Bold = true;
                        formatD34CellRange.FormulaR1C1 = ":";
                        formatD34CellRange.ColumnWidth = 15;

                        strQuery = "SELECT CONTRACTORS.cp_tender_award,  " +
                        " CONTRACTORS.cp_received_of_doc, CONTRACTORS.cp_start_date_receive, " +
                        " CONTRACTORS.cp_notice_contractor_to_sign,CONTRACTORS.StaffInCharge,CONTRACTORS.cp_contractor_sign, CONTRACTORS.cp_sent_fd_commit," +
                        "CONTRACTORS.cp_distribution FROM CONTRACTORS INNER JOIN " +
                        " COMPANY ON CONTRACTORS.co_id = COMPANY.co_id WHERE (CONTRACTORS.proj_id = " + lblProjID.Text + " and CONTRACTORS.stage_Id = 4 and CONTRACTORS.cp_tender_award is Not Null)";

                        string cpTenderAward = null;
                        string cpReceivedOfDoc = null;
                        string cpStartDateReceive = null;
                        string cpNoticeContractorToSign = null;
                        string cpContractorSign = null;
                        string cpSentFdCommit = null;
                        string cpDistribution = null;
                        string cpStaffInCharge = null;

                        sqlCmd = new SqlCommand(strQuery, sqlCn);
                        sqlDr = sqlCmd.ExecuteReader();
                        if (sqlDr.HasRows)
                        {
                            sqlDr.Read();

                            if (sqlDr["cp_tender_award"].ToString() != "")
                            {
                                DateTime dtAwardDate = Convert.ToDateTime(sqlDr["cp_tender_award"].ToString());
                                cpTenderAward = dtAwardDate.ToString("dd/MMM/yyyy");
                            }

                            if (sqlDr["cp_received_of_doc"].ToString() != "")
                            {
                                DateTime dtReceivedOfDoc = Convert.ToDateTime(sqlDr["cp_received_of_doc"].ToString());
                                cpReceivedOfDoc = dtReceivedOfDoc.ToString("dd/MMM/yyyy");
                            }

                            if (sqlDr["cp_start_date_receive"].ToString() != "")
                            {
                                DateTime dtStartDateReceive = Convert.ToDateTime(sqlDr["cp_start_date_receive"].ToString());
                                cpStartDateReceive = dtStartDateReceive.ToString("dd/MMM/yyyy");
                            }

                            if (sqlDr["cp_notice_contractor_to_sign"].ToString() != "")
                            {
                                DateTime dtNoticeContractorToSign = Convert.ToDateTime(sqlDr["cp_notice_contractor_to_sign"].ToString());
                                cpNoticeContractorToSign = dtNoticeContractorToSign.ToString("dd/MMM/yyyy");
                            }

                            if (sqlDr["cp_contractor_sign"].ToString() != "")
                            {
                                DateTime dtCpContractorSign = Convert.ToDateTime(sqlDr["cp_contractor_sign"].ToString());
                                cpContractorSign = dtCpContractorSign.ToString("dd/MMM/yyyy");
                            }

                            if (sqlDr["cp_sent_fd_commit"].ToString() != "")
                            {
                                DateTime dtCpSentFdCommit = Convert.ToDateTime(sqlDr["cp_sent_fd_commit"].ToString());
                                cpSentFdCommit = dtCpSentFdCommit.ToString("dd/MMM/yyyy");
                            }

                            if (sqlDr["cp_distribution"].ToString() != "")
                            {
                                DateTime dtCpDistribution = Convert.ToDateTime(sqlDr["cp_distribution"].ToString());
                                cpDistribution = dtCpDistribution.ToString("dd/MMM/yyyy");
                            }

                            if (sqlDr["StaffInCharge"].ToString() != "")
                            {
                                //DateTime dtCpDistribution = Convert.ToDateTime(sqlDr["cp_distribution"].ToString());
                                cpStaffInCharge = sqlDr["StaffInCharge"].ToString();
                            }

                            sqlDr.Close();
                        }
                        sqlCn.Close();

                        formatE34CellRange = worksheet.get_Range("C34", "C34");
                        formatE34CellRange.Font.Name = "Calibri (Body)";
                        formatE34CellRange.ColumnWidth = 50;
                        formatE34CellRange.Font.Size = 11;
                        formatE34CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        if (cpTenderAward != null)
                        {
                            formatE34CellRange.FormulaR1C1 = cpTenderAward;
                        }
                        else
                        {
                            formatE34CellRange.FormulaR1C1 = "TBA";
                        }

                        formatA35CellRange = worksheet.get_Range("A35", "A35");
                        formatA35CellRange.Font.Name = "Calibri (Body)";
                        formatA35CellRange.Font.Size = 11;
                        formatA35CellRange.ColumnWidth = 50;
                        formatA35CellRange.FormulaR1C1 = "Total Days taken from tender open";

                        formatD35CellRange = worksheet.get_Range("B35", "B35");
                        formatD35CellRange.Font.Name = "Calibri (Body)";
                        formatD35CellRange.Font.Size = 11;
                        formatD35CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD35CellRange.Font.Bold = true;
                        formatD35CellRange.FormulaR1C1 = ":";
                        formatD35CellRange.ColumnWidth = 15;

                        formatE35CellRange = worksheet.get_Range("C35", "C35");
                        formatE35CellRange.Font.Name = "Calibri (Body)";
                        formatE35CellRange.ColumnWidth = 50;
                        formatE35CellRange.Font.Size = 11;
                        formatE35CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        if (cpTenderAward != null && evalTdrOpening != null)
                        {
                            formatE35CellRange.FormulaR1C1 = (Convert.ToDateTime(cpTenderAward) - Convert.ToDateTime(evalTdrOpening)).Days;
                        }
                        else
                        {
                            formatE35CellRange.FormulaR1C1 = "TBA";
                        }

                        formatA37CellRange = worksheet.get_Range("A37", "C37");
                        formatA37CellRange.Merge(true);
                        formatA37CellRange.Font.Name = "Calibri (Body)";
                        formatA37CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatA37CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(252, 213, 180));
                        formatA37CellRange.Font.Size = 11;
                        formatA37CellRange.Font.Bold = true;
                        formatA37CellRange.Font.Underline = true;
                        formatA37CellRange.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Black);
                        formatA37CellRange.FormulaR1C1 = "Contracts Process";

                        formatA38CellRange = worksheet.get_Range("A38", "A38");
                        formatA38CellRange.Font.Name = "Calibri (Body)";
                        formatA38CellRange.Font.Size = 11;
                        formatA38CellRange.ColumnWidth = 50;
                        formatA38CellRange.FormulaR1C1 = "Contracts process in charge";

                        formatD38CellRange = worksheet.get_Range("B38", "B38");
                        formatD38CellRange.Font.Name = "Calibri (Body)";
                        formatD38CellRange.Font.Size = 11;
                        formatD38CellRange.Font.Bold = true;
                        formatD38CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD38CellRange.Font.Bold = true;
                        formatD38CellRange.FormulaR1C1 = ":";
                        formatD38CellRange.ColumnWidth = 15;

                        formatE38CellRange = worksheet.get_Range("C38", "C38");
                        formatE38CellRange.Font.Name = "Calibri (Body)";
                        formatE38CellRange.ColumnWidth = 50;
                        formatE38CellRange.Font.Size = 11;
                        formatE38CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        if (cpStaffInCharge != null)
                        {
                            formatE38CellRange.FormulaR1C1 = cpStaffInCharge;
                        }
                        else
                        {
                            formatE38CellRange.FormulaR1C1 = "TBA";
                        }

                        formatA39CellRange = worksheet.get_Range("A39", "A39");
                        formatA39CellRange.Font.Name = "Calibri (Body)";
                        formatA39CellRange.Font.Size = 11;
                        formatA39CellRange.ColumnWidth = 50;
                        formatA39CellRange.FormulaR1C1 = "Document Received";

                        formatD39CellRange = worksheet.get_Range("B39", "B39");
                        formatD39CellRange.Font.Name = "Calibri (Body)";
                        formatD39CellRange.Font.Size = 11;
                        formatD39CellRange.Font.Bold = true;
                        formatD39CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD39CellRange.Font.Bold = true;
                        formatD39CellRange.FormulaR1C1 = ":";
                        formatD39CellRange.ColumnWidth = 15;

                        formatE39CellRange = worksheet.get_Range("C39", "C39");
                        formatE39CellRange.Font.Name = "Calibri (Body)";
                        formatE39CellRange.ColumnWidth = 50;
                        formatE39CellRange.Font.Size = 11;
                        formatE39CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        if (cpReceivedOfDoc != null)
                        {
                            formatE39CellRange.FormulaR1C1 = cpReceivedOfDoc;
                        }
                        else
                        {
                            formatE39CellRange.FormulaR1C1 = "TBA";
                        }

                        formatA40CellRange = worksheet.get_Range("A40", "A40");
                        formatA40CellRange.Font.Name = "Calibri (Body)";
                        formatA40CellRange.Font.Size = 11;
                        formatA40CellRange.ColumnWidth = 50;
                        formatA40CellRange.FormulaR1C1 = "Start Date Received";

                        formatD40CellRange = worksheet.get_Range("B40", "B40");
                        formatD40CellRange.Font.Name = "Calibri (Body)";
                        formatD40CellRange.Font.Size = 11;
                        formatD40CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD40CellRange.Font.Bold = true;
                        formatD40CellRange.FormulaR1C1 = ":";
                        formatD40CellRange.ColumnWidth = 15;

                        formatE40CellRange = worksheet.get_Range("C40", "C40");
                        formatE40CellRange.Font.Name = "Calibri (Body)";
                        formatE40CellRange.ColumnWidth = 50;
                        formatE40CellRange.Font.Size = 11;
                        formatE40CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        if (cpStartDateReceive != null)
                        {
                            formatE40CellRange.FormulaR1C1 = cpStartDateReceive;
                        }
                        else
                        {
                            formatE40CellRange.FormulaR1C1 = "TBA";
                        }

                        formatA41CellRange = worksheet.get_Range("A41", "A41");
                        formatA41CellRange.Font.Name = "Calibri (Body)";
                        formatA41CellRange.Font.Size = 11;
                        formatA41CellRange.ColumnWidth = 50;
                        formatA41CellRange.FormulaR1C1 = "NoA Issued";

                        formatD41CellRange = worksheet.get_Range("B41", "B41");
                        formatD41CellRange.Font.Name = "Calibri (Body)";
                        formatD41CellRange.Font.Size = 11;
                        formatD41CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD41CellRange.Font.Bold = true;
                        formatD41CellRange.FormulaR1C1 = ":";
                        formatD41CellRange.ColumnWidth = 15;

                        formatE41CellRange = worksheet.get_Range("C41", "C41");
                        formatE41CellRange.Font.Name = "Calibri (Body)";
                        formatE41CellRange.ColumnWidth = 50;
                        formatE41CellRange.Font.Size = 11;
                        formatE41CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        if (cpNoticeContractorToSign != null)
                        {
                            formatE41CellRange.FormulaR1C1 = cpNoticeContractorToSign;
                        }
                        else
                        {
                            formatE41CellRange.FormulaR1C1 = "TBA";
                        }

                        //strQuery = "SELECT  CONTRACTORS.StaffInCharge " +
                        //" FROM CONTRACTORS INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id " +
                        //" WHERE (CONTRACTORS.proj_id = " + lblProjID.Text + " and CONTRACTORS.stage_Id=4 and CONTRACTORS.cp_tender_award is not NULL)";



                        //sqlCmd = new SqlCommand(strQuery, sqlCn);
                        //sqlDr = sqlCmd.ExecuteReader();
                        //if (sqlDr.HasRows)
                        //{
                        //    sqlDr.Read();



                        //    sqlDr.Close();
                        //}

                        formatA42CellRange = worksheet.get_Range("A42", "A42");
                        formatA42CellRange.Font.Name = "Calibri (Body)";
                        formatA42CellRange.Font.Size = 11;
                        formatA42CellRange.ColumnWidth = 50;
                        formatA42CellRange.FormulaR1C1 = "Date of Sign";

                        formatD42CellRange = worksheet.get_Range("B42", "B42");
                        formatD42CellRange.Font.Name = "Calibri (Body)";
                        formatD42CellRange.Font.Size = 11;
                        formatD42CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD42CellRange.Font.Bold = true;
                        formatD42CellRange.FormulaR1C1 = ":";
                        formatD42CellRange.ColumnWidth = 15;

                        formatE42CellRange = worksheet.get_Range("C42", "C42");
                        formatE42CellRange.Font.Name = "Calibri (Body)";
                        formatE42CellRange.ColumnWidth = 50;
                        formatE42CellRange.Font.Size = 11;
                        formatE42CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        if (cpContractorSign != null)
                        {
                            formatE42CellRange.FormulaR1C1 = cpContractorSign;
                        }
                        else
                        {
                            formatE42CellRange.FormulaR1C1 = "TBA";
                        }

                        formatA43CellRange = worksheet.get_Range("A43", "A43");
                        formatA43CellRange.Font.Name = "Calibri (Body)";
                        formatA43CellRange.Font.Size = 11;
                        formatA43CellRange.ColumnWidth = 50;
                        formatA43CellRange.FormulaR1C1 = "Date of Commitment";

                        formatD43CellRange = worksheet.get_Range("B43", "B43");
                        formatD43CellRange.Font.Name = "Calibri (Body)";
                        formatD43CellRange.Font.Size = 11;
                        formatD43CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD43CellRange.Font.Bold = true;
                        formatD43CellRange.FormulaR1C1 = ":";
                        formatD43CellRange.ColumnWidth = 15;

                        formatE43CellRange = worksheet.get_Range("C43", "C43");
                        formatE43CellRange.Font.Name = "Calibri (Body)";
                        formatE43CellRange.ColumnWidth = 50;
                        formatE43CellRange.Font.Size = 11;
                        formatE43CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        if (cpSentFdCommit != null)
                        {
                            formatE43CellRange.FormulaR1C1 = cpSentFdCommit;
                        }
                        else
                        {
                            formatE43CellRange.FormulaR1C1 = "TBA";
                        }

                        formatA44CellRange = worksheet.get_Range("A44", "A44");
                        formatA44CellRange.Font.Name = "Calibri (Body)";
                        formatA44CellRange.Font.Size = 11;
                        formatA44CellRange.ColumnWidth = 50;
                        formatA44CellRange.FormulaR1C1 = "Date of Distiribution";

                        formatD44CellRange = worksheet.get_Range("B44", "B44");
                        formatD44CellRange.Font.Name = "Calibri (Body)";
                        formatD44CellRange.Font.Size = 11;
                        formatD44CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD44CellRange.Font.Bold = true;
                        formatD44CellRange.FormulaR1C1 = ":";
                        formatD44CellRange.ColumnWidth = 15;

                        formatE44CellRange = worksheet.get_Range("C44", "C44");
                        formatE44CellRange.Font.Name = "Calibri (Body)";
                        formatE44CellRange.ColumnWidth = 50;
                        formatE44CellRange.Font.Size = 11;
                        formatE44CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        if (cpDistribution != null)
                        {
                            formatE44CellRange.FormulaR1C1 = cpDistribution;
                        }
                        else
                        {
                            formatE44CellRange.FormulaR1C1 = "TBA";
                        }


                        formatA45CellRange = worksheet.get_Range("A45", "A45");
                        formatA45CellRange.Font.Name = "Calibri (Body)";
                        formatA45CellRange.Font.Size = 11;
                        formatA45CellRange.ColumnWidth = 50;
                        formatA45CellRange.FormulaR1C1 = "Total days taken for Contract Process";

                        formatD45CellRange = worksheet.get_Range("B45", "B45");
                        formatD45CellRange.Font.Name = "Calibri (Body)";
                        formatD45CellRange.Font.Size = 11;
                        formatD45CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatD45CellRange.Font.Bold = true;
                        formatD45CellRange.FormulaR1C1 = ":";
                        formatD45CellRange.ColumnWidth = 15;

                        formatE45CellRange = worksheet.get_Range("C45", "C45");
                        formatE45CellRange.Font.Name = "Calibri (Body)";
                        formatE45CellRange.ColumnWidth = 50;
                        formatE45CellRange.Font.Size = 11;
                        formatE45CellRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        if (cpDistribution != null && cpReceivedOfDoc != null)
                        {
                            formatE45CellRange.FormulaR1C1 = (Convert.ToDateTime(cpDistribution) - Convert.ToDateTime(cpReceivedOfDoc)).Days;
                        }
                        else
                        {
                            formatE45CellRange.FormulaR1C1 = "TBA";
                        }

                        // save the workbook
                        workbook.SaveAs(saveFileDialog1.FileName, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    }

                }
                else
                {
                    MessageBox.Show("You do not have permission to Export the Project Summary into Excel sheet, Please contact the Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while creating the excel file", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        //private void dtpTTR_datesent1_ValueChanged(object sender, EventArgs e)
        //{
        //    //DateSendFirstEvalValidation(dtpTE_datesent1, msk_dtpTE_datesent1, msk_dtpTE_daterec1);
        //    msk_dtpTTR_datesent1.Text = "";
        //    TenderRevDateSendFirstEvalValidation(dtpTTR_datesent1, msk_dtpTTR_datesent1, msk_dtpTE_daterec1, msk_dtpTE_daterec2, "Technical Tender Review", "Technical Evaluation", false);
        //}

        //private void dtpTTR_daterec1_ValueChanged(object sender, EventArgs e)
        //{
        //    msk_dtpTTR_daterec1.Text = "";
        //    DateReceivedFirstEvalValidation(dtpTTR_daterec1, msk_dtpTTR_datesent1, msk_dtpTTR_daterec1, "Technical Tender Review", false);
        //    //TechTdrRevDateRecFirstEvalValidation();            
        //}

        //private void dtpTTR_datesent2_ValueChanged(object sender, EventArgs e)
        //{
        //    msk_dtpTTR_datesent2.Text = "";
        //    DateSendSecEvalValidation(dtpTTR_datesent2, msk_dtpTTR_datesent2, msk_dtpTTR_datesent1, msk_dtpTTR_daterec1, "Technical Tender Review", false);
        //}

        //private void dtpTTR_daterec2_ValueChanged(object sender, EventArgs e)
        //{
        //    msk_dtpTTR_daterec2.Text = "";
        //    DateReceivedSecEvalValidation(dtpTTR_daterec2, msk_dtpTTR_daterec2, msk_dtpTTR_datesent1, msk_dtpTTR_daterec1, "Technical Tender Review", false);
        //}

        //private void dtpFTR_datesentfin1_ValueChanged(object sender, EventArgs e)
        //{
        //    msk_dtpFTR_datesent1.Text = "";
        //    TenderRevDateSendFirstEvalValidation(dtpFTR_datesentfin1, msk_dtpFTR_datesent1, msk_dtpFE_daterecFin1, msk_dtpFE_daterecFin2, "Financial Tender Review", "Financial Evaluation", false);
        //}

        //private void dtpFTR_daterecFin1_ValueChanged(object sender, EventArgs e)
        //{
        //    msk_dtpFTR_daterec1.Text = "";
        //    DateReceivedFirstEvalValidation(dtpFTR_daterecFin1, msk_dtpFTR_datesent1, msk_dtpFTR_daterec1, "Financial Tender Review", false);
        //}

        //private void dtpFTR_datesentfin2_ValueChanged(object sender, EventArgs e)
        //{
        //    msk_dtpFTR_datesent2.Text = "";
        //    DateSendSecEvalValidation(dtpFTR_datesentfin2, msk_dtpFTR_datesent2, msk_dtpFTR_datesent1, msk_dtpFTR_daterec1, "Financial Tender Review", false);
        //}

        //private void dtpFTR_daterecFin2_ValueChanged(object sender, EventArgs e)
        //{
        //    msk_dtpFTR_daterec2.Text = "";
        //    DateReceivedSecEvalValidation(dtpFTR_daterecFin2, msk_dtpFTR_daterec2, msk_dtpFTR_datesent1, msk_dtpFTR_daterec1, "Financial Tender Review", false);
        //}

        private void dgvContracts_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                if (e.ColumnIndex == 2 || e.ColumnIndex == 4 || e.ColumnIndex == 5 || e.ColumnIndex == 6 || e.ColumnIndex == 7 || e.ColumnIndex == 8)
                {
                    if (dgvContracts.Rows[e.RowIndex].Cells[4].Value.ToString().Trim() != "" && dgvContracts.Rows[e.RowIndex].Cells[2].Value.ToString().Trim() != "")
                    {
                        if (Convert.ToDateTime(dgvContracts.Rows[e.RowIndex].Cells[4].Value).CompareTo(Convert.ToDateTime(dgvContracts.Rows[e.RowIndex].Cells[2].Value)) < 0) //Cells[2]->AwardLetter and Cells[4]->RecAwardDocument 
                        {
                            MessageBox.Show("Received of Award Document date cannot be less than Date of Letter of Award");
                            return;
                        }
                    }

                    if (dgvContracts.Rows[e.RowIndex].Cells[5].Value.ToString().Trim() != "" && dgvContracts.Rows[e.RowIndex].Cells[4].Value.ToString().Trim() != "")
                    {
                        if (Convert.ToDateTime(dgvContracts.Rows[e.RowIndex].Cells[5].Value).CompareTo(Convert.ToDateTime(dgvContracts.Rows[e.RowIndex].Cells[4].Value)) < 0) //Cells[2]->AwardLetter and Cells[4]->RecAwardDocument 
                        {
                            MessageBox.Show("Request Department to provide Start date cannot be less than Received of Award Document date");
                            return;
                        }
                    }

                    if (dgvContracts.Rows[e.RowIndex].Cells[6].Value.ToString().Trim() != "" && dgvContracts.Rows[e.RowIndex].Cells[5].Value.ToString().Trim() != "")
                    {
                        if (Convert.ToDateTime(dgvContracts.Rows[e.RowIndex].Cells[6].Value).CompareTo(Convert.ToDateTime(dgvContracts.Rows[e.RowIndex].Cells[5].Value)) < 0) //Cells[2]->AwardLetter and Cells[4]->RecAwardDocument 
                        {
                            MessageBox.Show("Start Date Received cannot be less than Request Department to provide Start date");
                            return;
                        }
                    }

                    if (dgvContracts.Rows[e.RowIndex].Cells[7].Value.ToString().Trim() != "" && dgvContracts.Rows[e.RowIndex].Cells[6].Value.ToString().Trim() != "")
                    {
                        if (Convert.ToDateTime(dgvContracts.Rows[e.RowIndex].Cells[7].Value).CompareTo(Convert.ToDateTime(dgvContracts.Rows[e.RowIndex].Cells[6].Value)) < 0) //Cells[2]->AwardLetter and Cells[4]->RecAwardDocument 
                        {
                            MessageBox.Show("Notice Sent To Tenderer to Sign date cannot be less than Start Date Received");
                            return;
                        }
                    }

                    if (dgvContracts.Rows[e.RowIndex].Cells[8].Value.ToString().Trim() != "" && dgvContracts.Rows[e.RowIndex].Cells[7].Value.ToString().Trim() != "")
                    {
                        if (Convert.ToDateTime(dgvContracts.Rows[e.RowIndex].Cells[8].Value).CompareTo(Convert.ToDateTime(dgvContracts.Rows[e.RowIndex].Cells[7].Value)) < 0) //Cells[2]->AwardLetter and Cells[4]->RecAwardDocument 
                        {
                            MessageBox.Show("Due date of Submission of Bond and Sign date cannot be less than Notice Sent To Tenderer to Sign date");
                            return;
                        }
                    }
                }
            }
        }

        private void dgvContracts_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                if (e.ColumnIndex == 2 || e.ColumnIndex == 4 || e.ColumnIndex == 5 || e.ColumnIndex == 6 || e.ColumnIndex == 7 || e.ColumnIndex == 8)
                {
                    if (dgvContracts.Rows[e.RowIndex].Cells[4].Value.ToString().Trim() != "" && dgvContracts.Rows[e.RowIndex].Cells[2].Value.ToString().Trim() != "")
                    {
                        if (Convert.ToDateTime(dgvContracts.Rows[e.RowIndex].Cells[4].Value.ToString().Split(' ')[0]).CompareTo(Convert.ToDateTime(dgvContracts.Rows[e.RowIndex].Cells[2].Value.ToString().Split(' ')[0])) < 0) //Cells[2]->AwardLetter and Cells[4]->RecAwardDocument 
                        {
                            MessageBox.Show("Received of Award Document date cannot be less than Date of Letter of Award");
                            dgvContracts.Rows[e.RowIndex].Cells[4].Selected = true;
                            dgvContracts.Rows[e.RowIndex].Cells[4].Style.ForeColor = Color.Red;
                            return;
                        }
                        else
                        {
                            dgvContracts.Rows[e.RowIndex].Cells[4].Style.ForeColor = Color.Orange;
                        }
                    }

                    if (dgvContracts.Rows[e.RowIndex].Cells[5].Value.ToString().Trim() != "" && dgvContracts.Rows[e.RowIndex].Cells[4].Value.ToString().Trim() != "")
                    {
                        if (Convert.ToDateTime(dgvContracts.Rows[e.RowIndex].Cells[5].Value.ToString().Split(' ')[0]).CompareTo(Convert.ToDateTime(dgvContracts.Rows[e.RowIndex].Cells[4].Value.ToString().Split(' ')[0])) < 0) //Cells[2]->AwardLetter and Cells[4]->RecAwardDocument 
                        {
                            MessageBox.Show("Request Department to provide Start date cannot be less than Received of Award Document date");
                            dgvContracts.Rows[e.RowIndex].Cells[5].Selected = true;
                            dgvContracts.Rows[e.RowIndex].Cells[5].Style.ForeColor = Color.Red;
                            return;
                        }
                        if (Convert.ToDateTime(dgvContracts.Rows[e.RowIndex].Cells[5].Value.ToString().Split(' ')[0]).CompareTo(Convert.ToDateTime(dgvContracts.Rows[e.RowIndex].Cells[2].Value.ToString().Split(' ')[0])) < 0) //Cells[2]->AwardLetter and Cells[4]->RecAwardDocument 
                        {
                            MessageBox.Show("Request Department to provide Start date cannot be less than Date of Letter of Award");
                            dgvContracts.Rows[e.RowIndex].Cells[4].Selected = true;
                            dgvContracts.Rows[e.RowIndex].Cells[4].Style.ForeColor = Color.Red;
                            return;
                        }
                        else
                        {
                            dgvContracts.Rows[e.RowIndex].Cells[5].Style.ForeColor = Color.Orange;
                        }
                    }

                    if (dgvContracts.Rows[e.RowIndex].Cells[6].Value.ToString().Trim() != "" && dgvContracts.Rows[e.RowIndex].Cells[5].Value.ToString().Trim() != "")
                    {
                        if (Convert.ToDateTime(dgvContracts.Rows[e.RowIndex].Cells[6].Value.ToString().Split(' ')[0]).CompareTo(Convert.ToDateTime(dgvContracts.Rows[e.RowIndex].Cells[5].Value.ToString().Split(' ')[0])) < 0) //Cells[2]->AwardLetter and Cells[4]->RecAwardDocument 
                        {
                            MessageBox.Show("Start Date Received cannot be less than Request Department to provide Start date");
                            dgvContracts.Rows[e.RowIndex].Cells[6].Selected = true;
                            dgvContracts.Rows[e.RowIndex].Cells[6].Style.ForeColor = Color.Red;
                            return;
                        }
                        else
                        {
                            dgvContracts.Rows[e.RowIndex].Cells[6].Style.ForeColor = Color.Orange;
                        }
                    }

                    if (dgvContracts.Rows[e.RowIndex].Cells[7].Value.ToString().Trim() != "" && dgvContracts.Rows[e.RowIndex].Cells[6].Value.ToString().Trim() != "")
                    {
                        if (Convert.ToDateTime(dgvContracts.Rows[e.RowIndex].Cells[7].Value.ToString().Split(' ')[0]).CompareTo(Convert.ToDateTime(dgvContracts.Rows[e.RowIndex].Cells[6].Value.ToString().Split(' ')[0])) < 0) //Cells[2]->AwardLetter and Cells[4]->RecAwardDocument 
                        {
                            MessageBox.Show("Notice Sent To Tenderer to Sign date cannot be less than Start Date Received");
                            dgvContracts.Rows[e.RowIndex].Cells[7].Selected = true;
                            dgvContracts.Rows[e.RowIndex].Cells[7].Style.ForeColor = Color.Red;
                            return;
                        }
                        else
                        {
                            dgvContracts.Rows[e.RowIndex].Cells[7].Style.ForeColor = Color.Orange;
                        }
                    }

                    if (dgvContracts.Rows[e.RowIndex].Cells[8].Value.ToString().Trim() != "" && dgvContracts.Rows[e.RowIndex].Cells[7].Value.ToString().Trim() != "")
                    {
                        if (Convert.ToDateTime(dgvContracts.Rows[e.RowIndex].Cells[8].Value.ToString().Split(' ')[0]).CompareTo(Convert.ToDateTime(dgvContracts.Rows[e.RowIndex].Cells[7].Value.ToString().Split(' ')[0])) < 0) //Cells[2]->AwardLetter and Cells[4]->RecAwardDocument 
                        {
                            MessageBox.Show("Due date of Submission of Bond and Sign date cannot be less than Notice Sent To Tenderer to Sign date");
                            dgvContracts.Rows[e.RowIndex].Cells[8].Selected = true;
                            dgvContracts.Rows[e.RowIndex].Cells[8].Style.ForeColor = Color.Red;
                            return;
                        }
                        else
                        {
                            dgvContracts.Rows[e.RowIndex].Cells[8].Style.ForeColor = Color.Orange;
                        }
                    }
                }
            }
        }

        private void dgvCpDataEntry_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                if (e.ColumnIndex == 1 || e.ColumnIndex == 2 || e.ColumnIndex == 3 || e.ColumnIndex == 4 || e.ColumnIndex == 5 || e.ColumnIndex == 6)
                {
                    if (dgvCpDataEntry.Rows[e.RowIndex].Cells[2].Value.ToString().Trim() != "" && dgvCpDataEntry.Rows[e.RowIndex].Cells[1].Value.ToString().Trim() != "")
                    {
                        if (Convert.ToDateTime(dgvCpDataEntry.Rows[e.RowIndex].Cells[2].Value.ToString().Split(' ')[0]).CompareTo(Convert.ToDateTime(dgvCpDataEntry.Rows[e.RowIndex].Cells[1].Value.ToString().Split(' ')[0])) < 0) //Cells[2]->AwardLetter and Cells[4]->RecAwardDocument 
                        {
                            MessageBox.Show("Sent to Dept. for Signature date cannot be less than or equal to Date of Sign Contract");
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[2].Selected = true;
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[2].Style.ForeColor = Color.Red;
                            return;
                        }
                        if (Convert.ToDateTime(dgvCpDataEntry.Rows[e.RowIndex].Cells[1].Value.ToString().Split(' ')[0]).CompareTo(Convert.ToDateTime(dgvCpDataEntry.Rows[e.RowIndex].Cells[2].Value.ToString().Split(' ')[0])) > 0) //Cells[2]->AwardLetter and Cells[4]->RecAwardDocument 
                        {
                            MessageBox.Show("Date of Sign Contract cannot be greater than or equal to Sent to Dept. for Signature date");
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[1].Selected = true;
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[1].Style.ForeColor = Color.Red;
                            return;
                        }
                        else
                        {
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[1].Style.ForeColor = Color.Orange;
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[2].Style.ForeColor = Color.Orange;
                        }
                    }

                    if (dgvCpDataEntry.Rows[e.RowIndex].Cells[3].Value.ToString().Trim() != "" && dgvCpDataEntry.Rows[e.RowIndex].Cells[2].Value.ToString().Trim() != "")
                    {
                        if (Convert.ToDateTime(dgvCpDataEntry.Rows[e.RowIndex].Cells[3].Value.ToString().Split(' ')[0]).CompareTo(Convert.ToDateTime(dgvCpDataEntry.Rows[e.RowIndex].Cells[2].Value.ToString().Split(' ')[0])) <= 0) //Cells[2]->AwardLetter and Cells[4]->RecAwardDocument 
                        {
                            MessageBox.Show("Received from Dept. for PRSD Sign date cannot be less than or equal to Sent to Dept. for Signature date");
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[3].Selected = true;
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[3].Style.ForeColor = Color.Red;
                            return;
                        }
                        if (Convert.ToDateTime(dgvCpDataEntry.Rows[e.RowIndex].Cells[2].Value.ToString().Split(' ')[0]).CompareTo(Convert.ToDateTime(dgvCpDataEntry.Rows[e.RowIndex].Cells[3].Value.ToString().Split(' ')[0])) >= 0) //Cells[2]->AwardLetter and Cells[4]->RecAwardDocument 
                        {
                            MessageBox.Show("Sent to Dept. for Signature date cannot be greater than or equal to Received from Dept. for PRSD Sign date");
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[2].Selected = true;
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[2].Style.ForeColor = Color.Red;
                            return;
                        }
                        else
                        {
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[2].Style.ForeColor = Color.Orange;
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[3].Style.ForeColor = Color.Orange;
                        }
                    }

                    if (dgvCpDataEntry.Rows[e.RowIndex].Cells[4].Value.ToString().Trim() != "" && dgvCpDataEntry.Rows[e.RowIndex].Cells[3].Value.ToString().Trim() != "")
                    {
                        if (Convert.ToDateTime(dgvCpDataEntry.Rows[e.RowIndex].Cells[4].Value.ToString().Split(' ')[0]).CompareTo(Convert.ToDateTime(dgvCpDataEntry.Rows[e.RowIndex].Cells[3].Value.ToString().Split(' ')[0])) <= 0) //Cells[2]->AwardLetter and Cells[4]->RecAwardDocument 
                        {
                            MessageBox.Show("Sent to Finance Dept for Committment cannot be less than or equal to Received from Dept. for PRSD Sign date");
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[4].Selected = true;
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[4].Style.ForeColor = Color.Red;
                            return;
                        }
                        if (Convert.ToDateTime(dgvCpDataEntry.Rows[e.RowIndex].Cells[3].Value.ToString().Split(' ')[0]).CompareTo(Convert.ToDateTime(dgvCpDataEntry.Rows[e.RowIndex].Cells[4].Value.ToString().Split(' ')[0])) >= 0) //Cells[2]->AwardLetter and Cells[4]->RecAwardDocument 
                        {
                            MessageBox.Show("Received from Dept. for PRSD Sign date cannot be greater than or equal to Sent to Finance Dept for Committment date");
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[3].Selected = true;
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[3].Style.ForeColor = Color.Red;
                            return;
                        }
                        else
                        {
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[3].Style.ForeColor = Color.Orange;
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[4].Style.ForeColor = Color.Orange;
                        }
                    }

                    if (dgvCpDataEntry.Rows[e.RowIndex].Cells[5].Value.ToString().Trim() != "" && dgvCpDataEntry.Rows[e.RowIndex].Cells[4].Value.ToString().Trim() != "")
                    {
                        if (Convert.ToDateTime(dgvCpDataEntry.Rows[e.RowIndex].Cells[5].Value.ToString().Split(' ')[0]).CompareTo(Convert.ToDateTime(dgvCpDataEntry.Rows[e.RowIndex].Cells[4].Value.ToString().Split(' ')[0])) <= 0) //Cells[2]->AwardLetter and Cells[4]->RecAwardDocument 
                        {
                            MessageBox.Show("Received From Finance Dept. date cannot be less than or equal to Sent to Finance Dept. for Committment date");
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[5].Selected = true;
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[5].Style.ForeColor = Color.Red;
                            return;
                        }
                        if (Convert.ToDateTime(dgvCpDataEntry.Rows[e.RowIndex].Cells[4].Value.ToString().Split(' ')[0]).CompareTo(Convert.ToDateTime(dgvCpDataEntry.Rows[e.RowIndex].Cells[5].Value.ToString().Split(' ')[0])) >= 0) //Cells[2]->AwardLetter and Cells[4]->RecAwardDocument 
                        {
                            MessageBox.Show("Sent to Finance Dept. for Committment date cannot be greater than or equal to Received From Finance Dept. date ");
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[4].Selected = true;
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[4].Style.ForeColor = Color.Red;
                            return;
                        }
                        else
                        {
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[4].Style.ForeColor = Color.Orange;
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[5].Style.ForeColor = Color.Orange;
                        }
                    }

                    if (dgvCpDataEntry.Rows[e.RowIndex].Cells[6].Value.ToString().Trim() != "" && dgvCpDataEntry.Rows[e.RowIndex].Cells[5].Value.ToString().Trim() != "")
                    {
                        if (Convert.ToDateTime(dgvCpDataEntry.Rows[e.RowIndex].Cells[6].Value.ToString().Split(' ')[0]).CompareTo(Convert.ToDateTime(dgvCpDataEntry.Rows[e.RowIndex].Cells[5].Value.ToString().Split(' ')[0])) <= 0) //Cells[2]->AwardLetter and Cells[4]->RecAwardDocument 
                        {
                            MessageBox.Show("Distribution Date cannot be less than or equal to Received From Finance Dept. date");
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[6].Selected = true;
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[6].Style.ForeColor = Color.Red;
                            return;
                        }
                        if (Convert.ToDateTime(dgvCpDataEntry.Rows[e.RowIndex].Cells[5].Value.ToString().Split(' ')[0]).CompareTo(Convert.ToDateTime(dgvCpDataEntry.Rows[e.RowIndex].Cells[6].Value.ToString().Split(' ')[0])) >= 0) //Cells[2]->AwardLetter and Cells[4]->RecAwardDocument 
                        {
                            MessageBox.Show("Distribution Date cannot be less than or equal to Received From Finance Dept. date");
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[5].Selected = true;
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[5].Style.ForeColor = Color.Red;
                            return;
                        }
                        else
                        {
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[5].Style.ForeColor = Color.Orange;
                            dgvCpDataEntry.Rows[e.RowIndex].Cells[6].Style.ForeColor = Color.Orange;
                        }
                    }
                }
            }
        }

        private void msk_dtpTE_datesent1_Leave(object sender, EventArgs e)
        {
            //if (msk_dtpTE_datesent1.Text.Trim() == "")
            //{
            //    msk_dtpTE_datesent1.Text = "01/Jan/1900";
            //} 
        }

        private void msk_dtpTE_datesent2_Leave(object sender, EventArgs e)
        {
            //if (msk_dtpTE_datesent2.Text.Trim() == "")
            //{
            //    msk_dtpTE_datesent2.Text = "01/Jan/1900";
            //}  
        }

        private void msk_dtpTE_daterec2_Leave(object sender, EventArgs e)
        {
            //if (msk_dtpTE_daterec2.Text == "")
            //{
            //    msk_dtpTE_daterec2.Text = "01/Jan/1900";
            //}            
        }

        private void msk_dtpFE_datesentfin2_Leave(object sender, EventArgs e)
        {
            //if (msk_dtpFE_datesentfin2.Text.Trim() == "")
            //{
            //    msk_dtpFE_datesentfin2.Text = "01/Jan/1900";
            //} 
        }

        private void msk_dtpFE_daterecFin2_Leave(object sender, EventArgs e)
        {
            //if (msk_dtpFE_daterecFin2.Text.Trim() == "")
            //{
            //    msk_dtpFE_daterecFin2.Text = "01/Jan/1900";
            //} 
        }

        private void btnWorkOrder2_Click(object sender, EventArgs e)
        {
            frmWorkOrders frmWorkOrders = null;
            frmWorkOrders = new MDI_ParenrForm.Projects.frmWorkOrders(mUserRightsColl, _projID, txtTenderNo.Text, txtproj.Text, _userName, mIsHeadOfSection,false);
            frmWorkOrders.StartPosition = FormStartPosition.CenterParent;
            frmWorkOrders.ShowDialog();
        }

        private void btnWorkOrderInPTD_Click(object sender, EventArgs e)
        {
            frmWorkOrders frmWorkOrders = null;
            frmWorkOrders = new MDI_ParenrForm.Projects.frmWorkOrders(mUserRightsColl, _projID, txtTenderNo.Text, txtproj.Text, _userName, mIsHeadOfSection, true);
            frmWorkOrders.StartPosition = FormStartPosition.CenterParent;
            frmWorkOrders.ShowDialog();
        }
    }
}
