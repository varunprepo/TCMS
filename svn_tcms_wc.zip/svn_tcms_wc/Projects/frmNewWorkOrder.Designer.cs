﻿namespace MDI_ParenrForm.Projects
{
    partial class frmNewWorkOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblWorkOrderNo = new System.Windows.Forms.Label();
            this.lblProjTitle = new System.Windows.Forms.Label();
            this.txtWorkOrderNo = new System.Windows.Forms.TextBox();
            this.txtProjTitle = new System.Windows.Forms.TextBox();
            this.btnSaveAndClose = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.dtpWorkOrderClosingDate = new System.Windows.Forms.DateTimePicker();
            this.mskTxtWorkOrderClosingDate = new System.Windows.Forms.MaskedTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.mskTxtWOIssueDate = new System.Windows.Forms.TextBox();
            this.lblWorkOrderClosingDate = new System.Windows.Forms.Label();
            this.dtpWOIssueDate = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblWorkOrderNo
            // 
            this.lblWorkOrderNo.AutoSize = true;
            this.lblWorkOrderNo.Location = new System.Drawing.Point(27, 42);
            this.lblWorkOrderNo.Name = "lblWorkOrderNo";
            this.lblWorkOrderNo.Size = new System.Drawing.Size(82, 13);
            this.lblWorkOrderNo.TabIndex = 0;
            this.lblWorkOrderNo.Text = "Work Order No.";
            // 
            // lblProjTitle
            // 
            this.lblProjTitle.AutoSize = true;
            this.lblProjTitle.Location = new System.Drawing.Point(27, 87);
            this.lblProjTitle.Name = "lblProjTitle";
            this.lblProjTitle.Size = new System.Drawing.Size(85, 13);
            this.lblProjTitle.TabIndex = 2;
            this.lblProjTitle.Text = "Work Order Title";
            // 
            // txtWorkOrderNo
            // 
            this.txtWorkOrderNo.Location = new System.Drawing.Point(153, 44);
            this.txtWorkOrderNo.Name = "txtWorkOrderNo";
            this.txtWorkOrderNo.Size = new System.Drawing.Size(100, 20);
            this.txtWorkOrderNo.TabIndex = 3;
            // 
            // txtProjTitle
            // 
            this.txtProjTitle.Location = new System.Drawing.Point(153, 84);
            this.txtProjTitle.Multiline = true;
            this.txtProjTitle.Name = "txtProjTitle";
            this.txtProjTitle.Size = new System.Drawing.Size(250, 60);
            this.txtProjTitle.TabIndex = 5;
            // 
            // btnSaveAndClose
            // 
            this.btnSaveAndClose.BackColor = System.Drawing.Color.Maroon;
            this.btnSaveAndClose.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSaveAndClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveAndClose.ForeColor = System.Drawing.Color.White;
            this.btnSaveAndClose.Location = new System.Drawing.Point(153, 264);
            this.btnSaveAndClose.Name = "btnSaveAndClose";
            this.btnSaveAndClose.Size = new System.Drawing.Size(106, 26);
            this.btnSaveAndClose.TabIndex = 14;
            this.btnSaveAndClose.Text = "Save && Close";
            this.btnSaveAndClose.UseVisualStyleBackColor = false;
            this.btnSaveAndClose.Click += new System.EventHandler(this.btnSaveAndClose_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(256, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(12, 15);
            this.label2.TabIndex = 16;
            this.label2.Text = "*";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(18, 239);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 13);
            this.label4.TabIndex = 18;
            this.label4.Text = "* Mandatory Fields";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(274, 204);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(12, 15);
            this.label5.TabIndex = 19;
            this.label5.Text = "*";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 206);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(125, 13);
            this.label8.TabIndex = 45;
            this.label8.Text = "Work Order Closing Date";
            // 
            // dtpWorkOrderClosingDate
            // 
            this.dtpWorkOrderClosingDate.Checked = false;
            this.dtpWorkOrderClosingDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpWorkOrderClosingDate.Location = new System.Drawing.Point(153, 202);
            this.dtpWorkOrderClosingDate.Name = "dtpWorkOrderClosingDate";
            this.dtpWorkOrderClosingDate.ShowCheckBox = true;
            this.dtpWorkOrderClosingDate.Size = new System.Drawing.Size(118, 20);
            this.dtpWorkOrderClosingDate.TabIndex = 46;
            this.dtpWorkOrderClosingDate.Value = new System.DateTime(2015, 10, 15, 0, 0, 0, 0);
            this.dtpWorkOrderClosingDate.ValueChanged += new System.EventHandler(this.dtpWorkOrderClosingDate_ValueChanged);
            // 
            // mskTxtWorkOrderClosingDate
            // 
            this.mskTxtWorkOrderClosingDate.Location = new System.Drawing.Point(151, 202);
            this.mskTxtWorkOrderClosingDate.Name = "mskTxtWorkOrderClosingDate";
            this.mskTxtWorkOrderClosingDate.Size = new System.Drawing.Size(87, 20);
            this.mskTxtWorkOrderClosingDate.TabIndex = 47;
            this.mskTxtWorkOrderClosingDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(406, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(12, 15);
            this.label3.TabIndex = 48;
            this.label3.Text = "*";
            // 
            // mskTxtWOIssueDate
            // 
            this.mskTxtWOIssueDate.Location = new System.Drawing.Point(152, 160);
            this.mskTxtWOIssueDate.Name = "mskTxtWOIssueDate";
            this.mskTxtWOIssueDate.Size = new System.Drawing.Size(86, 20);
            this.mskTxtWOIssueDate.TabIndex = 62;
            // 
            // lblWorkOrderClosingDate
            // 
            this.lblWorkOrderClosingDate.AutoSize = true;
            this.lblWorkOrderClosingDate.Location = new System.Drawing.Point(12, 163);
            this.lblWorkOrderClosingDate.Name = "lblWorkOrderClosingDate";
            this.lblWorkOrderClosingDate.Size = new System.Drawing.Size(116, 13);
            this.lblWorkOrderClosingDate.TabIndex = 63;
            this.lblWorkOrderClosingDate.Text = "Work Order Issue Date";
            // 
            // dtpWOIssueDate
            // 
            this.dtpWOIssueDate.Checked = false;
            this.dtpWOIssueDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpWOIssueDate.Location = new System.Drawing.Point(155, 160);
            this.dtpWOIssueDate.Name = "dtpWOIssueDate";
            this.dtpWOIssueDate.ShowCheckBox = true;
            this.dtpWOIssueDate.Size = new System.Drawing.Size(116, 20);
            this.dtpWOIssueDate.TabIndex = 61;
            this.dtpWOIssueDate.Value = new System.DateTime(2016, 12, 25, 0, 0, 0, 0);
            this.dtpWOIssueDate.ValueChanged += new System.EventHandler(this.dtpWOIssueDate_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(273, 161);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(12, 15);
            this.label1.TabIndex = 64;
            this.label1.Text = "*";
            // 
            // frmNewWorkOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FloralWhite;
            this.ClientSize = new System.Drawing.Size(432, 322);
            this.Controls.Add(this.mskTxtWOIssueDate);
            this.Controls.Add(this.lblWorkOrderClosingDate);
            this.Controls.Add(this.dtpWOIssueDate);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.mskTxtWorkOrderClosingDate);
            this.Controls.Add(this.dtpWorkOrderClosingDate);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnSaveAndClose);
            this.Controls.Add(this.txtProjTitle);
            this.Controls.Add(this.txtWorkOrderNo);
            this.Controls.Add(this.lblProjTitle);
            this.Controls.Add(this.lblWorkOrderNo);
            this.Name = "frmNewWorkOrder";
            this.Text = "Add New Work Order";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblWorkOrderNo;
        private System.Windows.Forms.Label lblProjTitle;
        private System.Windows.Forms.TextBox txtWorkOrderNo;
        private System.Windows.Forms.TextBox txtProjTitle;
        private System.Windows.Forms.Button btnSaveAndClose;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker dtpWorkOrderClosingDate;
        private System.Windows.Forms.MaskedTextBox mskTxtWorkOrderClosingDate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox mskTxtWOIssueDate;
        private System.Windows.Forms.Label lblWorkOrderClosingDate;
        private System.Windows.Forms.DateTimePicker dtpWOIssueDate;
        private System.Windows.Forms.Label label1;
    }
}