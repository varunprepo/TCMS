﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using TenderTrackingSystem.Contacts;
using TenderTrackingSystem;
using System.IO;
using System.Diagnostics;

namespace MDI_ParenrForm.Projects
{
    public partial class frmIssueTenderInfo : Form
    {
        CommonClass comCls = null;
        int _ProjId = 0;
        int _bidDateID = 0;
        IList<string> mUserRightsColl = new List<string>();
        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();
        protected SqlConnection sqlConn;   
        string _userName = string.Empty;
        char _chGetShortListed = ' ';        
        char _chTypeOfShortList = ' ';
        string firstTimeIssue = "";
        string mProjCode = "";         
        string mDocFee = "";         
        int mTotalCirculars = 0;
        clsTs_Stage clsForTS = null;
        string originalCmpID = null;
        string originalCmpName = null;         

        public frmIssueTenderInfo(IList<string> userRightsCollPrjState, int prjId, string tndrNo, string tndrTitle, string chkCmpFilter, string user, char chShortListed,string issueStatus,string projCode,string docFee)
        {
            mUserRightsColl = userRightsCollPrjState;
            InitializeComponent();
            _ProjId = prjId;
            _userName = user;
            comCls  = new CommonClass(_userName);           
            _chGetShortListed = chShortListed;
            firstTimeIssue = issueStatus;
            mProjCode = projCode;
            mDocFee = docFee;             
            clsForTS = new clsTs_Stage(_userName);
            mTotalCirculars = clsForTS.GetCircularCount(prjId);
            if (chkCmpFilter != "")
            {
                string sqlQuery = @"SELECT COMPANY.co_id, COMPANY.co_name, COMPANY.block_listed, COMPANY_TYPE.co_type_id " +
                 " FROM COMPANY INNER JOIN COMPANY_TYPE ON COMPANY.co_type_id = COMPANY_TYPE.co_type_id " +
                 " WHERE (COMPANY.co_category_id<>4) and (COMPANY_TYPE.co_type_id IN (" + chkCmpFilter + ",4)) and COMPANY.co_name <>'' and (COMPANY.co_id <> 425)" +
                 " Order by Co_Name";

                comCls.PopulateComboBox(cmbCompany, sqlQuery, "co_id", "co_name");

                string sqlQueryEmp = @"SELECT Contacts.employee_id,Contacts.FirstName + ' ' + Contacts.LastName AS PersonName, COMPANY.co_name, COMPANY_TYPE.co_type_id " +
                " FROM COMPANY INNER JOIN COMPANY_TYPE ON COMPANY.co_type_id = COMPANY_TYPE.co_type_id INNER JOIN " +
                " Contacts ON COMPANY.co_id = Contacts.co_id WHERE (COMPANY_TYPE.co_type_id IN (" + chkCmpFilter + ",4)) AND Contacts.AuthorizedRep = 1 AND (COMPANY.co_category_id <> 4) " +
                " AND (Contacts.employee_id <> 83) AND (Contacts.employee_id <> 122) ORDER BY PersonName";  //
                comCls.PopulateComboBox(cmbEmp, sqlQueryEmp, "employee_id", "PersonName");
            }           
            
            txtTenderNo.Text = tndrNo;
            txtPrjTitle.Text = tndrTitle;                      
        }

        public frmIssueTenderInfo(IList<string> userRightsCollPrjState, string biddersGridColumnValues , string tndrNo, string contractTitle, Boolean chkMode, string chkCmpFilter, string user, char chShortListed, char paramTypeOfShortList, string projCode, string docFee)
        {
            mUserRightsColl = userRightsCollPrjState;
            InitializeComponent();
            _bidDateID = Convert.ToInt32(biddersGridColumnValues.Split(',')[0]);
            _ProjId = Convert.ToInt32(biddersGridColumnValues.Split(',')[1]);             
            txtTenderNo.Text = tndrNo;
            txtPrjTitle.Text = contractTitle;
            _chGetShortListed = chShortListed;         
            _chTypeOfShortList = paramTypeOfShortList;
            mProjCode = projCode;
            mDocFee = docFee;
            if (_chGetShortListed == 'Y')
            {
                label15.Visible = false;
                lblProjIDNonMohMandatory.Visible = false;
            }
            _userName = user;
            comCls = new CommonClass(_userName);
            if (chkCmpFilter != "")
            {
                string sqlQuery = @"SELECT COMPANY.co_id, COMPANY.co_name, COMPANY.block_listed, COMPANY_TYPE.co_type_id " +
                 " FROM COMPANY INNER JOIN COMPANY_TYPE ON COMPANY.co_type_id = COMPANY_TYPE.co_type_id " +
                 " WHERE (COMPANY.co_category_id!=4) and (COMPANY_TYPE.co_type_id IN (" + chkCmpFilter + ",4)) and COMPANY.co_name <>'' and (COMPANY.co_id <> 425)" +
                 " Order by Co_Name";
                comCls.PopulateComboBox(cmbCompany, sqlQuery, "co_id", "co_name");

                string sqlQueryEmp = @"SELECT Contacts.employee_id,Contacts.FirstName + ' ' + Contacts.LastName AS PersonName, COMPANY.co_name, COMPANY_TYPE.co_type_id " +
                " FROM COMPANY INNER JOIN COMPANY_TYPE ON COMPANY.co_type_id = COMPANY_TYPE.co_type_id INNER JOIN " +
                " Contacts ON COMPANY.co_id = Contacts.co_id WHERE (COMPANY_TYPE.co_type_id IN (" + chkCmpFilter + ",4)) AND Contacts.AuthorizedRep = 1 AND (COMPANY.co_category_id <> 4) " +
                " AND (Contacts.employee_id <> 83) AND (Contacts.employee_id <> 122) ORDER BY PersonName";  //
                comCls.PopulateComboBox(cmbEmp, sqlQueryEmp, "employee_id", "PersonName");
                 
            }            
        }
        private void GetBidderInfo(int bidID)
        {
            string empname = string.Empty;                       
            
            string sqlQuery =  "SELECT TenderDatesInfo.date_id, TenderDatesInfo.proj_id, TenderDatesInfo.stage_id, TenderDatesInfo.ts_tender_issue, TenderDatesInfo.ts_receipt_no, " +
              " TenderDatesInfo.remarks, COMPANY.co_name, TenderDatesInfo.co_id, TenderDatesInfo.employee_id, " +
              " Contacts.FirstName + Contacts.LastName AS PersonName,TenderDatesInfo.Company_EmailID FROM TenderDatesInfo INNER JOIN COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id INNER JOIN " +
              " Contacts ON TenderDatesInfo.employee_id = Contacts.employee_id WHERE (TenderDatesInfo.date_id = " + bidID + ")";

            using (SqlConnection sqlCon = new SqlConnection(strCon))
            {
                sqlCon.Open();
                using (SqlCommand sqlComm = new SqlCommand(sqlQuery, sqlCon))
                {
                    using (SqlDataReader dr = sqlComm.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            DateTime? dt = null;
                            if (dr[3].ToString() != "")
                            {
                                dt = Convert.ToDateTime(dr[3].ToString());
                                if (!(dt.ToString().Contains("1947") || dt.ToString().Contains("01/Jan/1947") || dt.ToString().Contains("01/Jan/47") || dt.ToString().Contains("01-Jan-47") || dt.ToString().Contains("01/01/47")))  // Added by Varun the date should not be equal to 01/Jan/1947 12:00:00 AM hardcoded                       
                                dtptenderIssue.Text = Convert.ToDateTime(dt).ToString("dd/MMM/yyyy");
                            }

                            if(dr[4].ToString() !="")
                              txtRecptNo.Text = dr[4].ToString();
                            if (dr[5].ToString() != "")
                              txtBidRemarks.Text = dr[5].ToString();
                            if (dr[7].ToString() != "")
                            {
                                cmbCompany.SelectedValue = Convert.ToInt16(dr[7].ToString());
                                originalCmpID = cmbCompany.SelectedValue.ToString();
                                DataRowView dtView = (DataRowView)cmbCompany.SelectedItem;
                                originalCmpName = dtView.Row.ItemArray[1].ToString();
                            }
                            if (dr[8].ToString() != "")
                            {
                                cmbEmp.SelectedValue = Convert.ToInt16(dr[8].ToString());                                

                            }
                            if (dr[9].ToString() != "")
                              empname = dr[9].ToString();
                            
                            if (dr[10].ToString() != "")
                                txtEmail.Text = dr[10].ToString();
                        }
                    }
                }
            }           
            FillCompanyData(true);           
        }
        private void frmIssueTenderInfo_Load(object sender, EventArgs e)
        {
            if (_bidDateID!=0)
            GetBidderInfo(_bidDateID);
        }
        private void button3_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Contains("26"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }
            TenderTrackingSystem.Contacts.frmContactPerson frmPerson = new TenderTrackingSystem.Contacts.frmContactPerson(mUserRightsColl,_userName,false);
            frmPerson.StartPosition = FormStartPosition.CenterScreen;
            frmPerson.ShowDialog();             
        }
        
        private int maxDateID()
        {
            int bid_dateID = 0;
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"SELECT MAX(date_id)+1 FROM TenderDatesInfo";
                        bid_dateID = Convert.ToInt16(cmd.ExecuteScalar());                     
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE DATES records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            return bid_dateID;
        }

        DateTime? tenderIssueDateTime = null;
        private void InsertBidderInfo(int maxbid_dateID)
        {
            int iSNo = 0;             
            iSNo = comCls.GetMaxInfo("SELECT MAX(sn) FROM TenderDatesInfo WHERE proj_id=" + _ProjId, 'Y');
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        //Modified by Varun on 21/04/2014 based on change request of modifying the email address of the company and inserting it into TenderDatesInfo table and then retrieving from the same table instead of Company table
                        // this is only in case of non-short list companies view

                        if (txtTenderIssueDate.Text!="")
                        tenderIssueDateTime = Convert.ToDateTime(txtTenderIssueDate.Text + " " + string.Format("{0:hh:mm:ss tt}", DateTime.Now));

                        cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,ts_tender_issue,ts_receipt_no,employee_id,co_id,remarks,create_date,create_user,sn,Tender_Issued,Company_EmailID,docCollectedFrom,mobileNoofDoc,QID) " +
                        " VALUES(@dateId,@projId,@stageId,@tenderIssue,@tendrReceiptNo,@empId,@coid,@Bid_remarks,@createDate,@createUser,@sn,@tenderIssued,@companyEmailID,@docCollectedFrom,@mobileNoofDoc,@QID)";
                         
                        cmd.Parameters.AddWithValue("@dateId", maxbid_dateID);
                        cmd.Parameters.AddWithValue("@projId", _ProjId);
                        cmd.Parameters.AddWithValue("@stageId", 2);
                        cmd.Parameters.AddWithValue("@tenderIssue", tenderIssueDateTime);
                        cmd.Parameters.AddWithValue("@tendrReceiptNo", txtRecptNo.Text);    //tendrReceiptNo
                        cmd.Parameters.AddWithValue("@empId", Convert.ToInt16(cmbEmp.SelectedValue));
                        cmd.Parameters.AddWithValue("@coid", Convert.ToInt16(cmbCompany.SelectedValue));
                        cmd.Parameters.AddWithValue("@Bid_remarks", txtBidRemarks.Text);                        
                        cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now);                         
                        cmd.Parameters.AddWithValue("@createUser", _userName);
                        cmd.Parameters.AddWithValue("@tenderIssued", 1);
                        cmd.Parameters.AddWithValue("@sn", iSNo);

                        cmd.Parameters.AddWithValue("@companyEmailID", txtEmail.Text.ToString().Replace(";", "; "));

                        cmd.Parameters.AddWithValue("@docCollectedFrom", txtDocCollectedBy.Text);
                        cmd.Parameters.AddWithValue("@mobileNoofDoc", txtMobile.Text);
                        cmd.Parameters.AddWithValue("@QID", txtQID.Text);
                                                
                        int exUpdated = cmd.ExecuteNonQuery();                        
                        cmd.Parameters.Clear();                         
                        try
                        {
                            comCls.InsertRecordsInDocumentsTable(_ProjId, cmd, maxbid_dateID, sqlConn, comCls, Convert.ToInt16(cmbCompany.SelectedValue),Convert.ToInt16(cmbEmp.SelectedValue));
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error occurred while Inserting records::"+ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        foreach (ListViewItem item in lstCRCopies.Items)
                        {
                            using (SqlCommand command = new SqlCommand())
                            {
                                command.CommandText = @"INSERT INTO CRAttachment(crAttFileName, crAttFile,co_id,create_date,create_user) VALUES (@crAttFileName, @crAttFile,@co_id,@createDate,@createUser)";
                                command.Connection = sqlConn;
                                command.Parameters.AddWithValue("@crAttFileName", item.Text);
                                command.Parameters.AddWithValue("@crAttFile", item.Tag);
                                command.Parameters.AddWithValue("@co_id", cmbCompany.SelectedValue);
                                command.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                                command.Parameters.AddWithValue("@createUser", _userName);
                                command.ExecuteNonQuery();
                                command.Dispose();
                            }
                        }
                        MessageBox.Show("Tender Issued Succesfully");
                        this.Close();
                    }
                    sqlConn.Close();
                }                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Insert Tender Issue records, Try again.::" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        //Modified by Varun
        private void UpdateBidderInfo(int projID, int biddateID, char chGetShortListed)
        {
            clsDatabase clsObj = null;
            try
            {
                tenderIssueDateTime = Convert.ToDateTime(txtTenderIssueDate.Text + " " + string.Format("{0:hh:mm:ss tt}", DateTime.Now));
                clsForTS = new clsTs_Stage(_userName);
                mTotalCirculars = clsForTS.GetCircularCount(projID);
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        using (SqlCommand command = new SqlCommand())
                        {
                            command.CommandText = @"DELETE FROM CRAttachment WHERE co_id = @coID";
                            command.Connection = sqlConn;
                            command.Parameters.AddWithValue("@coID", cmbCompany.SelectedValue);
                            int ex = command.ExecuteNonQuery();
                            command.Dispose();
                        }

                        foreach (ListViewItem item in lstCRCopies.Items)
                        {
                            using (SqlCommand command = new SqlCommand())
                            {
                                command.CommandText = @"INSERT INTO CRAttachment(crAttFileName, crAttFile,co_id,create_date,create_user) VALUES (@crAttFileName, @crAttFile,@co_id,@createDate,@createUser)";
                                command.Connection = sqlConn;
                                command.Parameters.AddWithValue("@crAttFileName", item.Text);
                                command.Parameters.AddWithValue("@crAttFile", item.Tag);
                                command.Parameters.AddWithValue("@co_id", cmbCompany.SelectedValue);
                                command.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                                command.Parameters.AddWithValue("@createUser", _userName);
                                command.ExecuteNonQuery();
                                command.Dispose();
                            }
                        }

                        if (txtTenderIssueDate.Text != "" && chGetShortListed != 'Y')
                        {
                            //Modified by Varun on 21/04/2014 based on change request of modifying the email address of the company and inserting it into TenderDatesInfo table and then retrieving from the same table instead of Company table
                            // this is only in case of non-short list companies view
                           // cmd.CommandText = @"UPDATE TenderDatesInfo SET ts_tender_issue = @tenderIssue,ts_receipt_no = @tendrReceiptNo,employee_id = @empId,co_id = @coid,remarks = @Bid_remarks,update_date = @updateDate,update_user = @updateUser, Company_EmailID=@companyEmailID Where date_id = @biddateId ";
                            

                            // Modified bty Sreedhar on Jun 9th 2014 : Update QID n Doc Colleded person n mob no in tenderdaes info                             
                            cmd.CommandText = @"UPDATE TenderDatesInfo SET ts_tender_issue = @tenderIssue,ts_receipt_no = @tendrReceiptNo,employee_id = @empId,co_id = @coid,remarks = @Bid_remarks,update_date = @updateDate,update_user = @updateUser, " +
                            "  Company_EmailID=@companyEmailID, mobileNoofDoc = @mobNo,QID = @QID_No,Doc_SubmittedBy = @docCollectedBy  Where date_id = @biddateId ";     //docCollectedFrom = @docCollectedBy,  Doc_SubmittedBy                                                     
                        
                            cmd.Parameters.AddWithValue("@biddateId", biddateID);
                            cmd.Parameters.AddWithValue("@tenderIssue", tenderIssueDateTime);
                            cmd.Parameters.AddWithValue("@tendrReceiptNo", txtRecptNo.Text);    //tendrReceiptNo                                                         
                            cmd.Parameters.AddWithValue("@empId", Convert.ToInt16(cmbEmp.SelectedValue));
                            cmd.Parameters.AddWithValue("@coid", Convert.ToInt16(cmbCompany.SelectedValue));                            
                            cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                            cmd.Parameters.AddWithValue("@updateUser", _userName);
                            cmd.Parameters.AddWithValue("@companyEmailID", txtEmail.Text.ToString().Replace(";","; "));                            
                            cmd.Parameters.AddWithValue("@docCollectedBy", txtDocCollectedBy.Text);
                            cmd.Parameters.AddWithValue("@mobNo", txtMobile.Text);
                            cmd.Parameters.AddWithValue("@QID_No", txtQID.Text);
                            if (!cmbCompany.SelectedValue.ToString().Equals(originalCmpID))
                            {
                                DataRowView dtView = (DataRowView)cmbCompany.SelectedItem;                               
                                cmd.Parameters.AddWithValue("@Bid_remarks", txtBidRemarks.Text + " " + "Based on Tender Committee decision " + originalCmpName + " has been changed to " + dtView.Row.ItemArray[1].ToString() + "");
                            }
                            else
                                cmd.Parameters.AddWithValue("@Bid_remarks", txtBidRemarks.Text);
                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                            MessageBox.Show("Updated Tender Issued Data Succesfully");                           
                        }
                        else if (chGetShortListed == 'Y')
                        {
                            if(_chTypeOfShortList=='3')
                                cmd.CommandText = @"UPDATE TenderDatesInfo SET ts_tender_issue = @tenderIssue,ts_receipt_no = @tendrReceiptNo,employee_id = @empId,co_id = @coid,remarks = @Bid_remarks,update_date = @updateDate,update_user=@updateUser,Company_EmailID=@companyEmailID Where date_id = @biddateId ";                                                             
                            else
                                cmd.CommandText = @"UPDATE TenderDatesInfo SET ts_tender_issue = @tenderIssue,ts_receipt_no = @tendrReceiptNo,employee_id = @empId,co_id = @coid,remarks = @Bid_remarks,update_date = @updateDate,update_user=@updateUser,Tender_Issued=@tenderIssued,Company_EmailID=@companyEmailID Where date_id = @biddateId ";                                                             
                            if (txtTenderIssueDate.Text == "" && txtRecptNo.Text == "")
                            {
                                cmd.CommandText = @"UPDATE TenderDatesInfo SET sn=@sn,ts_tender_issue = @tenderIssue,ts_receipt_no = @tendrReceiptNo,employee_id = @empId,co_id = @coid,remarks = @Bid_remarks,update_date = @updateDate,update_user=@updateUser,Tender_Issued=@tenderIssued Where date_id = @biddateId ";                                                             
                                cmd.Parameters.AddWithValue("@tenderIssue", "01/01/1947");
                                cmd.Parameters.AddWithValue("@tendrReceiptNo", System.DBNull.Value);    //tendrReceiptNo                                                                                         
                                cmd.Parameters.AddWithValue("@tenderIssued", 0);
                                cmd.Parameters.AddWithValue("@sn", System.DBNull.Value);
                                cmd.Parameters.AddWithValue("@companyEmailID", System.DBNull.Value);
                            }
                            else
                            {
                                cmd.Parameters.AddWithValue("@tenderIssue", tenderIssueDateTime);
                                cmd.Parameters.AddWithValue("@tendrReceiptNo", txtRecptNo.Text);    //tendrReceiptNo                                                                                                                         
                                if (_chTypeOfShortList == 'S')
                                    cmd.Parameters.AddWithValue("@tenderIssued", 1);
                                cmd.Parameters.AddWithValue("@companyEmailID", txtEmail.Text.ToString().Replace(";", "; "));
                            }                            
                            cmd.Parameters.AddWithValue("@biddateId", biddateID);                            
                            cmd.Parameters.AddWithValue("@empId", Convert.ToInt16(cmbEmp.SelectedValue));
                            cmd.Parameters.AddWithValue("@coid", Convert.ToInt16(cmbCompany.SelectedValue));
                            if (!cmbCompany.SelectedValue.ToString().Equals(originalCmpID))
                            {
                                DataRowView dtView = (DataRowView)cmbCompany.SelectedItem;
                                string currentCmpName = dtView.Row.ItemArray[1].ToString();
                                originalCmpName = dtView.Row.ItemArray[1].ToString();
                                cmd.Parameters.AddWithValue("@Bid_remarks", txtBidRemarks.Text + " " + "Based on Tender Committee decision " + originalCmpName + " has been changed to " + currentCmpName + "");
                            }
                            else
                                cmd.Parameters.AddWithValue("@Bid_remarks", txtBidRemarks.Text);
                            cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                            cmd.Parameters.AddWithValue("@updateUser", _userName);                             
                            cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                            if (txtTenderIssueDate.Text != "" && txtRecptNo.Text != "")
                            {
                                receiptCounter = comCls.maxValue("SELECT COUNT(*) FROM TenderDatesInfo WHERE (ts_tender_issue >= CONVERT(VARCHAR(20), CAST('05-01-2014' AS DATETIME), 101))");                                 
                                PopulateBidderDetails();
                                companyInfo[5] = receiptCounter.ToString();

                                DialogResult dlgResult = DialogResult.Yes;
                                dlgResult = MessageBox.Show(" Are you sure you want to Print the Receipt after Editing the Tenderer Information?", "Print Receipt Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                                string outTenderSubmissionDateAndTime = null;

                                if (dlgResult.ToString() == "Yes")
                                {
                                    comCls.ExportToPDF(strCon, null, null, null, txtTenderNo.Text, mProjCode, txtPrjTitle.Text, _ProjId, null, null, mTotalCirculars, null, mDocFee, tenderIssueDateTime.ToString(), 'I', 'N', null, null, 0, companyInfo, 2, "", 1, null, false,false);       // ref outTenderSubmissionDateAndTime                          
                                }
                                else
                                    return; 
//=======
//                                {
//                                    // Modified by Varun on 22/072014 changed the value of txtDocCollectedBy.Text to collectedBy=collectedBy/Qid
//                                    string collectedBy = txtDocCollectedBy.Text + "/" + txtQID.Text;
//                                    comCls.ExportToPDF(strCon, null, null, null, txtTenderNo.Text, mProjCode, txtPrjTitle.Text, _ProjId, null, null, mTotalCirculars, null, mDocFee, tenderIssueDateTime.ToString(), 'I', 'N', null, null, 0, companyInfo, 2, collectedBy);
//                                }
//                                else
//                                    return; 

                            }
                            if (txtTenderIssueDate.Text == "" && txtRecptNo.Text == "")
                            {
                                comCls = new CommonClass(_userName);
                                comCls.ReNumberSNCol(projID, strCon, _chTypeOfShortList);
                                clsObj = new clsDatabase(strCon);
                                clsObj.ExecuteNonQuery("delete from DOCUMENTS where date_id=" + biddateID + " and proj_Id =" + projID + " AND (stage_id = 2)");
                                
                            }
                            MessageBox.Show("Updated Tender Issued Data Succesfully");                             
                        }
                        if (!cmbCompany.SelectedValue.ToString().Equals(originalCmpID))
                        {
                            clsObj = new clsDatabase(strCon);
                            clsObj.ConnectDB();
                            string currentBidderId = null;
                            bool isFound = false;
                            SqlDataReader sqlDtReader = clsObj.ExecuteReader("select bidder_id from CONTRACTORS where proj_Id =" + projID + " AND co_id=" + cmbCompany.SelectedValue, sqlConn, 'Y');                            
                            
                            if (sqlDtReader.Read())
                            {
                                currentBidderId = sqlDtReader["bidder_id"].ToString();
                                sqlDtReader.Close();
                                sqlDtReader = clsObj.ExecuteReader("select bidder_id from CONTRACTORS where proj_Id =" + projID + " AND co_id=" + originalCmpID, sqlConn, 'Y');                               
                                string originalBidderId = null;
                                if (sqlDtReader.Read())
                                {                                    
                                    originalBidderId = sqlDtReader["bidder_id"].ToString();
                                    sqlDtReader.Close();
                                    clsObj.ExecuteNonQuery("Update WorkOrders set bidder_Id=" + currentBidderId + " where proj_Id =" + projID + " and  bidder_Id=" + originalBidderId);
                                }                  
                                isFound = true;
                            }
                            if (!isFound)
                            {
                                sqlDtReader.Close();
                                sqlDtReader = clsObj.ExecuteReader("select bidder_id from CONTRACTORS where proj_Id =" + projID + " AND co_id=" + originalCmpID, sqlConn, 'Y');
                                if (!sqlDtReader.Read())
                                {
                                    sqlDtReader.Close();
                                    clsObj.ExecuteNonQuery("delete from CONTRACTORS where proj_Id =" + projID + " and co_id=" + originalCmpID);
                                }
                            }                           
                            
                            clsObj.DisconnectDB();
                        }

                    }

                    sqlConn.Close();
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating Tender Issue records", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        CommonClass cmnCls = new CommonClass("");       
        private void FillEmployeeData()
        {
            try
            {
                if (cmbEmp.Items.Count == 0)
                {
                    string sqlQuery = "SELECT employee_id, FirstName + ' ' + LastName AS PersonName, ShortName, AuthorizedRep,co_id FROM Contacts WHERE employee_id =117";

                    cmbEmp.DataSource = null;
                    comCls.PopulateComboBox(cmbEmp, sqlQuery, "employee_id", "PersonName");
                    cmbEmp.SelectedIndex = 0;
                }
                else
                {
                    string sqlQuery = "SELECT employee_id, FirstName + ' ' + LastName AS PersonName, ShortName, AuthorizedRep,co_id FROM Contacts WHERE (AuthorizedRep = 1) AND (co_id = " + cmbCompany.SelectedValue + ")";
                    
                    cmbEmp.SelectedIndex = -1;
                    using (SqlConnection sqlConn = new SqlConnection(strCon))
                    {
                        sqlConn.Open();
                        using (SqlCommand cmd = new SqlCommand())
                        {
                            cmd.Connection = sqlConn;
                            cmd.CommandText = sqlQuery;
                            SqlDataReader dr = cmd.ExecuteReader();
                            if (dr.HasRows)
                            {
                                while (dr.Read())
                                {
                                    cmbEmp.Text = dr[1].ToString();
                                }
                            }
                            dr.Close();
                        }
                        sqlConn.Close();
                    }

                    if (cmbEmp.Text == "")
                    {
                        getAuthorizedEmpInfo();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while populating the Employee data", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void getAuthorizedEmpInfo()
        {
            string sqlQueryNew = "SELECT employee_id, FirstName + ' ' + LastName AS PersonName, ShortName, AuthorizedRep,co_id FROM Contacts WHERE (AuthorizedRep = 1) AND (employee_id = 117) ";
            using (SqlConnection sqlConn = new SqlConnection(strCon))
            {
                sqlConn.Open();
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlConn;
                    cmd.CommandText = sqlQueryNew;
                    SqlDataReader drAuth = cmd.ExecuteReader();
                    if (drAuth.HasRows)
                    {
                        if (drAuth.Read())
                        {
                            cmbEmp.Text = drAuth[1].ToString();
                        }
                    }
                    drAuth.Close();
                }
                sqlConn.Close();
            }
        }

        private void FillCompanyData(bool isUpdate)
        {           
            if (txtTenderNo.Text != "")
            {
                try
                {
                    txtAddress.Text = "";                     
                    txtTel.Text = "";
                    txtMobile.Text = "";
                    if (!isUpdate)
                    {
                        txtEmail.Text = "";
                    }
                    txtCommercialDate.Text = "";
                    txtNationality.Text = "";
                    txtQataryShare.Text = "";
                    txtCRNO.Text = "";

                    using (SqlConnection sqlConn = new SqlConnection(strCon))
                    {
                        using (SqlCommand cmd = new SqlCommand())
                        {
                            sqlConn.Open();
                            string sqlQuery = null;

                            //Modified by Varun on 21/04/2014 and 18/05/2014 based on change request of modifying the email address of the company and inserting it into TenderDatesInfo table and then retrieving from the same table instead of Company table
                            // this is only in case of non-short list companies view                            

                            Boolean chkCondition = false;
                            if ((firstTimeIssue != "Issue" && firstTimeIssue != "") || (_chTypeOfShortList == 'V' || _chTypeOfShortList == 'S'))
                            {
                                //sqlQuery = "SELECT COMPANY.co_address, COMPANY.co_fax, COMPANY.co_tel,Contacts.MobilePhone,TenderDatesInfo.Company_EmailID,COMPANY.cr_expiry_date,COMPANY.nationality,COMPANY.qatari_share,COMPANY.CRNo,COMPANY.co_city,COMPANY.co_state,COMPANY.co_country,COMPANY.co_zip " +
                                //"FROM TenderDatesInfo LEFT OUTER JOIN COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id LEFT OUTER JOIN Contacts ON TenderDatesInfo.employee_id = Contacts.employee_id" +
                                //" WHERE (TenderDatesInfo.proj_id =" + _ProjId + ") AND (TenderDatesInfo.employee_id = " + cmbEmp.SelectedValue + ") AND (TenderDatesInfo.co_id = " + cmbCompany.SelectedValue + ")";
                                
                                sqlQuery = "SELECT COMPANY.co_address, COMPANY.co_fax, COMPANY.co_tel,Contacts.MobilePhone,TenderDatesInfo.Company_EmailID,COMPANY.cr_expiry_date,COMPANY.nationality,COMPANY.qatari_share,COMPANY.CRNo,COMPANY.co_city,COMPANY.co_state,COMPANY.co_country,COMPANY.co_zip,TenderDatesInfo.Doc_SubmittedBy, TenderDatesInfo.mobileNoofDoc,TenderDatesInfo.QID " +
                                "FROM TenderDatesInfo LEFT OUTER JOIN COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id LEFT OUTER JOIN Contacts ON TenderDatesInfo.employee_id = Contacts.employee_id" +
                                " WHERE (TenderDatesInfo.proj_id =" + _ProjId + ") AND (TenderDatesInfo.employee_id = " + cmbEmp.SelectedValue + ") AND (TenderDatesInfo.co_id = " + cmbCompany.SelectedValue + ")";
                            }
                            else if (cmbCompany.SelectedValue != "" && cmbCompany.SelectedValue !=null)
                            {
                                sqlQuery = "SELECT COMPANY.co_address, COMPANY.co_fax, COMPANY.co_tel,Contacts.MobilePhone,COMPANY.co_email_address,COMPANY.cr_expiry_date,COMPANY.nationality,COMPANY.qatari_share,COMPANY.CRNo,COMPANY.co_city,COMPANY.co_state,COMPANY.co_country,COMPANY.co_zip " +
                               " FROM Contacts right outer join COMPANY ON Contacts.co_id = COMPANY.co_id " +
                               " WHERE (COMPANY.co_id = " + cmbCompany.SelectedValue + ")";

                                chkCondition = true;
                            }
                            else if (cmbEmp.SelectedValue != "" && cmbEmp.SelectedValue !=null)
                            {
                                sqlQuery = "SELECT COMPANY.co_address, COMPANY.co_fax, COMPANY.co_tel,Contacts.MobilePhone,COMPANY.co_email_address,COMPANY.cr_expiry_date,COMPANY.nationality,COMPANY.qatari_share,COMPANY.CRNo,COMPANY.co_city,COMPANY.co_state,COMPANY.co_country,COMPANY.co_zip " +
                                " FROM Contacts INNER JOIN COMPANY ON Contacts.co_id = COMPANY.co_id " +
                                " WHERE (Contacts.employee_id = " + cmbEmp.SelectedValue + ")";

                                chkCondition = true;
                            }

                            if (sqlQuery!=null)
                            { 
                                cmd.Connection = sqlConn;
                                cmd.CommandText = sqlQuery;

                                using (SqlDataReader dr = cmd.ExecuteReader())
                                {
                                    while (dr.Read())
                                    {

                                        if (dr[0].ToString() != "")
                                            txtAddress.Text = dr[0].ToString() + " " + dr[9].ToString() + " " + dr[10].ToString() + " " + dr[11].ToString() + " " + dr[12].ToString();
                                        if (dr[1].ToString() != "")
                                            txtFaxNo.Text = dr[1].ToString();
                                        if (dr[2].ToString() != "")
                                            txtTel.Text = dr[2].ToString();
                                        if (dr[3].ToString() != "")
                                            txtMobile.Text = dr[3].ToString();
                                        if (!isUpdate)
                                        {
                                            if (dr[4].ToString() != "")
                                                txtEmail.Text = dr[4].ToString();
                                        }
                                        if (dr[5].ToString() != "")
                                            txtCommercialDate.Text = Convert.ToDateTime(dr[5]).ToString("dd/MMM/yyyy");
                                        if (dr[6].ToString() != "")
                                            txtNationality.Text = dr[6].ToString();
                                        if (dr[7].ToString() != "")
                                            txtQataryShare.Text = dr[7].ToString();
                                        if (dr[8].ToString() != "")
                                            txtCRNO.Text = dr[8].ToString();

                                        if (chkCondition != true)
                                        {
                                            if (dr[13].ToString() != "")
                                                txtDocCollectedBy.Text = dr[13].ToString();

                                            if (dr[14].ToString() != "")
                                                txtMobile.Text = dr[14].ToString();

                                            if (dr[15].ToString() != "")
                                                txtQID.Text = dr[15].ToString();
                                        }

                                    }
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while populating the company data, the company which you want to edit does not belongs to selected Eligible To Tender Types, Re-Check the selected Eligible To Tender Types", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                try
                {
                    //sqlConn.Open();
                    lstCRCopies.Items.Clear();
                    string sqlQuery = "SELECT crAttFile,crAttFileName FROM CRAttachment WHERE (co_id = " + cmbCompany.SelectedValue + ")";
                    sqlConn = new SqlConnection(strCon);
                    sqlConn.Open();
                    SqlCommand sqlCommand = new SqlCommand(sqlQuery, sqlConn);
                    SqlDataReader sqlReader = sqlCommand.ExecuteReader();
                    if (sqlReader.HasRows)
                    {

                        while (sqlReader.Read())
                        {
                            //docID = Convert.ToInt16(sqlReader[2].ToString());

                            ListViewItem lstItem = new ListViewItem();
                            lstItem.Text = sqlReader[1].ToString();
                            if (sqlReader[0] != DBNull.Value)
                                lstItem.Tag = (byte[])sqlReader[0];
                            lstCRCopies.Items.Add(lstItem);

                            //existedSentAttachments.Add(Convert.ToInt16(sqlReader[2].ToString()), sqlReader[1].ToString());
                        }
                    }
                    sqlReader.Close();
                    sqlCommand.Dispose();
                    //attFile = getImage(ref attFileName); 
                }
                catch (Exception ex)
                {
                    string exMsg = ex.Message;
                }
                finally
                {
                    sqlConn.Close();
                }                
               
                int cmpID = Convert.ToInt16(cmbCompany.SelectedValue);
                         get_CompanyShare_Info(cmpID);                
            }
        }
        private void get_CompanyShare_Info(int cmpID)
        {
            string sqlQuery = "Select countryName,countryShare from CompanyShare where co_id = " + cmpID + "";

            using (SqlConnection sqlConn = new SqlConnection(strCon))
            {
                using (SqlCommand cmd = new SqlCommand(sqlQuery,sqlConn))
                {
                    sqlConn.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    while (dr.Read())
                    {
                       string strcmpName =  dr[0].ToString();
                       string strShare = dr[1].ToString();

                       string res  = strcmpName + " - " + strShare;

                       txtOtherShare.Text = res + " , " +txtOtherShare.Text;
                    }
                }
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
        private void dtptenderIssue_ValueChanged(object sender, EventArgs e)
        {
            dtptenderIssue.CustomFormat = "dd/MMM/yyyy";
            txtTenderIssueDate.Text = dtptenderIssue.Value.ToString("dd/MMM/yyyy");             
        }
        private void button4_Click(object sender, EventArgs e)
        {
            if (cmbEmp.Items.Count > 0)
            {

                cmbEmp.DataSource = null;
                comCls.PopulateComboBox(cmbEmp, @"SELECT employee_id, FirstName + ' ' + LastName AS PersonName, ShortName, AuthorizedRep,co_id FROM Contacts  Where AuthorizedRep = 1 Order by FirstName", "employee_id", "PersonName");

            }
        }



        private void cmbAuthorized_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (CheckBlockListCompany() == true)
            {
                MessageBox.Show("Selected Company "  + cmbCompany.Text +  " is currently blocklisted", "Block Listed Company Info", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                cmbCompany.SelectedIndex = -1;
                return;
            }
            else
            {
                FillEmployeeData();
                FillCompanyData(false);

                if (cmbEmp.Text.Equals("Not in Database "))
                {
                    GetCompanyDetails();
                }
            }            
        }



        private Boolean CheckBlockListCompany()
        {
            Boolean blkCmp = false;
            string sqlQuery = "SELECT block_listed From COMPANY WHERE Co_id = '" + cmbCompany.SelectedValue + "'";
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    sqlConn.Open();
                    using (SqlCommand cmd = new SqlCommand())
                    { 
                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        blkCmp = Convert.ToBoolean(cmd.ExecuteScalar());                        
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while reading company blocklist, Try again.", ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            return blkCmp;
        }
        private void cmbEmp_SelectionChangeCommitted(object sender, EventArgs e)
        {
            FillCompanyData(false);

            string sqlQuery = "SELECT COMPANY.co_id, COMPANY.co_name, Contacts.employee_id " +
                                 " FROM COMPANY INNER JOIN Contacts ON COMPANY.co_id = Contacts.co_id " +
                                 " WHERE (Contacts.employee_id = " + cmbEmp.SelectedValue + ")";
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    sqlConn.Open();
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                cmbCompany.Text = dr[1].ToString();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while reading company blocklist, Try again.", ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Contains("25"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }
            frmAddCompanyInfo frmCmp = new frmAddCompanyInfo(mUserRightsColl,_userName);
            frmCmp.StartPosition = FormStartPosition.CenterScreen;
            frmCmp.ShowDialog();
        }
        private void btnCmpRef_Click(object sender, EventArgs e)
        {
            cmbCompany.DataSource = null;
            comCls.PopulateComboBox(cmbCompany, @"SELECT co_id, co_name, block_listed FROM COMPANY ORDER BY co_name", "co_id", "co_name");
        }
        private void ReadEmp_Info()
        {
            string sqlQuery = "SELECT Contacts.MobilePhone, COMPANY.co_address, Contacts.BusinessPhone, COMPANY.co_fax, Contacts.EmailAddress, COMPANY.nationality, " +
                     " COMPANY.qatari_share, COMPANY.cr_expiry_date, Contacts.employee_id,COMPANY.CRNo FROM COMPANY INNER JOIN Contacts ON COMPANY.co_id = Contacts.co_id " +
                    " WHERE (Contacts.employee_id = " + cmbEmp.SelectedValue + ")";
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    sqlConn.Open();
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                txtMobile.Text = dr[0].ToString();                                
                            }
                        }
                    }
                    sqlConn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while reading company info, Try again.", ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }        
        private void cmbEmp_TextChanged(object sender, EventArgs e)
        {
           
        }
        string[] companyInfo = new string[7];
        int receiptCounter = 0;
        private void PopulateBidderDetails()
        {
            DataRowView dataCmp = (DataRowView)cmbCompany.Items[cmbCompany.SelectedIndex];
            companyInfo[0] = dataCmp.Row.ItemArray[1].ToString();
            companyInfo[1] = txtAddress.Text;
            companyInfo[2] = txtTel.Text + " / " + txtMobile.Text;
            companyInfo[3] = txtEmail.Text;
            companyInfo[4] = txtRecptNo.Text;
            companyInfo[6] = txtDocCollectedBy.Text;    
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtDocCollectedBy.Text.Trim() == "")
            {
                MessageBox.Show("Please Enter Document Collected By");
                txtDocCollectedBy.Focus();
                return;
            }
            if (txtQID.Text.Trim() == "")
            {
                MessageBox.Show("Please Enter QID");
                txtQID.Focus();
                return;
            } 
            if (_chGetShortListed != 'Y')
            {
                if (txtTenderIssueDate.Text.Trim() == "")
                {
                    MessageBox.Show("Please Select TenderIssue Date");
                    txtTenderIssueDate.Focus();
                    return;
                }
                if (txtRecptNo.Text.Trim() == "")
                {
                    MessageBox.Show("Please Enter Receipt No");
                    txtRecptNo.Focus();
                    return;
                }                               
            }
            else
            {
                if (txtTenderIssueDate.Text.Trim() != "")
                {
                    if (txtRecptNo.Text.Trim() == "")
                    {
                        MessageBox.Show("Please Enter Receipt No");
                        txtRecptNo.Focus();
                        return;
                    }
                }
                else if (txtRecptNo.Text.Trim() != "")
                {
                    if (txtTenderIssueDate.Text.Trim() == "")
                    {
                        MessageBox.Show("Please Enter Tender Issue Date");
                        txtTenderIssueDate.Focus();
                        return;
                    }
                }                
            }

            if (cmbCompany.SelectedIndex == -1)
            {
                MessageBox.Show("Please Select Company info");
                cmbCompany.Focus();
                return;
            }
            if (cmbEmp.SelectedIndex == -1)
            {
                MessageBox.Show("Please Select Employee info");
                cmbEmp.Focus();
                return;
            }
          

            //int stgID = 2;             
            int bid_dateID = 0;            
            if (_bidDateID == 0)
            {         
                bid_dateID = comCls.GetMaxInfo("SELECT MAX(date_id) FROM TenderDatesInfo", 'Y');                
                InsertBidderInfo(bid_dateID);
                receiptCounter = comCls.GetMaxInfo("SELECT COUNT(*) FROM TenderDatesInfo WHERE (ts_tender_issue >= CONVERT(VARCHAR(20), CAST('05-01-2014' AS DATETIME), 101)) and Tender_Issued=1", 'Y');
                CommonClass.isSaved = 'Y';
                PopulateBidderDetails();
                companyInfo[5] = "-OC";                  

                DialogResult dlgResult = DialogResult.Yes;
                dlgResult = MessageBox.Show("Do you want to print the receipt for this tender?", "Print Receipt Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                
                if (dlgResult.ToString() == "Yes")
                {
                    comCls.ExportToPDF(strCon, null, null, null, txtTenderNo.Text, mProjCode, txtPrjTitle.Text, _ProjId, null, null, mTotalCirculars, null, mDocFee, tenderIssueDateTime.ToString(), 'I', 'N', null, null, 0, companyInfo, 2, "Original", 1, null, false,false);   //ref outTenderSubmissionDateAndTime,
                    companyInfo[5] = "-FC";
                    comCls.ExportToPDF(strCon, null, null, null, txtTenderNo.Text, mProjCode, txtPrjTitle.Text, _ProjId, null, null, mTotalCirculars, null, mDocFee, tenderIssueDateTime.ToString(), 'I', 'N', null, null, 0, companyInfo, 2, "Copy", 2, null, false,false);   //ref outTenderSubmissionDateAndTime,
//=======
//                    // Added by Varun on 22/072014 changed collectedBy=collectedBy/Qid based on Riyas request
//                    string collectedBy = txtDocCollectedBy.Text + "/" + txtQID.Text;
//                    comCls.ExportToPDF(strCon, null, null, null, txtTenderNo.Text, mProjCode, txtPrjTitle.Text, _ProjId, null, null, mTotalCirculars, null, mDocFee, tenderIssueDateTime.ToString(), 'I', 'N', null, null, 0, companyInfo, 2, collectedBy);
//>>>>>>> .r21
                }
                else
                {
                    return;
                }     
            }
            else
            {
                UpdateBidderInfo(_ProjId, _bidDateID, _chGetShortListed);                
                CommonClass.isSaved = 'Y';                 
            }
      

        }
        clsDatabase cls = null;
        private void GetCompanyDetails()
        {
            try
            {
                cls = new clsDatabase("");
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    sqlConn.Open();
                    string strQuery = "SELECT co_address, co_tel, co_email_address, qatari_share, CRNo, cr_expiry_date, nationality, co_id " +
                    " FROM COMPANY WHERE (co_id = " + cmbCompany.SelectedValue + ")";
                    SqlDataReader dr = cls.ExecuteReader(strQuery, sqlConn,' ');
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            if (dr[0].ToString() != "")
                                txtAddress.Text = dr[0].ToString();                             
                            if (dr[1].ToString() != "")
                                txtTel.Text = dr[1].ToString();                            
                            if (dr[2].ToString() != "")
                                txtEmail.Text = dr[2].ToString().Replace(";","; ");
                            if (dr[3].ToString() != "")
                                txtQataryShare.Text = dr[3].ToString();
                            if (dr[4].ToString() != "")
                                txtCRNO.Text = dr[4].ToString();
                            if (dr[5].ToString() != "")
                                txtCommercialDate.Text = Convert.ToDateTime(dr[5]).ToString("dd/MMM/yyyy");
                            if (dr[6].ToString() != "")
                                txtNationality.Text = dr[6].ToString(); 
                        }
                    }
                    dr.Close();
                    sqlConn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while populating the company data, the company which you want to edit does not belongs to selected Eligible To Tender Types, Re-Check the selected Eligible To Tender Types", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }        
        char lastChar = ' ';
        private void cmbCompany_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            string strToFind;

            // if first char
            if (lastChar == 0)
                strToFind = ch.ToString();
            else
                strToFind = lastChar.ToString() + ch;

            // set first char
            lastChar = ch;

            // find first item that exactly like strToFind
            int idx = cmbCompany.FindStringExact(strToFind);

            // if not found, find first item that start with strToFind
            if (idx == -1) idx = cmbCompany.FindString(strToFind);

            if (idx == -1) return;

            cmbCompany.SelectedIndex = idx;

            e.Handled = true;
        }






        void comboBox1_GotFocus(object sender, EventArgs e)
        {
            // remove last char before select new item
            lastChar = (char)0;
        }
        private void cmbEmp_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            string strToFind;

            // if first char
            if (lastChar == 0)
                strToFind = ch.ToString();
            else
                strToFind = lastChar.ToString() + ch;

            // set first char
            lastChar = ch;

            // find first item that exactly like strToFind
            int idx = cmbEmp.FindStringExact(strToFind);

            // if not found, find first item that start with strToFind
            if (idx == -1) idx = cmbEmp.FindString(strToFind);

            if (idx == -1) return;

            cmbEmp.SelectedIndex = idx;

            e.Handled = true;
        }

        // Added by Varun on 22 May 2014 for checking the duplicate receipt no.
        private void txtRecptNo_Leave(object sender, EventArgs e)
        {
            try
            {
                if (txtRecptNo.Text != "")
                {
                    cls = new clsDatabase("");
                    using (SqlConnection sqlConn = new SqlConnection(strCon))
                    {
                        sqlConn.Open();
                        string strQuery = "SELECT ts_receipt_no FROM TenderDatesInfo WHERE ts_receipt_no = '" + txtRecptNo.Text + "' and proj_id= " + _ProjId;
                        SqlDataReader dr = cls.ExecuteReader(strQuery, sqlConn, ' ');
                        if (dr.HasRows)
                        {
                            if (dr.Read())
                            {
                                MessageBox.Show("Entered Receipt No. already exists for this Project, Please enter a unique Receipt No.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                txtRecptNo.Focus();
                                return;
                            }
                        }
                        dr.Close();
                        sqlConn.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while checking the Receipt No.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        string attFileName = string.Empty;
        private void btnCRFileUpload_Click(object sender, EventArgs e)
        {
            addMultipleFiles(ref attFileName);
        }

        private void addMultipleFiles(ref string _fileName)
        {
            System.IO.FileStream fileStream = null;
            System.IO.BinaryReader binaryReader = null;             
            byte[] buffer = null;
             
            try
            {
                OpenFileDialog op1 = new OpenFileDialog();
                op1.Multiselect = true;
                op1.ShowDialog();
                long totBytes = 0;


                if (op1.FileNames.Count() != 0)
                {
                    SqlCommand sqlCommand = new SqlCommand();
                    sqlConn = new SqlConnection(strCon);
                    sqlCommand.Connection = sqlConn;
                    foreach (string s in op1.FileNames)
                    {                
                        string[] strColl = s.Split('\\');
                        string fileName = strColl[strColl.Length - 1];
                        string specialChars = "`~!@#$%^&*(){}:<>?|[];";
                        foreach (char fChar in specialChars)
                        {
                            fileName = fileName.Replace(fChar.ToString(), "");
                        }
                        fileStream = new System.IO.FileStream(s, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                        binaryReader = new System.IO.BinaryReader(fileStream);
                        totBytes = new System.IO.FileInfo(s).Length;
                        buffer = binaryReader.ReadBytes((Int32)totBytes);
                        
                        ListViewItem lstItem = new ListViewItem();
                        lstItem.Text = fileName;
                        lstItem.Tag = buffer;
                        lstCRCopies.View = View.LargeIcon;
                        lstCRCopies.Items.Add(lstItem);
                    }
                    fileStream.Close();
                    fileStream.Dispose();
                    binaryReader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error While Uploading the images, try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void btnCRRemoveAttachment_Click(object sender, EventArgs e)
        {
            if (lstCRCopies.Items.Count > 0 && lstCRCopies.SelectedIndices.Count == 0)
                MessageBox.Show("No Item is selected, Please select an Item", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
            {
                DialogResult dlgResult = DialogResult.Yes;
                dlgResult = MessageBox.Show("Are you sure you want to DELETE this Document?", "Delete Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (dlgResult.ToString() == "Yes")
                {
                    foreach (ListViewItem lstViewItem in lstCRCopies.SelectedItems)
                    {
                        lstCRCopies.Items.Remove(lstViewItem);
                    }
                }
            } 
        }

        private void lstCRCopies_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            foreach (ListViewItem item in lstCRCopies.Items)
            {
                if (item.Text.Equals(lstCRCopies.SelectedItems[0].Text))
                {
                    string sName = item.Text;
                    byte[] _image = (byte[])item.Tag;

                    byte[] byteArray = _image;
                    MemoryStream mstream = new MemoryStream();
                    mstream.Write(byteArray, 0, byteArray.Length);

                    mstream.Seek(0, SeekOrigin.Begin);
                    //Modified By Varun on 29th Jan 2014 for opening the file with a specific ext. and to preserve the real name of the file
                    string ext = sName.Substring(sName.ToString().LastIndexOf('.'));
                    StringBuilder strBuild = new StringBuilder();
                    var tempFilePath = Path.ChangeExtension(Path.GetTempFileName(), ext);
                    strBuild.Append(tempFilePath.Substring(0, tempFilePath.LastIndexOf('\\')).ToString());
                    strBuild.Append("\\" + lstCRCopies.SelectedItems[0].Text);
                    if (File.Exists(strBuild.ToString()))
                        File.Delete(strBuild.ToString());
                    File.WriteAllBytes(strBuild.ToString(), byteArray);


                    Process.Start(strBuild.ToString());

                    mstream.Close();
                    return;
                }
            }
        }
    }
}
