﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace datagrid
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection cn = new SqlConnection();
        string str = "Data Source=YASMITA-PC\\SQLSERVER2008R2;Initial Catalog=Tender;Integrated Security=True";

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'tenderDataSet.age' table. You can move, or remove it, as needed.'

            dataload();
         
        }
        public void dataload()
        {
            this.ageTableAdapter.Fill(this.tenderDataSet.age);
            cn.ConnectionString = str;
            cn.Open();

            SqlDataAdapter da1 = new SqlDataAdapter("select * from age", cn);
            DataSet ds1 = new DataSet();
            da1.Fill(ds1);

            DataGridViewComboBoxColumn cmb = new DataGridViewComboBoxColumn();
            cmb.HeaderText = "Select Data";
            cmb.Name = "cmb";
            cmb.DataSource = ds1.Tables[0].DefaultView;
            cmb.DisplayMember = "age";
            cmb.DataPropertyName = "sage";
            gview.Columns.Add(cmb);

            SqlDataAdapter da = new SqlDataAdapter("select * from student", cn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cn.Close();
            //comboBox1.Items.Clear();
            gview.DataSource = ds.Tables[0];
            ds.Tables.Clear();
            cn.Close();
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string str;

            str = "insert into student(studentname,sdob,sage)values(";
            str =str + "'"+textBox1.Text + "','"+dateTimePicker1.Value.Date + "',"+ textBox2.Text +")";
            SqlCommand cmd = new SqlCommand();
            cn.Open();
            cmd.CommandText=str;
            cmd.Connection = cn;
            int s;
            cmd.CommandType = CommandType.Text;
             cmd.ExecuteNonQuery();
             cn.Close();
             MessageBox.Show("Record Added");


             dataload();


        }
    }
}
