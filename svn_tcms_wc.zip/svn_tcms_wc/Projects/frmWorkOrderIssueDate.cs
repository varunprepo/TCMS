﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Globalization;
using System.Text.RegularExpressions;

namespace MDI_ParenrForm.Projects
{
    public partial class frmWorkOrderIssueDate : Form
    {
        string mWorkOrderID = null;         
        string mUserName = null;
        int mPrjID = 0;        
        DataGridView mDgv = null;         
        IList<string> mUserRightsColl = new List<string>();                
        string mProjectTitle = null;
        string mBidderId = null;         
        bool mIsHeadOfSection = false;         
        CommonClass cmnCls = null;
        clsCP_Stage clsForCP = null;

        public frmWorkOrderIssueDate(IList<string> userRightsColl, string userName, string[] workOrderInfo, int prjId, DataGridView dgv, bool isHeadOfSection, string projectTitle)
        {
            InitializeComponent();
            mUserRightsColl = userRightsColl;
            if (userRightsColl.Count == 0 || isHeadOfSection)
            {
                txtWOTitle.Enabled = true;
                txtWorkOrderNo.Enabled = true;                 
            }
            else
            {
                //if (userRightsColl.Contains("76"))
                //{
                //    dgvAwardedBidders.Visible = false;                    
                //}

                //if (userRightsColl.Contains("77"))
                //{
                //    dgvAwardedBidders.ReadOnly = true;
                //}
                if (!userRightsColl.Contains("83"))
                {
                    btnDeleteWO.Visible = true;
                }
                if (userRightsColl.Contains("101"))
                {
                    UnableDisableTenderingPhaseControls(false);
                }
                if (userRightsColl.Contains("102"))
                {
                    UnableDisableTenderEvalPhaseControls(false);
                }
                if (!userRightsColl.Contains("103"))
                {
                    txtWOTitle.Enabled = true;
                    txtWorkOrderNo.Enabled = true;

                    //UnableDisableContractsProcessControls(false);
                }
            }
            mUserName = userName;
            mWorkOrderID = workOrderInfo[6];
            cmnCls = new CommonClass(userName);
            txtWorkOrderNo.Text = workOrderInfo[0];
            txtWOTitle.Text = workOrderInfo[1];
            mBidderId = workOrderInfo[7].ToString();
            if (mWorkOrderID != "")
                btnUpdateAndCloseWO.Text = "Update";
            else
                btnUpdateAndCloseWO.Text = "Save";

            if (workOrderInfo[8].ToString() != "")
            {
                mskTxtWOIssueDate.Text = Convert.ToDateTime(workOrderInfo[8].ToString().Split(' ')[0]).ToString("dd/MMM/yyyy");
            }
            if (workOrderInfo[9].ToString() != "")
            {
                mskTxtWOClosingDate.Text = Convert.ToDateTime(workOrderInfo[9].ToString().Split(' ')[0]).ToString("dd/MMM/yyyy");
            }
            if (workOrderInfo[10].ToString() != "")
            {
                mskTxtTenderOpenDate.Text = Convert.ToDateTime(workOrderInfo[10].ToString().Split(' ')[0]).ToString("dd/MMM/yyyy");
            }

            //if (workOrderInfo[9].ToString() != "")
            //{
            //    mskTxtEvalReportDateSend.Text = Convert.ToDateTime(workOrderInfo[9].ToString().Split(' ')[0]).ToString("dd/MMM/yyyy");
            //}
            //txtTechnoFinTotWorkdays.Text = workOrderInfo[10].ToString();
            //txtNoOfMeetings.Text = workOrderInfo[11].ToString();
            //if (workOrderInfo[12].ToString() != "")
            //{
            //    mskTxtEvalRepDateReceived.Text = Convert.ToDateTime(workOrderInfo[12].ToString().Split(' ')[0]).ToString("dd/MMM/yyyy");
            //}
            //if (workOrderInfo[13].ToString() != "")
            //{
            //    mskTxtTenderAwardApprovalDate.Text = Convert.ToDateTime(workOrderInfo[13].ToString().Split(' ')[0]).ToString("dd/MMM/yyyy");
            //}
            //if (mUserRightsColl.Count != 0)
            //    cmbCompany.Enabled = false;

            //if (workOrderInfo[14].ToString() != "") 
            //    mskTxtWOAwardDate.Text = Convert.ToDateTime(workOrderInfo[14]).ToString("dd/MMM/yyyy");
            //if (workOrderInfo[15] != "")
            //    txtWOTenderEstimate.Text = string.Format("{0:#,##0.00}", double.Parse(workOrderInfo[15].ToString()));
            //if (workOrderInfo[15] != "")
            //    txtWOAmount.Text = string.Format("{0:#,##0.00}", double.Parse(workOrderInfo[15].ToString()));

            //if (workOrderInfo[16] != "")
            //    mskTxtRecOfAwardDoc.Text = Convert.ToDateTime(workOrderInfo[16]).ToString("dd/MMM/yyyy");

            //if (workOrderInfo[17] != "")
            //    mskTxtReqDeptStartDate.Text = Convert.ToDateTime(workOrderInfo[17]).ToString("dd/MMM/yyyy");
            //if (workOrderInfo[18] != "")
            //    mskTxtStartDateReceive.Text = Convert.ToDateTime(workOrderInfo[18]).ToString("dd/MMM/yyyy");
            //if (workOrderInfo[19] != "")
            //    mskTxtNoticeSendSignContract.Text = Convert.ToDateTime(workOrderInfo[19]).ToString("dd/MMM/yyyy");
            //if (workOrderInfo[20] != "")
            //    mskTxtDueDateOfSubPBSign.Text = Convert.ToDateTime(workOrderInfo[20]).ToString("dd/MMM/yyyy");
            
            //if (workOrderInfo[21] != "")
            //    mskTxtSentDeptForSign.Text = Convert.ToDateTime(workOrderInfo[21]).ToString("dd/MMM/yyyy");
            //if (workOrderInfo[22] != "")
            //    mskTxtRcvdDeptSentPRSDForSign.Text = Convert.ToDateTime(workOrderInfo[22]).ToString("dd/MMM/yyyy");
            //if (workOrderInfo[23] != "")
            //    mskTxtSentFinanceDeptForCommittment.Text = Convert.ToDateTime(workOrderInfo[23]).ToString("dd/MMM/yyyy");
            //if (workOrderInfo[24] != "")
            //    mskTxtRcvdFromFinanceDeptForCommittment.Text = Convert.ToDateTime(workOrderInfo[24]).ToString("dd/MMM/yyyy");
            //if (workOrderInfo[25] != "")
            //    mskTxtDistribution.Text = Convert.ToDateTime(workOrderInfo[25]).ToString("dd/MMM/yyyy");
            //if (workOrderInfo[27] != "")
            //    textRemarks.Text = workOrderInfo[27].ToString().Replace("Char(13)", "\r").Replace("Char(10)", "\n");

            //if (workOrderInfo[4] != "")
            //    txtContractNo.Text = workOrderInfo[4].ToString();
            //if (workOrderInfo[28] != "")
            //    mskTxtDateOfSignContract.Text = Convert.ToDateTime(workOrderInfo[28]).ToString("dd/MMM/yyyy");
            mPrjID = prjId;
            mDgv = dgv;
            mIsHeadOfSection = isHeadOfSection;
            mProjectTitle = projectTitle;
            
            try
            {                
                //if (cmnCls.PopulateComboBox1(cmbCompany, "SELECT CONTRACTORS.bidder_id, COMPANY.co_id, COMPANY.co_name FROM CONTRACTORS INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id WHERE (CONTRACTORS.proj_id = " + prjId + ") AND (CONTRACTORS.stage_Id = 4) " +
                //"ORDER BY COMPANY.co_name", null, null) == null)  //on CONTRACTORS.bidder_id=WorkOrderSubmissions.bidder_id                  
                //{
                //    MessageBox.Show("Error occurred while populating the Submitted Bidders", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //}               

                //if (mContractId != "")
                //{
                

                    //DataTable dtAwardedBidders = cmnCls.GetDataTable("Select COMPANY.co_id,COMPANY.CO_NAME,CONTRACTORS.cp_tender_award,CONTRACTORS.ContractAmount,cp_request_start_date,CONTRACTORS.cp_start_date_receive,CONTRACTORS.cp_notice_contractor_to_sign, " +
                    //"CONTRACTORS.cp_due_date_pb,CONTRACTORS.cp_contractor_sign,CONTRACTORS.cp_sent_dep_sign,CONTRACTORS.cp_receive_dep_sent_prsd,CONTRACTORS.cp_sent_fd_commit,CONTRACTORS.cp_receive_fd_commit,CONTRACTORS.cp_distribution,CONTRACTORS.contract_no, " +
                    //"CONTRACTORS.remarks,CONTRACTORS.cp_received_of_doc,CONTRACTORS.WOTenderEstimate FROM CONTRACTORS join COMPANY on CONTRACTORS.co_id=COMPANY.co_id where proj_id=" + prjId + " and bidder_id=" + mContractId + " AND (CONTRACTORS.stage_Id = 6) Order by COMPANY.CO_NAME", sqlCn);

                    //DataTable dtAwardedBidders = cmnCls.GetDataTable("Select COMPANY.co_id,COMPANY.CO_NAME,CONTRACTORS.cp_tender_award,CONTRACTORS.ContractAmount,cp_request_start_date,CONTRACTORS.cp_start_date_receive,CONTRACTORS.cp_notice_contractor_to_sign, " +
                    //"CONTRACTORS.cp_due_date_pb,CONTRACTORS.cp_contractor_sign,CONTRACTORS.cp_sent_dep_sign,CONTRACTORS.cp_receive_dep_sent_prsd,CONTRACTORS.cp_sent_fd_commit,CONTRACTORS.cp_receive_fd_commit,CONTRACTORS.cp_distribution,CONTRACTORS.contract_no, " +
                    //"CONTRACTORS.remarks,CONTRACTORS.cp_received_of_doc,CONTRACTORS.WOTenderEstimate FROM CONTRACTORS join COMPANY on CONTRACTORS.co_id=COMPANY.co_id where proj_id=" + prjId + " and bidder_id=" + mContractId + " AND (CONTRACTORS.stage_Id = 6) Order by COMPANY.CO_NAME", sqlCn);

                         
                        //DataTable dtSubmittedCompanies = (DataTable)cmbCompany.DataSource;
                        //DataRow[] drBiddersSubmitted = dtSubmittedCompanies.Select("Ids like '%," + coID + "%'");
                        //int rowCounter = 0;
                        //while (rowCounter < drBiddersSubmitted.Length)
                        //{
                        //    drBiddersSubmitted[rowCounter].Delete();
                        //    rowCounter++;
                        //}
                        //dtSubmittedCompanies.AcceptChanges();                      


                        //DataRow drNewSubmittedBidders = dtSubmittedCompanies.NewRow();
                        //drNewSubmittedBidders[0] = dtAwardedBidders.Rows[0]["CO_NAME"].ToString();
                        //drNewSubmittedBidders[1] = mContractId + "," + coID;
                        //dtSubmittedCompanies.Rows.Add(drNewSubmittedBidders);
                        //dtSubmittedCompanies.AcceptChanges();

                        //cmbCompany.DataSource = dtSubmittedCompanies;
                        //cmbCompany.DisplayMember = "CO_NAME";
                        //cmbCompany.ValueMember = "Ids";
                        //cmbCompany.SelectedValue = mContractId + "," + coID;

                        //dgvAwardedBidders.Columns.Clear();
                        //if (dgvCntrStage3.Columns.Count == 0)
                        //clsForCP = new clsCP_Stage(userName, isHeadOfSection);
                        //clsForCP.CreateColumnsForWOContracors(dgvAwardedBidders, prjId);
                        //clsForCP.CreateColumnsForCP_Contracors(dgvContractsTemp, _projID);
                        //FillCP_ContractsData();
                        //clsForCP.FillWOBiddersGrid(dgvAwardedBidders, prjId, mWorkOrderID);                        
                           
                    
                    

                //}

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while populating the Submitted Bidders", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
           

        }

        private void UnableDisableTenderingPhaseControls(bool isEnabled)
        {
            txtWOTitle.Enabled = isEnabled;
            txtWorkOrderNo.Enabled = isEnabled;
            mskTxtWOClosingDate.Enabled = isEnabled;
            //dtpWOClosingDate.Enabled = isEnabled;
        }

        private void UnableDisableTenderEvalPhaseControls(bool isEnabled)
        {
            mskTxtTenderOpenDate.Enabled = isEnabled;
            //dtpTenderOpenDate.Enabled = isEnabled;
            //mskTxtEvalReportDateSend.Enabled = isEnabled;
            //dtpEvalReportDateSend.Enabled = isEnabled;
            //txtTechnoFinTotWorkdays.Enabled = isEnabled;
            //mskTxtEvalRepDateReceived.Enabled = isEnabled;
            //dtpEvalRepDateReceived.Enabled = isEnabled;
            //mskTxtTenderAwardApprovalDate.Enabled = isEnabled;
            //dtpTenderAwardApprovalDate.Enabled = isEnabled;
            //txtNoOfMeetings.Enabled = isEnabled;
            //mskTxtWOAwardDate.Enabled = isEnabled;
            //dtpWOAwardDate.Enabled = isEnabled;
            //cmbCompany.Enabled = isEnabled;
            //txtWOAmount.Enabled = isEnabled;
        }

        //private void UnableDisableContractsProcessControls(bool isEnabled)
        //{
        //    mskTxtRecOfAwardDoc.Enabled = isEnabled;
        //    dtpRecOfAwardDoc.Enabled = isEnabled;
        //    mskTxtReqDeptStartDate.Enabled = isEnabled;
        //    dtpReqDeptStartDate.Enabled = isEnabled;
        //    mskTxtStartDateReceive.Enabled = isEnabled;
        //    dtpStartDateReceive.Enabled = isEnabled;
        //    mskTxtNoticeSendSignContract.Enabled = isEnabled;
        //    dtpNoticeSendSignContract.Enabled = isEnabled;
        //    mskTxtDueDateOfSubPBSign.Enabled = isEnabled;
        //    dtpDueDateOfSubPBSign.Enabled = isEnabled;
        //    mskTxtDateOfSignContract.Enabled = isEnabled;
        //    dtpDateOfSignContract.Enabled = isEnabled;
        //    mskTxtSentDeptForSign.Enabled = isEnabled;
        //    dtpSentDeptForSign.Enabled = isEnabled;
        //    mskTxtRcvdDeptSentPRSDForSign.Enabled = isEnabled;
        //    dtpRcvdDeptSentPRSDForSign.Enabled = isEnabled;
        //    mskTxtSentFinanceDeptForCommittment.Enabled = isEnabled;
        //    dtpSentFinanceDeptForCommittment.Enabled = isEnabled;
        //    mskTxtRcvdFromFinanceDeptForCommittment.Enabled = isEnabled;
        //    dtpRcvdFromFinanceDeptForCommittment.Enabled = isEnabled;
        //    mskTxtDistribution.Enabled = isEnabled;
        //    dtpDistribution.Enabled = isEnabled;
        //    txtContractNo.Enabled = isEnabled;
        //    textRemarks.Enabled = isEnabled;
        //}
        
        private void btnSaveAndCloseWO_Click(object sender, EventArgs e)
        {
            if ((!mUserRightsColl.Contains("78") && (!mUserRightsColl.Contains("75"))))
            {
                if (mUserRightsColl.Contains("46") || mUserRightsColl.Contains("48"))        // For TE and Contract Process Stage
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }

                //SaveBiddersInfo();
                //if (mWorkOrderID != "")
                //{                
                //    btnUpdateAndCloseWO.Text = "Update";
                //}
                //else
                //{
                //    btnUpdateAndCloseWO.Text = "Save";
                //}

                //if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                //{
                //    if (mUserRightsColl.Contains("77"))
                //    {
                //        MessageBox.Show("You do not have permission to Edit Contractors Details In Work Orders, Please contact the head of section", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //        return;
                //    }
                //}

                if (mskTxtWOIssueDate.Text.Trim() == "")
                {
                    MessageBox.Show("WorkOrder Issue Date cannot be left blank", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    mskTxtWOIssueDate.Focus();
                    return;
                }
                //if (txtTechnoFinTotWorkdays.Text != "")
                //{
                //    if (Convert.ToInt32(txtTechnoFinTotWorkdays.Text) > 32767)
                //    {
                //        MessageBox.Show("Techno Financial Total Workdays cannot be greater than 32767");
                //        return;
                //    }
                //}

                //if (txtNoOfMeetings.Text != "")
                //{

                //    if (Convert.ToInt32(txtNoOfMeetings.Text) > 32767)
                //    {
                //        MessageBox.Show("No. Of Meetings cannot be greater than 32767");
                //        return;
                //    }
                //}


                //if (cmbCompany.SelectedItem != null)
                //{                
                //    if (mskTxtWOAwardDate.Text != "")
                //    {
                //        if (Convert.ToDateTime(mskTxtWOAwardDate.Text).Date.CompareTo(Convert.ToDateTime(mskTxtWOClosingDate.Text).Date) < 0)
                //        {
                //            MessageBox.Show("Awarded date cannot be less than closing date, Please enter Awarded date greater than Closing Date", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //            mskTxtWOAwardDate.Focus();
                //            return;
                //        }
                //    }                 
                //}            


                //CommonClass comCls = new CommonClass(mUserName);
                //string woStatus = null;
                //int noOfDays = comCls.DateDiff(mskTxtWOClosingDate.Text);
                //if (noOfDays <= 0)
                //{
                //    if (noOfDays == 0)
                //    {
                //        if (DateTime.Now.TimeOfDay.Hours >= 13)
                //            woStatus = "Closed";
                //        else
                //            woStatus = "Open";
                //    }
                //    else
                //        woStatus = "Closed";
                //}
                //else
                //    woStatus = "Open";

                SqlConnection sqlConn = null;
                //SqlTransaction transaction = null;
                try
                {
                    using (sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                    {
                        if (sqlConn.State == ConnectionState.Closed)
                            sqlConn.Open();

                        string sqlQuery = null;
                        SqlCommand sqlCmd = null;

                        //if (btnUpdateAndCloseWO.Text == "Update")
                        //{                          

                        //sqlQuery = "update CONTRACTORS set contract_no=@contractNo,cp_request_start_date=@cpReqStartDate,cp_start_date_receive=@cpStartDateRec,cp_notice_contractor_to_sign=@cpNoticeContractorToSign," +
                        //"cp_due_date_pb=@cpDueDatePb,cp_contractor_sign=@cpContractorSign,cp_sent_dep_sign=@cpSentDepSign,cp_receive_dep_sent_prsd=@cpRecDepSentPrsd,cp_sent_fd_commit=@cpSentFdCommit,cp_receive_fd_commit=@cpRecFdCommit," +
                        //"cp_distribution=@cpDistribution,Remarks=@remarks,update_user_pc=@updateUserPC,update_date_pc=@updateDatePC,contractAmount=@workOrderAmount,cp_tender_award=@cpTenderAward,cp_received_of_doc=@cpReceivedOfDoc, " +
                        //"WOTenderEstimate=@woTenderEstimate where bidder_id=@bidderId";

                        //if (mUserRightsColl.Count == 0 || mIsHeadOfSection)
                        //{
                        //    sqlQuery = "update WorkOrders set bidder_Id=@bidderId,workOrderNo=@workOrderNo,workOrderTitle=@workOrderTitle,workOrderClosingDate=@workOrderClosingDate,workOrderStatus=@workOrderStatus,update_user=@updateUser,update_date=@updateDate," +
                        //    "tender_open_date=@tenderOpenDate,evaluation_report_datesend=@evalReportDatesend,techno_financial_totalworkdays=@technoFinancialTotWorkdays,evaluation_report_daterecvd=@evalReportDaterecvd,tender_award_approvaldate=@tenderAwardApprovaldate," +
                        //    "no_of_meetings=@noOfMeetings where workOrderId=@workOrderId";
                        //}
                        //else
                        //{
                        //    sqlQuery = "update WorkOrders set bidder_Id=@bidderId,workOrderClosingDate=@workOrderClosingDate,workOrderStatus=@workOrderStatus,update_user=@updateUser,update_date=@updateDate,tender_open_date=@tenderOpenDate,evaluation_report_datesend=@evalReportDatesend," +
                        //    "techno_financial_totalworkdays=@technoFinancialTotWorkdays,evaluation_report_daterecvd=@evalReportDaterecvd,tender_award_approvaldate=@tenderAwardApprovaldate,no_of_meetings=@noOfMeetings where workOrderId=@workOrderId";
                        //}

                        //if (mUserRightsColl.Count == 0 || mIsHeadOfSection)
                        //{
                        //    sqlQuery = "update WorkOrders set workOrderNo=@workOrderNo,workOrderTitle=@workOrderTitle,workOrderClosingDate=@workOrderClosingDate,workOrderStatus=@workOrderStatus,tender_open_date=@tenderOpenDate,evaluation_report_datesend=@evalReportDatesend," +
                        //    "techno_financial_totalworkdays=@technoFinancialTotWorkdays,evaluation_report_daterecvd=@evalReportDaterecvd," +
                        //    "tender_award_approvaldate=@tenderAwardApprovaldate,no_of_meetings=@noOfMeetings,woAwardDate=@woTenderAward,WOTenderEstimate=@woTenderEstimate where workOrderId=@workOrderId";
                            //,cp_start_date_receive=@cpStartDateRec,cp_notice_contractor_to_sign=@cpNoticeContractorToSign," +
                            //"cp_due_date_pb=@cpDueDatePb,cp_contractor_sign=@cpContractorSign,cp_sent_dep_sign=@cpSentDepSign,cp_receive_dep_sent_prsd=@cpRecDepSentPrsd,cp_sent_fd_commit=@cpSentFdCommit,cp_receive_fd_commit=@cpRecFdCommit," +
                            //"cp_distribution=@cpDistribution,Remarks=@remarks,update_user=@updateUser,update_date=@updateDate,woContractAmount=@workOrderAmount,,cp_received_of_doc=@cpReceivedOfDoc, " +
                            //",evaluation_report_daterecvd=@evalReportDaterecvd
                        //}
                        //else
                        //{
                            //sqlQuery = "update WorkOrders set workOrderClosingDate=@workOrderClosingDate,workOrderStatus=@workOrderStatus,update_user=@updateUser,update_date=@updateDate,tender_open_date=@tenderOpenDate,evaluation_report_datesend=@evalReportDatesend," +
                            //"techno_financial_totalworkdays=@technoFinancialTotWorkdays,evaluation_report_daterecvd=@evalReportDaterecvd,tender_award_approvaldate=@tenderAwardApprovaldate,no_of_meetings=@noOfMeetings,woAwardDate=@woTenderAward,WOTenderEstimate=@woTenderEstimate where workOrderId=@workOrderId";
                        if (!mUserRightsColl.Contains("103"))
                        {
                            txtWOTitle.Enabled = true;
                            txtWorkOrderNo.Enabled = true;
                            sqlQuery = "update WorkOrders set workOrderNo=@workOrderNo,workOrderTitle=@workOrderTitle,update_user=@updateUser,update_date=@updateDate,workOrderIssueDate=@workOrderIssueDate where workOrderId=@workOrderId";
                            //UnableDisableContractsProcessControls(false);
                        }
                        else
                        {
                            sqlQuery = "update WorkOrders set update_user=@updateUser,update_date=@updateDate,workOrderIssueDate=@workOrderIssueDate where workOrderId=@workOrderId";
                        }
                            
                        //}

                        //transaction = sqlConn.BeginTransaction();
                        sqlCmd = new SqlCommand(sqlQuery, sqlConn);
                        //sqlCmd.Transaction = transaction;

                        if (!mUserRightsColl.Contains("103"))
                        {
                            sqlCmd.Parameters.AddWithValue("@workOrderNo", txtWorkOrderNo.Text.Replace("'", "").Trim());
                            sqlCmd.Parameters.AddWithValue("@workOrderTitle", txtWOTitle.Text.Replace("'", "").Trim());
                        }
                        //sqlCmd.Parameters.AddWithValue("@bidderId", mContractId);                           
                        sqlCmd.Parameters.AddWithValue("@workOrderId", mWorkOrderID);
                        //if (mskTxtRecOfAwardDoc.Text.Trim() != "")
                        //    sqlCmd.Parameters.AddWithValue("@cpReceivedOfDoc", Convert.ToDateTime(mskTxtRecOfAwardDoc.Text.Trim()));
                        //else
                        //    sqlCmd.Parameters.AddWithValue("@cpReceivedOfDoc", DBNull.Value);
                        //if (mskTxtReqDeptStartDate.Text.Trim() != "")
                        //    sqlCmd.Parameters.AddWithValue("@cpReqStartDate", Convert.ToDateTime(mskTxtReqDeptStartDate.Text.Trim()));
                        //else
                        //    sqlCmd.Parameters.AddWithValue("@cpReqStartDate", DBNull.Value);
                        //if (mskTxtStartDateReceive.Text.Trim() != "")
                        //    sqlCmd.Parameters.AddWithValue("@cpStartDateRec", Convert.ToDateTime(mskTxtStartDateReceive.Text.Trim()));
                        //else
                        //    sqlCmd.Parameters.AddWithValue("@cpStartDateRec", DBNull.Value);
                        //if (mskTxtNoticeSendSignContract.Text.Trim() != "")
                        //    sqlCmd.Parameters.AddWithValue("@cpNoticeContractorToSign", Convert.ToDateTime(mskTxtNoticeSendSignContract.Text.Trim()));
                        //else
                        //    sqlCmd.Parameters.AddWithValue("@cpNoticeContractorToSign", DBNull.Value);
                        //if (mskTxtDueDateOfSubPBSign.Text.Trim() != "")
                        //    sqlCmd.Parameters.AddWithValue("@cpDueDatePb", Convert.ToDateTime(mskTxtDueDateOfSubPBSign.Text.Trim()));
                        //else
                        //    sqlCmd.Parameters.AddWithValue("@cpDueDatePb", DBNull.Value);
                        //if (mskTxtDateOfSignContract.Text.Trim() != "")
                        //    sqlCmd.Parameters.AddWithValue("@cpContractorSign", Convert.ToDateTime(mskTxtDateOfSignContract.Text.Trim()));
                        //else
                        //    sqlCmd.Parameters.AddWithValue("@cpContractorSign", DBNull.Value);
                        //if (mskTxtSentDeptForSign.Text.Trim() != "")
                        //    sqlCmd.Parameters.AddWithValue("@cpSentDepSign", Convert.ToDateTime(mskTxtSentDeptForSign.Text.Trim()));
                        //else
                        //    sqlCmd.Parameters.AddWithValue("@cpSentDepSign", DBNull.Value);
                        //if (mskTxtRcvdDeptSentPRSDForSign.Text.Trim() != "")
                        //    sqlCmd.Parameters.AddWithValue("@cpRecDepSentPrsd", Convert.ToDateTime(mskTxtRcvdDeptSentPRSDForSign.Text.Trim()));
                        //else
                        //    sqlCmd.Parameters.AddWithValue("@cpRecDepSentPrsd", DBNull.Value);
                        //if (mskTxtSentFinanceDeptForCommittment.Text.Trim() != "")
                        //    sqlCmd.Parameters.AddWithValue("@cpSentFdCommit", Convert.ToDateTime(mskTxtSentFinanceDeptForCommittment.Text.Trim()));
                        //else
                        //    sqlCmd.Parameters.AddWithValue("@cpSentFdCommit", DBNull.Value);
                        //if (mskTxtRcvdFromFinanceDeptForCommittment.Text.Trim() != "")
                        //    sqlCmd.Parameters.AddWithValue("@cpRecFdCommit", Convert.ToDateTime(mskTxtRcvdFromFinanceDeptForCommittment.Text.Trim()));
                        //else
                        //    sqlCmd.Parameters.AddWithValue("@cpRecFdCommit", DBNull.Value);
                        //if (mskTxtDistribution.Text.Trim() != "")
                        //    sqlCmd.Parameters.AddWithValue("@cpDistribution", Convert.ToDateTime(mskTxtDistribution.Text.Trim()));
                        //else
                        //    sqlCmd.Parameters.AddWithValue("@cpDistribution", DBNull.Value);
                        //if (textRemarks.Text.Trim() != "")
                        //    sqlCmd.Parameters.AddWithValue("@remarks", textRemarks.Text.Replace("\r","Char(13)").Replace("\n","Char(10)"));
                        //else
                        //    sqlCmd.Parameters.AddWithValue("@remarks", DBNull.Value);
                        //if (txtContractNo.Text.Trim() != "")
                        //    sqlCmd.Parameters.AddWithValue("@contractNo", txtContractNo.Text.Trim());
                        //else
                        //    sqlCmd.Parameters.AddWithValue("@contractNo", DBNull.Value);

                        //if (txtWOAmount.Text.Trim() != "")
                        //    sqlCmd.Parameters.AddWithValue("@workOrderAmount", txtWOAmount.Text.Trim().Replace(",", ""));
                        //else
                        //    sqlCmd.Parameters.AddWithValue("@workOrderAmount", DBNull.Value);

                        //if (txtWOTenderEstimate.Text.Trim() != "")
                        //    sqlCmd.Parameters.AddWithValue("@woTenderEstimate", txtWOTenderEstimate.Text.Trim().Replace(",", ""));
                        //else
                        //    sqlCmd.Parameters.AddWithValue("@woTenderEstimate", DBNull.Value);

                        //if (mskTxtEvalRepDateReceived.Text.Trim() != "")
                        //    sqlCmd.Parameters.AddWithValue("@evalReportDaterecvd", mskTxtEvalRepDateReceived.Text.Trim());
                        //else
                        //    sqlCmd.Parameters.AddWithValue("@evalReportDaterecvd", DBNull.Value);

                        if (mskTxtWOIssueDate.Text.Trim() != "")
                        {
                            sqlCmd.Parameters.AddWithValue("@workOrderIssueDate", Convert.ToDateTime(mskTxtWOIssueDate.Text));
                        }
                        else
                        {
                            sqlCmd.Parameters.AddWithValue("@workOrderIssueDate", DBNull.Value);
                        }

                        //if (mskTxtTenderOpenDate.Text.Trim() != "")
                        //    sqlCmd.Parameters.AddWithValue("@tenderOpenDate", Convert.ToDateTime(mskTxtTenderOpenDate.Text.Trim()));
                        //else
                        //    sqlCmd.Parameters.AddWithValue("@tenderOpenDate", DBNull.Value);

                        //if (txtNoOfMeetings.Text.Trim() != "")
                        //    sqlCmd.Parameters.AddWithValue("@noOfMeetings", txtNoOfMeetings.Text.Trim());
                        //else
                        //    sqlCmd.Parameters.AddWithValue("@noOfMeetings", DBNull.Value);

                        //if (mskTxtWOAwardDate.Text.Trim() != "")
                        //    sqlCmd.Parameters.AddWithValue("@woTenderAward", Convert.ToDateTime(mskTxtWOAwardDate.Text.Trim()));
                        //else
                        //    sqlCmd.Parameters.AddWithValue("@woTenderAward", DBNull.Value);

                        //if (mskTxtEvalReportDateSend.Text.Trim() != "")
                        //    sqlCmd.Parameters.AddWithValue("@evalReportDatesend", Convert.ToDateTime(mskTxtEvalReportDateSend.Text.Trim()));
                        //else
                        //    sqlCmd.Parameters.AddWithValue("@evalReportDatesend", DBNull.Value);

                        //if (txtTechnoFinTotWorkdays.Text.Trim() != "")
                        //    sqlCmd.Parameters.AddWithValue("@technoFinancialTotWorkdays", txtTechnoFinTotWorkdays.Text.Trim());
                        //else
                        //    sqlCmd.Parameters.AddWithValue("@technoFinancialTotWorkdays", DBNull.Value);

                        //if (mskTxtTenderAwardApprovalDate.Text.Trim() != "")
                        //    sqlCmd.Parameters.AddWithValue("@tenderAwardApprovaldate", mskTxtTenderAwardApprovalDate.Text.Trim());
                        //else
                        //    sqlCmd.Parameters.AddWithValue("@tenderAwardApprovaldate", DBNull.Value);
                        //sqlCmd.Parameters.AddWithValue("@workOrderIssueDate", woStatus);
                        //sqlCmd.Parameters.AddWithValue("@workOrderStatus", woStatus);
                        sqlCmd.Parameters.AddWithValue("@updateUser", mUserName);
                        sqlCmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);

                        sqlCmd.ExecuteNonQuery();
                        sqlCmd.Dispose();


                        MessageBox.Show(txtWorkOrderNo.Text + " Work Order details updated successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //    }
                        //    else
                        //    {
                        //        int contractorId = 0;

                        //            transaction = sqlConn.BeginTransaction();
                        //            clsCP_Stage clsCPStage = new clsCP_Stage(mUserName, mIsHeadOfSection);
                        //            contractorId = clsCPStage.maxValue("SELECT MAX(bidder_id)+1 FROM [CONTRACTORS]");

                        //            //sqlQuery = "insert into CONTRACTORS (ContractTitle,contract_status_id,contract_no,cp_request_start_date,cp_start_date_receive,cp_notice_contractor_to_sign,cp_due_date_pb,cp_contractor_sign,cp_sent_dep_sign,cp_receive_dep_sent_prsd,cp_sent_fd_commit,cp_receive_fd_commit," +
                        //            //"cp_distribution,Remarks,create_date,create_user,contractAmount,cp_tender_award,bidder_id,co_id,proj_id,stage_Id,cp_received_of_doc,WOTenderEstimate) " +
                        //            //"values (@contractTitle,@contractStatusId,@contractNo,@cpReqStartDate,@cpStartDateRec,@cpNoticeContractorToSign,@cpDueDatePb,@cpContractorSign,@cpSentDepSign,@cpRecDepSentPrsd,@cpSentFdCommit," +
                        //            //"@cpRecFdCommit,@cpDistribution,@remarks,@createdate,@createUser,@workOrderAmount,@cpTenderAward,@contractorId,@co_id,@proj_id,@stageId,@cpReceivedOfDoc,@woTenderEstimate)";

                        //            if (mUserRightsColl.Count == 0 || mIsHeadOfSection)
                        //            {
                        //                sqlQuery = "insert into WorkOrders (workOrderNo,workOrderTitle,contract_no,cp_request_start_date,cp_start_date_receive,cp_notice_contractor_to_sign,cp_due_date_pb,cp_contractor_sign,cp_sent_dep_sign,cp_receive_dep_sent_prsd,cp_sent_fd_commit,cp_receive_fd_commit," +
                        //                "cp_distribution,Remarks,create_date,create_user,woContractAmount,woAwardDate,proj_id,cp_received_of_doc,WOTenderEstimate,workOrderStatus,tender_open_date,evaluation_report_datesend,techno_financial_totalworkdays,evaluation_report_daterecvd,tender_award_approvaldate,no_of_meetings,workOrderClosingDate) " +
                        //                "values (@workOrderNo,@workOrderTitle,@contractNo,@cpReqStartDate,@cpStartDateRec,@cpNoticeContractorToSign,@cpDueDatePb,@cpContractorSign,@cpSentDepSign,@cpRecDepSentPrsd,@cpSentFdCommit," +
                        //                "@cpRecFdCommit,@cpDistribution,@remarks,@createdate,@createUser,@workOrderAmount,@woTenderAward,@proj_id,@cpReceivedOfDoc,@woTenderEstimate,@workOrderStatus,@tenderOpenDate,@evalReportDatesend,@technoFinancialTotWorkdays,@evalReportDaterecvd,@tenderAwardApprovaldate,@noOfMeetings,@workOrderClosingDate)";
                        //            }
                        //            else
                        //            {
                        //                sqlQuery = "insert into WorkOrders (workOrderNo,workOrderTitle,contract_no,cp_request_start_date,cp_start_date_receive,cp_notice_contractor_to_sign,cp_due_date_pb,cp_contractor_sign,cp_sent_dep_sign,cp_receive_dep_sent_prsd,cp_sent_fd_commit,cp_receive_fd_commit," +
                        //                "cp_distribution,Remarks,create_date,create_user,woContractAmount,woAwardDate,proj_id,cp_received_of_doc,WOTenderEstimate,workOrderStatus,tender_open_date,evaluation_report_datesend,techno_financial_totalworkdays,evaluation_report_daterecvd,tender_award_approvaldate,no_of_meetings,workOrderClosingDate) " +
                        //                "values (@workOrderNo,@workOrderTitle,@contractNo,@cpReqStartDate,@cpStartDateRec,@cpNoticeContractorToSign,@cpDueDatePb,@cpContractorSign,@cpSentDepSign,@cpRecDepSentPrsd,@cpSentFdCommit," +
                        //                "@cpRecFdCommit,@cpDistribution,@remarks,@createdate,@createUser,@workOrderAmount,@woTenderAward,@proj_id,@cpReceivedOfDoc,@woTenderEstimate,@workOrderStatus,@tenderOpenDate,@evalReportDatesend,@technoFinancialTotWorkdays,@evalReportDaterecvd,@tenderAwardApprovaldate,@noOfMeetings,@workOrderClosingDate)";
                        //            }

                        //            sqlCmd = new SqlCommand(sqlQuery, sqlConn);
                        //            sqlCmd.Transaction = transaction;


                        //            sqlCmd.Parameters.AddWithValue("@workOrderNo", txtWorkOrderNo.Text.Replace("'", "").Trim());
                        //            sqlCmd.Parameters.AddWithValue("@workOrderTitle", txtWOTitle.Text.Replace("'", "").Trim());

                        //            sqlCmd.Parameters.AddWithValue("@proj_id", mPrjID);
                        //            //sqlCmd.Parameters.AddWithValue("@contractorId", contractorId);
                        //            sqlCmd.Parameters.AddWithValue("@contractTitle", txtWOTitle.Text.Trim());
                        //            //sqlCmd.Parameters.AddWithValue("@contractStatusId", 1);
                        //            if (mskTxtRecOfAwardDoc.Text.Trim() != "")
                        //                sqlCmd.Parameters.AddWithValue("@cpReceivedOfDoc", Convert.ToDateTime(mskTxtRecOfAwardDoc.Text.Trim()));
                        //            else
                        //                sqlCmd.Parameters.AddWithValue("@cpReceivedOfDoc", DBNull.Value);
                        //            if (txtContractNo.Text.Trim() != "")
                        //                sqlCmd.Parameters.AddWithValue("@contractNo", txtContractNo.Text.Trim());
                        //            else
                        //                sqlCmd.Parameters.AddWithValue("@contractNo", DBNull.Value);
                        //            if (mskTxtReqDeptStartDate.Text.Trim() != "")
                        //                sqlCmd.Parameters.AddWithValue("@cpReqStartDate", Convert.ToDateTime(mskTxtReqDeptStartDate.Text.Trim()));
                        //            else
                        //                sqlCmd.Parameters.AddWithValue("@cpReqStartDate", DBNull.Value);
                        //            if (mskTxtStartDateReceive.Text.Trim() != "")
                        //                sqlCmd.Parameters.AddWithValue("@cpStartDateRec", Convert.ToDateTime(mskTxtStartDateReceive.Text.Trim()));
                        //            else
                        //                sqlCmd.Parameters.AddWithValue("@cpStartDateRec", DBNull.Value);
                        //            if (mskTxtNoticeSendSignContract.Text.Trim() != "")
                        //                sqlCmd.Parameters.AddWithValue("@cpNoticeContractorToSign", Convert.ToDateTime(mskTxtNoticeSendSignContract.Text.Trim()));
                        //            else
                        //                sqlCmd.Parameters.AddWithValue("@cpNoticeContractorToSign", DBNull.Value);
                        //            if (mskTxtDueDateOfSubPBSign.Text.Trim() != "")
                        //                sqlCmd.Parameters.AddWithValue("@cpDueDatePb", Convert.ToDateTime(mskTxtDueDateOfSubPBSign.Text.Trim()));
                        //            else
                        //                sqlCmd.Parameters.AddWithValue("@cpDueDatePb", DBNull.Value);
                        //            if (mskTxtDateOfSignContract.Text.Trim() != "")
                        //                sqlCmd.Parameters.AddWithValue("@cpContractorSign", Convert.ToDateTime(mskTxtDateOfSignContract.Text.Trim()));
                        //            else
                        //                sqlCmd.Parameters.AddWithValue("@cpContractorSign", DBNull.Value);
                        //            if (mskTxtSentDeptForSign.Text.Trim() != "")
                        //                sqlCmd.Parameters.AddWithValue("@cpSentDepSign", Convert.ToDateTime(mskTxtSentDeptForSign.Text.Trim()));
                        //            else
                        //                sqlCmd.Parameters.AddWithValue("@cpSentDepSign", DBNull.Value);
                        //            if (mskTxtRcvdDeptSentPRSDForSign.Text.Trim() != "")
                        //                sqlCmd.Parameters.AddWithValue("@cpRecDepSentPrsd", Convert.ToDateTime(mskTxtRcvdDeptSentPRSDForSign.Text.Trim()));
                        //            else
                        //                sqlCmd.Parameters.AddWithValue("@cpRecDepSentPrsd", DBNull.Value);
                        //            if (mskTxtSentFinanceDeptForCommittment.Text.Trim() != "")
                        //                sqlCmd.Parameters.AddWithValue("@cpSentFdCommit", Convert.ToDateTime(mskTxtSentFinanceDeptForCommittment.Text.Trim()));
                        //            else
                        //                sqlCmd.Parameters.AddWithValue("@cpSentFdCommit", DBNull.Value);
                        //            if (mskTxtRcvdFromFinanceDeptForCommittment.Text.Trim() != "")
                        //                sqlCmd.Parameters.AddWithValue("@cpRecFdCommit", Convert.ToDateTime(mskTxtRcvdFromFinanceDeptForCommittment.Text.Trim()));
                        //            else
                        //                sqlCmd.Parameters.AddWithValue("@cpRecFdCommit", DBNull.Value);
                        //            if (mskTxtDistribution.Text.Trim() != "")
                        //                sqlCmd.Parameters.AddWithValue("@cpDistribution", Convert.ToDateTime(mskTxtDistribution.Text.Trim()));
                        //            else
                        //                sqlCmd.Parameters.AddWithValue("@cpDistribution", DBNull.Value);
                        //            if (textRemarks.Text.Trim() != "")
                        //                sqlCmd.Parameters.AddWithValue("@remarks", textRemarks.Text.Trim());
                        //            else
                        //                sqlCmd.Parameters.AddWithValue("@remarks", DBNull.Value);
                        //            sqlCmd.Parameters.AddWithValue("@createUser", mUserName);
                        //            sqlCmd.Parameters.AddWithValue("@createDate", DateTime.Now);

                        //            if (txtWOAmount.Text.Trim() != "")
                        //                sqlCmd.Parameters.AddWithValue("@workOrderAmount", txtWOAmount.Text.Trim().Replace(",", ""));
                        //            else
                        //                sqlCmd.Parameters.AddWithValue("@workOrderAmount", DBNull.Value);

                        //            if (mskTxtWOAwardDate.Text.Trim() != "")
                        //                sqlCmd.Parameters.AddWithValue("@woTenderAward", Convert.ToDateTime(mskTxtWOAwardDate.Text.Trim()));
                        //            else
                        //                sqlCmd.Parameters.AddWithValue("@woTenderAward", DBNull.Value);

                        //            if (txtWOTenderEstimate.Text.Trim() != "")
                        //                sqlCmd.Parameters.AddWithValue("@woTenderEstimate", txtWOTenderEstimate.Text.Trim().Replace(",", ""));
                        //            else
                        //                sqlCmd.Parameters.AddWithValue("@woTenderEstimate", DBNull.Value);

                        //            if (mskTxtTenderOpenDate.Text.Trim() != "")
                        //                sqlCmd.Parameters.AddWithValue("@tenderOpenDate", Convert.ToDateTime(mskTxtTenderOpenDate.Text.Trim()));
                        //            else
                        //                sqlCmd.Parameters.AddWithValue("@tenderOpenDate", DBNull.Value);

                        //            if (mskTxtEvalReportDateSend.Text.Trim() != "")
                        //                sqlCmd.Parameters.AddWithValue("@evalReportDatesend", Convert.ToDateTime(mskTxtEvalReportDateSend.Text.Trim()));
                        //            else
                        //                sqlCmd.Parameters.AddWithValue("@evalReportDatesend", DBNull.Value);

                        //            if (txtTechnoFinTotWorkdays.Text.Trim() != "")
                        //                sqlCmd.Parameters.AddWithValue("@technoFinancialTotWorkdays", txtTechnoFinTotWorkdays.Text.Trim());
                        //            else
                        //                sqlCmd.Parameters.AddWithValue("@technoFinancialTotWorkdays", DBNull.Value);

                        //            if (mskTxtEvalRepDateReceived.Text.Trim() != "")
                        //                sqlCmd.Parameters.AddWithValue("@evalReportDaterecvd", mskTxtEvalRepDateReceived.Text.Trim());
                        //            else
                        //                sqlCmd.Parameters.AddWithValue("@evalReportDaterecvd", DBNull.Value);

                        //            if (txtNoOfMeetings.Text.Trim() != "")
                        //                sqlCmd.Parameters.AddWithValue("@noOfMeetings", txtNoOfMeetings.Text.Trim());
                        //            else
                        //                sqlCmd.Parameters.AddWithValue("@noOfMeetings", DBNull.Value);

                        //            if (mskTxtTenderAwardApprovalDate.Text.Trim() != "")
                        //                sqlCmd.Parameters.AddWithValue("@tenderAwardApprovaldate", mskTxtTenderAwardApprovalDate.Text.Trim());
                        //            else
                        //                sqlCmd.Parameters.AddWithValue("@tenderAwardApprovaldate", DBNull.Value);

                        //            sqlCmd.Parameters.AddWithValue("@workOrderStatus", woStatus);


                        //            sqlCmd.Parameters.AddWithValue("@workOrderClosingDate", Convert.ToDateTime(mskTxtWOClosingDate.Text));
                        //            //sqlCmd.Parameters.AddWithValue("@co_id", cmbCompany.SelectedValue.ToString().Split(',')[1]);
                        //            //sqlCmd.Parameters.AddWithValue("@stageId", 6); //When WorkOrder is Awarded to a company
                        //            sqlCmd.ExecuteNonQuery();
                        //            sqlCmd.Dispose();                     




                        //        MessageBox.Show("Awarded Contractor details inserted successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //    }
                        //    cmnCls.CreateWorkOrderGridViewColumns(mDgv, mPrjID, 0);                                                           
                        DataTable dtWO = cmnCls.GetWODataTable();
                        dtWO.Rows.Clear();
                        cmnCls.FillWorkOrders(dtWO, mPrjID); 
                    }
                }
                catch (Exception ex)
                {
                    //transaction.Rollback();
                    MessageBox.Show("Exception occurred while inserting a new Work Order", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    sqlConn.Close();
                }
            }
            else
            {
                MessageBox.Show("You do not have permission to Edit Work Order Closing or Award Dates, Please contact the Administrator of TCMS", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // Added by Varun on 21 May 2014 for checking the duplicate ContractNo.
        //public bool ValidateContractNo(string contractNo)
        //{
        //    using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
        //    {
        //        sqlConn.Open();
        //        string sqlQuery = null;
        //        //if (contractorID != "")
        //        //    sqlQuery = "select contract_no from [CONTRACTORS] where contract_no = @cntrNo and bidder_id<>" + contractorID;
        //        //else
        //            sqlQuery = "select contract_no from [CONTRACTORS] where contract_no = @cntrNo";
        //        SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
        //        contractNo = contractNo.Replace(" ", "").Replace("-", "/");
        //        while (Regex.Match(contractNo, "/0").Success)
        //            contractNo = contractNo.Replace("/0", "/");
        //        sqlCom.Parameters.AddWithValue("@cntrNo", contractNo.ToUpper());
        //        SqlDataReader sqlDtReader = sqlCom.ExecuteReader();
        //        if (sqlDtReader.HasRows)
        //        {
        //            if (sqlDtReader.Read())
        //            {
        //                MessageBox.Show("Entered Contract Number already assigned to some other Contractor, Please enter a unique Contract Number", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //                return false;
        //            }
        //        }
        //        else
        //            //txtContractNo.Text = contractNo.ToUpper();
        //        sqlDtReader.Close();
        //        sqlCom = null;
        //        sqlConn.Close();
        //    }
        //    return true;
        //}

        private void dtpReqDeptStartDate_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                //dtpReqDeptStartDate.CustomFormat = "dd/MMM/yyyy";
                //if (mskTxtRecOfAwardDoc.Text.Trim() != "" && mskTxtReqDeptStartDate.Text.Trim() == "")
                //{
                //    dtpReqDeptStartDate.Value = Convert.ToDateTime(mskTxtRecOfAwardDoc.Text.ToString()).AddDays(1);                    
                //}
                //mskTxtReqDeptStartDate.Text = dtpReqDeptStartDate.Value.ToString("dd/MMM/yyyy");
                //mskTxtReqDeptStartDate.Focus();
            }
            else
            {
                //dtpStartDateReceive.Value = dtpReqDeptStartDate.Value.AddDays(1);                
            }            
        }

        private void txtContractNo_Leave(object sender, EventArgs e)
        {
            //if (txtContractNo.Text.Trim() != "")
            //{
            //    if (ValidateContractNo(txtContractNo.Text) == false)
            //        txtContractNo.Focus();
            //}
        }

        private void dtpStartDateReceive_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                //dtpStartDateReceive.CustomFormat = "dd/MMM/yyyy";
                //if (mskTxtReqDeptStartDate.Text.Trim() != "" && mskTxtStartDateReceive.Text.Trim() == "")
                //{
                //    dtpStartDateReceive.Value = Convert.ToDateTime(mskTxtReqDeptStartDate.Text.ToString()).AddDays(1);
                 
                //}
                //mskTxtStartDateReceive.Text = dtpStartDateReceive.Value.ToString("dd/MMM/yyyy");
                //mskTxtStartDateReceive.Focus();
            }
            else
            {
                //dtpNoticeSendSignContract.Value = dtpStartDateReceive.Value.AddDays(1);
            }            
        }

        private void dtpNoticeSendSignContract_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                //dtpNoticeSendSignContract.CustomFormat = "dd/MMM/yyyy";
                //if (mskTxtStartDateReceive.Text.Trim() != "" && mskTxtNoticeSendSignContract.Text.Trim() == "")
                //{
                //    dtpNoticeSendSignContract.Value = Convert.ToDateTime(mskTxtStartDateReceive.Text.ToString()).AddDays(1);                    
                //}
                //mskTxtNoticeSendSignContract.Text = dtpNoticeSendSignContract.Value.ToString("dd/MMM/yyyy");
                //mskTxtNoticeSendSignContract.Focus();
            }
            else
            {
                //dtpDueDateOfSubPBSign.Value = dtpNoticeSendSignContract.Value.AddDays(1);
            }
            
        }

        private void dtpDueDateOfSubPBSign_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                //dtpDueDateOfSubPBSign.CustomFormat = "dd/MMM/yyyy";
                //if (mskTxtStartDateReceive.Text.Trim() != "" && mskTxtDueDateOfSubPBSign.Text.Trim() == "")
                //{
                //    dtpDueDateOfSubPBSign.Value = Convert.ToDateTime(mskTxtStartDateReceive.Text.ToString()).AddDays(1);                    
                //}
                //mskTxtDueDateOfSubPBSign.Text = dtpDueDateOfSubPBSign.Value.ToString("dd/MMM/yyyy");
                //mskTxtDueDateOfSubPBSign.Focus();
            }
            else
            {
                //dtpDateOfSignContract.Value = dtpDueDateOfSubPBSign.Value.AddDays(1);
            }
            
        }

        private void dtpDateOfSignContract_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                //dtpDateOfSignContract.CustomFormat = "dd/MMM/yyyy";
                //if (mskTxtDueDateOfSubPBSign.Text.Trim() != "" && mskTxtDateOfSignContract.Text.Trim() == "")
                //{
                //    dtpDateOfSignContract.Value = Convert.ToDateTime(mskTxtDueDateOfSubPBSign.Text.ToString()).AddDays(1);                    
                //}
                //mskTxtDateOfSignContract.Text = dtpDateOfSignContract.Value.ToString("dd/MMM/yyyy");
                //mskTxtDateOfSignContract.Focus();
            }
            else
            {
                //dtpSentDeptForSign.Value = dtpDateOfSignContract.Value.AddDays(1);
            }
            
        }

        private void dtpSentDeptForSign_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                //dtpSentDeptForSign.CustomFormat = "dd/MMM/yyyy";
                //if (mskTxtDateOfSignContract.Text.Trim() != "" && mskTxtSentDeptForSign.Text.Trim() == "")
                //{
                //    dtpSentDeptForSign.Value = Convert.ToDateTime(mskTxtDateOfSignContract.Text.ToString()).AddDays(1);                    
                //}
                //mskTxtSentDeptForSign.Text = dtpSentDeptForSign.Value.ToString("dd/MMM/yyyy");
                //mskTxtSentDeptForSign.Focus();
            }
            else
            {
                //dtpRcvdDeptSentPRSDForSign.Value = dtpSentDeptForSign.Value.AddDays(1);
            }
            
        }

        private void dtpRcvdDeptSentPRSDForSign_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                //dtpRcvdDeptSentPRSDForSign.CustomFormat = "dd/MMM/yyyy";
                //if (mskTxtSentDeptForSign.Text.Trim() != "" && mskTxtRcvdDeptSentPRSDForSign.Text.Trim() == "")
                //{
                //    dtpRcvdDeptSentPRSDForSign.Value = Convert.ToDateTime(mskTxtSentDeptForSign.Text.ToString()).AddDays(1);                    
                //}
                //mskTxtRcvdDeptSentPRSDForSign.Text = dtpRcvdDeptSentPRSDForSign.Value.ToString("dd/MMM/yyyy");
                //mskTxtRcvdDeptSentPRSDForSign.Focus();
            }
            else
            {
                //dtpSentFinanceDeptForCommittment.Value = dtpRcvdDeptSentPRSDForSign.Value.AddDays(1);
            }
            
        }

        private void dtpSentFinanceDeptForCommittment_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                //dtpSentFinanceDeptForCommittment.CustomFormat = "dd/MMM/yyyy";
                //if (mskTxtSentDeptForSign.Text.Trim() != "" && mskTxtSentFinanceDeptForCommittment.Text.Trim() == "")
                //{
                //    dtpSentFinanceDeptForCommittment.Value = Convert.ToDateTime(mskTxtSentDeptForSign.Text.ToString()).AddDays(1);                    
                //}
                //mskTxtSentFinanceDeptForCommittment.Text = dtpSentFinanceDeptForCommittment.Value.ToString("dd/MMM/yyyy");
                //mskTxtSentFinanceDeptForCommittment.Focus();
            }
            else
            {
                //dtpRcvdFromFinanceDeptForCommittment.Value = dtpSentFinanceDeptForCommittment.Value.AddDays(1);
            }
        }

        private void dtpRcvdFromFinanceDeptForCommittment_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                //dtpRcvdFromFinanceDeptForCommittment.CustomFormat = "dd/MMM/yyyy";
                //if (mskTxtSentFinanceDeptForCommittment.Text.Trim() != "" && mskTxtRcvdFromFinanceDeptForCommittment.Text.Trim() == "")
                //{
                //    dtpRcvdFromFinanceDeptForCommittment.Value = Convert.ToDateTime(mskTxtSentFinanceDeptForCommittment.Text.ToString()).AddDays(1);
                //}
                //mskTxtRcvdFromFinanceDeptForCommittment.Text = dtpRcvdFromFinanceDeptForCommittment.Value.ToString("dd/MMM/yyyy");
                //mskTxtRcvdFromFinanceDeptForCommittment.Focus();                
            }
            else
            {
                //dtpDistribution.Value = dtpRcvdFromFinanceDeptForCommittment.Value.AddDays(1);
            }
        }

        private void dtpDistribution_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                //dtpDistribution.CustomFormat = "dd/MMM/yyyy";
                //if (mskTxtRcvdFromFinanceDeptForCommittment.Text.Trim() != "" && mskTxtDistribution.Text.Trim() == "")
                //{
                //    dtpDistribution.Value = Convert.ToDateTime(mskTxtRcvdFromFinanceDeptForCommittment.Text.ToString()).AddDays(1);
                //}
                //mskTxtDistribution.Text = dtpDistribution.Value.ToString("dd/MMM/yyyy");
                //mskTxtDistribution.Focus();
            }
            else
            {
                isProgrammaticEvent = false;
            }
        }

        private void btnCancelWO_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnDeleteWO_Click(object sender, EventArgs e)
        {

        }

        private void txtContractAmt_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }

        private bool nonNumberEntered = false;
        private void ValidateNumericAndDecimalInput(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != 8 && e.KeyChar != 13) //&& e.KeyChar.ToString().Contains('.').ToString().Length>=2
            {
                nonNumberEntered = true;
            }
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                nonNumberEntered = true;
                e.Handled = true;
            }

            if (nonNumberEntered == true)
            {
                MessageBox.Show("Please enter number only...");                 
                e.Handled = true;
            }           
            nonNumberEntered = false;
        }

        private void txtContractAmt_Leave(object sender, EventArgs e)
        {
            //if(txtWOAmount.Text.Trim()!="")
            //    txtWOAmount.Text = string.Format("{0:#,##0.00}", double.Parse(txtWOAmount.Text));
        }

        public int DateDiff()
        {
            DateTime startdate;
            DateTime enddate;
            TimeSpan remaindate;

            startdate = DateTime.Parse(System.DateTime.Now.ToString()).Date;
            enddate = DateTime.Parse(mskTxtWOClosingDate.Text.ToString()).Date;

            remaindate = enddate - startdate;

            return Convert.ToInt16(remaindate.TotalDays);
        }         

        private void txtNoOfEnvelopes_KeyPress(object sender, KeyPressEventArgs e)
        {                        
                ValidateNumericAndDecimalInput(sender, e);                       
        }
        

        bool isProgrammaticEvent = false;

        public class LastDateTimePicker : DateTimePicker
        {
            protected override void OnValueChanged(EventArgs eventargs)
            {
                base.OnValueChanged(eventargs);

                LastValue = Value;
                IsProgrammaticChange = false;
            }

            public DateTime? LastValue { get; private set; }
            public bool IsProgrammaticChange { get; private set; }

            public new DateTime Value
            {
                get { return base.Value; }
                set
                {
                    IsProgrammaticChange = true;
                    base.Value = value;
                }
            }
        }

        private void cmbCompany_SelectionChangeCommitted(object sender, EventArgs e)
        {            
            //try
            //{
            //    if (cmbCompany.SelectedItem != null)
            //    {                   
            //        if (mBidderId == cmbCompany.SelectedValue.ToString().Split(',')[0])
            //            btnUpdateAndCloseWO.Text = "Update";
            //        else
            //            btnUpdateAndCloseWO.Text = "Save";
            //        PopulateContractProcessDetails(cmbCompany.SelectedValue.ToString().Split(',')[0]);
            //        txtWOAmount1.Focus();                 
                    
            //    }
            //    else
            //    {
            //        MessageBox.Show("Awarded Bidder cannot be left blank, Please select an Awarded Bidder.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //        cmbCompany.Focus();
            //    }
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show("Error occurred while checking the assignment of the selected company with a Work Order", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //}            
        }

        private void ResetWOContractProcessDetails()
        {
            //mskTxtWOAwardDate.Text = "";
            //txtWOAmount.Text = "";
            //mskTxtReqDeptStartDate.Text = "";
            //mskTxtStartDateReceive.Text = "";
          
            //mskTxtNoticeSendSignContract.Text = "";
           
            //mskTxtDueDateOfSubPBSign.Text = "";
            
            //mskTxtDateOfSignContract.Text = "";
             
            //mskTxtSentDeptForSign.Text = "";
             
            //mskTxtRcvdDeptSentPRSDForSign.Text = "";
             
            //mskTxtSentFinanceDeptForCommittment.Text = "";
             
            //mskTxtRcvdFromFinanceDeptForCommittment.Text = "";
             
            //mskTxtDistribution.Text = "";
             
            //txtContractNo.Text = "";
             
            //textRemarks.Text = "";
        }

        private void PopulateContractProcessDetails(string contractorID)
        {
            SqlConnection sqlConn = null;
            SqlDataReader sqlDtReader = null;

            try
            {
                using (sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                {
                    if (sqlConn.State == ConnectionState.Closed)
                        sqlConn.Open();

                    SqlCommand sqlCmd = new SqlCommand("select CONTRACTORS.cp_request_start_date,CONTRACTORS.cp_start_date_receive,CONTRACTORS.cp_notice_contractor_to_sign,CONTRACTORS.cp_due_date_pb,CONTRACTORS.cp_contractor_sign," +
                    "CONTRACTORS.cp_sent_dep_sign,CONTRACTORS.cp_receive_dep_sent_prsd,CONTRACTORS.cp_sent_fd_commit,CONTRACTORS.cp_receive_fd_commit,CONTRACTORS.cp_distribution,CONTRACTORS.contract_no,CONTRACTORS.remarks,CONTRACTORS.ContractAmount," +
                    "CONTRACTORS.cp_tender_award,CONTRACTORS.cp_received_of_doc from CONTRACTORS join WorkOrders on CONTRACTORS.bidder_Id=WorkOrders.bidder_Id where CONTRACTORS.bidder_id=" + contractorID + " and CONTRACTORS.stage_id=6", sqlConn);

                    sqlDtReader = sqlCmd.ExecuteReader();
                    if (sqlDtReader.Read())
                    {
                        //if (sqlDtReader["cp_tender_award"].ToString() != "")
                        //    mskTxtWOAwardDate.Text = Convert.ToDateTime(sqlDtReader["cp_tender_award"]).ToString("dd/MMM/yyyy");
                        //if (sqlDtReader["ContractAmount"].ToString() != "")
                        //    txtWOAmount.Text = string.Format("{0:#,##0.00}", double.Parse(sqlDtReader["ContractAmount"].ToString()));
                        //if (sqlDtReader["cp_received_of_doc"].ToString() != "")
                        //    mskTxtRecOfAwardDoc.Text = Convert.ToDateTime(sqlDtReader["cp_received_of_doc"]).ToString("dd/MMM/yyyy");
                        //if (sqlDtReader["cp_request_start_date"] != DBNull.Value)
                        //    mskTxtReqDeptStartDate.Text = Convert.ToDateTime(sqlDtReader["cp_request_start_date"]).ToString("dd/MMM/yyyy");
                        //if (sqlDtReader["cp_start_date_receive"] != DBNull.Value)
                        //    mskTxtStartDateReceive.Text = Convert.ToDateTime(sqlDtReader["cp_start_date_receive"]).ToString("dd/MMM/yyyy");
                        //if (sqlDtReader["cp_notice_contractor_to_sign"] != DBNull.Value)
                        //    mskTxtNoticeSendSignContract.Text = Convert.ToDateTime(sqlDtReader["cp_notice_contractor_to_sign"]).ToString("dd/MMM/yyyy");
                        //if (sqlDtReader["cp_due_date_pb"] != DBNull.Value)
                        //    mskTxtDueDateOfSubPBSign.Text = Convert.ToDateTime(sqlDtReader["cp_due_date_pb"]).ToString("dd/MMM/yyyy");
                        //if (sqlDtReader["cp_contractor_sign"] != DBNull.Value)
                        //    mskTxtDateOfSignContract.Text = Convert.ToDateTime(sqlDtReader["cp_contractor_sign"]).ToString("dd/MMM/yyyy");
                        //if (sqlDtReader["cp_sent_dep_sign"] != DBNull.Value)
                        //    mskTxtSentDeptForSign.Text = Convert.ToDateTime(sqlDtReader["cp_sent_dep_sign"]).ToString("dd/MMM/yyyy");
                        //if (sqlDtReader["cp_receive_dep_sent_prsd"] != DBNull.Value)
                        //    mskTxtRcvdDeptSentPRSDForSign.Text = Convert.ToDateTime(sqlDtReader["cp_receive_dep_sent_prsd"]).ToString("dd/MMM/yyyy");
                        //if (sqlDtReader["cp_sent_fd_commit"] != DBNull.Value)
                        //    mskTxtSentFinanceDeptForCommittment.Text = Convert.ToDateTime(sqlDtReader["cp_sent_fd_commit"]).ToString("dd/MMM/yyyy");
                        //if (sqlDtReader["cp_receive_fd_commit"] != DBNull.Value)
                        //    mskTxtRcvdFromFinanceDeptForCommittment.Text = Convert.ToDateTime(sqlDtReader["cp_receive_fd_commit"]).ToString("dd/MMM/yyyy");
                        //if (sqlDtReader["cp_distribution"] != DBNull.Value)
                        //    mskTxtDistribution.Text = Convert.ToDateTime(sqlDtReader["cp_distribution"]).ToString("dd/MMM/yyyy");
                        //if (sqlDtReader["contract_no"] != DBNull.Value)
                        //    txtContractNo.Text = sqlDtReader["contract_no"].ToString();
                        //if (sqlDtReader["remarks"] != DBNull.Value)
                        //    textRemarks.Text = sqlDtReader["remarks"].ToString();
                    }
                    else
                        ResetWOContractProcessDetails();                                             
                     
                    sqlDtReader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception occurred while displaying the Work Order", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlConn.Close();
            }
        }
         
        private void dtpWOAwardDate_ValueChanged(object sender, EventArgs e)
        {
            if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
            {
                if (mUserRightsColl.Contains("78"))
                {
                    MessageBox.Show("You do not have permission to Edit Award Date of Work Orders, Please contact the head of section", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            if (!isProgrammaticEvent)
            {
                //dtpWOAwardDate.CustomFormat = "dd/MMM/yyyy";
                //if (mskTxtTenderAwardApprovalDate.Text.Trim() != "" && mskTxtWOAwardDate.Text.Trim() == "")
                //{
                //    dtpWOAwardDate.Value = Convert.ToDateTime(mskTxtTenderAwardApprovalDate.Text.ToString()).AddDays(1);
                //}
                //mskTxtWOAwardDate.Text = dtpWOAwardDate.Value.ToString("dd/MMM/yyyy");
                //mskTxtWOAwardDate.Focus();
            }
            else
            {
                //dtpRecOfAwardDoc.Value = dtpWOAwardDate.Value.AddDays(1);                            
            }
        }

        private void txtWorkOrderNo_Leave(object sender, EventArgs e)
        {
            try
            {
                string sqlQuery = "select workOrderID from WorkOrders where workOrderNo='" + txtWorkOrderNo.Text.Replace("'","") + "'";
                SqlCommand sqlCmd = null;
                SqlDataReader sqlDtReader = null;
                using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                {
                    sqlConn.Open();
                    sqlCmd = new SqlCommand(sqlQuery, sqlConn);
                    sqlDtReader = sqlCmd.ExecuteReader();
                    if (sqlDtReader.Read())
                    {
                        MessageBox.Show("Entered Work Order Number already exists, please enter a unique Work Order Number", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtWorkOrderNo.Focus();
                    }
                    sqlDtReader.Close();
                    sqlConn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while checking existing Work Order Numbers", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }             
        }

        private void dtpRecOfAwardDoc_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                //dtpRecOfAwardDoc.CustomFormat = "dd/MMM/yyyy";
                //if (mskTxtWOAwardDate.Text.Trim() != "" && mskTxtRecOfAwardDoc.Text.Trim() == "")
                //{
                //    dtpRecOfAwardDoc.Value = Convert.ToDateTime(mskTxtWOAwardDate.Text.ToString()).AddDays(1);
                //}
                //mskTxtRecOfAwardDoc.Text = dtpRecOfAwardDoc.Value.ToString("dd/MMM/yyyy");
                //mskTxtRecOfAwardDoc.Focus();
            }
            else
            {
                //dtpReqDeptStartDate.Value = dtpRecOfAwardDoc.Value.AddDays(1);             
            }
        } 

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();   
        }
        

        private void dtpEvalReportDateSend_ValueChanged(object sender, EventArgs e)
        {

            if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
            {
                if (mUserRightsColl.Contains("75"))
                {
                    MessageBox.Show("Do not have access rights to Evaluation Report Date Send of Work Order, Please contact Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            if (!isProgrammaticEvent)
            {
                //dtpEvalReportDateSend.CustomFormat = "dd/MMM/yyyy";
                //if (mskTxtTenderOpenDate.Text.Trim() != "" && mskTxtEvalReportDateSend.Text.Trim() == "")
                //{
                //    dtpEvalReportDateSend.Value = Convert.ToDateTime(mskTxtTenderOpenDate.Text.ToString()).AddDays(1);
                //}
                //mskTxtEvalReportDateSend.Text = dtpEvalReportDateSend.Value.ToString("dd/MMM/yyyy");
                //mskTxtEvalReportDateSend.Focus();
                //isProgrammaticEvent = true;
            }
            else
            {
                //dtpEvalRepDateReceived.Value = dtpEvalReportDateSend.Value.AddDays(1);
            }           
        }     

        private void txtTechnoFinTotWorkdays_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }

        private void txtNoOfMeetings_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }

        private void dtpEvalRepDateReceived_ValueChanged(object sender, EventArgs e)
        {

            if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
            {
                if (mUserRightsColl.Contains("75"))
                {
                    MessageBox.Show("Do not have access rights to Edit Evaluation Report Date Received of Work Order, Please contact Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            
            if (!isProgrammaticEvent)
            {
                //dtpEvalRepDateReceived.CustomFormat = "dd/MMM/yyyy";
                //if (mskTxtEvalReportDateSend.Text.Trim() != "" && mskTxtEvalRepDateReceived.Text.Trim() == "")
                //{
                //    dtpEvalRepDateReceived.Value = Convert.ToDateTime(mskTxtEvalReportDateSend.Text.ToString()).AddDays(1);
                //}
                //mskTxtEvalRepDateReceived.Text = dtpEvalRepDateReceived.Value.ToString("dd/MMM/yyyy");
                //mskTxtEvalRepDateReceived.Focus();
                //isProgrammaticEvent = true;
            }
            else
            {
                //dtpTenderAwardApprovalDate.Value = dtpTenderOpenDate.Value.AddDays(1);
            }    
        }

        private void dtpTenderAwardApprovalDate_ValueChanged(object sender, EventArgs e)
        {

            if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
            {
                if (mUserRightsColl.Contains("75"))
                {
                    MessageBox.Show("Do not have access rights to Edit Tender Award Approval Date of Work Order, Please contact Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            if (!isProgrammaticEvent)
            {
                //dtpTenderAwardApprovalDate.CustomFormat = "dd/MMM/yyyy";
                //if (mskTxtEvalRepDateReceived.Text.Trim() != "" && mskTxtTenderAwardApprovalDate.Text.Trim() == "")
                //{
                //    dtpTenderAwardApprovalDate.Value = Convert.ToDateTime(mskTxtEvalRepDateReceived.Text.ToString()).AddDays(1);
                //}
                //mskTxtTenderAwardApprovalDate.Text = dtpTenderAwardApprovalDate.Value.ToString("dd/MMM/yyyy");
                //mskTxtTenderAwardApprovalDate.Focus();
                //isProgrammaticEvent = true;
            }
            else
            {
                //dtpWOAwardDate.Value = dtpTenderAwardApprovalDate.Value.AddDays(1);
            }        
        }
         

        private void SaveBiddersInfo()
        {            
            //int statusID = getStatusID(mPrjID);           // statusID = 7 for contractProcess
            if (isAwardBiddersInfoEmpty == false || !mUserRightsColl.Contains("77"))
            {
                //WOBidderInsertOrUpdate(dgvAwardedBidders, mIsHeadOfSection);
                //clsForCP = new clsCP_Stage(mUserName, mIsHeadOfSection);
                //clsForCP.CreateColumnsForCP_Contracors(dgvContractsTemp, _projID);
                //FillCP_ContractsData();
                //clsForCP.FillWOBiddersGrid(dgvAwardedBidders, mPrjID, mWorkOrderID);
            }
            else
            {
                MessageBox.Show("Awarded Bidders mandatory information cannot be left empty", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnCntrSave_Click(object sender, EventArgs e)
        {
            if (isEditingAllowed)
            {
                if (mIsHeadOfSection || !mUserRightsColl.Contains("77"))
                {
                    if (mUserRightsColl.Contains("46") || mUserRightsColl.Contains("48"))        // For TE and Contract Process Stage
                    {
                        MessageBox.Show("You have no privilege,Contact administrator");
                        return;
                    }
                    SaveBiddersInfo();
                }
                else
                {
                    MessageBox.Show("Cannot insert the information of company, Do not have privilege to insert the data, Contact Head of Section", "Information ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Cannot Save an already Awarded Bidder(company)", "Information ", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            //tabControl1.SelectedIndex = 3;


            //foreach (DataGridViewRow row in this.dgvAwardedBidders.Rows)
            //{
            //    if (row.Cells[4].Value != null)
            //    {
            //        if (row.Cells[4].Value.ToString() != "")
            //        {
            //            if (statusID < 7)
            //            {
            //                clsCP_Stage clsCP = new clsCP_Stage(mUserName, mIsHeadOfSection);
            //                clsCP.Status_Award(6, mPrjID.ToString());                                                                         
            //            }
            //        }
            //    }
            //}
        
        }

        private string FindDuplicateCoIds(string coIds)
        {
            var dictionary = new Dictionary<string, bool>();

            // Build up string into this StringBuilder.
            StringBuilder duplicateCoIds = new StringBuilder();

            // Split the input and handle spaces and punctuation.
            string[] arrayCoIds = coIds.Split(new char[] { ',' },
                StringSplitOptions.RemoveEmptyEntries);

            // Loop over each coIds
            foreach (string coId in arrayCoIds)
            {
                // If we haven't already encountered the word,
                // append it to the result.
                if (!dictionary.ContainsKey(coId))
                    dictionary.Add(coId, true);
                else
                    duplicateCoIds.Append(coId + ",");
            }
            // Return the duplicate coIds
            return duplicateCoIds.ToString();
        }

        private void WOBidderInsertOrUpdate(DataGridView dgvCntr, bool isHeadOfSection)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        if (sqlConn.State == ConnectionState.Closed)
                            sqlConn.Open();
                        cmd.Connection = sqlConn;

                        StringBuilder strCoIDs = new StringBuilder();

                        foreach (DataGridViewRow dr in dgvCntr.Rows)
                        {
                            if (dr.Cells[1].Value != null)
                            {
                                if (dr.Cells[1].Value != DBNull.Value)
                                    strCoIDs.Append(dr.Cells[1].Value.ToString() + ",");
                            }
                        }
                        string duplicateCoIds = FindDuplicateCoIds(strCoIDs.ToString());

                        foreach (DataGridViewRow dr in dgvCntr.Rows)
                        {
                            if (dr.Cells[1].Value != null) //&& dr.Cells[2].Value != null && dr.Cells[3].Value != null
                            {
                                if (dr.Cells[1].Value != DBNull.Value) //&& dr.Cells[2].Value != DBNull.Value && dr.Cells[3].Value != DBNull.Value
                                {
                                    if (dr.Cells[1].Value.ToString() != "")
                                    {
                                        //string strQuery = null;
                                        //string cmpName = null;
                                        string workOrderBidderID = null;
                                        string coID = null; 
                                        //co_Id = dr.Cells[1].Value.ToString();   //co_id                     

                                        //strQuery = "SELECT COMPANY.co_name,CONTRACTORS.bidder_id FROM CONTRACTORS INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id " +
                                        //" WHERE CONTRACTORS.proj_id=" + prjID + " and CONTRACTORS.co_id =" + co_Id;

                                        //cmd.CommandText = strQuery;
                                        //SqlDataReader sqlDtReader = cmd.ExecuteReader();


                                        //if (dr.Cells[2].Value.ToString() != "")                     // Wo_Cntr_Amnt->Wo-Work Order
                                        //    cntr_Amnt = Convert.ToDouble(dr.Cells[2].Value.ToString());

                                        //if (dr.Cells[3].Value.ToString() != "")              // Wo_Tndr_Award->Wo-Work Order
                                        //    tndr_Award_Date = Convert.ToString(dr.Cells[3].Value.ToString());
                                        //else
                                        //    tndr_Award_Date = "";

                                        //if (sqlDtReader.HasRows)
                                        //{
                                        //    sqlDtReader.Read();
                                        //    if (sqlDtReader["bidder_id"] != null)              //Bid_ID
                                        //    {
                                        //        bidID = sqlDtReader["bidder_id"].ToString();
                                        //    }

                                        //}
                                        //else
                                        //{
                                        coID = dr.Cells[1].Value.ToString();
                                        workOrderBidderID = dr.Cells[5].Value.ToString();
                                        if (workOrderBidderID=="")
                                        {
                                            if (isHeadOfSection || !mUserRightsColl.Contains("77"))
                                            {
                                                //sqlDtReader.Close();

                                                insertWOBidderDetails(cmd, coID);
                                                //isWOBidderInsertedOrUpdated = true;

                                            }
                                            else
                                            {
                                                //sqlDtReader.Close();
                                                MessageBox.Show("Cannot insert the information of company, Do not have privilege to insert the data, Contact Head of Section", "Information ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                            }
                                            //if (isHeadOfSection)
                                            //{
                                            //    updateWOBidderDetails(cmd, coID, workOrderBidderID);
                                            //    //isWOBidderInsertedOrUpdated = true;
                                            //}
                                            //else
                                            //{
                                            //    MessageBox.Show("Cannot edit the information of company which was already awarded this contract, Do not have privilege to edit or save the data, Contact Head of Section", "Information ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                            //}

                                        }                                         
                                        else
                                        {
                                            //cmpName = dr.Cells[2].Value.ToString();
                                            //if (!duplicateCoIds.Contains(dr.Cells[1].Value.ToString()))
                                            //{
                                            //    if (isHeadOfSection)
                                            //    {
                                            //        updateWOBidderDetails(cmd, coID, workOrderBidderID);
                                            //        //isWOBidderInsertedOrUpdated = true;
                                            //    }
                                            //    else
                                            //    {
                                            //        MessageBox.Show("Cannot edit the information of company which was already awarded this contract, Do not have privilege to edit or save the data, Contact Head of Section", "Information ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                            //    }

                                            //}
                                            //else
                                            //{
                                            //    if (cmpName != "")
                                            //    {
                                            //        if (isHeadOfSection)
                                            //        {
                                            //            updateWODetailsOfRepeatedBidder(cmd, coID, cmpName, workOrderBidderID);
                                            //        }
                                            //        else
                                            //        {
                                            //            MessageBox.Show("Cannot edit the information of company, Do not have privilege to edit or save the data, Contact Head of Section", "Information ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                            //        }
                                            //    }
                                            //}
                                        }
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Cannot Save or Update the Awarded Bidder information because either of Awarded Bidder (Company Name) or Awarded Amount or Date of Award is empty.", "Information ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                            }

                        }                        
                        
                        //tabControl1.TabPages[3].Focus();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the Contracts records, Try again.", ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void updateWODetailsOfRepeatedBidder(SqlCommand cmd, string coId, string compName, string workOrderBidderID)
        {
            DialogResult dlgResult = DialogResult.No;
            dlgResult = MessageBox.Show(compName + " was already awarded this contract, Click Yes if you want to update the information", "Update Confirmation ", MessageBoxButtons.YesNo);

            if (dlgResult.ToString() == "Yes")
            {
                updateWOBidderDetails(cmd, coId, workOrderBidderID);
                //isInsertedOrUpdated = true;
            }
        }

        private int updateWOBidderDetails(SqlCommand cmd, string coID, string workOrderBidderID)
        {
            //cmd.CommandText = @"Update [WorkOrderSuccessfulBidders] set woContractAmount = @woCntrAmount,update_date=@update_date,update_user =@update_user, woAwardDate = @woAwardDate " +
            //",co_id=@coId where workOrderID=@workOrderID and workOrderBidderID=@workOrderBidderID";
            //cmd.CommandText = @"Update [WorkOrderSuccessfulBidders] set update_date=@update_date,update_user=@update_user,co_id=@coId,proj_Id=@projId,woContractAmount=@woContractAmount,cp_received_of_doc=@cpReceivedofDoc," +
            //"cp_request_start_date=@cpRequestStartDate,cp_start_date_receive=@cpStartDateReceive,cp_notice_contractor_to_sign=@cpNoticeContractorToSign,cp_due_date_pb=@cpDueDatePb,cp_sent_dep_sign=@cpSentDepSign,cp_receive_dep_sent_prsd=@cpReceiveDepSentPrsd, "+
            //"cp_sent_fd_commit=@cpSentFdCommit,cp_receive_fd_commit=@cpReceiveFdCommit,cp_distribution=@cpDistribution,remarks=@remarks,contract_no=@contractNo,cp_contractor_sign=@cpContractorSign where workOrderBidderID=@workOrderBidderID";

            cmd.CommandText = @"Update [WorkOrderSuccessfulBidders] set update_date=@update_date,update_user=@update_user,co_id=@coId,proj_Id=@projId where workOrderBidderID=@workOrderBidderID";
            cmd.Parameters.AddWithValue("@update_date", DateTime.Now.ToString());
            cmd.Parameters.AddWithValue("@update_user", mUserName);  //ContractAmount
            cmd.Parameters.AddWithValue("@coId", coID);            
            cmd.Parameters.AddWithValue("@projId", mPrjID);
            cmd.Parameters.AddWithValue("@workOrderBidderID", workOrderBidderID);
            //cmd.Parameters.AddWithValue("@cmpID", coID);

            //if (awardedAmount != 0)
            //    cmd.Parameters.AddWithValue("@woAmount", awardedAmount);
            //else
            //    cmd.Parameters.AddWithValue("@woAmount", DBNull.Value);

            
            //cmd.Parameters.AddWithValue("@workOrderID", mWorkOrderID);
            //if (tndrAwardDate != "")
            //    cmd.Parameters.AddWithValue("@woAwardDate", Convert.ToDateTime(tndrAwardDate));    //CntrAward
            //else
            //    cmd.Parameters.AddWithValue("@woAwardDate", DBNull.Value);

            

            //if (txtWOAmount.Text != "")
            //{
            //    cmd.Parameters.AddWithValue("@woContractAmount", double.Parse(txtWOAmount.Text));               
            //}
            //else
            //{
            //    cmd.Parameters.AddWithValue("@woContractAmount", DBNull.Value);  
            //}

            //if (mskTxtRecOfAwardDoc.Text != "")
            //{
            //    cmd.Parameters.AddWithValue("@cpReceivedofDoc", Convert.ToDateTime(mskTxtRecOfAwardDoc.Text).ToString("dd/MMM/yyyy"));                   
            //}
            //else
            //{
            //    cmd.Parameters.AddWithValue("@cpReceivedofDoc", DBNull.Value);  
            //}

            //if (mskTxtReqDeptStartDate.Text != "")
            //{
            //    cmd.Parameters.AddWithValue("@cpRequestStartDate", Convert.ToDateTime(mskTxtReqDeptStartDate.Text).ToString("dd/MMM/yyyy"));                   
            //}
            //else
            //{
            //    cmd.Parameters.AddWithValue("@cpRequestStartDate", DBNull.Value);  
            //}

            //if (mskTxtStartDateReceive.Text != "")
            //{
            //    cmd.Parameters.AddWithValue("@cpStartDateReceive", Convert.ToDateTime(mskTxtStartDateReceive.Text).ToString("dd/MMM/yyyy"));                   
            //}
            //else
            //{
            //    cmd.Parameters.AddWithValue("@cpStartDateReceive", DBNull.Value);  
            //}
            
            //if (mskTxtNoticeSendSignContract.Text != "")
            //{
            //    cmd.Parameters.AddWithValue("@cpNoticeContractorToSign", Convert.ToDateTime(mskTxtNoticeSendSignContract.Text).ToString("dd/MMM/yyyy"));
            //}
            //else
            //{
            //    cmd.Parameters.AddWithValue("@cpNoticeContractorToSign", DBNull.Value);  
            //}

            //if (mskTxtDueDateOfSubPBSign.Text != "")
            //{
            //    cmd.Parameters.AddWithValue("@cpDueDatePb", Convert.ToDateTime(mskTxtDueDateOfSubPBSign.Text).ToString("dd/MMM/yyyy"));
            //}
            //else
            //{
            //    cmd.Parameters.AddWithValue("@cpDueDatePb", DBNull.Value);  
            //}

            //if (mskTxtSentDeptForSign.Text != "")
            //{
            //    cmd.Parameters.AddWithValue("@cpSentDepSign", Convert.ToDateTime(mskTxtSentDeptForSign.Text).ToString("dd/MMM/yyyy"));
            //}
            //else
            //{
            //    cmd.Parameters.AddWithValue("@cpSentDepSign", DBNull.Value);  
            //}

            //if (mskTxtRcvdDeptSentPRSDForSign.Text != "")
            //{
            //    cmd.Parameters.AddWithValue("@cpReceiveDepSentPrsd", Convert.ToDateTime(mskTxtRcvdDeptSentPRSDForSign.Text).ToString("dd/MMM/yyyy"));
            //}
            //else
            //{
            //    cmd.Parameters.AddWithValue("@cpReceiveDepSentPrsd", DBNull.Value);  
            //}

            //if (mskTxtSentFinanceDeptForCommittment.Text != "")
            //{
            //    cmd.Parameters.AddWithValue("@cpSentFdCommit", Convert.ToDateTime(mskTxtSentFinanceDeptForCommittment.Text).ToString("dd/MMM/yyyy"));
            //}
            //else
            //{
            //    cmd.Parameters.AddWithValue("@cpSentFdCommit", DBNull.Value);  
            //}

            //if (mskTxtRcvdFromFinanceDeptForCommittment.Text != "")
            //{
            //    cmd.Parameters.AddWithValue("@cpReceiveFdCommit", Convert.ToDateTime(mskTxtRcvdFromFinanceDeptForCommittment.Text).ToString("dd/MMM/yyyy"));
            //}
            //else
            //{
            //    cmd.Parameters.AddWithValue("@cpReceiveFdCommit", DBNull.Value);  
            //}

            //if (mskTxtDistribution.Text != "")
            //{
            //    cmd.Parameters.AddWithValue("@cpDistribution", Convert.ToDateTime(mskTxtDistribution.Text).ToString("dd/MMM/yyyy"));
            //}
            //else
            //{
            //    cmd.Parameters.AddWithValue("@cpDistribution", DBNull.Value);  
            //}                       
            
            //if (textRemarks.Text != "")
            //{
            //    cmd.Parameters.AddWithValue("@remarks", textRemarks.Text.Replace("Char(13)", "\r").Replace("Char(10)", "\n"));
            //}
            //else
            //{
            //    cmd.Parameters.AddWithValue("@remarks", DBNull.Value);  
            //} 

            //if (txtContractNo.Text != "")
            //{
            //    cmd.Parameters.AddWithValue("@contractNo", txtContractNo.Text);
            //}
            //else
            //{
            //    cmd.Parameters.AddWithValue("@contractNo", DBNull.Value);  
            //}             
            
            //if (mskTxtDateOfSignContract.Text  != "")
            //{
            //    cmd.Parameters.AddWithValue("@cpContractorSign", mskTxtDateOfSignContract.Text);
            //}
            //else
            //{
            //    cmd.Parameters.AddWithValue("@cpContractorSign", DBNull.Value);  
            //}                
            //cmd.Parameters.AddWithValue("@workOrderBidderID",workOrderBidderID);
            int updated = cmd.ExecuteNonQuery();
            cmd.Parameters.Clear();
            return updated;

        }

        private void insertWOBidderDetails(SqlCommand cmd, string coID)
        {
            //cmd.CommandText = @"insert into WorkOrderSuccessfulBidders(woContractAmount,create_user,create_date,woAwardDate,co_id,proj_id,workOrderID) values(@woAmount,@createUser,@createDate,@woAwardDate,@coId,@projId,@workOrderID)";
            //,workOrderID,woContractAmount,cp_received_of_doc,cp_request_start_date,cp_start_date_receive,cp_notice_contractor_to_sign,cp_due_date_pb," +
            //"cp_sent_dep_sign,cp_receive_dep_sent_prsd,cp_sent_fd_commit,cp_receive_fd_commit,cp_distribution,remarks,contract_no,cp_contractor_sign
            //"@cpReceiveDepSentPrsd,@cpSentFdCommit,@cpReceiveFdCommit,@cpDistribution,@remarks,@contractNo,@cpContractorSign
            //,@workOrderID,@woContractAmount,@cpReceivedofDoc,@cpRequestStartDate,@cpStartDateReceive,@cpNoticeContractorToSign,@cpDueDatePb,@cpSentDepSign,
            cmd.CommandText = @"insert into WorkOrderSuccessfulBidders(create_user,create_date,co_id,proj_id,workOrderID) values(@createUser,@createDate,@coId,@projId,@workOrderID)";
            cmd.Parameters.AddWithValue("@createDate", DateTime.Now.ToString());
            cmd.Parameters.AddWithValue("@createUser", mUserName);  //ContractAmount
            cmd.Parameters.AddWithValue("@coId", coID); //maxValue("SELECT MAX(bidder_id)+1 FROM [CONTRACTORS]")
            cmd.Parameters.AddWithValue("@projId", mPrjID);

            //cmd.Parameters.AddWithValue("@cmpID", coID);

            //if (awardedAmount != 0)
            //    cmd.Parameters.AddWithValue("@woAmount", awardedAmount);
            //else
            //    cmd.Parameters.AddWithValue("@woAmount", DBNull.Value);

            
            cmd.Parameters.AddWithValue("@workOrderID", mWorkOrderID);
            //if (tndrAwardDate != "")
            //    cmd.Parameters.AddWithValue("@woAwardDate", Convert.ToDateTime(tndrAwardDate));    //CntrAward
            //else
            //    cmd.Parameters.AddWithValue("@woAwardDate", DBNull.Value);

            

                          

            int inserted = cmd.ExecuteNonQuery();
            cmd.Parameters.Clear();

        }

        private int getStatusID(int projID)
        {
            string strQuery = "SELECT Tender_Status_id FROM projects WHERE (proj_id = " + projID + ")";
            int sttID = 0;
            using (SqlConnection sqlCn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                    {
                        if (sqlDr.HasRows)
                        {
                            while (sqlDr.Read())
                            {
                                sttID = Convert.ToInt32(sqlDr[0].ToString());
                            }
                        }
                    }
                }
                sqlCn.Close();
            }
            return sttID;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (mIsHeadOfSection || !mUserRightsColl.Contains("77"))
            {
                if (mUserRightsColl.Contains("46") || mUserRightsColl.Contains("48")) // For TE and Contract Process Stage
                {
                    MessageBox.Show("You have no privilege, Contact administrator");
                    return;
                }

                int iCnt = 0;
                //for (int iCounter = 0; iCounter < dgvAwardedBidders.RowCount; iCounter++)
                //{
                //    DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgvAwardedBidders.Rows[iCounter].Cells[0];
                //    if (chkactive.Value != null)
                //    {
                //        if (chkactive.Value.ToString().ToLower() == "true")
                //            iCnt = iCnt + 1;
                //    }
                //}
                if (iCnt > 1)
                {
                    MessageBox.Show("Please select only one record to delete", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                else if (iCnt == 0)
                {
                    MessageBox.Show("Please click the checkbox of the record you wish to delete", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                DialogResult dlgResult = DialogResult.Yes;
                dlgResult = MessageBox.Show(" Are you sure you want to DELETE the Awarded Bidder?", "Delete Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (dlgResult.ToString() == "Yes")
                {
                    clsForCP = new clsCP_Stage(mUserName, mIsHeadOfSection);
                    //for (int iCounter = 0; iCounter < dgvAwardedBidders.RowCount; iCounter++)
                    //{
                    //    DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgvAwardedBidders.Rows[iCounter].Cells[0];
                    //    if (chkactive.Value != null)
                    //    {
                    //        if (chkactive.Value.ToString().ToLower() == "true")
                    //        {
                    //            string workOrderID = dgvAwardedBidders.Rows[iCounter].Cells[3].Value.ToString();
                    //            if (workOrderID != "")
                    //            {
                    //                string sqlUpdate = "Delete from WorkOrderSuccessfulBidders where workOrderBidderID = @workOrderBidderID";
                    //                using (SqlConnection sqlCn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                    //                {
                    //                    sqlCn.Open();
                    //                    using (SqlCommand sqlCmd = new SqlCommand(sqlUpdate, sqlCn))
                    //                    {
                    //                        sqlCmd.Parameters.AddWithValue("@workOrderBidderID", workOrderID);
                    //                        sqlCmd.ExecuteNonQuery();
                    //                    }
                    //                    sqlCn.Close();
                                        
                    //                    //if (msk_dtpTE_datesent1.Text != "" & msk_dtpFE_datesentfin1.Text == "")
                    //                    //{
                    //                    //    clsForCP.FillContractsGrid_TE(dgvAwardedBidders, mPrjID, 5);
                    //                    //    isUpdated = true;
                    //                    //}
                    //                    //else if (msk_dtpTE_datesent1.Text != "" & msk_dtpFE_datesentfin1.Text != "")
                    //                    //{
                    //                    //    if (Convert.ToDateTime(msk_dtpTE_datesent1.Text.ToString()).CompareTo(Convert.ToDateTime(msk_dtpFE_datesentfin1.Text.ToString())) == 0)
                    //                    //    {
                    //                    //        clsForCP.FillContractsGrid_TE(dgvCntrStage3, _projID, 3);
                    //                    //        isUpdated = true;
                    //                    //    }
                    //                    //    else if (Convert.ToDateTime(msk_dtpTE_datesent1.Text.ToString()).CompareTo(Convert.ToDateTime(msk_dtpFE_datesentfin1.Text.ToString())) != 0)
                    //                    //    {
                    //                    //        clsForCP.FillContractsGrid_TE(dgvCntrStage3, _projID, 5);
                    //                    //        isUpdated = true;
                    //                    //    }
                    //                    //}


                    //                }
                    //            }                                 
                    //            clsForCP.FillWOBiddersGrid(dgvAwardedBidders, mPrjID, mWorkOrderID);
                    //            isEditingAllowed = true;
                    //        }
                    //    }
                    //}
                }
            }
            else
            {
                MessageBox.Show("Cannot delete the information of company, Do not have privilege to delete the data, Contact Head of Section", "Information ", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        bool isAwardBiddersInfoEmpty = false;         

        private void dgvAwardedBidders_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvAwardedBidders_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvAwardedBidders_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            //if (dgvAwardedBidders.CurrentCell.ColumnIndex == 1 && e.Control is ComboBox)
            //{
            //    ComboBox comboBox = e.Control as ComboBox;
            //    comboBox.SelectedIndexChanged -= SecondColumnComboSelectionChanged;
            //    comboBox.SelectedIndexChanged += SecondColumnComboSelectionChanged;
            //}
        }

        bool isEditingAllowed = true;
        private void SecondColumnComboSelectionChanged(object sender, EventArgs e)
        {
            //var currentcell = dgvAwardedBidders.CurrentCellAddress;
            //var sendingCB = sender as DataGridViewComboBoxEditingControl;
            ////DataGridViewComboBoxCell cmbCell = (DataGridViewComboBoxCell)dgvAwardedBidders.Rows[currentcell.Y].Cells[1];
            ////DataGridViewTextBoxCell textCell = (DataGridViewTextBoxCell)dgvAwardedBidders.Rows[currentcell.Y].Cells[1];
            ////sendingCB.EditingControlFormattedValue.ToString();
            //bool isDuplicate = false;
            //foreach (DataGridViewRow item in dgvAwardedBidders.Rows)
            //{
            //    if (item.Cells[1].FormattedValue.ToString() == sendingCB.EditingControlFormattedValue.ToString())
            //    {
            //        MessageBox.Show("Cannot select an already Awarded Bidder(company)", "Information ", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //        isDuplicate = true;
                    
            //    }                
            //}
            //if(isDuplicate)
            //{
            //    isEditingAllowed = false;
            //}
            //else
            //{
            //    isEditingAllowed = true;
            //}

            //cmbCell.Value = ;
            //try
            //{

            //    if (sendingCB.SelectedValue!=null)
            //    {
            //        if (sendingCB.SelectedValue is int)
            //        {
                        //if (textCell.Value.ToString() != "")
                        //{
                        //    using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                        //    {
                        //        if (sqlConn.State == ConnectionState.Closed)
                        //            sqlConn.Open();

                        //        string sqlQuery = null;
                        //        SqlCommand sqlCmd = null;
                        //        sqlQuery = "SELECT woContractAmount,cp_received_of_doc,cp_request_start_date,cp_start_date_receive,cp_notice_contractor_to_sign,cp_due_date_pb,cp_sent_dep_sign,cp_receive_dep_sent_prsd," +
                        //        "cp_sent_fd_commit,cp_receive_fd_commit,cp_distribution,remarks,contract_no,cp_contractor_sign from WorkOrderSuccessfulBidders where workOrderBidderID = " + textCell.Value + " and co_id=" + sendingCB.SelectedValue;
                        //        sqlCmd = new SqlCommand(sqlQuery, sqlConn);
                        //        SqlDataReader sqlReader = sqlCmd.ExecuteReader();
                        //        if (sqlReader.HasRows)
                        //        {
                        //            sqlReader.Read();
                        //            //if (sqlReader["woContractAmount"].ToString() != "")
                        //            //    txtWOAmount.Text = string.Format("{0:#,##0.00}", double.Parse(sqlReader["woContractAmount"].ToString()));
                        //            //else
                        //            //    txtWOAmount.Text = "";

                        //            //if (sqlReader["cp_received_of_doc"].ToString() != "")
                        //            //    mskTxtRecOfAwardDoc.Text = Convert.ToDateTime(sqlReader["cp_received_of_doc"]).ToString("dd/MMM/yyyy");
                        //            //else
                        //            //    mskTxtRecOfAwardDoc.Text = "";
                        //            //if (sqlReader["cp_request_start_date"].ToString() != "")
                        //            //    mskTxtReqDeptStartDate.Text = Convert.ToDateTime(sqlReader["cp_request_start_date"]).ToString("dd/MMM/yyyy");
                        //            //else
                        //            //    mskTxtReqDeptStartDate.Text = "";
                        //            //if (sqlReader["cp_start_date_receive"].ToString() != "")
                        //            //    mskTxtStartDateReceive.Text = Convert.ToDateTime(sqlReader["cp_start_date_receive"]).ToString("dd/MMM/yyyy");
                        //            //else
                        //            //    mskTxtStartDateReceive.Text = "";
                        //            //if (sqlReader["cp_notice_contractor_to_sign"].ToString() != "")
                        //            //    mskTxtNoticeSendSignContract.Text = Convert.ToDateTime(sqlReader["cp_notice_contractor_to_sign"]).ToString("dd/MMM/yyyy");
                        //            //else
                        //            //    mskTxtNoticeSendSignContract.Text = "";
                        //            //if (sqlReader["cp_due_date_pb"].ToString() != "")
                        //            //    mskTxtDueDateOfSubPBSign.Text = Convert.ToDateTime(sqlReader["cp_due_date_pb"]).ToString("dd/MMM/yyyy");
                        //            //else
                        //            //    mskTxtDueDateOfSubPBSign.Text = "";
                        //            //if (sqlReader["cp_sent_dep_sign"].ToString() != "")
                        //            //    mskTxtSentDeptForSign.Text = Convert.ToDateTime(sqlReader["cp_sent_dep_sign"]).ToString("dd/MMM/yyyy");
                        //            //else
                        //            //    mskTxtSentDeptForSign.Text = "";
                        //            //if (sqlReader["cp_receive_dep_sent_prsd"].ToString() != "")
                        //            //    mskTxtRcvdDeptSentPRSDForSign.Text = Convert.ToDateTime(sqlReader["cp_receive_dep_sent_prsd"]).ToString("dd/MMM/yyyy");
                        //            //else
                        //            //    mskTxtRcvdDeptSentPRSDForSign.Text = "";
                        //            //if (sqlReader["cp_sent_fd_commit"].ToString() != "")
                        //            //    mskTxtSentFinanceDeptForCommittment.Text = Convert.ToDateTime(sqlReader["cp_sent_fd_commit"]).ToString("dd/MMM/yyyy");
                        //            //else
                        //            //    mskTxtSentFinanceDeptForCommittment.Text = "";
                        //            //if (sqlReader["cp_receive_fd_commit"].ToString() != "")
                        //            //    mskTxtRcvdFromFinanceDeptForCommittment.Text = Convert.ToDateTime(sqlReader["cp_receive_fd_commit"]).ToString("dd/MMM/yyyy");
                        //            //else
                        //            //    mskTxtRcvdFromFinanceDeptForCommittment.Text = "";
                        //            //if (sqlReader["cp_distribution"].ToString() != "")
                        //            //    mskTxtDistribution.Text = Convert.ToDateTime(sqlReader["cp_distribution"]).ToString("dd/MMM/yyyy");
                        //            //else
                        //            //    mskTxtDistribution.Text = "";
                        //            //if (sqlReader["remarks"].ToString() != "")
                        //            //    textRemarks.Text = sqlReader["remarks"].ToString().Replace("Char(13)", "\r").Replace("Char(10)", "\n");
                        //            //else
                        //            //    textRemarks.Text = "";
                        //            //if (sqlReader["contract_no"].ToString() != "")
                        //            //    txtContractNo.Text = sqlReader["contract_no"].ToString();
                        //            //else
                        //            //    txtContractNo.Text = "";
                        //            //if (sqlReader["cp_contractor_sign"].ToString() != "")
                        //            //    mskTxtDateOfSignContract.Text = Convert.ToDateTime(sqlReader["cp_contractor_sign"]).ToString("dd/MMM/yyyy");
                        //            //else
                        //            //    mskTxtDateOfSignContract.Text = "";
                        //        }
                        //    }
                        //}
            //        }
            //    }
            //}
            //catch(Exception ex)
            //{
            //    MessageBox.Show("Error occurred while populating the Submitted Bidders", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //}

        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (mIsHeadOfSection || !mUserRightsColl.Contains("77"))
            {
                int iCnt = 0;
                //for (int iCounter = 0; iCounter < dgvAwardedBidders.RowCount; iCounter++)
                //{
                //    DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgvAwardedBidders.Rows[iCounter].Cells[0];

                //    if (chkactive.Value != null)
                //    {
                //        if (chkactive.Value.ToString().ToLower() == "true")
                //            iCnt = iCnt + 1;
                //    }
                //}
                if (iCnt > 1)
                {
                    MessageBox.Show("Please Select Only One Record to Edit");
                    return;
                }


                string[] workOrderBidderInfo = new string[17];
                string prjCode = string.Empty;

                //for (int iCounter = 0; iCounter < dgvAwardedBidders.RowCount; iCounter++)
                //{
                //    DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgvAwardedBidders.Rows[iCounter].Cells[0];
                //    if (chkactive.Value != null)
                //    {
                //        if (chkactive.Value.ToString().ToLower() == "true")
                //        {
                //            workOrderBidderInfo[0] = dgvAwardedBidders.Rows[iCounter].Cells[1].Value.ToString();
                //            workOrderBidderInfo[1] = dgvAwardedBidders.Rows[iCounter].Cells[2].Value.ToString();
                //            workOrderBidderInfo[2] = dgvAwardedBidders.Rows[iCounter].Cells[3].Value.ToString();
                //            workOrderBidderInfo[3] = dgvAwardedBidders.Rows[iCounter].Cells[4].Value.ToString();
                //            workOrderBidderInfo[4] = dgvAwardedBidders.Rows[iCounter].Cells[5].Value.ToString();
                //            workOrderBidderInfo[5] = dgvAwardedBidders.Rows[iCounter].Cells[6].Value.ToString();
                //            workOrderBidderInfo[6] = dgvAwardedBidders.Rows[iCounter].Cells[7].Value.ToString();
                //            workOrderBidderInfo[7] = dgvAwardedBidders.Rows[iCounter].Cells[8].Value.ToString();
                //            workOrderBidderInfo[8] = dgvAwardedBidders.Rows[iCounter].Cells[9].Value.ToString();
                //            workOrderBidderInfo[9] = dgvAwardedBidders.Rows[iCounter].Cells[10].Value.ToString();
                //            workOrderBidderInfo[10] = dgvAwardedBidders.Rows[iCounter].Cells[11].Value.ToString();
                //            workOrderBidderInfo[11] = dgvAwardedBidders.Rows[iCounter].Cells[12].Value.ToString();
                //            workOrderBidderInfo[12] = dgvAwardedBidders.Rows[iCounter].Cells[13].Value.ToString();
                //            workOrderBidderInfo[13] = dgvAwardedBidders.Rows[iCounter].Cells[14].Value.ToString(); 
                //            workOrderBidderInfo[14] = dgvAwardedBidders.Rows[iCounter].Cells[15].Value.ToString();
                //            workOrderBidderInfo[15] = dgvAwardedBidders.Rows[iCounter].Cells[16].Value.ToString();
                //            workOrderBidderInfo[16] = dgvAwardedBidders.Rows[iCounter].Cells[17].Value.ToString();
                //            //workOrderBidderInfo[17] = dgvAwardedBidders.Rows[iCounter].Cells[18].Value.ToString();
                //        }
                //    }
                //}
                if (workOrderBidderInfo[0] == null)
                {
                    MessageBox.Show("Please click the checkbox to select the Bidder Information you want to View/Edit.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    // frmProjectEdit frmEditProject = new frmProjectEdit(ProjectID, prjCode, affairsName, deptName, prjTitleEn, prjTitleArb, tndrCommitte, typeOfTender, fiscalYear, typeOfCntr);
                    //frmBidderWorkOrderDetails frmWODetails = new frmBidderWorkOrderDetails(workOrderBidderInfo, mUserName, mPrjID, mWorkOrderID, mIsHeadOfSection, dgvAwardedBidders);
                    //frmWODetails.StartPosition = FormStartPosition.CenterParent;
                    //frmWODetails.ShowDialog();
                }
            }
            else
            {
                MessageBox.Show("Cannot edit the information of company, Do not have privilege to edit the data, Contact Head of Section", "Information ", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void refreshAwardedBidders_Click(object sender, EventArgs e)
        {
            //dgvAwardedBidders.Columns.Clear();
            //dgvAwardedBidders.Rows.Clear();
            //if (dgvCntrStage3.Columns.Count == 0)
            //clsForCP = new clsCP_Stage(mUserName, mIsHeadOfSection);             
            //clsForCP.CreateColumnsForCP_Contracors(dgvContractsTemp, _projID);
            //FillCP_ContractsData();
            //clsForCP.FillWOBiddersGrid(dgvAwardedBidders, mPrjID, mWorkOrderID);
        }

        private void dgvAwardedBidders_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            //if (e.ColumnIndex == 1 && e.RowIndex != (dgvAwardedBidders.Rows.Count - 1))
            //{
            //    DataGridViewComboBoxCell cell = (DataGridViewComboBoxCell)dgvAwardedBidders[e.ColumnIndex, e.RowIndex];                
            //    cell.ReadOnly = true;
            //}
            // Added by Varun on 19/Aug/20 for formatting the CalendarColumn date to blank
            DataGridView dgvWOCntr = sender as DataGridView;
            if (e.ColumnIndex == 4)
            {
                DateTime? nullable_dt = new DateTime?();
                if (dgvWOCntr.Rows[e.RowIndex].Cells[0].Value == null)
                    dgvWOCntr.Rows[e.RowIndex].Cells[4].Value = nullable_dt;                
            }           

            if (e.ColumnIndex == 3)
            {
                object val = dgvWOCntr.Rows[e.RowIndex].Cells[3].Value;
                if ((val != null) && !object.ReferenceEquals(val, DBNull.Value))
                {
                    e.Value = string.Format("{0:#,##0.00}", double.Parse(dgvWOCntr.Rows[e.RowIndex].Cells[3].Value.ToString()));//#,##0
                }
            }
        }

        private void dtpWOIssueDate_ValueChanged(object sender, EventArgs e)
        {
            dtpWOIssueDate.CustomFormat = "dd/MMM/yyyy";
            //if (mskTxtWOIssueDate.Text.Trim() != "")
            //{
            //    dtpWOIssueDate.Value = Convert.ToDateTime(mskTxtWOIssueDate.Text.ToString()); //.AddDays(1);
            //}
            mskTxtWOIssueDate.Text = dtpWOIssueDate.Value.ToString("dd/MMM/yyyy");
            mskTxtWOIssueDate.Focus();
        }

        private void btnDeleteWO_Click_1(object sender, EventArgs e)
        {
            if (mUserRightsColl.Contains("83"))
            {
                MessageBox.Show("Do not have access rights to delete Work Orders, Please contact Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            DialogResult dlgResult = DialogResult.Yes;
            dlgResult = MessageBox.Show(" Are you sure you want to DELETE the Work Order?", "Delete Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (dlgResult.ToString() == "Yes")
            {
                string sqlUpdate = "Delete from WorkOrders where workOrderID = @workOrderID";
                using (SqlConnection sqlCn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                {
                    sqlCn.Open();
                    using (SqlCommand sqlCmd = new SqlCommand(sqlUpdate, sqlCn))
                    {
                        sqlCmd.Parameters.AddWithValue("@workOrderID", mWorkOrderID);

                        if (sqlCmd.ExecuteNonQuery() == 0)
                            MessageBox.Show("Did not found Work order details. Work order details not deleted successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show("Work order details deleted successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    sqlCn.Close();
                    this.Close();
                    cmnCls.CreateWorkOrderGridViewColumns(mDgv, mPrjID, 0);
                }

            }
        }

        
    }
}
