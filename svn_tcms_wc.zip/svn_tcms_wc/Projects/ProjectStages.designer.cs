﻿namespace TenderTrackingSystem
{
    partial class ProjectStages
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            _commId = 0;
            tenderTypeId = 0;
            //bdgtEstimated = 0;
            strFiscalYr = null;
            //projCode = null;
            //projTitle = null;
            dtCreateDate = null;
            projId = 0;
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle45 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle46 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle47 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle48 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnExportToExcel = new System.Windows.Forms.Button();
            this.btnUpdateProjStatus = new System.Windows.Forms.Button();
            this.cmbTenderStatusChange = new System.Windows.Forms.ComboBox();
            this.btnBudgetRefNo = new System.Windows.Forms.Button();
            this.lblContractNoDisplay = new System.Windows.Forms.Label();
            this.lblContractNo = new System.Windows.Forms.Label();
            this.btnMinistry = new System.Windows.Forms.Button();
            this.btnBudgetRef = new System.Windows.Forms.Button();
            this.lblProjID = new System.Windows.Forms.Label();
            this.btnSaveMinistryCode = new System.Windows.Forms.Button();
            this.cmbTenderStatus = new System.Windows.Forms.ComboBox();
            this.cmbBudgetRef = new System.Windows.Forms.ComboBox();
            this.cmbMinistryCode = new System.Windows.Forms.ComboBox();
            this.txtProvisionNo = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblPrjCode = new System.Windows.Forms.Label();
            this.lblTenderNo = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtProjCode = new System.Windows.Forms.TextBox();
            this.txtTenderNo = new System.Windows.Forms.TextBox();
            this.txtproj = new System.Windows.Forms.TextBox();
            this.btnAssignTender = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.dgView = new System.Windows.Forms.DataGridView();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.pcsTabPage = new System.Windows.Forms.TabPage();
            this.label43 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.btnPC_Save = new System.Windows.Forms.Button();
            this.dgvPC_Contracts = new System.Windows.Forms.DataGridView();
            this.dgvPC = new System.Windows.Forms.DataGridView();
            this.txtPC_Remarks = new System.Windows.Forms.TextBox();
            this.txtPC_BudjetAmnt = new System.Windows.Forms.TextBox();
            this.txtPC_EstimatedAmnt = new System.Windows.Forms.TextBox();
            this.lblPc_EstAmnt = new System.Windows.Forms.Label();
            this.lblPC_bdgtAmnt = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.cpTabPage = new System.Windows.Forms.TabPage();
            this.btnWorkOrder2 = new System.Windows.Forms.Button();
            this.lblEstCostCurr = new System.Windows.Forms.Label();
            this.lblBudAmtCP = new System.Windows.Forms.Label();
            this.btnDatesExtend = new System.Windows.Forms.Button();
            this.dgvCpDataEntry = new System.Windows.Forms.DataGridView();
            this.dgvCP_Sent = new System.Windows.Forms.DataGridView();
            this.dgvCP_Rec = new System.Windows.Forms.DataGridView();
            this.btnSentCp = new System.Windows.Forms.Button();
            this.btnRecCp = new System.Windows.Forms.Button();
            this.lblCP_bdgtAmnt = new System.Windows.Forms.Label();
            this.btnCP_Save = new System.Windows.Forms.Button();
            this.lblCP_estimateAmnt = new System.Windows.Forms.Label();
            this.txtCp_EstimatedAmnt = new System.Windows.Forms.TextBox();
            this.txtCp_BudgetAmnt = new System.Windows.Forms.TextBox();
            this.dgvContracts = new System.Windows.Forms.DataGridView();
            this.teaTabPage = new System.Windows.Forms.TabPage();
            this.msk_dtpEA_closeDate_Stage2 = new System.Windows.Forms.MaskedTextBox();
            this.btnTenderSubmissionStg2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.msk_dtpFE_daterecFin2 = new System.Windows.Forms.MaskedTextBox();
            this.dtpFE_daterecFin2 = new System.Windows.Forms.DateTimePicker();
            this.txtFinEval2ProposedWorkDays = new System.Windows.Forms.TextBox();
            this.msk_dtpFE_datesentfin2 = new System.Windows.Forms.MaskedTextBox();
            this.dtpFE_datesentfin2 = new System.Windows.Forms.DateTimePicker();
            this.txtTechEval2ProposedWorkDays = new System.Windows.Forms.TextBox();
            this.msk_dtpTE_datesent2 = new System.Windows.Forms.MaskedTextBox();
            this.dtpTE_datesent2 = new System.Windows.Forms.DateTimePicker();
            this.msk_dtpTE_daterec2 = new System.Windows.Forms.MaskedTextBox();
            this.dtpTE_daterec2 = new System.Windows.Forms.DateTimePicker();
            this.btnWorkOrder = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.txtFinEval1ProposedWorkDays = new System.Windows.Forms.TextBox();
            this.lblFinEvalProposedWorkDays = new System.Windows.Forms.Label();
            this.txtTechEval1ProposedWorkDays = new System.Windows.Forms.TextBox();
            this.lblTechEvalProposedWorkDays = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.btnTenderSubmissionStage1 = new System.Windows.Forms.Button();
            this.lblEstCostCurrSymbol = new System.Windows.Forms.Label();
            this.lblBdgAmtCurrSymbol = new System.Windows.Forms.Label();
            this.btnCntrSave = new System.Windows.Forms.Button();
            this.dgvCntrStage3 = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.txtTE_remarks = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label70 = new System.Windows.Forms.Label();
            this.msk_dtpTBV_SEdate = new System.Windows.Forms.MaskedTextBox();
            this.label69 = new System.Windows.Forms.Label();
            this.msk_dtpTV_SEdate = new System.Windows.Forms.MaskedTextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.msk_dtpTBV_FEdate = new System.Windows.Forms.MaskedTextBox();
            this.label67 = new System.Windows.Forms.Label();
            this.msk_dtpTV_FEdate = new System.Windows.Forms.MaskedTextBox();
            this.label66 = new System.Windows.Forms.Label();
            this.msk_dtpTBV_OrgDate = new System.Windows.Forms.MaskedTextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.msk_dtpTV_OrgDate = new System.Windows.Forms.MaskedTextBox();
            this.dtpTBV_FEdate = new System.Windows.Forms.DateTimePicker();
            this.dtpTBV_SEdate = new System.Windows.Forms.DateTimePicker();
            this.dtpTV_SEdate = new System.Windows.Forms.DateTimePicker();
            this.txtTV_exipre = new System.Windows.Forms.TextBox();
            this.dtpTV_FEdate = new System.Windows.Forms.DateTimePicker();
            this.txtTBV_exipre = new System.Windows.Forms.TextBox();
            this.msk_dtpEA_closeDate = new System.Windows.Forms.MaskedTextBox();
            this.msk_dtpEA_stage2 = new System.Windows.Forms.MaskedTextBox();
            this.msk_dtpEA_stage1 = new System.Windows.Forms.MaskedTextBox();
            this.msk_dtpEA_apprDate = new System.Windows.Forms.MaskedTextBox();
            this.msk_dtpFE_daterecFin1 = new System.Windows.Forms.MaskedTextBox();
            this.msk_dtpFE_datesentfin1 = new System.Windows.Forms.MaskedTextBox();
            this.msk_dtpTE_daterec1 = new System.Windows.Forms.MaskedTextBox();
            this.msk_dtpTE_datesent1 = new System.Windows.Forms.MaskedTextBox();
            this.msk_dtpEA_reqdate = new System.Windows.Forms.MaskedTextBox();
            this.msk_dtpEA_recfromcd = new System.Windows.Forms.MaskedTextBox();
            this.dgvTE_Sent = new System.Windows.Forms.DataGridView();
            this.lblTE_estimateAmnt = new System.Windows.Forms.Label();
            this.lblTE_bdgtAmt = new System.Windows.Forms.Label();
            this.txtEstimatedAmnt = new System.Windows.Forms.TextBox();
            this.txtBudjetAmnt = new System.Windows.Forms.TextBox();
            this.txtEA_Noofmeetings = new System.Windows.Forms.TextBox();
            this.dgvTE_Rec = new System.Windows.Forms.DataGridView();
            this.btnSent_TEA = new System.Windows.Forms.Button();
            this.btnRecDocTE = new System.Windows.Forms.Button();
            this.btnTE_Save = new System.Windows.Forms.Button();
            this.dtpEA_recfromcd = new System.Windows.Forms.DateTimePicker();
            this.dtpEA_apprDate = new System.Windows.Forms.DateTimePicker();
            this.dtpFE_daterecFin1 = new System.Windows.Forms.DateTimePicker();
            this.dtpFE_datesentfin1 = new System.Windows.Forms.DateTimePicker();
            this.dtpTE_daterec1 = new System.Windows.Forms.DateTimePicker();
            this.dtpTE_datesent1 = new System.Windows.Forms.DateTimePicker();
            this.dtpEA_reqdate = new System.Windows.Forms.DateTimePicker();
            this.label82 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.tsTabPage = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.msk_dtp_tsModifiedDate_Stage2 = new System.Windows.Forms.MaskedTextBox();
            this.dtp_tsModifiedDate_Stage2 = new System.Windows.Forms.DateTimePicker();
            this.btnClk = new System.Windows.Forms.Button();
            this.lbltype = new System.Windows.Forms.Label();
            this.txtCmpType = new System.Windows.Forms.TextBox();
            this.lblDateCnt = new System.Windows.Forms.Label();
            this.txtTotCompInShortList = new System.Windows.Forms.TextBox();
            this.lblCompaniesInShortList = new System.Windows.Forms.Label();
            this.btnViewShortList = new System.Windows.Forms.Button();
            this.btnExportToPdf = new System.Windows.Forms.Button();
            this.lblDFTenderBondCur = new System.Windows.Forms.Label();
            this.lblTSTenderBondCur = new System.Windows.Forms.Label();
            this.grpEligibleCompanies = new System.Windows.Forms.GroupBox();
            this.chkJointVenture = new System.Windows.Forms.CheckBox();
            this.chkInternational = new System.Windows.Forms.CheckBox();
            this.chkLocal = new System.Windows.Forms.CheckBox();
            this.btnViewBidder = new System.Windows.Forms.Button();
            this.txtCircular = new System.Windows.Forms.TextBox();
            this.lblTotCircularIssued = new System.Windows.Forms.Label();
            this.btnRecDocTS = new System.Windows.Forms.Button();
            this.msk_dtp_tsModifiedDate_Stage1 = new System.Windows.Forms.MaskedTextBox();
            this.btnSentDocTS = new System.Windows.Forms.Button();
            this.dgvTS_Rec = new System.Windows.Forms.DataGridView();
            this.msk_dtp_tsStage2 = new System.Windows.Forms.MaskedTextBox();
            this.dgvTS_Sent = new System.Windows.Forms.DataGridView();
            this.msk_dtp_tsStage1 = new System.Windows.Forms.MaskedTextBox();
            this.msk_dtp_tsInvitation = new System.Windows.Forms.MaskedTextBox();
            this.msk_dtp_tsAdvertisement = new System.Windows.Forms.MaskedTextBox();
            this.msk_dtp_tsRecFromDept = new System.Windows.Forms.MaskedTextBox();
            this.msk_dtp_tsReturnDept = new System.Windows.Forms.MaskedTextBox();
            this.msk_dtp_tsRecOn = new System.Windows.Forms.MaskedTextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.lblTenderProjTitle = new System.Windows.Forms.Label();
            this.txt_tsRemarks = new System.Windows.Forms.TextBox();
            this.lblBondAmt = new System.Windows.Forms.Label();
            this.btnIssueTender = new System.Windows.Forms.Button();
            this.btnTS = new System.Windows.Forms.Button();
            this.lblDocAmt = new System.Windows.Forms.Label();
            this.dtp_tsInvitation = new System.Windows.Forms.DateTimePicker();
            this.label49 = new System.Windows.Forms.Label();
            this.dtp_tsAdvertisement = new System.Windows.Forms.DateTimePicker();
            this.label50 = new System.Windows.Forms.Label();
            this.dtp_tsRecFromDept = new System.Windows.Forms.DateTimePicker();
            this.label51 = new System.Windows.Forms.Label();
            this.dtp_tsReturnDept = new System.Windows.Forms.DateTimePicker();
            this.label52 = new System.Windows.Forms.Label();
            this.dtp_tsModifiedDate_Stage1 = new System.Windows.Forms.DateTimePicker();
            this.lblTotNoBidders = new System.Windows.Forms.Label();
            this.dtp_tsStage2 = new System.Windows.Forms.DateTimePicker();
            this.label57 = new System.Windows.Forms.Label();
            this.dtp_tsStage1 = new System.Windows.Forms.DateTimePicker();
            this.label56 = new System.Windows.Forms.Label();
            this.txt_bidders = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.txtDocumentFee = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.txtTenderBond = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.cmb_tstenderHandle = new System.Windows.Forms.ComboBox();
            this.label62 = new System.Windows.Forms.Label();
            this.dtp_tsRecOn = new System.Windows.Forms.DateTimePicker();
            this.ptdTabPage = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblGridIndex = new System.Windows.Forms.Label();
            this.btnPtdClear = new System.Windows.Forms.Button();
            this.msk_dtpFrwdDept = new System.Windows.Forms.MaskedTextBox();
            this.btnPtdDelete = new System.Windows.Forms.Button();
            this.msk_dtpReview = new System.Windows.Forms.MaskedTextBox();
            this.lblDateID = new System.Windows.Forms.Label();
            this.msk_dtpRecievedOn = new System.Windows.Forms.MaskedTextBox();
            this.dtpFrwdDept = new System.Windows.Forms.DateTimePicker();
            this.btnPTD = new System.Windows.Forms.Button();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.cmbAssignedQs = new System.Windows.Forms.ComboBox();
            this.dtpReview = new System.Windows.Forms.DateTimePicker();
            this.cmbTenderDocStatus = new System.Windows.Forms.ComboBox();
            this.cmbQsWorkingStatus = new System.Windows.Forms.ComboBox();
            this.cmbPurpose = new System.Windows.Forms.ComboBox();
            this.dtpRecievedOn = new System.Windows.Forms.DateTimePicker();
            this.label89 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvPTD_Sent = new System.Windows.Forms.DataGridView();
            this.dgvPTD_Rec = new System.Windows.Forms.DataGridView();
            this.btnSentDoc = new System.Windows.Forms.Button();
            this.btnReceiveDoc = new System.Windows.Forms.Button();
            this.dgvPTD = new System.Windows.Forms.DataGridView();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn36 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn37 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn38 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn39 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn40 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn41 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn42 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn43 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn44 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn45 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn46 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnWorkOrderInPTD = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.pcsTabPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPC_Contracts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPC)).BeginInit();
            this.cpTabPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCpDataEntry)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCP_Sent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCP_Rec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContracts)).BeginInit();
            this.teaTabPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCntrStage3)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTE_Sent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTE_Rec)).BeginInit();
            this.tsTabPage.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.grpEligibleCompanies.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTS_Rec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTS_Sent)).BeginInit();
            this.ptdTabPage.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPTD_Sent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPTD_Rec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPTD)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.btnExportToExcel);
            this.groupBox1.Controls.Add(this.btnUpdateProjStatus);
            this.groupBox1.Controls.Add(this.cmbTenderStatusChange);
            this.groupBox1.Controls.Add(this.btnBudgetRefNo);
            this.groupBox1.Controls.Add(this.lblContractNoDisplay);
            this.groupBox1.Controls.Add(this.lblContractNo);
            this.groupBox1.Controls.Add(this.btnMinistry);
            this.groupBox1.Controls.Add(this.btnBudgetRef);
            this.groupBox1.Controls.Add(this.lblProjID);
            this.groupBox1.Controls.Add(this.btnSaveMinistryCode);
            this.groupBox1.Controls.Add(this.cmbTenderStatus);
            this.groupBox1.Controls.Add(this.cmbBudgetRef);
            this.groupBox1.Controls.Add(this.cmbMinistryCode);
            this.groupBox1.Controls.Add(this.txtProvisionNo);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.lblPrjCode);
            this.groupBox1.Controls.Add(this.lblTenderNo);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.txtProjCode);
            this.groupBox1.Controls.Add(this.txtTenderNo);
            this.groupBox1.Controls.Add(this.txtproj);
            this.groupBox1.Controls.Add(this.btnAssignTender);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1050, 167);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // btnExportToExcel
            // 
            this.btnExportToExcel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExportToExcel.ForeColor = System.Drawing.Color.Blue;
            this.btnExportToExcel.Location = new System.Drawing.Point(22, 134);
            this.btnExportToExcel.Name = "btnExportToExcel";
            this.btnExportToExcel.Size = new System.Drawing.Size(191, 23);
            this.btnExportToExcel.TabIndex = 90;
            this.btnExportToExcel.Text = "Project Summary Export To Excel";
            this.btnExportToExcel.UseVisualStyleBackColor = true;
            this.btnExportToExcel.Click += new System.EventHandler(this.btnExportToExcel_Click);
            // 
            // btnUpdateProjStatus
            // 
            this.btnUpdateProjStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateProjStatus.ForeColor = System.Drawing.Color.Blue;
            this.btnUpdateProjStatus.Location = new System.Drawing.Point(968, 129);
            this.btnUpdateProjStatus.Name = "btnUpdateProjStatus";
            this.btnUpdateProjStatus.Size = new System.Drawing.Size(53, 23);
            this.btnUpdateProjStatus.TabIndex = 89;
            this.btnUpdateProjStatus.Text = "Save";
            this.btnUpdateProjStatus.UseVisualStyleBackColor = true;
            this.btnUpdateProjStatus.Visible = false;
            this.btnUpdateProjStatus.Click += new System.EventHandler(this.button2_Click);
            // 
            // cmbTenderStatusChange
            // 
            this.cmbTenderStatusChange.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTenderStatusChange.FormattingEnabled = true;
            this.cmbTenderStatusChange.Location = new System.Drawing.Point(916, 107);
            this.cmbTenderStatusChange.Name = "cmbTenderStatusChange";
            this.cmbTenderStatusChange.Size = new System.Drawing.Size(105, 21);
            this.cmbTenderStatusChange.TabIndex = 88;
            this.cmbTenderStatusChange.Visible = false;
            // 
            // btnBudgetRefNo
            // 
            this.btnBudgetRefNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBudgetRefNo.ForeColor = System.Drawing.Color.Blue;
            this.btnBudgetRefNo.Location = new System.Drawing.Point(968, 55);
            this.btnBudgetRefNo.Name = "btnBudgetRefNo";
            this.btnBudgetRefNo.Size = new System.Drawing.Size(53, 23);
            this.btnBudgetRefNo.TabIndex = 87;
            this.btnBudgetRefNo.Text = "Save";
            this.btnBudgetRefNo.UseVisualStyleBackColor = true;
            this.btnBudgetRefNo.Click += new System.EventHandler(this.btnBudgetRefNo_Click);
            // 
            // lblContractNoDisplay
            // 
            this.lblContractNoDisplay.AutoSize = true;
            this.lblContractNoDisplay.Location = new System.Drawing.Point(711, 139);
            this.lblContractNoDisplay.Name = "lblContractNoDisplay";
            this.lblContractNoDisplay.Size = new System.Drawing.Size(0, 13);
            this.lblContractNoDisplay.TabIndex = 86;
            // 
            // lblContractNo
            // 
            this.lblContractNo.AutoSize = true;
            this.lblContractNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContractNo.ForeColor = System.Drawing.Color.Black;
            this.lblContractNo.Location = new System.Drawing.Point(626, 139);
            this.lblContractNo.Name = "lblContractNo";
            this.lblContractNo.Size = new System.Drawing.Size(67, 13);
            this.lblContractNo.TabIndex = 85;
            this.lblContractNo.Text = "Contract No.";
            this.lblContractNo.Visible = false;
            // 
            // btnMinistry
            // 
            this.btnMinistry.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMinistry.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnMinistry.Location = new System.Drawing.Point(922, 26);
            this.btnMinistry.Name = "btnMinistry";
            this.btnMinistry.Size = new System.Drawing.Size(36, 23);
            this.btnMinistry.TabIndex = 1;
            this.btnMinistry.Text = "New";
            this.btnMinistry.UseVisualStyleBackColor = true;
            this.btnMinistry.Click += new System.EventHandler(this.btnMinistry_Click);
            // 
            // btnBudgetRef
            // 
            this.btnBudgetRef.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBudgetRef.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnBudgetRef.Location = new System.Drawing.Point(922, 54);
            this.btnBudgetRef.Name = "btnBudgetRef";
            this.btnBudgetRef.Size = new System.Drawing.Size(36, 21);
            this.btnBudgetRef.TabIndex = 2;
            this.btnBudgetRef.Text = "New";
            this.btnBudgetRef.UseVisualStyleBackColor = true;
            this.btnBudgetRef.Click += new System.EventHandler(this.btnBudgetRef_Click);
            // 
            // lblProjID
            // 
            this.lblProjID.AutoSize = true;
            this.lblProjID.Location = new System.Drawing.Point(753, 8);
            this.lblProjID.Name = "lblProjID";
            this.lblProjID.Size = new System.Drawing.Size(48, 13);
            this.lblProjID.TabIndex = 18;
            this.lblProjID.Text = "label90";
            // 
            // btnSaveMinistryCode
            // 
            this.btnSaveMinistryCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveMinistryCode.ForeColor = System.Drawing.Color.Blue;
            this.btnSaveMinistryCode.Location = new System.Drawing.Point(968, 25);
            this.btnSaveMinistryCode.Name = "btnSaveMinistryCode";
            this.btnSaveMinistryCode.Size = new System.Drawing.Size(53, 23);
            this.btnSaveMinistryCode.TabIndex = 1;
            this.btnSaveMinistryCode.Text = "Save";
            this.btnSaveMinistryCode.UseVisualStyleBackColor = true;
            this.btnSaveMinistryCode.Click += new System.EventHandler(this.btnSaveMinistry_Click);
            // 
            // cmbTenderStatus
            // 
            this.cmbTenderStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTenderStatus.FormattingEnabled = true;
            this.cmbTenderStatus.Location = new System.Drawing.Point(707, 107);
            this.cmbTenderStatus.Name = "cmbTenderStatus";
            this.cmbTenderStatus.Size = new System.Drawing.Size(197, 21);
            this.cmbTenderStatus.TabIndex = 17;
            this.cmbTenderStatus.SelectionChangeCommitted += new System.EventHandler(this.cmbTenderStatus_SelectionChangeCommitted);
            // 
            // cmbBudgetRef
            // 
            this.cmbBudgetRef.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbBudgetRef.FormattingEnabled = true;
            this.cmbBudgetRef.Location = new System.Drawing.Point(707, 54);
            this.cmbBudgetRef.Name = "cmbBudgetRef";
            this.cmbBudgetRef.Size = new System.Drawing.Size(197, 21);
            this.cmbBudgetRef.TabIndex = 16;
            // 
            // cmbMinistryCode
            // 
            this.cmbMinistryCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbMinistryCode.FormattingEnabled = true;
            this.cmbMinistryCode.Location = new System.Drawing.Point(707, 26);
            this.cmbMinistryCode.Name = "cmbMinistryCode";
            this.cmbMinistryCode.Size = new System.Drawing.Size(197, 21);
            this.cmbMinistryCode.TabIndex = 15;
            // 
            // txtProvisionNo
            // 
            this.txtProvisionNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProvisionNo.Location = new System.Drawing.Point(706, 81);
            this.txtProvisionNo.Name = "txtProvisionNo";
            this.txtProvisionNo.Size = new System.Drawing.Size(197, 20);
            this.txtProvisionNo.TabIndex = 12;
            this.txtProvisionNo.Leave += new System.EventHandler(this.txtProvisionNo_Leave);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(621, 110);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(74, 13);
            this.label15.TabIndex = 10;
            this.label15.Text = "Tender Status";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(622, 84);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(67, 13);
            this.label14.TabIndex = 9;
            this.label14.Text = "Provision No";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(622, 57);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(78, 13);
            this.label13.TabIndex = 8;
            this.label13.Text = "Budget Ref No";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(622, 29);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(70, 13);
            this.label10.TabIndex = 7;
            this.label10.Text = "Ministry Code";
            // 
            // lblPrjCode
            // 
            this.lblPrjCode.AutoSize = true;
            this.lblPrjCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrjCode.ForeColor = System.Drawing.Color.Black;
            this.lblPrjCode.Location = new System.Drawing.Point(19, 29);
            this.lblPrjCode.Name = "lblPrjCode";
            this.lblPrjCode.Size = new System.Drawing.Size(68, 13);
            this.lblPrjCode.TabIndex = 1;
            this.lblPrjCode.Text = "Project Code";
            // 
            // lblTenderNo
            // 
            this.lblTenderNo.AutoSize = true;
            this.lblTenderNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTenderNo.ForeColor = System.Drawing.Color.Black;
            this.lblTenderNo.Location = new System.Drawing.Point(337, 29);
            this.lblTenderNo.Name = "lblTenderNo";
            this.lblTenderNo.Size = new System.Drawing.Size(58, 13);
            this.lblTenderNo.TabIndex = 2;
            this.lblTenderNo.Text = "Tender No";
            this.lblTenderNo.Visible = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(19, 70);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(63, 13);
            this.label12.TabIndex = 3;
            this.label12.Text = "Project Title";
            // 
            // txtProjCode
            // 
            this.txtProjCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProjCode.Location = new System.Drawing.Point(103, 27);
            this.txtProjCode.Name = "txtProjCode";
            this.txtProjCode.ReadOnly = true;
            this.txtProjCode.Size = new System.Drawing.Size(183, 20);
            this.txtProjCode.TabIndex = 4;
            // 
            // txtTenderNo
            // 
            this.txtTenderNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenderNo.Location = new System.Drawing.Point(405, 28);
            this.txtTenderNo.Name = "txtTenderNo";
            this.txtTenderNo.ReadOnly = true;
            this.txtTenderNo.Size = new System.Drawing.Size(176, 20);
            this.txtTenderNo.TabIndex = 6;
            // 
            // txtproj
            // 
            this.txtproj.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtproj.Location = new System.Drawing.Point(103, 57);
            this.txtproj.Multiline = true;
            this.txtproj.Name = "txtproj";
            this.txtproj.ReadOnly = true;
            this.txtproj.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtproj.Size = new System.Drawing.Size(478, 71);
            this.txtproj.TabIndex = 5;
            // 
            // btnAssignTender
            // 
            this.btnAssignTender.BackColor = System.Drawing.Color.Maroon;
            this.btnAssignTender.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAssignTender.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAssignTender.ForeColor = System.Drawing.Color.White;
            this.btnAssignTender.Location = new System.Drawing.Point(288, 23);
            this.btnAssignTender.Name = "btnAssignTender";
            this.btnAssignTender.Size = new System.Drawing.Size(115, 26);
            this.btnAssignTender.TabIndex = 83;
            this.btnAssignTender.Text = "Assign TenderNo";
            this.btnAssignTender.UseVisualStyleBackColor = false;
            this.btnAssignTender.Visible = false;
            this.btnAssignTender.Click += new System.EventHandler(this.btnAssignTender_Click);
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(703, 20);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(75, 23);
            this.button24.TabIndex = 139;
            this.button24.Text = "button24";
            this.button24.UseVisualStyleBackColor = true;
            // 
            // dgView
            // 
            this.dgView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dgView.BackgroundColor = System.Drawing.Color.Gray;
            this.dgView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.HotPink;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgView.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgView.GridColor = System.Drawing.Color.Olive;
            this.dgView.Location = new System.Drawing.Point(15, 161);
            this.dgView.Name = "dgView";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgView.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgView.Size = new System.Drawing.Size(899, 232);
            this.dgView.TabIndex = 138;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView1.Location = new System.Drawing.Point(15, 23);
            this.dataGridView1.Name = "dataGridView1";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView1.Size = new System.Drawing.Size(442, 120);
            this.dataGridView1.TabIndex = 137;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(545, 104);
            this.textBox15.Multiline = true;
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(369, 39);
            this.textBox15.TabIndex = 136;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(545, 50);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(78, 20);
            this.textBox14.TabIndex = 135;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(545, 77);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(78, 20);
            this.textBox13.TabIndex = 134;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(463, 80);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(77, 13);
            this.label19.TabIndex = 133;
            this.label19.Text = "Estimated Cost";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(499, 53);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(41, 13);
            this.label18.TabIndex = 132;
            this.label18.Text = "Budget";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(490, 107);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(49, 13);
            this.label17.TabIndex = 131;
            this.label17.Text = "Remarks";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(545, 24);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(78, 20);
            this.textBox11.TabIndex = 130;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(463, 27);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(76, 13);
            this.label16.TabIndex = 129;
            this.label16.Text = "Award Amount";
            this.label16.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // pcsTabPage
            // 
            this.pcsTabPage.AutoScroll = true;
            this.pcsTabPage.BackColor = System.Drawing.Color.Cornsilk;
            this.pcsTabPage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pcsTabPage.Controls.Add(this.label43);
            this.pcsTabPage.Controls.Add(this.label36);
            this.pcsTabPage.Controls.Add(this.btnPC_Save);
            this.pcsTabPage.Controls.Add(this.dgvPC_Contracts);
            this.pcsTabPage.Controls.Add(this.dgvPC);
            this.pcsTabPage.Controls.Add(this.txtPC_Remarks);
            this.pcsTabPage.Controls.Add(this.txtPC_BudjetAmnt);
            this.pcsTabPage.Controls.Add(this.txtPC_EstimatedAmnt);
            this.pcsTabPage.Controls.Add(this.lblPc_EstAmnt);
            this.pcsTabPage.Controls.Add(this.lblPC_bdgtAmnt);
            this.pcsTabPage.Controls.Add(this.label92);
            this.pcsTabPage.Location = new System.Drawing.Point(4, 34);
            this.pcsTabPage.Name = "pcsTabPage";
            this.pcsTabPage.Size = new System.Drawing.Size(1039, 547);
            this.pcsTabPage.TabIndex = 5;
            this.pcsTabPage.Text = "POST CONTRACT STAGE   ";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.Color.Cornsilk;
            this.label43.ForeColor = System.Drawing.Color.Black;
            this.label43.Location = new System.Drawing.Point(783, 56);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(23, 13);
            this.label43.TabIndex = 200;
            this.label43.Text = "QR";
            this.label43.Visible = false;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.Color.Cornsilk;
            this.label36.ForeColor = System.Drawing.Color.Black;
            this.label36.Location = new System.Drawing.Point(783, 30);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(23, 13);
            this.label36.TabIndex = 199;
            this.label36.Text = "QR";
            this.label36.Visible = false;
            // 
            // btnPC_Save
            // 
            this.btnPC_Save.BackColor = System.Drawing.Color.Maroon;
            this.btnPC_Save.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPC_Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPC_Save.ForeColor = System.Drawing.Color.White;
            this.btnPC_Save.Location = new System.Drawing.Point(870, 24);
            this.btnPC_Save.Name = "btnPC_Save";
            this.btnPC_Save.Size = new System.Drawing.Size(65, 24);
            this.btnPC_Save.TabIndex = 198;
            this.btnPC_Save.Text = "Save";
            this.btnPC_Save.UseVisualStyleBackColor = false;
            this.btnPC_Save.Visible = false;
            this.btnPC_Save.Click += new System.EventHandler(this.btnPC_Click);
            // 
            // dgvPC_Contracts
            // 
            this.dgvPC_Contracts.AllowUserToAddRows = false;
            this.dgvPC_Contracts.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPC_Contracts.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dgvPC_Contracts.BackgroundColor = System.Drawing.Color.Cornsilk;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.HotPink;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPC_Contracts.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgvPC_Contracts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.Padding = new System.Windows.Forms.Padding(0, 3, 0, 3);
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPC_Contracts.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgvPC_Contracts.GridColor = System.Drawing.Color.Olive;
            this.dgvPC_Contracts.Location = new System.Drawing.Point(36, 163);
            this.dgvPC_Contracts.Name = "dgvPC_Contracts";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPC_Contracts.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgvPC_Contracts.Size = new System.Drawing.Size(899, 319);
            this.dgvPC_Contracts.TabIndex = 149;
            this.dgvPC_Contracts.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPC_Contracts_CellContentClick);
            // 
            // dgvPC
            // 
            this.dgvPC.AllowUserToAddRows = false;
            this.dgvPC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPC.BackgroundColor = System.Drawing.Color.Cornsilk;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPC.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dgvPC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPC.DefaultCellStyle = dataGridViewCellStyle11;
            this.dgvPC.Location = new System.Drawing.Point(36, 21);
            this.dgvPC.Name = "dgvPC";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPC.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dgvPC.RowHeadersVisible = false;
            this.dgvPC.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPC.Size = new System.Drawing.Size(470, 120);
            this.dgvPC.TabIndex = 148;
            // 
            // txtPC_Remarks
            // 
            this.txtPC_Remarks.Location = new System.Drawing.Point(646, 79);
            this.txtPC_Remarks.Multiline = true;
            this.txtPC_Remarks.Name = "txtPC_Remarks";
            this.txtPC_Remarks.Size = new System.Drawing.Size(289, 62);
            this.txtPC_Remarks.TabIndex = 147;
            this.txtPC_Remarks.Visible = false;
            // 
            // txtPC_BudjetAmnt
            // 
            this.txtPC_BudjetAmnt.Location = new System.Drawing.Point(646, 24);
            this.txtPC_BudjetAmnt.Name = "txtPC_BudjetAmnt";
            this.txtPC_BudjetAmnt.Size = new System.Drawing.Size(131, 20);
            this.txtPC_BudjetAmnt.TabIndex = 146;
            this.txtPC_BudjetAmnt.Visible = false;
            this.txtPC_BudjetAmnt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPC_BudjetAmnt_KeyPress);
            this.txtPC_BudjetAmnt.Leave += new System.EventHandler(this.txtPC_BudjetAmnt_Leave);
            // 
            // txtPC_EstimatedAmnt
            // 
            this.txtPC_EstimatedAmnt.Location = new System.Drawing.Point(646, 50);
            this.txtPC_EstimatedAmnt.Name = "txtPC_EstimatedAmnt";
            this.txtPC_EstimatedAmnt.Size = new System.Drawing.Size(131, 20);
            this.txtPC_EstimatedAmnt.TabIndex = 145;
            this.txtPC_EstimatedAmnt.Visible = false;
            this.txtPC_EstimatedAmnt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPC_EstimatedAmnt_KeyPress);
            this.txtPC_EstimatedAmnt.Leave += new System.EventHandler(this.txtPC_EstimatedAmnt_Leave);
            // 
            // lblPc_EstAmnt
            // 
            this.lblPc_EstAmnt.AutoSize = true;
            this.lblPc_EstAmnt.BackColor = System.Drawing.Color.Cornsilk;
            this.lblPc_EstAmnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPc_EstAmnt.Location = new System.Drawing.Point(547, 53);
            this.lblPc_EstAmnt.Name = "lblPc_EstAmnt";
            this.lblPc_EstAmnt.Size = new System.Drawing.Size(77, 13);
            this.lblPc_EstAmnt.TabIndex = 144;
            this.lblPc_EstAmnt.Text = "Estimated Cost";
            this.lblPc_EstAmnt.Visible = false;
            // 
            // lblPC_bdgtAmnt
            // 
            this.lblPC_bdgtAmnt.AutoSize = true;
            this.lblPC_bdgtAmnt.BackColor = System.Drawing.Color.Cornsilk;
            this.lblPC_bdgtAmnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPC_bdgtAmnt.Location = new System.Drawing.Point(547, 24);
            this.lblPC_bdgtAmnt.Name = "lblPC_bdgtAmnt";
            this.lblPC_bdgtAmnt.Size = new System.Drawing.Size(80, 13);
            this.lblPC_bdgtAmnt.TabIndex = 143;
            this.lblPC_bdgtAmnt.Text = "Budget Amount";
            this.lblPC_bdgtAmnt.Visible = false;
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.BackColor = System.Drawing.Color.Cornsilk;
            this.label92.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label92.Location = new System.Drawing.Point(547, 82);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(49, 13);
            this.label92.TabIndex = 142;
            this.label92.Text = "Remarks";
            this.label92.Visible = false;
            // 
            // cpTabPage
            // 
            this.cpTabPage.AutoScroll = true;
            this.cpTabPage.BackColor = System.Drawing.Color.Cornsilk;
            this.cpTabPage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cpTabPage.Controls.Add(this.btnWorkOrder2);
            this.cpTabPage.Controls.Add(this.lblEstCostCurr);
            this.cpTabPage.Controls.Add(this.lblBudAmtCP);
            this.cpTabPage.Controls.Add(this.btnDatesExtend);
            this.cpTabPage.Controls.Add(this.dgvCpDataEntry);
            this.cpTabPage.Controls.Add(this.dgvCP_Sent);
            this.cpTabPage.Controls.Add(this.dgvCP_Rec);
            this.cpTabPage.Controls.Add(this.btnSentCp);
            this.cpTabPage.Controls.Add(this.btnRecCp);
            this.cpTabPage.Controls.Add(this.lblCP_bdgtAmnt);
            this.cpTabPage.Controls.Add(this.btnCP_Save);
            this.cpTabPage.Controls.Add(this.lblCP_estimateAmnt);
            this.cpTabPage.Controls.Add(this.txtCp_EstimatedAmnt);
            this.cpTabPage.Controls.Add(this.txtCp_BudgetAmnt);
            this.cpTabPage.Controls.Add(this.dgvContracts);
            this.cpTabPage.Location = new System.Drawing.Point(4, 34);
            this.cpTabPage.Name = "cpTabPage";
            this.cpTabPage.Size = new System.Drawing.Size(1039, 547);
            this.cpTabPage.TabIndex = 3;
            this.cpTabPage.Text = "CONTRACTS PROCESS   ";
            // 
            // btnWorkOrder2
            // 
            this.btnWorkOrder2.BackColor = System.Drawing.Color.Maroon;
            this.btnWorkOrder2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnWorkOrder2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnWorkOrder2.ForeColor = System.Drawing.Color.White;
            this.btnWorkOrder2.Location = new System.Drawing.Point(174, 361);
            this.btnWorkOrder2.Name = "btnWorkOrder2";
            this.btnWorkOrder2.Size = new System.Drawing.Size(86, 24);
            this.btnWorkOrder2.TabIndex = 241;
            this.btnWorkOrder2.Text = "Work Order";
            this.btnWorkOrder2.UseVisualStyleBackColor = false;
            this.btnWorkOrder2.Visible = false;
            this.btnWorkOrder2.Click += new System.EventHandler(this.btnWorkOrder2_Click);
            // 
            // lblEstCostCurr
            // 
            this.lblEstCostCurr.AutoSize = true;
            this.lblEstCostCurr.BackColor = System.Drawing.SystemColors.Window;
            this.lblEstCostCurr.Location = new System.Drawing.Point(937, 365);
            this.lblEstCostCurr.Name = "lblEstCostCurr";
            this.lblEstCostCurr.Size = new System.Drawing.Size(23, 13);
            this.lblEstCostCurr.TabIndex = 233;
            this.lblEstCostCurr.Text = "QR";
            // 
            // lblBudAmtCP
            // 
            this.lblBudAmtCP.AutoSize = true;
            this.lblBudAmtCP.BackColor = System.Drawing.SystemColors.Window;
            this.lblBudAmtCP.Location = new System.Drawing.Point(702, 365);
            this.lblBudAmtCP.Name = "lblBudAmtCP";
            this.lblBudAmtCP.Size = new System.Drawing.Size(23, 13);
            this.lblBudAmtCP.TabIndex = 232;
            this.lblBudAmtCP.Text = "QR";
            // 
            // btnDatesExtend
            // 
            this.btnDatesExtend.BackColor = System.Drawing.Color.Maroon;
            this.btnDatesExtend.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDatesExtend.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDatesExtend.ForeColor = System.Drawing.Color.White;
            this.btnDatesExtend.Location = new System.Drawing.Point(283, 362);
            this.btnDatesExtend.Name = "btnDatesExtend";
            this.btnDatesExtend.Size = new System.Drawing.Size(189, 23);
            this.btnDatesExtend.TabIndex = 231;
            this.btnDatesExtend.Text = "View Tender Validity Dates";
            this.btnDatesExtend.UseVisualStyleBackColor = false;
            this.btnDatesExtend.Visible = false;
            this.btnDatesExtend.Click += new System.EventHandler(this.btnDatesExtend_Click);
            // 
            // dgvCpDataEntry
            // 
            this.dgvCpDataEntry.AllowUserToAddRows = false;
            this.dgvCpDataEntry.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCpDataEntry.BackgroundColor = System.Drawing.Color.Cornsilk;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCpDataEntry.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dgvCpDataEntry.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCpDataEntry.DefaultCellStyle = dataGridViewCellStyle14;
            this.dgvCpDataEntry.Location = new System.Drawing.Point(24, 187);
            this.dgvCpDataEntry.Name = "dgvCpDataEntry";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCpDataEntry.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.dgvCpDataEntry.RowHeadersVisible = false;
            this.dgvCpDataEntry.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCpDataEntry.Size = new System.Drawing.Size(947, 159);
            this.dgvCpDataEntry.TabIndex = 208;
            this.dgvCpDataEntry.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCpDataEntry_CellEndEdit);
            this.dgvCpDataEntry.UserAddedRow += new System.Windows.Forms.DataGridViewRowEventHandler(this.dgvCpDataEntry_UserAddedRow);
            // 
            // dgvCP_Sent
            // 
            this.dgvCP_Sent.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCP_Sent.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCP_Sent.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.dgvCP_Sent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvCP_Sent.DefaultCellStyle = dataGridViewCellStyle17;
            this.dgvCP_Sent.Location = new System.Drawing.Point(530, 421);
            this.dgvCP_Sent.Name = "dgvCP_Sent";
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCP_Sent.RowHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.dgvCP_Sent.Size = new System.Drawing.Size(441, 111);
            this.dgvCP_Sent.TabIndex = 207;
            this.dgvCP_Sent.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCP_Sent_CellClick);
            // 
            // dgvCP_Rec
            // 
            this.dgvCP_Rec.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCP_Rec.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCP_Rec.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.dgvCP_Rec.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvCP_Rec.DefaultCellStyle = dataGridViewCellStyle20;
            this.dgvCP_Rec.Location = new System.Drawing.Point(24, 421);
            this.dgvCP_Rec.Name = "dgvCP_Rec";
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle21.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle21.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCP_Rec.RowHeadersDefaultCellStyle = dataGridViewCellStyle21;
            this.dgvCP_Rec.Size = new System.Drawing.Size(476, 111);
            this.dgvCP_Rec.TabIndex = 206;
            this.dgvCP_Rec.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCP_Rec_CellClick);
            // 
            // btnSentCp
            // 
            this.btnSentCp.BackColor = System.Drawing.Color.Maroon;
            this.btnSentCp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSentCp.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSentCp.ForeColor = System.Drawing.Color.White;
            this.btnSentCp.Location = new System.Drawing.Point(530, 392);
            this.btnSentCp.Name = "btnSentCp";
            this.btnSentCp.Size = new System.Drawing.Size(113, 23);
            this.btnSentCp.TabIndex = 205;
            this.btnSentCp.Text = "Sent Document";
            this.btnSentCp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSentCp.UseVisualStyleBackColor = false;
            this.btnSentCp.Click += new System.EventHandler(this.btnSentCp_Click);
            // 
            // btnRecCp
            // 
            this.btnRecCp.BackColor = System.Drawing.Color.Maroon;
            this.btnRecCp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRecCp.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRecCp.ForeColor = System.Drawing.Color.White;
            this.btnRecCp.Location = new System.Drawing.Point(24, 392);
            this.btnRecCp.Name = "btnRecCp";
            this.btnRecCp.Size = new System.Drawing.Size(115, 23);
            this.btnRecCp.TabIndex = 204;
            this.btnRecCp.Text = "Recieved Document";
            this.btnRecCp.UseVisualStyleBackColor = false;
            this.btnRecCp.Click += new System.EventHandler(this.btnRecCp_Click);
            // 
            // lblCP_bdgtAmnt
            // 
            this.lblCP_bdgtAmnt.AutoSize = true;
            this.lblCP_bdgtAmnt.BackColor = System.Drawing.Color.Cornsilk;
            this.lblCP_bdgtAmnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCP_bdgtAmnt.ForeColor = System.Drawing.Color.Black;
            this.lblCP_bdgtAmnt.Location = new System.Drawing.Point(509, 367);
            this.lblCP_bdgtAmnt.Name = "lblCP_bdgtAmnt";
            this.lblCP_bdgtAmnt.Size = new System.Drawing.Size(80, 13);
            this.lblCP_bdgtAmnt.TabIndex = 153;
            this.lblCP_bdgtAmnt.Text = "Budget Amount";
            // 
            // btnCP_Save
            // 
            this.btnCP_Save.BackColor = System.Drawing.Color.Maroon;
            this.btnCP_Save.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCP_Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCP_Save.ForeColor = System.Drawing.Color.White;
            this.btnCP_Save.Location = new System.Drawing.Point(24, 362);
            this.btnCP_Save.Name = "btnCP_Save";
            this.btnCP_Save.Size = new System.Drawing.Size(65, 24);
            this.btnCP_Save.TabIndex = 198;
            this.btnCP_Save.Text = "Save";
            this.btnCP_Save.UseVisualStyleBackColor = false;
            this.btnCP_Save.Click += new System.EventHandler(this.btnCP_Save_Click);
            // 
            // lblCP_estimateAmnt
            // 
            this.lblCP_estimateAmnt.AutoSize = true;
            this.lblCP_estimateAmnt.BackColor = System.Drawing.Color.Cornsilk;
            this.lblCP_estimateAmnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCP_estimateAmnt.ForeColor = System.Drawing.Color.Black;
            this.lblCP_estimateAmnt.Location = new System.Drawing.Point(748, 365);
            this.lblCP_estimateAmnt.Name = "lblCP_estimateAmnt";
            this.lblCP_estimateAmnt.Size = new System.Drawing.Size(77, 13);
            this.lblCP_estimateAmnt.TabIndex = 154;
            this.lblCP_estimateAmnt.Text = "Estimated Cost";
            // 
            // txtCp_EstimatedAmnt
            // 
            this.txtCp_EstimatedAmnt.Location = new System.Drawing.Point(831, 362);
            this.txtCp_EstimatedAmnt.Name = "txtCp_EstimatedAmnt";
            this.txtCp_EstimatedAmnt.Size = new System.Drawing.Size(129, 20);
            this.txtCp_EstimatedAmnt.TabIndex = 155;
            this.txtCp_EstimatedAmnt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCp_EstimatedAmnt_KeyPress);
            this.txtCp_EstimatedAmnt.Leave += new System.EventHandler(this.txtCp_EstimatedAmnt_Leave);
            // 
            // txtCp_BudgetAmnt
            // 
            this.txtCp_BudgetAmnt.Location = new System.Drawing.Point(594, 362);
            this.txtCp_BudgetAmnt.Name = "txtCp_BudgetAmnt";
            this.txtCp_BudgetAmnt.Size = new System.Drawing.Size(135, 20);
            this.txtCp_BudgetAmnt.TabIndex = 156;
            this.txtCp_BudgetAmnt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCp_BudgetAmnt_KeyPress);
            this.txtCp_BudgetAmnt.Leave += new System.EventHandler(this.txtCp_BudgetAmnt_Leave);
            // 
            // dgvContracts
            // 
            this.dgvContracts.AllowUserToAddRows = false;
            this.dgvContracts.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvContracts.BackgroundColor = System.Drawing.Color.Cornsilk;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvContracts.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle22;
            this.dgvContracts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvContracts.DefaultCellStyle = dataGridViewCellStyle23;
            this.dgvContracts.Location = new System.Drawing.Point(24, 19);
            this.dgvContracts.Name = "dgvContracts";
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvContracts.RowHeadersDefaultCellStyle = dataGridViewCellStyle24;
            this.dgvContracts.RowHeadersVisible = false;
            this.dgvContracts.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvContracts.Size = new System.Drawing.Size(947, 162);
            this.dgvContracts.TabIndex = 124;
            this.dgvContracts.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvContracts_CellContentClick);
            this.dgvContracts.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvContracts_CellEndEdit);
            this.dgvContracts.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvContracts_CellFormatting);
            this.dgvContracts.CellValidated += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvContracts_CellValidated);
            this.dgvContracts.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.dgvContracts_CellValidating);
            this.dgvContracts.CurrentCellDirtyStateChanged += new System.EventHandler(this.dgvContracts_CurrentCellDirtyStateChanged);
            this.dgvContracts.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvContracts_EditingControlShowing);
            this.dgvContracts.UserAddedRow += new System.Windows.Forms.DataGridViewRowEventHandler(this.dgvContracts_UserAddedRow);
            // 
            // teaTabPage
            // 
            this.teaTabPage.AutoScroll = true;
            this.teaTabPage.BackColor = System.Drawing.Color.Cornsilk;
            this.teaTabPage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.teaTabPage.Controls.Add(this.msk_dtpEA_closeDate_Stage2);
            this.teaTabPage.Controls.Add(this.btnTenderSubmissionStg2);
            this.teaTabPage.Controls.Add(this.label2);
            this.teaTabPage.Controls.Add(this.msk_dtpFE_daterecFin2);
            this.teaTabPage.Controls.Add(this.dtpFE_daterecFin2);
            this.teaTabPage.Controls.Add(this.txtFinEval2ProposedWorkDays);
            this.teaTabPage.Controls.Add(this.msk_dtpFE_datesentfin2);
            this.teaTabPage.Controls.Add(this.dtpFE_datesentfin2);
            this.teaTabPage.Controls.Add(this.txtTechEval2ProposedWorkDays);
            this.teaTabPage.Controls.Add(this.msk_dtpTE_datesent2);
            this.teaTabPage.Controls.Add(this.dtpTE_datesent2);
            this.teaTabPage.Controls.Add(this.msk_dtpTE_daterec2);
            this.teaTabPage.Controls.Add(this.dtpTE_daterec2);
            this.teaTabPage.Controls.Add(this.btnWorkOrder);
            this.teaTabPage.Controls.Add(this.btnDelete);
            this.teaTabPage.Controls.Add(this.txtFinEval1ProposedWorkDays);
            this.teaTabPage.Controls.Add(this.lblFinEvalProposedWorkDays);
            this.teaTabPage.Controls.Add(this.txtTechEval1ProposedWorkDays);
            this.teaTabPage.Controls.Add(this.lblTechEvalProposedWorkDays);
            this.teaTabPage.Controls.Add(this.button1);
            this.teaTabPage.Controls.Add(this.btnTenderSubmissionStage1);
            this.teaTabPage.Controls.Add(this.lblEstCostCurrSymbol);
            this.teaTabPage.Controls.Add(this.lblBdgAmtCurrSymbol);
            this.teaTabPage.Controls.Add(this.btnCntrSave);
            this.teaTabPage.Controls.Add(this.dgvCntrStage3);
            this.teaTabPage.Controls.Add(this.label3);
            this.teaTabPage.Controls.Add(this.txtTE_remarks);
            this.teaTabPage.Controls.Add(this.groupBox4);
            this.teaTabPage.Controls.Add(this.msk_dtpEA_closeDate);
            this.teaTabPage.Controls.Add(this.msk_dtpEA_stage2);
            this.teaTabPage.Controls.Add(this.msk_dtpEA_stage1);
            this.teaTabPage.Controls.Add(this.msk_dtpEA_apprDate);
            this.teaTabPage.Controls.Add(this.msk_dtpFE_daterecFin1);
            this.teaTabPage.Controls.Add(this.msk_dtpFE_datesentfin1);
            this.teaTabPage.Controls.Add(this.msk_dtpTE_daterec1);
            this.teaTabPage.Controls.Add(this.msk_dtpTE_datesent1);
            this.teaTabPage.Controls.Add(this.msk_dtpEA_reqdate);
            this.teaTabPage.Controls.Add(this.msk_dtpEA_recfromcd);
            this.teaTabPage.Controls.Add(this.dgvTE_Sent);
            this.teaTabPage.Controls.Add(this.lblTE_estimateAmnt);
            this.teaTabPage.Controls.Add(this.lblTE_bdgtAmt);
            this.teaTabPage.Controls.Add(this.txtEstimatedAmnt);
            this.teaTabPage.Controls.Add(this.txtBudjetAmnt);
            this.teaTabPage.Controls.Add(this.txtEA_Noofmeetings);
            this.teaTabPage.Controls.Add(this.dgvTE_Rec);
            this.teaTabPage.Controls.Add(this.btnSent_TEA);
            this.teaTabPage.Controls.Add(this.btnRecDocTE);
            this.teaTabPage.Controls.Add(this.btnTE_Save);
            this.teaTabPage.Controls.Add(this.dtpEA_recfromcd);
            this.teaTabPage.Controls.Add(this.dtpEA_apprDate);
            this.teaTabPage.Controls.Add(this.dtpFE_daterecFin1);
            this.teaTabPage.Controls.Add(this.dtpFE_datesentfin1);
            this.teaTabPage.Controls.Add(this.dtpTE_daterec1);
            this.teaTabPage.Controls.Add(this.dtpTE_datesent1);
            this.teaTabPage.Controls.Add(this.dtpEA_reqdate);
            this.teaTabPage.Controls.Add(this.label82);
            this.teaTabPage.Controls.Add(this.label81);
            this.teaTabPage.Controls.Add(this.label80);
            this.teaTabPage.Controls.Add(this.label73);
            this.teaTabPage.Controls.Add(this.label74);
            this.teaTabPage.Controls.Add(this.label75);
            this.teaTabPage.Controls.Add(this.label76);
            this.teaTabPage.Controls.Add(this.label77);
            this.teaTabPage.Controls.Add(this.label78);
            this.teaTabPage.Controls.Add(this.label79);
            this.teaTabPage.Controls.Add(this.label55);
            this.teaTabPage.Controls.Add(this.label63);
            this.teaTabPage.Controls.Add(this.label64);
            this.teaTabPage.Controls.Add(this.label65);
            this.teaTabPage.Location = new System.Drawing.Point(4, 34);
            this.teaTabPage.Name = "teaTabPage";
            this.teaTabPage.Size = new System.Drawing.Size(1039, 547);
            this.teaTabPage.TabIndex = 2;
            this.teaTabPage.Text = "TENDER EVALUATION AND AWARD   ";
            // 
            // msk_dtpEA_closeDate_Stage2
            // 
            this.msk_dtpEA_closeDate_Stage2.Location = new System.Drawing.Point(264, 198);
            this.msk_dtpEA_closeDate_Stage2.Name = "msk_dtpEA_closeDate_Stage2";
            this.msk_dtpEA_closeDate_Stage2.ReadOnly = true;
            this.msk_dtpEA_closeDate_Stage2.Size = new System.Drawing.Size(115, 20);
            this.msk_dtpEA_closeDate_Stage2.TabIndex = 257;
            this.msk_dtpEA_closeDate_Stage2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnTenderSubmissionStg2
            // 
            this.btnTenderSubmissionStg2.BackColor = System.Drawing.Color.Maroon;
            this.btnTenderSubmissionStg2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTenderSubmissionStg2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnTenderSubmissionStg2.ForeColor = System.Drawing.Color.White;
            this.btnTenderSubmissionStg2.Location = new System.Drawing.Point(326, 346);
            this.btnTenderSubmissionStg2.Name = "btnTenderSubmissionStg2";
            this.btnTenderSubmissionStg2.Size = new System.Drawing.Size(128, 38);
            this.btnTenderSubmissionStg2.TabIndex = 256;
            this.btnTenderSubmissionStg2.Text = "Tender Submission (Stage 2)";
            this.btnTenderSubmissionStg2.UseVisualStyleBackColor = false;
            this.btnTenderSubmissionStg2.Visible = false;
            this.btnTenderSubmissionStg2.Click += new System.EventHandler(this.btnTenderSubmissionStg2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Gainsboro;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.ForeColor = System.Drawing.Color.Chocolate;
            this.label2.Location = new System.Drawing.Point(156, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 15);
            this.label2.TabIndex = 255;
            this.label2.Text = "Second Evaluation";
            // 
            // msk_dtpFE_daterecFin2
            // 
            this.msk_dtpFE_daterecFin2.Location = new System.Drawing.Point(706, 94);
            this.msk_dtpFE_daterecFin2.Name = "msk_dtpFE_daterecFin2";
            this.msk_dtpFE_daterecFin2.Size = new System.Drawing.Size(81, 20);
            this.msk_dtpFE_daterecFin2.TabIndex = 252;
            this.msk_dtpFE_daterecFin2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.msk_dtpFE_daterecFin2.Leave += new System.EventHandler(this.msk_dtpFE_daterecFin2_Leave);
            // 
            // dtpFE_daterecFin2
            // 
            this.dtpFE_daterecFin2.Checked = false;
            this.dtpFE_daterecFin2.CustomFormat = "  ";
            this.dtpFE_daterecFin2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFE_daterecFin2.Location = new System.Drawing.Point(706, 94);
            this.dtpFE_daterecFin2.Name = "dtpFE_daterecFin2";
            this.dtpFE_daterecFin2.ShowCheckBox = true;
            this.dtpFE_daterecFin2.Size = new System.Drawing.Size(104, 20);
            this.dtpFE_daterecFin2.TabIndex = 251;
            this.dtpFE_daterecFin2.Value = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.dtpFE_daterecFin2.ValueChanged += new System.EventHandler(this.dtpEA_daterecFin2_ValueChanged);
            // 
            // txtFinEval2ProposedWorkDays
            // 
            this.txtFinEval2ProposedWorkDays.Location = new System.Drawing.Point(663, 94);
            this.txtFinEval2ProposedWorkDays.Name = "txtFinEval2ProposedWorkDays";
            this.txtFinEval2ProposedWorkDays.Size = new System.Drawing.Size(32, 20);
            this.txtFinEval2ProposedWorkDays.TabIndex = 250;
            // 
            // msk_dtpFE_datesentfin2
            // 
            this.msk_dtpFE_datesentfin2.Location = new System.Drawing.Point(545, 94);
            this.msk_dtpFE_datesentfin2.Name = "msk_dtpFE_datesentfin2";
            this.msk_dtpFE_datesentfin2.Size = new System.Drawing.Size(83, 20);
            this.msk_dtpFE_datesentfin2.TabIndex = 249;
            this.msk_dtpFE_datesentfin2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.msk_dtpFE_datesentfin2.Leave += new System.EventHandler(this.msk_dtpFE_datesentfin2_Leave);
            // 
            // dtpFE_datesentfin2
            // 
            this.dtpFE_datesentfin2.Checked = false;
            this.dtpFE_datesentfin2.CustomFormat = "  ";
            this.dtpFE_datesentfin2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFE_datesentfin2.Location = new System.Drawing.Point(545, 94);
            this.dtpFE_datesentfin2.Name = "dtpFE_datesentfin2";
            this.dtpFE_datesentfin2.ShowCheckBox = true;
            this.dtpFE_datesentfin2.Size = new System.Drawing.Size(113, 20);
            this.dtpFE_datesentfin2.TabIndex = 248;
            this.dtpFE_datesentfin2.Value = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.dtpFE_datesentfin2.ValueChanged += new System.EventHandler(this.dtpEA_datesentfin2_ValueChanged);
            // 
            // txtTechEval2ProposedWorkDays
            // 
            this.txtTechEval2ProposedWorkDays.Location = new System.Drawing.Point(387, 94);
            this.txtTechEval2ProposedWorkDays.Name = "txtTechEval2ProposedWorkDays";
            this.txtTechEval2ProposedWorkDays.Size = new System.Drawing.Size(30, 20);
            this.txtTechEval2ProposedWorkDays.TabIndex = 247;
            // 
            // msk_dtpTE_datesent2
            // 
            this.msk_dtpTE_datesent2.Location = new System.Drawing.Point(262, 94);
            this.msk_dtpTE_datesent2.Name = "msk_dtpTE_datesent2";
            this.msk_dtpTE_datesent2.Size = new System.Drawing.Size(88, 20);
            this.msk_dtpTE_datesent2.TabIndex = 246;
            this.msk_dtpTE_datesent2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.msk_dtpTE_datesent2.Leave += new System.EventHandler(this.msk_dtpTE_datesent2_Leave);
            // 
            // dtpTE_datesent2
            // 
            this.dtpTE_datesent2.Checked = false;
            this.dtpTE_datesent2.CustomFormat = "  ";
            this.dtpTE_datesent2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTE_datesent2.Location = new System.Drawing.Point(262, 94);
            this.dtpTE_datesent2.Name = "dtpTE_datesent2";
            this.dtpTE_datesent2.ShowCheckBox = true;
            this.dtpTE_datesent2.Size = new System.Drawing.Size(119, 20);
            this.dtpTE_datesent2.TabIndex = 245;
            this.dtpTE_datesent2.Value = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.dtpTE_datesent2.ValueChanged += new System.EventHandler(this.dtpEA_datesent2_ValueChanged);
            // 
            // msk_dtpTE_daterec2
            // 
            this.msk_dtpTE_daterec2.Location = new System.Drawing.Point(424, 94);
            this.msk_dtpTE_daterec2.Name = "msk_dtpTE_daterec2";
            this.msk_dtpTE_daterec2.Size = new System.Drawing.Size(83, 20);
            this.msk_dtpTE_daterec2.TabIndex = 244;
            this.msk_dtpTE_daterec2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.msk_dtpTE_daterec2.Leave += new System.EventHandler(this.msk_dtpTE_daterec2_Leave);
            // 
            // dtpTE_daterec2
            // 
            this.dtpTE_daterec2.Checked = false;
            this.dtpTE_daterec2.CustomFormat = "  ";
            this.dtpTE_daterec2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTE_daterec2.Location = new System.Drawing.Point(424, 94);
            this.dtpTE_daterec2.Name = "dtpTE_daterec2";
            this.dtpTE_daterec2.ShowCheckBox = true;
            this.dtpTE_daterec2.Size = new System.Drawing.Size(114, 20);
            this.dtpTE_daterec2.TabIndex = 243;
            this.dtpTE_daterec2.Value = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.dtpTE_daterec2.ValueChanged += new System.EventHandler(this.dtpEA_daterec2_ValueChanged);
            // 
            // btnWorkOrder
            // 
            this.btnWorkOrder.BackColor = System.Drawing.Color.Maroon;
            this.btnWorkOrder.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnWorkOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnWorkOrder.ForeColor = System.Drawing.Color.White;
            this.btnWorkOrder.Location = new System.Drawing.Point(460, 346);
            this.btnWorkOrder.Name = "btnWorkOrder";
            this.btnWorkOrder.Size = new System.Drawing.Size(86, 24);
            this.btnWorkOrder.TabIndex = 240;
            this.btnWorkOrder.Text = "Work Order";
            this.btnWorkOrder.UseVisualStyleBackColor = false;
            this.btnWorkOrder.Visible = false;
            this.btnWorkOrder.Click += new System.EventHandler(this.btnWorkOrder_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Maroon;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.Color.White;
            this.btnDelete.Location = new System.Drawing.Point(126, 346);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(55, 24);
            this.btnDelete.TabIndex = 238;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // txtFinEval1ProposedWorkDays
            // 
            this.txtFinEval1ProposedWorkDays.Location = new System.Drawing.Point(663, 74);
            this.txtFinEval1ProposedWorkDays.Name = "txtFinEval1ProposedWorkDays";
            this.txtFinEval1ProposedWorkDays.Size = new System.Drawing.Size(32, 20);
            this.txtFinEval1ProposedWorkDays.TabIndex = 237;
            this.txtFinEval1ProposedWorkDays.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFinEvalProposedWorkDays_KeyPress);
            // 
            // lblFinEvalProposedWorkDays
            // 
            this.lblFinEvalProposedWorkDays.AutoSize = true;
            this.lblFinEvalProposedWorkDays.BackColor = System.Drawing.Color.Gainsboro;
            this.lblFinEvalProposedWorkDays.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblFinEvalProposedWorkDays.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinEvalProposedWorkDays.ForeColor = System.Drawing.Color.Chocolate;
            this.lblFinEvalProposedWorkDays.Location = new System.Drawing.Point(657, 43);
            this.lblFinEvalProposedWorkDays.Name = "lblFinEvalProposedWorkDays";
            this.lblFinEvalProposedWorkDays.Padding = new System.Windows.Forms.Padding(2);
            this.lblFinEvalProposedWorkDays.Size = new System.Drawing.Size(48, 21);
            this.lblFinEvalProposedWorkDays.TabIndex = 236;
            this.lblFinEvalProposedWorkDays.Text = "FPWD";
            this.lblFinEvalProposedWorkDays.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTechEval1ProposedWorkDays
            // 
            this.txtTechEval1ProposedWorkDays.Location = new System.Drawing.Point(387, 74);
            this.txtTechEval1ProposedWorkDays.Name = "txtTechEval1ProposedWorkDays";
            this.txtTechEval1ProposedWorkDays.Size = new System.Drawing.Size(30, 20);
            this.txtTechEval1ProposedWorkDays.TabIndex = 235;
            this.txtTechEval1ProposedWorkDays.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTechEvalProposedWorkDays_KeyPress);
            // 
            // lblTechEvalProposedWorkDays
            // 
            this.lblTechEvalProposedWorkDays.AutoSize = true;
            this.lblTechEvalProposedWorkDays.BackColor = System.Drawing.Color.Gainsboro;
            this.lblTechEvalProposedWorkDays.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTechEvalProposedWorkDays.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTechEvalProposedWorkDays.ForeColor = System.Drawing.Color.Chocolate;
            this.lblTechEvalProposedWorkDays.Location = new System.Drawing.Point(380, 43);
            this.lblTechEvalProposedWorkDays.Name = "lblTechEvalProposedWorkDays";
            this.lblTechEvalProposedWorkDays.Padding = new System.Windows.Forms.Padding(2);
            this.lblTechEvalProposedWorkDays.Size = new System.Drawing.Size(48, 21);
            this.lblTechEvalProposedWorkDays.TabIndex = 234;
            this.lblTechEvalProposedWorkDays.Text = "TPWD";
            this.lblTechEvalProposedWorkDays.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Maroon;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(636, 382);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(95, 23);
            this.button1.TabIndex = 233;
            this.button1.Text = "TFE Sent Doc";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // btnTenderSubmissionStage1
            // 
            this.btnTenderSubmissionStage1.BackColor = System.Drawing.Color.Maroon;
            this.btnTenderSubmissionStage1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTenderSubmissionStage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnTenderSubmissionStage1.ForeColor = System.Drawing.Color.White;
            this.btnTenderSubmissionStage1.Location = new System.Drawing.Point(192, 346);
            this.btnTenderSubmissionStage1.Name = "btnTenderSubmissionStage1";
            this.btnTenderSubmissionStage1.Size = new System.Drawing.Size(128, 38);
            this.btnTenderSubmissionStage1.TabIndex = 232;
            this.btnTenderSubmissionStage1.Text = "Tender Submission";
            this.btnTenderSubmissionStage1.UseVisualStyleBackColor = false;
            this.btnTenderSubmissionStage1.Click += new System.EventHandler(this.btnTenderSubmissionStage1_Click);
            // 
            // lblEstCostCurrSymbol
            // 
            this.lblEstCostCurrSymbol.AutoSize = true;
            this.lblEstCostCurrSymbol.BackColor = System.Drawing.SystemColors.Window;
            this.lblEstCostCurrSymbol.Location = new System.Drawing.Point(962, 319);
            this.lblEstCostCurrSymbol.Name = "lblEstCostCurrSymbol";
            this.lblEstCostCurrSymbol.Size = new System.Drawing.Size(23, 13);
            this.lblEstCostCurrSymbol.TabIndex = 231;
            this.lblEstCostCurrSymbol.Text = "QR";
            // 
            // lblBdgAmtCurrSymbol
            // 
            this.lblBdgAmtCurrSymbol.AutoSize = true;
            this.lblBdgAmtCurrSymbol.BackColor = System.Drawing.SystemColors.Window;
            this.lblBdgAmtCurrSymbol.Location = new System.Drawing.Point(741, 318);
            this.lblBdgAmtCurrSymbol.Name = "lblBdgAmtCurrSymbol";
            this.lblBdgAmtCurrSymbol.Size = new System.Drawing.Size(23, 13);
            this.lblBdgAmtCurrSymbol.TabIndex = 230;
            this.lblBdgAmtCurrSymbol.Text = "QR";
            // 
            // btnCntrSave
            // 
            this.btnCntrSave.BackColor = System.Drawing.Color.Maroon;
            this.btnCntrSave.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCntrSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCntrSave.ForeColor = System.Drawing.Color.White;
            this.btnCntrSave.Location = new System.Drawing.Point(65, 346);
            this.btnCntrSave.Name = "btnCntrSave";
            this.btnCntrSave.Size = new System.Drawing.Size(55, 24);
            this.btnCntrSave.TabIndex = 229;
            this.btnCntrSave.Text = "Save";
            this.btnCntrSave.UseVisualStyleBackColor = false;
            this.btnCntrSave.Click += new System.EventHandler(this.btnCntrSave_Click);
            // 
            // dgvCntrStage3
            // 
            this.dgvCntrStage3.BackgroundColor = System.Drawing.Color.Cornsilk;
            this.dgvCntrStage3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle25.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle25.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCntrStage3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle25;
            this.dgvCntrStage3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle26.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle26.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.Color.Peru;
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCntrStage3.DefaultCellStyle = dataGridViewCellStyle26;
            this.dgvCntrStage3.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvCntrStage3.Location = new System.Drawing.Point(12, 220);
            this.dgvCntrStage3.Name = "dgvCntrStage3";
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle27.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCntrStage3.RowHeadersDefaultCellStyle = dataGridViewCellStyle27;
            this.dgvCntrStage3.RowHeadersVisible = false;
            this.dgvCntrStage3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCntrStage3.Size = new System.Drawing.Size(510, 109);
            this.dgvCntrStage3.TabIndex = 228;
            this.dgvCntrStage3.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCntrStage3_CellValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(413, 117);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 224;
            this.label3.Text = "Remarks";
            // 
            // txtTE_remarks
            // 
            this.txtTE_remarks.Location = new System.Drawing.Point(468, 117);
            this.txtTE_remarks.Multiline = true;
            this.txtTE_remarks.Name = "txtTE_remarks";
            this.txtTE_remarks.Size = new System.Drawing.Size(509, 51);
            this.txtTE_remarks.TabIndex = 225;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label70);
            this.groupBox4.Controls.Add(this.msk_dtpTBV_SEdate);
            this.groupBox4.Controls.Add(this.label69);
            this.groupBox4.Controls.Add(this.msk_dtpTV_SEdate);
            this.groupBox4.Controls.Add(this.label68);
            this.groupBox4.Controls.Add(this.msk_dtpTBV_FEdate);
            this.groupBox4.Controls.Add(this.label67);
            this.groupBox4.Controls.Add(this.msk_dtpTV_FEdate);
            this.groupBox4.Controls.Add(this.label66);
            this.groupBox4.Controls.Add(this.msk_dtpTBV_OrgDate);
            this.groupBox4.Controls.Add(this.label54);
            this.groupBox4.Controls.Add(this.msk_dtpTV_OrgDate);
            this.groupBox4.Controls.Add(this.dtpTBV_FEdate);
            this.groupBox4.Controls.Add(this.dtpTBV_SEdate);
            this.groupBox4.Controls.Add(this.dtpTV_SEdate);
            this.groupBox4.Controls.Add(this.txtTV_exipre);
            this.groupBox4.Controls.Add(this.dtpTV_FEdate);
            this.groupBox4.Controls.Add(this.txtTBV_exipre);
            this.groupBox4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox4.Location = new System.Drawing.Point(526, 203);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(1);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox4.Size = new System.Drawing.Size(463, 100);
            this.groupBox4.TabIndex = 223;
            this.groupBox4.TabStop = false;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.BackColor = System.Drawing.Color.Cornsilk;
            this.label70.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label70.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label70.Location = new System.Drawing.Point(110, 12);
            this.label70.Name = "label70";
            this.label70.Padding = new System.Windows.Forms.Padding(3);
            this.label70.Size = new System.Drawing.Size(81, 34);
            this.label70.TabIndex = 139;
            this.label70.Text = "       Original   \r\n    Expiry Date";
            // 
            // msk_dtpTBV_SEdate
            // 
            this.msk_dtpTBV_SEdate.Location = new System.Drawing.Point(297, 73);
            this.msk_dtpTBV_SEdate.Name = "msk_dtpTBV_SEdate";
            this.msk_dtpTBV_SEdate.Size = new System.Drawing.Size(71, 20);
            this.msk_dtpTBV_SEdate.TabIndex = 222;
            this.msk_dtpTBV_SEdate.Leave += new System.EventHandler(this.msk_dtpTBV_SEdate_Leave);
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.BackColor = System.Drawing.Color.Cornsilk;
            this.label69.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label69.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label69.Location = new System.Drawing.Point(196, 12);
            this.label69.Name = "label69";
            this.label69.Padding = new System.Windows.Forms.Padding(3);
            this.label69.Size = new System.Drawing.Size(97, 34);
            this.label69.TabIndex = 140;
            this.label69.Text = "          First \r\n      Extension      ";
            // 
            // msk_dtpTV_SEdate
            // 
            this.msk_dtpTV_SEdate.Location = new System.Drawing.Point(297, 51);
            this.msk_dtpTV_SEdate.Name = "msk_dtpTV_SEdate";
            this.msk_dtpTV_SEdate.Size = new System.Drawing.Size(71, 20);
            this.msk_dtpTV_SEdate.TabIndex = 221;
            this.msk_dtpTV_SEdate.TextChanged += new System.EventHandler(this.msk_dtpTV_SEdate_TextChanged);
            this.msk_dtpTV_SEdate.Leave += new System.EventHandler(this.msk_dtpTV_SEdate_Leave);
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.BackColor = System.Drawing.Color.Cornsilk;
            this.label68.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label68.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label68.Location = new System.Drawing.Point(297, 12);
            this.label68.Name = "label68";
            this.label68.Padding = new System.Windows.Forms.Padding(3);
            this.label68.Size = new System.Drawing.Size(97, 34);
            this.label68.TabIndex = 141;
            this.label68.Text = "          Last \r\n      Extension      ";
            // 
            // msk_dtpTBV_FEdate
            // 
            this.msk_dtpTBV_FEdate.Location = new System.Drawing.Point(197, 73);
            this.msk_dtpTBV_FEdate.Name = "msk_dtpTBV_FEdate";
            this.msk_dtpTBV_FEdate.Size = new System.Drawing.Size(70, 20);
            this.msk_dtpTBV_FEdate.TabIndex = 220;
            this.msk_dtpTBV_FEdate.Leave += new System.EventHandler(this.msk_dtpTBV_FEdate_Leave);
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.BackColor = System.Drawing.Color.Cornsilk;
            this.label67.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label67.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label67.Location = new System.Drawing.Point(397, 12);
            this.label67.Name = "label67";
            this.label67.Padding = new System.Windows.Forms.Padding(3);
            this.label67.Size = new System.Drawing.Size(54, 34);
            this.label67.TabIndex = 142;
            this.label67.Text = " Days to\r\n  Expire";
            // 
            // msk_dtpTV_FEdate
            // 
            this.msk_dtpTV_FEdate.Location = new System.Drawing.Point(196, 50);
            this.msk_dtpTV_FEdate.Name = "msk_dtpTV_FEdate";
            this.msk_dtpTV_FEdate.Size = new System.Drawing.Size(71, 20);
            this.msk_dtpTV_FEdate.TabIndex = 219;
            this.msk_dtpTV_FEdate.ModifiedChanged += new System.EventHandler(this.msk_dtpTV_FEdate_ModifiedChanged);
            this.msk_dtpTV_FEdate.TextChanged += new System.EventHandler(this.msk_dtpTV_FEdate_TextChanged);
            this.msk_dtpTV_FEdate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.msk_dtpTV_FEdate_KeyPress);
            this.msk_dtpTV_FEdate.Leave += new System.EventHandler(this.msk_dtpTV_FEdate_Leave);
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.ForeColor = System.Drawing.Color.Black;
            this.label66.Location = new System.Drawing.Point(29, 52);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(77, 13);
            this.label66.TabIndex = 143;
            this.label66.Text = "Tender Validity";
            // 
            // msk_dtpTBV_OrgDate
            // 
            this.msk_dtpTBV_OrgDate.Location = new System.Drawing.Point(110, 73);
            this.msk_dtpTBV_OrgDate.Name = "msk_dtpTBV_OrgDate";
            this.msk_dtpTBV_OrgDate.ReadOnly = true;
            this.msk_dtpTBV_OrgDate.Size = new System.Drawing.Size(81, 20);
            this.msk_dtpTBV_OrgDate.TabIndex = 218;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.ForeColor = System.Drawing.Color.Black;
            this.label54.Location = new System.Drawing.Point(3, 77);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(105, 13);
            this.label54.TabIndex = 144;
            this.label54.Text = "Tender Bond Validity";
            // 
            // msk_dtpTV_OrgDate
            // 
            this.msk_dtpTV_OrgDate.Location = new System.Drawing.Point(110, 50);
            this.msk_dtpTV_OrgDate.Name = "msk_dtpTV_OrgDate";
            this.msk_dtpTV_OrgDate.ReadOnly = true;
            this.msk_dtpTV_OrgDate.Size = new System.Drawing.Size(81, 20);
            this.msk_dtpTV_OrgDate.TabIndex = 217;
            // 
            // dtpTBV_FEdate
            // 
            this.dtpTBV_FEdate.Checked = false;
            this.dtpTBV_FEdate.CustomFormat = "  ";
            this.dtpTBV_FEdate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTBV_FEdate.Location = new System.Drawing.Point(196, 73);
            this.dtpTBV_FEdate.Name = "dtpTBV_FEdate";
            this.dtpTBV_FEdate.ShowCheckBox = true;
            this.dtpTBV_FEdate.Size = new System.Drawing.Size(97, 20);
            this.dtpTBV_FEdate.TabIndex = 193;
            this.dtpTBV_FEdate.ValueChanged += new System.EventHandler(this.dtpTBV_FEdate_ValueChanged);
            // 
            // dtpTBV_SEdate
            // 
            this.dtpTBV_SEdate.Checked = false;
            this.dtpTBV_SEdate.CustomFormat = "  ";
            this.dtpTBV_SEdate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTBV_SEdate.Location = new System.Drawing.Point(297, 73);
            this.dtpTBV_SEdate.Name = "dtpTBV_SEdate";
            this.dtpTBV_SEdate.ShowCheckBox = true;
            this.dtpTBV_SEdate.Size = new System.Drawing.Size(97, 20);
            this.dtpTBV_SEdate.TabIndex = 194;
            this.dtpTBV_SEdate.ValueChanged += new System.EventHandler(this.dtpTBV_SEdate_ValueChanged);
            // 
            // dtpTV_SEdate
            // 
            this.dtpTV_SEdate.Checked = false;
            this.dtpTV_SEdate.CustomFormat = "  ";
            this.dtpTV_SEdate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTV_SEdate.Location = new System.Drawing.Point(297, 51);
            this.dtpTV_SEdate.Name = "dtpTV_SEdate";
            this.dtpTV_SEdate.ShowCheckBox = true;
            this.dtpTV_SEdate.Size = new System.Drawing.Size(97, 20);
            this.dtpTV_SEdate.TabIndex = 190;
            this.dtpTV_SEdate.ValueChanged += new System.EventHandler(this.dtpTV_SEdate_ValueChanged);
            // 
            // txtTV_exipre
            // 
            this.txtTV_exipre.Enabled = false;
            this.txtTV_exipre.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTV_exipre.Location = new System.Drawing.Point(400, 50);
            this.txtTV_exipre.Name = "txtTV_exipre";
            this.txtTV_exipre.Size = new System.Drawing.Size(51, 20);
            this.txtTV_exipre.TabIndex = 204;
            // 
            // dtpTV_FEdate
            // 
            this.dtpTV_FEdate.Checked = false;
            this.dtpTV_FEdate.CustomFormat = "  ";
            this.dtpTV_FEdate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTV_FEdate.Location = new System.Drawing.Point(196, 50);
            this.dtpTV_FEdate.Name = "dtpTV_FEdate";
            this.dtpTV_FEdate.ShowCheckBox = true;
            this.dtpTV_FEdate.Size = new System.Drawing.Size(97, 20);
            this.dtpTV_FEdate.TabIndex = 189;
            this.dtpTV_FEdate.ValueChanged += new System.EventHandler(this.dtpTV_FEdate_ValueChanged);
            // 
            // txtTBV_exipre
            // 
            this.txtTBV_exipre.Enabled = false;
            this.txtTBV_exipre.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTBV_exipre.Location = new System.Drawing.Point(400, 73);
            this.txtTBV_exipre.Name = "txtTBV_exipre";
            this.txtTBV_exipre.Size = new System.Drawing.Size(51, 20);
            this.txtTBV_exipre.TabIndex = 205;
            // 
            // msk_dtpEA_closeDate
            // 
            this.msk_dtpEA_closeDate.Location = new System.Drawing.Point(264, 172);
            this.msk_dtpEA_closeDate.Name = "msk_dtpEA_closeDate";
            this.msk_dtpEA_closeDate.ReadOnly = true;
            this.msk_dtpEA_closeDate.Size = new System.Drawing.Size(115, 20);
            this.msk_dtpEA_closeDate.TabIndex = 216;
            this.msk_dtpEA_closeDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // msk_dtpEA_stage2
            // 
            this.msk_dtpEA_stage2.Location = new System.Drawing.Point(65, 194);
            this.msk_dtpEA_stage2.Name = "msk_dtpEA_stage2";
            this.msk_dtpEA_stage2.ReadOnly = true;
            this.msk_dtpEA_stage2.Size = new System.Drawing.Size(114, 20);
            this.msk_dtpEA_stage2.TabIndex = 215;
            this.msk_dtpEA_stage2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // msk_dtpEA_stage1
            // 
            this.msk_dtpEA_stage1.Location = new System.Drawing.Point(65, 168);
            this.msk_dtpEA_stage1.Name = "msk_dtpEA_stage1";
            this.msk_dtpEA_stage1.ReadOnly = true;
            this.msk_dtpEA_stage1.Size = new System.Drawing.Size(114, 20);
            this.msk_dtpEA_stage1.TabIndex = 214;
            this.msk_dtpEA_stage1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // msk_dtpEA_apprDate
            // 
            this.msk_dtpEA_apprDate.Location = new System.Drawing.Point(817, 73);
            this.msk_dtpEA_apprDate.Name = "msk_dtpEA_apprDate";
            this.msk_dtpEA_apprDate.Size = new System.Drawing.Size(94, 20);
            this.msk_dtpEA_apprDate.TabIndex = 213;
            this.msk_dtpEA_apprDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.msk_dtpEA_apprDate.Leave += new System.EventHandler(this.msk_dtpEA_apprDate_Leave);
            // 
            // msk_dtpFE_daterecFin1
            // 
            this.msk_dtpFE_daterecFin1.Location = new System.Drawing.Point(706, 74);
            this.msk_dtpFE_daterecFin1.Name = "msk_dtpFE_daterecFin1";
            this.msk_dtpFE_daterecFin1.Size = new System.Drawing.Size(81, 20);
            this.msk_dtpFE_daterecFin1.TabIndex = 212;
            this.msk_dtpFE_daterecFin1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.msk_dtpFE_daterecFin1.Leave += new System.EventHandler(this.msk_dtpEA_daterecFin_Leave);
            // 
            // msk_dtpFE_datesentfin1
            // 
            this.msk_dtpFE_datesentfin1.Location = new System.Drawing.Point(545, 74);
            this.msk_dtpFE_datesentfin1.Name = "msk_dtpFE_datesentfin1";
            this.msk_dtpFE_datesentfin1.Size = new System.Drawing.Size(83, 20);
            this.msk_dtpFE_datesentfin1.TabIndex = 211;
            this.msk_dtpFE_datesentfin1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.msk_dtpFE_datesentfin1.Leave += new System.EventHandler(this.msk_dtpEA_datesentfin_Leave);
            // 
            // msk_dtpTE_daterec1
            // 
            this.msk_dtpTE_daterec1.Location = new System.Drawing.Point(424, 74);
            this.msk_dtpTE_daterec1.Name = "msk_dtpTE_daterec1";
            this.msk_dtpTE_daterec1.Size = new System.Drawing.Size(84, 20);
            this.msk_dtpTE_daterec1.TabIndex = 210;
            this.msk_dtpTE_daterec1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.msk_dtpTE_daterec1.Leave += new System.EventHandler(this.msk_dtpEA_daterec_Leave);
            // 
            // msk_dtpTE_datesent1
            // 
            this.msk_dtpTE_datesent1.Location = new System.Drawing.Point(262, 74);
            this.msk_dtpTE_datesent1.Name = "msk_dtpTE_datesent1";
            this.msk_dtpTE_datesent1.Size = new System.Drawing.Size(88, 20);
            this.msk_dtpTE_datesent1.TabIndex = 209;
            this.msk_dtpTE_datesent1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.msk_dtpTE_datesent1.Leave += new System.EventHandler(this.msk_dtpTE_datesent1_Leave);
            // 
            // msk_dtpEA_reqdate
            // 
            this.msk_dtpEA_reqdate.Location = new System.Drawing.Point(24, 74);
            this.msk_dtpEA_reqdate.Name = "msk_dtpEA_reqdate";
            this.msk_dtpEA_reqdate.Size = new System.Drawing.Size(85, 20);
            this.msk_dtpEA_reqdate.TabIndex = 208;
            this.msk_dtpEA_reqdate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.msk_dtpEA_reqdate.TextChanged += new System.EventHandler(this.msk_dtpEA_reqdate_TextChanged);
            this.msk_dtpEA_reqdate.Leave += new System.EventHandler(this.msk_dtpEA_reqdate_Leave);
            // 
            // msk_dtpEA_recfromcd
            // 
            this.msk_dtpEA_recfromcd.Location = new System.Drawing.Point(141, 74);
            this.msk_dtpEA_recfromcd.Name = "msk_dtpEA_recfromcd";
            this.msk_dtpEA_recfromcd.Size = new System.Drawing.Size(85, 20);
            this.msk_dtpEA_recfromcd.TabIndex = 207;
            this.msk_dtpEA_recfromcd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.msk_dtpEA_recfromcd.Leave += new System.EventHandler(this.msk_dtpEA_recfromcd_Leave);
            // 
            // dgvTE_Sent
            // 
            this.dgvTE_Sent.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTE_Sent.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle28.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle28.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle28.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTE_Sent.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle28;
            this.dgvTE_Sent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle29.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle29.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle29.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle29.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvTE_Sent.DefaultCellStyle = dataGridViewCellStyle29;
            this.dgvTE_Sent.Location = new System.Drawing.Point(526, 412);
            this.dgvTE_Sent.Name = "dgvTE_Sent";
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle30.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle30.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle30.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle30.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle30.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTE_Sent.RowHeadersDefaultCellStyle = dataGridViewCellStyle30;
            this.dgvTE_Sent.RowHeadersVisible = false;
            this.dgvTE_Sent.Size = new System.Drawing.Size(451, 88);
            this.dgvTE_Sent.TabIndex = 203;
            this.dgvTE_Sent.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTE_Sent_CellClick);
            // 
            // lblTE_estimateAmnt
            // 
            this.lblTE_estimateAmnt.AutoSize = true;
            this.lblTE_estimateAmnt.BackColor = System.Drawing.Color.Cornsilk;
            this.lblTE_estimateAmnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTE_estimateAmnt.ForeColor = System.Drawing.Color.Black;
            this.lblTE_estimateAmnt.Location = new System.Drawing.Point(769, 318);
            this.lblTE_estimateAmnt.Name = "lblTE_estimateAmnt";
            this.lblTE_estimateAmnt.Size = new System.Drawing.Size(77, 13);
            this.lblTE_estimateAmnt.TabIndex = 154;
            this.lblTE_estimateAmnt.Text = "Estimated Cost";
            // 
            // lblTE_bdgtAmt
            // 
            this.lblTE_bdgtAmt.AutoSize = true;
            this.lblTE_bdgtAmt.BackColor = System.Drawing.Color.Cornsilk;
            this.lblTE_bdgtAmt.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTE_bdgtAmt.ForeColor = System.Drawing.Color.Black;
            this.lblTE_bdgtAmt.Location = new System.Drawing.Point(530, 318);
            this.lblTE_bdgtAmt.Name = "lblTE_bdgtAmt";
            this.lblTE_bdgtAmt.Size = new System.Drawing.Size(80, 13);
            this.lblTE_bdgtAmt.TabIndex = 153;
            this.lblTE_bdgtAmt.Text = "Budget Amount";
            // 
            // txtEstimatedAmnt
            // 
            this.txtEstimatedAmnt.Location = new System.Drawing.Point(850, 315);
            this.txtEstimatedAmnt.Name = "txtEstimatedAmnt";
            this.txtEstimatedAmnt.Size = new System.Drawing.Size(139, 20);
            this.txtEstimatedAmnt.TabIndex = 155;
            this.txtEstimatedAmnt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEstimatedAmnt_KeyPress);
            this.txtEstimatedAmnt.Leave += new System.EventHandler(this.txtEstimatedAmnt_Leave);
            // 
            // txtBudjetAmnt
            // 
            this.txtBudjetAmnt.Location = new System.Drawing.Point(622, 315);
            this.txtBudjetAmnt.Name = "txtBudjetAmnt";
            this.txtBudjetAmnt.Size = new System.Drawing.Size(146, 20);
            this.txtBudjetAmnt.TabIndex = 156;
            this.txtBudjetAmnt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBudjetAmnt_KeyPress);
            this.txtBudjetAmnt.Leave += new System.EventHandler(this.txtBudjetAmnt_Leave);
            // 
            // txtEA_Noofmeetings
            // 
            this.txtEA_Noofmeetings.Location = new System.Drawing.Point(943, 73);
            this.txtEA_Noofmeetings.Name = "txtEA_Noofmeetings";
            this.txtEA_Noofmeetings.Size = new System.Drawing.Size(79, 20);
            this.txtEA_Noofmeetings.TabIndex = 168;
            this.txtEA_Noofmeetings.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEA_Noofmeetings_KeyPress);
            // 
            // dgvTE_Rec
            // 
            this.dgvTE_Rec.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTE_Rec.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle31.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle31.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle31.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle31.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle31.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle31.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTE_Rec.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle31;
            this.dgvTE_Rec.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle32.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle32.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle32.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle32.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle32.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle32.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvTE_Rec.DefaultCellStyle = dataGridViewCellStyle32;
            this.dgvTE_Rec.Location = new System.Drawing.Point(65, 412);
            this.dgvTE_Rec.Name = "dgvTE_Rec";
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle33.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle33.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle33.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle33.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle33.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle33.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTE_Rec.RowHeadersDefaultCellStyle = dataGridViewCellStyle33;
            this.dgvTE_Rec.RowHeadersVisible = false;
            this.dgvTE_Rec.Size = new System.Drawing.Size(452, 88);
            this.dgvTE_Rec.TabIndex = 202;
            this.dgvTE_Rec.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTE_Rec_CellClick);
            // 
            // btnSent_TEA
            // 
            this.btnSent_TEA.BackColor = System.Drawing.Color.Maroon;
            this.btnSent_TEA.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSent_TEA.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSent_TEA.ForeColor = System.Drawing.Color.White;
            this.btnSent_TEA.Location = new System.Drawing.Point(526, 382);
            this.btnSent_TEA.Name = "btnSent_TEA";
            this.btnSent_TEA.Size = new System.Drawing.Size(98, 23);
            this.btnSent_TEA.TabIndex = 201;
            this.btnSent_TEA.Text = "Sent Document";
            this.btnSent_TEA.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSent_TEA.UseVisualStyleBackColor = false;
            this.btnSent_TEA.Click += new System.EventHandler(this.btnSent_TEA_Click);
            // 
            // btnRecDocTE
            // 
            this.btnRecDocTE.BackColor = System.Drawing.Color.Maroon;
            this.btnRecDocTE.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRecDocTE.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRecDocTE.ForeColor = System.Drawing.Color.White;
            this.btnRecDocTE.Location = new System.Drawing.Point(66, 382);
            this.btnRecDocTE.Name = "btnRecDocTE";
            this.btnRecDocTE.Size = new System.Drawing.Size(113, 23);
            this.btnRecDocTE.TabIndex = 200;
            this.btnRecDocTE.Text = "Recieved Document";
            this.btnRecDocTE.UseVisualStyleBackColor = false;
            this.btnRecDocTE.Click += new System.EventHandler(this.btnRecDocTE_Click);
            // 
            // btnTE_Save
            // 
            this.btnTE_Save.BackColor = System.Drawing.Color.Maroon;
            this.btnTE_Save.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTE_Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTE_Save.ForeColor = System.Drawing.Color.White;
            this.btnTE_Save.Location = new System.Drawing.Point(711, 178);
            this.btnTE_Save.Name = "btnTE_Save";
            this.btnTE_Save.Size = new System.Drawing.Size(58, 24);
            this.btnTE_Save.TabIndex = 197;
            this.btnTE_Save.Text = "Save";
            this.btnTE_Save.UseVisualStyleBackColor = false;
            this.btnTE_Save.Click += new System.EventHandler(this.btnTE_Save_Click);
            // 
            // dtpEA_recfromcd
            // 
            this.dtpEA_recfromcd.Checked = false;
            this.dtpEA_recfromcd.CustomFormat = "  ";
            this.dtpEA_recfromcd.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpEA_recfromcd.Location = new System.Drawing.Point(143, 74);
            this.dtpEA_recfromcd.Name = "dtpEA_recfromcd";
            this.dtpEA_recfromcd.ShowCheckBox = true;
            this.dtpEA_recfromcd.Size = new System.Drawing.Size(113, 20);
            this.dtpEA_recfromcd.TabIndex = 185;
            this.dtpEA_recfromcd.Value = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.dtpEA_recfromcd.ValueChanged += new System.EventHandler(this.dtpEA_recfromcd_ValueChanged);
            // 
            // dtpEA_apprDate
            // 
            this.dtpEA_apprDate.Checked = false;
            this.dtpEA_apprDate.CustomFormat = "   ";
            this.dtpEA_apprDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpEA_apprDate.Location = new System.Drawing.Point(816, 73);
            this.dtpEA_apprDate.Name = "dtpEA_apprDate";
            this.dtpEA_apprDate.ShowCheckBox = true;
            this.dtpEA_apprDate.Size = new System.Drawing.Size(124, 20);
            this.dtpEA_apprDate.TabIndex = 184;
            this.dtpEA_apprDate.Value = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.dtpEA_apprDate.ValueChanged += new System.EventHandler(this.dtpEA_apprDate_ValueChanged);
            // 
            // dtpFE_daterecFin1
            // 
            this.dtpFE_daterecFin1.Checked = false;
            this.dtpFE_daterecFin1.CustomFormat = "  ";
            this.dtpFE_daterecFin1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFE_daterecFin1.Location = new System.Drawing.Point(706, 74);
            this.dtpFE_daterecFin1.Name = "dtpFE_daterecFin1";
            this.dtpFE_daterecFin1.ShowCheckBox = true;
            this.dtpFE_daterecFin1.Size = new System.Drawing.Size(104, 20);
            this.dtpFE_daterecFin1.TabIndex = 183;
            this.dtpFE_daterecFin1.Value = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.dtpFE_daterecFin1.ValueChanged += new System.EventHandler(this.dtpEA_daterecFin_ValueChanged);
            // 
            // dtpFE_datesentfin1
            // 
            this.dtpFE_datesentfin1.Checked = false;
            this.dtpFE_datesentfin1.CustomFormat = "  ";
            this.dtpFE_datesentfin1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFE_datesentfin1.Location = new System.Drawing.Point(545, 74);
            this.dtpFE_datesentfin1.Name = "dtpFE_datesentfin1";
            this.dtpFE_datesentfin1.ShowCheckBox = true;
            this.dtpFE_datesentfin1.Size = new System.Drawing.Size(113, 20);
            this.dtpFE_datesentfin1.TabIndex = 182;
            this.dtpFE_datesentfin1.Value = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.dtpFE_datesentfin1.ValueChanged += new System.EventHandler(this.dtpEA_datesentfin_ValueChanged);
            // 
            // dtpTE_daterec1
            // 
            this.dtpTE_daterec1.Checked = false;
            this.dtpTE_daterec1.CustomFormat = "  ";
            this.dtpTE_daterec1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTE_daterec1.Location = new System.Drawing.Point(424, 74);
            this.dtpTE_daterec1.Name = "dtpTE_daterec1";
            this.dtpTE_daterec1.ShowCheckBox = true;
            this.dtpTE_daterec1.Size = new System.Drawing.Size(114, 20);
            this.dtpTE_daterec1.TabIndex = 181;
            this.dtpTE_daterec1.Value = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.dtpTE_daterec1.ValueChanged += new System.EventHandler(this.dtpEA_daterec_ValueChanged);
            // 
            // dtpTE_datesent1
            // 
            this.dtpTE_datesent1.Checked = false;
            this.dtpTE_datesent1.CustomFormat = "  ";
            this.dtpTE_datesent1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTE_datesent1.Location = new System.Drawing.Point(266, 74);
            this.dtpTE_datesent1.Name = "dtpTE_datesent1";
            this.dtpTE_datesent1.ShowCheckBox = true;
            this.dtpTE_datesent1.Size = new System.Drawing.Size(114, 20);
            this.dtpTE_datesent1.TabIndex = 180;
            this.dtpTE_datesent1.Value = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.dtpTE_datesent1.ValueChanged += new System.EventHandler(this.dtpEA_datesent_ValueChanged);
            // 
            // dtpEA_reqdate
            // 
            this.dtpEA_reqdate.CalendarMonthBackground = System.Drawing.Color.White;
            this.dtpEA_reqdate.Checked = false;
            this.dtpEA_reqdate.CustomFormat = "  ";
            this.dtpEA_reqdate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpEA_reqdate.Location = new System.Drawing.Point(25, 74);
            this.dtpEA_reqdate.Name = "dtpEA_reqdate";
            this.dtpEA_reqdate.ShowCheckBox = true;
            this.dtpEA_reqdate.Size = new System.Drawing.Size(110, 20);
            this.dtpEA_reqdate.TabIndex = 179;
            this.dtpEA_reqdate.Value = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.dtpEA_reqdate.ValueChanged += new System.EventHandler(this.dtpEA_reqdate_ValueChanged);
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.BackColor = System.Drawing.Color.Gainsboro;
            this.label82.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label82.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label82.ForeColor = System.Drawing.Color.Chocolate;
            this.label82.Location = new System.Drawing.Point(707, 43);
            this.label82.Name = "label82";
            this.label82.Padding = new System.Windows.Forms.Padding(2);
            this.label82.Size = new System.Drawing.Size(105, 21);
            this.label82.TabIndex = 172;
            this.label82.Text = "Date Recieved    ";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.BackColor = System.Drawing.Color.Gainsboro;
            this.label81.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label81.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label81.ForeColor = System.Drawing.Color.Chocolate;
            this.label81.Location = new System.Drawing.Point(426, 43);
            this.label81.Name = "label81";
            this.label81.Padding = new System.Windows.Forms.Padding(2);
            this.label81.Size = new System.Drawing.Size(114, 21);
            this.label81.TabIndex = 171;
            this.label81.Text = "  Date Recieved     ";
            this.label81.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.BackColor = System.Drawing.Color.Gainsboro;
            this.label80.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label80.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label80.ForeColor = System.Drawing.Color.Chocolate;
            this.label80.Location = new System.Drawing.Point(546, 43);
            this.label80.Name = "label80";
            this.label80.Padding = new System.Windows.Forms.Padding(2);
            this.label80.Size = new System.Drawing.Size(110, 21);
            this.label80.TabIndex = 170;
            this.label80.Text = "   Date Send          ";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.BackColor = System.Drawing.Color.Gainsboro;
            this.label73.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label73.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label73.ForeColor = System.Drawing.Color.Chocolate;
            this.label73.Location = new System.Drawing.Point(263, 43);
            this.label73.Name = "label73";
            this.label73.Padding = new System.Windows.Forms.Padding(2);
            this.label73.Size = new System.Drawing.Size(116, 21);
            this.label73.TabIndex = 169;
            this.label73.Text = "     Date Send          ";
            this.label73.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.BackColor = System.Drawing.Color.Gainsboro;
            this.label74.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label74.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label74.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.ForeColor = System.Drawing.Color.Chocolate;
            this.label74.Location = new System.Drawing.Point(944, 16);
            this.label74.Name = "label74";
            this.label74.Padding = new System.Windows.Forms.Padding(8);
            this.label74.Size = new System.Drawing.Size(79, 48);
            this.label74.TabIndex = 162;
            this.label74.Text = "  No.Of    \r\nMeetings ";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.BackColor = System.Drawing.Color.Gainsboro;
            this.label75.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label75.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label75.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label75.ForeColor = System.Drawing.Color.Chocolate;
            this.label75.Location = new System.Drawing.Point(818, 16);
            this.label75.Name = "label75";
            this.label75.Padding = new System.Windows.Forms.Padding(8);
            this.label75.Size = new System.Drawing.Size(125, 48);
            this.label75.TabIndex = 161;
            this.label75.Text = "    Tender Award    \r\n     Approval Date\r\n";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.BackColor = System.Drawing.Color.Gainsboro;
            this.label76.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label76.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.ForeColor = System.Drawing.Color.Chocolate;
            this.label76.Location = new System.Drawing.Point(546, 16);
            this.label76.Name = "label76";
            this.label76.Padding = new System.Windows.Forms.Padding(4);
            this.label76.Size = new System.Drawing.Size(265, 25);
            this.label76.TabIndex = 160;
            this.label76.Text = "                         Financial Evaluation                     ";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.BackColor = System.Drawing.Color.Gainsboro;
            this.label77.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label77.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label77.ForeColor = System.Drawing.Color.Chocolate;
            this.label77.Location = new System.Drawing.Point(263, 16);
            this.label77.Name = "label77";
            this.label77.Padding = new System.Windows.Forms.Padding(4);
            this.label77.Size = new System.Drawing.Size(277, 25);
            this.label77.TabIndex = 159;
            this.label77.Text = "                          Technical Evaluation                       ";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.BackColor = System.Drawing.Color.Gainsboro;
            this.label78.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label78.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label78.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label78.ForeColor = System.Drawing.Color.Chocolate;
            this.label78.Location = new System.Drawing.Point(141, 16);
            this.label78.Name = "label78";
            this.label78.Padding = new System.Windows.Forms.Padding(8);
            this.label78.Size = new System.Drawing.Size(116, 48);
            this.label78.TabIndex = 158;
            this.label78.Text = "  Doc Received   \r\n         From CD\r\n";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.BackColor = System.Drawing.Color.Gainsboro;
            this.label79.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label79.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label79.ForeColor = System.Drawing.Color.Chocolate;
            this.label79.Location = new System.Drawing.Point(24, 16);
            this.label79.Name = "label79";
            this.label79.Padding = new System.Windows.Forms.Padding(8);
            this.label79.Size = new System.Drawing.Size(115, 48);
            this.label79.TabIndex = 157;
            this.label79.Text = "      Tender           \r\n  Open Date\r\n";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.ForeColor = System.Drawing.Color.Black;
            this.label55.Location = new System.Drawing.Point(185, 201);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(41, 13);
            this.label55.TabIndex = 138;
            this.label55.Text = "Stage2";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.ForeColor = System.Drawing.Color.Black;
            this.label63.Location = new System.Drawing.Point(185, 175);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(41, 13);
            this.label63.TabIndex = 137;
            this.label63.Text = "Stage1";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.BackColor = System.Drawing.Color.Gainsboro;
            this.label64.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label64.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.ForeColor = System.Drawing.Color.Chocolate;
            this.label64.Location = new System.Drawing.Point(65, 117);
            this.label64.Name = "label64";
            this.label64.Padding = new System.Windows.Forms.Padding(8);
            this.label64.Size = new System.Drawing.Size(114, 48);
            this.label64.TabIndex = 134;
            this.label64.Text = " Tender Closing \r\n      Date\r\n";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.BackColor = System.Drawing.Color.Gainsboro;
            this.label65.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label65.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.ForeColor = System.Drawing.Color.Chocolate;
            this.label65.Location = new System.Drawing.Point(264, 117);
            this.label65.Name = "label65";
            this.label65.Padding = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.label65.Size = new System.Drawing.Size(115, 48);
            this.label65.TabIndex = 132;
            this.label65.Text = "Modified Closing\r\n         Date";
            // 
            // tsTabPage
            // 
            this.tsTabPage.AutoScroll = true;
            this.tsTabPage.BackColor = System.Drawing.Color.Cornsilk;
            this.tsTabPage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tsTabPage.Controls.Add(this.groupBox3);
            this.tsTabPage.Location = new System.Drawing.Point(4, 34);
            this.tsTabPage.Name = "tsTabPage";
            this.tsTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.tsTabPage.Size = new System.Drawing.Size(1039, 547);
            this.tsTabPage.TabIndex = 1;
            this.tsTabPage.Text = "TENDERING STAGE   ";
            this.tsTabPage.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.AutoSize = true;
            this.groupBox3.BackColor = System.Drawing.Color.Cornsilk;
            this.groupBox3.Controls.Add(this.msk_dtp_tsModifiedDate_Stage2);
            this.groupBox3.Controls.Add(this.dtp_tsModifiedDate_Stage2);
            this.groupBox3.Controls.Add(this.btnClk);
            this.groupBox3.Controls.Add(this.lbltype);
            this.groupBox3.Controls.Add(this.txtCmpType);
            this.groupBox3.Controls.Add(this.lblDateCnt);
            this.groupBox3.Controls.Add(this.txtTotCompInShortList);
            this.groupBox3.Controls.Add(this.lblCompaniesInShortList);
            this.groupBox3.Controls.Add(this.btnViewShortList);
            this.groupBox3.Controls.Add(this.btnExportToPdf);
            this.groupBox3.Controls.Add(this.lblDFTenderBondCur);
            this.groupBox3.Controls.Add(this.lblTSTenderBondCur);
            this.groupBox3.Controls.Add(this.grpEligibleCompanies);
            this.groupBox3.Controls.Add(this.btnViewBidder);
            this.groupBox3.Controls.Add(this.txtCircular);
            this.groupBox3.Controls.Add(this.lblTotCircularIssued);
            this.groupBox3.Controls.Add(this.btnRecDocTS);
            this.groupBox3.Controls.Add(this.msk_dtp_tsModifiedDate_Stage1);
            this.groupBox3.Controls.Add(this.btnSentDocTS);
            this.groupBox3.Controls.Add(this.dgvTS_Rec);
            this.groupBox3.Controls.Add(this.msk_dtp_tsStage2);
            this.groupBox3.Controls.Add(this.dgvTS_Sent);
            this.groupBox3.Controls.Add(this.msk_dtp_tsStage1);
            this.groupBox3.Controls.Add(this.msk_dtp_tsInvitation);
            this.groupBox3.Controls.Add(this.msk_dtp_tsAdvertisement);
            this.groupBox3.Controls.Add(this.msk_dtp_tsRecFromDept);
            this.groupBox3.Controls.Add(this.msk_dtp_tsReturnDept);
            this.groupBox3.Controls.Add(this.msk_dtp_tsRecOn);
            this.groupBox3.Controls.Add(this.label59);
            this.groupBox3.Controls.Add(this.lblTenderProjTitle);
            this.groupBox3.Controls.Add(this.txt_tsRemarks);
            this.groupBox3.Controls.Add(this.lblBondAmt);
            this.groupBox3.Controls.Add(this.btnIssueTender);
            this.groupBox3.Controls.Add(this.btnTS);
            this.groupBox3.Controls.Add(this.lblDocAmt);
            this.groupBox3.Controls.Add(this.dtp_tsInvitation);
            this.groupBox3.Controls.Add(this.label49);
            this.groupBox3.Controls.Add(this.dtp_tsAdvertisement);
            this.groupBox3.Controls.Add(this.label50);
            this.groupBox3.Controls.Add(this.dtp_tsRecFromDept);
            this.groupBox3.Controls.Add(this.label51);
            this.groupBox3.Controls.Add(this.dtp_tsReturnDept);
            this.groupBox3.Controls.Add(this.label52);
            this.groupBox3.Controls.Add(this.dtp_tsModifiedDate_Stage1);
            this.groupBox3.Controls.Add(this.lblTotNoBidders);
            this.groupBox3.Controls.Add(this.dtp_tsStage2);
            this.groupBox3.Controls.Add(this.label57);
            this.groupBox3.Controls.Add(this.dtp_tsStage1);
            this.groupBox3.Controls.Add(this.label56);
            this.groupBox3.Controls.Add(this.txt_bidders);
            this.groupBox3.Controls.Add(this.label60);
            this.groupBox3.Controls.Add(this.txtDocumentFee);
            this.groupBox3.Controls.Add(this.label58);
            this.groupBox3.Controls.Add(this.txtTenderBond);
            this.groupBox3.Controls.Add(this.label61);
            this.groupBox3.Controls.Add(this.cmb_tstenderHandle);
            this.groupBox3.Controls.Add(this.label62);
            this.groupBox3.Controls.Add(this.dtp_tsRecOn);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(3, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1031, 539);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            // 
            // msk_dtp_tsModifiedDate_Stage2
            // 
            this.msk_dtp_tsModifiedDate_Stage2.Location = new System.Drawing.Point(259, 206);
            this.msk_dtp_tsModifiedDate_Stage2.Name = "msk_dtp_tsModifiedDate_Stage2";
            this.msk_dtp_tsModifiedDate_Stage2.Size = new System.Drawing.Size(99, 20);
            this.msk_dtp_tsModifiedDate_Stage2.TabIndex = 153;
            // 
            // dtp_tsModifiedDate_Stage2
            // 
            this.dtp_tsModifiedDate_Stage2.Checked = false;
            this.dtp_tsModifiedDate_Stage2.CustomFormat = "dd/MMM/yyyy";
            this.dtp_tsModifiedDate_Stage2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_tsModifiedDate_Stage2.Location = new System.Drawing.Point(259, 206);
            this.dtp_tsModifiedDate_Stage2.Name = "dtp_tsModifiedDate_Stage2";
            this.dtp_tsModifiedDate_Stage2.ShowCheckBox = true;
            this.dtp_tsModifiedDate_Stage2.Size = new System.Drawing.Size(129, 20);
            this.dtp_tsModifiedDate_Stage2.TabIndex = 152;
            this.dtp_tsModifiedDate_Stage2.ValueChanged += new System.EventHandler(this.dtp_tsModifiedDate_Stage2_ValueChanged);
            // 
            // btnClk
            // 
            this.btnClk.Location = new System.Drawing.Point(367, 308);
            this.btnClk.Name = "btnClk";
            this.btnClk.Size = new System.Drawing.Size(55, 23);
            this.btnClk.TabIndex = 150;
            this.btnClk.Text = "click";
            this.btnClk.UseVisualStyleBackColor = true;
            this.btnClk.Visible = false;
            this.btnClk.Click += new System.EventHandler(this.button1_Click);
            // 
            // lbltype
            // 
            this.lbltype.AutoSize = true;
            this.lbltype.Location = new System.Drawing.Point(86, 313);
            this.lbltype.Name = "lbltype";
            this.lbltype.Size = new System.Drawing.Size(90, 13);
            this.lbltype.TabIndex = 149;
            this.lbltype.Text = "Type of Company";
            this.lbltype.Visible = false;
            // 
            // txtCmpType
            // 
            this.txtCmpType.Location = new System.Drawing.Point(199, 310);
            this.txtCmpType.Name = "txtCmpType";
            this.txtCmpType.Size = new System.Drawing.Size(152, 20);
            this.txtCmpType.TabIndex = 148;
            this.txtCmpType.Visible = false;
            // 
            // lblDateCnt
            // 
            this.lblDateCnt.AutoSize = true;
            this.lblDateCnt.Location = new System.Drawing.Point(396, 211);
            this.lblDateCnt.Name = "lblDateCnt";
            this.lblDateCnt.Size = new System.Drawing.Size(0, 13);
            this.lblDateCnt.TabIndex = 147;
            // 
            // txtTotCompInShortList
            // 
            this.txtTotCompInShortList.BackColor = System.Drawing.SystemColors.Control;
            this.txtTotCompInShortList.Location = new System.Drawing.Point(639, 294);
            this.txtTotCompInShortList.Name = "txtTotCompInShortList";
            this.txtTotCompInShortList.Size = new System.Drawing.Size(48, 20);
            this.txtTotCompInShortList.TabIndex = 145;
            this.txtTotCompInShortList.Visible = false;
            // 
            // lblCompaniesInShortList
            // 
            this.lblCompaniesInShortList.AutoSize = true;
            this.lblCompaniesInShortList.Location = new System.Drawing.Point(502, 299);
            this.lblCompaniesInShortList.Name = "lblCompaniesInShortList";
            this.lblCompaniesInShortList.Size = new System.Drawing.Size(132, 13);
            this.lblCompaniesInShortList.TabIndex = 144;
            this.lblCompaniesInShortList.Text = "Companies in the ShortList";
            this.lblCompaniesInShortList.Visible = false;
            // 
            // btnViewShortList
            // 
            this.btnViewShortList.BackColor = System.Drawing.Color.Maroon;
            this.btnViewShortList.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnViewShortList.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewShortList.ForeColor = System.Drawing.Color.White;
            this.btnViewShortList.Location = new System.Drawing.Point(854, 336);
            this.btnViewShortList.Name = "btnViewShortList";
            this.btnViewShortList.Size = new System.Drawing.Size(102, 26);
            this.btnViewShortList.TabIndex = 143;
            this.btnViewShortList.Text = "View Short List";
            this.btnViewShortList.UseVisualStyleBackColor = false;
            this.btnViewShortList.Visible = false;
            this.btnViewShortList.Click += new System.EventHandler(this.btnViewShortList_Click);
            // 
            // btnExportToPdf
            // 
            this.btnExportToPdf.BackColor = System.Drawing.Color.Maroon;
            this.btnExportToPdf.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnExportToPdf.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExportToPdf.ForeColor = System.Drawing.Color.White;
            this.btnExportToPdf.Location = new System.Drawing.Point(747, 336);
            this.btnExportToPdf.Name = "btnExportToPdf";
            this.btnExportToPdf.Size = new System.Drawing.Size(102, 26);
            this.btnExportToPdf.TabIndex = 141;
            this.btnExportToPdf.Text = "View Report";
            this.btnExportToPdf.UseVisualStyleBackColor = false;
            this.btnExportToPdf.Visible = false;
            this.btnExportToPdf.Click += new System.EventHandler(this.btnExportToPdf_Click);
            // 
            // lblDFTenderBondCur
            // 
            this.lblDFTenderBondCur.AutoSize = true;
            this.lblDFTenderBondCur.BackColor = System.Drawing.SystemColors.Window;
            this.lblDFTenderBondCur.Location = new System.Drawing.Point(930, 275);
            this.lblDFTenderBondCur.Name = "lblDFTenderBondCur";
            this.lblDFTenderBondCur.Size = new System.Drawing.Size(23, 13);
            this.lblDFTenderBondCur.TabIndex = 140;
            this.lblDFTenderBondCur.Text = "QR";
            // 
            // lblTSTenderBondCur
            // 
            this.lblTSTenderBondCur.AutoSize = true;
            this.lblTSTenderBondCur.BackColor = System.Drawing.SystemColors.Window;
            this.lblTSTenderBondCur.Location = new System.Drawing.Point(929, 244);
            this.lblTSTenderBondCur.Name = "lblTSTenderBondCur";
            this.lblTSTenderBondCur.Size = new System.Drawing.Size(23, 13);
            this.lblTSTenderBondCur.TabIndex = 139;
            this.lblTSTenderBondCur.Text = "QR";
            // 
            // grpEligibleCompanies
            // 
            this.grpEligibleCompanies.Controls.Add(this.chkJointVenture);
            this.grpEligibleCompanies.Controls.Add(this.chkInternational);
            this.grpEligibleCompanies.Controls.Add(this.chkLocal);
            this.grpEligibleCompanies.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpEligibleCompanies.Location = new System.Drawing.Point(80, 242);
            this.grpEligibleCompanies.Name = "grpEligibleCompanies";
            this.grpEligibleCompanies.Size = new System.Drawing.Size(342, 63);
            this.grpEligibleCompanies.TabIndex = 138;
            this.grpEligibleCompanies.TabStop = false;
            this.grpEligibleCompanies.Text = "Eligible To Tender";
            // 
            // chkJointVenture
            // 
            this.chkJointVenture.AutoSize = true;
            this.chkJointVenture.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chkJointVenture.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkJointVenture.ForeColor = System.Drawing.Color.MediumSlateBlue;
            this.chkJointVenture.Location = new System.Drawing.Point(213, 26);
            this.chkJointVenture.Name = "chkJointVenture";
            this.chkJointVenture.Size = new System.Drawing.Size(107, 19);
            this.chkJointVenture.TabIndex = 2;
            this.chkJointVenture.Text = "Joint Venture";
            this.chkJointVenture.UseVisualStyleBackColor = true;
            this.chkJointVenture.CheckedChanged += new System.EventHandler(this.grpEligibleCompaniesCheckBoxes_CheckedChanged);
            // 
            // chkInternational
            // 
            this.chkInternational.AutoSize = true;
            this.chkInternational.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chkInternational.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkInternational.ForeColor = System.Drawing.Color.MediumSlateBlue;
            this.chkInternational.Location = new System.Drawing.Point(98, 26);
            this.chkInternational.Name = "chkInternational";
            this.chkInternational.Size = new System.Drawing.Size(104, 19);
            this.chkInternational.TabIndex = 1;
            this.chkInternational.Text = "International";
            this.chkInternational.UseVisualStyleBackColor = true;
            this.chkInternational.CheckedChanged += new System.EventHandler(this.grpEligibleCompaniesCheckBoxes_CheckedChanged);
            // 
            // chkLocal
            // 
            this.chkLocal.AutoSize = true;
            this.chkLocal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chkLocal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkLocal.ForeColor = System.Drawing.Color.MediumSlateBlue;
            this.chkLocal.Location = new System.Drawing.Point(21, 26);
            this.chkLocal.Name = "chkLocal";
            this.chkLocal.Size = new System.Drawing.Size(58, 19);
            this.chkLocal.TabIndex = 0;
            this.chkLocal.Text = "Local";
            this.chkLocal.UseVisualStyleBackColor = true;
            this.chkLocal.CheckedChanged += new System.EventHandler(this.grpEligibleCompaniesCheckBoxes_CheckedChanged);
            // 
            // btnViewBidder
            // 
            this.btnViewBidder.BackColor = System.Drawing.Color.Maroon;
            this.btnViewBidder.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnViewBidder.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewBidder.ForeColor = System.Drawing.Color.White;
            this.btnViewBidder.Location = new System.Drawing.Point(639, 336);
            this.btnViewBidder.Name = "btnViewBidder";
            this.btnViewBidder.Size = new System.Drawing.Size(102, 26);
            this.btnViewBidder.TabIndex = 137;
            this.btnViewBidder.Text = "View Bidders";
            this.btnViewBidder.UseVisualStyleBackColor = false;
            this.btnViewBidder.Visible = false;
            this.btnViewBidder.Click += new System.EventHandler(this.btnViewBidder_Click);
            // 
            // txtCircular
            // 
            this.txtCircular.Location = new System.Drawing.Point(640, 242);
            this.txtCircular.Name = "txtCircular";
            this.txtCircular.ReadOnly = true;
            this.txtCircular.Size = new System.Drawing.Size(47, 20);
            this.txtCircular.TabIndex = 136;
            this.txtCircular.Visible = false;
            // 
            // lblTotCircularIssued
            // 
            this.lblTotCircularIssued.AutoSize = true;
            this.lblTotCircularIssued.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotCircularIssued.Location = new System.Drawing.Point(458, 245);
            this.lblTotCircularIssued.Name = "lblTotCircularIssued";
            this.lblTotCircularIssued.Size = new System.Drawing.Size(176, 13);
            this.lblTotCircularIssued.TabIndex = 135;
            this.lblTotCircularIssued.Text = "Total No Of Tender Circulars Issued";
            this.lblTotCircularIssued.Visible = false;
            // 
            // btnRecDocTS
            // 
            this.btnRecDocTS.BackColor = System.Drawing.Color.Maroon;
            this.btnRecDocTS.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRecDocTS.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRecDocTS.ForeColor = System.Drawing.Color.White;
            this.btnRecDocTS.Location = new System.Drawing.Point(80, 373);
            this.btnRecDocTS.Name = "btnRecDocTS";
            this.btnRecDocTS.Size = new System.Drawing.Size(113, 23);
            this.btnRecDocTS.TabIndex = 131;
            this.btnRecDocTS.Text = "Recieved Document";
            this.btnRecDocTS.UseVisualStyleBackColor = false;
            this.btnRecDocTS.Click += new System.EventHandler(this.btnRecDocTS_Click);
            // 
            // msk_dtp_tsModifiedDate_Stage1
            // 
            this.msk_dtp_tsModifiedDate_Stage1.Location = new System.Drawing.Point(259, 180);
            this.msk_dtp_tsModifiedDate_Stage1.Name = "msk_dtp_tsModifiedDate_Stage1";
            this.msk_dtp_tsModifiedDate_Stage1.Size = new System.Drawing.Size(99, 20);
            this.msk_dtp_tsModifiedDate_Stage1.TabIndex = 133;
            this.msk_dtp_tsModifiedDate_Stage1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.msk_dtp_tsModifiedDate_Stage1.Leave += new System.EventHandler(this.msk_dtp_tsModifiedDate_Leave);
            // 
            // btnSentDocTS
            // 
            this.btnSentDocTS.BackColor = System.Drawing.Color.Maroon;
            this.btnSentDocTS.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSentDocTS.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSentDocTS.ForeColor = System.Drawing.Color.White;
            this.btnSentDocTS.Location = new System.Drawing.Point(543, 373);
            this.btnSentDocTS.Name = "btnSentDocTS";
            this.btnSentDocTS.Size = new System.Drawing.Size(113, 23);
            this.btnSentDocTS.TabIndex = 132;
            this.btnSentDocTS.Text = "Sent Document";
            this.btnSentDocTS.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSentDocTS.UseVisualStyleBackColor = false;
            this.btnSentDocTS.Click += new System.EventHandler(this.btnSentDocTS_Click);
            // 
            // dgvTS_Rec
            // 
            this.dgvTS_Rec.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTS_Rec.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle34.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle34.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle34.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle34.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle34.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTS_Rec.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle34;
            this.dgvTS_Rec.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle35.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle35.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle35.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle35.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle35.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle35.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvTS_Rec.DefaultCellStyle = dataGridViewCellStyle35;
            this.dgvTS_Rec.Location = new System.Drawing.Point(80, 404);
            this.dgvTS_Rec.Name = "dgvTS_Rec";
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle36.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle36.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle36.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle36.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle36.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle36.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTS_Rec.RowHeadersDefaultCellStyle = dataGridViewCellStyle36;
            this.dgvTS_Rec.RowHeadersVisible = false;
            this.dgvTS_Rec.Size = new System.Drawing.Size(441, 74);
            this.dgvTS_Rec.TabIndex = 133;
            this.dgvTS_Rec.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTS_Rec_CellClick);
            // 
            // msk_dtp_tsStage2
            // 
            this.msk_dtp_tsStage2.Location = new System.Drawing.Point(80, 205);
            this.msk_dtp_tsStage2.Name = "msk_dtp_tsStage2";
            this.msk_dtp_tsStage2.Size = new System.Drawing.Size(102, 20);
            this.msk_dtp_tsStage2.TabIndex = 132;
            this.msk_dtp_tsStage2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.msk_dtp_tsStage2.Leave += new System.EventHandler(this.msk_dtp_tsStage2_Leave);
            // 
            // dgvTS_Sent
            // 
            this.dgvTS_Sent.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTS_Sent.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle37.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle37.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle37.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle37.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle37.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle37.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTS_Sent.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle37;
            this.dgvTS_Sent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle38.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle38.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle38.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle38.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle38.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle38.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvTS_Sent.DefaultCellStyle = dataGridViewCellStyle38;
            this.dgvTS_Sent.Location = new System.Drawing.Point(540, 404);
            this.dgvTS_Sent.Name = "dgvTS_Sent";
            dataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle39.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle39.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle39.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle39.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle39.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle39.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTS_Sent.RowHeadersDefaultCellStyle = dataGridViewCellStyle39;
            this.dgvTS_Sent.RowHeadersVisible = false;
            this.dgvTS_Sent.Size = new System.Drawing.Size(428, 74);
            this.dgvTS_Sent.TabIndex = 134;
            this.dgvTS_Sent.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTS_Sent_CellClick);
            // 
            // msk_dtp_tsStage1
            // 
            this.msk_dtp_tsStage1.Location = new System.Drawing.Point(80, 179);
            this.msk_dtp_tsStage1.Name = "msk_dtp_tsStage1";
            this.msk_dtp_tsStage1.Size = new System.Drawing.Size(102, 20);
            this.msk_dtp_tsStage1.TabIndex = 131;
            this.msk_dtp_tsStage1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.msk_dtp_tsStage1.Leave += new System.EventHandler(this.msk_dtp_tsStage1_Leave);
            // 
            // msk_dtp_tsInvitation
            // 
            this.msk_dtp_tsInvitation.Location = new System.Drawing.Point(823, 79);
            this.msk_dtp_tsInvitation.Name = "msk_dtp_tsInvitation";
            this.msk_dtp_tsInvitation.Size = new System.Drawing.Size(102, 20);
            this.msk_dtp_tsInvitation.TabIndex = 130;
            this.msk_dtp_tsInvitation.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.msk_dtp_tsInvitation.Leave += new System.EventHandler(this.msk_dtp_tsInvitation_Leave);
            // 
            // msk_dtp_tsAdvertisement
            // 
            this.msk_dtp_tsAdvertisement.Location = new System.Drawing.Point(666, 80);
            this.msk_dtp_tsAdvertisement.Name = "msk_dtp_tsAdvertisement";
            this.msk_dtp_tsAdvertisement.Size = new System.Drawing.Size(125, 20);
            this.msk_dtp_tsAdvertisement.TabIndex = 129;
            this.msk_dtp_tsAdvertisement.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.msk_dtp_tsAdvertisement.Leave += new System.EventHandler(this.msk_dtp_tsAdvertisement_Leave);
            // 
            // msk_dtp_tsRecFromDept
            // 
            this.msk_dtp_tsRecFromDept.Location = new System.Drawing.Point(527, 80);
            this.msk_dtp_tsRecFromDept.Name = "msk_dtp_tsRecFromDept";
            this.msk_dtp_tsRecFromDept.Size = new System.Drawing.Size(107, 20);
            this.msk_dtp_tsRecFromDept.TabIndex = 128;
            this.msk_dtp_tsRecFromDept.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.msk_dtp_tsRecFromDept.Leave += new System.EventHandler(this.msk_dtp_tsRecFromDept_Leave);
            // 
            // msk_dtp_tsReturnDept
            // 
            this.msk_dtp_tsReturnDept.Location = new System.Drawing.Point(390, 80);
            this.msk_dtp_tsReturnDept.Name = "msk_dtp_tsReturnDept";
            this.msk_dtp_tsReturnDept.Size = new System.Drawing.Size(105, 20);
            this.msk_dtp_tsReturnDept.TabIndex = 127;
            this.msk_dtp_tsReturnDept.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.msk_dtp_tsReturnDept.Leave += new System.EventHandler(this.msk_dtp_tsReturnDept_Leave);
            // 
            // msk_dtp_tsRecOn
            // 
            this.msk_dtp_tsRecOn.Location = new System.Drawing.Point(80, 81);
            this.msk_dtp_tsRecOn.Name = "msk_dtp_tsRecOn";
            this.msk_dtp_tsRecOn.Size = new System.Drawing.Size(105, 20);
            this.msk_dtp_tsRecOn.TabIndex = 126;
            this.msk_dtp_tsRecOn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.msk_dtp_tsRecOn.Leave += new System.EventHandler(this.msk_dtp_tsRecOn_Leave);
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.BackColor = System.Drawing.Color.Gainsboro;
            this.label59.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label59.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label59.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.ForeColor = System.Drawing.Color.Chocolate;
            this.label59.Location = new System.Drawing.Point(80, 26);
            this.label59.Name = "label59";
            this.label59.Padding = new System.Windows.Forms.Padding(8);
            this.label59.Size = new System.Drawing.Size(134, 48);
            this.label59.TabIndex = 95;
            this.label59.Text = "     (For Tendering)   \r\n        Receive On\r\n";
            // 
            // lblTenderProjTitle
            // 
            this.lblTenderProjTitle.AutoSize = true;
            this.lblTenderProjTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTenderProjTitle.Location = new System.Drawing.Point(426, 126);
            this.lblTenderProjTitle.Name = "lblTenderProjTitle";
            this.lblTenderProjTitle.Size = new System.Drawing.Size(49, 13);
            this.lblTenderProjTitle.TabIndex = 74;
            this.lblTenderProjTitle.Text = "Remarks";
            // 
            // txt_tsRemarks
            // 
            this.txt_tsRemarks.Location = new System.Drawing.Point(483, 123);
            this.txt_tsRemarks.Multiline = true;
            this.txt_tsRemarks.Name = "txt_tsRemarks";
            this.txt_tsRemarks.Size = new System.Drawing.Size(472, 74);
            this.txt_tsRemarks.TabIndex = 75;
            // 
            // lblBondAmt
            // 
            this.lblBondAmt.AutoSize = true;
            this.lblBondAmt.Location = new System.Drawing.Point(753, 249);
            this.lblBondAmt.Name = "lblBondAmt";
            this.lblBondAmt.Size = new System.Drawing.Size(69, 13);
            this.lblBondAmt.TabIndex = 76;
            this.lblBondAmt.Text = "Tender Bond";
            // 
            // btnIssueTender
            // 
            this.btnIssueTender.BackColor = System.Drawing.Color.Maroon;
            this.btnIssueTender.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnIssueTender.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIssueTender.ForeColor = System.Drawing.Color.White;
            this.btnIssueTender.Location = new System.Drawing.Point(80, 336);
            this.btnIssueTender.Name = "btnIssueTender";
            this.btnIssueTender.Size = new System.Drawing.Size(122, 26);
            this.btnIssueTender.TabIndex = 82;
            this.btnIssueTender.Text = "Issue a Tender...";
            this.btnIssueTender.UseVisualStyleBackColor = false;
            this.btnIssueTender.Visible = false;
            this.btnIssueTender.Click += new System.EventHandler(this.btnIssueTender_Click);
            // 
            // btnTS
            // 
            this.btnTS.BackColor = System.Drawing.Color.Maroon;
            this.btnTS.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTS.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTS.ForeColor = System.Drawing.Color.White;
            this.btnTS.Location = new System.Drawing.Point(888, 202);
            this.btnTS.Name = "btnTS";
            this.btnTS.Size = new System.Drawing.Size(65, 26);
            this.btnTS.TabIndex = 125;
            this.btnTS.Text = "Save";
            this.btnTS.UseVisualStyleBackColor = false;
            this.btnTS.Click += new System.EventHandler(this.btnTS_Click);
            // 
            // lblDocAmt
            // 
            this.lblDocAmt.AutoSize = true;
            this.lblDocAmt.Location = new System.Drawing.Point(745, 275);
            this.lblDocAmt.Name = "lblDocAmt";
            this.lblDocAmt.Size = new System.Drawing.Size(77, 13);
            this.lblDocAmt.TabIndex = 84;
            this.lblDocAmt.Text = "Document Fee";
            // 
            // dtp_tsInvitation
            // 
            this.dtp_tsInvitation.Checked = false;
            this.dtp_tsInvitation.CustomFormat = "dd/MMM/yyyy";
            this.dtp_tsInvitation.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_tsInvitation.Location = new System.Drawing.Point(823, 79);
            this.dtp_tsInvitation.Name = "dtp_tsInvitation";
            this.dtp_tsInvitation.ShowCheckBox = true;
            this.dtp_tsInvitation.Size = new System.Drawing.Size(132, 20);
            this.dtp_tsInvitation.TabIndex = 122;
            this.dtp_tsInvitation.ValueChanged += new System.EventHandler(this.dtp_tsInvitation_ValueChanged);
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.BackColor = System.Drawing.Color.Gainsboro;
            this.label49.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label49.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.ForeColor = System.Drawing.Color.Chocolate;
            this.label49.Location = new System.Drawing.Point(259, 124);
            this.label49.Name = "label49";
            this.label49.Padding = new System.Windows.Forms.Padding(8);
            this.label49.Size = new System.Drawing.Size(129, 48);
            this.label49.TabIndex = 86;
            this.label49.Text = "   Modified Closing \r\n              Date\r\n";
            // 
            // dtp_tsAdvertisement
            // 
            this.dtp_tsAdvertisement.Checked = false;
            this.dtp_tsAdvertisement.CustomFormat = "dd/MMM/yyyy";
            this.dtp_tsAdvertisement.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_tsAdvertisement.Location = new System.Drawing.Point(666, 80);
            this.dtp_tsAdvertisement.Name = "dtp_tsAdvertisement";
            this.dtp_tsAdvertisement.ShowCheckBox = true;
            this.dtp_tsAdvertisement.Size = new System.Drawing.Size(155, 20);
            this.dtp_tsAdvertisement.TabIndex = 121;
            this.dtp_tsAdvertisement.ValueChanged += new System.EventHandler(this.dtp_tsAdvertisement_ValueChanged);
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.BackColor = System.Drawing.Color.Gainsboro;
            this.label50.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label50.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.ForeColor = System.Drawing.Color.Chocolate;
            this.label50.Location = new System.Drawing.Point(80, 124);
            this.label50.Name = "label50";
            this.label50.Padding = new System.Windows.Forms.Padding(8);
            this.label50.Size = new System.Drawing.Size(132, 48);
            this.label50.TabIndex = 88;
            this.label50.Text = "    Tender Closing    \r\n             Date";
            // 
            // dtp_tsRecFromDept
            // 
            this.dtp_tsRecFromDept.Checked = false;
            this.dtp_tsRecFromDept.CustomFormat = "dd/MMM/yyyy";
            this.dtp_tsRecFromDept.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_tsRecFromDept.Location = new System.Drawing.Point(527, 80);
            this.dtp_tsRecFromDept.Name = "dtp_tsRecFromDept";
            this.dtp_tsRecFromDept.ShowCheckBox = true;
            this.dtp_tsRecFromDept.Size = new System.Drawing.Size(137, 20);
            this.dtp_tsRecFromDept.TabIndex = 120;
            this.dtp_tsRecFromDept.ValueChanged += new System.EventHandler(this.dtp_tsRecFromDept_ValueChanged);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(212, 184);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(41, 13);
            this.label51.TabIndex = 91;
            this.label51.Text = "Stage1";
            // 
            // dtp_tsReturnDept
            // 
            this.dtp_tsReturnDept.Checked = false;
            this.dtp_tsReturnDept.CustomFormat = "dd/MMM/yyyy";
            this.dtp_tsReturnDept.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_tsReturnDept.Location = new System.Drawing.Point(391, 80);
            this.dtp_tsReturnDept.Name = "dtp_tsReturnDept";
            this.dtp_tsReturnDept.ShowCheckBox = true;
            this.dtp_tsReturnDept.Size = new System.Drawing.Size(134, 20);
            this.dtp_tsReturnDept.TabIndex = 119;
            this.dtp_tsReturnDept.ValueChanged += new System.EventHandler(this.dtp_tsReturnDept_ValueChanged);
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(212, 209);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(41, 13);
            this.label52.TabIndex = 92;
            this.label52.Text = "Stage2";
            // 
            // dtp_tsModifiedDate_Stage1
            // 
            this.dtp_tsModifiedDate_Stage1.Checked = false;
            this.dtp_tsModifiedDate_Stage1.CustomFormat = "dd/MMM/yyyy";
            this.dtp_tsModifiedDate_Stage1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_tsModifiedDate_Stage1.Location = new System.Drawing.Point(259, 180);
            this.dtp_tsModifiedDate_Stage1.Name = "dtp_tsModifiedDate_Stage1";
            this.dtp_tsModifiedDate_Stage1.ShowCheckBox = true;
            this.dtp_tsModifiedDate_Stage1.Size = new System.Drawing.Size(129, 20);
            this.dtp_tsModifiedDate_Stage1.TabIndex = 118;
            this.dtp_tsModifiedDate_Stage1.ValueChanged += new System.EventHandler(this.dtp_tsModifiedDate_Stage1_ValueChanged);
            // 
            // lblTotNoBidders
            // 
            this.lblTotNoBidders.AutoSize = true;
            this.lblTotNoBidders.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotNoBidders.Location = new System.Drawing.Point(513, 271);
            this.lblTotNoBidders.Name = "lblTotNoBidders";
            this.lblTotNoBidders.Size = new System.Drawing.Size(121, 13);
            this.lblTotNoBidders.TabIndex = 93;
            this.lblTotNoBidders.Text = "Total Number of Bidders";
            this.lblTotNoBidders.Visible = false;
            // 
            // dtp_tsStage2
            // 
            this.dtp_tsStage2.Checked = false;
            this.dtp_tsStage2.CustomFormat = "dd/MMM/yyyy";
            this.dtp_tsStage2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_tsStage2.Location = new System.Drawing.Point(80, 205);
            this.dtp_tsStage2.Name = "dtp_tsStage2";
            this.dtp_tsStage2.ShowCheckBox = true;
            this.dtp_tsStage2.Size = new System.Drawing.Size(132, 20);
            this.dtp_tsStage2.TabIndex = 117;
            this.dtp_tsStage2.ValueChanged += new System.EventHandler(this.dtp_tsStage2_ValueChanged);
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.BackColor = System.Drawing.Color.Gainsboro;
            this.label57.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label57.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label57.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.ForeColor = System.Drawing.Color.Chocolate;
            this.label57.Location = new System.Drawing.Point(666, 26);
            this.label57.Name = "label57";
            this.label57.Padding = new System.Windows.Forms.Padding(8);
            this.label57.Size = new System.Drawing.Size(155, 48);
            this.label57.TabIndex = 96;
            this.label57.Text = "Sent to Public Relations\r\nDept For Advertisement";
            // 
            // dtp_tsStage1
            // 
            this.dtp_tsStage1.Checked = false;
            this.dtp_tsStage1.CustomFormat = "dd/MMM/yyyy";
            this.dtp_tsStage1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_tsStage1.Location = new System.Drawing.Point(80, 179);
            this.dtp_tsStage1.Name = "dtp_tsStage1";
            this.dtp_tsStage1.ShowCheckBox = true;
            this.dtp_tsStage1.Size = new System.Drawing.Size(132, 20);
            this.dtp_tsStage1.TabIndex = 116;
            this.dtp_tsStage1.ValueChanged += new System.EventHandler(this.dtp_tsStage1_ValueChanged);
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.BackColor = System.Drawing.Color.Gainsboro;
            this.label56.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label56.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.ForeColor = System.Drawing.Color.Chocolate;
            this.label56.Location = new System.Drawing.Point(823, 26);
            this.label56.Name = "label56";
            this.label56.Padding = new System.Windows.Forms.Padding(8);
            this.label56.Size = new System.Drawing.Size(132, 48);
            this.label56.TabIndex = 97;
            this.label56.Text = "       Tender Issue     \r\n              Date        \r\n";
            // 
            // txt_bidders
            // 
            this.txt_bidders.Location = new System.Drawing.Point(640, 268);
            this.txt_bidders.Name = "txt_bidders";
            this.txt_bidders.ReadOnly = true;
            this.txt_bidders.Size = new System.Drawing.Size(47, 20);
            this.txt_bidders.TabIndex = 114;
            this.txt_bidders.Visible = false;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.BackColor = System.Drawing.Color.Gainsboro;
            this.label60.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label60.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.ForeColor = System.Drawing.Color.Chocolate;
            this.label60.Location = new System.Drawing.Point(217, 26);
            this.label60.Name = "label60";
            this.label60.Padding = new System.Windows.Forms.Padding(8);
            this.label60.Size = new System.Drawing.Size(171, 48);
            this.label60.TabIndex = 103;
            this.label60.Text = "              Tender Issues         \r\n                 Handled By\r\n";
            // 
            // txtDocumentFee
            // 
            this.txtDocumentFee.Location = new System.Drawing.Point(828, 272);
            this.txtDocumentFee.Name = "txtDocumentFee";
            this.txtDocumentFee.Size = new System.Drawing.Size(128, 20);
            this.txtDocumentFee.TabIndex = 111;
            this.txtDocumentFee.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDocumentFree_KeyPress);
            this.txtDocumentFee.Leave += new System.EventHandler(this.txtDocumentFree_Leave);
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.BackColor = System.Drawing.Color.Gainsboro;
            this.label58.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label58.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label58.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.ForeColor = System.Drawing.Color.Chocolate;
            this.label58.Location = new System.Drawing.Point(389, 26);
            this.label58.Name = "label58";
            this.label58.Padding = new System.Windows.Forms.Padding(4);
            this.label58.Size = new System.Drawing.Size(275, 25);
            this.label58.TabIndex = 104;
            this.label58.Text = "                                If Comments                               ";
            // 
            // txtTenderBond
            // 
            this.txtTenderBond.Location = new System.Drawing.Point(828, 242);
            this.txtTenderBond.Name = "txtTenderBond";
            this.txtTenderBond.Size = new System.Drawing.Size(128, 20);
            this.txtTenderBond.TabIndex = 110;
            this.txtTenderBond.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTenderBond_KeyPress_1);
            this.txtTenderBond.Leave += new System.EventHandler(this.txtTenderBond_Leave);
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.BackColor = System.Drawing.Color.Gainsboro;
            this.label61.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label61.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.ForeColor = System.Drawing.Color.Chocolate;
            this.label61.Location = new System.Drawing.Point(389, 55);
            this.label61.Name = "label61";
            this.label61.Padding = new System.Windows.Forms.Padding(2);
            this.label61.Size = new System.Drawing.Size(135, 19);
            this.label61.TabIndex = 105;
            this.label61.Text = "    Returned To Dept        ";
            // 
            // cmb_tstenderHandle
            // 
            this.cmb_tstenderHandle.FormattingEnabled = true;
            this.cmb_tstenderHandle.Location = new System.Drawing.Point(217, 80);
            this.cmb_tstenderHandle.Name = "cmb_tstenderHandle";
            this.cmb_tstenderHandle.Size = new System.Drawing.Size(171, 21);
            this.cmb_tstenderHandle.TabIndex = 109;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.BackColor = System.Drawing.Color.Gainsboro;
            this.label62.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label62.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.ForeColor = System.Drawing.Color.Chocolate;
            this.label62.Location = new System.Drawing.Point(529, 55);
            this.label62.Name = "label62";
            this.label62.Padding = new System.Windows.Forms.Padding(2);
            this.label62.Size = new System.Drawing.Size(135, 19);
            this.label62.TabIndex = 106;
            this.label62.Text = "      Received From Dept  ";
            // 
            // dtp_tsRecOn
            // 
            this.dtp_tsRecOn.Checked = false;
            this.dtp_tsRecOn.CustomFormat = "   ";
            this.dtp_tsRecOn.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_tsRecOn.Location = new System.Drawing.Point(80, 81);
            this.dtp_tsRecOn.Name = "dtp_tsRecOn";
            this.dtp_tsRecOn.ShowCheckBox = true;
            this.dtp_tsRecOn.Size = new System.Drawing.Size(134, 20);
            this.dtp_tsRecOn.TabIndex = 108;
            this.dtp_tsRecOn.Value = new System.DateTime(2013, 2, 5, 0, 0, 0, 0);
            this.dtp_tsRecOn.ValueChanged += new System.EventHandler(this.dtp_tsRecOn_ValueChanged);
            // 
            // ptdTabPage
            // 
            this.ptdTabPage.AutoScroll = true;
            this.ptdTabPage.BackColor = System.Drawing.Color.Cornsilk;
            this.ptdTabPage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ptdTabPage.Controls.Add(this.btnWorkOrderInPTD);
            this.ptdTabPage.Controls.Add(this.groupBox2);
            this.ptdTabPage.Controls.Add(this.dgvPTD_Sent);
            this.ptdTabPage.Controls.Add(this.dgvPTD_Rec);
            this.ptdTabPage.Controls.Add(this.btnSentDoc);
            this.ptdTabPage.Controls.Add(this.btnReceiveDoc);
            this.ptdTabPage.Controls.Add(this.dgvPTD);
            this.ptdTabPage.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ptdTabPage.ForeColor = System.Drawing.SystemColors.ControlText;
            this.ptdTabPage.Location = new System.Drawing.Point(4, 34);
            this.ptdTabPage.Name = "ptdTabPage";
            this.ptdTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.ptdTabPage.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ptdTabPage.Size = new System.Drawing.Size(1039, 547);
            this.ptdTabPage.TabIndex = 0;
            this.ptdTabPage.Text = "PREPARE TENDER DOCUMENTS  ";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Cornsilk;
            this.groupBox2.Controls.Add(this.lblGridIndex);
            this.groupBox2.Controls.Add(this.btnPtdClear);
            this.groupBox2.Controls.Add(this.msk_dtpFrwdDept);
            this.groupBox2.Controls.Add(this.btnPtdDelete);
            this.groupBox2.Controls.Add(this.msk_dtpReview);
            this.groupBox2.Controls.Add(this.lblDateID);
            this.groupBox2.Controls.Add(this.msk_dtpRecievedOn);
            this.groupBox2.Controls.Add(this.dtpFrwdDept);
            this.groupBox2.Controls.Add(this.btnPTD);
            this.groupBox2.Controls.Add(this.txtRemarks);
            this.groupBox2.Controls.Add(this.cmbAssignedQs);
            this.groupBox2.Controls.Add(this.dtpReview);
            this.groupBox2.Controls.Add(this.cmbTenderDocStatus);
            this.groupBox2.Controls.Add(this.cmbQsWorkingStatus);
            this.groupBox2.Controls.Add(this.cmbPurpose);
            this.groupBox2.Controls.Add(this.dtpRecievedOn);
            this.groupBox2.Controls.Add(this.label89);
            this.groupBox2.Controls.Add(this.label88);
            this.groupBox2.Controls.Add(this.label87);
            this.groupBox2.Controls.Add(this.label86);
            this.groupBox2.Controls.Add(this.label85);
            this.groupBox2.Controls.Add(this.label84);
            this.groupBox2.Controls.Add(this.label83);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.groupBox2.Location = new System.Drawing.Point(41, 9);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(938, 155);
            this.groupBox2.TabIndex = 130;
            this.groupBox2.TabStop = false;
            // 
            // lblGridIndex
            // 
            this.lblGridIndex.AutoSize = true;
            this.lblGridIndex.Location = new System.Drawing.Point(6, 126);
            this.lblGridIndex.Name = "lblGridIndex";
            this.lblGridIndex.Size = new System.Drawing.Size(42, 13);
            this.lblGridIndex.TabIndex = 134;
            this.lblGridIndex.Text = "grdIndx";
            this.lblGridIndex.Visible = false;
            // 
            // btnPtdClear
            // 
            this.btnPtdClear.BackColor = System.Drawing.Color.Maroon;
            this.btnPtdClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPtdClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPtdClear.ForeColor = System.Drawing.Color.White;
            this.btnPtdClear.Location = new System.Drawing.Point(871, 116);
            this.btnPtdClear.Name = "btnPtdClear";
            this.btnPtdClear.Size = new System.Drawing.Size(57, 23);
            this.btnPtdClear.TabIndex = 131;
            this.btnPtdClear.Text = "Clear";
            this.btnPtdClear.UseVisualStyleBackColor = false;
            this.btnPtdClear.Click += new System.EventHandler(this.button23_Click_1);
            // 
            // msk_dtpFrwdDept
            // 
            this.msk_dtpFrwdDept.Location = new System.Drawing.Point(718, 77);
            this.msk_dtpFrwdDept.Name = "msk_dtpFrwdDept";
            this.msk_dtpFrwdDept.Size = new System.Drawing.Size(82, 20);
            this.msk_dtpFrwdDept.TabIndex = 133;
            this.msk_dtpFrwdDept.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.msk_dtpFrwdDept.Leave += new System.EventHandler(this.msk_dtpFrwdDept_Leave);
            // 
            // btnPtdDelete
            // 
            this.btnPtdDelete.BackColor = System.Drawing.Color.Maroon;
            this.btnPtdDelete.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPtdDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPtdDelete.ForeColor = System.Drawing.Color.White;
            this.btnPtdDelete.Location = new System.Drawing.Point(813, 116);
            this.btnPtdDelete.Name = "btnPtdDelete";
            this.btnPtdDelete.Size = new System.Drawing.Size(57, 23);
            this.btnPtdDelete.TabIndex = 27;
            this.btnPtdDelete.Text = "Delete";
            this.btnPtdDelete.UseVisualStyleBackColor = false;
            this.btnPtdDelete.Click += new System.EventHandler(this.button22_Click_1);
            // 
            // msk_dtpReview
            // 
            this.msk_dtpReview.Location = new System.Drawing.Point(483, 77);
            this.msk_dtpReview.Name = "msk_dtpReview";
            this.msk_dtpReview.Size = new System.Drawing.Size(90, 20);
            this.msk_dtpReview.TabIndex = 132;
            this.msk_dtpReview.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.msk_dtpReview.Leave += new System.EventHandler(this.msk_dtpReview_Leave);
            // 
            // lblDateID
            // 
            this.lblDateID.AutoSize = true;
            this.lblDateID.BackColor = System.Drawing.Color.Silver;
            this.lblDateID.Location = new System.Drawing.Point(6, 107);
            this.lblDateID.Name = "lblDateID";
            this.lblDateID.Size = new System.Drawing.Size(41, 13);
            this.lblDateID.TabIndex = 130;
            this.lblDateID.Text = "label90";
            this.lblDateID.Visible = false;
            // 
            // msk_dtpRecievedOn
            // 
            this.msk_dtpRecievedOn.Location = new System.Drawing.Point(9, 77);
            this.msk_dtpRecievedOn.Name = "msk_dtpRecievedOn";
            this.msk_dtpRecievedOn.Size = new System.Drawing.Size(85, 20);
            this.msk_dtpRecievedOn.TabIndex = 131;
            this.msk_dtpRecievedOn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.msk_dtpRecievedOn.Leave += new System.EventHandler(this.msk_dtpRecievedOn_Leave);
            // 
            // dtpFrwdDept
            // 
            this.dtpFrwdDept.Checked = false;
            this.dtpFrwdDept.CustomFormat = " ";
            this.dtpFrwdDept.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFrwdDept.Location = new System.Drawing.Point(718, 77);
            this.dtpFrwdDept.Name = "dtpFrwdDept";
            this.dtpFrwdDept.Size = new System.Drawing.Size(112, 20);
            this.dtpFrwdDept.TabIndex = 25;
            this.dtpFrwdDept.Value = new System.DateTime(2013, 1, 23, 0, 0, 0, 0);
            this.dtpFrwdDept.ValueChanged += new System.EventHandler(this.dtpFrwdDept_ValueChanged);
            // 
            // btnPTD
            // 
            this.btnPTD.BackColor = System.Drawing.Color.Maroon;
            this.btnPTD.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPTD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPTD.ForeColor = System.Drawing.Color.White;
            this.btnPTD.Location = new System.Drawing.Point(762, 116);
            this.btnPTD.Name = "btnPTD";
            this.btnPTD.Size = new System.Drawing.Size(50, 23);
            this.btnPTD.TabIndex = 24;
            this.btnPTD.Text = "Save";
            this.btnPTD.UseVisualStyleBackColor = false;
            this.btnPTD.Click += new System.EventHandler(this.btnPTD_Click);
            // 
            // txtRemarks
            // 
            this.txtRemarks.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRemarks.Location = new System.Drawing.Point(833, 77);
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Size = new System.Drawing.Size(95, 20);
            this.txtRemarks.TabIndex = 23;
            // 
            // cmbAssignedQs
            // 
            this.cmbAssignedQs.FormattingEnabled = true;
            this.cmbAssignedQs.Location = new System.Drawing.Point(239, 76);
            this.cmbAssignedQs.Name = "cmbAssignedQs";
            this.cmbAssignedQs.Size = new System.Drawing.Size(128, 21);
            this.cmbAssignedQs.TabIndex = 22;
            // 
            // dtpReview
            // 
            this.dtpReview.Checked = false;
            this.dtpReview.CustomFormat = " ";
            this.dtpReview.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpReview.Location = new System.Drawing.Point(483, 77);
            this.dtpReview.Name = "dtpReview";
            this.dtpReview.Size = new System.Drawing.Size(119, 20);
            this.dtpReview.TabIndex = 20;
            this.dtpReview.Value = new System.DateTime(2013, 1, 23, 0, 0, 0, 0);
            this.dtpReview.ValueChanged += new System.EventHandler(this.dtpReview_ValueChanged);
            // 
            // cmbTenderDocStatus
            // 
            this.cmbTenderDocStatus.FormattingEnabled = true;
            this.cmbTenderDocStatus.Location = new System.Drawing.Point(605, 76);
            this.cmbTenderDocStatus.Name = "cmbTenderDocStatus";
            this.cmbTenderDocStatus.Size = new System.Drawing.Size(110, 21);
            this.cmbTenderDocStatus.TabIndex = 19;
            this.cmbTenderDocStatus.Leave += new System.EventHandler(this.cmbTenderDocStatus_Leave);
            // 
            // cmbQsWorkingStatus
            // 
            this.cmbQsWorkingStatus.FormattingEnabled = true;
            this.cmbQsWorkingStatus.Location = new System.Drawing.Point(369, 76);
            this.cmbQsWorkingStatus.Name = "cmbQsWorkingStatus";
            this.cmbQsWorkingStatus.Size = new System.Drawing.Size(110, 21);
            this.cmbQsWorkingStatus.TabIndex = 18;
            // 
            // cmbPurpose
            // 
            this.cmbPurpose.FormattingEnabled = true;
            this.cmbPurpose.Location = new System.Drawing.Point(127, 76);
            this.cmbPurpose.Name = "cmbPurpose";
            this.cmbPurpose.Size = new System.Drawing.Size(109, 21);
            this.cmbPurpose.TabIndex = 17;
            this.cmbPurpose.SelectionChangeCommitted += new System.EventHandler(this.cmbPurpose_SelectionChangeCommitted);
            // 
            // dtpRecievedOn
            // 
            this.dtpRecievedOn.Checked = false;
            this.dtpRecievedOn.CustomFormat = "";
            this.dtpRecievedOn.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpRecievedOn.Location = new System.Drawing.Point(9, 77);
            this.dtpRecievedOn.Name = "dtpRecievedOn";
            this.dtpRecievedOn.Size = new System.Drawing.Size(115, 20);
            this.dtpRecievedOn.TabIndex = 16;
            this.dtpRecievedOn.Value = new System.DateTime(2013, 1, 23, 0, 0, 0, 0);
            this.dtpRecievedOn.ValueChanged += new System.EventHandler(this.dtpRecievedOn_ValueChanged);
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.BackColor = System.Drawing.Color.Gainsboro;
            this.label89.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label89.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label89.ForeColor = System.Drawing.Color.Chocolate;
            this.label89.Location = new System.Drawing.Point(833, 14);
            this.label89.Name = "label89";
            this.label89.Padding = new System.Windows.Forms.Padding(18);
            this.label89.Size = new System.Drawing.Size(95, 53);
            this.label89.TabIndex = 15;
            this.label89.Text = "Remarks";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.BackColor = System.Drawing.Color.Gainsboro;
            this.label88.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label88.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label88.ForeColor = System.Drawing.Color.Chocolate;
            this.label88.Location = new System.Drawing.Point(718, 14);
            this.label88.Name = "label88";
            this.label88.Padding = new System.Windows.Forms.Padding(10, 10, 10, 11);
            this.label88.Size = new System.Drawing.Size(112, 53);
            this.label88.TabIndex = 14;
            this.label88.Text = "Forward To       \r\nDepartment\r\n";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.BackColor = System.Drawing.Color.Gainsboro;
            this.label87.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label87.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label87.ForeColor = System.Drawing.Color.Chocolate;
            this.label87.Location = new System.Drawing.Point(239, 13);
            this.label87.Name = "label87";
            this.label87.Padding = new System.Windows.Forms.Padding(18);
            this.label87.Size = new System.Drawing.Size(128, 53);
            this.label87.TabIndex = 13;
            this.label87.Text = "    Assigned Qs ";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.BackColor = System.Drawing.Color.Gainsboro;
            this.label86.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label86.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label86.ForeColor = System.Drawing.Color.Chocolate;
            this.label86.Location = new System.Drawing.Point(605, 14);
            this.label86.Name = "label86";
            this.label86.Padding = new System.Windows.Forms.Padding(3);
            this.label86.Size = new System.Drawing.Size(110, 53);
            this.label86.TabIndex = 12;
            this.label86.Text = "      Tender\r\n    Document \r\nCurrent Status      ";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.BackColor = System.Drawing.Color.Gainsboro;
            this.label85.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label85.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label85.ForeColor = System.Drawing.Color.Chocolate;
            this.label85.Location = new System.Drawing.Point(370, 14);
            this.label85.Name = "label85";
            this.label85.Padding = new System.Windows.Forms.Padding(10, 10, 10, 11);
            this.label85.Size = new System.Drawing.Size(110, 53);
            this.label85.TabIndex = 11;
            this.label85.Text = "    Qs Working  \r\n       Status";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.BackColor = System.Drawing.Color.Gainsboro;
            this.label84.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label84.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label84.ForeColor = System.Drawing.Color.Chocolate;
            this.label84.Location = new System.Drawing.Point(127, 13);
            this.label84.Name = "label84";
            this.label84.Padding = new System.Windows.Forms.Padding(18);
            this.label84.Size = new System.Drawing.Size(109, 53);
            this.label84.TabIndex = 10;
            this.label84.Text = "      Purpose";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.BackColor = System.Drawing.Color.Gainsboro;
            this.label83.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label83.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label83.ForeColor = System.Drawing.Color.Chocolate;
            this.label83.Location = new System.Drawing.Point(483, 14);
            this.label83.Name = "label83";
            this.label83.Padding = new System.Windows.Forms.Padding(3);
            this.label83.Size = new System.Drawing.Size(119, 53);
            this.label83.TabIndex = 9;
            this.label83.Text = "Sent to department\r\n     for review \r\n   with comments";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Gainsboro;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Chocolate;
            this.label1.Location = new System.Drawing.Point(9, 13);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(18);
            this.label1.Size = new System.Drawing.Size(115, 53);
            this.label1.TabIndex = 8;
            this.label1.Text = "Received On";
            // 
            // dgvPTD_Sent
            // 
            this.dgvPTD_Sent.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPTD_Sent.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle40.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle40.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle40.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle40.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle40.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle40.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle40.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPTD_Sent.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle40;
            this.dgvPTD_Sent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle41.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle41.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle41.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle41.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle41.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle41.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle41.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPTD_Sent.DefaultCellStyle = dataGridViewCellStyle41;
            this.dgvPTD_Sent.Location = new System.Drawing.Point(517, 329);
            this.dgvPTD_Sent.Name = "dgvPTD_Sent";
            dataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle42.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle42.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle42.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle42.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle42.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle42.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPTD_Sent.RowHeadersDefaultCellStyle = dataGridViewCellStyle42;
            this.dgvPTD_Sent.RowHeadersVisible = false;
            this.dgvPTD_Sent.Size = new System.Drawing.Size(462, 121);
            this.dgvPTD_Sent.TabIndex = 128;
            this.dgvPTD_Sent.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPTD_Sent_CellClick);
            // 
            // dgvPTD_Rec
            // 
            this.dgvPTD_Rec.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPTD_Rec.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle43.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle43.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle43.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle43.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle43.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle43.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle43.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPTD_Rec.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle43;
            this.dgvPTD_Rec.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle44.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle44.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle44.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle44.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle44.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle44.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle44.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPTD_Rec.DefaultCellStyle = dataGridViewCellStyle44;
            this.dgvPTD_Rec.Location = new System.Drawing.Point(41, 329);
            this.dgvPTD_Rec.Name = "dgvPTD_Rec";
            dataGridViewCellStyle45.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle45.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle45.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle45.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle45.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle45.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle45.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPTD_Rec.RowHeadersDefaultCellStyle = dataGridViewCellStyle45;
            this.dgvPTD_Rec.RowHeadersVisible = false;
            this.dgvPTD_Rec.Size = new System.Drawing.Size(462, 121);
            this.dgvPTD_Rec.TabIndex = 127;
            this.dgvPTD_Rec.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPTD_Rec_CellClick);
            // 
            // btnSentDoc
            // 
            this.btnSentDoc.BackColor = System.Drawing.Color.Maroon;
            this.btnSentDoc.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSentDoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSentDoc.ForeColor = System.Drawing.Color.White;
            this.btnSentDoc.Location = new System.Drawing.Point(519, 300);
            this.btnSentDoc.Name = "btnSentDoc";
            this.btnSentDoc.Size = new System.Drawing.Size(140, 23);
            this.btnSentDoc.TabIndex = 126;
            this.btnSentDoc.Text = "Sent Document";
            this.btnSentDoc.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSentDoc.UseVisualStyleBackColor = false;
            this.btnSentDoc.Click += new System.EventHandler(this.btnSentDoc_Click);
            // 
            // btnReceiveDoc
            // 
            this.btnReceiveDoc.BackColor = System.Drawing.Color.Maroon;
            this.btnReceiveDoc.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnReceiveDoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReceiveDoc.ForeColor = System.Drawing.Color.White;
            this.btnReceiveDoc.Location = new System.Drawing.Point(41, 300);
            this.btnReceiveDoc.Name = "btnReceiveDoc";
            this.btnReceiveDoc.Size = new System.Drawing.Size(140, 23);
            this.btnReceiveDoc.TabIndex = 125;
            this.btnReceiveDoc.Text = "Recieved Document";
            this.btnReceiveDoc.UseVisualStyleBackColor = false;
            this.btnReceiveDoc.Click += new System.EventHandler(this.btnReceiveDoc_Click);
            // 
            // dgvPTD
            // 
            this.dgvPTD.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPTD.BackgroundColor = System.Drawing.Color.Cornsilk;
            this.dgvPTD.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle46.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle46.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle46.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle46.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle46.Padding = new System.Windows.Forms.Padding(0, 3, 0, 3);
            dataGridViewCellStyle46.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle46.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle46.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPTD.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle46;
            this.dgvPTD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle47.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle47.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle47.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle47.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle47.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle47.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle47.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPTD.DefaultCellStyle = dataGridViewCellStyle47;
            this.dgvPTD.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvPTD.Location = new System.Drawing.Point(41, 180);
            this.dgvPTD.Name = "dgvPTD";
            this.dgvPTD.ReadOnly = true;
            dataGridViewCellStyle48.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle48.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle48.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle48.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle48.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle48.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle48.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPTD.RowHeadersDefaultCellStyle = dataGridViewCellStyle48;
            this.dgvPTD.RowHeadersVisible = false;
            this.dgvPTD.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPTD.Size = new System.Drawing.Size(938, 93);
            this.dgvPTD.TabIndex = 9;
            this.dgvPTD.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPTD_CellClick);
            this.dgvPTD.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvPTD_RowHeaderMouseClick);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.ptdTabPage);
            this.tabControl1.Controls.Add(this.tsTabPage);
            this.tabControl1.Controls.Add(this.teaTabPage);
            this.tabControl1.Controls.Add(this.cpTabPage);
            this.tabControl1.Controls.Add(this.pcsTabPage);
            this.tabControl1.Location = new System.Drawing.Point(0, 167);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.Padding = new System.Drawing.Point(9, 9);
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1047, 585);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.FillToRight;
            this.tabControl1.TabIndex = 0;
            this.tabControl1.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.tabControl1_DrawItem);
            this.tabControl1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tabControl1_MouseClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Receive On";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 128;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Purpose";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 129;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Assigned QS";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 129;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "QS Working Status";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 122;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "Send To Dept. for Review / with Comments";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 150;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "Forwarded to Department";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 123;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "(For Tendering) Receive on";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn7.Width = 126;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.HeaderText = "Tender Issues Handled by:";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn8.Width = 126;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.HeaderText = "Returned To Dept.";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn9.Width = 126;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.HeaderText = "Received From Dept.";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.Width = 150;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.HeaderText = "Sent to Public Relations Dept. for ADVERTISEMENT";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.Width = 150;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.HeaderText = "Original";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.Width = 129;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.HeaderText = "To Expire";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.Width = 126;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.HeaderText = "Extended 1";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            this.dataGridViewTextBoxColumn14.Width = 126;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.HeaderText = "Extended 2";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            this.dataGridViewTextBoxColumn15.Width = 150;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.HeaderText = "Tender No. Request Date";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            this.dataGridViewTextBoxColumn16.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn16.Width = 150;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.HeaderText = "Tender Doc.  Received from CD";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.ReadOnly = true;
            this.dataGridViewTextBoxColumn17.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn17.Width = 91;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.HeaderText = "Tech. Evaluation Sent Date";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            this.dataGridViewTextBoxColumn18.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn18.Width = 92;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.HeaderText = "Tech. Evaluation Received Date";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            this.dataGridViewTextBoxColumn19.Width = 92;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.HeaderText = "Comm. Evaluation Sent Date";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.Width = 92;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.HeaderText = "Comm. Evaluation Received Date";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.ReadOnly = true;
            this.dataGridViewTextBoxColumn21.Width = 150;
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.HeaderText = "File Name";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            this.dataGridViewTextBoxColumn22.Width = 92;
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.HeaderText = "Reference No";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            this.dataGridViewTextBoxColumn23.Width = 127;
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.HeaderText = "Status";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            this.dataGridViewTextBoxColumn24.Width = 128;
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.HeaderText = "Successful Builder";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            this.dataGridViewTextBoxColumn25.Width = 127;
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.HeaderText = "Type of Company";
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            this.dataGridViewTextBoxColumn26.Width = 132;
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.HeaderText = "Date of Signing of Contract";
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            this.dataGridViewTextBoxColumn27.Width = 131;
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.HeaderText = "Staff Incharge";
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            this.dataGridViewTextBoxColumn28.Width = 132;
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.HeaderText = "From";
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            this.dataGridViewTextBoxColumn29.Width = 105;
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.HeaderText = "To";
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            this.dataGridViewTextBoxColumn30.Width = 106;
            // 
            // dataGridViewTextBoxColumn31
            // 
            this.dataGridViewTextBoxColumn31.HeaderText = "File Name";
            this.dataGridViewTextBoxColumn31.Name = "dataGridViewTextBoxColumn31";
            this.dataGridViewTextBoxColumn31.Width = 105;
            // 
            // dataGridViewTextBoxColumn32
            // 
            this.dataGridViewTextBoxColumn32.HeaderText = "Reference No";
            this.dataGridViewTextBoxColumn32.Name = "dataGridViewTextBoxColumn32";
            this.dataGridViewTextBoxColumn32.Width = 116;
            // 
            // dataGridViewTextBoxColumn33
            // 
            this.dataGridViewTextBoxColumn33.HeaderText = "Status";
            this.dataGridViewTextBoxColumn33.Name = "dataGridViewTextBoxColumn33";
            this.dataGridViewTextBoxColumn33.Width = 115;
            // 
            // dataGridViewTextBoxColumn34
            // 
            this.dataGridViewTextBoxColumn34.HeaderText = "File Name";
            this.dataGridViewTextBoxColumn34.Name = "dataGridViewTextBoxColumn34";
            this.dataGridViewTextBoxColumn34.Width = 116;
            // 
            // dataGridViewTextBoxColumn35
            // 
            this.dataGridViewTextBoxColumn35.HeaderText = "Reference No";
            this.dataGridViewTextBoxColumn35.Name = "dataGridViewTextBoxColumn35";
            this.dataGridViewTextBoxColumn35.Width = 115;
            // 
            // dataGridViewTextBoxColumn36
            // 
            this.dataGridViewTextBoxColumn36.HeaderText = "Status";
            this.dataGridViewTextBoxColumn36.Name = "dataGridViewTextBoxColumn36";
            this.dataGridViewTextBoxColumn36.Width = 112;
            // 
            // dataGridViewTextBoxColumn37
            // 
            this.dataGridViewTextBoxColumn37.HeaderText = "Contractor/Vendor";
            this.dataGridViewTextBoxColumn37.Name = "dataGridViewTextBoxColumn37";
            this.dataGridViewTextBoxColumn37.Width = 111;
            // 
            // dataGridViewTextBoxColumn38
            // 
            this.dataGridViewTextBoxColumn38.HeaderText = "Type of Company";
            this.dataGridViewTextBoxColumn38.Name = "dataGridViewTextBoxColumn38";
            // 
            // dataGridViewTextBoxColumn39
            // 
            this.dataGridViewTextBoxColumn39.HeaderText = "Date of Signing of Contract";
            this.dataGridViewTextBoxColumn39.Name = "dataGridViewTextBoxColumn39";
            // 
            // dataGridViewTextBoxColumn40
            // 
            this.dataGridViewTextBoxColumn40.HeaderText = "Contract No";
            this.dataGridViewTextBoxColumn40.Name = "dataGridViewTextBoxColumn40";
            // 
            // dataGridViewTextBoxColumn41
            // 
            this.dataGridViewTextBoxColumn41.HeaderText = "Staff Incharge";
            this.dataGridViewTextBoxColumn41.Name = "dataGridViewTextBoxColumn41";
            // 
            // dataGridViewTextBoxColumn42
            // 
            this.dataGridViewTextBoxColumn42.HeaderText = "From";
            this.dataGridViewTextBoxColumn42.Name = "dataGridViewTextBoxColumn42";
            this.dataGridViewTextBoxColumn42.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewTextBoxColumn43
            // 
            this.dataGridViewTextBoxColumn43.HeaderText = "To";
            this.dataGridViewTextBoxColumn43.Name = "dataGridViewTextBoxColumn43";
            this.dataGridViewTextBoxColumn43.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewTextBoxColumn44
            // 
            this.dataGridViewTextBoxColumn44.HeaderText = "File Name";
            this.dataGridViewTextBoxColumn44.Name = "dataGridViewTextBoxColumn44";
            this.dataGridViewTextBoxColumn44.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewTextBoxColumn45
            // 
            this.dataGridViewTextBoxColumn45.HeaderText = "Reference No";
            this.dataGridViewTextBoxColumn45.Name = "dataGridViewTextBoxColumn45";
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Contract No";
            this.Column4.Name = "Column4";
            // 
            // dataGridViewTextBoxColumn46
            // 
            this.dataGridViewTextBoxColumn46.HeaderText = "Status";
            this.dataGridViewTextBoxColumn46.Name = "dataGridViewTextBoxColumn46";
            // 
            // btnWorkOrderInPTD
            // 
            this.btnWorkOrderInPTD.BackColor = System.Drawing.Color.Maroon;
            this.btnWorkOrderInPTD.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnWorkOrderInPTD.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnWorkOrderInPTD.ForeColor = System.Drawing.Color.White;
            this.btnWorkOrderInPTD.Location = new System.Drawing.Point(417, 299);
            this.btnWorkOrderInPTD.Name = "btnWorkOrderInPTD";
            this.btnWorkOrderInPTD.Size = new System.Drawing.Size(86, 24);
            this.btnWorkOrderInPTD.TabIndex = 241;
            this.btnWorkOrderInPTD.Text = "Work Order";
            this.btnWorkOrderInPTD.UseVisualStyleBackColor = false;
            this.btnWorkOrderInPTD.Visible = false;
            this.btnWorkOrderInPTD.Click += new System.EventHandler(this.btnWorkOrderInPTD_Click);
            // 
            // ProjectStages
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1050, 747);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ProjectStages";
            this.Text = "Projects Data Entry Window";
            this.Load += new System.EventHandler(this.ProjectStages_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.ProjectStages_Paint);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.pcsTabPage.ResumeLayout(false);
            this.pcsTabPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPC_Contracts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPC)).EndInit();
            this.cpTabPage.ResumeLayout(false);
            this.cpTabPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCpDataEntry)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCP_Sent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCP_Rec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContracts)).EndInit();
            this.teaTabPage.ResumeLayout(false);
            this.teaTabPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCntrStage3)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTE_Sent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTE_Rec)).EndInit();
            this.tsTabPage.ResumeLayout(false);
            this.tsTabPage.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.grpEligibleCompanies.ResumeLayout(false);
            this.grpEligibleCompanies.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTS_Rec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTS_Sent)).EndInit();
            this.ptdTabPage.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPTD_Sent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPTD_Rec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPTD)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblPrjCode;
        private System.Windows.Forms.Label lblTenderNo;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtProjCode;
        private System.Windows.Forms.TextBox txtTenderNo;
        private System.Windows.Forms.TextBox txtproj;
        private System.Windows.Forms.Button btnSaveMinistryCode;
        private System.Windows.Forms.ComboBox cmbTenderStatus;
        private System.Windows.Forms.ComboBox cmbBudgetRef;
        private System.Windows.Forms.ComboBox cmbMinistryCode;
        private System.Windows.Forms.TextBox txtProvisionNo;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn31;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn32;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn33;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn34;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn35;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn36;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn37;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn38;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn39;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn40;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn44;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn45;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn46;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn41;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn42;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn43;
        private System.Windows.Forms.Label lblProjID;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.DataGridView dgView;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TabPage pcsTabPage;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Button btnPC_Save;
        private System.Windows.Forms.DataGridView dgvPC_Contracts;
        private System.Windows.Forms.DataGridView dgvPC;
        private System.Windows.Forms.TextBox txtPC_Remarks;
        private System.Windows.Forms.TextBox txtPC_BudjetAmnt;
        private System.Windows.Forms.TextBox txtPC_EstimatedAmnt;
        private System.Windows.Forms.Label lblPc_EstAmnt;
        private System.Windows.Forms.Label lblPC_bdgtAmnt;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.TabPage cpTabPage;
        private System.Windows.Forms.Button btnDatesExtend;
        private System.Windows.Forms.DataGridView dgvCpDataEntry;
        private System.Windows.Forms.DataGridView dgvCP_Sent;
        private System.Windows.Forms.DataGridView dgvCP_Rec;
        private System.Windows.Forms.Button btnSentCp;
        private System.Windows.Forms.Button btnRecCp;
        private System.Windows.Forms.Label lblCP_bdgtAmnt;
        private System.Windows.Forms.Button btnCP_Save;
        private System.Windows.Forms.Label lblCP_estimateAmnt;
        private System.Windows.Forms.TextBox txtCp_EstimatedAmnt;
        private System.Windows.Forms.TextBox txtCp_BudgetAmnt;
        private System.Windows.Forms.DataGridView dgvContracts;
        private System.Windows.Forms.TabPage teaTabPage;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.MaskedTextBox msk_dtpTBV_SEdate;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.MaskedTextBox msk_dtpTV_SEdate;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.MaskedTextBox msk_dtpTBV_FEdate;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.MaskedTextBox msk_dtpTV_FEdate;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.MaskedTextBox msk_dtpTBV_OrgDate;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.MaskedTextBox msk_dtpTV_OrgDate;
        private System.Windows.Forms.DateTimePicker dtpTV_SEdate;
        private System.Windows.Forms.DateTimePicker dtpTBV_FEdate;
        private System.Windows.Forms.DateTimePicker dtpTV_FEdate;
        private System.Windows.Forms.DateTimePicker dtpTBV_SEdate;
        private System.Windows.Forms.TextBox txtTV_exipre;
        private System.Windows.Forms.TextBox txtTBV_exipre;
        private System.Windows.Forms.MaskedTextBox msk_dtpEA_closeDate;
        private System.Windows.Forms.MaskedTextBox msk_dtpEA_stage2;
        private System.Windows.Forms.MaskedTextBox msk_dtpEA_stage1;
        private System.Windows.Forms.MaskedTextBox msk_dtpEA_apprDate;
        private System.Windows.Forms.MaskedTextBox msk_dtpFE_daterecFin1;
        private System.Windows.Forms.MaskedTextBox msk_dtpFE_datesentfin1;
        private System.Windows.Forms.MaskedTextBox msk_dtpTE_daterec1;
        private System.Windows.Forms.MaskedTextBox msk_dtpTE_datesent1;
        private System.Windows.Forms.MaskedTextBox msk_dtpEA_reqdate;
        private System.Windows.Forms.MaskedTextBox msk_dtpEA_recfromcd;
        private System.Windows.Forms.DataGridView dgvTE_Sent;
        private System.Windows.Forms.Label lblTE_estimateAmnt;
        private System.Windows.Forms.Label lblTE_bdgtAmt;
        private System.Windows.Forms.TextBox txtEstimatedAmnt;
        private System.Windows.Forms.TextBox txtBudjetAmnt;
        private System.Windows.Forms.TextBox txtEA_Noofmeetings;
        private System.Windows.Forms.DataGridView dgvTE_Rec;
        private System.Windows.Forms.Button btnSent_TEA;
        private System.Windows.Forms.Button btnRecDocTE;
        private System.Windows.Forms.Button btnTE_Save;
        private System.Windows.Forms.DateTimePicker dtpEA_recfromcd;
        private System.Windows.Forms.DateTimePicker dtpEA_apprDate;
        private System.Windows.Forms.DateTimePicker dtpFE_daterecFin1;
        private System.Windows.Forms.DateTimePicker dtpFE_datesentfin1;
        private System.Windows.Forms.DateTimePicker dtpTE_daterec1;
        private System.Windows.Forms.DateTimePicker dtpTE_datesent1;
        private System.Windows.Forms.DateTimePicker dtpEA_reqdate;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.TabPage tsTabPage;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnViewBidder;
        private System.Windows.Forms.TextBox txtCircular;
        private System.Windows.Forms.Label lblTotCircularIssued;
        private System.Windows.Forms.Button btnRecDocTS;
        private System.Windows.Forms.MaskedTextBox msk_dtp_tsModifiedDate_Stage1;
        private System.Windows.Forms.Button btnSentDocTS;
        private System.Windows.Forms.DataGridView dgvTS_Rec;
        private System.Windows.Forms.MaskedTextBox msk_dtp_tsStage2;
        private System.Windows.Forms.DataGridView dgvTS_Sent;
        private System.Windows.Forms.MaskedTextBox msk_dtp_tsStage1;
        private System.Windows.Forms.MaskedTextBox msk_dtp_tsInvitation;
        private System.Windows.Forms.MaskedTextBox msk_dtp_tsAdvertisement;
        private System.Windows.Forms.MaskedTextBox msk_dtp_tsRecFromDept;
        private System.Windows.Forms.MaskedTextBox msk_dtp_tsReturnDept;
        private System.Windows.Forms.MaskedTextBox msk_dtp_tsRecOn;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label lblTenderProjTitle;
        private System.Windows.Forms.TextBox txt_tsRemarks;
        private System.Windows.Forms.Label lblBondAmt;
        private System.Windows.Forms.Button btnIssueTender;
        private System.Windows.Forms.Button btnAssignTender;
        private System.Windows.Forms.Button btnTS;
        private System.Windows.Forms.Label lblDocAmt;
        private System.Windows.Forms.DateTimePicker dtp_tsInvitation;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.DateTimePicker dtp_tsAdvertisement;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.DateTimePicker dtp_tsRecFromDept;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.DateTimePicker dtp_tsReturnDept;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.DateTimePicker dtp_tsModifiedDate_Stage1;
        private System.Windows.Forms.Label lblTotNoBidders;
        private System.Windows.Forms.DateTimePicker dtp_tsStage2;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.DateTimePicker dtp_tsStage1;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox txt_bidders;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox txtDocumentFee;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.TextBox txtTenderBond;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.ComboBox cmb_tstenderHandle;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.DateTimePicker dtp_tsRecOn;
        private System.Windows.Forms.TabPage ptdTabPage;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnPtdClear;
        private System.Windows.Forms.MaskedTextBox msk_dtpFrwdDept;
        private System.Windows.Forms.Button btnPtdDelete;
        private System.Windows.Forms.MaskedTextBox msk_dtpReview;
        private System.Windows.Forms.Label lblDateID;
        private System.Windows.Forms.MaskedTextBox msk_dtpRecievedOn;
        private System.Windows.Forms.DateTimePicker dtpFrwdDept;
        private System.Windows.Forms.Button btnPTD;
        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Forms.ComboBox cmbAssignedQs;
        private System.Windows.Forms.DateTimePicker dtpReview;
        private System.Windows.Forms.ComboBox cmbTenderDocStatus;
        private System.Windows.Forms.ComboBox cmbQsWorkingStatus;
        private System.Windows.Forms.ComboBox cmbPurpose;
        private System.Windows.Forms.DateTimePicker dtpRecievedOn;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvPTD_Sent;
        private System.Windows.Forms.DataGridView dgvPTD_Rec;
        private System.Windows.Forms.Button btnSentDoc;
        private System.Windows.Forms.Button btnReceiveDoc;
        private System.Windows.Forms.DataGridView dgvPTD;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtTE_remarks;
        private System.Windows.Forms.DataGridView dgvCntrStage3;
        private System.Windows.Forms.Button btnCntrSave;
        private System.Windows.Forms.GroupBox grpEligibleCompanies;
        private System.Windows.Forms.CheckBox chkJointVenture;
        private System.Windows.Forms.CheckBox chkInternational;
        private System.Windows.Forms.CheckBox chkLocal;
        private System.Windows.Forms.Button btnMinistry;
        private System.Windows.Forms.Button btnBudgetRef;
        private System.Windows.Forms.Label lblEstCostCurrSymbol;
        private System.Windows.Forms.Label lblBdgAmtCurrSymbol;
        private System.Windows.Forms.Label lblDFTenderBondCur;
        private System.Windows.Forms.Label lblTSTenderBondCur;
        private System.Windows.Forms.Label lblBudAmtCP;
        private System.Windows.Forms.Label lblEstCostCurr;
        private System.Windows.Forms.Button btnExportToPdf;
        private System.Windows.Forms.Button btnViewShortList;
        private System.Windows.Forms.Label lblCompaniesInShortList;
        private System.Windows.Forms.TextBox txtTotCompInShortList;
        private System.Windows.Forms.Label lblGridIndex;
        private System.Windows.Forms.Label lblDateCnt;
        private System.Windows.Forms.Label lbltype;
        private System.Windows.Forms.TextBox txtCmpType;
        private System.Windows.Forms.Button btnClk;
        private System.Windows.Forms.Label lblContractNo;
        private System.Windows.Forms.Label lblContractNoDisplay;
        private System.Windows.Forms.Button btnTenderSubmissionStage1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblTechEvalProposedWorkDays;
        private System.Windows.Forms.TextBox txtFinEval1ProposedWorkDays;
        private System.Windows.Forms.Label lblFinEvalProposedWorkDays;
        private System.Windows.Forms.TextBox txtTechEval1ProposedWorkDays;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnBudgetRefNo;
        private System.Windows.Forms.Button btnWorkOrder;
        private System.Windows.Forms.Button btnUpdateProjStatus;
        private System.Windows.Forms.ComboBox cmbTenderStatusChange;
        private System.Windows.Forms.TextBox txtTechEval2ProposedWorkDays;
        private System.Windows.Forms.MaskedTextBox msk_dtpTE_datesent2;
        private System.Windows.Forms.DateTimePicker dtpTE_datesent2;
        private System.Windows.Forms.MaskedTextBox msk_dtpTE_daterec2;
        private System.Windows.Forms.DateTimePicker dtpTE_daterec2;
        private System.Windows.Forms.MaskedTextBox msk_dtpFE_daterecFin2;
        private System.Windows.Forms.DateTimePicker dtpFE_daterecFin2;
        private System.Windows.Forms.TextBox txtFinEval2ProposedWorkDays;
        private System.Windows.Forms.MaskedTextBox msk_dtpFE_datesentfin2;
        private System.Windows.Forms.DateTimePicker dtpFE_datesentfin2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnTenderSubmissionStg2;
        private System.Windows.Forms.DateTimePicker dtp_tsModifiedDate_Stage2;
        private System.Windows.Forms.MaskedTextBox msk_dtp_tsModifiedDate_Stage2;
        private System.Windows.Forms.MaskedTextBox msk_dtpEA_closeDate_Stage2;
        private System.Windows.Forms.Button btnExportToExcel;
        private System.Windows.Forms.Button btnWorkOrder2;
        private System.Windows.Forms.Button btnWorkOrderInPTD;
    }
}