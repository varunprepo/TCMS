﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace MDI_ParenrForm.Projects
{
    public partial class frmNewWorkOrder : Form
    {         

        int _projID = 0;              
        string _userName = null;
        IList<string> _userRightsColl = new List<string>();
        bool _isHeadOfSection = false;         
        DataGridView _dgvWorkOrders = null;
        CommonClass cmnCls = null;

        public frmNewWorkOrder(IList<string> userRightsCollContracts, int projID, string userName, bool isHeadOfSection, DataGridView dgvWorkOrders)
        {
            InitializeComponent();             
            _userRightsColl = userRightsCollContracts;             
            _projID = projID;             
            _userName = userName;
            _isHeadOfSection = isHeadOfSection;             
            _dgvWorkOrders = dgvWorkOrders;
            cmnCls = new CommonClass(userName);          
        }


        private void btnSaveAndClose_Click(object sender, EventArgs e)
        {
            if (txtWorkOrderNo.Text.Trim() == "")
            {
                MessageBox.Show("Work Order No. can not be left blank", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtWorkOrderNo.Focus();
                return;
            }

            if (txtProjTitle.Text.Trim() == "")
            {
                MessageBox.Show("Project Title can not be left blank", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtProjTitle.Focus();
                return;
            }

            if (mskTxtWOIssueDate.Text.Trim() == "")
            {
                MessageBox.Show("Work Order Issue Date can not be left blank", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                mskTxtWOIssueDate.Focus();
                return;
            } 

            if (mskTxtWorkOrderClosingDate.Text.Trim() == "")
            {
                MessageBox.Show("Work Order Closing Date can not be left blank", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                mskTxtWorkOrderClosingDate.Focus();
                return;
            }           
           
            SqlConnection sqlConn = null;
            try
            {
                using (sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                {
                    if (sqlConn.State == ConnectionState.Closed)
                        sqlConn.Open();
                    CommonClass comCls = new CommonClass(_userName);
                    //if (comCls.ExecuteReaderQuery("select bidder_id from CONTRACTORS where workOrder_No='" + txtWorkOrderNo.Text.Trim() + "'", sqlConn) == 0)
                    //{
                    //if(txtContractAmount.Text.Trim()!="")
                    //    comCls.ExecuteNonQuery("insert into WorkOrders(bidder_id,proj_id,co_id,stage_Id,workOrder_No,ContractTitle,ContractAmount,create_user,create_date,contract_status_id,workOrderAwardDate) values(" + cmbCompany.SelectedValue + "," + _projID + "," +
                    //    _cmpID + ",6,'" + txtWorkOrderNo.Text.Trim() + "','" + txtProjTitle.Text.Trim() + "'," + txtContractAmount.Text.Trim().Replace(",", "") + ",'" + _userName + "','" + DateTime.Now.ToString() + "',1,'" + Convert.ToDateTime(mskTxtWorkOrderClosingDate.Text).ToString() + "')", sqlConn);
                    //else
                    //    comCls.ExecuteNonQuery("insert into WorkOrders(bidder_id,proj_id,co_id,stage_Id,workOrder_No,ContractTitle,create_user,create_date,contract_status_id,workOrderAwardDate) values(" + MaxBidderID() + "," + _projID + "," +
                    //    _cmpID + ",6,'" + txtWorkOrderNo.Text.Trim() + "','" + txtProjTitle.Text.Trim() + "','" + _userName + "','" + DateTime.Now.ToString() + "',1,'" + Convert.ToDateTime(mskTxtWorkOrderClosingDate.Text).ToString() + "')", sqlConn);

                    //if (txtContractAmount.Text.Trim() != "")
                    string woStatus = null;                    
                    int noOfDays = comCls.DateDiff(mskTxtWorkOrderClosingDate.Text);
                    if (noOfDays <= 0)
                    {
                        if (noOfDays == 0)
                        {
                            if (DateTime.Now.TimeOfDay.Hours >= 13)
                                woStatus = "Closed";
                            else
                                woStatus = "Open";
                        }
                        else
                            woStatus = "Closed";
                    }
                    else
                        woStatus = "Open";

                    comCls.ExecuteNonQuery("insert into WorkOrders(proj_id,workOrderNo,workOrderTitle,create_user,create_date,workOrderClosingDate,workOrderStatus,workOrderIssueDate) values(" + _projID + "," +
                    "'" + txtWorkOrderNo.Text.Replace("'", "").Trim() + "','" + txtProjTitle.Text.Replace("'", "").Trim() + "','" + _userName + "','" + DateTime.Now.ToString() + "','" + Convert.ToDateTime(mskTxtWorkOrderClosingDate.Text).ToString() + "','" + woStatus + "','"+Convert.ToDateTime(mskTxtWOIssueDate.Text)+"')", sqlConn);
                    //else
                    //    comCls.ExecuteNonQuery("insert into WorkOrders(proj_id,workOrderNo,workOrderTitle,create_user,create_date,workOrderAwardDate) values(" + _projID + "," +
                    //    "'" + txtWorkOrderNo.Text.Trim() + "','" + txtProjTitle.Text.Trim() + "','" + _userName + "','" + DateTime.Now.ToString() + "','" + Convert.ToDateTime(mskTxtWorkOrderClosingDate.Text).ToString() + "')", sqlConn);                    
                    this.Close();
                    cmnCls.CreateWorkOrderGridViewColumns(_dgvWorkOrders, _projID, 0);                       
                    
                    
                    //}
                    //else
                    //{
                    //    MessageBox.Show("Work Order with the same name already exists, Can not Add a duplicate Work Order", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //    txtWorkOrderNo.Focus();
                    //}
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception occurred while inserting a new Work Order", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlConn.Close();
            }
        }
       

        //private void txtContractAmount_Leave(object sender, EventArgs e)
        //{
        //    if(txtContractAmount.Text.Trim()!="")
        //        txtContractAmount.Text = string.Format("{0:#,##0.00}", double.Parse(txtContractAmount.Text));
        //}

        private void txtContractAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }

        private bool nonNumberEntered = false;
        private void ValidateNumericAndDecimalInput(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != 8 && e.KeyChar != 13) //&& e.KeyChar.ToString().Contains('.').ToString().Length>=2
            {
                nonNumberEntered = true;
            }
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                nonNumberEntered = true;
                e.Handled = true;
            }

            if (nonNumberEntered == true)
            {
                MessageBox.Show("Please enter number only...");
                e.Handled = true;
            }
            nonNumberEntered = false;
        }

        private void dtpWorkOrderClosingDate_ValueChanged(object sender, EventArgs e)
        {
            dtpWorkOrderClosingDate.CustomFormat = "dd/MMM/yyyy";
            mskTxtWorkOrderClosingDate.Text = dtpWorkOrderClosingDate.Value.ToString("dd/MMM/yyyy");
            mskTxtWorkOrderClosingDate.Focus(); 
        }

        private void dtpWOIssueDate_ValueChanged(object sender, EventArgs e)
        {
            dtpWOIssueDate.CustomFormat = "dd/MMM/yyyy";
            mskTxtWOIssueDate.Text = dtpWOIssueDate.Value.ToString("dd/MMM/yyyy");
            mskTxtWOIssueDate.Focus(); 
        }       
         
    }
}
