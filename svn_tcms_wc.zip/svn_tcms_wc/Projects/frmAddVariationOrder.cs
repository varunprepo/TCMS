﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MDI_ParenrForm.Projects
{
    public partial class frmAddVariationOrder : Form
    {
        string mContractNo = null;
        int mBidderID = 0;
        public frmAddVariationOrder(string contractNo, int bidderID)
        {
            InitializeComponent();
            mBidderID = bidderID;
            mContractNo = contractNo;
            CalendarColumn voDate = new CalendarColumn();
            voDate.Name = "VOReqDate";
            voDate.HeaderText = "VO Request Date";
            voDate.Width = 40;
            dgvVOReqDate.Columns.Add(voDate);

            voDate = new CalendarColumn();
            voDate.Name = "CommitteeDecisionDate";
            voDate.HeaderText = "Committee Decision Date";
            voDate.Width = 40;
            dgvCommDecDate.Columns.Add(voDate);
        }

        private void btnAddVODetails_Click(object sender, EventArgs e)
        {
            try
            {
                string voID = null;
                using (SqlConnection sqlConn = new SqlConnection(ConfigurationSettings.AppSettings["TCMSConnString"].ToString()))
                {                    
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        if (sqlConn.State == ConnectionState.Closed)
                            sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "AddOrUpdateVO";
                        cmd.Parameters.AddWithValue("@voID",SqlDbType.Int).Direction = ParameterDirection.Output;
                        cmd.Parameters.AddWithValue("@voNo", txtVONo.Text);
                        cmd.Parameters.AddWithValue("@siNo", txtSINo.Text);
                        cmd.Parameters.AddWithValue("@voValue", txtVOVal.Text);
                        cmd.Parameters.AddWithValue("@voDuration", txtVODur.Text);
                        cmd.Parameters.AddWithValue("@voStatus", txtVOStatus.Text);
                        cmd.Parameters.AddWithValue("@voCurrentContractValue", txtCurrCntrtVal.Text);
                        cmd.Parameters.AddWithValue("@voNewContractValue", txtNewCntrtVal.Text);
                        cmd.Parameters.AddWithValue("@voCurrentContractDuration", txtCurrCntrtDur.Text);
                        cmd.Parameters.AddWithValue("@voNewContractDuration", txtNewCntrtDur.Text);
                        cmd.Parameters.AddWithValue("@contractNo", mContractNo);
                        cmd.Parameters.AddWithValue("@bidderId", mBidderID);
                        cmd.Parameters.AddWithValue("@isUpdate", 0);
                        cmd.ExecuteNonQuery();
                        voID = cmd.Parameters["@voID"].Value.ToString();
                    }
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        if (sqlConn.State == ConnectionState.Closed)
                            sqlConn.Open();
                        cmd.Connection = sqlConn;
                        foreach (DataGridViewRow dr in dgvVOReqDate.Rows)
                        {                             
                            cmd.CommandType = CommandType.Text;
                            cmd.Connection = sqlConn;
                            cmd.CommandText = "insert into VORequestDates (voID,voRequestDate) values (@voID,@voRequestDate)";
                            cmd.Parameters.AddWithValue("@voID",voID);
                            cmd.Parameters.AddWithValue("@voRequestDate", dr.Cells[0].Value.ToString());                            
                            cmd.ExecuteNonQuery();
                            cmd.Parameters.RemoveAt("@voID");
                            cmd.Parameters.RemoveAt("@voRequestDate");                            
                        }
                        foreach (DataGridViewRow dr in dgvCommDecDate.Rows)
                        {
                            cmd.CommandType = CommandType.Text;
                            cmd.Connection = sqlConn;
                            cmd.CommandText = "insert into VOCommDecDates (voID,voCommDecDate) values (@voID,@voCommDecDate)";
                            cmd.Parameters.AddWithValue("@voID", voID);
                            cmd.Parameters.AddWithValue("@voCommDecDate", dr.Cells[0].Value.ToString());                             
                            cmd.ExecuteNonQuery();
                            cmd.Parameters.RemoveAt("@voID");
                            cmd.Parameters.RemoveAt("@voCommDecDate");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Occurred while Adding the Variation Order");                 
            }
            
        }
    }
}
