﻿namespace MDI_ParenrForm.Projects
{
    partial class frmInactiveProjects
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgViewInactive = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.lblCntrVendor = new System.Windows.Forms.Label();
            this.txtVendor = new System.Windows.Forms.TextBox();
            this.lblCntrno = new System.Windows.Forms.Label();
            this.txtCntrNo = new System.Windows.Forms.TextBox();
            this.lblCntrTitle = new System.Windows.Forms.Label();
            this.txtCntrTitle = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgViewInactive)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgViewInactive
            // 
            this.dgViewInactive.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgViewInactive.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(236)))), ((int)(((byte)(236)))));
            this.dgViewInactive.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(236)))), ((int)(((byte)(236)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgViewInactive.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgViewInactive.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.Peru;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgViewInactive.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgViewInactive.Location = new System.Drawing.Point(12, 112);
            this.dgViewInactive.Name = "dgViewInactive";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgViewInactive.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgViewInactive.RowHeadersVisible = false;
            this.dgViewInactive.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dgViewInactive.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgViewInactive.Size = new System.Drawing.Size(1158, 589);
            this.dgViewInactive.TabIndex = 27;
            this.dgViewInactive.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgViewInactive_CellClick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.btnRefresh);
            this.groupBox1.Controls.Add(this.lblCntrVendor);
            this.groupBox1.Controls.Add(this.txtVendor);
            this.groupBox1.Controls.Add(this.lblCntrno);
            this.groupBox1.Controls.Add(this.txtCntrNo);
            this.groupBox1.Controls.Add(this.lblCntrTitle);
            this.groupBox1.Controls.Add(this.txtCntrTitle);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(9, 40);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1161, 66);
            this.groupBox1.TabIndex = 40;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Inactive Contracts Information";
            // 
            // btnRefresh
            // 
            this.btnRefresh.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefresh.ForeColor = System.Drawing.Color.Coral;
            this.btnRefresh.Image = global::MDI_ParenrForm.Properties.Resources.Button_Reload_icon;
            this.btnRefresh.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRefresh.Location = new System.Drawing.Point(1003, 18);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(84, 32);
            this.btnRefresh.TabIndex = 52;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // lblCntrVendor
            // 
            this.lblCntrVendor.AutoSize = true;
            this.lblCntrVendor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCntrVendor.Location = new System.Drawing.Point(507, 31);
            this.lblCntrVendor.Name = "lblCntrVendor";
            this.lblCntrVendor.Size = new System.Drawing.Size(46, 15);
            this.lblCntrVendor.TabIndex = 45;
            this.lblCntrVendor.Text = "Vendor";
            // 
            // txtVendor
            // 
            this.txtVendor.Location = new System.Drawing.Point(567, 28);
            this.txtVendor.Name = "txtVendor";
            this.txtVendor.Size = new System.Drawing.Size(155, 21);
            this.txtVendor.TabIndex = 44;
            this.txtVendor.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtVendor_KeyDown);
            this.txtVendor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtVendor_KeyPress);
            // 
            // lblCntrno
            // 
            this.lblCntrno.AutoSize = true;
            this.lblCntrno.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCntrno.Location = new System.Drawing.Point(39, 30);
            this.lblCntrno.Name = "lblCntrno";
            this.lblCntrno.Size = new System.Drawing.Size(71, 15);
            this.lblCntrno.TabIndex = 43;
            this.lblCntrno.Text = "Contract No";
            // 
            // txtCntrNo
            // 
            this.txtCntrNo.Location = new System.Drawing.Point(124, 28);
            this.txtCntrNo.Name = "txtCntrNo";
            this.txtCntrNo.Size = new System.Drawing.Size(129, 21);
            this.txtCntrNo.TabIndex = 42;
            this.txtCntrNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtCntrNo_KeyDown);
            this.txtCntrNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCntrNo_KeyPress);
            // 
            // lblCntrTitle
            // 
            this.lblCntrTitle.AutoSize = true;
            this.lblCntrTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCntrTitle.Location = new System.Drawing.Point(259, 31);
            this.lblCntrTitle.Name = "lblCntrTitle";
            this.lblCntrTitle.Size = new System.Drawing.Size(78, 15);
            this.lblCntrTitle.TabIndex = 41;
            this.lblCntrTitle.Text = "Contract Title";
            // 
            // txtCntrTitle
            // 
            this.txtCntrTitle.Location = new System.Drawing.Point(357, 28);
            this.txtCntrTitle.Name = "txtCntrTitle";
            this.txtCntrTitle.Size = new System.Drawing.Size(143, 21);
            this.txtCntrTitle.TabIndex = 40;
            this.txtCntrTitle.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtCntrTitle_KeyDown);
            this.txtCntrTitle.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCntrTitle_KeyPress);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Gray;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button3.Cursor = System.Windows.Forms.Cursors.Default;
            this.button3.ForeColor = System.Drawing.Color.Red;
            this.button3.Image = global::MDI_ParenrForm.Properties.Resources.Actions_window_close_icon;
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(1088, 18);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(68, 32);
            this.button3.TabIndex = 53;
            this.button3.Text = "Close";
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // frmInactiveProjects
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(236)))), ((int)(((byte)(236)))));
            this.ClientSize = new System.Drawing.Size(1182, 713);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dgViewInactive);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmInactiveProjects";
            this.Text = "Pwa Inactive Projects Information";
            this.Load += new System.EventHandler(this.frmInactiveProjects_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgViewInactive)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgViewInactive;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblCntrVendor;
        private System.Windows.Forms.TextBox txtVendor;
        private System.Windows.Forms.Label lblCntrno;
        private System.Windows.Forms.TextBox txtCntrNo;
        private System.Windows.Forms.Label lblCntrTitle;
        private System.Windows.Forms.TextBox txtCntrTitle;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button button3;
    }
}