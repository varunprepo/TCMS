﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace MDI_ParenrForm.Projects
{
    public partial class frmExtDatesInfo : Form
    {
        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();
        int _prjID = 0;
        public frmExtDatesInfo(int PrjID)
        {
            InitializeComponent();
            _prjID = PrjID;
        }

        // Developed and modified by Varun on 25/02/14 
        private void frmExtDatesInfo_Load(object sender, EventArgs e)
        {
            string strQuery = "SELECT  org_tender_validity, org_tenderbond_validity, tender_validity_ext1,tenderbond_validity_ext1,tender_validity_ext2,tenderbond_validity_ext2,org_tender_to_expire," +
            "org_tenderbond_to_expire FROM TenderDatesInfo WHERE (proj_id = " + _prjID + ") AND (stage_id = 2) and ts_tender_issue is NULL";            

            using (SqlConnection sqlCn = new SqlConnection(strCon))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                    {
                        if (sqlDr.HasRows)
                        {
                            while (sqlDr.Read())
                            {
                                if (sqlDr[0].ToString() != "")
                                {
                                    if (sqlDr[0].ToString() != "")                                    
                                        msk_dtpTV_OrgDate_Cp.Text = Convert.ToDateTime(sqlDr[0].ToString()).ToString("dd/MMM/yyyy");                                                                              

                                    if (sqlDr[1].ToString() != "")                                        
                                        msk_dtpTBV_OrgDate_Cp.Text = Convert.ToDateTime(sqlDr[1].ToString()).ToString("dd/MMM/yyyy");                                                                                     

                                    if (sqlDr[2].ToString() != "") 
                                        msk_dtpTV_FEdate_Cp.Text = Convert.ToDateTime(sqlDr[2].ToString()).ToString("dd/MMM/yyyy");                                                                                  

                                    if (sqlDr[3].ToString() != "") 
                                        msk_dtpTBV_FEdate_Cp.Text = Convert.ToDateTime(sqlDr[3].ToString()).ToString("dd/MMM/yyyy");                                              
                                    
                                    if (sqlDr[4].ToString() != "")                                        
                                        msk_dtpTV_SEdate_Cp.Text = Convert.ToDateTime(sqlDr[4].ToString()).ToString("dd/MMM/yyyy");                                                                                  

                                    if (sqlDr[5].ToString() != "")                                        
                                        msk_dtpTBV_SEdate_Cp.Text = Convert.ToDateTime(sqlDr[5].ToString()).ToString("dd/MMM/yyyy");                                                                                     

                                    if (sqlDr[6].ToString() != "")                                        
                                        txtCp_TVDays.Text =sqlDr[6].ToString();                           
                                    
                                    if (sqlDr[7].ToString() != "")
                                        txtCp_TBVDays.Text = sqlDr[7].ToString();                                                   
                                } 
                            }
                        }
                    }
                }
                sqlCn.Close();
            }
        }
    }
}
