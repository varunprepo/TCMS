﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using TenderTrackingSystem;
using DataGridViewAutoFilter;
using System.Data.SqlClient;

namespace MDI_ParenrForm.Projects
{
    public partial class frmOngoingContracts : Form
    {
        static string staticUserName = null;        

        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();

        // Protected Connection.
        protected SqlConnection sqlConn;
        protected SqlCommand sqlCom;

        protected SqlDataReader sqlReader;
        private System.Windows.Forms.Label label1;

        CreateCheckBox chkBox = null;
        CheckBox headerCheckBox = null;

        DataTable dtTemp = null;
        DataTable dtTempForCombo = null;

        IList<string> userRightsColl = new List<string>();
        string _userName = string.Empty;
        string _projectTitle = null;
        bool _isHeadOfSection = false;

        public frmOngoingContracts(IList<string> userRightsCollOngoing, string user, bool isHeadOfSection,string projectTitle)
        {
            InitializeComponent();
            userRightsColl = getUserAccessList();
            _userName = user;
            _isHeadOfSection = isHeadOfSection;
            _projectTitle = projectTitle;
        }
        private IList<string> getUserAccessList()
        {
            userRightsColl.Clear();
            SqlConnection sqlConn = new SqlConnection(strCon);

            string sqlQuery = "SELECT  UserAccessRights.AccessID,UserAccessRights.[AccessRights], UserPrivelege.HasPrivelege, UserPrivelege.user_profile_id, UserSecurityProfile.profile_name, USERS.user_id, " +
            " USERS.user_name FROM UserAccessRights INNER JOIN UserPrivelege ON UserAccessRights.AccessID = UserPrivelege.AccessID INNER JOIN " +
            " UserSecurityProfile ON UserPrivelege.user_profile_id = UserSecurityProfile.user_profile_id INNER JOIN " +
            " USERS ON UserSecurityProfile.user_profile_id = USERS.user_profile_id WHERE (UserPrivelege.HasPrivelege = 0) AND (USERS.user_name = '" + _userName + "') ORDER BY UserAccessRights.AccessID";

            try
            {
                sqlConn.Open();
                SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
                SqlDataReader sqlReader = sqlCom.ExecuteReader();
                while (sqlReader.Read())
                {
                    userRightsColl.Add(sqlReader[0].ToString());
                }
                sqlReader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error getting while reading data !" + ex.Message);
            }
            finally
            {
                sqlConn.Close();
            }
            return userRightsColl;
        }
        string filterQuery = string.Empty;
        private void frmOngoingContracts_Load(object sender, EventArgs e)
        {
            if (!userRightsColl.Contains("54"))
            {
                rePopulateDataGridView_Contact_Person_EntryData("");
            }
            else
            {
                if (!userRightsColl.Contains("55"))
                {
                    filterQuery = "'" + "GTC" + "'";
                }
                if (!userRightsColl.Contains("56"))
                {
                    if (filterQuery == "")
                        filterQuery = "'" + "STC" + "'";
                    else
                        filterQuery = filterQuery + "," + "'" + "STC" + "'";

                }
                if (!userRightsColl.Contains("57"))
                {
                    if (filterQuery == "")
                        filterQuery = "'" + "ITC" + "'";
                    else
                        filterQuery = filterQuery + "," + "'" + "ITC" + "'";
                }
                if (!userRightsColl.Contains("58"))
                {
                    if (filterQuery == "")
                        filterQuery = "'" + "MRPSC" + "'";
                    else
                        filterQuery = filterQuery + "," + "'" + "MRPSC" + "'";

                    // filterQuery = filterQuery + "," + "'" + "MRPCS" + "'";
                }
                if (!userRightsColl.Contains("59"))
                {
                    if (filterQuery == "")
                        filterQuery = "'" + "U&EWTC" + "'";
                    else
                        filterQuery = filterQuery + "," + "'" + "U&EWTC" + "'";
                }
                if (!userRightsColl.Contains("60"))
                {
                    if (filterQuery == "")
                        filterQuery = "'" + "WPC" + "'";
                    else
                        filterQuery = filterQuery + "," + "'" + "WPC" + "'";
                }
                if (filterQuery == "")
                    filterQuery = "'" + "NC" + "'";
                else
                    filterQuery = filterQuery + "," + "'" + "NC" + "'";

                //filterQueryMain = filterQuery;

                rePopulateDataGridView_Contact_Person_EntryData(filterQuery);
            }
        }
        private void rePopulateDataGridView_Contact_Person_EntryData(string committesList)
        {
            //InitializeComponent();

            //headerCheckBox = new CheckBox();
            //chkBox = new CreateCheckBox(dgView, headerCheckBox);
            //chkBox.AddHeaderCheckBox();

            if (dgViewOngoing.ColumnCount == 0)
            {

                //this.dgViewOngoing.CellContentClick += new DataGridViewCellEventHandler(dgViewOngoing_CellContentClick);


                var col0 = new DataGridViewCheckBoxColumn();
                var col1 = new DataGridViewLinkColumn();    // DataGridViewAutoFilterTextBoxColumn(); //DataGridViewLinkColumn

                //var col1 = new DataGridViewAutoFilterTextBoxColumn();
                var col2 = new DataGridViewAutoFilterTextBoxColumn();
                var col3 = new DataGridViewAutoFilterTextBoxColumn();
                var col4 = new DataGridViewAutoFilterTextBoxColumn();
                var col5 = new DataGridViewAutoFilterTextBoxColumn();
                var col6 = new DataGridViewAutoFilterTextBoxColumn();
                var col7 = new DataGridViewAutoFilterTextBoxColumn();
                var col8 = new DataGridViewLinkColumn();
                var col9 = new DataGridViewAutoFilterTextBoxColumn();
                var col10 = new DataGridViewTextBoxColumn();
                var col11 = new DataGridViewTextBoxColumn();
                var col12 = new DataGridViewTextBoxColumn();

                dgViewOngoing.Columns.AddRange(new DataGridViewColumn[] { col0, col1, col2, col3, col4, col5, col6, col7, col8, col9, col10, col11, col12 });                

                dgViewOngoing.AutoGenerateColumns = false;
                dgViewOngoing.AllowUserToAddRows = false;

                //dgView.AutoResizeColumns();

                col0.Name = "chkBxSelect";
                col0.DataPropertyName = "";
                col0.HeaderText = "";
                col0.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
                col0.Width = 50;
                col0.Visible = false;

                col1.DataPropertyName = "ContractNo";
                col1.HeaderText = "Contract No";
                col1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
                col1.Width = 90;
                col1.LinkBehavior = LinkBehavior.NeverUnderline;

                col2.DataPropertyName = "ContractTitle";
                col2.HeaderText = "Contract Title";
                col2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
                col2.Width = 140;

                col3.DataPropertyName = "ContractStartDate";
                col3.HeaderText = "Contract StartDate";
                col3.Resizable = System.Windows.Forms.DataGridViewTriState.True;

                col4.DataPropertyName = "ContractEndDate";
                col4.HeaderText = "Contract FinishDate";
                col4.Resizable = System.Windows.Forms.DataGridViewTriState.True;

                col5.DataPropertyName = "BondExpiry";
                col5.HeaderText = "Performancebond ExpiryDate";
                col5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
                col5.Width = 110;
                col6.DataPropertyName = "Vendor";
                col6.HeaderText = "Contractor /Vendor";
                col6.Resizable = System.Windows.Forms.DataGridViewTriState.True;

                col7.DataPropertyName = "Type";
                col7.HeaderText = "Type";
                col7.Resizable = System.Windows.Forms.DataGridViewTriState.True;
                col7.Width = 80;

                col8.DataPropertyName = "ProjectCode";
                col8.HeaderText = "Project Code";
                col8.Width = 130;
                col8.Resizable = System.Windows.Forms.DataGridViewTriState.True;
                col8.LinkBehavior = LinkBehavior.HoverUnderline;

                col9.DataPropertyName = "TypeOfContract";
                col9.HeaderText = "TypeOf Contract";
                col9.Resizable = System.Windows.Forms.DataGridViewTriState.True;

                col10.DataPropertyName = "BidID";
                col10.HeaderText = "BidID";
                col10.Resizable = System.Windows.Forms.DataGridViewTriState.True;

                col11.DataPropertyName = "ProjID";
                col11.HeaderText = "ProjID";
                col11.Resizable = System.Windows.Forms.DataGridViewTriState.True;
                col12.DataPropertyName = "CoID";
                col12.HeaderText = "CoID";
                col12.Resizable = System.Windows.Forms.DataGridViewTriState.True;

                //col12.DataPropertyName = "Tender Committee";
                //col12.HeaderText = "Tender Committee";
                //col12.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            }

            BindingSource myBindingSource = null;
            try
            {
                DataTable finalDt = new DataTable("Company");
                finalDt.Columns.Add("Select");
                finalDt.Columns.Add("ContractNo");
                finalDt.Columns.Add("ContractTitle");
                finalDt.Columns.Add("ContractStartDate");
                finalDt.Columns.Add("ContractEndDate");
                finalDt.Columns.Add("BondExpiry");
                finalDt.Columns.Add("Vendor");
                finalDt.Columns.Add("Type");
                finalDt.Columns.Add("ProjectCode");
                finalDt.Columns.Add("TypeOfContract");
                finalDt.Columns.Add("BidID");
                finalDt.Columns.Add("ProjID");
                finalDt.Columns.Add("CoID");
               // finalDt.Columns.Add("Committee");

                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();

                //SELECT FORMAT ( GETDATE(), 'dd mon yyyy HH:m:ss:mmm', 'en-US' ) AS DateConvert;

                string sqlQuery = string.Empty;
                if (filterQuery == "")

               sqlQuery = "SELECT CONTRACTORS.bidder_id, CONTRACTORS.contract_status_id, PROJECTS.project_code, CONTRACTORS.proj_id, CONTRACTORS.contract_no, " +
                      " CONTRACTORS.[ContractTitle], CONVERT(varchar(11), CONTRACTORS.StartDate, 101) AS StartDate, CONVERT(varchar(11), " +
                      " CONTRACTORS.FinishDate, 101) AS EndDate, CONVERT(varchar(11), CONTRACTORS.[PB_Expiry_Date], 101) AS BondExpireDate, " +
                      "COMPANY.co_name, COMPANY_TYPE.co_type_name, [ContractStatus].[ContractStatus], PROJECTS.contract_type_id, " +
                      "[ContractTypes].type_short_name, [ContractTypes].[TypeofContract],CONTRACTORS.co_id,PROJECTS.committee_id, Committee.committee_short_name " +
                      " FROM  Committee RIGHT OUTER JOIN [ContractTypes] INNER JOIN " +
                      " PROJECTS ON [ContractTypes].contract_type_id = PROJECTS.contract_type_id ON Committee.committee_id = PROJECTS.committee_id INNER JOIN " +
                      " COMPANY_TYPE INNER JOIN COMPANY ON COMPANY_TYPE.co_type_id = COMPANY.co_type_id INNER JOIN [ContractStatus] INNER JOIN " +
                      " CONTRACTORS ON [ContractStatus].contract_status_id = CONTRACTORS.contract_status_id ON COMPANY.co_id = CONTRACTORS.co_id ON " +
                      " PROJECTS.proj_id = CONTRACTORS.proj_id WHERE  (CONTRACTORS.contract_status_id = 1) AND (CONTRACTORS.contract_no IS NOT NULL) AND (CONTRACTORS.contract_no <> '') ORDER BY PROJECTS.dummyfield DESC";
                
                else

                    sqlQuery = "SELECT CONTRACTORS.bidder_id, CONTRACTORS.contract_status_id, PROJECTS.project_code, CONTRACTORS.proj_id, CONTRACTORS.contract_no, " +
                      " CONTRACTORS.[ContractTitle], CONVERT(varchar(11), CONTRACTORS.StartDate, 101) AS StartDate, CONVERT(varchar(11), " +
                      " CONTRACTORS.FinishDate, 101) AS EndDate, CONVERT(varchar(11), CONTRACTORS.[PB_Expiry_Date], 101) AS BondExpireDate, " +
                      "COMPANY.co_name, COMPANY_TYPE.co_type_name, [ContractStatus].[ContractStatus], PROJECTS.contract_type_id, " +
                      "[ContractTypes].type_short_name, [ContractTypes].[TypeofContract],CONTRACTORS.co_id,PROJECTS.committee_id, Committee.committee_short_name " +
                      " FROM  Committee RIGHT OUTER JOIN [ContractTypes] INNER JOIN " +
                      " PROJECTS ON [ContractTypes].contract_type_id = PROJECTS.contract_type_id ON Committee.committee_id = PROJECTS.committee_id INNER JOIN " +
                      " COMPANY_TYPE INNER JOIN COMPANY ON COMPANY_TYPE.co_type_id = COMPANY.co_type_id INNER JOIN [ContractStatus] INNER JOIN " +
                      " CONTRACTORS ON [ContractStatus].contract_status_id = CONTRACTORS.contract_status_id ON COMPANY.co_id = CONTRACTORS.co_id ON " +
                      " PROJECTS.proj_id = CONTRACTORS.proj_id WHERE  (CONTRACTORS.contract_status_id = 1) AND (CONTRACTORS.contract_no IS NOT NULL) AND (CONTRACTORS.contract_no <> '') And ([Committee].committee_short_name in (" + committesList + ")) ORDER BY PROJECTS.dummyfield DESC";
                

                finalDt.AcceptChanges();
                sqlCom = new SqlCommand(sqlQuery, sqlConn);
                sqlReader = sqlCom.ExecuteReader();

                while (sqlReader.Read())
                {
                    //if (sqlReader[4].ToString() != "")
                    //{
                        DataRow dr = finalDt.NewRow();
                        dr[1] = sqlReader[4];     //ContractNo
                        dr[2] = sqlReader[5];     //ContractTitle
                        dr[3] = sqlReader[6];     //ContractStartDate
                        dr[4] = sqlReader[7];     //ContractEndDate
                        dr[5] = sqlReader[8];     //BondExpiry
                        dr[6] = sqlReader[9];     //Vendor
                        dr[7] = sqlReader[10];     //Type
                        dr[8] = sqlReader[2];     //ProjectCode
                        dr[9] = sqlReader[14];    //TypeOfContract
                        dr[10] = sqlReader[0];    //BidID
                        dr[11] = sqlReader[3];    //PrjID
                        dr[12] = sqlReader[15];    //CoID                         

                        finalDt.Rows.Add(dr);
                        finalDt.AcceptChanges();
                    //}
                }

                sqlReader.Close();
                myBindingSource = new BindingSource(finalDt, null);
                dgViewOngoing.DataSource = myBindingSource;

                dtTemp = finalDt;
                dtTempForCombo = finalDt;

                //dgView.ColumnHeadersDefaultCellStyle.BackColor = Color.Olive;
                //dgView.ColumnHeadersDefaultCellStyle.ForeColor = Color.Blue;

                //dgViewOngoing.ColumnHeadersDefaultCellStyle.Font = new Font(dgViewOngoing.Font, FontStyle.Bold);
                dgViewOngoing.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

               // dgView.EnableHeadersVisualStyles = false;

                dgViewOngoing.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
                dgViewOngoing.RowsDefaultCellStyle.WrapMode = DataGridViewTriState.True;
                dgViewOngoing.RowsDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgViewOngoing.ReadOnly = true;

                dgViewOngoing.Columns[10].Visible = false;
                dgViewOngoing.Columns[11].Visible = false;
                dgViewOngoing.Columns[12].Visible = false;
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }

            //dgView.ColumnHeadersDefaultCellStyle.BackColor = Color.Green;
            //dgView.ColumnHeadersDefaultCellStyle.ForeColor = Color.GreenYellow;
           // dgViewOngoing.ColumnHeadersDefaultCellStyle.Font = new Font(dgViewOngoing.Font, FontStyle.Bold);
            dgViewOngoing.EnableHeadersVisualStyles = false;

           // headerCheckBox.KeyUp += new KeyEventHandler(chkBox.HeaderCheckBox_KeyUp);
            //headerCheckBox.MouseClick += new MouseEventHandler(chkBox.HeaderCheckBox_MouseClick);
           // dgView.CellValueChanged += new DataGridViewCellEventHandler(chkBox.dgvSelectAll_CellValueChanged);
           // dgView.CurrentCellDirtyStateChanged += new EventHandler(chkBox.dgvSelectAll_CurrentCellDirtyStateChanged);
            //dgView.CellPainting += new DataGridViewCellPaintingEventHandler(chkBox.dgvSelectAll_CellPainting);              

            this.label1 = new Label();
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Service Uri:";
        }

        private void dgViewOngoing_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 1)
            {
                string mnstryCode = string.Empty;
                string prvsnNo = string.Empty;
                string tendrStatus = string.Empty;
                string budgetRefNo = string.Empty;
                int rowIndex = e.RowIndex;
                //int colIndex = e.ColumnIndex;
                try
                {
                    //   frmContractsEntry contractsEntry = new frmContractsEntry(0, dgView.Rows[e.RowIndex].Cells[1].Value.ToString(), dgView.Rows[e.RowIndex].Cells[2].Value.ToString(), dgView.Rows[e.RowIndex].Cells[3].Value.ToString(), staticUserName, dgView.Rows[e.RowIndex].Cells[4].Value.ToString(), mnstryCode, prvsnNo, budgetRefNo, dgView.Rows[e.RowIndex].Cells[6].Value.ToString());
                    frmContractsEntry contractsEntry = null;
                    if (dgViewOngoing.Rows[rowIndex].Cells[1].Value.ToString().ToLower() != "framework")
                    {
                        contractsEntry = new frmContractsEntry(userRightsColl, Convert.ToInt32(dgViewOngoing.Rows[rowIndex].Cells[10].Value), Convert.ToInt32(dgViewOngoing.Rows[rowIndex].Cells[11].Value), null, _userName, _isHeadOfSection, null, null, null, null);
                    }
                    else if (dgViewOngoing.Rows[rowIndex].Cells[1].Value.ToString().ToLower() == "framework")
                    {
                        sqlConn = new SqlConnection(strCon);
                        sqlConn.Open();
                        sqlCom = new SqlCommand("select proj.project_name_en,proj.tender_no,tdi.ts_modified_closing,tdi.ts_closing_s1 PROJECTS proj inner join TenderDatesInfo tdi on proj.proj_id=tdi.proj_id  " +
                        "where tdi.proj_id=" + dgViewOngoing.Rows[rowIndex].Cells[11].Value +"", sqlConn);
                        sqlReader = sqlCom.ExecuteReader();
                        sqlReader.Read();
                        string projectName = sqlReader[0].ToString();
                        string tenderNo =  sqlReader[1].ToString();
                        string modifiedClosing = sqlReader[2].ToString();
                        string closingDate = sqlReader[3].ToString();
                        sqlReader.Close();
                        sqlConn.Close();
                        contractsEntry = new frmContractsEntry(userRightsColl, Convert.ToInt32(dgViewOngoing.Rows[rowIndex].Cells[10].Value), Convert.ToInt32(dgViewOngoing.Rows[rowIndex].Cells[11].Value), dgViewOngoing.Rows[rowIndex].Cells[12].Value.ToString(), _userName, _isHeadOfSection, projectName, tenderNo, modifiedClosing, closingDate);
                    }

                    //frmContractsEntry contractsEntry = new frmContractsEntry(userRightsColl, Convert.ToInt16(dgViewOngoing.Rows[e.RowIndex].Cells[10].Value), Convert.ToInt16(dgViewOngoing.Rows[e.RowIndex].Cells[11].Value),null,_userName,_isHeadOfSection);
                    contractsEntry.StartPosition = FormStartPosition.CenterParent;
                    contractsEntry.ShowDialog();
                }
                catch (Exception ex)
                {
                }
                finally
                {
                }
            }
            if (e.ColumnIndex == 8)
            {
                try
                {
                    ProjectStages projStg = new ProjectStages(userRightsColl, "", Convert.ToInt16(dgViewOngoing.Rows[e.RowIndex].Cells[11].Value),_userName,null,_isHeadOfSection);
                    // ProjectStages projStg = new ProjectStages(Convert.ToInt16(dgView.Rows[e.RowIndex].Cells[0].Value));                 
                    projStg.StartPosition = FormStartPosition.CenterParent;
                    projStg.ShowDialog();
                }
                catch (Exception ex)
                {

                }
                finally
                {
                    sqlConn.Close();
                }
            }
        }
        
        private void GridFill(string filterQuery)
        {
            dtTempForCombo = dtTemp;
            int iCnt = dtTempForCombo.Rows.Count;
            DataTable dtCmbTbl = null;
            if (dtTempForCombo.Select(filterQuery).Length != 0)
            {
                dtCmbTbl = dtTempForCombo.Select(filterQuery).CopyToDataTable();
                int jCnt = dtCmbTbl.Rows.Count;
                try
                {
                    BindingSource myBindingSource = new BindingSource(dtCmbTbl, null);
                    dgViewOngoing.DataSource = myBindingSource;

                    dtTempForCombo = dtCmbTbl;

                    dgViewOngoing.EnableHeadersVisualStyles = false;
                    dgViewOngoing.Columns[0].Visible = false;
                    lblCnt.Text = dgViewOngoing.Rows.Count.ToString();
                }
                catch (Exception ex)
                {
                    string exMsg = ex.Message;
                }
                finally
                {
                }
            }
            else
            {
                DataTable nullTable = new DataTable();
                dtCmbTbl = null;
                BindingSource myBindingSource2 = new BindingSource(nullTable, null);
                dgViewOngoing.DataSource = myBindingSource2;
            }
        }
        private void txtContractNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtContractNo.Text == "" && (e.KeyChar >= 0 && e.KeyChar <= 47) || e.KeyChar == 127 || (e.KeyChar >= 58 && e.KeyChar <= 64) || (e.KeyChar >= 91 && e.KeyChar <= 96) || (e.KeyChar >= 123 && e.KeyChar <= 126))
            {
                GridFill("");
            }
            else if ((e.KeyChar >= 0 && e.KeyChar <= 47) || e.KeyChar == 127 || (e.KeyChar >= 58 && e.KeyChar <= 64) || (e.KeyChar >= 91 && e.KeyChar <= 96) || (e.KeyChar >= 123 && e.KeyChar <= 126))
            {
                string filterQuery = "ContractNo like '" + "%" + txtContractNo.Text.Remove(txtContractNo.Text.Length-1) + "%" + "'";
                GridFill(filterQuery);
            }
            else
            {                
                filterQuery = "ContractNo like '" + "%" + txtContractNo.Text + e.KeyChar.ToString() + "%" + "'";
                GridFill(filterQuery);
            } 

            //filterCombo();
        }

        private void txtContractTitle_KeyDown(object sender, KeyEventArgs e)
        {

        }
        
        private void filterCombo()
        {
            string filterQuery = string.Empty;
        
            if (txtContractNo.Text != "")
            {

                if (filterQuery == "")
                {
                    filterQuery = "ContractNo like '" + "%" + txtContractNo.Text + "%" + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "ContractNo like '" + "%" + txtContractNo.Text + "%" + "'";
                }
            }
            if (txtContractTitle.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "ContractTitle like '" + "%" + txtContractTitle.Text + "%" + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "ContractTitle like '" + "%" + txtContractNo.Text + "%" + "'";
                }
            }
            if (txtVendor.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "Vendor like '" + "%" + txtVendor.Text + "%" + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "Vendor like '" + "%" + txtVendor.Text + "%" + "'";
                }
            }           
           
            if (filterQuery == "")
            {
                GridFill("");
            }
            else
            {
                GridFill(filterQuery);
            }
        }

      

        private void dgViewOngoing_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnAddNewContract_Click(object sender, EventArgs e)
        {
            if (userRightsColl.Contains("1"))   //Add New Project
            {
                MessageBox.Show("You have no privilege to add project,Contact administrator");
                return;
            }
            MDI_ParenrForm.Projects.frmProjectInfo prjInfo = new MDI_ParenrForm.Projects.frmProjectInfo(userRightsColl, "Contracts Form",false);
            prjInfo.StartPosition = FormStartPosition.CenterScreen;
            prjInfo.ShowDialog();

            //RefreshProjectData();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            txtContractNo.Text = "";
            txtContractTitle.Text = "";
            txtVendor.Text = "";

            rePopulateDataGridView_Contact_Person_EntryData(filterQuery);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void txtContractTitle_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtContractTitle.Text == "" && (e.KeyChar >= 0 && e.KeyChar <= 47) || e.KeyChar == 127 || (e.KeyChar >= 58 && e.KeyChar <= 64) || (e.KeyChar >= 91 && e.KeyChar <= 96) || (e.KeyChar >= 123 && e.KeyChar <= 126))
            {
                GridFill("");
            }
            else if ((e.KeyChar >= 0 && e.KeyChar <= 47) || e.KeyChar == 127 || (e.KeyChar >= 58 && e.KeyChar <= 64) || (e.KeyChar >= 91 && e.KeyChar <= 96) || (e.KeyChar >= 123 && e.KeyChar <= 126))
            {
                string filterQuery = "ContractTitle like '" + "%" + txtContractTitle.Text.Remove(txtContractTitle.Text.Length - 1) + "%" + "'";
                GridFill(filterQuery);
            }
            else
            {
                filterQuery = "ContractTitle like '" + "%" + txtContractTitle.Text + e.KeyChar.ToString() + "%" + "'";
                GridFill(filterQuery);
            } 
        }

        private void txtVendor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtVendor.Text == "" && (e.KeyChar >= 0 && e.KeyChar <= 47) || e.KeyChar == 127 || (e.KeyChar >= 58 && e.KeyChar <= 64) || (e.KeyChar >= 91 && e.KeyChar <= 96) || (e.KeyChar >= 123 && e.KeyChar <= 126))
            {
                GridFill("");
            }
            else if ((e.KeyChar >= 0 && e.KeyChar <= 47) || e.KeyChar == 127 || (e.KeyChar >= 58 && e.KeyChar <= 64) || (e.KeyChar >= 91 && e.KeyChar <= 96) || (e.KeyChar >= 123 && e.KeyChar <= 126))
            {
                string filterQuery = "Vendor like '" + "%" + txtVendor.Text.Remove(txtVendor.Text.Length - 1) + "%" + "'";
                GridFill(filterQuery);
            }
            else
            {
                filterQuery = "Vendor like '" + "%" + txtVendor.Text + e.KeyChar.ToString() + "%" + "'";
                GridFill(filterQuery);
            } 
        }

        Int32 id1 = 1;
        Int32 id2 = 25;
        private string NavClicked = "";
        int CurrentPage = 1;
        bool isRefresh = true;

        #region DeterminePageBoundaries
        // This method will determine the correct
        // Page Boundaries for the RecordID's to filter by
        private void DeterminePageBoundaries()
        {
            int totalRowCount = 0;
            if (dtCmbTbl != null && isRefresh == false)
            {
                totalRowCount = dtCmbTbl.Rows.Count;
                dtTemp = dtCmbTbl;
            }
            else
                totalRowCount = dtTemp.Rows.Count;

            //This is the maximum rows to display on a page.
            //So we want paging to be implemented at 100 rows a page                          
            int pageRows = 23;
            int pages = 0;

            //If the rows per page are less than
            //the total row count do the following:
            if (pageRows < totalRowCount)
            {
                //If the Modulus returns > 0 then there should be another page.
                if ((totalRowCount % pageRows) > 0)
                {
                    pages = ((totalRowCount / pageRows) + 1);
                }
                else
                {
                    //There is nothing left after the Modulus,
                    //so the pageRows divide exactly...
                    //...into TotalRowCount leaving no rest,
                    //thus no extra page needs to be added.
                    pages = totalRowCount / pageRows;
                }
            }
            else
            {
                //If the rows per page are more than the total
                //row count, we will obviously only ever have 1 page
                pages = 1;
            }

            //Added By Varun on 24/02/14 for creating pagination functionality
            //We now need to determine the LowerBoundary
            //and UpperBoundary in order to correctly...
            //...determine the Correct RecordID's
            //to use in the bindingSource1.Filter property.
            int LowerBoundary = 0;
            int UpperBoundary = 0;

            //We now need to know what button was clicked,
            //if any (First, Last, Next, Previous)
            switch (NavClicked)
            {
                case "First":
                    //First clicked, the Current Page will always be 1
                    CurrentPage = 1;
                    //The LowerBoundary will thus be ((50 * 1) - (50 - 1)) = 1
                    LowerBoundary = ((pageRows * CurrentPage) - (pageRows - 1));

                    //If the rows per page are less than
                    //the total row count do the following:
                    if (pageRows < totalRowCount)
                    {
                        UpperBoundary = (pageRows * CurrentPage);
                    }
                    else
                    {
                        //If the rows per page are more than
                        //the total row count do the following:
                        //There is only one page, so get
                        //the total row count as an UpperBoundary
                        UpperBoundary = totalRowCount;
                    }

                    //Now using these boundaries, get the
                    //appropriate RecordID's (min & max)...
                    //...for this specific page.
                    //Remember, .NET is 0 based, so subtract 1 from both boundaries
                    id1 = Convert.ToInt16(dtTemp.Rows[LowerBoundary - 1]["ID"]);
                    id2 = Convert.ToInt16(dtTemp.Rows[UpperBoundary - 1]["ID"]);

                    break;

                case "Last":
                    //Last clicked, the CurrentPage will always be = to the variable pages
                    CurrentPage = pages;
                    LowerBoundary = ((pageRows * CurrentPage) - (pageRows - 1));
                    //The UpperBoundary will always be the sum total of all the rows
                    UpperBoundary = totalRowCount;

                    //Now using these boundaries, get the appropriate
                    //RecordID's (min & max)...
                    //...for this specific page.
                    //Remember, .NET is 0 based, so subtract 1 from both boundaries
                    id1 = Convert.ToInt16(dtTemp.Rows[LowerBoundary - 1]["ID"]);
                    id2 = Convert.ToInt16(dtTemp.Rows[UpperBoundary - 1]["ID"]);

                    break;

                case "Next":
                    //Next clicked
                    if (CurrentPage != pages)
                    {
                        //If we arent on the last page already, add another page
                        CurrentPage += 1;
                    }

                    LowerBoundary = ((pageRows * CurrentPage) - (pageRows - 1));

                    if (CurrentPage == pages)
                    {
                        //If we are on the last page, the UpperBougndary
                        //will always be the sum total of all the rows
                        UpperBoundary = totalRowCount;
                    }
                    else
                    {
                        //Else if we have a pageRow of 50 and we are
                        //on page 3, the UpperBoundary = 150
                        UpperBoundary = (pageRows * CurrentPage);
                    }

                    //Now using these boundaries, get the appropriate
                    //RecordID's (min & max)...
                    //...for this specific page.
                    //Remember, .NET is 0 based, so subtract 1 from both boundaries

                    id1 = Convert.ToInt16(dtTemp.Rows[LowerBoundary - 1]["ID"]);
                    id2 = Convert.ToInt16(dtTemp.Rows[UpperBoundary - 1]["ID"]);

                    break;

                case "Previous":
                    //Previous clicked
                    if (CurrentPage != 1)
                    {
                        //If we aren't on the first page already,
                        //subtract 1 from the CurrentPage
                        CurrentPage -= 1;
                    }
                    //Get the LowerBoundary
                    LowerBoundary = ((pageRows * CurrentPage) - (pageRows - 1));

                    if (pageRows < totalRowCount)
                    {
                        UpperBoundary = (pageRows * CurrentPage);
                    }
                    else
                    {
                        UpperBoundary = totalRowCount;
                    }

                    //Now using these boundaries,
                    //get the appropriate RecordID's (min & max)...
                    //...for this specific page.
                    //Remember, .NET is 0 based, so subtract 1 from both boundaries
                    id1 = Convert.ToInt16(dtTemp.Rows[LowerBoundary - 1]["ID"]);
                    id2 = Convert.ToInt16(dtTemp.Rows[UpperBoundary - 1]["ID"]);

                    break;

                default:
                    //No button was clicked.
                    LowerBoundary = ((pageRows * CurrentPage) - (pageRows - 1));

                    //If the rows per page are less than
                    //the total row count do the following:
                    if (pageRows < totalRowCount)
                    {
                        UpperBoundary = (pageRows * CurrentPage);
                    }
                    else
                    {
                        //If the rows per page are more than
                        //the total row count do the following:
                        //Therefore there is only one page,
                        //so get the total row count as an UpperBoundary
                        UpperBoundary = totalRowCount;
                    }

                    //Now using these boundaries, get the
                    //appropriate RecordID's (min & max)...
                    //...for this specific page.
                    //Remember, .NET is 0 based, so subtract 1 from both boundaries
                    id1 = Convert.ToInt16(dtTemp.Rows[LowerBoundary - 1]["ID"]);
                    id2 = Convert.ToInt16(dtTemp.Rows[UpperBoundary - 1]["ID"]);

                    break;
            }

        }
        #endregion

        private enum NavButton
        {
            First = 1,
            Next = 2,
            Previous = 3,
            Last = 4,
        }


        //Added By Varun on 24/02/14 for creating pagination functionality
        private void tsbFirst_Click(object sender, EventArgs e)
        {
            try
            {
                NavClicked = NavButton.First.ToString();
                DeterminePageBoundaries();
                FilterDataGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

       

       
       

      
    }
}
