﻿namespace MDI_ParenrForm.Projects
{
    partial class frmIssueTenderInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
            CommonClass.isSaved = 'N';
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lstCRCopies = new System.Windows.Forms.ListView();
            this.btnCRRemoveAttachment = new System.Windows.Forms.Button();
            this.btnCRFileUpload = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtOtherShare = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtQID = new System.Windows.Forms.TextBox();
            this.lblQID = new System.Windows.Forms.Label();
            this.txtDocCollectedBy = new System.Windows.Forms.TextBox();
            this.lblCollectedBy = new System.Windows.Forms.Label();
            this.txtFaxNo = new System.Windows.Forms.TextBox();
            this.lblFax = new System.Windows.Forms.Label();
            this.txtTenderIssueDate = new System.Windows.Forms.TextBox();
            this.txtCRNO = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.lbl_bidderremarks = new System.Windows.Forms.Label();
            this.txtBidRemarks = new System.Windows.Forms.TextBox();
            this.btnCmpRef = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.cmbEmp = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.txtCommercialDate = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.lblProjIDNonMohMandatory = new System.Windows.Forms.Label();
            this.cmbCompany = new System.Windows.Forms.ComboBox();
            this.btnAddRep = new System.Windows.Forms.Button();
            this.dtptenderIssue = new System.Windows.Forms.DateTimePicker();
            this.txtTel = new System.Windows.Forms.TextBox();
            this.txtNationality = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtQataryShare = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtMobile = new System.Windows.Forms.TextBox();
            this.txtRecptNo = new System.Windows.Forms.TextBox();
            this.txtPrjTitle = new System.Windows.Forms.TextBox();
            this.txtTenderNo = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lstCRCopies);
            this.groupBox1.Controls.Add(this.btnCRRemoveAttachment);
            this.groupBox1.Controls.Add(this.btnCRFileUpload);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txtOtherShare);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.txtQID);
            this.groupBox1.Controls.Add(this.lblQID);
            this.groupBox1.Controls.Add(this.txtDocCollectedBy);
            this.groupBox1.Controls.Add(this.lblCollectedBy);
            this.groupBox1.Controls.Add(this.txtFaxNo);
            this.groupBox1.Controls.Add(this.lblFax);
            this.groupBox1.Controls.Add(this.txtTenderIssueDate);
            this.groupBox1.Controls.Add(this.txtCRNO);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.lbl_bidderremarks);
            this.groupBox1.Controls.Add(this.txtBidRemarks);
            this.groupBox1.Controls.Add(this.btnCmpRef);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.cmbEmp);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.button4);
            this.groupBox1.Controls.Add(this.txtCommercialDate);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.lblProjIDNonMohMandatory);
            this.groupBox1.Controls.Add(this.cmbCompany);
            this.groupBox1.Controls.Add(this.btnAddRep);
            this.groupBox1.Controls.Add(this.dtptenderIssue);
            this.groupBox1.Controls.Add(this.txtTel);
            this.groupBox1.Controls.Add(this.txtNationality);
            this.groupBox1.Controls.Add(this.txtEmail);
            this.groupBox1.Controls.Add(this.txtQataryShare);
            this.groupBox1.Controls.Add(this.txtAddress);
            this.groupBox1.Controls.Add(this.txtMobile);
            this.groupBox1.Controls.Add(this.txtRecptNo);
            this.groupBox1.Controls.Add(this.txtPrjTitle);
            this.groupBox1.Controls.Add(this.txtTenderNo);
            this.groupBox1.Controls.Add(this.btnSave);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(23, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1085, 701);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Add / Update Tender Issue Details";
            // 
            // lstCRCopies
            // 
            this.lstCRCopies.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstCRCopies.Location = new System.Drawing.Point(584, 83);
            this.lstCRCopies.Name = "lstCRCopies";
            this.lstCRCopies.Size = new System.Drawing.Size(495, 68);
            this.lstCRCopies.TabIndex = 73;
            this.lstCRCopies.UseCompatibleStateImageBehavior = false;
            this.lstCRCopies.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.lstCRCopies_MouseDoubleClick);
            // 
            // btnCRRemoveAttachment
            // 
            this.btnCRRemoveAttachment.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCRRemoveAttachment.Location = new System.Drawing.Point(808, 49);
            this.btnCRRemoveAttachment.Name = "btnCRRemoveAttachment";
            this.btnCRRemoveAttachment.Size = new System.Drawing.Size(62, 25);
            this.btnCRRemoveAttachment.TabIndex = 72;
            this.btnCRRemoveAttachment.Text = "Remove Attachment";
            this.btnCRRemoveAttachment.UseVisualStyleBackColor = true;
            this.btnCRRemoveAttachment.Click += new System.EventHandler(this.btnCRRemoveAttachment_Click);
            // 
            // btnCRFileUpload
            // 
            this.btnCRFileUpload.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCRFileUpload.Location = new System.Drawing.Point(746, 49);
            this.btnCRFileUpload.Name = "btnCRFileUpload";
            this.btnCRFileUpload.Size = new System.Drawing.Size(56, 25);
            this.btnCRFileUpload.TabIndex = 71;
            this.btnCRFileUpload.Text = "Browse to Upload File";
            this.btnCRFileUpload.UseVisualStyleBackColor = true;
            this.btnCRFileUpload.Click += new System.EventHandler(this.btnCRFileUpload_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label24.Location = new System.Drawing.Point(618, 56);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(71, 13);
            this.label24.TabIndex = 70;
            this.label24.Text = "Attachment";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(618, 32);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(120, 13);
            this.label21.TabIndex = 67;
            this.label21.Text = "CR Copy as Attachment";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Red;
            this.label20.Location = new System.Drawing.Point(525, 360);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(14, 18);
            this.label20.TabIndex = 63;
            this.label20.Text = "*";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(323, 363);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(14, 18);
            this.label10.TabIndex = 62;
            this.label10.Text = "*";
            // 
            // txtOtherShare
            // 
            this.txtOtherShare.Location = new System.Drawing.Point(695, 174);
            this.txtOtherShare.Name = "txtOtherShare";
            this.txtOtherShare.ReadOnly = true;
            this.txtOtherShare.Size = new System.Drawing.Size(384, 21);
            this.txtOtherShare.TabIndex = 60;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(616, 177);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(73, 15);
            this.label19.TabIndex = 61;
            this.label19.Text = "Other Share";
            // 
            // txtQID
            // 
            this.txtQID.Location = new System.Drawing.Point(396, 360);
            this.txtQID.Name = "txtQID";
            this.txtQID.Size = new System.Drawing.Size(126, 21);
            this.txtQID.TabIndex = 58;
            // 
            // lblQID
            // 
            this.lblQID.AutoSize = true;
            this.lblQID.Location = new System.Drawing.Point(340, 363);
            this.lblQID.Name = "lblQID";
            this.lblQID.Size = new System.Drawing.Size(50, 15);
            this.lblQID.TabIndex = 59;
            this.lblQID.Text = "QID No ";
            // 
            // txtDocCollectedBy
            // 
            this.txtDocCollectedBy.Location = new System.Drawing.Point(170, 361);
            this.txtDocCollectedBy.Name = "txtDocCollectedBy";
            this.txtDocCollectedBy.Size = new System.Drawing.Size(151, 21);
            this.txtDocCollectedBy.TabIndex = 56;
            // 
            // lblCollectedBy
            // 
            this.lblCollectedBy.AutoSize = true;
            this.lblCollectedBy.Location = new System.Drawing.Point(28, 364);
            this.lblCollectedBy.Name = "lblCollectedBy";
            this.lblCollectedBy.Size = new System.Drawing.Size(137, 15);
            this.lblCollectedBy.TabIndex = 57;
            this.lblCollectedBy.Text = "Document Collected By ";
            // 
            // txtFaxNo
            // 
            this.txtFaxNo.Location = new System.Drawing.Point(219, 496);
            this.txtFaxNo.Name = "txtFaxNo";
            this.txtFaxNo.ReadOnly = true;
            this.txtFaxNo.Size = new System.Drawing.Size(146, 21);
            this.txtFaxNo.TabIndex = 55;
            // 
            // lblFax
            // 
            this.lblFax.AutoSize = true;
            this.lblFax.Location = new System.Drawing.Point(219, 479);
            this.lblFax.Name = "lblFax";
            this.lblFax.Size = new System.Drawing.Size(49, 15);
            this.lblFax.TabIndex = 54;
            this.lblFax.Text = "Fax No.";
            // 
            // txtTenderIssueDate
            // 
            this.txtTenderIssueDate.Location = new System.Drawing.Point(27, 180);
            this.txtTenderIssueDate.Name = "txtTenderIssueDate";
            this.txtTenderIssueDate.Size = new System.Drawing.Size(137, 21);
            this.txtTenderIssueDate.TabIndex = 53;
            // 
            // txtCRNO
            // 
            this.txtCRNO.Location = new System.Drawing.Point(27, 600);
            this.txtCRNO.Name = "txtCRNO";
            this.txtCRNO.ReadOnly = true;
            this.txtCRNO.Size = new System.Drawing.Size(105, 21);
            this.txtCRNO.TabIndex = 51;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(24, 583);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(46, 15);
            this.label18.TabIndex = 52;
            this.label18.Text = "CR No.";
            // 
            // lbl_bidderremarks
            // 
            this.lbl_bidderremarks.AutoSize = true;
            this.lbl_bidderremarks.Location = new System.Drawing.Point(581, 231);
            this.lbl_bidderremarks.Name = "lbl_bidderremarks";
            this.lbl_bidderremarks.Size = new System.Drawing.Size(57, 15);
            this.lbl_bidderremarks.TabIndex = 50;
            this.lbl_bidderremarks.Text = "Remarks";
            // 
            // txtBidRemarks
            // 
            this.txtBidRemarks.Location = new System.Drawing.Point(583, 249);
            this.txtBidRemarks.Multiline = true;
            this.txtBidRemarks.Name = "txtBidRemarks";
            this.txtBidRemarks.Size = new System.Drawing.Size(496, 44);
            this.txtBidRemarks.TabIndex = 49;
            // 
            // btnCmpRef
            // 
            this.btnCmpRef.BackgroundImage = global::MDI_ParenrForm.Properties.Resources.Refresh;
            this.btnCmpRef.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnCmpRef.Location = new System.Drawing.Point(470, 260);
            this.btnCmpRef.Name = "btnCmpRef";
            this.btnCmpRef.Size = new System.Drawing.Size(53, 23);
            this.btnCmpRef.TabIndex = 48;
            this.btnCmpRef.UseVisualStyleBackColor = true;
            this.btnCmpRef.Click += new System.EventHandler(this.btnCmpRef_Click);
            // 
            // button2
            // 
            this.button2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.button2.Location = new System.Drawing.Point(295, 259);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(169, 23);
            this.button2.TabIndex = 47;
            this.button2.Text = "Add New Company";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // cmbEmp
            // 
            this.cmbEmp.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbEmp.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbEmp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEmp.FormattingEnabled = true;
            this.cmbEmp.Location = new System.Drawing.Point(27, 289);
            this.cmbEmp.Name = "cmbEmp";
            this.cmbEmp.Size = new System.Drawing.Size(496, 23);
            this.cmbEmp.TabIndex = 46;
            this.cmbEmp.SelectionChangeCommitted += new System.EventHandler(this.cmbEmp_SelectionChangeCommitted);
            this.cmbEmp.TextChanged += new System.EventHandler(this.cmbEmp_TextChanged);
            this.cmbEmp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbEmp_KeyPress);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.SystemColors.Control;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Maroon;
            this.label17.Location = new System.Drawing.Point(259, 603);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(19, 15);
            this.label17.TabIndex = 45;
            this.label17.Text = "%";
            // 
            // button4
            // 
            this.button4.BackgroundImage = global::MDI_ParenrForm.Properties.Resources.Refresh;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button4.Location = new System.Drawing.Point(469, 318);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(53, 23);
            this.button4.TabIndex = 44;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // txtCommercialDate
            // 
            this.txtCommercialDate.Location = new System.Drawing.Point(296, 600);
            this.txtCommercialDate.Name = "txtCommercialDate";
            this.txtCommercialDate.ReadOnly = true;
            this.txtCommercialDate.Size = new System.Drawing.Size(226, 21);
            this.txtCommercialDate.TabIndex = 43;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Red;
            this.label16.Location = new System.Drawing.Point(529, 232);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(14, 18);
            this.label16.TabIndex = 42;
            this.label16.Text = "*";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Red;
            this.label15.Location = new System.Drawing.Point(197, 181);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(14, 18);
            this.label15.TabIndex = 41;
            this.label15.Text = "*";
            // 
            // lblProjIDNonMohMandatory
            // 
            this.lblProjIDNonMohMandatory.AutoSize = true;
            this.lblProjIDNonMohMandatory.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjIDNonMohMandatory.ForeColor = System.Drawing.Color.Red;
            this.lblProjIDNonMohMandatory.Location = new System.Drawing.Point(525, 180);
            this.lblProjIDNonMohMandatory.Name = "lblProjIDNonMohMandatory";
            this.lblProjIDNonMohMandatory.Size = new System.Drawing.Size(14, 18);
            this.lblProjIDNonMohMandatory.TabIndex = 40;
            this.lblProjIDNonMohMandatory.Text = "*";
            // 
            // cmbCompany
            // 
            this.cmbCompany.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbCompany.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCompany.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCompany.FormattingEnabled = true;
            this.cmbCompany.Location = new System.Drawing.Point(27, 231);
            this.cmbCompany.Name = "cmbCompany";
            this.cmbCompany.Size = new System.Drawing.Size(496, 23);
            this.cmbCompany.TabIndex = 3;
            this.cmbCompany.SelectionChangeCommitted += new System.EventHandler(this.cmbAuthorized_SelectionChangeCommitted);
            this.cmbCompany.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbCompany_KeyPress);
            // 
            // btnAddRep
            // 
            this.btnAddRep.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnAddRep.Location = new System.Drawing.Point(297, 318);
            this.btnAddRep.Name = "btnAddRep";
            this.btnAddRep.Size = new System.Drawing.Size(168, 23);
            this.btnAddRep.TabIndex = 32;
            this.btnAddRep.Text = "Add Autorized Rep.";
            this.btnAddRep.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddRep.UseVisualStyleBackColor = true;
            this.btnAddRep.Click += new System.EventHandler(this.button3_Click);
            // 
            // dtptenderIssue
            // 
            this.dtptenderIssue.Checked = false;
            this.dtptenderIssue.CustomFormat = "  ";
            this.dtptenderIssue.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtptenderIssue.Location = new System.Drawing.Point(27, 180);
            this.dtptenderIssue.Name = "dtptenderIssue";
            this.dtptenderIssue.Size = new System.Drawing.Size(167, 21);
            this.dtptenderIssue.TabIndex = 1;
            this.dtptenderIssue.ValueChanged += new System.EventHandler(this.dtptenderIssue_ValueChanged);
            // 
            // txtTel
            // 
            this.txtTel.Location = new System.Drawing.Point(27, 500);
            this.txtTel.Name = "txtTel";
            this.txtTel.ReadOnly = true;
            this.txtTel.Size = new System.Drawing.Size(152, 21);
            this.txtTel.TabIndex = 7;
            // 
            // txtNationality
            // 
            this.txtNationality.Location = new System.Drawing.Point(389, 496);
            this.txtNationality.Name = "txtNationality";
            this.txtNationality.ReadOnly = true;
            this.txtNationality.Size = new System.Drawing.Size(133, 21);
            this.txtNationality.TabIndex = 10;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(27, 549);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(495, 21);
            this.txtEmail.TabIndex = 9;
            // 
            // txtQataryShare
            // 
            this.txtQataryShare.Location = new System.Drawing.Point(138, 600);
            this.txtQataryShare.Name = "txtQataryShare";
            this.txtQataryShare.ReadOnly = true;
            this.txtQataryShare.Size = new System.Drawing.Size(141, 21);
            this.txtQataryShare.TabIndex = 11;
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(27, 444);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.ReadOnly = true;
            this.txtAddress.Size = new System.Drawing.Size(495, 21);
            this.txtAddress.TabIndex = 6;
            // 
            // txtMobile
            // 
            this.txtMobile.Location = new System.Drawing.Point(170, 397);
            this.txtMobile.Name = "txtMobile";
            this.txtMobile.Size = new System.Drawing.Size(352, 21);
            this.txtMobile.TabIndex = 4;
            // 
            // txtRecptNo
            // 
            this.txtRecptNo.Location = new System.Drawing.Point(296, 177);
            this.txtRecptNo.Name = "txtRecptNo";
            this.txtRecptNo.Size = new System.Drawing.Size(227, 21);
            this.txtRecptNo.TabIndex = 2;
            this.txtRecptNo.Leave += new System.EventHandler(this.txtRecptNo_Leave);
            // 
            // txtPrjTitle
            // 
            this.txtPrjTitle.Location = new System.Drawing.Point(27, 101);
            this.txtPrjTitle.Multiline = true;
            this.txtPrjTitle.Name = "txtPrjTitle";
            this.txtPrjTitle.ReadOnly = true;
            this.txtPrjTitle.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtPrjTitle.Size = new System.Drawing.Size(496, 47);
            this.txtPrjTitle.TabIndex = 16;
            // 
            // txtTenderNo
            // 
            this.txtTenderNo.Location = new System.Drawing.Point(27, 48);
            this.txtTenderNo.Name = "txtTenderNo";
            this.txtTenderNo.ReadOnly = true;
            this.txtTenderNo.Size = new System.Drawing.Size(248, 21);
            this.txtTenderNo.TabIndex = 15;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.Maroon;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Location = new System.Drawing.Point(528, 648);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(71, 26);
            this.btnSave.TabIndex = 13;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(24, 531);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(141, 15);
            this.label11.TabIndex = 11;
            this.label11.Text = "Company Email Address";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(389, 478);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(64, 15);
            this.label12.TabIndex = 12;
            this.label12.Text = "Nationality";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(135, 582);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(76, 15);
            this.label13.TabIndex = 13;
            this.label13.Text = "Qatari Share";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(292, 582);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(230, 15);
            this.label14.TabIndex = 14;
            this.label14.Text = "Commercial Registration Expiration Date";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(27, 397);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(93, 15);
            this.label6.TabIndex = 6;
            this.label6.Text = "Mobile Number";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(25, 213);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 15);
            this.label7.TabIndex = 7;
            this.label7.Text = "Company";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(24, 426);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(106, 15);
            this.label8.TabIndex = 8;
            this.label8.Text = "Company Address";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(24, 482);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(140, 15);
            this.label9.TabIndex = 9;
            this.label9.Text = "Company Telephone No";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Tender No.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Project Title";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 162);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 15);
            this.label3.TabIndex = 3;
            this.label3.Text = "Tender Issue Date";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(294, 162);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 15);
            this.label4.TabIndex = 4;
            this.label4.Text = "Receipt No.";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(24, 271);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(140, 15);
            this.label5.TabIndex = 5;
            this.label5.Text = "Authorized Representive";
            // 
            // frmIssueTenderInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.FloralWhite;
            this.ClientSize = new System.Drawing.Size(1120, 727);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "frmIssueTenderInfo";
            this.Text = "Issue A Tender";
            this.Load += new System.EventHandler(this.frmIssueTenderInfo_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtTel;
        private System.Windows.Forms.TextBox txtNationality;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtQataryShare;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtMobile;
        private System.Windows.Forms.TextBox txtRecptNo;
        private System.Windows.Forms.TextBox txtPrjTitle;
        private System.Windows.Forms.TextBox txtTenderNo;
        private System.Windows.Forms.DateTimePicker dtptenderIssue;
        private System.Windows.Forms.Button btnAddRep;
        private System.Windows.Forms.ComboBox cmbCompany;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblProjIDNonMohMandatory;
        private System.Windows.Forms.TextBox txtCommercialDate;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox cmbEmp;
        private System.Windows.Forms.Button btnCmpRef;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label lbl_bidderremarks;
        private System.Windows.Forms.TextBox txtBidRemarks;
        private System.Windows.Forms.TextBox txtCRNO;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtTenderIssueDate;
        private System.Windows.Forms.Label lblFax;
        private System.Windows.Forms.TextBox txtFaxNo;
        private System.Windows.Forms.TextBox txtQID;
        private System.Windows.Forms.Label lblQID;
        private System.Windows.Forms.TextBox txtDocCollectedBy;
        private System.Windows.Forms.Label lblCollectedBy;
        private System.Windows.Forms.TextBox txtOtherShare;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button btnCRFileUpload;
        private System.Windows.Forms.Button btnCRRemoveAttachment;
        private System.Windows.Forms.ListView lstCRCopies;
    }
}