﻿namespace MDI_ParenrForm.Projects
{
    partial class frmAddToShortList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTenderNo = new System.Windows.Forms.Label();
            this.txtTenderNo = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblProjTitle = new System.Windows.Forms.Label();
            this.txtProjTitle = new System.Windows.Forms.TextBox();
            this.lblCompany = new System.Windows.Forms.Label();
            this.cmbCompany = new System.Windows.Forms.ComboBox();
            this.btnAddNewCompany = new System.Windows.Forms.Button();
            this.btnCmpRef = new System.Windows.Forms.Button();
            this.lblAuthorizedRepresentative = new System.Windows.Forms.Label();
            this.cmbAuthRepresentative = new System.Windows.Forms.ComboBox();
            this.btnAddAuthRep = new System.Windows.Forms.Button();
            this.btnAuthRepRef = new System.Windows.Forms.Button();
            this.lblMobile = new System.Windows.Forms.Label();
            this.txtMobileNo = new System.Windows.Forms.TextBox();
            this.lblCompAddress = new System.Windows.Forms.Label();
            this.txtCompAddress = new System.Windows.Forms.TextBox();
            this.lblCompTelNo = new System.Windows.Forms.Label();
            this.txtCompTelNo = new System.Windows.Forms.TextBox();
            this.lblFaxNo = new System.Windows.Forms.Label();
            this.txtFaxNo = new System.Windows.Forms.TextBox();
            this.lblNationality = new System.Windows.Forms.Label();
            this.txtNationality = new System.Windows.Forms.TextBox();
            this.lblCompEmailAddress = new System.Windows.Forms.Label();
            this.txtCompEmailAddress = new System.Windows.Forms.TextBox();
            this.lblQatariShare = new System.Windows.Forms.Label();
            this.txtQatariShare = new System.Windows.Forms.TextBox();
            this.lblCRExpDate = new System.Windows.Forms.Label();
            this.txtCRExpDate = new System.Windows.Forms.TextBox();
            this.lblCRNumber = new System.Windows.Forms.Label();
            this.txtCRNumber = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblTenderNo
            // 
            this.lblTenderNo.AutoSize = true;
            this.lblTenderNo.Location = new System.Drawing.Point(28, 29);
            this.lblTenderNo.Name = "lblTenderNo";
            this.lblTenderNo.Size = new System.Drawing.Size(61, 13);
            this.lblTenderNo.TabIndex = 0;
            this.lblTenderNo.Text = "Tender No.";
            // 
            // txtTenderNo
            // 
            this.txtTenderNo.Enabled = false;
            this.txtTenderNo.Location = new System.Drawing.Point(31, 46);
            this.txtTenderNo.Name = "txtTenderNo";
            this.txtTenderNo.Size = new System.Drawing.Size(173, 20);
            this.txtTenderNo.TabIndex = 1;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.Maroon;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Location = new System.Drawing.Point(501, 43);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(66, 23);
            this.btnSave.TabIndex = 2;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lblProjTitle
            // 
            this.lblProjTitle.AutoSize = true;
            this.lblProjTitle.Location = new System.Drawing.Point(31, 89);
            this.lblProjTitle.Name = "lblProjTitle";
            this.lblProjTitle.Size = new System.Drawing.Size(63, 13);
            this.lblProjTitle.TabIndex = 3;
            this.lblProjTitle.Text = "Project Title";
            // 
            // txtProjTitle
            // 
            this.txtProjTitle.Enabled = false;
            this.txtProjTitle.Location = new System.Drawing.Point(34, 106);
            this.txtProjTitle.Multiline = true;
            this.txtProjTitle.Name = "txtProjTitle";
            this.txtProjTitle.Size = new System.Drawing.Size(533, 63);
            this.txtProjTitle.TabIndex = 4;
            // 
            // lblCompany
            // 
            this.lblCompany.AutoSize = true;
            this.lblCompany.Location = new System.Drawing.Point(33, 196);
            this.lblCompany.Name = "lblCompany";
            this.lblCompany.Size = new System.Drawing.Size(51, 13);
            this.lblCompany.TabIndex = 5;
            this.lblCompany.Text = "Company";
            // 
            // cmbCompany
            // 
            this.cmbCompany.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbCompany.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCompany.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCompany.FormattingEnabled = true;
            this.cmbCompany.Location = new System.Drawing.Point(36, 213);
            this.cmbCompany.Name = "cmbCompany";
            this.cmbCompany.Size = new System.Drawing.Size(531, 21);
            this.cmbCompany.TabIndex = 6;
            this.cmbCompany.SelectionChangeCommitted += new System.EventHandler(this.cmbCompany_SelectionChangeCommitted);
            this.cmbCompany.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbCompany_KeyPress);
            // 
            // btnAddNewCompany
            // 
            this.btnAddNewCompany.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddNewCompany.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnAddNewCompany.Location = new System.Drawing.Point(334, 239);
            this.btnAddNewCompany.Name = "btnAddNewCompany";
            this.btnAddNewCompany.Size = new System.Drawing.Size(181, 23);
            this.btnAddNewCompany.TabIndex = 7;
            this.btnAddNewCompany.Text = "Add New Company";
            this.btnAddNewCompany.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddNewCompany.UseVisualStyleBackColor = true;
            this.btnAddNewCompany.Click += new System.EventHandler(this.btnAddNewCompany_Click);
            // 
            // btnCmpRef
            // 
            this.btnCmpRef.BackColor = System.Drawing.Color.FloralWhite;
            this.btnCmpRef.BackgroundImage = global::MDI_ParenrForm.Properties.Resources.Refresh;
            this.btnCmpRef.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnCmpRef.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCmpRef.Location = new System.Drawing.Point(522, 239);
            this.btnCmpRef.Name = "btnCmpRef";
            this.btnCmpRef.Size = new System.Drawing.Size(45, 23);
            this.btnCmpRef.TabIndex = 8;
            this.btnCmpRef.UseVisualStyleBackColor = false;
            // 
            // lblAuthorizedRepresentative
            // 
            this.lblAuthorizedRepresentative.AutoSize = true;
            this.lblAuthorizedRepresentative.Location = new System.Drawing.Point(36, 274);
            this.lblAuthorizedRepresentative.Name = "lblAuthorizedRepresentative";
            this.lblAuthorizedRepresentative.Size = new System.Drawing.Size(132, 13);
            this.lblAuthorizedRepresentative.TabIndex = 9;
            this.lblAuthorizedRepresentative.Text = "Authorized Representative";
            // 
            // cmbAuthRepresentative
            // 
            this.cmbAuthRepresentative.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbAuthRepresentative.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbAuthRepresentative.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAuthRepresentative.FormattingEnabled = true;
            this.cmbAuthRepresentative.Location = new System.Drawing.Point(39, 290);
            this.cmbAuthRepresentative.Name = "cmbAuthRepresentative";
            this.cmbAuthRepresentative.Size = new System.Drawing.Size(528, 21);
            this.cmbAuthRepresentative.TabIndex = 10;
            this.cmbAuthRepresentative.SelectionChangeCommitted += new System.EventHandler(this.cmbAuthRepresentative_SelectionChangeCommitted);
            this.cmbAuthRepresentative.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbAuthRepresentative_KeyPress);
            // 
            // btnAddAuthRep
            // 
            this.btnAddAuthRep.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddAuthRep.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnAddAuthRep.Location = new System.Drawing.Point(334, 316);
            this.btnAddAuthRep.Name = "btnAddAuthRep";
            this.btnAddAuthRep.Size = new System.Drawing.Size(181, 23);
            this.btnAddAuthRep.TabIndex = 11;
            this.btnAddAuthRep.Text = "Add Autorized Representative";
            this.btnAddAuthRep.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddAuthRep.UseVisualStyleBackColor = true;
            this.btnAddAuthRep.Click += new System.EventHandler(this.btnAddAuthRep_Click);
            // 
            // btnAuthRepRef
            // 
            this.btnAuthRepRef.BackColor = System.Drawing.Color.FloralWhite;
            this.btnAuthRepRef.BackgroundImage = global::MDI_ParenrForm.Properties.Resources.Refresh;
            this.btnAuthRepRef.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnAuthRepRef.Location = new System.Drawing.Point(522, 316);
            this.btnAuthRepRef.Name = "btnAuthRepRef";
            this.btnAuthRepRef.Size = new System.Drawing.Size(45, 23);
            this.btnAuthRepRef.TabIndex = 12;
            this.btnAuthRepRef.UseVisualStyleBackColor = false;
            // 
            // lblMobile
            // 
            this.lblMobile.AutoSize = true;
            this.lblMobile.Location = new System.Drawing.Point(39, 345);
            this.lblMobile.Name = "lblMobile";
            this.lblMobile.Size = new System.Drawing.Size(38, 13);
            this.lblMobile.TabIndex = 13;
            this.lblMobile.Text = "Mobile";
            // 
            // txtMobileNo
            // 
            this.txtMobileNo.Enabled = false;
            this.txtMobileNo.Location = new System.Drawing.Point(42, 362);
            this.txtMobileNo.Name = "txtMobileNo";
            this.txtMobileNo.Size = new System.Drawing.Size(100, 20);
            this.txtMobileNo.TabIndex = 14;
            // 
            // lblCompAddress
            // 
            this.lblCompAddress.AutoSize = true;
            this.lblCompAddress.Location = new System.Drawing.Point(39, 399);
            this.lblCompAddress.Name = "lblCompAddress";
            this.lblCompAddress.Size = new System.Drawing.Size(92, 13);
            this.lblCompAddress.TabIndex = 15;
            this.lblCompAddress.Text = "Company Address";
            // 
            // txtCompAddress
            // 
            this.txtCompAddress.Enabled = false;
            this.txtCompAddress.Location = new System.Drawing.Point(43, 416);
            this.txtCompAddress.Name = "txtCompAddress";
            this.txtCompAddress.Size = new System.Drawing.Size(524, 20);
            this.txtCompAddress.TabIndex = 16;
            // 
            // lblCompTelNo
            // 
            this.lblCompTelNo.AutoSize = true;
            this.lblCompTelNo.Location = new System.Drawing.Point(41, 452);
            this.lblCompTelNo.Name = "lblCompTelNo";
            this.lblCompTelNo.Size = new System.Drawing.Size(89, 13);
            this.lblCompTelNo.TabIndex = 17;
            this.lblCompTelNo.Text = "Company Tel No.";
            // 
            // txtCompTelNo
            // 
            this.txtCompTelNo.Enabled = false;
            this.txtCompTelNo.Location = new System.Drawing.Point(44, 469);
            this.txtCompTelNo.Name = "txtCompTelNo";
            this.txtCompTelNo.Size = new System.Drawing.Size(156, 20);
            this.txtCompTelNo.TabIndex = 18;
            // 
            // lblFaxNo
            // 
            this.lblFaxNo.AutoSize = true;
            this.lblFaxNo.Location = new System.Drawing.Point(227, 452);
            this.lblFaxNo.Name = "lblFaxNo";
            this.lblFaxNo.Size = new System.Drawing.Size(64, 13);
            this.lblFaxNo.TabIndex = 19;
            this.lblFaxNo.Text = "Fax Number";
            // 
            // txtFaxNo
            // 
            this.txtFaxNo.Enabled = false;
            this.txtFaxNo.Location = new System.Drawing.Point(230, 469);
            this.txtFaxNo.Name = "txtFaxNo";
            this.txtFaxNo.Size = new System.Drawing.Size(152, 20);
            this.txtFaxNo.TabIndex = 20;
            // 
            // lblNationality
            // 
            this.lblNationality.AutoSize = true;
            this.lblNationality.Location = new System.Drawing.Point(402, 452);
            this.lblNationality.Name = "lblNationality";
            this.lblNationality.Size = new System.Drawing.Size(56, 13);
            this.lblNationality.TabIndex = 21;
            this.lblNationality.Text = "Nationality";
            // 
            // txtNationality
            // 
            this.txtNationality.Enabled = false;
            this.txtNationality.Location = new System.Drawing.Point(405, 468);
            this.txtNationality.Name = "txtNationality";
            this.txtNationality.Size = new System.Drawing.Size(162, 20);
            this.txtNationality.TabIndex = 22;
            // 
            // lblCompEmailAddress
            // 
            this.lblCompEmailAddress.AutoSize = true;
            this.lblCompEmailAddress.Location = new System.Drawing.Point(42, 505);
            this.lblCompEmailAddress.Name = "lblCompEmailAddress";
            this.lblCompEmailAddress.Size = new System.Drawing.Size(120, 13);
            this.lblCompEmailAddress.TabIndex = 23;
            this.lblCompEmailAddress.Text = "Company Email Address";
            // 
            // txtCompEmailAddress
            // 
            this.txtCompEmailAddress.Enabled = false;
            this.txtCompEmailAddress.Location = new System.Drawing.Point(44, 522);
            this.txtCompEmailAddress.Name = "txtCompEmailAddress";
            this.txtCompEmailAddress.Size = new System.Drawing.Size(338, 20);
            this.txtCompEmailAddress.TabIndex = 24;
            // 
            // lblQatariShare
            // 
            this.lblQatariShare.AutoSize = true;
            this.lblQatariShare.Location = new System.Drawing.Point(405, 505);
            this.lblQatariShare.Name = "lblQatariShare";
            this.lblQatariShare.Size = new System.Drawing.Size(66, 13);
            this.lblQatariShare.TabIndex = 25;
            this.lblQatariShare.Text = "Qatari Share";
            // 
            // txtQatariShare
            // 
            this.txtQatariShare.Enabled = false;
            this.txtQatariShare.Location = new System.Drawing.Point(408, 521);
            this.txtQatariShare.Name = "txtQatariShare";
            this.txtQatariShare.Size = new System.Drawing.Size(100, 20);
            this.txtQatariShare.TabIndex = 26;
            // 
            // lblCRExpDate
            // 
            this.lblCRExpDate.AutoSize = true;
            this.lblCRExpDate.Location = new System.Drawing.Point(42, 561);
            this.lblCRExpDate.Name = "lblCRExpDate";
            this.lblCRExpDate.Size = new System.Drawing.Size(97, 13);
            this.lblCRExpDate.TabIndex = 27;
            this.lblCRExpDate.Text = "CR Expiration Date";
            // 
            // txtCRExpDate
            // 
            this.txtCRExpDate.Enabled = false;
            this.txtCRExpDate.Location = new System.Drawing.Point(45, 578);
            this.txtCRExpDate.Name = "txtCRExpDate";
            this.txtCRExpDate.Size = new System.Drawing.Size(155, 20);
            this.txtCRExpDate.TabIndex = 28;
            // 
            // lblCRNumber
            // 
            this.lblCRNumber.AutoSize = true;
            this.lblCRNumber.Location = new System.Drawing.Point(230, 560);
            this.lblCRNumber.Name = "lblCRNumber";
            this.lblCRNumber.Size = new System.Drawing.Size(62, 13);
            this.lblCRNumber.TabIndex = 29;
            this.lblCRNumber.Text = "CR Number";
            // 
            // txtCRNumber
            // 
            this.txtCRNumber.Enabled = false;
            this.txtCRNumber.Location = new System.Drawing.Point(233, 578);
            this.txtCRNumber.Name = "txtCRNumber";
            this.txtCRNumber.Size = new System.Drawing.Size(149, 20);
            this.txtCRNumber.TabIndex = 30;
            // 
            // frmAddToShortList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FloralWhite;
            this.ClientSize = new System.Drawing.Size(583, 630);
            this.Controls.Add(this.txtCRNumber);
            this.Controls.Add(this.lblCRNumber);
            this.Controls.Add(this.txtCRExpDate);
            this.Controls.Add(this.lblCRExpDate);
            this.Controls.Add(this.txtQatariShare);
            this.Controls.Add(this.lblQatariShare);
            this.Controls.Add(this.txtCompEmailAddress);
            this.Controls.Add(this.lblCompEmailAddress);
            this.Controls.Add(this.txtNationality);
            this.Controls.Add(this.lblNationality);
            this.Controls.Add(this.txtFaxNo);
            this.Controls.Add(this.lblFaxNo);
            this.Controls.Add(this.txtCompTelNo);
            this.Controls.Add(this.lblCompTelNo);
            this.Controls.Add(this.txtCompAddress);
            this.Controls.Add(this.lblCompAddress);
            this.Controls.Add(this.txtMobileNo);
            this.Controls.Add(this.lblMobile);
            this.Controls.Add(this.btnAuthRepRef);
            this.Controls.Add(this.btnAddAuthRep);
            this.Controls.Add(this.cmbAuthRepresentative);
            this.Controls.Add(this.lblAuthorizedRepresentative);
            this.Controls.Add(this.btnCmpRef);
            this.Controls.Add(this.btnAddNewCompany);
            this.Controls.Add(this.cmbCompany);
            this.Controls.Add(this.lblCompany);
            this.Controls.Add(this.txtProjTitle);
            this.Controls.Add(this.lblProjTitle);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtTenderNo);
            this.Controls.Add(this.lblTenderNo);
            this.Name = "frmAddToShortList";
            this.Text = "Add To ShortList";
            this.Load += new System.EventHandler(this.frmAddToShortList_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTenderNo;
        private System.Windows.Forms.TextBox txtTenderNo;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblProjTitle;
        private System.Windows.Forms.TextBox txtProjTitle;
        private System.Windows.Forms.Label lblCompany;
        private System.Windows.Forms.ComboBox cmbCompany;
        private System.Windows.Forms.Button btnAddNewCompany;
        private System.Windows.Forms.Button btnCmpRef;
        private System.Windows.Forms.Label lblAuthorizedRepresentative;
        private System.Windows.Forms.ComboBox cmbAuthRepresentative;
        private System.Windows.Forms.Button btnAddAuthRep;
        private System.Windows.Forms.Button btnAuthRepRef;
        private System.Windows.Forms.Label lblMobile;
        private System.Windows.Forms.TextBox txtMobileNo;
        private System.Windows.Forms.Label lblCompAddress;
        private System.Windows.Forms.TextBox txtCompAddress;
        private System.Windows.Forms.Label lblCompTelNo;
        private System.Windows.Forms.TextBox txtCompTelNo;
        private System.Windows.Forms.Label lblFaxNo;
        private System.Windows.Forms.TextBox txtFaxNo;
        private System.Windows.Forms.Label lblNationality;
        private System.Windows.Forms.TextBox txtNationality;
        private System.Windows.Forms.Label lblCompEmailAddress;
        private System.Windows.Forms.TextBox txtCompEmailAddress;
        private System.Windows.Forms.Label lblQatariShare;
        private System.Windows.Forms.TextBox txtQatariShare;
        private System.Windows.Forms.Label lblCRExpDate;
        private System.Windows.Forms.TextBox txtCRExpDate;
        private System.Windows.Forms.Label lblCRNumber;
        private System.Windows.Forms.TextBox txtCRNumber;
    }
}