﻿namespace MDI_ParenrForm.Projects
{
    partial class frmWorkOrderIssueDate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancelWO = new System.Windows.Forms.Button();
            this.btnUpdateAndCloseWO = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txtWorkOrderNo = new System.Windows.Forms.TextBox();
            this.lblWorkOrderNo = new System.Windows.Forms.Label();
            this.txtWOTitle = new System.Windows.Forms.TextBox();
            this.lblProjectTitle = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.mskTxtTenderOpenDate = new System.Windows.Forms.MaskedTextBox();
            this.grpBoxTenderEvalPhase = new System.Windows.Forms.GroupBox();
            this.grpBoxTenderingPhase = new System.Windows.Forms.GroupBox();
            this.mskTxtWOIssueDate = new System.Windows.Forms.TextBox();
            this.lblWorkOrderClosingDate = new System.Windows.Forms.Label();
            this.dtpWOIssueDate = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.mskTxtWOClosingDate = new System.Windows.Forms.TextBox();
            this.btnDeleteWO = new System.Windows.Forms.Button();
            this.grpBoxTenderEvalPhase.SuspendLayout();
            this.grpBoxTenderingPhase.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCancelWO
            // 
            this.btnCancelWO.BackColor = System.Drawing.Color.Maroon;
            this.btnCancelWO.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCancelWO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelWO.ForeColor = System.Drawing.Color.White;
            this.btnCancelWO.Location = new System.Drawing.Point(127, 336);
            this.btnCancelWO.Name = "btnCancelWO";
            this.btnCancelWO.Size = new System.Drawing.Size(60, 26);
            this.btnCancelWO.TabIndex = 45;
            this.btnCancelWO.Text = "Cancel";
            this.btnCancelWO.UseVisualStyleBackColor = false;
            this.btnCancelWO.Visible = false;
            this.btnCancelWO.Click += new System.EventHandler(this.btnCancelWO_Click);
            // 
            // btnUpdateAndCloseWO
            // 
            this.btnUpdateAndCloseWO.BackColor = System.Drawing.Color.Maroon;
            this.btnUpdateAndCloseWO.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnUpdateAndCloseWO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateAndCloseWO.ForeColor = System.Drawing.Color.White;
            this.btnUpdateAndCloseWO.Location = new System.Drawing.Point(233, 335);
            this.btnUpdateAndCloseWO.Name = "btnUpdateAndCloseWO";
            this.btnUpdateAndCloseWO.Size = new System.Drawing.Size(86, 27);
            this.btnUpdateAndCloseWO.TabIndex = 46;
            this.btnUpdateAndCloseWO.UseVisualStyleBackColor = false;
            this.btnUpdateAndCloseWO.Click += new System.EventHandler(this.btnSaveAndCloseWO_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(10, 305);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 13);
            this.label3.TabIndex = 36;
            this.label3.Text = "* Mandatory Fields";
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.Maroon;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(348, 335);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(86, 27);
            this.btnClose.TabIndex = 47;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 160);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(125, 13);
            this.label4.TabIndex = 53;
            this.label4.Text = "Work Order Closing Date";
            // 
            // txtWorkOrderNo
            // 
            this.txtWorkOrderNo.Enabled = false;
            this.txtWorkOrderNo.Location = new System.Drawing.Point(248, 97);
            this.txtWorkOrderNo.Name = "txtWorkOrderNo";
            this.txtWorkOrderNo.Size = new System.Drawing.Size(120, 20);
            this.txtWorkOrderNo.TabIndex = 2;
            // 
            // lblWorkOrderNo
            // 
            this.lblWorkOrderNo.AutoSize = true;
            this.lblWorkOrderNo.Location = new System.Drawing.Point(14, 97);
            this.lblWorkOrderNo.Name = "lblWorkOrderNo";
            this.lblWorkOrderNo.Size = new System.Drawing.Size(82, 13);
            this.lblWorkOrderNo.TabIndex = 2;
            this.lblWorkOrderNo.Text = "Work Order No.";
            // 
            // txtWOTitle
            // 
            this.txtWOTitle.Enabled = false;
            this.txtWOTitle.Location = new System.Drawing.Point(14, 41);
            this.txtWOTitle.Multiline = true;
            this.txtWOTitle.Name = "txtWOTitle";
            this.txtWOTitle.Size = new System.Drawing.Size(354, 43);
            this.txtWOTitle.TabIndex = 1;
            // 
            // lblProjectTitle
            // 
            this.lblProjectTitle.AutoSize = true;
            this.lblProjectTitle.Location = new System.Drawing.Point(11, 25);
            this.lblProjectTitle.Name = "lblProjectTitle";
            this.lblProjectTitle.Size = new System.Drawing.Size(85, 13);
            this.lblProjectTitle.TabIndex = 0;
            this.lblProjectTitle.Text = "Work Order Title";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(17, 30);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(96, 13);
            this.label9.TabIndex = 61;
            this.label9.Text = "Tender Open Date";
            // 
            // mskTxtTenderOpenDate
            // 
            this.mskTxtTenderOpenDate.Enabled = false;
            this.mskTxtTenderOpenDate.Location = new System.Drawing.Point(251, 30);
            this.mskTxtTenderOpenDate.Name = "mskTxtTenderOpenDate";
            this.mskTxtTenderOpenDate.Size = new System.Drawing.Size(96, 20);
            this.mskTxtTenderOpenDate.TabIndex = 6;
            // 
            // grpBoxTenderEvalPhase
            // 
            this.grpBoxTenderEvalPhase.Controls.Add(this.mskTxtTenderOpenDate);
            this.grpBoxTenderEvalPhase.Controls.Add(this.label9);
            this.grpBoxTenderEvalPhase.Location = new System.Drawing.Point(12, 221);
            this.grpBoxTenderEvalPhase.Name = "grpBoxTenderEvalPhase";
            this.grpBoxTenderEvalPhase.Size = new System.Drawing.Size(422, 71);
            this.grpBoxTenderEvalPhase.TabIndex = 59;
            this.grpBoxTenderEvalPhase.TabStop = false;
            this.grpBoxTenderEvalPhase.Text = "Tender Evaluation Phase";
            // 
            // grpBoxTenderingPhase
            // 
            this.grpBoxTenderingPhase.Controls.Add(this.mskTxtWOIssueDate);
            this.grpBoxTenderingPhase.Controls.Add(this.lblWorkOrderClosingDate);
            this.grpBoxTenderingPhase.Controls.Add(this.dtpWOIssueDate);
            this.grpBoxTenderingPhase.Controls.Add(this.label2);
            this.grpBoxTenderingPhase.Controls.Add(this.mskTxtWOClosingDate);
            this.grpBoxTenderingPhase.Controls.Add(this.lblProjectTitle);
            this.grpBoxTenderingPhase.Controls.Add(this.txtWOTitle);
            this.grpBoxTenderingPhase.Controls.Add(this.lblWorkOrderNo);
            this.grpBoxTenderingPhase.Controls.Add(this.txtWorkOrderNo);
            this.grpBoxTenderingPhase.Controls.Add(this.label4);
            this.grpBoxTenderingPhase.Location = new System.Drawing.Point(15, 13);
            this.grpBoxTenderingPhase.Name = "grpBoxTenderingPhase";
            this.grpBoxTenderingPhase.Size = new System.Drawing.Size(419, 196);
            this.grpBoxTenderingPhase.TabIndex = 62;
            this.grpBoxTenderingPhase.TabStop = false;
            this.grpBoxTenderingPhase.Text = "Tendering Phase";
            // 
            // mskTxtWOIssueDate
            // 
            this.mskTxtWOIssueDate.Location = new System.Drawing.Point(247, 129);
            this.mskTxtWOIssueDate.Name = "mskTxtWOIssueDate";
            this.mskTxtWOIssueDate.Size = new System.Drawing.Size(98, 20);
            this.mskTxtWOIssueDate.TabIndex = 58;
            // 
            // lblWorkOrderClosingDate
            // 
            this.lblWorkOrderClosingDate.AutoSize = true;
            this.lblWorkOrderClosingDate.Location = new System.Drawing.Point(16, 129);
            this.lblWorkOrderClosingDate.Name = "lblWorkOrderClosingDate";
            this.lblWorkOrderClosingDate.Size = new System.Drawing.Size(116, 13);
            this.lblWorkOrderClosingDate.TabIndex = 59;
            this.lblWorkOrderClosingDate.Text = "Work Order Issue Date";
            // 
            // dtpWOIssueDate
            // 
            this.dtpWOIssueDate.Checked = false;
            this.dtpWOIssueDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpWOIssueDate.Location = new System.Drawing.Point(250, 129);
            this.dtpWOIssueDate.Name = "dtpWOIssueDate";
            this.dtpWOIssueDate.ShowCheckBox = true;
            this.dtpWOIssueDate.Size = new System.Drawing.Size(118, 20);
            this.dtpWOIssueDate.TabIndex = 57;
            this.dtpWOIssueDate.Value = new System.DateTime(2016, 12, 25, 0, 0, 0, 0);
            this.dtpWOIssueDate.ValueChanged += new System.EventHandler(this.dtpWOIssueDate_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(368, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(12, 15);
            this.label2.TabIndex = 60;
            this.label2.Text = "*";
            // 
            // mskTxtWOClosingDate
            // 
            this.mskTxtWOClosingDate.Enabled = false;
            this.mskTxtWOClosingDate.Location = new System.Drawing.Point(247, 160);
            this.mskTxtWOClosingDate.Name = "mskTxtWOClosingDate";
            this.mskTxtWOClosingDate.Size = new System.Drawing.Size(98, 20);
            this.mskTxtWOClosingDate.TabIndex = 4;
            // 
            // btnDeleteWO
            // 
            this.btnDeleteWO.BackColor = System.Drawing.Color.Maroon;
            this.btnDeleteWO.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDeleteWO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteWO.ForeColor = System.Drawing.Color.White;
            this.btnDeleteWO.Location = new System.Drawing.Point(29, 335);
            this.btnDeleteWO.Name = "btnDeleteWO";
            this.btnDeleteWO.Size = new System.Drawing.Size(60, 26);
            this.btnDeleteWO.TabIndex = 63;
            this.btnDeleteWO.Text = "Delete";
            this.btnDeleteWO.UseVisualStyleBackColor = false;
            this.btnDeleteWO.Click += new System.EventHandler(this.btnDeleteWO_Click_1);
            // 
            // frmWorkOrderIssueDate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FloralWhite;
            this.ClientSize = new System.Drawing.Size(450, 385);
            this.Controls.Add(this.btnDeleteWO);
            this.Controls.Add(this.grpBoxTenderingPhase);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.grpBoxTenderEvalPhase);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnUpdateAndCloseWO);
            this.Controls.Add(this.btnCancelWO);
            this.Name = "frmWorkOrderIssueDate";
            this.Text = "Work Order Contract Process Details";
            this.grpBoxTenderEvalPhase.ResumeLayout(false);
            this.grpBoxTenderEvalPhase.PerformLayout();
            this.grpBoxTenderingPhase.ResumeLayout(false);
            this.grpBoxTenderingPhase.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCancelWO;
        private System.Windows.Forms.Button btnUpdateAndCloseWO;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtWorkOrderNo;
        private System.Windows.Forms.Label lblWorkOrderNo;
        private System.Windows.Forms.TextBox txtWOTitle;
        private System.Windows.Forms.Label lblProjectTitle;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.MaskedTextBox mskTxtTenderOpenDate;
        private System.Windows.Forms.GroupBox grpBoxTenderEvalPhase;
        private System.Windows.Forms.GroupBox grpBoxTenderingPhase;
        private System.Windows.Forms.TextBox mskTxtWOClosingDate;
        private System.Windows.Forms.TextBox mskTxtWOIssueDate;
        private System.Windows.Forms.Label lblWorkOrderClosingDate;
        private System.Windows.Forms.DateTimePicker dtpWOIssueDate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnDeleteWO;
    }
}