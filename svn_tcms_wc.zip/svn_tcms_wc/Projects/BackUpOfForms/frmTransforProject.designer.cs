﻿namespace MDI_ParenrForm.Projects
{
    partial class frmTransforProject
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCommitteName = new System.Windows.Forms.Label();
            this.cmbCommittee = new System.Windows.Forms.ComboBox();
            this.btnTransfor = new System.Windows.Forms.Button();
            this.grpBoxTenderType = new System.Windows.Forms.GroupBox();
            this.rdbLimited = new System.Windows.Forms.RadioButton();
            this.rdbPublic = new System.Windows.Forms.RadioButton();
            this.grpBoxTenderType.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblCommitteName
            // 
            this.lblCommitteName.AutoSize = true;
            this.lblCommitteName.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblCommitteName.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCommitteName.Location = new System.Drawing.Point(50, 31);
            this.lblCommitteName.Name = "lblCommitteName";
            this.lblCommitteName.Size = new System.Drawing.Size(130, 18);
            this.lblCommitteName.TabIndex = 0;
            this.lblCommitteName.Text = "Committe Name";
            // 
            // cmbCommittee
            // 
            this.cmbCommittee.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCommittee.FormattingEnabled = true;
            this.cmbCommittee.Location = new System.Drawing.Point(188, 27);
            this.cmbCommittee.Name = "cmbCommittee";
            this.cmbCommittee.Size = new System.Drawing.Size(278, 26);
            this.cmbCommittee.TabIndex = 1;
            this.cmbCommittee.SelectedIndexChanged += new System.EventHandler(this.cmbCommittee_SelectedIndexChanged);
            // 
            // btnTransfor
            // 
            this.btnTransfor.BackColor = System.Drawing.Color.Maroon;
            this.btnTransfor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTransfor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTransfor.ForeColor = System.Drawing.Color.White;
            this.btnTransfor.Location = new System.Drawing.Point(188, 111);
            this.btnTransfor.Name = "btnTransfor";
            this.btnTransfor.Size = new System.Drawing.Size(75, 27);
            this.btnTransfor.TabIndex = 2;
            this.btnTransfor.Text = "Proceed";
            this.btnTransfor.UseVisualStyleBackColor = false;
            this.btnTransfor.Click += new System.EventHandler(this.button1_Click);
            // 
            // grpBoxTenderType
            // 
            this.grpBoxTenderType.Controls.Add(this.rdbLimited);
            this.grpBoxTenderType.Controls.Add(this.rdbPublic);
            this.grpBoxTenderType.Location = new System.Drawing.Point(188, 59);
            this.grpBoxTenderType.Name = "grpBoxTenderType";
            this.grpBoxTenderType.Size = new System.Drawing.Size(278, 46);
            this.grpBoxTenderType.TabIndex = 3;
            this.grpBoxTenderType.TabStop = false;
            this.grpBoxTenderType.Text = "Tender Type";
            this.grpBoxTenderType.Visible = false;
            // 
            // rdbLimited
            // 
            this.rdbLimited.AutoSize = true;
            this.rdbLimited.Location = new System.Drawing.Point(119, 20);
            this.rdbLimited.Name = "rdbLimited";
            this.rdbLimited.Size = new System.Drawing.Size(58, 17);
            this.rdbLimited.TabIndex = 1;
            this.rdbLimited.TabStop = true;
            this.rdbLimited.Text = "Limited";
            this.rdbLimited.UseVisualStyleBackColor = true;
            // 
            // rdbPublic
            // 
            this.rdbPublic.AutoSize = true;
            this.rdbPublic.Location = new System.Drawing.Point(7, 20);
            this.rdbPublic.Name = "rdbPublic";
            this.rdbPublic.Size = new System.Drawing.Size(54, 17);
            this.rdbPublic.TabIndex = 0;
            this.rdbPublic.TabStop = true;
            this.rdbPublic.Text = "Public";
            this.rdbPublic.UseVisualStyleBackColor = true;
            // 
            // frmTransforProject
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(549, 150);
            this.Controls.Add(this.grpBoxTenderType);
            this.Controls.Add(this.btnTransfor);
            this.Controls.Add(this.cmbCommittee);
            this.Controls.Add(this.lblCommitteName);
            this.Name = "frmTransforProject";
            this.Text = "Transfer Project To Other Committee";
            this.Load += new System.EventHandler(this.frmTransforProject_Load);
            this.grpBoxTenderType.ResumeLayout(false);
            this.grpBoxTenderType.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCommitteName;
        private System.Windows.Forms.ComboBox cmbCommittee;
        private System.Windows.Forms.Button btnTransfor;
        private System.Windows.Forms.GroupBox grpBoxTenderType;
        private System.Windows.Forms.RadioButton rdbLimited;
        private System.Windows.Forms.RadioButton rdbPublic;
    }
}