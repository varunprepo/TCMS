﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using DataGridViewAutoFilter;
using MDI_ParenrForm;
using MDI_ParenrForm.Projects;
using System.Text.RegularExpressions;
//using MDI_ParenrForm;
//using MDI_ParenrForm.Projects;
using System.DirectoryServices;
using MDI_ParenrForm.Admin;
using System.Net.Mail;
using System.Globalization;
using System.Threading;

namespace TenderTrackingSystem
{
    public partial class ProjectStages : Form
    {
        static Int32 projId = 0;
        static short _commId = 0;
        static short tenderTypeId = 0;
        static string strFiscalYr = null;
        static DateTime? dtCreateDate = null;

        Boolean chkProjectTrnsfor = false;
        Boolean chkOnHold = false;
        static string connStr = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();
        SqlConnection sqlConn = new SqlConnection(connStr);
        bool isOnLoad = false;
        //protected SqlConnection sqlCon;
        protected SqlCommand sqlCom;
        protected SqlDataReader sqlDtReader;
        char _chGetShortListed = ' ';
        clsStaffUpdate clsStaff = new clsStaffUpdate();

         
        //static string userName = null;
        string _prjCode = string.Empty;
        string proj_Title = string.Empty;
        int _projID = 0;
        string ministryCode = string.Empty;
        string budjetRefNo = string.Empty;
        string provisionNo = string.Empty;
        string tenderStatus = string.Empty;
        string _cmtName = string.Empty;
        string _tndrType = string.Empty;
        string _fiscalYear = string.Empty;
        string mSelectedTab = null;
        IList<string> mUserRightsColl = new List<string>();
        CommonClass commCls = new CommonClass("");

        clsPtd_Stage clsForPTD = null;
        clsTs_Stage clsForTS = null;
        clsTE_Stage clsForTE = null;
        clsCP_Stage clsForCP = null;
        clsPostContract_Stage clspC = null;

        string _userName = string.Empty;
        bool mIsHeadOfSection = false;
        public ProjectStages(IList<string> userRightsCollPrjState, string paramUserName, int prjID, string user,string selectedTab, bool isHeadOfSection)
        {
            mUserRightsColl = userRightsCollPrjState;
            _userName = user;
            mIsHeadOfSection = isHeadOfSection;
            InitializeComponent();
            _projID = prjID;
            ProjectId = prjID;
            mSelectedTab = selectedTab;
            lblContractNoDisplay.Visible = false;

            commCls.DisplayContractNumber(lblContractNoDisplay, lblContractNo, btnWorkOrder, prjID);
            FillProjectComboInfo();
            FillProjectInfo();
            if (msk_dtp_tsRecOn.Text == "" && msk_dtp_tsStage1.Text == "")
                btnIssueTender.Visible = true;
            if (_tndrType == "L" || _tndrType == "DO")
                btnIssueTender.Text = "Add To ShortList";
            else
                btnIssueTender.Text = "Issue a Tender...";

            clsForPTD = new clsPtd_Stage(user);
            clsForTS = new clsTs_Stage(user);
            clsForTE = new clsTE_Stage(user);
            clsForCP = new clsCP_Stage(user,isHeadOfSection);
            clspC = new clsPostContract_Stage(user);             

            if (txtTenderNo.Text == "")
                btnAssignTender.Visible = true;
            else
                lblTenderNo.Visible = true;

            dgvPC.DataError += new DataGridViewDataErrorEventHandler(dgvPC_DataError);
            dgvPC.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(dgvPC_CellValueChanged);
            dgvContracts.DataError += new DataGridViewDataErrorEventHandler(dgvContracts_DataError);
            dgvCpDataEntry.DataError += new DataGridViewDataErrorEventHandler(dgvCpDataEntry_DataError);
            // Added by Varun on 21 May 2014 for checking the duplicate ContractNo.
            dgvCpDataEntry.EditingControlShowing += new DataGridViewEditingControlShowingEventHandler(dgvCpDataEntry_EditingContractNoColumn);
            lblProjID.Text = _projID.ToString();
        }
        void dgvContracts_DataError(object sender, DataGridViewDataErrorEventArgs e)     //dgvContracts_DataError
        {
            e.Cancel = true;
        }
        void dgvCpDataEntry_DataError(object sender, DataGridViewDataErrorEventArgs e)     //dgvContracts_DataError
        {
            e.Cancel = true;
        }


        private void dgvPC_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            //if (dgvPC.IsCurrentCellDirty)
            //{
            //    iCnt = iCnt + 1;
            //    DataGridView dgv = sender as DataGridView;
            //    if (dgv.CurrentCell != null)
            //    {
            //        if (dgv.CurrentCell.ColumnIndex == 0)
            //        {
            //            // ComboBox comboBox = e.Control as ComboBox;
            //            if (e.RowIndex >= 0) //check if combobox column
            //            {
            //                object selectedValue = dgvPC.Rows[dgv.CurrentCell.RowIndex].Cells[dgv.CurrentCell.ColumnIndex].Value;

            //                if (selectedValue is int)
            //                {
            //                    clspC.FillPostContractsData(dgvPC, _projID);
            //                    string _cmpName = clsForCP.FillComapany_dgvComboValue(Convert.ToInt16(selectedValue));
            //                    dgvPC.Rows[dgv.CurrentCell.RowIndex].Cells[dgv.CurrentCell.ColumnIndex].Value = _cmpName;
            //                }
            //            }
            //            // comboBox.SelectedIndexChanged += LastColumnComboSelectionChanged;
            //        }

            //    }
            //}
            // suspendEventCellValueChanged = false;
        }

        // Added by Varun on 21 May 2014 for checking the duplicate ContractNo.
        TextBox txtContractNo = null;
        string currentBidderID = null;
        void dgvCpDataEntry_EditingContractNoColumn(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            if (mUserRightsColl.Contains("48") && mUserRightsColl.Contains("50"))     // 50 for DA
            {
                MessageBox.Show("You have no privilege to edit the Contract Number,Contact administrator");
                return;
            }
            if (this.dgvCpDataEntry.CurrentCell.ColumnIndex == 7)
            {
                txtContractNo = e.Control as TextBox;
               
                    if (txtContractNo.Text != "")
                    {
                        if (txtContractNo.Text.ToLower().Trim() != "framework")
                        {
                            currentBidderID = dgvCpDataEntry[9, dgvCpDataEntry.CurrentCell.RowIndex].Value.ToString();
                            txtContractNo.Leave -= new EventHandler(txtContractNo_Leave);
                            txtContractNo.Leave += new EventHandler(txtContractNo_Leave);
                        }
                    }
                

            }
        }

        // Added by Varun on 21 May 2014 for checking the duplicate ContractNo.
        private void txtContractNo_Leave(object sender, EventArgs e)
        {
            if (txtContractNo.Text.Trim() != "" && txtContractNo.Text.ToLower().Trim() != "framework")
            {
                if (ValidateContractNo(txtContractNo.Text) == false)
                    txtContractNo.Focus();
            }
        }

        int finalProjId = 0;
        public int ProjectId
        {
            get { return finalProjId; }
            set { finalProjId = value; }
        }
        private void ProjectStages_Load(object sender, EventArgs e)
        {
            CultureInfo m_EnglishCulture = new CultureInfo("en-US", true);
            // set which culture to use
            //Thread.CurrentThread.CurrentUICulture = new CultureInfo("en-US");
            System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.CreateSpecificCulture("en-US");
            System.Threading.Thread.CurrentThread.CurrentUICulture = System.Threading.Thread.CurrentThread.CurrentCulture;

            dtpRecievedOn.Format = DateTimePickerFormat.Custom;

            if (mUserRightsColl.Contains("17"))
            {
                cmbMinistryCode.Enabled = false;
                cmbBudgetRef.Enabled = false;
                txtProvisionNo.Enabled = false;
            }

            if (txtTenderNo.Text == "")
                btnAssignTender.Visible = true;
            else
                lblTenderNo.Visible = true;


            if (mUserRightsColl.Contains("12"))
            {
                cmbTenderStatus.Enabled = false;
            }
            if (cmbTenderStatus.Text.Equals("Committed"))
            {
                if (mUserRightsColl.Count == 0)
                    cmbTenderStatus.Enabled = true;
                else
                    cmbTenderStatus.Enabled = false;

                //Added by Varun on 24-Nov-2015
                if (mUserRightsColl.Count != 0 && mIsHeadOfSection==false)
                {
                    DisabledAllControls();
                }
            }

            if (mUserRightsColl.Count == 0)
            {
                cmbTenderStatusChange.Visible = true;
                btnUpdateProjStatus.Visible = true;
            }
            EnableTabs_BasedOn_UserRights();

            commCls.FillGridSentDocsInfo(Convert.ToInt16(lblProjID.Text), dgvTS_Sent, 2);
            commCls.FillGridReceivedDocsInfo(Convert.ToInt16(lblProjID.Text), dgvTS_Rec, 2);

            //dgvTS_Sent
        }

        //Added by Varun on 24-Nov-2015
        private void DisabledAllControls()
        {
            dtpRecievedOn.Enabled = false;
            msk_dtpRecievedOn.Enabled = false;
            cmbPurpose.Enabled = false;
            cmbAssignedQs.Enabled = false;
            cmbQsWorkingStatus.Enabled = false;
            dtpReview.Enabled = false;
            msk_dtpReview.Enabled = false;
            cmbTenderDocStatus.Enabled = false;
            dtpFrwdDept.Enabled = false;
            msk_dtpFrwdDept.Enabled = false;
            txtRemarks.Enabled = false;
            btnPTD.Enabled = false;
            button22.Enabled = false;
            button23.Enabled = false;
            dtp_tsRecOn.Enabled = false;
            msk_dtp_tsRecOn.Enabled = false;
            cmb_tstenderHandle.Enabled = false;
            dtp_tsReturnDept.Enabled = false;
            msk_dtp_tsReturnDept.Enabled = false;
            dtp_tsRecFromDept.Enabled = false;
            msk_dtp_tsRecFromDept.Enabled = false;
            dtp_tsAdvertisement.Enabled = false;
            msk_dtp_tsAdvertisement.Enabled = false;
            dtp_tsInvitation.Enabled = false;
            msk_dtp_tsInvitation.Enabled = false;
            dtp_tsStage1.Enabled = false;
            msk_dtp_tsStage1.Enabled = false;
            dtp_tsStage2.Enabled = false;
            msk_dtp_tsStage2.Enabled = false;
            dtp_tsModifiedDate.Enabled = false;
            msk_dtp_tsModifiedDate.Enabled = false;
            txt_tsRemarks.Enabled = false;
            btnIssueTender.Enabled = false;
            btnTS.Enabled = false;
            btnViewBidder.Enabled = false;
            btnExportToPdf.Enabled = false;
            btnViewShortList.Enabled = false;
            dtpEA_reqdate.Enabled = false;
            msk_dtpEA_reqdate.Enabled = false;
            dtpEA_recfromcd.Enabled = false;
            msk_dtpEA_recfromcd.Enabled = false;
            dtpEA_datesent.Enabled = false;
            msk_dtpEA_datesent.Enabled = false;
            txtTechEvalProposedWorkDays.Enabled = false;
            dtpEA_daterec.Enabled = false;
            msk_dtpEA_daterec.Enabled = false;
            dtpEA_datesentfin.Enabled = false;
            msk_dtpEA_datesentfin.Enabled = false;
            txtFinEvalProposedWorkDays.Enabled = false;
            dtpEA_daterecFin.Enabled = false;
            msk_dtpEA_daterecFin.Enabled = false;
            dtpEA_apprDate.Enabled = false;
            msk_dtpEA_apprDate.Enabled = false;
            txtEA_Noofmeetings.Enabled = false;
            txtTE_remarks.Enabled = false;
            btnTE_Save.Enabled = false;
            btnCntrSave.Enabled = false;
            btnDelete.Enabled = false;
            btnCP_Save.Enabled = false;
            btnPC_Save.Enabled = false;
        }

        //Added by Varun on 04 Feb 2014 based on Adonis req.
        bool isCpContractorSign = false;
        private void EnableTabs_BasedOn_UserRights()
        {
            string tabToRemove = "ptdTabPage";
            for (int i = 0; i < tabControl1.TabPages.Count; i++)
            {
                if (tabControl1.TabPages[i].Name.Equals(tabToRemove, StringComparison.OrdinalIgnoreCase))
                {
                    if (mUserRightsColl.Contains("37"))
                    {
                        tabControl1.TabPages.RemoveAt(i);
                        break;
                    }
                }
            }
            string tabToRemoveNext = "tsTabPage";
            for (int i = 0; i < tabControl1.TabPages.Count; i++)
            {
                if (tabControl1.TabPages[i].Name.Equals(tabToRemoveNext, StringComparison.OrdinalIgnoreCase))
                {
                    if (mUserRightsColl.Contains("39"))
                    {
                        tabControl1.TabPages.RemoveAt(i);
                        break;
                    }
                    else
                    {
                        //Added by Varun on 04 Feb 2014 based on Adonis req.
                        clsDatabase clsDB = new clsDatabase(ConfigurationManager.AppSettings["TCMSConnString"].ToString());
                        clsDB.ConnectDB();
                        if (clsDB.ExecuteReader1("select proj_id from PROJECTS where Tender_Status_id in(7,14,15) and proj_id=" + _projID))
                            isCpContractorSign = true;
                        clsDB.DisconnectDB();
                    }
                }
            }

            string tabToRemove3 = "teaTabPage";
            for (int i = 0; i < tabControl1.TabPages.Count; i++)
            {
                if (tabControl1.TabPages[i].Name.Equals(tabToRemove3, StringComparison.OrdinalIgnoreCase))
                {
                    if (mUserRightsColl.Contains("45"))
                    {
                        tabControl1.TabPages.RemoveByKey(tabControl1.TabPages[i].Name);
                        //tabControl1.TabPages.RemoveAt(i);
                        break;
                    }
                }
            }
            string tabToRemoveCP = "cpTabPage";
            for (int i = 0; i < tabControl1.TabPages.Count; i++)
            {
                if (tabControl1.TabPages[i].Name.Equals(tabToRemoveCP, StringComparison.OrdinalIgnoreCase))
                {
                    if (mUserRightsColl.Contains("47") && mUserRightsColl.Contains("49"))                   //userRightsColl.Contains("49") ||
                    {
                        tabControl1.TabPages.RemoveAt(i);
                        break;
                    }
                }
            }
            string tabToRemovePC = "pcsTabPage";
            for (int i = 0; i < tabControl1.TabPages.Count; i++)
            {
                if (tabControl1.TabPages[i].Name.Equals(tabToRemovePC, StringComparison.OrdinalIgnoreCase))
                {
                    if (mUserRightsColl.Contains("51"))
                    {
                        tabControl1.TabPages.RemoveAt(i);
                        break;
                    }
                }
            }
            lblProjID.Visible = false;
            string tabToFind = "ptdTabPage";
            for (int i = 0; i < tabControl1.TabPages.Count; i++)
            {
                if (tabControl1.TabPages[i].Name.Equals(tabToFind, StringComparison.OrdinalIgnoreCase))
                {
                    if (ptdCmbFillChk == false)
                    {
                        FillCombo_PTD();
                        ptdCmbFillChk = true;
                        FillPTDInformation();
                    }
                    break;
                }
            }
            if (_tndrType.Equals("DO"))
            {
                string tabToFindCp = "cpTabPage";
                for (int i = 0; i < tabControl1.TabPages.Count; i++)
                {
                    if (tabControl1.TabPages[i].Name.Equals(tabToFindCp, StringComparison.OrdinalIgnoreCase))
                    {
                        tabControl1.TabPages[i].Text = "CONTRACT PROCESS (DIRECT AWARD )";
                        //lblAwardDate.Text = "Direct Award Approval Date";
                        //lblAwardDate.Size= new Size(90, 48);
                        //lblAwardDate.Margin = new Padding(7, 8, 7, 8);      //7, 8, 7, 8
                        btnDatesExtend.Visible = false;
                        break;
                    }
                }
            }
            else
            {
                btnDatesExtend.Visible = true;
            }
        }
        private void EnableTabs_BasedOn_UserRights_Old()
        {
            string tabToRemove = "ptdTabPage";
            for (int i = 0; i < tabControl1.TabPages.Count; i++)
            {
                if (tabControl1.TabPages[i].Name.Equals(tabToRemove, StringComparison.OrdinalIgnoreCase))
                {
                    if (mUserRightsColl.Contains("37"))
                    {
                        tabControl1.TabPages.RemoveAt(i);
                        break;
                    }
                }
            }
            string tabToRemoveNext = "tsTabPage";
            for (int i = 0; i < tabControl1.TabPages.Count; i++)
            {
                if (tabControl1.TabPages[i].Name.Equals(tabToRemoveNext, StringComparison.OrdinalIgnoreCase))
                {
                    if (mUserRightsColl.Contains("39"))
                    {
                        tabControl1.TabPages.RemoveAt(i);
                        break;
                    }
                }
            }
            string tabToRemove3 = "teaTabPage";
            for (int i = 0; i < tabControl1.TabPages.Count; i++)
            {
                if (tabControl1.TabPages[i].Name.Equals(tabToRemove3, StringComparison.OrdinalIgnoreCase))
                {
                    if (mUserRightsColl.Contains("45"))
                    {
                        tabControl1.TabPages.RemoveAt(i);
                        break;
                    }
                }
            }
            string tabToRemoveCP = "cpTabPage";
            for (int i = 0; i < tabControl1.TabPages.Count; i++)
            {
                if (tabControl1.TabPages[i].Name.Equals(tabToRemoveCP, StringComparison.OrdinalIgnoreCase))
                {
                    if (mUserRightsColl.Contains("47") && mUserRightsColl.Contains("49"))                   //userRightsColl.Contains("49") ||
                    {
                        tabControl1.TabPages.RemoveAt(i);
                        break;
                    }
                }
            }
            string tabToRemovePC = "pcsTabPage";
            for (int i = 0; i < tabControl1.TabPages.Count; i++)
            {
                if (tabControl1.TabPages[i].Name.Equals(tabToRemovePC, StringComparison.OrdinalIgnoreCase))
                {
                    if (mUserRightsColl.Contains("51"))
                    {
                        tabControl1.TabPages.RemoveAt(i);
                        break;
                    }
                }
            }
            lblProjID.Visible = false;
            string tabToFind = "ptdTabPage";
            for (int i = 0; i < tabControl1.TabPages.Count; i++)
            {
                if (tabControl1.TabPages[i].Name.Equals(tabToFind, StringComparison.OrdinalIgnoreCase))
                {
                    if (ptdCmbFillChk == false)
                    {
                        FillCombo_PTD();
                        ptdCmbFillChk = true;
                    }
                    FillPTDInformation();
                    break;
                }
            }
            if (_tndrType.Equals("DO"))
            {
                string tabToFindCp = "cpTabPage";
                for (int i = 0; i < tabControl1.TabPages.Count; i++)
                {
                    if (tabControl1.TabPages[i].Name.Equals(tabToFindCp, StringComparison.OrdinalIgnoreCase))
                    {
                        tabControl1.TabPages[i].Text = "CONTRACT PROCESS (DIRECT AWARD )";
                        //lblAwardDate.Text = "Direct Award Approval Date";
                        //lblAwardDate.Size= new Size(90, 48);
                        //lblAwardDate.Margin = new Padding(7, 8, 7, 8);      //7, 8, 7, 8
                        btnDatesExtend.Visible = false;
                        break;
                    }
                }
            }
            else
            {
                btnDatesExtend.Visible = true;
            }
        }
        private void FillProjectComboInfo()
        {
            commCls.PopulateComboBox(cmb_tstenderHandle, @"Select employee_id, shortname from Contacts where shortname is not null order by shortname asc", "employee_id", "shortname");
            commCls.PopulateComboBox(cmbMinistryCode, @"SELECT Ministry_id,[MinistryCode] as MinistryCode FROM [MinistryCodes] ORDER BY MinistryCode", "Ministry_id", "MinistryCode");
            commCls.PopulateComboBox(cmbBudgetRef, @"SELECT [BudgetRef_id] as BudRefID, [BudgetRefNumber] as BudgeRefCode FROM [BudgetReferenceCodes] ORDER BY BudgeRefCode", "BudRefID", "BudgeRefCode");
            if (mSelectedTab == "Deleted Projects")
                commCls.PopulateComboBox(cmbTenderStatus, @"Select Tender_Status_id,[Status_Name] as tsStatus from [TenderStatus] Where Tender_Status_id =16 Order By Tender_Status_id", "Tender_Status_id", "tsStatus");
            else
                commCls.PopulateComboBox(cmbTenderStatus, @"Select Tender_Status_id,[Status_Name] as tsStatus from [TenderStatus] Where Tender_Status_id in(8,9,10,11) Order By Tender_Status_id", "Tender_Status_id", "tsStatus");
            if(mUserRightsColl.Count ==0)
                commCls.PopulateComboBox(cmbTenderStatusChange, @"Select Tender_Status_id,[Status_Name] as tsStatus from [TenderStatus] Where Tender_Status_id <8 Order By Tender_Status_id", "Tender_Status_id", "tsStatus");
        }

        private void FillProjectInfo()
        {
            try
            {
                using (sqlConn = new SqlConnection(connStr))
                {
                    sqlConn.Open();
                    string sqlQuery = "SELECT PROJECTS.project_code, PROJECTS.project_newname_en, PROJECTS.tender_no, Committee.committee_short_name, Committee.committee_name, " +
                    " [FiscalYear].[FiscalYear], [TenderTypes].tender_type_short_name, PROJECTS.[Ministry_Code], PROJECTS.[Budget_Reference_No], " +
                    " PROJECTS.[Provision_Number], PROJECTS.proj_id, [TenderStatus].[Status_Name], PROJECTS.committee_id, AFFAIRS.Affairs_Name, Department.Department" +
                    " FROM PROJECTS INNER JOIN Committee ON PROJECTS.committee_id = Committee.committee_id INNER JOIN [TenderTypes] ON PROJECTS.tender_type_id = [TenderTypes].tender_type_id INNER JOIN " +
                    " [FiscalYear] ON PROJECTS.FYID = [FiscalYear].FYID INNER JOIN [TenderStatus] ON PROJECTS.Tender_Status_id = [TenderStatus].Tender_Status_id  INNER JOIN " +
                    " Department ON PROJECTS.department_id = Department.department_id INNER JOIN AFFAIRS ON PROJECTS.Affair_id = AFFAIRS.Affair_id " +
                    " WHERE (PROJECTS.proj_id = " + _projID + " )";

                    using (SqlCommand sqlCommand = new SqlCommand(sqlQuery, sqlConn))
                    {
                        using (SqlDataReader sqlReader = sqlCommand.ExecuteReader())
                        {
                            while (sqlReader.Read())
                            {
                                _prjCode = sqlReader[0].ToString();
                                proj_Title = sqlReader[1].ToString();
                                txtProjCode.Text = sqlReader[0].ToString();
                                txtproj.Text = sqlReader[1].ToString();
                                lblProjID.Text = sqlReader[10].ToString();
                                txtTenderNo.Text = sqlReader[2].ToString();
                                if (txtTenderNo.Text != "")
                                    btnAssignTender.Visible = false;
                                txtProvisionNo.Text = sqlReader[9].ToString().Replace(" ", "-").Replace("/", "-").Replace(".", "-");
                                cmbMinistryCode.Text = sqlReader[7].ToString();
                                cmbBudgetRef.Text = sqlReader[8].ToString();
                                // Added by Varun on 3rd Nov 2015
                                if (mSelectedTab != null)
                                {
                                    if (mSelectedTab == "Archives")
                                    {
                                        if (sqlReader[11].ToString().Trim() == "Cancelled" || sqlReader[11].ToString().Trim() == "Re-Tender" || sqlReader[11].ToString().Trim() == "Transferred To Other Committee" || sqlReader[11].ToString().Trim() == "On Hold")
                                        {
                                            txt_tsRemarks.Enabled = false;
                                            txtTE_remarks.Enabled = false;
                                        }
                                    }
                                }
                                if (mSelectedTab != "Deleted Projects")
                                    cmbTenderStatus.Text = sqlReader[11].ToString();
                                else
                                    cmbTenderStatus.Text = "Revert Deleted Project";
                                _cmtName = sqlReader[3].ToString();
                                _tndrType = sqlReader[6].ToString();
                                _fiscalYear = sqlReader[5].ToString();
                                _commId = Convert.ToSByte(sqlReader[12]);
                                _userDept = sqlReader[13].ToString();
                                _AffairsName = sqlReader[14].ToString();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error While Reading Project Data" + ex.Message);
            }
            finally
            {
                sqlConn.Close();
            }
        }

        #region   // For Prepare Tender Document Tab


        private void FillPTDInformation()
        {
            clsForPTD.CreateGridviewForPTD(dgvPTD, _projID);
            FillReceiveSentDocs();
        }
        private void FillReceiveSentDocs()
        {
            if (tabControl1.SelectedTab.Name == "ptdTabPage")
            {
                commCls.FillGridReceivedDocsInfo(_projID, dgvPTD_Rec, 1);
                commCls.FillGridSentDocsInfo(_projID, dgvPTD_Sent, 1);
            }
        }
        private void FillCombo_PTD()
        {
            cmbPurpose.Items.Add("Preparation");
            cmbPurpose.Items.Add("Review");
            cmbPurpose.Items.Add("Amendment");
            cmbPurpose.Items.Add("Re-Tender");
            cmbPurpose.Items.Add("Tender");

            cmbPurpose.SelectedIndex = -1;

            commCls.PopulateComboBox(cmbAssignedQs, "SELECT employee_id, shortname from Contacts where shortname is not null order by shortname asc", "employee_id", "shortname");
            cmbAssignedQs.SelectedIndex = -1;

            cmbQsWorkingStatus.Items.Add("On-going");
            cmbQsWorkingStatus.Items.Add("Completed");
            cmbQsWorkingStatus.Items.Add("On Hold");
            cmbQsWorkingStatus.SelectedIndex = -1;

            cmbTenderDocStatus.Items.Add("Approved");
            cmbTenderDocStatus.Items.Add("Disapproved");
            cmbTenderDocStatus.SelectedIndex = -1;
        }
        private void btnReceiveDoc_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Contains("19"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }
            ReceivedDocProperties receivedDoc = new ReceivedDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), 1, _userName);
            receivedDoc.StartPosition = FormStartPosition.CenterParent;
            receivedDoc.ShowDialog();
            commCls.FillGridReceivedDocsInfo(Convert.ToInt16(lblProjID.Text), dgvPTD_Rec, 1);
        }
        private void btnSentDoc_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Contains("19"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }
            SentDocProperties sentDocProp = new SentDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), 1, _userName);
            sentDocProp.StartPosition = FormStartPosition.CenterParent;
            sentDocProp.ShowDialog();
            commCls.FillGridSentDocsInfo(Convert.ToInt16(lblProjID.Text), dgvPTD_Sent, 1);
        }
        private void dgvPTD_Rec_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (mUserRightsColl.Contains("21"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }
            int rowIndex = e.RowIndex;
            try
            {
                if (rowIndex != -1)
                {
                    if (dgvPTD_Rec.Rows[rowIndex].Cells[3].Value.ToString() != "")
                    {
                        int docId = Convert.ToInt16(dgvPTD_Rec.Rows[rowIndex].Cells[3].Value);
                        ReceivedDocProperties receivedDoc = new ReceivedDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), txtProjCode.Text, docId, 1, _userName);
                        receivedDoc.StartPosition = FormStartPosition.CenterParent;
                        receivedDoc.ShowDialog();
                        commCls.FillGridReceivedDocsInfo(Convert.ToInt16(lblProjID.Text), dgvPTD_Rec, 1);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void dgvPTD_Sent_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (mUserRightsColl.Contains("21"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            int rowIndex = e.RowIndex;

            try
            {
                if (rowIndex != -1)
                {
                    if (dgvPTD_Sent.Rows[rowIndex].Cells[0].Value.ToString() != "")
                    {
                        int docId = Convert.ToInt32(dgvPTD_Sent.Rows[rowIndex].Cells[0].Value);
                        SentDocProperties sentDoc = null;
                        if (dgvPTD_Sent.Rows[rowIndex].Cells[1].Value.ToString() != "")
                            sentDoc = new SentDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), txtProjCode.Text, docId, 1, _userName, dgvPTD_Sent.Rows[rowIndex].Cells[0].Value, 'Y', mIsHeadOfSection);
                        else
                            sentDoc = new SentDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), txtProjCode.Text, docId, 1, _userName, "", 'Y', mIsHeadOfSection);

                        sentDoc.StartPosition = FormStartPosition.CenterParent;
                        sentDoc.ShowDialog();

                        commCls.FillGridSentDocsInfo(Convert.ToInt16(lblProjID.Text), dgvPTD_Sent, 1);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region   // For Tender Stage Tab

        private void btnIssueTender_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
            {
                if (mUserRightsColl.Contains("70"))
                {
                    int hrCnt = System.DateTime.Now.Hour;
                    if (hrCnt >= 13)
                    {
                        if (btnIssueTender.Text == "Issue a Tender...")
                            MessageBox.Show("Issue a tender time is exceeded for the day, Please contact head of section", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show("Can not add to shortlist, time is exceeded for the day, Please contact head of section", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                }
            }

            if ((mUserRightsColl.Count != 0 || mUserRightsColl.Count == 0) && mIsHeadOfSection == false)
            {
                if (msk_dtp_tsStage1.Text.Trim() != "")
                {
                    DateTime start = new DateTime(1990, 1, 1);
                    if (msk_dtp_tsModifiedDate.Text.Trim() != "")
                        start = Convert.ToDateTime(msk_dtp_tsModifiedDate.Text);
                    else
                        start = Convert.ToDateTime(msk_dtp_tsStage1.Text);

                    DateTime end = new DateTime(1990, 1, 31);
                    end = System.DateTime.Now;

                    int dateCnt = Convert.ToInt16((start - end).Days);
                    if (dateCnt < 0)
                    {
                        if (btnIssueTender.Text == "Issue a Tender...")
                            MessageBox.Show("You can't Issue a tender after Tender Closing Date expired", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show("You can't add to shortlist after Tender Closing Date expired", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                }
            }

            if (btnIssueTender.Text == "Issue a Tender...")
            {
                if (mUserRightsColl.Contains("42"))
                {
                    MessageBox.Show("You have no privilege to Issue a Tender. Please Contact system administrator.");
                    return;
                }

                string strSelectedComp = commCls.chkAccessRightsAndSelectedCompanies('I', mUserRightsColl, txtTenderNo.Text, msk_dtp_tsStage1, chkLocal, chkInternational, chkJointVenture);
                if (strSelectedComp == "R")
                    return;

                //New parameter closing date added by Varun on 07/Jun/2015
                MDI_ParenrForm.Projects.frmIssueTenderInfo tenderInfo = new MDI_ParenrForm.Projects.frmIssueTenderInfo(mUserRightsColl, Convert.ToInt16(lblProjID.Text), txtTenderNo.Text, txtproj.Text, strSelectedComp, _userName, 'N', "Issue", _prjCode, txtDocumentFee.Text);
                tenderInfo.StartPosition = FormStartPosition.CenterParent;
                tenderInfo.ShowDialog();
            }
            else
            {
                if (mUserRightsColl.Contains("42"))
                {
                    MessageBox.Show("You have no privilege to Add Company in the Short List. Please Contact system administrator.");
                    return;
                }

                string strSelectedCompanies = string.Empty;
                strSelectedCompanies = commCls.chkAccessRightsAndSelectedCompanies('A', mUserRightsColl, txtTenderNo.Text, msk_dtp_tsStage1, chkLocal, chkInternational, chkJointVenture);
                if (strSelectedCompanies == "R")
                    return;
                //New parameter closing date added by Varun on 07/Jun/2015
                MDI_ParenrForm.Projects.frmAddToShortList addToShortList = new MDI_ParenrForm.Projects.frmAddToShortList(mUserRightsColl, Convert.ToInt16(lblProjID.Text), txtTenderNo.Text, txtproj.Text, strSelectedCompanies, _userName, msk_dtpEA_stage1.Text);
                addToShortList.StartPosition = FormStartPosition.CenterParent;
                addToShortList.ShowDialog();
            }
        }
        private void btnTS_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Contains("40"))       // For TS
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            int updDateID = 0;
            string tsReceivedDate = string.Empty;

            int statusID = 0;
            statusID = getStatusID(ProjectId);

            if (CheckDataExistForTenderStage(ref updDateID, ref tsReceivedDate) == true)
            {
                UpdateTenderStageInfo(updDateID);

                if (msk_dtp_tsModifiedDate.Text != "")
                {
                    if (Convert.ToDateTime(msk_dtp_tsModifiedDate.Text) > Convert.ToDateTime(System.DateTime.Now))
                    {
                        if (statusID < 2)
                        {
                            UpdateStatusForClosingDate();
                            // added by Varun on 11/05/2015
                            FillProjectInfo();
                        }
                    }
                }
                else if (msk_dtp_tsStage1.Text != "")
                {
                    if (Convert.ToDateTime(msk_dtp_tsStage1.Text) > Convert.ToDateTime(System.DateTime.Now))
                    {
                        // if (statusID < 2)
                        UpdateStatusForClosingDate();
                    }
                }

                if (msk_dtp_tsRecOn.Text != "")
                {
                    //string  dt = Convert.ToDateTime(tsReceivedDate); //.ToString("dd-MMM-yyyy");
                    //string dt1 = Convert.ToDateTime(tsReceivedDate); //.ToString("dd-MMM-yyyy");
                    if (tsReceivedDate != "")
                    {
                        if (!Convert.ToDateTime(tsReceivedDate).Equals(Convert.ToDateTime(msk_dtp_tsRecOn.Text)))
                        {
                            if (statusID < 2)
                            {
                                UpdateStatusFor_ReceivedDate();
                                // added by Varun on 11/05/2015
                                FillProjectInfo();
                            }
                        }
                    }
                }
            }
            else
            {
                int dateID = MaxDateID();
                if (msk_dtp_tsRecOn.Text == "")
                { MessageBox.Show("Please select tender received date"); return; }

                InsertTenderStageInfo(dateID);
                clsForPTD.UpdateStageLevel(_projID);
                if (msk_dtp_tsModifiedDate.Text != "")
                {
                    if (Convert.ToDateTime(msk_dtp_tsModifiedDate.Text) < Convert.ToDateTime(System.DateTime.Now))
                    {
                        UpdateStatusForClosingDate();
                        // added by Varun on 11/05/2015
                        FillProjectInfo();
                    }
                }
                else if (msk_dtp_tsStage1.Text != "")
                {
                    if (Convert.ToDateTime(msk_dtp_tsStage1.Text) < Convert.ToDateTime(System.DateTime.Now))
                    {
                        UpdateStatusForClosingDate();
                        // added by Varun on 11/05/2015
                        FillProjectInfo();
                    }
                }
            }


        }

        private int MaxDateID()
        {
            SqlConnection sqlConn = null;
            int dateId = 0;
            try
            {
                using (sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"SELECT MAX(DATE_ID)+1 FROM TenderDatesInfo";
                        dateId = Convert.ToInt16(cmd.ExecuteScalar());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while reading Max Date, Try again.", ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {
                sqlConn.Close();
            }
            return dateId;
        }

        private int getStatusID(int projID)
        {
            string strQuery = "SELECT Tender_Status_id FROM projects WHERE (proj_id = " + projID + ")";
            int sttID = 0;
            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                    {
                        if (sqlDr.HasRows)
                        {
                            while (sqlDr.Read())
                            {
                                sttID = Convert.ToInt32(sqlDr[0].ToString());
                            }
                        }
                    }
                }
                sqlCn.Close();
            }
            return sttID;
        }
        private string getReceivedOnDate(int projID)
        {
            string strQuery = "SELECT ts_receive_on FROM tenderdatesinfo WHERE (proj_id = " + projID + ")";
            string dt_tsRecOn = string.Empty;
            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                    {
                        if (sqlDr.HasRows)
                        {
                            while (sqlDr.Read())
                            {
                                if (sqlDr[0].ToString() != "")
                                {
                                    dt_tsRecOn = sqlDr[0].ToString();
                                }
                            }
                        }
                    }
                }
                sqlCn.Close();
            }
            return dt_tsRecOn;
        }
        private void btnViewBidder_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Contains("43"))
            {
                MessageBox.Show("You have no privilege to View Bidders. Please Contact system administrator.");
                return;
            }

            string strSelectedCompanies = string.Empty;
            strSelectedCompanies = commCls.chkAccessRightsAndSelectedCompanies('V', mUserRightsColl, null, null, chkLocal, chkInternational, chkJointVenture);

            int _circularCnt = clsForTS.GetCircularCount(_projID);

            MDI_ParenrForm.Projects.frmBidderInfo frmbidders = null;
            //replace msk_dtp_tsAdvertisement.Text by msk_dtp_tsInvitation.Text based on Riyas request by Varun on 16 Feb 2014 
            if (_chGetShortListed == 'Y')
                frmbidders = new MDI_ParenrForm.Projects.frmBidderInfo(mUserRightsColl, _projID, txtProjCode.Text, txtproj.Text, txtTenderNo.Text, strSelectedCompanies, _userName, txtTenderBond.Text, txtDocumentFee.Text, msk_dtp_tsInvitation.Text, '3', strEligibleTenderTypes, 'Y', _tndrType, 1);
            else
                frmbidders = new MDI_ParenrForm.Projects.frmBidderInfo(mUserRightsColl, _projID, txtProjCode.Text, txtproj.Text, txtTenderNo.Text, strSelectedCompanies, _userName, txtTenderBond.Text, txtDocumentFee.Text, msk_dtp_tsInvitation.Text, 'V', strEligibleTenderTypes, 'Y', _tndrType, 1);

            frmbidders.StartPosition = FormStartPosition.CenterScreen;
            frmbidders.ShowDialog();
        }
        private void btnRecDocTS_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Contains("19"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }
            ReceivedDocProperties receivedDoc = new ReceivedDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), 2, _userName);
            receivedDoc.StartPosition = FormStartPosition.CenterParent;
            receivedDoc.ShowDialog();

            commCls.FillGridReceivedDocsInfo(Convert.ToInt16(lblProjID.Text), dgvTS_Rec, 2);
        }
        private void btnSentDocTS_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Contains("19"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }
            SentDocProperties sentDocProp = new SentDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), 2, _userName);
            sentDocProp.StartPosition = FormStartPosition.CenterParent;
            sentDocProp.ShowDialog();
            commCls.FillGridSentDocsInfo(Convert.ToInt16(lblProjID.Text), dgvTS_Sent, 2);
            int _circularCnt = clsForTS.GetCircularCount(_projID);
            txtCircular.Text = _circularCnt.ToString();
        }

        #endregion

        #region   // For Tender Stage Tab

        private void btnTE_Save_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Contains("46"))         // For TE
            {
                MessageBox.Show("You have no privilege, Contact Administrator");
                return;
            }

            if (msk_dtpEA_recfromcd.Text != "" && msk_dtpEA_stage1.Text != "")
            {
                if (Convert.ToDateTime(msk_dtpEA_recfromcd.Text).CompareTo(Convert.ToDateTime(msk_dtpEA_stage1.Text)) >= 1 || Convert.ToDateTime(msk_dtpEA_recfromcd.Text).CompareTo(Convert.ToDateTime(msk_dtpEA_stage1.Text)) == 0)
                {
                    MessageBox.Show("Doc Received From CD Date cannot be greater than or equal to Tender Closing Date");
                    return;
                }
            }
            if (msk_dtpEA_recfromcd.Text != "" && msk_dtp_tsInvitation.Text != "")
            {
                if (Convert.ToDateTime(msk_dtpEA_recfromcd.Text).CompareTo(Convert.ToDateTime(msk_dtp_tsInvitation.Text)) < 0)
                {
                    MessageBox.Show("Doc Received From CD Date cannot be less than Tender Issue Date");
                    return;
                }
            }

            int statusID = getStatusID(ProjectId);

            if (CheckDataExistForTenderEvaluation() == true)
            {
                UpdateTenderElevationData();
                Get_original_TenderDates();

                if (msk_dtpEA_datesent.Text != "" & msk_dtpEA_datesentfin.Text == "")
                {
                    if (statusID <= 3)
                    {
                        clsForTE.UpdateTenderStatusForEvaluationData(_projID);
                        // added by Varun on 11/05/2015
                        FillProjectInfo();
                    }
                    else
                    {
                        clsForTE.UpdateTenderStatusForEvaluationData(_projID);
                        // added by Varun on 11/05/2015
                        FillProjectInfo();
                    }
                }
                else if (msk_dtpEA_datesent.Text != "" & msk_dtpEA_datesentfin.Text != "")
                {
                    if (msk_dtpEA_datesent.Text.Equals(msk_dtpEA_datesentfin.Text))
                    {
                        if (statusID <= 3)
                        {
                            clsForTE.UpdateTenderStatusFor_Tech_and_EvaluationData(_projID);
                            // added by Varun on 11/05/2015
                            FillProjectInfo();
                        }
                        else
                        {
                            clsForTE.UpdateTenderStatusFor_Tech_and_EvaluationData(_projID);
                            // added by Varun on 11/05/2015
                            FillProjectInfo();
                        }
                    }
                    else if (!msk_dtpEA_datesent.Text.Equals(msk_dtpEA_datesentfin.Text))
                    {
                        if (statusID <= 5)
                        {
                            clsForTE.UpdateTenderStatusForFinancialData(_projID);
                            // added by Varun on 11/05/2015
                            FillProjectInfo();
                        }
                        else
                        {
                            clsForTE.UpdateTenderStatusForFinancialData(_projID);
                            // added by Varun on 11/05/2015
                            FillProjectInfo();
                        }
                    }
                }


            }
            else
            {
                int dateId = 0;
                dateId = MaxDateID();
                
                if (msk_dtpEA_reqdate.Text == "")
                {
                    MessageBox.Show("Please Select Tender Open Date");
                    return;
                }
                InsertTenderElevationData(dateId);
                //UpdateTenderStageForElevation();

                Get_original_TenderDates();

                //Sree

                if (msk_dtpEA_datesent.Text != "" & msk_dtpEA_datesentfin.Text == "")
                {
                    clsForTE.UpdateTenderStatusForEvaluationData(_projID);
                    // added by Varun on 11/05/2015
                    FillProjectInfo();
                }
                else if (msk_dtpEA_datesent.Text != "" & msk_dtpEA_datesentfin.Text != "")
                {
                    if (msk_dtpEA_datesent.Text.Equals(msk_dtpEA_datesentfin.Text))
                    {
                        clsForTE.UpdateTenderStatusFor_Tech_and_EvaluationData(_projID);
                        // added by Varun on 11/05/2015
                        FillProjectInfo();
                    }
                    else if (!msk_dtpEA_datesent.Text.Equals(msk_dtpEA_datesentfin.Text))
                    {
                        clsForTE.UpdateTenderStatusForFinancialData(_projID);
                        // added by Varun on 11/05/2015
                        FillProjectInfo();
                    }
                }

                if (msk_dtpEA_apprDate.Text != "")
                {
                    if (msk_dtpEA_datesent.Text != "" & msk_dtpEA_datesentfin.Text != "")
                    {
                        clsForTE.UpdateTenderStatusForAward(_projID);
                        // added by Varun on 11/05/2015
                        FillProjectInfo();
                    }
                }
            }
        }
        private void btnSent_TEA_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Contains("19"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }
            SentDocProperties sentDocProp = new SentDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), 3, _userName);
            sentDocProp.StartPosition = FormStartPosition.CenterParent;
            sentDocProp.ShowDialog();

            commCls.FillGridSentDocsInfo(Convert.ToInt16(lblProjID.Text), dgvTE_Sent, 3);
        }
        private void btnRecDocTE_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Contains("19"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            ReceivedDocProperties receivedDoc = new ReceivedDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), 3, _userName);
            receivedDoc.StartPosition = FormStartPosition.CenterParent;
            receivedDoc.ShowDialog();

            commCls.FillGridReceivedDocsInfo(Convert.ToInt16(lblProjID.Text), dgvTE_Rec, 3);
        }

        #endregion

        private void button8_Click(object sender, EventArgs e)
        {
            ReceivedDocProperties receivedDoc = new ReceivedDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), txtProjCode.Text, Convert.ToInt16(lblProjID.Text), 0, _userName);
            receivedDoc.StartPosition = FormStartPosition.CenterParent;
            receivedDoc.ShowDialog();
        }
        private void button7_Click(object sender, EventArgs e)
        {
            SentDocProperties sentDocProp = new SentDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), txtProjCode.Text, Convert.ToInt16(lblProjID.Text), 0, _userName, "", 'N', mIsHeadOfSection);
            sentDocProp.StartPosition = FormStartPosition.CenterParent;
            sentDocProp.ShowDialog();
        }

        private void btnSavePrj_Click(object sender, EventArgs e)
        {
            //for (int i = 0; i < dgvPTD.Rows.Count - 1; i++)
            //{
            //   Array MyArray =new Array[5];               
            //   string ProductA = dgvPTD.Rows[i].Cells[0].Value.ToString();
            //   string ProductB = dgvPTD.Rows[i].Cells[1].Value.ToString();
            //   string Productc = dgvPTD.Rows[i].Cells[2].Value.ToString();
            //   string Productd = dgvPTD.Rows[i].Cells[3].Value.ToString();

            //MyArray.Add(ClassPro);
            //}

            //class Database Access Object
            //for (int i = 0; i < Class.MyArray.Count; i++)
            //{
            //    string InsertTable = "insert into table_name values('" + Class.MyArray[i].ProductA + "', '" + Class.MyArray[i].ProductB + "' )";
            //} 
        }

        private void GridViewRefresh_PTD()
        {
            SqlConnection sqlConn = new SqlConnection(connStr);
            DataTable dtProject = null;
            string[] projRows = new string[8];
            try
            {
                sqlConn = new SqlConnection(connStr);
                sqlConn.Open();
                DAL dalObj = new DAL();
                dtProject = dalObj.GetDataFromDB("ProjectPTD", "SELECT date_id,proj_id, stage_id, ptd_receive_on, ptd_purpose, ptd_assign_qs, ptd_sent_for_rev, ptd_qs_working_status, ptd_tendec_doc_cur_status,ptd_forwarded_to_dep, remarks FROM TenderDatesInfo WHERE (stage_id = 1) AND (proj_id = " + Convert.ToInt16(lblProjID.Text) + " ) Order by date_id");

                DataTable finalDt = new DataTable("ProjectPTD");
                finalDt.Columns.Add("ReceivedOn");
                finalDt.Columns.Add("Purpose");
                finalDt.Columns.Add("AssignedQS");
                finalDt.Columns.Add("Review");
                finalDt.Columns.Add("QSWorkingStatus");
                finalDt.Columns.Add("TenderDocumentCurrentStatus");
                finalDt.Columns.Add("ForwardedToTenderDepartment");
                finalDt.Columns.Add("Remarks");
                finalDt.Columns.Add("DateID");

                finalDt.AcceptChanges();
                foreach (DataRow drProj in dtProject.Rows)
                {
                    DataRow dr = finalDt.NewRow();                     
                    if (drProj[3] != DBNull.Value)
                        dr[0] = Convert.ToDateTime(drProj[3]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture);//ToString("dd/MMM/yyyy");   //ReceivedOn
                    else
                        dr[0] = drProj[3];   //ReceivedOn

                    dr[1] = drProj[4];  //Purpose
                    dr[2] = drProj[5]; ;  //AssignedQS

                    if (drProj[6] != DBNull.Value)
                        dr[3] = Convert.ToDateTime(drProj[6]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture);//ToString("dd/MMM/yyyy");  //Review
                    else
                        dr[3] = drProj[6];

                    dr[4] = drProj[7];  //QSWorkingStatus
                    dr[5] = drProj[8];  //TenderDocumentCurrentStatus

                    if (drProj[9] != DBNull.Value)
                        dr[6] = Convert.ToDateTime(drProj[9]).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture);//ToString("dd/MMM/yyyy");  //ForwardedToTenderDepartment
                    else
                        dr[6] = drProj[9];

                    dr[7] = drProj[10];  //Remarks
                    //dr[9] = drProj[1];  //proj_id
                    // dr[10] = drProj[0];  //stage_id
                    dr[8] = Convert.ToInt16(drProj[0]);   //dateID
                    finalDt.Rows.Add(dr);
                    finalDt.AcceptChanges();
                }
                BindingSource myBindingSource = new BindingSource(finalDt, null);
                dgvPTD.DataSource = myBindingSource;
                dgvPTD.DefaultCellStyle.WrapMode = DataGridViewTriState.True;

                //dgvPTD.ColumnHeadersDefaultCellStyle.Font = new Font(dgvPTD.Font, FontStyle.Bold);

                dgvPTD.EnableHeadersVisualStyles = false;
                dgvPTD.Columns[8].Visible = false;
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }
        }
        Boolean ptdCmbFillChk = false;
        Boolean saveChk = false;
        Boolean saveTEAChk = false;
        int dateID_TEA = 0;

        static string _modifiedClosingDate = string.Empty;
        private Boolean FillTenderStageInfo(ref int dateiDofTS, ref string mdfExistDate)
        {
            Boolean statusChk = false;

            string strQuery = "SELECT  ts_receive_on,ts_issue_handling, ts_return_to_dept, ts_receive_from_dept, ts_pr_advertise, ts_tender_invitation, ts_closing_s1, ts_closing_s2, " +
            " ts_modified_closing, date_id, proj_id, stage_id, date_id AS Expr1,remarks FROM TenderDatesInfo WHERE (proj_id = " + Convert.ToInt16(lblProjID.Text) + ") AND (stage_id = 2) AND (ts_tender_issue is null) AND (co_ID is NULL)";

            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                    {
                        if (sqlDr.HasRows)
                        {
                            statusChk = true;
                            while (sqlDr.Read())
                            {
                                if (sqlDr[0].ToString() != "")
                                {
                                    DateTime dt_tsRecOn = Convert.ToDateTime(sqlDr[0].ToString());
                                    msk_dtp_tsRecOn.Text = dt_tsRecOn.ToString("dd/MMM/yyyy");
                                }

                                cmb_tstenderHandle.Text = sqlDr[1].ToString();

                                if (sqlDr[2].ToString() != "")
                                {
                                    DateTime dt_tsReturnDept = Convert.ToDateTime(sqlDr[2].ToString());
                                    msk_dtp_tsReturnDept.Text = dt_tsReturnDept.ToString("dd/MMM/yyyy");
                                }
                                if (sqlDr[3].ToString() != "")
                                {
                                    DateTime dt_tsRecFromDept = Convert.ToDateTime(sqlDr[3].ToString());
                                    msk_dtp_tsRecFromDept.Text = dt_tsRecFromDept.ToString("dd/MMM/yyyy");
                                }
                                if (sqlDr[4].ToString() != "")
                                {
                                    DateTime dt_tsAdvertisement = Convert.ToDateTime(sqlDr[4].ToString());
                                    msk_dtp_tsAdvertisement.Text = dt_tsAdvertisement.ToString("dd/MMM/yyyy");
                                }
                                if (sqlDr[5].ToString() != "")
                                {
                                    DateTime dt_tsInvitation = Convert.ToDateTime(sqlDr[5].ToString());
                                    msk_dtp_tsInvitation.Text = dt_tsInvitation.ToString("dd/MMM/yyyy");
                                }
                                if (sqlDr[6].ToString() != "")
                                {
                                    DateTime dt_tsStage1 = Convert.ToDateTime(sqlDr[6].ToString());
                                    msk_dtp_tsStage1.Text = dt_tsStage1.ToString("dd/MMM/yyyy");
                                }
                                if (sqlDr[7].ToString() != "")
                                {
                                    DateTime dt_tsStage2 = Convert.ToDateTime(sqlDr[7].ToString());
                                    msk_dtp_tsStage2.Text = dt_tsStage2.ToString("dd/MMM/yyyy");
                                }
                                if (sqlDr[8].ToString() != "")
                                {
                                    DateTime dt_tsModifiedDate = Convert.ToDateTime(sqlDr[8].ToString());
                                    msk_dtp_tsModifiedDate.Text = dt_tsModifiedDate.ToString("dd/MMM/yyyy");
                                    _modifiedClosingDate = dt_tsModifiedDate.ToString("dd/MMM/yyyy");
                                    mdfExistDate = dt_tsModifiedDate.ToString("dd/MMM/yyyy");
                                }

                                // cmb_tstenderHandle.Text = sqlDr[11].ToString();

                                txt_tsRemarks.Text = sqlDr[13].ToString();
                                dateiDofTS = Convert.ToInt16(sqlDr[12]);
                            }
                        }
                    }
                }
                sqlCn.Close();
            }
            return statusChk;
        }
        private List<string> FillTender_ModifiedDates()
        {
            List<string> dateColl = new List<string>();
            //cmbTndrMdfColl.Items.Clear();

            string strQuery = "SELECT tndr_modifiedDate,proj_id, stage_id FROM tndr_ModifiedDates WHERE (proj_id = " + Convert.ToInt16(lblProjID.Text) + ") order by DateID";

            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                    {
                        if (sqlDr.HasRows)
                        {
                            while (sqlDr.Read())
                            {
                                if (sqlDr[0].ToString() != "")
                                {
                                    DateTime dt_tsRecOn = Convert.ToDateTime(sqlDr[0].ToString());

                                    //cmbTndrMdfColl.Items.Add(dt_tsRecOn.ToString("dd/MMM/yyyy"));
                                }
                            }
                        }
                    }
                }
                sqlCn.Close();
            }
            if (cmbTndrMdfColl.Items.Count != 0)
                lblDateCnt.Text = cmbTndrMdfColl.Items.Count.ToString();
            return dateColl;
        }
        private void FillProjectCostDetailsOfTenderEvaluation()
        {
            string strQuery = "SELECT budgeted_cost,estimated_cost FROM PROJECTCOST WHERE proj_id = " + Convert.ToInt16(lblProjID.Text) + " and Stage_id = 4";
            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                    {
                        if (sqlDr.HasRows)
                        {
                            while (sqlDr.Read())
                            {
                                if (sqlDr[0].ToString() != "") //&& sqlDr[0].ToString() != "0.0000"
                                {
                                    txtBudjetAmnt.Text = string.Format("{0:#,##0.00}", double.Parse(sqlDr[0].ToString())); //#,##0
                                }
                                else
                                    txtBudjetAmnt.Text = "";

                                if (sqlDr[1].ToString() != "" && sqlDr[1].ToString() != "0.0000")
                                {
                                    txtEstimatedAmnt.Text = string.Format("{0:#,##0.00}", double.Parse(sqlDr[1].ToString())); //#,##0
                                }
                                else
                                    txtEstimatedAmnt.Text = "";

                            }
                        }
                    }
                }
                sqlCn.Close();
            }
        }
        private void FillProjectCostDetailsOfContractProcess()
        {
            string strQuery = "SELECT budgeted_cost,estimated_cost FROM PROJECTCOST WHERE proj_id = " + Convert.ToInt16(lblProjID.Text) + " and Stage_id = 4 ";
            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                    {
                        if (sqlDr.HasRows)
                        {
                            while (sqlDr.Read())
                            {
                                if (sqlDr[0].ToString() != "") //&& sqlDr[0].ToString() != "0.0000"
                                {
                                    txtCp_BudgetAmnt.Text = string.Format("{0:#,##0.00}", double.Parse(sqlDr[0].ToString()));
                                }
                                else
                                    txtCp_BudgetAmnt.Text = "";
                                if (sqlDr[1].ToString() != "")
                                {
                                    txtCp_EstimatedAmnt.Text = string.Format("{0:#,##0.00}", double.Parse(sqlDr[1].ToString()));
                                }
                                else
                                    txtCp_EstimatedAmnt.Text = "";
                            }
                        }
                    }
                }
                sqlCn.Close();
            }
        }
        private void FillProjectCostDetailsOfPostContract()
        {
            string strQuery = "SELECT budgeted_cost,estimated_cost FROM PROJECTCOST WHERE proj_id = " + Convert.ToInt16(lblProjID.Text) + " and Stage_id = 4";
            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                    {
                        if (sqlDr.HasRows)
                        {
                            while (sqlDr.Read())
                            {
                                if (sqlDr[0].ToString() != "")
                                {
                                    txtPC_BudjetAmnt.Text = string.Format("{0:#,##0.00}", double.Parse(sqlDr[0].ToString()));
                                }
                                else
                                    txtPC_BudjetAmnt.Text = "";
                                if (sqlDr[1].ToString() != "")
                                {
                                    txtPC_EstimatedAmnt.Text = string.Format("{0:#,##0.00}", double.Parse(sqlDr[1].ToString()));
                                }
                                else
                                    txtPC_EstimatedAmnt.Text = "";
                            }
                        }
                    }
                }
                sqlCn.Close();
            }
        }
        private void FillProjectCostDetailsOfTenderStage()
        {
            string strQuery = "SELECT tender_bond,doc_fee FROM PROJECTCOST WHERE proj_id = " + Convert.ToInt16(lblProjID.Text) + " and Stage_id = 4";
            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                    {
                        if (sqlDr.HasRows)
                        {
                            while (sqlDr.Read())
                            {
                                if (sqlDr[0].ToString() != "")
                                {
                                    txtTenderBond.Text = string.Format("{0:#,##0.00}", double.Parse((sqlDr[0]).ToString()));
                                }
                                if (sqlDr[1].ToString() != "")
                                {
                                    txtDocumentFee.Text = string.Format("{0:#,##0.00}", double.Parse((sqlDr[1]).ToString())); //Convert.ToDouble(sqlDr[1]).ToString();
                                }
                            }
                        }
                    }
                }
                sqlCn.Close();
            }
        }
        private Boolean FillTenderEvaluationInfo(ref int dateiDofTEA)
        {
            Boolean statusTEAChk = false;
            string strQuery = "SELECT eval_tender_opening,eval_tender_doc_receive_from_cd, eval_tech_sent, eval_tech_receive, eval_com_sent, " +
            " eval_com_receive, eval_tender_award_approval,tender_validity_ext1,tender_validity_ext2,tenderbond_validity_ext1,tenderbond_validity_ext2,date_id, proj_id, stage_id,eval_no_of_meetings,remarks,TPWD,FPWD " +
            "FROM TenderDatesInfo WHERE (proj_id = " + Convert.ToInt16(lblProjID.Text) + ") AND (stage_id = 3)";

            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                    {

                        if (sqlDr.HasRows)
                        {
                            statusTEAChk = true;
                            while (sqlDr.Read())
                            {
                                if (sqlDr[3].ToString() != "")
                                {
                                    DateTime dt_EA_daterec = Convert.ToDateTime(sqlDr[3].ToString());
                                    msk_dtpEA_daterec.Text = dt_EA_daterec.ToString("dd/MMM/yyyy");
                                }
                                if (sqlDr[5].ToString() != "")
                                {
                                    DateTime dt_EA_daterecFin = Convert.ToDateTime(sqlDr[5].ToString());
                                    msk_dtpEA_daterecFin.Text = dt_EA_daterecFin.ToString("dd/MMM/yyyy");
                                }
                                if (sqlDr[2].ToString() != "")
                                {
                                    DateTime dt_EA_datesent = Convert.ToDateTime(sqlDr[2].ToString());
                                    msk_dtpEA_datesent.Text = dt_EA_datesent.ToString("dd/MMM/yyyy");
                                }
                                if (sqlDr[4].ToString() != "")
                                {
                                    DateTime dt_EA_datesentfin = Convert.ToDateTime(sqlDr[4].ToString());
                                    msk_dtpEA_datesentfin.Text = dt_EA_datesentfin.ToString("dd/MMM/yyyy");
                                }
                                if (sqlDr[1].ToString() != "")
                                {
                                    DateTime dt_EA_recfromcd = Convert.ToDateTime(sqlDr[1].ToString());
                                    msk_dtpEA_recfromcd.Text = dt_EA_recfromcd.ToString("dd/MMM/yyyy");
                                }
                                if (sqlDr[0].ToString() != "")
                                {
                                    DateTime dt_EA_reqdate = Convert.ToDateTime(sqlDr[0].ToString());
                                    msk_dtpEA_reqdate.Text = dt_EA_reqdate.ToString("dd/MMM/yyyy");
                                }
                                if (sqlDr[6].ToString() != "")
                                {
                                    DateTime dt_EA_apprDate = Convert.ToDateTime(sqlDr[6].ToString());
                                    msk_dtpEA_apprDate.Text = dt_EA_apprDate.ToString("dd/MMM/yyyy");
                                }
                                if (isCpContractorSign == false)
                                {
                                    if (sqlDr[7].ToString() != "")
                                    {
                                        DateTime dt_TV_FEdate = Convert.ToDateTime(sqlDr[7].ToString());
                                        msk_dtpTV_FEdate.Text = dt_TV_FEdate.ToString("dd/MMM/yyyy");
                                    }
                                    if (sqlDr[8].ToString() != "")
                                    {
                                        DateTime dt_TV_SEdate = Convert.ToDateTime(sqlDr[8].ToString());
                                        msk_dtpTV_SEdate.Text = dt_TV_SEdate.ToString("dd/MMM/yyyy");
                                    }
                                    if (sqlDr[9].ToString() != "")
                                    {
                                        DateTime dt_TBV_FEdate = Convert.ToDateTime(sqlDr[9].ToString());
                                        msk_dtpTBV_FEdate.Text = dt_TBV_FEdate.ToString("dd/MMM/yyyy");
                                    }
                                    if (sqlDr[10].ToString() != "")
                                    {
                                        DateTime dt_TBV_SEdate = Convert.ToDateTime(sqlDr[10].ToString());
                                        msk_dtpTBV_SEdate.Text = dt_TBV_SEdate.ToString("dd/MMM/yyyy");
                                    }
                                }
                                else
                                {
                                    msk_dtpTV_FEdate.Text = "";
                                    msk_dtpTV_SEdate.Text = "";
                                    msk_dtpTBV_FEdate.Text = "";
                                    msk_dtpTBV_SEdate.Text = "";
                                    txtTV_exipre.Text = "";
                                    txtTBV_exipre.Text = "";
                                }
                                txtEA_Noofmeetings.Text = sqlDr[14].ToString();

                                txtTE_remarks.Text = sqlDr[15].ToString();

                                txtTechEvalProposedWorkDays.Text = sqlDr[16].ToString();
                                txtFinEvalProposedWorkDays.Text = sqlDr[17].ToString();

                                dateiDofTEA = Convert.ToInt16(sqlDr[11].ToString());
                            }
                        }
                    }
                }
                sqlCn.Close();
            }
            return statusTEAChk;
        }
        private void ProjectStages_Paint(object sender, PaintEventArgs e)
        {
            tabControl1.DrawMode = TabDrawMode.OwnerDrawFixed;
             
        }
        private void tabControl1_DrawItem(object sender, DrawItemEventArgs e)
        {
            Graphics g = e.Graphics;
            Brush _TextBrush;

            TabPage _TabPage = tabControl1.TabPages[e.Index];
            Rectangle _TabBounds = tabControl1.GetTabRect(e.Index);
            if (e.State == DrawItemState.Selected)
            {
                _TextBrush = new SolidBrush(Color.Maroon);
                g.FillRectangle(Brushes.White, e.Bounds);
            }
            else
            {
                _TextBrush = new System.Drawing.SolidBrush(e.ForeColor);
            }

            Font _TabFont = new Font(e.Font.FontFamily, (float)7, FontStyle.Bold);   //, GraphicsUnit.Pixel
            StringFormat _StringFlags = new StringFormat();
            _StringFlags.Alignment = StringAlignment.Center;
            _StringFlags.LineAlignment = StringAlignment.Center;

            g.DrawString(tabControl1.TabPages[e.Index].Text, _TabFont, _TextBrush, _TabBounds, new StringFormat(_StringFlags));

            //PopulatingVariousStagesTabControlsOfProject();

        }
        private void button13_Click(object sender, EventArgs e)
        {
            Boolean statusChk = false;
            if (dtpRecievedOn.Checked == false)
            {
                MessageBox.Show("Please select Received On Date");
                return;
            }
            if (cmbPurpose.SelectedIndex == -1)
            {
                MessageBox.Show("Please Select Document Purpose");
                return;
            }

            SqlConnection sqlConn = new SqlConnection(connStr);
            int dateID = 0;
            sqlConn.Open();
            try
            {
                string sqlQuery = "SELECT MAX(date_id) from TenderDatesInfo";
                SqlCommand sqlCommand = new SqlCommand(sqlQuery, sqlConn);
                dateID = Convert.ToInt16(sqlCommand.ExecuteScalar());
                dateID = dateID + 1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlConn.Close();
            }
            try
            {
                sqlConn.Open();
                string insertQuery = "INSERT INTO TenderDatesInfo(date_id,proj_id, stage_id, ptd_receive_on, ptd_purpose, ptd_assign_qs," +
                " ptd_sent_for_rev, ptd_qs_working_status, ptd_tendec_doc_cur_status,ptd_forwarded_to_dep, remarks) VALUES " +
                " (" + dateID + "," + Convert.ToInt16(lblProjID.Text) + "," + 1 + ",'" + dtpRecievedOn.Value + "','" + cmbPurpose.SelectedItem.ToString() + "'," +
                " '" + cmbAssignedQs.SelectedItem.ToString() + "','" + dtpReview.Value + "','" + cmbQsWorkingStatus.SelectedItem.ToString() + "'," +
                " '" + cmbTenderDocStatus.SelectedItem.ToString() + "','" + dtpFrwdDept.Value + "','" + txtRemarks.Text + "')";

                SqlCommand sqlCommand = new SqlCommand(insertQuery, sqlConn);
                sqlCommand.ExecuteNonQuery();
                MessageBox.Show("Tender Document Preparation Data Added Successfully!");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlConn.Close();
            }
            dtpRecievedOn.Checked = false;
            dtpReview.Checked = false;
            dtpFrwdDept.Checked = false;

            cmbAssignedQs.SelectedIndex = -1;
            cmbPurpose.SelectedIndex = -1;
            cmbQsWorkingStatus.SelectedIndex = -1;
            cmbTenderDocStatus.SelectedIndex = -1;
            txtRemarks.Text = "";

            if (cmbQsWorkingStatus.Text == "Completed" & cmbTenderDocStatus.Text == "Approved")
            {
                statusChk = true;
            }
            if (statusChk == true)
            {
                try
                {
                    using (sqlConn = new SqlConnection(connStr))
                    {
                        using (SqlCommand cmd = new SqlCommand())
                        {
                            sqlConn.Open();
                            cmd.Connection = sqlConn;

                            cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]= 2 Where proj_id=@projId";
                            cmd.Parameters.AddWithValue("@projId", Convert.ToInt16(lblProjID.Text));
                            //cmd.Parameters.AddWithValue("@tenderSatus", dtp_tsRecOn.Value.ToString("dd/MMM/yyyy"));

                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            GridViewRefresh_PTD();
        }
        private void UpdateTenderStageInfo(int _upddateID_Ts)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        cmd.CommandText = @"UPDATE TenderDatesInfo SET " +
                        " ts_receive_on =@receiveOn,ts_issue_handling = @issueHandling," +
                        " ts_return_to_dept=@returnDept,ts_receive_from_dept = @receivedFromDept,ts_pr_advertise =@advertisement,ts_tender_invitation = @invitation, " +
                        " ts_closing_s1 = @closingDate, ts_closing_s2 = @closingDate2,ts_modified_closing= @tsModifyDate,Remarks =@tsRemarks,Update_Date = @UpdateDate,Update_User = @UpdateUser Where date_id = @dateId " +
                        "and stage_id = 2 AND (ts_tender_issue IS NULL)";

                        cmd.Parameters.AddWithValue("@dateId", _upddateID_Ts);
                        //cmd.Parameters.AddWithValue("@projId", Convert.ToInt16(lblProjID.Text));

                        //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings                                                                       
                        if (msk_dtp_tsRecOn.Text != "")
                            cmd.Parameters.AddWithValue("@receiveOn", Convert.ToDateTime(msk_dtp_tsRecOn.Text));
                        else
                            cmd.Parameters.AddWithValue("@receiveOn", DBNull.Value);

                        if (cmb_tstenderHandle.SelectedIndex != -1 || cmb_tstenderHandle.Text != "")
                            cmd.Parameters.AddWithValue("@issueHandling", cmb_tstenderHandle.Text);
                        else
                            cmd.Parameters.AddWithValue("@issueHandling", DBNull.Value);

                        //Modified by Varun on 13/02/2014
                        if (msk_dtp_tsReturnDept.Text != "")
                            cmd.Parameters.AddWithValue("@returnDept", Convert.ToDateTime(msk_dtp_tsReturnDept.Text));
                        else
                            cmd.Parameters.AddWithValue("@returnDept", DBNull.Value);

                        //Modified by Varun on 13/02/2014
                        if (msk_dtp_tsRecFromDept.Text != "")
                            cmd.Parameters.AddWithValue("@receivedFromDept", Convert.ToDateTime(msk_dtp_tsRecFromDept.Text));
                        else
                            cmd.Parameters.AddWithValue("@receivedFromDept", DBNull.Value);

                        //Modified by Varun on 13/02/2014
                        if (msk_dtp_tsAdvertisement.Text != "")
                            cmd.Parameters.AddWithValue("@advertisement", Convert.ToDateTime(msk_dtp_tsAdvertisement.Text));
                        else
                            cmd.Parameters.AddWithValue("@advertisement", DBNull.Value);

                        //Modified by Varun on 13/02/2014
                        if (msk_dtp_tsInvitation.Text != "")
                            cmd.Parameters.AddWithValue("@invitation", Convert.ToDateTime(msk_dtp_tsInvitation.Text));
                        else
                            cmd.Parameters.AddWithValue("@invitation", DBNull.Value);

                        //Modified by Varun on 13/02/2014
                        if (msk_dtp_tsStage1.Text != "")
                            cmd.Parameters.AddWithValue("@closingDate", Convert.ToDateTime(msk_dtp_tsStage1.Text));
                        else
                            cmd.Parameters.AddWithValue("@closingDate", DBNull.Value);

                        //Modified by Varun on 13/02/2014
                        if (msk_dtp_tsStage2.Text != "")
                            cmd.Parameters.AddWithValue("@closingDate2", Convert.ToDateTime(msk_dtp_tsStage2.Text));
                        else
                            cmd.Parameters.AddWithValue("@closingDate2", DBNull.Value);

                        //Modified by Varun on 13/02/2014
                        if (msk_dtp_tsModifiedDate.Text != "")
                            cmd.Parameters.AddWithValue("@tsModifyDate", Convert.ToDateTime(msk_dtp_tsModifiedDate.Text));
                        else
                            cmd.Parameters.AddWithValue("@tsModifyDate", DBNull.Value);

                        cmd.Parameters.AddWithValue("@tsRemarks", txt_tsRemarks.Text);


                        cmd.Parameters.AddWithValue("@UpdateDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@UpdateUser", _userName);

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();

                        MessageBox.Show("Data Updated Successfully");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            if (msk_dtp_tsModifiedDate.Text != "")
            {
                if (Check_ModifiedDateExist() == false)
                {
                    try
                    {
                        using (SqlConnection sqlConn = new SqlConnection(connStr))
                        {
                            using (SqlCommand cmd = new SqlCommand())
                            {
                                sqlConn.Open();
                                cmd.Connection = sqlConn;

                                cmd.CommandText = "INSERT INTO TNDR_MODIFIEDDATES(proj_id, stage_id, Tndr_ModifiedDate,Create_User,Create_Date) VALUES(@prjID,@stageID,@modifiedOn,@CreateUser,@CreateDate)";

                                cmd.Parameters.AddWithValue("@stageID", 2);
                                cmd.Parameters.AddWithValue("@prjID", Convert.ToInt16(lblProjID.Text));

                                if (msk_dtp_tsRecOn.Text != "")
                                    cmd.Parameters.AddWithValue("@modifiedOn", msk_dtp_tsModifiedDate.Text);
                                else
                                    cmd.Parameters.AddWithValue("@modifiedOn", DBNull.Value);

                                cmd.Parameters.AddWithValue("@CreateDate", System.DateTime.Now);
                                cmd.Parameters.AddWithValue("@CreateUser", _userName);

                                int exUpdated = cmd.ExecuteNonQuery();
                                cmd.Parameters.Clear();

                                //MessageBox.Show("Data Updated Successfully");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error occurred while Updating the UPDATE TNDR_MODIFIEDDATES records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }


            //Update Tender Handling By in Projects Table
            if (cmb_tstenderHandle.Text != "")
                clsStaff.update_TenderHandled(cmb_tstenderHandle.Text, Convert.ToInt16(lblProjID.Text));


            //if (!Convert.ToDateTime(mdfExistDate).ToString("dd/MMM/yyyy").Equals(msk_dtp_tsModifiedDate.Text))
            //{
            //    MessageBox.Show("Alert message for modified date " + " existed Date was " + mdfExistDate + " New Modified Date is  " + msk_dtp_tsModifiedDate.Text + "");
            //}
        }

        private Boolean Check_ModifiedDateExist()
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    sqlConn.Open();
                    SqlCommand sqlCom = new SqlCommand("SELECT Tndr_ModifiedDate FROM Tndr_ModifiedDates Where Tndr_ModifiedDate = '" + Convert.ToDateTime(msk_dtp_tsModifiedDate.Text).ToString("dd/MMM/yyyy") + "'", sqlConn);
                    using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                    {
                        if (sqlReader.HasRows)
                        {
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }
        private Boolean ValidateDatesOfTndrStage()
        {
            Boolean dateFormat = true;
            dateFormat = ValidateDate(msk_dtp_tsRecOn);
            dateFormat = ValidateDate(msk_dtp_tsReturnDept);
            dateFormat = ValidateDate(msk_dtp_tsRecFromDept);
            dateFormat = ValidateDate(msk_dtp_tsAdvertisement);
            dateFormat = ValidateDate(msk_dtp_tsInvitation);
            dateFormat = ValidateDate(msk_dtp_tsStage1);
            dateFormat = ValidateDate(msk_dtp_tsStage2);
            dateFormat = ValidateDate(msk_dtp_tsModifiedDate);
            return dateFormat;
        }
        private void InsertTenderStageInfo(int _dateID)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        int stgeId = 0;
                        stgeId = 2;

                        cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,ts_receive_on,ts_issue_handling,ts_return_to_dept, " +
                        " ts_receive_from_dept,ts_pr_advertise,ts_tender_invitation,ts_closing_s1,ts_closing_s2,ts_modified_closing,Create_Date,Create_User) VALUES " +
                        " (@dateId,@projId,@stageId,@receiveOn,@issueHandling,@returnDept,@receivedFromDept,@advertisement,@invitation,@closingDate,@closingDate2,@tsModifyDate,@CreateDate,@CreateUser)";
                        // ,ts_modified_closing,ts_tender_issue
                        cmd.Parameters.AddWithValue("@stageId", 2);
                        cmd.Parameters.AddWithValue("@projId", Convert.ToInt16(lblProjID.Text));
                        cmd.Parameters.AddWithValue("@receiveOn", msk_dtp_tsRecOn.Text);
                        if (cmb_tstenderHandle.SelectedIndex != -1 || cmb_tstenderHandle.Text != "")
                            cmd.Parameters.AddWithValue("@issueHandling", cmb_tstenderHandle.Text);
                        else
                            cmd.Parameters.AddWithValue("@issueHandling", DBNull.Value);

                        //DateTime dtNull;
                        //DateTime.TryParseExact(dtp_tsReturnDept.Value.ToString(), "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out dtNull);

                        if (dtp_tsReturnDept.Checked == true)
                            cmd.Parameters.AddWithValue("@returnDept", msk_dtp_tsReturnDept.Text);
                        else
                            cmd.Parameters.AddWithValue("@returnDept", DBNull.Value);

                        if (dtp_tsRecFromDept.Checked == true)
                            cmd.Parameters.AddWithValue("@receivedFromDept", msk_dtp_tsRecFromDept.Text);
                        else
                            cmd.Parameters.AddWithValue("@receivedFromDept", DBNull.Value);

                        if (dtp_tsAdvertisement.Checked == true)
                            cmd.Parameters.AddWithValue("@advertisement", msk_dtp_tsAdvertisement.Text);
                        else
                            cmd.Parameters.AddWithValue("@advertisement", DBNull.Value);

                        if (dtp_tsInvitation.Checked == true)
                            cmd.Parameters.AddWithValue("@invitation", msk_dtp_tsInvitation.Text);
                        else
                            cmd.Parameters.AddWithValue("@invitation", DBNull.Value);

                        if (dtp_tsStage1.Checked == true)
                            cmd.Parameters.AddWithValue("@closingDate", msk_dtp_tsStage1.Text);
                        else
                            cmd.Parameters.AddWithValue("@closingDate", DBNull.Value);

                        if (dtp_tsStage2.Checked == true)
                            cmd.Parameters.AddWithValue("@closingDate2", msk_dtp_tsStage2.Text);
                        else
                            cmd.Parameters.AddWithValue("@closingDate2", DBNull.Value);

                        if (dtp_tsModifiedDate.Checked == true)
                            cmd.Parameters.AddWithValue("@tsModifyDate", msk_dtp_tsModifiedDate.Text);
                        else
                            cmd.Parameters.AddWithValue("@tsModifyDate", DBNull.Value);


                        //cmd.Parameters.AddWithValue("@advertisement", dtp_tsRecOn.Value.ToString("dd/MMM/yyyy"));     //ts_modified_closing
                        //cmd.Parameters.AddWithValue("@invitation", dtp_tsRecOn.Value.ToString("dd/MMM/yyyy"));        //remarks
                        //cmd.Parameters.AddWithValue("@closingDate", dtp_tsRecOn.Value.ToString("dd/MMM/yyyy"));
                        //cmd.Parameters.AddWithValue("@closingDate2", dtp_tsRecOn.Value.ToString("dd/MMM/yyyy")); 

                        cmd.Parameters.AddWithValue("@CreateDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@CreateUser", _userName);

                        cmd.Parameters.AddWithValue("@dateId", _dateID);

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();

                        MessageBox.Show("Entered Data Saved SuccessFully");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }


            // Update Tender Handling By in Projects Table
            if (cmb_tstenderHandle.Text != "")
                clsStaff.update_TenderHandled(cmb_tstenderHandle.Text, Convert.ToInt16(lblProjID.Text));

        }
        private Boolean CheckDataExistForTenderStage(ref int _updDateID, ref string receivedDate)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    sqlConn.Open();
                    sqlCom = new SqlCommand("SELECT date_id,ts_receive_on FROM TenderDatesInfo Where Proj_id = " + _projID + " and Stage_id = 2 And ts_tender_issue IS NULL", sqlConn);
                    using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                    {
                        if (sqlReader.HasRows)
                        {
                            while (sqlReader.Read())
                            {
                                _updDateID = Convert.ToInt16(sqlReader[0]);
                                receivedDate = sqlReader[1].ToString();
                            }
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }
        private Boolean CheckDataExistForTenderEvaluation()
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    sqlConn.Open();
                    sqlCom = new SqlCommand("SELECT * FROM TenderDatesInfo Where Proj_id = " + _projID + " and Stage_id = 3", sqlConn);
                    using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                    {
                        if (sqlReader.HasRows)
                        {
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }
        private Boolean CheckDataExistForContractProcess()
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    sqlConn.Open();
                    sqlCom = new SqlCommand("SELECT * FROM TenderDatesInfo Where Proj_id = " + _projID + " and Stage_id = 4 and cp_tender_award != ''", sqlConn);
                    using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                    {
                        if (sqlReader.HasRows)
                        {
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }

        int dateID_Ts = 0;



        private void UpdateStatusForClosingDate()
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]= 2,[stage_id]= 2 Where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@projId", Convert.ToInt16(lblProjID.Text));
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void UpdateStatusFor_ReceivedDate()
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]= 2,[stage_id]= 2 Where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@projId", Convert.ToInt16(lblProjID.Text));
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void InsertTenderElevationData(int dateID)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        int stage_Id = 0;
                        stage_Id = 3;

                        cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,eval_tender_opening,eval_tender_doc_receive_from_cd, " +
                            " eval_tech_sent,eval_tech_receive,eval_com_sent,eval_com_receive,eval_tender_award_approval,eval_no_of_meetings,remarks,Create_Date,Create_User,TPWD,FPWD) " +
                            " VALUES(@dateId,@projId,@stageId,@evltendrReq,@fromCd,@senttoTech,@recfromtech,@sentFin,@recFin,@awardAppr,@NoOfMeetings,@TE_Remarks,@CreateDate,@CreateUser,@TPWD,@FPWD)";

                        //tender_validity_ext1  tender_validity_ext2  // tenderbond_validity_ext1   tenderbond_validity_ext2  //org_tender_validity  //org_tenderbond_validity  //org_tenderbond_to_expire
                        cmd.Parameters.AddWithValue("@projId", Convert.ToInt16(lblProjID.Text));
                        cmd.Parameters.AddWithValue("@stageId", stage_Id);

                        if (msk_dtp_tsRecFromDept.Text != "")
                            cmd.Parameters.AddWithValue("@receivedFromDept", msk_dtp_tsRecFromDept.Text);
                        else
                            cmd.Parameters.AddWithValue("@receivedFromDept", DBNull.Value);

                        if (msk_dtpEA_reqdate.Text != "")
                            cmd.Parameters.AddWithValue("@evltendrReq", msk_dtpEA_reqdate.Text);
                        else
                            cmd.Parameters.AddWithValue("@evltendrReq", DBNull.Value);

                        if (msk_dtpEA_recfromcd.Text != "")
                            cmd.Parameters.AddWithValue("@fromCd", msk_dtpEA_recfromcd.Text);
                        else
                            cmd.Parameters.AddWithValue("@fromCd", DBNull.Value);

                        if (msk_dtpEA_datesent.Text != "")
                            cmd.Parameters.AddWithValue("@senttoTech", msk_dtpEA_datesent.Text);
                        else
                            cmd.Parameters.AddWithValue("@senttoTech", DBNull.Value);

                        if (msk_dtpEA_daterec.Text != "")
                            cmd.Parameters.AddWithValue("@recfromtech", msk_dtpEA_daterec.Text);
                        else
                            cmd.Parameters.AddWithValue("@recfromtech", DBNull.Value);

                        if (msk_dtpEA_datesentfin.Text != "")
                            cmd.Parameters.AddWithValue("@sentFin", msk_dtpEA_datesentfin.Text);
                        else
                            cmd.Parameters.AddWithValue("@sentFin", DBNull.Value);

                        if (msk_dtpEA_daterecFin.Text != "")
                            cmd.Parameters.AddWithValue("@recFin", msk_dtpEA_daterecFin.Text);
                        else
                            cmd.Parameters.AddWithValue("@recFin", DBNull.Value);

                        if (msk_dtpEA_apprDate.Text != "")
                            cmd.Parameters.AddWithValue("@awardAppr", msk_dtpEA_apprDate.Text);
                        else
                            cmd.Parameters.AddWithValue("@awardAppr", DBNull.Value);

                        if (txtEA_Noofmeetings.Text == "")
                            cmd.Parameters.AddWithValue("@NoOfMeetings", 0);
                        else
                            cmd.Parameters.AddWithValue("@NoOfMeetings", Convert.ToInt16(txtEA_Noofmeetings.Text));

                        cmd.Parameters.AddWithValue("@TE_Remarks", txtTE_remarks.Text);

                        cmd.Parameters.AddWithValue("@dateId", dateID);  //NoOfMeetings

                        cmd.Parameters.AddWithValue("@CreateDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@CreateUser", _userName);

                        if (txtTechEvalProposedWorkDays.Text != "")
                            cmd.Parameters.AddWithValue("@TPWD", txtTechEvalProposedWorkDays.Text);
                        else
                            cmd.Parameters.AddWithValue("@TPWD", DBNull.Value);

                        if (txtFinEvalProposedWorkDays.Text != "")
                            cmd.Parameters.AddWithValue("@FPWD", txtFinEvalProposedWorkDays.Text);
                        else
                            cmd.Parameters.AddWithValue("@FPWD", DBNull.Value);

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        MessageBox.Show("Tender Evaluation & Award data added Succesfully");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Insert the TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void UpdateTenderElevationData()
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        cmd.CommandText = @"UPDATE TenderDatesInfo set Proj_Id=@projId,eval_tender_opening=@evltendrReq,eval_tender_doc_receive_from_cd=@fromCd,eval_tech_sent=@senttoTech,eval_tech_receive=@recfromtech," +
                        "eval_com_sent=@sentFin,eval_com_receive=@recFin,eval_tender_award_approval=@awardAppr,eval_no_of_meetings =@meetingCnt,remarks = @TE_Remarks,Update_Date = @UpdateDate,Update_User = @UpdateUser, " +
                        "TPWD=@TPWD,FPWD=@FPWD where date_id=@dateId";

                        //tender_validity_ext1 =@ValidityExt1,tender_validity_ext2 =@ValidityExt2,tenderbond_validity_ext1 =@BondValidityExt1,tenderbond_validity_ext2 =@BondValidityExt2,

                        cmd.Parameters.AddWithValue("@projId", Convert.ToInt16(lblProjID.Text));
                        if (msk_dtp_tsRecFromDept.Text != "")
                            cmd.Parameters.AddWithValue("@receivedFromDept", msk_dtp_tsRecFromDept.Text);
                        else
                            cmd.Parameters.AddWithValue("@receivedFromDept", DBNull.Value);

                        if (msk_dtpEA_reqdate.Text != "")
                            cmd.Parameters.AddWithValue("@evltendrReq", msk_dtpEA_reqdate.Text);
                        else
                            cmd.Parameters.AddWithValue("@evltendrReq", DBNull.Value);

                        if (msk_dtpEA_recfromcd.Text != "")
                            cmd.Parameters.AddWithValue("@fromCd", msk_dtpEA_recfromcd.Text);
                        else
                            cmd.Parameters.AddWithValue("@fromCd", DBNull.Value);

                        if (msk_dtpEA_datesent.Text != "")
                            cmd.Parameters.AddWithValue("@senttoTech", msk_dtpEA_datesent.Text);
                        else
                            cmd.Parameters.AddWithValue("@senttoTech", DBNull.Value);

                        if (msk_dtpEA_daterec.Text != "")
                            cmd.Parameters.AddWithValue("@recfromtech", msk_dtpEA_daterec.Text);
                        else
                            cmd.Parameters.AddWithValue("@recfromtech", DBNull.Value);

                        if (msk_dtpEA_datesentfin.Text != "")
                            cmd.Parameters.AddWithValue("@sentFin", msk_dtpEA_datesentfin.Text);
                        else
                            cmd.Parameters.AddWithValue("@sentFin", DBNull.Value);

                        if (msk_dtpEA_daterecFin.Text != "")
                            cmd.Parameters.AddWithValue("@recFin", msk_dtpEA_daterecFin.Text);
                        else
                            cmd.Parameters.AddWithValue("@recFin", DBNull.Value);

                        if (msk_dtpEA_apprDate.Text != "")
                            cmd.Parameters.AddWithValue("@awardAppr", msk_dtpEA_apprDate.Text);
                        else
                            cmd.Parameters.AddWithValue("@awardAppr", DBNull.Value);

                        if (txtEA_Noofmeetings.Text == "")
                            cmd.Parameters.AddWithValue("@meetingCnt", 0);
                        else
                            cmd.Parameters.AddWithValue("@meetingCnt", Convert.ToInt16(txtEA_Noofmeetings.Text));

                        cmd.Parameters.AddWithValue("@TE_Remarks", txtTE_remarks.Text);

                        cmd.Parameters.AddWithValue("@dateId", dateID_TEA);

                        cmd.Parameters.AddWithValue("@UpdateDate ", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@UpdateUser", _userName);

                        if (txtTechEvalProposedWorkDays.Text != "")
                            cmd.Parameters.AddWithValue("@TPWD", txtTechEvalProposedWorkDays.Text);
                        else
                            cmd.Parameters.AddWithValue("@TPWD", DBNull.Value);

                        if (txtFinEvalProposedWorkDays.Text != "")
                            cmd.Parameters.AddWithValue("@FPWD", txtFinEvalProposedWorkDays.Text);
                        else
                            cmd.Parameters.AddWithValue("@FPWD", DBNull.Value);

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        MessageBox.Show("Tender Evaluation & Award data updated Succesfully");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE DATES records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void dateTimePicker39_ValueChanged(object sender, EventArgs e)
        {
            // dtpTBV_OrgDate.Text = dtpEA_stage2.Value.AddDays(90).ToString();
        }

        string _tndrTypeName = string.Empty;
        string _userDept = string.Empty;
        string _AffairsName = string.Empty;
        private void btnAssignTender_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Contains("41"))    //      * Assign Tender No.
            {
                MessageBox.Show("You have no privilege to assign Tender No. Please Contact system administrator.");
                return;
            }

            UserList_ForAlert(1);

            if (userListColl.Count == 0)
            {
                MessageBox.Show("Information for Tender No.assignment is required to be sent to a user who handles " + _cmtName + " projects, " +
                  " but there is no identified user to receive the email. Please contact system administrator for information.");
                return;
            }

            DialogResult dlgResult = DialogResult.No;
            dlgResult = MessageBox.Show("Do you want to create new Tender Number. ", "Assign Tender No.", MessageBoxButtons.YesNo);

            if (dlgResult.ToString() == "Yes")
            {

                string _prjCreaedOn = string.Empty;

                CommonClass comCls = new CommonClass(_userName);

                string strTenderNo = comCls.AssignTenderNo(mUserRightsColl, _projID, _tndrType, txtProjCode.Text, txtproj.Text, 'A', null, null, ref _tndrTypeName, ref _userDept, ref _prjCreaedOn, ref _AffairsName);
                // Added by Varun on 10 Feb 2014 for checking the exception occurence and to stop sending email alerts if there is a problem in assigning the Tender No.
                if (!strTenderNo.Contains("Exception"))
                {
                    if (strTenderNo != "")
                    {
                        btnAssignTender.Visible = false;
                        lblTenderNo.Visible = true;
                        txtTenderNo.Text = strTenderNo;
                        //txtTenderNo.Enabled = false;
                    }


                    //string DisplayName = ""; string Email = ""; string Department = ""; string Title = "";                         
                    // AlertOnNewTenderNo(tenderNo, _projID.ToString(), "New Project");

                    string fromUser = null;
                    fromUser = comCls.getUserEmailID(_userName);

                    try
                    {
                        //if (GetUserInformation4rmActiveDirectory(fromUser, "ashghal.gov.qa", ref user_DisplayName, ref user_Email, ref  user_Department, ref user_Title) == true)
                        //{
                        foreach (string strname in userListColl)
                        {
                            // if (GetUserInformation4rmActiveDirectory(strname, "ashghal.gov.qa", ref DisplayName, ref Email, ref  Department, ref Title) == true)

                            MailMessage mailMessage = new MailMessage();
                            //mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["MailFrom"].ToString());

                            mailMessage.From = new MailAddress(fromUser);
                            mailMessage.To.Add(new MailAddress(strname));
                            mailMessage.Subject = "TCMS Alert: Tender No. " + strTenderNo + " was assigned";
                            mailMessage.IsBodyHtml = true;


                            mailMessage.Body = "<html><body><i style='font-family:Calibri; font-size:15'>Dear Sir/Madam,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Tender & Contract Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>" +
                            "Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'> New Tender No. " + strTenderNo + "</i><i style='font-family:Calibri; font-size:15'> has created and the details are as follows:-</i><br /><br />" +
                            "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:Maroon;color:White;font-family:Calibri;font-size:18;font-weight:bold'>TENDER NO: " + strTenderNo + "</td>" +
                            "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Code</i></td><td style='font-family:Calibri;font-size:15'>" + _prjCode + "</td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Title</i></td><td style='font-family:Calibri;font-size:15'>" + proj_Title + "</td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Type of Tender</i></td><td style='font-family:Calibri;font-size:15'>" + _tndrTypeName + "</td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Tender Committee</i></td><td style='font-family:Calibri;font-size:15'>" + _cmtName + "</td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Financial Year</i></td><td style='font-family:Calibri;font-size:15'>" + _fiscalYear + "</td></tr>" +       //+ "(" + _AffairsName + ")
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>User Dept.</i></td><td style='font-family:Calibri;font-size:15'>" + _userDept + " / " + _AffairsName + " </td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                            "</table><br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>TCMS Team</div></body></html>";

                            //mailMessage.Body = "This is an automated alert from TCMS." + "\n" + "\n" + "Project Code     : " + _prjCode + "\n" + "Project Title    : " + proj_Title + "\n" +   "Type of Tender   : " + _tndrTypeName + " " +
                            // "\n"  + "Tender Committee : " + _cmtName + " " +
                            // "\n" +  "User Department  : " + _userDept + " " +
                            // "\n" +  "Date Created     : " + System.DateTime.Now.ToString() + " " +
                            //" \n" +  "\n" + "Tender No. " + strTenderNo + " was assigned to above project.";

                            SmtpClient client = new SmtpClient();
                            client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                            client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                            client.Send(mailMessage);

                        }
                        //}
                        MessageBox.Show("Tender Alert E-mail send to the users", "Create Tender Number");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Exception occurred while sending the email notification to Tender Committee, Please inform them Personally", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
            }
        }
        IList<string> userListColl = new List<string>();
        private void UserList_ForAlert(int categryID)
        {
            userListColl.Clear();
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();

                        string sqlQuery = "SELECT DISTINCT EmailAlertRecipients.user_id, USERS.email_address, USERS.user_name, EmailAlertCategory.AlertCategory, EmailAlertRecipients.alert_cat_id, " +
                                             " Committee.committee_short_name FROM EmailAlertCategory INNER JOIN EmailAlertRecipients ON EmailAlertCategory.alert_cat_id = EmailAlertRecipients.alert_cat_id INNER JOIN " +
                                             " USERS ON EmailAlertRecipients.user_id = USERS.user_id INNER JOIN Committee ON EmailAlertRecipients.committee_id = Committee.committee_id " +
                                             " WHERE (EmailAlertRecipients.alert_cat_id = " + categryID + ") AND (USERS.email_address <> N'') AND (Committee.committee_short_name ='" + _cmtName + "')";

                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                string strData = dr[1].ToString();
                                if (!userListColl.Contains(strData))
                                    userListColl.Add(strData);
                            }
                            dr.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while retrieving the email ids of a particular committee.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //UserList();
        //string DisplayName = ""; string Email = ""; string Department = ""; string Title = "";

        //string user_DisplayName = ""; string user_Email = ""; string user_Department = ""; string user_Title = "";
        //if (GetUserInformation4rmActiveDirectory(_userName, "ashghal.gov.qa", ref user_DisplayName, ref user_Email, ref  user_Department, ref user_Title) == true)
        //{
        //    foreach (string strname in userColl)
        //    {
        //        if (GetUserInformation4rmActiveDirectory(strname, "ashghal.gov.qa", ref DisplayName, ref Email, ref  Department, ref Title) == true)
        //        {
        //            string mailSub = "Assigned New tenderNo " + tenderNo;
        //            string bodySub = " Mr " + user_DisplayName + " From " + user_Department + " Department " + " Assigned New TenderNo As-- " + tenderNo + " For ProjectCode " + txtProjCode.Text;
        //            string attBody = "TenderNo Created";
        //            string attpath = "C:\\Temp\\SrcFile.txt";
        //            sendEMailThroughOUTLOOK(Email, mailSub, bodySub, attBody, attpath);
        //        }
        //    }
        //}


        IList<string> userColl = new List<string>();
        private void UserList()
        {
            userColl.Clear();
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        string sqlQuery = "SELECT USER_ID,USER_NAME FROM USERS Where User_ID in (14,15,16)";
                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                string strData = dr[1].ToString();
                                userColl.Add(strData);
                            }
                            dr.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while retrieving the usernames.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public Boolean GetUserInformation4rmActiveDirectory(string userId, string Domain, ref string DisplayName, ref string Email, ref string Department, ref string Title)
        {
            Boolean chkUserExist = false;
            try
            {
                string filter = string.Format("(&(ObjectClass={0})(sAMAccountName={1}))", "person", userId);

                DirectoryEntry activeDirectoryaddress = new DirectoryEntry("LDAP://" + Domain, null, null, AuthenticationTypes.Secure);
                DirectorySearcher searcher = new DirectorySearcher(activeDirectoryaddress);
                searcher.SearchScope = SearchScope.Subtree;

                searcher.Filter = filter;
                SearchResult result = searcher.FindOne();
                DirectoryEntry directoryEntry = result.GetDirectoryEntry();

                DisplayName = directoryEntry.Properties["displayName"][0].ToString();
                Email = directoryEntry.Properties["mail"][0].ToString();
                Department = directoryEntry.Properties["department"][0].ToString();
                Title = directoryEntry.Properties["title"][0].ToString();

                if (Email != null)
                {
                    chkUserExist = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Sorry unable to get your mail id from outlook", "ASHGHAL - EBSD");
            }

            return chkUserExist;
        }
        public void sendEMailThroughOUTLOOK(string emailAddr, string mailSubject, string mailBody, string attachmentDisplayName, string attachmentpath)
        {
            try
            {
                // Create the Outlook application.
                Microsoft.Office.Interop.Outlook.Application oApp = new Microsoft.Office.Interop.Outlook.Application();
                // Create a new mail item.
                Microsoft.Office.Interop.Outlook.MailItem oMsg = (Microsoft.Office.Interop.Outlook.MailItem)oApp.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                // Set HTMLBody. 
                //add the body of the email
                oMsg.HTMLBody = mailBody;
                //Add an attachment.
                String sDisplayName = attachmentDisplayName;
                int iPosition = (int)oMsg.Body.Length + 1;
                int iAttachType = (int)Microsoft.Office.Interop.Outlook.OlAttachmentType.olByValue;
                //now attached the file
                Microsoft.Office.Interop.Outlook.Attachment oAttach = oMsg.Attachments.Add(attachmentpath, iAttachType, iPosition, sDisplayName);  //"C:\\Temp\\SrcFile.txt"
                //Subject line
                oMsg.Subject = mailSubject;
                // Add a recipient.
                Microsoft.Office.Interop.Outlook.Recipients oRecips = (Microsoft.Office.Interop.Outlook.Recipients)oMsg.Recipients;
                // Change the recipient in the next line if necessary.
                Microsoft.Office.Interop.Outlook.Recipient oRecip = (Microsoft.Office.Interop.Outlook.Recipient)oRecips.Add(emailAddr);
                // Microsoft.Office.Interop.Outlook.Recipient oRecip = (Microsoft.Office.Interop.Outlook.Recipient)oRecips.Add("svadakapuram@ashghal.gov.qa");

                oRecip.Resolve();
                // Send.
                oMsg.Send();
                // Clean up.
                oRecip = null;
                oRecips = null;
                oMsg = null;
                oApp = null;
            }//end of try block
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }//end of catch
        }
        private void button15_Click(object sender, EventArgs e)
        {
            int dateId = MaxDateID();
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        int stage_Id = 0;
                        stage_Id = 4;

                        //  cmd.CommandText = @"INSERT INTO DATES(date_id,proj_id,stage_id,cp_tender_award,cp_received_of_doc,cp_request_start_date,cp_start_date_receive,cp_notice_contractor_to_sign,cp_due_date_pb,cp_sent_dep_sign,cp_receive_dep_sent_prsd,cp_sent_fd_commit,cp_receive_fd_commit,cp_distribution) VALUES(@dateId,@projId,@stageId,@evltendrReq,@fromCd,@senttoTech,@recfromtech,@sentFin,@recFin,@awardAppr)";

                        cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,cp_tender_award,cp_received_of_doc,cp_request_start_date,cp_start_date_receive,cp_notice_contractor_to_sign,cp_due_date_pb) VALUES(@dateId,@projId,@stageId,@cptenderaward,@cpreceivedofdoc,@cprequeststartdate,@cpstartdatereceive,@cpnotice_contractortosign,@cpduedatepb)";

                        cmd.Parameters.AddWithValue("@projId", Convert.ToInt16(lblProjID.Text));
                        cmd.Parameters.AddWithValue("@stageId", stage_Id);
                        cmd.Parameters.AddWithValue("@cptenderaward", dtpEA_reqdate.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@cpreceivedofdoc", dtpEA_recfromcd.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@cprequeststartdate", dtpEA_datesent.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@cpstartdatereceive", dtpEA_daterec.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@cpnotice_contractortosign", dtpEA_datesentfin.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@cpduedatepb", dtpEA_daterecFin.Value.ToString("dd/MMM/yyyy"));

                        cmd.Parameters.AddWithValue("@cp_sent_dep_sign", dtpEA_apprDate.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@cp_receive_dep_sent_prsd", dtpEA_datesentfin.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@cp_sent_fd_commit", dtpEA_daterecFin.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@cp_receive_fd_commit", dtpEA_apprDate.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@cp_distribution", dtpEA_apprDate.Value.ToString("dd/MMM/yyyy"));

                        cmd.Parameters.AddWithValue("@dateId", dateId);

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        MessageBox.Show("Contract Process data added Succesfully");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Insert the Contract Process records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            clsForCP.UpdateTenderStatus_CP(_projID);
        }

        private void button16_Click(object sender, EventArgs e)
        {
            int dateId = MaxDateID();

            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        int stage_Id = 0;
                        stage_Id = 5;

                        //  cmd.CommandText = @"INSERT INTO DATES(date_id,proj_id,stage_id,cp_tender_award,cp_received_of_doc,cp_request_start_date,cp_start_date_receive,cp_notice_contractor_to_sign,cp_due_date_pb,cp_sent_dep_sign,cp_receive_dep_sent_prsd,cp_sent_fd_commit,cp_receive_fd_commit,cp_distribution) VALUES(@dateId,@projId,@stageId,@evltendrReq,@fromCd,@senttoTech,@recfromtech,@sentFin,@recFin,@awardAppr)";

                        cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,cp_tender_award,cp_received_of_doc,cp_request_start_date,cp_start_date_receive,cp_notice_contractor_to_sign,cp_due_date_pb) VALUES(@dateId,@projId,@stageId,@cptenderaward,@cpreceivedofdoc,@cprequeststartdate,@cpstartdatereceive,@cpnotice_contractortosign,@cpduedatepb)";

                        cmd.Parameters.AddWithValue("@projId", Convert.ToInt16(lblProjID.Text));
                        cmd.Parameters.AddWithValue("@stageId", stage_Id);
                        cmd.Parameters.AddWithValue("@cptenderaward", dtpEA_reqdate.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@cpreceivedofdoc", dtpEA_recfromcd.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@cprequeststartdate", dtpEA_datesent.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@cpstartdatereceive", dtpEA_daterec.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@cpnotice_contractortosign", dtpEA_datesentfin.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@cpduedatepb", dtpEA_daterecFin.Value.ToString("dd/MMM/yyyy"));

                        cmd.Parameters.AddWithValue("@dateId", dateId);

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        MessageBox.Show("Contract Process data added Succesfully");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE DATES records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void btnUpdate_TP_Click(object sender, EventArgs e)
        {
            if (lblDateID.Text == "label90")
            {
                MessageBox.Show("Please Click on Row Which you want to Update !");
                return;
            }
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        cmd.CommandText = @"UPDATE TenderDatesInfo set ptd_receive_on=@ptdreceivedate,ptd_purpose=@ptdpurpose,ptd_assign_qs=@ptdassignqs,ptd_sent_for_rev=@ptdReview," +
                        "ptd_qs_working_status=@ptdQsstatus,ptd_tendec_doc_cur_status=@ptdCurrentStatus,ptd_forwarded_to_dep=@ptdFrwdToDep where date_id=@dateId";

                        cmd.Parameters.AddWithValue("@ptdreceivedate", dtpRecievedOn.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@ptdpurpose", cmbPurpose.SelectedItem.ToString());
                        cmd.Parameters.AddWithValue("@ptdassignqs", cmbAssignedQs.SelectedItem.ToString());
                        cmd.Parameters.AddWithValue("@ptdReview", dtpReview.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@ptdQsstatus", cmbQsWorkingStatus.SelectedItem.ToString());
                        cmd.Parameters.AddWithValue("@ptdCurrentStatus", cmbTenderDocStatus.SelectedItem.ToString());
                        cmd.Parameters.AddWithValue("@ptdFrwdToDep", dtpFrwdDept.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@dateId", Convert.ToInt16(lblDateID.Text));

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        MessageBox.Show("Tender Preparation Values Updated Succesfully");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE DATES records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            GridViewRefresh_PTD();

        }

        Boolean chkUpdateStatus = false;
        private void dgvPTD_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int rowIndex = Convert.ToInt16(dgvPTD.Rows[e.RowIndex].Index);
            for (int iCnt = 0; iCnt < dgvPTD.Rows.Count; iCnt++)
            {
                if (iCnt.Equals(rowIndex))
                {
                    chkUpdateStatus = true;

                    if (dgvPTD.Rows[iCnt].Cells[0].Value != DBNull.Value)
                    {
                        //dtpRecievedOn.CustomFormat = "dd/MMM/yyyy";
                        msk_dtpRecievedOn.Text = Convert.ToDateTime(dgvPTD.Rows[iCnt].Cells[0].Value).ToString("dd/MMM/yyyy");
                    }
                    else
                    {
                        msk_dtpRecievedOn.Text = "";
                    }


                    cmbPurpose.Text = Convert.ToString(dgvPTD.Rows[iCnt].Cells[1].Value);
                    cmbAssignedQs.Text = Convert.ToString(dgvPTD.Rows[iCnt].Cells[2].Value);

                    if (dgvPTD.Rows[iCnt].Cells[3].Value.ToString() != "")
                    {
                        //dtpReview.CustomFormat = "dd/MMM/yyyy";
                        msk_dtpReview.Text = Convert.ToDateTime(dgvPTD.Rows[iCnt].Cells[3].Value).ToString("dd/MMM/yyyy");
                    }
                    else
                    {
                        msk_dtpReview.Text = "";
                    }


                    cmbQsWorkingStatus.Text = Convert.ToString(dgvPTD.Rows[iCnt].Cells[4].Value);
                    cmbTenderDocStatus.Text = Convert.ToString(dgvPTD.Rows[iCnt].Cells[5].Value);
                    if (dgvPTD.Rows[iCnt].Cells[6].Value.ToString() != "")
                    {
                        //dtpFrwdDept.CustomFormat = "dd/MMM/yyyy";
                        msk_dtpFrwdDept.Text = Convert.ToDateTime(dgvPTD.Rows[iCnt].Cells[6].Value).ToString("dd/MMM/yyyy");
                    }
                    else
                    {
                        msk_dtpFrwdDept.Text = "";
                    }

                    txtRemarks.Text = Convert.ToString(dgvPTD.Rows[iCnt].Cells[7].Value);

                    lblDateID.Text = Convert.ToString(dgvPTD.Rows[iCnt].Cells[8].Value);
                }
            }
            // btnPTD.Enabled = false;
        }
        private void button22_Click(object sender, EventArgs e)
        {
            if (lblDateID.Text == "label90")
            {
                return;
            }
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"DELETE FROM TenderDatesInfo WHERE DATE_ID = " + Convert.ToInt16(lblDateID.Text) + " ";
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Record Deleted Successfully ");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE DATES records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            GridViewRefresh_PTD();
        }


        private void dgvPTD_Rec_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //int rowIndex =  e.RowIndex;
            //try
            //{
            //    int docId = Convert.ToInt16(dgvPTD_Rec.Rows[e.RowIndex].Cells[3].Value);
            //    ReceivedDocProperties receivedDoc = new ReceivedDocProperties(Convert.ToInt16(lblProjID.Text), txtProjCode.Text, docId);
            //    receivedDoc.StartPosition = FormStartPosition.CenterParent;
            //    receivedDoc.ShowDialog();
            //}
            //catch (Exception ex)
            //{                
            //    throw ex;
            //}

        }





        private void button23_Click(object sender, EventArgs e)
        {
            dtpRecievedOn.Checked = false;
            dtpReview.Checked = false;
            dtpFrwdDept.Checked = false;
            cmbAssignedQs.SelectedIndex = -1;
            cmbPurpose.SelectedIndex = -1;
            cmbQsWorkingStatus.SelectedIndex = -1;
            cmbTenderDocStatus.SelectedIndex = -1;
            txtRemarks.Text = "";
        }
        private void dtpEA_stage1_ValueChanged(object sender, EventArgs e)
        {
            //dtpTV_OrgDate.Text =  dtpEA_stage1.Value.AddDays(90).ToString();

            //if (dtpTV_OrgDate.Checked == true)
            //{
            //    int iDays = (System.DateTime.Now.Date - dtpTV_OrgDate.Value).Days;
            //    txtTV_exipre.Text = iDays.ToString();
            //}
            //if (dtpTBV_OrgDate.Checked == true)
            //{
            //    int iDays = (System.DateTime.Now.Date - dtpTBV_OrgDate.Value).Days;
            //    txtTBV_exipre.Text = iDays.ToString();
            //}
        }

        private void dtpTV_SEdate_ValueChanged(object sender, EventArgs e)
        {
            msk_dtpTV_SEdate.Focus();
            msk_dtpTV_SEdate.Text = dtpTV_SEdate.Value.ToString("dd-MMM-yyyy");
            //if (msk_dtpEA_reqdate.Text != "")
            //{
            //    msk_dtpTV_SEdate.Text = dtpTV_SEdate.Value.ToString("dd/MMM/yyyy");                
            //}
        }
        private void dtpTBV_SEdate_ValueChanged(object sender, EventArgs e)
        {
            //if (msk_dtpEA_stage1.Text != "")
            //{
            //    msk_dtpTBV_SEdate.Text = dtpTBV_SEdate.Value.ToString("dd/MMM/yyyy");                
            //}
            msk_dtpTBV_SEdate.Text = dtpTBV_SEdate.Value.ToString("dd-MMM-yyyy");
            msk_dtpTBV_SEdate.Focus();
        }
        private void dtpTV_FEdate_ValueChanged(object sender, EventArgs e)
        {
            //if (msk_dtpEA_reqdate.Text != "")
            //{
            //    msk_dtpTV_FEdate.Text = dtpTV_FEdate.Value.ToString("dd/MMM/yyyy");               
            //}
            msk_dtpTV_FEdate.Text = dtpTV_FEdate.Value.ToString("dd-MMM-yyyy");
            msk_dtpTV_FEdate.Focus();
        }
        private void dtpTBV_FEdate_ValueChanged(object sender, EventArgs e)
        {
            //if (msk_dtpEA_reqdate.Text != "")
            //{
            //    msk_dtpTBV_FEdate.Text = dtpTBV_FEdate.Value.ToString("dd/MMM/yyyy");             
            //}
            msk_dtpTBV_FEdate.Text = dtpTBV_FEdate.Value.ToString("dd-MMM-yyyy");
            msk_dtpTBV_FEdate.Focus();
        }

        private void fillStage6()
        {
            try
            {
                using (SqlConnection sqlCn = new SqlConnection(connStr))
                {
                    sqlCn.Open();
                    String insertData = "DELETE FROM TenderDatesInfo WHERE (stage_id = 6) AND (proj_id = " + _projID + ")";
                    SqlCommand cmd = new SqlCommand(insertData, sqlCn);
                    cmd.ExecuteNonQuery();
                    sqlCn.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
            int dateID = 0;
            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                String readData = "SELECT MAX(DATE_ID) FROM TenderDatesInfo";
                SqlCommand cmd = new SqlCommand(readData, sqlCn);
                dateID = Convert.ToInt16(cmd.ExecuteScalar());
                dateID = dateID + 1;
                sqlCn.Close();
            }

            SqlConnection cn = new SqlConnection(connStr);
            cn.Open();
            SqlDataAdapter da = new SqlDataAdapter();
            for (int i = 0; i < dgvPC.Rows.Count - 1; i++)
            {
                if (dgvPC.Rows[i].Cells[0].Value != null)
                {
                    dateID = dateID + i;
                    String insertData = "INSERT INTO TenderDatesInfo(Date_ID, Proj_ID,stage_id,[Staff_In_Charge],FromDate,ToDate,Remarks,employee_id) VALUES (@dateId,@PrjId,@stgID, @staffName, @FromDate,@ToDate,@PC_Remarks,@empID)";
                    SqlCommand cmd = new SqlCommand(insertData, cn);

                    cmd.Parameters.AddWithValue("@dateId", dateID);
                    cmd.Parameters.AddWithValue("@PrjId", _projID);
                    cmd.Parameters.AddWithValue("@stgID", 6);
                    cmd.Parameters.AddWithValue("@empID", dgvPC.Rows[i].Cells[0].Value);
                    cmd.Parameters.AddWithValue("@staffName", dgvPC.Rows[i].Cells[0].Value);

                    if (dgvPC.Rows[i].Cells[1].Value.ToString() != "")
                    {
                        cmd.Parameters.AddWithValue("@FromDate", Convert.ToDateTime(dgvPC.Rows[i].Cells[1].Value).ToString("dd/MMM/yyyy"));
                    }
                    else
                        cmd.Parameters.AddWithValue("@FromDate", DBNull.Value);

                    if (dgvPC.Rows[i].Cells[2].Value.ToString() != "")
                    {
                        cmd.Parameters.AddWithValue("@ToDate", Convert.ToDateTime(dgvPC.Rows[i].Cells[2].Value).ToString("dd/MMM/yyyy"));
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("@ToDate", DBNull.Value);
                    }
                    // cmd.Parameters.AddWithValue("@PC_Remarks",txtPC_Remarks.Text);

                    if(dgvPC.Rows[i].Cells[3].Value!=null)
                        cmd.Parameters.AddWithValue("@PC_Remarks", dgvPC.Rows[i].Cells[3].Value);
                    else
                        cmd.Parameters.AddWithValue("@PC_Remarks", DBNull.Value);
                    da.InsertCommand = cmd;
                    cmd.ExecuteNonQuery();
                }
            }
            cn.Close();

            MessageBox.Show("Data saved successfully.", "PostContract Data Entry", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void dtp_tsRecOn_ValueChanged(object sender, EventArgs e)
        {
            //dtp_tsRecOn.Value.ToString("dd/MMM/yyyy");
            //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            msk_dtp_tsRecOn.Text = Convert.ToDateTime(dtp_tsRecOn.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
            msk_dtp_tsRecOn.Focus();
        }
        private void dtp_tsReturnDept_ValueChanged(object sender, EventArgs e)
        {
            //msk_dtp_tsReturnDept.Text = dtp_tsReturnDept.Value.ToString("dd/MMM/yyyy");
            //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            msk_dtp_tsReturnDept.Text = Convert.ToDateTime(dtp_tsReturnDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
            dtp_tsReturnDept.Focus();
        }
        private void dtp_tsRecFromDept_ValueChanged(object sender, EventArgs e)
        {
            //dtp_tsRecFromDept.Focus();
            //msk_dtp_tsRecFromDept.Text = dtp_tsRecFromDept.Value.ToString("dd/MMM/yyyy");
            //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            msk_dtp_tsRecFromDept.Text = Convert.ToDateTime(dtp_tsRecFromDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");

        }
        private void dtp_tsAdvertisement_ValueChanged(object sender, EventArgs e)
        {
            dtp_tsAdvertisement.Focus();
            //msk_dtp_tsAdvertisement.Text = dtp_tsAdvertisement.Value.ToString("dd/MMM/yyyy");
            //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            msk_dtp_tsAdvertisement.Text = Convert.ToDateTime(dtp_tsAdvertisement.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");

        }
        private void dtp_tsInvitation_ValueChanged(object sender, EventArgs e)
        {
            //msk_dtp_tsInvitation.Text = dtp_tsInvitation.Value.ToString("dd/MMM/yyyy");
            //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            msk_dtp_tsInvitation.Text = Convert.ToDateTime(dtp_tsInvitation.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
            dtp_tsInvitation.Focus();
        }

        private void dtp_tsStage1_ValueChanged(object sender, EventArgs e)
        {
            //msk_dtp_tsStage1.Text = dtp_tsStage1.Value.ToString("dd/MMM/yyyy");
            //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            if (mUserRightsColl.Contains("40"))       // For TS
            {
                MessageBox.Show("You don't have edit rights on Tendering Satge, Contact administrator");
                return;
            }
            msk_dtp_tsStage1.Text = Convert.ToDateTime(dtp_tsStage1.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
            msk_dtp_tsStage1.Focus();
        }
        private void dtp_tsStage2_ValueChanged(object sender, EventArgs e)
        {
            //msk_dtp_tsStage2.Text = dtp_tsStage2.Value.ToString("dd/MMM/yyyy");
            //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            msk_dtp_tsStage2.Text = Convert.ToDateTime(dtp_tsStage2.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
            msk_dtp_tsStage2.Focus();
        }
        private void dtp_tsModifiedDate_ValueChanged(object sender, EventArgs e)
        {
            if (mUserRightsColl.Contains("40"))       // For TS
            {
                MessageBox.Show("You don't have edit rights on Tendering Satge, Contact administrator");
                return;
            }
            //msk_dtp_tsModifiedDate.Text = dtp_tsModifiedDate.Value.ToString("dd/MMM/yyyy");
            //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            msk_dtp_tsModifiedDate.Text = Convert.ToDateTime(dtp_tsModifiedDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
            msk_dtp_tsModifiedDate.Focus();
        }
        private void msk_dtp_tsReturnDept_Leave(object sender, EventArgs e)
        {
            if (msk_dtp_tsReturnDept.Text != "")
            {
                if (ValidateDate(msk_dtp_tsReturnDept) == false)
                {
                    msk_dtp_tsReturnDept.Text = "";
                    msk_dtp_tsReturnDept.Focus();
                }
            }
        }
        private void msk_dtp_tsRecFromDept_Leave(object sender, EventArgs e)
        {
            if (msk_dtp_tsRecFromDept.Text != "")
            {
                if (ValidateDate(msk_dtp_tsRecFromDept) == false)
                {
                    msk_dtp_tsRecFromDept.Text = "";
                    msk_dtp_tsRecFromDept.Focus();
                }
            }
        }
        private void msk_dtp_tsAdvertisement_Leave(object sender, EventArgs e)
        {
            if (msk_dtp_tsAdvertisement.Text != "")
            {
                if (ValidateDate(msk_dtp_tsAdvertisement) == false)
                {
                    msk_dtp_tsAdvertisement.Text = "";
                    msk_dtp_tsAdvertisement.Focus();
                }
            }
        }
        private void msk_dtp_tsInvitation_Leave(object sender, EventArgs e)
        {
            if (msk_dtp_tsInvitation.Text != "")
            {
                if (ValidateDate(msk_dtp_tsInvitation) == false)
                {
                    msk_dtp_tsInvitation.Text = "";
                    msk_dtp_tsInvitation.Focus();
                }
            }
        }
        private void msk_dtp_tsStage1_Leave(object sender, EventArgs e)
        {
            if (msk_dtp_tsStage1.Text != "")
            {
                if (ValidateDate(msk_dtp_tsStage1) == true)
                {
                    if (msk_dtp_tsRecOn.Text == "")
                    {
                        msk_dtp_tsStage1.Text = "";
                        msk_dtp_tsRecOn.Focus();
                        MessageBox.Show("Please update the date on '(For Tendering) Received On' before this field.");
                        return;
                    }
                    if (Convert.ToDateTime(msk_dtp_tsRecOn.Text) > Convert.ToDateTime(msk_dtp_tsStage1.Text))
                    {
                        msk_dtp_tsStage1.Text = "";
                        msk_dtp_tsStage1.Focus();

                        MessageBox.Show("Date entered is earlier than '(For Tendering) Received On'. Please check and revise your entry.");
                        return;
                    }
                }
                else
                {
                    msk_dtp_tsStage1.Text = "";
                    msk_dtp_tsStage1.Focus();
                }
            }
        }
        private void msk_dtp_tsStage2_Leave(object sender, EventArgs e)
        {
            if (msk_dtp_tsStage2.Text != "")
            {
                if (ValidateDate(msk_dtp_tsStage2) == false)
                {
                    if (msk_dtp_tsStage1.Text == "")
                    {
                        msk_dtp_tsStage2.Text = "";
                        msk_dtp_tsStage1.Focus();
                        MessageBox.Show("There is no date in Tender Closing Date Stage 1. Please update this prior to this field.");

                        return;
                    }
                    if (Convert.ToDateTime(msk_dtp_tsStage1.Text) > Convert.ToDateTime(msk_dtp_tsStage2.Text))
                    {
                        msk_dtp_tsStage2.Text = "";
                        msk_dtp_tsStage2.Focus();
                        MessageBox.Show("Stage 2 date should be greater than Stage 1 date");

                        return;
                    }
                }
            }
        }
        private void msk_dtp_tsModifiedDate_Leave(object sender, EventArgs e)
        {
            if (msk_dtp_tsModifiedDate.Text != "")
            {
                if (ValidateDate(msk_dtp_tsModifiedDate) != false)
                {
                    if (msk_dtp_tsStage1.Text == "")
                    {
                        msk_dtp_tsStage1.Focus();
                        MessageBox.Show("There is no date in Tender Closing Date Stage 1. Please update this prior to this field.");
                        msk_dtp_tsModifiedDate.Text = "";
                        return;
                    }
                    if (Convert.ToDateTime(msk_dtp_tsStage1.Text) > Convert.ToDateTime(msk_dtp_tsModifiedDate.Text))
                    {

                        msk_dtp_tsModifiedDate.Focus();
                        MessageBox.Show("Date entered is less than 'Tender Closing Date'. Please check and revise your entry.");
                        msk_dtp_tsModifiedDate.Text = "";
                        return;
                    }
                }
                else
                {
                    msk_dtp_tsModifiedDate.Text = "";
                    msk_dtp_tsModifiedDate.Focus();
                }
            }

            //if (msk_dtp_tsModifiedDate.Text != "" && !msk_dtp_tsModifiedDate.Text.Equals(_modifiedClosingDate))
            //  AlertMessageForTenderClosing(_modifiedClosingDate, msk_dtp_tsModifiedDate.Text);

        }
        private void AlertMessageForTenderClosing(string _modifiedDate, string _modified_NewDate)
        {

            UserList_ForAlert(2);

            if (userListColl.Count == 0)
            {
                MessageBox.Show("Information for Tender No.assignment is required to be sent to a user who handles " + _cmtName + " projects, " +
                  " but there is no identified user to receive the email. Please contact system administrator for information.");
                return;
            }


            // AlertOnNewTenderNo(tenderNo, _projID.ToString(), "New Project");
            CommonClass comCls = new CommonClass(_userName);
            string fromUser = null;
            fromUser = comCls.getUserEmailID(_userName);

            try
            {

                foreach (string strname in userListColl)
                {
                    // if (GetUserInformation4rmActiveDirectory(strname, "ashghal.gov.qa", ref DisplayName, ref Email, ref  Department, ref Title) == true)
                    {
                        MailMessage mailMessage = new MailMessage();
                        //mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["MailFrom"].ToString());

                        mailMessage.From = new MailAddress(fromUser);
                        // mailMessage.To.Add(new MailAddress(ConfigurationManager.AppSettings["MailTo"].ToString()));
                        mailMessage.To.Add(new MailAddress(strname));
                        mailMessage.Subject = "TCMS Alert: Tender Closing Date. " + _modifiedDate + " was modified";
                        // mailMessage.Body = "This is an automated alert from TCMS." + "\n" + "\n" + "Project Code: " + _prjCode + "\n" + "Project Title: " + proj_Title + "\n" + "\n" + "Tender No. " + strTenderNo + " was assigned to above project.";

                        mailMessage.Body = "This is an automated alert from Tender & Contract Management System." + "\n" + "\n" + "Project Code     : " + _prjCode + " " +
                          "\n" + "Project Title    : " + proj_Title + " " +
                           "\n" + "Tender Closing Existed Date : " + _modifiedDate + " " +
                            "\n" + "Tender Closing New Date : " + _modified_NewDate + " " +
                            //  "\n" + "Type of Tender   : " + _tndrTypeName + " " +
                            //"\n" + "Tender Committee : " + _cmtName + " " +
                            // "\n" + "User Department  : " + _userDept + " " +
                            // "\n" + "Date Created     : " + System.DateTime.Now.ToString() + " " +
                        " \n" + "\n" + " Tender Closing Date Was Modified.";


                        SmtpClient client = new SmtpClient();
                        client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                        client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                        client.Send(mailMessage);
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception occurred while sending the email notification to Tender Committee, Please inform them Personally", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void dtpEA_reqdate_ValueChanged(object sender, EventArgs e)
        {
            msk_dtpEA_reqdate.Text = dtpEA_reqdate.Value.ToString("dd/MMM/yyyy");
            //DateTime dt_dtpEA_reqdate = Convert.ToDateTime(msk_dtpEA_reqdate.Text);
            //msk_dtpTV_OrgDate.Text = dt_dtpEA_reqdate.AddDays(90).ToString("dd/MMM/yyyy");
            //msk_dtpTBV_OrgDate.Text = dt_dtpEA_reqdate.AddDays(120).ToString("dd/MMM/yyyy");

            //int iDays = (System.DateTime.Now.Date - Convert.ToDateTime(msk_dtpTV_OrgDate.Text)).Days;
            //int iDaysBond = (System.DateTime.Now.Date - Convert.ToDateTime(msk_dtpTBV_OrgDate.Text)).Days;
            //txtTV_exipre.Text = iDays.ToString();
            //txtTBV_exipre.Text = iDaysBond.ToString();

        }
        private void dtpEA_recfromcd_ValueChanged(object sender, EventArgs e)
        {
            dtpEA_recfromcd.Focus();
            //msk_dtpEA_recfromcd.Text = dtpEA_recfromcd.Value.ToString("dd/MMM/yyyy");
            //Modified by Varun on 13/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            msk_dtpEA_recfromcd.Text = Convert.ToDateTime(dtpEA_recfromcd.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
        }
        private void dtpEA_datesent_ValueChanged(object sender, EventArgs e)
        {
            msk_dtpEA_datesent.Focus();
            //msk_dtpEA_datesent.Text = dtpEA_datesent.Value.ToString("dd/MMM/yyyy");
            //Modified by Varun on 13/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            msk_dtpEA_datesent.Text = Convert.ToDateTime(dtpEA_datesent.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
        }
        private void dtpEA_daterec_ValueChanged(object sender, EventArgs e)
        {
            msk_dtpEA_daterec.Focus();
            //msk_dtpEA_daterec.Text = dtpEA_daterec.Value.ToString("dd/MMM/yyyy");
            //Modified by Varun on 13/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            msk_dtpEA_daterec.Text = Convert.ToDateTime(dtpEA_daterec.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
        }
        private void dtpEA_datesentfin_ValueChanged(object sender, EventArgs e)
        {
            msk_dtpEA_datesentfin.Focus();
            //msk_dtpEA_datesentfin.Text = dtpEA_datesentfin.Value.ToString("dd/MMM/yyyy");                          
            //Modified by Varun on 13/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            msk_dtpEA_datesentfin.Text = Convert.ToDateTime(dtpEA_datesentfin.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
        }
        private void dtpEA_daterecFin_ValueChanged(object sender, EventArgs e)
        {
            msk_dtpEA_daterecFin.Focus();
            //msk_dtpEA_daterecFin.Text = dtpEA_daterecFin.Value.ToString("dd/MMM/yyyy");
            //Modified by Varun on 13/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            msk_dtpEA_daterecFin.Text = Convert.ToDateTime(dtpEA_daterecFin.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
        }
        private void dtpEA_apprDate_ValueChanged(object sender, EventArgs e)
        {
            msk_dtpEA_apprDate.Focus();
            //msk_dtpEA_apprDate.Text = dtpEA_apprDate.Value.ToString("dd/MMM/yyyy");
            //Modified by Varun on 13/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            msk_dtpEA_apprDate.Text = Convert.ToDateTime(dtpEA_apprDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
        }


        private void msk_dtpTV_FEdate_Leave(object sender, EventArgs e)
        {
            // msk_dtpTV_FEdate.Text = dtpTV_FEdate.Value.ToString("dd/MMM/yyyy");
            //if (msk_dtpTV_FEdate.Text != "")   

            if (msk_dtpTV_FEdate.Text != "")
            {
                if (ValidateDate(msk_dtpTV_FEdate) == false)
                {
                    msk_dtpTV_FEdate.Text = "";
                    msk_dtpTV_FEdate.Focus();
                    return;
                }
                // Modified on jan 28th by Sreedhar //Modified by Varun on 04 Feb 2014 based on Adonis req.
                if (msk_dtpTV_SEdate.Text == "" && msk_dtpTV_OrgDate.Text != "" && isCpContractorSign == false)
                {
                    if (Convert.ToDateTime(msk_dtpTV_OrgDate.Text) > Convert.ToDateTime(msk_dtpTV_FEdate.Text))
                    {
                        MessageBox.Show("Extension Date should be greater than Original Date");
                        msk_dtpTV_FEdate.Text = "";
                        msk_dtpTV_FEdate.Focus();
                        return;
                    }

                    if (msk_dtpTV_FEdate.Text != "")
                    {
                        int iDays = (Convert.ToDateTime(msk_dtpTV_FEdate.Text) - System.DateTime.Now.Date).Days;
                        txtTV_exipre.Text = iDays.ToString();
                    }
                }
            }
            //Modified by Varun on 04 Feb 2014 based on Adonis req.
            if (msk_dtpTV_FEdate.Text != "" && isCpContractorSign == false)
            {
                int iDays = (Convert.ToDateTime(msk_dtpTV_FEdate.Text) - System.DateTime.Now.Date).Days;
                txtTV_exipre.Text = iDays.ToString();
            }
            //Modified by Varun on 04 Feb 2014 based on Adonis req.
            if (txtTV_exipre.Text != "" && isCpContractorSign == false)
                clsForTS.UpdateTV_FirstExtension(msk_dtpTV_FEdate.Text, _projID, Convert.ToInt16(txtTV_exipre.Text));

        }
        private void msk_dtpTBV_FEdate_Leave(object sender, EventArgs e)
        {

            // if (msk_dtpTBV_FEdate.Text != "")
            //UpdateTBV_FirstExtension(msk_dtpTBV_FEdate.Text);

            if (msk_dtpTBV_FEdate.Text != "")
            {
                if (ValidateDate(msk_dtpTBV_FEdate) == false)
                {
                    msk_dtpTBV_FEdate.Text = "";
                    msk_dtpTBV_FEdate.Focus();
                    return;
                }
            }

            //Modified by Varun on 04 Feb 2014 based on Adonis req.

            if (msk_dtpTBV_FEdate.Text != "" && isCpContractorSign == false)

                if (msk_dtpTBV_SEdate.Text == "" & msk_dtpTBV_OrgDate.Text != "")
                {
                    if (Convert.ToDateTime(msk_dtpTBV_OrgDate.Text) > Convert.ToDateTime(msk_dtpTBV_FEdate.Text))
                    {
                        MessageBox.Show("Extension Date Should be greater than Original Date");
                        msk_dtpTBV_FEdate.Text = "";
                        msk_dtpTBV_FEdate.Focus();
                        return;
                    }
                    if (msk_dtpTBV_FEdate.Text != "")
                    {
                        int iDays = (Convert.ToDateTime(msk_dtpTBV_FEdate.Text) - System.DateTime.Now.Date).Days;
                        txtTBV_exipre.Text = iDays.ToString();
                    }
                }
            //Modified by Varun on 04 Feb 2014 based on Adonis req.
            if (msk_dtpTBV_SEdate.Text == "" && isCpContractorSign == false)
            {
                if (msk_dtpTBV_FEdate.Text != "")
                {
                    int iDays = (Convert.ToDateTime(msk_dtpTBV_FEdate.Text) - System.DateTime.Now.Date).Days;
                    txtTBV_exipre.Text = iDays.ToString();
                }
            }

            if (txtTBV_exipre.Text != "" && isCpContractorSign == false)
                clsForTS.UpdateTBV_FirstExtension(msk_dtpTBV_FEdate.Text, _projID, Convert.ToInt16(txtTBV_exipre.Text));

        }
        private void msk_dtpTV_SEdate_Leave(object sender, EventArgs e)
        {
            //if (msk_dtpTV_FEdate.Text != "")
            //  UpdateTV_LastExtension(msk_dtpTV_SEdate.Text);

            if (msk_dtpTV_SEdate.Text != "")
            {
                if (ValidateDate(msk_dtpTV_SEdate) == false)
                {
                    msk_dtpTV_SEdate.Text = "";
                    msk_dtpTV_SEdate.Focus();
                    return;
                }
            }
            //Modified by Varun on 04 Feb 2014 based on Adonis req.
            if (msk_dtpTV_FEdate.Text != "" && isCpContractorSign == false)
            {
                if (msk_dtpTV_SEdate.Text != "")
                {
                    if (Convert.ToDateTime(msk_dtpTV_FEdate.Text) > Convert.ToDateTime(msk_dtpTV_SEdate.Text))
                    {
                        MessageBox.Show("Extension Date Should be greater than Original Date");
                        msk_dtpTV_SEdate.Text = "";
                        msk_dtpTV_SEdate.Focus();
                        return;
                    }
                    //if (msk_dtpTBV_FEdate.Text != "")
                    //{
                    int iDays = (Convert.ToDateTime(msk_dtpTV_SEdate.Text) - System.DateTime.Now.Date).Days;
                    txtTV_exipre.Text = iDays.ToString();
                    //}
                }
            }
            else
            {
                MessageBox.Show("First Extension date should not be null", "Null Value", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                msk_dtpTV_SEdate.Text = "";
                msk_dtpTV_FEdate.Focus();
                return;
            }
            //Modified by Varun on 04 Feb 2014 based on Adonis req.
            if (msk_dtpTV_SEdate.Text != "" && isCpContractorSign == false)
            {
                int iDays = (Convert.ToDateTime(msk_dtpTV_SEdate.Text) - System.DateTime.Now.Date).Days;
                txtTV_exipre.Text = iDays.ToString();
            }
            //Modified by Varun on 04 Feb 2014 based on Adonis req.
            if (txtTV_exipre.Text != "" && isCpContractorSign == false)
                clsForTS.UpdateTV_LastExtension(msk_dtpTV_SEdate.Text, _projID, Convert.ToInt16(txtTV_exipre.Text));

        }
        private void msk_dtpTBV_SEdate_Leave(object sender, EventArgs e)
        {
            //if (msk_dtpTBV_SEdate.Text != "")
            //UpdateTBV_LastExtension(msk_dtpTBV_SEdate.Text);

            if (msk_dtpTBV_SEdate.Text != "")
            {
                if (ValidateDate(msk_dtpTBV_SEdate) == false)
                {
                    msk_dtpTBV_SEdate.Text = "";
                    msk_dtpTBV_SEdate.Focus();
                    return;
                }
            }

            //Modified by Varun on 04 Feb 2014 based on Adonis req.            
            if (msk_dtpTBV_FEdate.Text != "" && isCpContractorSign == false)
            {
                if (msk_dtpTBV_SEdate.Text != "")
                {
                    if (Convert.ToDateTime(msk_dtpTBV_FEdate.Text) > Convert.ToDateTime(msk_dtpTBV_SEdate.Text))
                    {
                        MessageBox.Show("Extension Date Should be greater than Original Date");
                        msk_dtpTBV_SEdate.Text = "";
                        msk_dtpTBV_SEdate.Focus();
                        return;
                    }
                    if (msk_dtpTBV_SEdate.Text != "")
                    {
                        int iDays = (Convert.ToDateTime(msk_dtpTBV_SEdate.Text) - System.DateTime.Now.Date).Days;
                        txtTBV_exipre.Text = iDays.ToString();
                    }
                }
            }
            else
            {
                msk_dtpTBV_SEdate.Text = "";
            }
            //Modified by Varun on 04 Feb 2014 based on Adonis req.            
            if (msk_dtpTBV_SEdate.Text != "" && isCpContractorSign == false)
            {
                int iDays = (Convert.ToDateTime(msk_dtpTBV_SEdate.Text) - System.DateTime.Now.Date).Days;
                txtTBV_exipre.Text = iDays.ToString();
            }
            //Modified by Varun on 04 Feb 2014 based on Adonis req.            
            if (txtTBV_exipre.Text != "" && isCpContractorSign == false)
                clsForTS.UpdateTBV_LastExtension(msk_dtpTBV_SEdate.Text, _projID, Convert.ToInt16(txtTBV_exipre.Text));

        }
        private void msk_dtpEA_reqdate_Leave(object sender, EventArgs e)
        {
            if (msk_dtpEA_reqdate.Text != "")
            {
                if (ValidateDate(msk_dtpEA_reqdate) == true)
                {
                    if (isCpContractorSign == false)
                    {
                        DateTime dt_dtpEA_reqdate = Convert.ToDateTime(msk_dtpEA_reqdate.Text, CultureInfo.InvariantCulture);
                        msk_dtpTV_OrgDate.Text = dt_dtpEA_reqdate.AddDays(90).ToString("dd/MMM/yyyy");
                        msk_dtpTBV_OrgDate.Text = dt_dtpEA_reqdate.AddDays(120).ToString("dd/MMM/yyyy");

                        // Added by Varun on 5 Feb 2014 for Update tenderValidityDate and tenderBondValidityDate
                        if (msk_dtpTV_OrgDate.Text != "")
                            Update_tenderValidityDate(tndrDate_ID);
                        if (msk_dtpTBV_OrgDate.Text != "")
                            Update_tender_BondValidityDate(tndrDate_ID);

                        TE_Validate(tndrDate_ID);
                        if (msk_dtpEA_reqdate.Text != "")
                        {
                            if (msk_dtpEA_stage1.Text == "")
                            {
                                msk_dtpEA_reqdate.Text = "";
                                msk_dtpEA_reqdate.Focus();
                                MessageBox.Show("Tender Closing Date in Tender Stage is not updated. Please Update this prior to this field.");
                                return;
                            }
                            //Modified by Varun on 04 Feb 2014 based on Adonis req.  
                            if (msk_dtpEA_stage1.Text != "" & msk_dtpEA_reqdate.Text != "")
                            {
                                if (Convert.ToDateTime(msk_dtpEA_reqdate.Text) < Convert.ToDateTime(msk_dtpEA_stage1.Text))
                                {
                                    MessageBox.Show("Date entered is earlier than Tender Closing Date. Please check and revise your entry.");
                                    msk_dtpEA_reqdate.Text = "";
                                    //msk_dtpEA_reqdate.Focus();
                                    return;
                                }
                            }
                        }
                    }
                }
                else
                {
                    msk_dtpEA_reqdate.Text = "";
                    msk_dtpEA_reqdate.Focus();
                    return;
                }
            }
        }
        private void msk_dtpTV_FEdate_TextChanged(object sender, EventArgs e)
        {
            //UpdateTV_FirstExtension(msk_dtpTV_FEdate.Text);
        }
        private void msk_dtpEA_reqdate_TextChanged(object sender, EventArgs e)
        {
            Control ctrl = sender as Control;
            if (ValidateDate(ctrl) == true)
            {
                //Modified by Varun on 04 Feb 2014 based on Adonis req.  
                if (msk_dtpEA_reqdate.Text != "")
                {
                    if (isCpContractorSign == false)
                    {
                        //msk_dtpEA_reqdate.Text = dtpEA_reqdate.Value.ToString("dd/MMM/yyyy");
                        DateTime dt_dtpEA_reqdate = Convert.ToDateTime(msk_dtpEA_reqdate.Text, CultureInfo.InvariantCulture);

                        msk_dtpTV_OrgDate.Text = dt_dtpEA_reqdate.AddDays(90).ToString("dd/MMM/yyyy");

                        //if (msk_dtpEA_closeDate.Text != "")
                        //{
                        //    DateTime dt_dtpEA_Modifydate = Convert.ToDateTime(msk_dtpEA_closeDate.Text);
                        //    msk_dtpTBV_OrgDate.Text = dt_dtpEA_Modifydate.AddDays(120).ToString("dd/MMM/yyyy");
                        //}
                        //else if (msk_dtpEA_stage1.Text != "")
                        //{
                        //    DateTime dt_dtpEA_stage1 = Convert.ToDateTime(msk_dtpEA_stage1.Text);
                        //    msk_dtpTBV_OrgDate.Text = dt_dtpEA_stage1.AddDays(120).ToString("dd/MMM/yyyy");
                        //}

                        int iDays = (Convert.ToDateTime(msk_dtpTV_OrgDate.Text) - System.DateTime.Now.Date).Days;
                        //int iDaysBond = (Convert.ToDateTime(msk_dtpTBV_OrgDate.Text) - System.DateTime.Now.Date).Days;
                        txtTV_exipre.Text = iDays.ToString();
                        //txtTBV_exipre.Text = iDaysBond.ToString();
                    }
                }
                else
                {

                    msk_dtpTV_OrgDate.Text = "";
                    msk_dtpTBV_OrgDate.Text = "";
                }
            }

        }
        private void btnPTD_Click(object sender, EventArgs e)
        {
            if (chkUpdateStatus == false)
            {
                if (msk_dtpRecievedOn.Text == "")
                {
                    MessageBox.Show("Please select Received On Date");
                    msk_dtpRecievedOn.Focus();
                    return;
                }
                int dateID = MaxDateID();
                InsertTenderPreparationInfo(dateID);

                if (cmbQsWorkingStatus.Text == "Completed" & cmbTenderDocStatus.Text == "Approved" & msk_dtpFrwdDept.Text != "")
                {

                    // Update the Stage and Status from PTD to TS and Tendering
                    clsForPTD.UpdateFromTPtoTS(_projID);

                    //dalObj.populateCmbBox("Select [Tender Status],[Tender Statsus Short Name] From [Status of Tender] WHERE [Tender Status] != 'Cancelled' and [Tender Status] != 'Re-Tender' ", cmbTenderStatus);
                    cmbTenderStatus.SelectedIndex = 1;
                    // added by Varun on 11/05/2015
                    FillProjectInfo();
                }

                GridViewRefresh_PTD();
                msk_dtpRecievedOn.Text = "";
                msk_dtpReview.Text = "";
                msk_dtpFrwdDept.Text = "";

                cmbAssignedQs.SelectedIndex = -1;
                cmbPurpose.SelectedIndex = -1;
                cmbQsWorkingStatus.SelectedIndex = -1;
                cmbTenderDocStatus.SelectedIndex = -1;
                txtRemarks.Text = "";
            }
            else
            {
                UpdateTenderPreparationInfo();
                GridViewRefresh_PTD();
            }

        }
        private void InsertTenderPreparationInfo(int _dateID)
        {
            if (msk_dtpRecievedOn.Text == "")
            {
                MessageBox.Show("Please select received on date");
                msk_dtpRecievedOn.Focus();
                return;
            }

            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    sqlConn.Open();
                    string insertQuery = "INSERT INTO TenderDatesInfo(date_id,proj_id, stage_id, ptd_receive_on, ptd_purpose, ptd_assign_qs," +
                    " ptd_sent_for_rev, ptd_qs_working_status, ptd_tendec_doc_cur_status,ptd_forwarded_to_dep, remarks,Create_Date,Create_User) VALUES " +
                    " (@dateId,@projId,@stageId,@PTDreceiveOn,@PTDPurpose,@PTDassignQs,@PTDForReview,@PTDQsStatus,@PTDdocStatus,@PTDfrwdDept,@PTDRemarks,@CreateDate,@CreateUser)";

                    SqlCommand cmd = new SqlCommand(insertQuery, sqlConn);
                    cmd.Parameters.AddWithValue("@dateId", _dateID);
                    cmd.Parameters.AddWithValue("@projId", Convert.ToInt16(lblProjID.Text));
                    cmd.Parameters.AddWithValue("@stageId", 1);

                    //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings 
                    if (msk_dtpRecievedOn.Text != "")
                        cmd.Parameters.AddWithValue("@PTDreceiveOn", Convert.ToDateTime(msk_dtpRecievedOn.Text)); //Convert.ToDateTime(msk_dtpRecievedOn.Text).ToString("dd/MMM/yyyy")
                    else
                        cmd.Parameters.AddWithValue("@PTDreceiveOn", DBNull.Value);

                    if (cmbPurpose.SelectedIndex != -1)                    
                        cmd.Parameters.AddWithValue("@PTDPurpose", cmbPurpose.SelectedItem.ToString());                                                                  
                    else                    
                        cmd.Parameters.AddWithValue("@PTDPurpose", DBNull.Value);                                            

                    if (cmbTenderDocStatus.SelectedIndex != -1)
                        cmd.Parameters.AddWithValue("@PTDdocStatus", cmbTenderDocStatus.SelectedItem.ToString());
                    else
                        cmd.Parameters.AddWithValue("@PTDdocStatus", DBNull.Value);

                    if (cmbAssignedQs.SelectedIndex != -1)
                        cmd.Parameters.AddWithValue("@PTDassignQs", cmbAssignedQs.Text.ToString());
                    else
                        cmd.Parameters.AddWithValue("@PTDassignQs", DBNull.Value);

                    DateTime value;
                    DateTime.TryParseExact(msk_dtpReview.Text, "dd/MMM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out value);
                    //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings 
                    if (msk_dtpReview.Text != "")
                        cmd.Parameters.AddWithValue("@PTDForReview", Convert.ToDateTime(msk_dtpReview.Text)); //.ToString("dd/MMM/yyyy")
                    else
                        cmd.Parameters.AddWithValue("@PTDForReview", DBNull.Value);

                    if (cmbQsWorkingStatus.SelectedIndex != -1)
                        cmd.Parameters.AddWithValue("@PTDQsStatus", cmbQsWorkingStatus.SelectedItem.ToString());
                    else
                        cmd.Parameters.AddWithValue("@PTDQsStatus", DBNull.Value);

                    //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings 
                    if (msk_dtpFrwdDept.Text != "")
                        cmd.Parameters.AddWithValue("@PTDfrwdDept", Convert.ToDateTime(msk_dtpFrwdDept.Text));//.ToString("dd/MMM/yyyy")
                    else
                        cmd.Parameters.AddWithValue("@PTDfrwdDept", DBNull.Value);

                    cmd.Parameters.AddWithValue("@PTDRemarks", txtRemarks.Text);

                    cmd.Parameters.AddWithValue("@CreateDate", System.DateTime.Now);
                    cmd.Parameters.AddWithValue("@CreateUser", _userName);

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Tender Document Preparation Data Added Successfully");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlConn.Close();
            }

            //For update Assigned QS in Projects Table
            clsStaff.update_AssignedQs(cmbAssignedQs.Text.ToString(), projId);

        }

        public string ConvertDateCalendar(DateTime DateConv, string Calendar, string DateLangCulture)
        {
            System.Globalization.DateTimeFormatInfo DTFormat;
            DateLangCulture = DateLangCulture.ToLower();
            /// We can't have the hijri date writen in English. We will get a runtime error - LAITH - 11/13/2005 1:01:45 PM -

            if (Calendar == "Hijri" && DateLangCulture.StartsWith("en-"))
            {
                DateLangCulture = "ar-sa";
            }

            /// Set the date time format to the given culture - LAITH - 11/13/2005 1:04:22 PM -
            DTFormat = new System.Globalization.CultureInfo(DateLangCulture, false).DateTimeFormat;

            /// Set the calendar property of the date time format to the given calendar - LAITH - 11/13/2005 1:04:52 PM -
            switch (Calendar)
            {
                case "Hijri":
                    DTFormat.Calendar = new System.Globalization.HijriCalendar();
                    break;

                case "Gregorian":
                    DTFormat.Calendar = new System.Globalization.GregorianCalendar();
                    break;

                default:
                    return "";
            }

            /// We format the date structure to whatever we want - LAITH - 11/13/2005 1:05:39 PM -
            DTFormat.ShortDatePattern = "dd/MM/yyyy";
            return (DateConv.Date.ToString("f", DTFormat));
        }

        private void UpdateTenderPreparationInfo()
        {
            //string[] allFormats ={"yyyy/MM/dd hh:mm:ss tt","yyyy/M/d hh:mm:ss tt",
            //"dd/MM/yyyy hh:mm:ss tt","d/M/yyyy hh:mm:ss tt",
            //"dd/M/yyyy hh:mm:ss tt","d/MM/yyyy hh:mm:ss tt","yyyy-MM-dd hh:mm:ss tt",
            //"yyyy-M-d hh:mm:ss tt","dd-MM-yyyy hh:mm:ss tt","d-M-yyyy hh:mm:ss tt",
            //"dd-M-yyyy hh:mm:ss tt","d-MM-yyyy hh:mm:ss tt","yyyy MM dd hh:mm:ss tt",
            //"yyyy M d hh:mm:ss tt","dd MM yyyy hh:mm:ss tt","d M yyyy hh:mm:ss tt",
            //"dd M yyyy hh:mm:ss tt","d MM yyyy hh:mm:ss tt"};

            //string[] allFormats ={"yyyy/MM/dd","yyyy/M/d",
            //    "dd/MM/yyyy","d/M/yyyy",
            //    "dd/M/yyyy","d/MM/yyyy","yyyy-MM-dd",
            //    "yyyy-M-d","dd-MM-yyyy","d-M-yyyy",
            //    "dd-M-yyyy","d-MM-yyyy","yyyy MM dd",
            //    "yyyy M d","dd MM yyyy","d M yyyy",
            //    "dd M yyyy","d MM yyyy","MM/dd/yyyy"};


            //CultureInfo enCul = new CultureInfo("en-US");
            //CultureInfo arCul = new CultureInfo("ar-SA");
            //arCul.DateTimeFormat.Calendar = new System.Globalization.HijriCalendar();
            //DateTime tempDate = DateTime.ParseExact(msk_dtpReview.Text, allFormats, arCul.DateTimeFormat, DateTimeStyles.AllowWhiteSpaces);

            //string strDate = ConvertDateCalendar(msk_dtpReview.Text, "Gregorian", "en-US"); 
            //DateTime tempDate = DateTime.ParseExact(msk_dtpReview.Text, allFormats,
            //enCul.DateTimeFormat, DateTimeStyles.AllowWhiteSpaces);

            if (lblDateID.Text == "label90")
            {
                MessageBox.Show("Please Click on Row Which you want to Update !");
                return;
            }

            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        cmd.CommandText = @"UPDATE TenderDatesInfo set ptd_receive_on=@PTDreceiveOn,ptd_purpose=@PTDPurpose,ptd_assign_qs=@PTDassignQs,ptd_sent_for_rev=@PTDForReview," +
                        "ptd_qs_working_status=@PTDQsStatus,ptd_tendec_doc_cur_status=@PTDdocStatus,ptd_forwarded_to_dep=@PTDfrwdDept, remarks = @PTDRemarks,Update_Date = @UpdateDate,Update_User = @UpdateUser where date_id=@dateId";

                        cmd.Parameters.AddWithValue("@dateId", Convert.ToInt16(lblDateID.Text));
                        //cmd.Parameters.AddWithValue("@projId", Convert.ToInt16(lblProjID.Text));
                        cmd.Parameters.AddWithValue("@stageId", 1);

                        //.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString()
                        //Modified by Varun on 12/02/2014 for updating dates when the regional settings of the system is Arabic, this will work for en-US settings                          
                        if (msk_dtpRecievedOn.Text != "")
                            cmd.Parameters.AddWithValue("@PTDreceiveOn", Convert.ToDateTime(msk_dtpRecievedOn.Text)); //.ToString("dd/MMM/yyyy")
                        else
                            cmd.Parameters.AddWithValue("@PTDreceiveOn", DBNull.Value);
                        if (cmbPurpose.SelectedIndex != -1)
                            cmd.Parameters.AddWithValue("@PTDPurpose", cmbPurpose.SelectedItem.ToString());
                        else
                            cmd.Parameters.AddWithValue("@PTDPurpose", DBNull.Value);

                        if (cmbAssignedQs.SelectedIndex != -1 || cmbAssignedQs.Text.ToString() != "")
                            cmd.Parameters.AddWithValue("@PTDassignQs", cmbAssignedQs.Text.ToString());
                        else
                            cmd.Parameters.AddWithValue("@PTDassignQs", DBNull.Value);

                        //Modified by Varun on 12/02/2014 for updating dates when the regional settings of the system is Arabic, this will work for en-US settings                          
                        if (msk_dtpReview.Text != "")
                            cmd.Parameters.AddWithValue("@PTDForReview", Convert.ToDateTime(msk_dtpReview.Text)); //.ToString("dd/MMM/yyyy")
                        else
                            cmd.Parameters.AddWithValue("@PTDForReview", DBNull.Value);

                        if (cmbQsWorkingStatus.SelectedIndex != -1)
                            cmd.Parameters.AddWithValue("@PTDQsStatus", cmbQsWorkingStatus.SelectedItem.ToString());
                        else
                            cmd.Parameters.AddWithValue("@PTDQsStatus", DBNull.Value);

                        if (cmbTenderDocStatus.SelectedIndex != -1)
                            cmd.Parameters.AddWithValue("@PTDdocStatus", cmbTenderDocStatus.SelectedItem.ToString());
                        else
                            cmd.Parameters.AddWithValue("@PTDdocStatus", DBNull.Value);

                        //Modified by Varun on 12/02/2014 for updating dates when the regional settings of the system is Arabic, this will work for en-US settings                          
                        if (msk_dtpFrwdDept.Text != "")
                            cmd.Parameters.AddWithValue("@PTDfrwdDept", Convert.ToDateTime(msk_dtpFrwdDept.Text)); //.ToString("dd/MMM/yyyy")
                        else
                            cmd.Parameters.AddWithValue("@PTDfrwdDept", DBNull.Value);

                        cmd.Parameters.AddWithValue("@PTDRemarks", txtRemarks.Text);

                        cmd.Parameters.AddWithValue("@UpdateDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@UpdateUser", _userName);

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        MessageBox.Show("Tender Preparation Values Updated Succesfully");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE DATES records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }


            // Update AssihgnedQs value in Projects Table
            int rowCnt = dgvPTD.Rows.Count - 1;

            if (lblGridIndex.Text != "")
            {
                if (rowCnt == Convert.ToInt16(lblGridIndex.Text))
                    clsStaff.update_AssignedQs(cmbAssignedQs.Text.ToString(), _projID);
            }

            ClearTP();
        }

        private void dtpRecievedOn_ValueChanged(object sender, EventArgs e)
        {
            if (dtpRecievedOn.Value.ToString() != "")
            {
                Control ctrl = sender as Control;
                Boolean chkDate = ValidateDate(ctrl);

                if (chkDate == false)
                {
                    msk_dtpRecievedOn.Text = "";
                    msk_dtpRecievedOn.Focus();
                    return;
                }
            }

            //msk_dtpRecievedOn.Text = Convert.ToDateTime(dtpRecievedOn.Value).ToString("dd/MMM/yyyy");                          
            //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings 
            msk_dtpRecievedOn.Text = Convert.ToDateTime(dtpRecievedOn.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");// ToString();             

        }
        private void dtpReview_ValueChanged(object sender, EventArgs e)
        {
            // dtpReview.CustomFormat = "dd/MMM/yyyy";
            //msk_dtpReview.Text = Convert.ToDateTime(dtpReview.Value).ToString("dd/MMM/yyyy");
            msk_dtpReview.Text = Convert.ToDateTime(dtpReview.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");

        }
        private void dtpFrwdDept_ValueChanged(object sender, EventArgs e)
        {
            // dtpFrwdDept.CustomFormat = "dd/MMM/yyyy";                    
            //msk_dtpFrwdDept.Text = Convert.ToDateTime(dtpFrwdDept.Value).ToString("dd/MMM/yyyy");
            if (msk_dtpRecievedOn.Text.Trim() == "")
            {
                MessageBox.Show("Please select Received On Date");
                return;
            }
            if (Convert.ToDateTime(dtpFrwdDept.Value.ToString()).CompareTo(Convert.ToDateTime(dtpRecievedOn.Value.ToString())) >= 0)
                msk_dtpFrwdDept.Text = Convert.ToDateTime(dtpFrwdDept.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
            else
            {
                MessageBox.Show("Forward To Department date cannot be less than Received On date");
                msk_dtpFrwdDept.Focus();
            }

        }
        private void dtpRecievedOn_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Delete)
            {
                if (sender is DateTimePicker)
                {
                    dtpRecievedOn.CustomFormat = " ";
                }
            }
        }
        private void dtpReview_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Delete)
            {
                if (sender is DateTimePicker)
                {
                    dtpReview.CustomFormat = " ";
                }
            }
        }
        private void dtpFrwdDept_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Delete)
            {
                if (sender is DateTimePicker)
                {
                    dtpFrwdDept.CustomFormat = " ";
                }
            }
        }
        private void button22_Click_1(object sender, EventArgs e)
        {
            if (lblDateID.Text == "")
            {
                return;
            }
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"DELETE FROM TenderDatesInfo WHERE DATE_ID = " + Convert.ToInt16(lblDateID.Text) + " ";
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Record Deleted Successfully");
                    }
                }
                ClearTP();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE DATES records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            GridViewRefresh_PTD();
        }
        private void ClearTP()
        {
            msk_dtpRecievedOn.Text = "";
            msk_dtpReview.Text = "";
            msk_dtpFrwdDept.Text = "";
            cmbAssignedQs.SelectedIndex = -1;
            cmbPurpose.SelectedIndex = -1;
            cmbQsWorkingStatus.SelectedIndex = -1;
            cmbAssignedQs.Text = "";
            cmbTenderDocStatus.SelectedIndex = -1;
            txtRemarks.Text = "";
            lblDateID.Text = "";
            chkUpdateStatus = false;
        }
        private void button23_Click_1(object sender, EventArgs e)
        {
            ClearTP();
        }
        private void dtpRecievedOn_FormatChanged(object sender, EventArgs e)
        {
            dtpRecievedOn.CustomFormat = "dd/MMM/yyyy";
        }


        private void dgvTE_Sent_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (mUserRightsColl.Contains("21"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            int rowIndex = e.RowIndex;
            try
            {
                if (rowIndex != -1)
                {
                 
                    if (dgvTE_Sent.Rows[rowIndex].Cells[0].Value.ToString() != "")
                    {
                        int docId = Convert.ToInt16(dgvTE_Sent.Rows[rowIndex].Cells[0].Value);
                        SentDocProperties sendDoc = null;
                        if (dgvTE_Sent.Rows[rowIndex].Cells[1].Value.ToString() != "")
                            sendDoc = new SentDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), txtProjCode.Text, docId, 3, _userName, dgvTE_Sent.Rows[rowIndex].Cells[0].Value, 'Y', mIsHeadOfSection);
                        else
                            sendDoc = new SentDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), txtProjCode.Text, docId, 3, _userName, "", 'Y', mIsHeadOfSection);
                        sendDoc.StartPosition = FormStartPosition.CenterParent;
                        sendDoc.ShowDialog();

                        commCls.FillGridSentDocsInfo(Convert.ToInt16(lblProjID.Text), dgvTE_Sent, 3);
                    }                    
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void dgvTE_Rec_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (mUserRightsColl.Contains("21"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            int rowIndex = e.RowIndex;
            try
            {
                if (rowIndex != -1)
                {
                    if (dgvTE_Rec.Rows[rowIndex].Cells[3].Value.ToString() != "")
                    {
                        int docId = Convert.ToInt16(dgvTE_Rec.Rows[rowIndex].Cells[3].Value);
                        ReceivedDocProperties receivedDoc = new ReceivedDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), txtProjCode.Text, docId, 3, _userName);
                        receivedDoc.StartPosition = FormStartPosition.CenterParent;
                        receivedDoc.ShowDialog();

                        commCls.FillGridReceivedDocsInfo(Convert.ToInt16(lblProjID.Text), dgvTE_Rec, 3);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void dgvTS_Rec_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (mUserRightsColl.Contains("20"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            int rowIndex = e.RowIndex;
            try
            {
                if (rowIndex != -1)
                {
                    if (dgvTS_Rec.Rows[rowIndex].Cells[3].Value.ToString() != "")
                    {
                        int docId = Convert.ToInt16(dgvTS_Rec.Rows[rowIndex].Cells[3].Value);
                        ReceivedDocProperties receivedDoc = new ReceivedDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), txtProjCode.Text, docId, 2, _userName);
                        receivedDoc.StartPosition = FormStartPosition.CenterParent;
                        receivedDoc.ShowDialog();
                        commCls.FillGridReceivedDocsInfo(Convert.ToInt16(lblProjID.Text), dgvTS_Rec, 2);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void dgvTS_Sent_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (mUserRightsColl.Contains("20"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            int rowIndex = e.RowIndex;
            try
            {
                if (rowIndex != -1)
                {
                    if (dgvTS_Sent.Rows[rowIndex].Cells[0].Value.ToString() != "")
                    {
                        int docId = Convert.ToInt16(dgvTS_Sent.Rows[rowIndex].Cells[0].Value);
                        SentDocProperties sentDoc = new SentDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), txtProjCode.Text, docId, 2, _userName, dgvTS_Sent.Rows[rowIndex].Cells[1].Value, 'Y', mIsHeadOfSection);
                        sentDoc.StartPosition = FormStartPosition.CenterParent;
                        sentDoc.ShowDialog();
                        commCls.FillGridSentDocsInfo(Convert.ToInt16(lblProjID.Text), dgvTS_Sent, 2);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void dgvCP_Sent_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (mUserRightsColl.Contains("20"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            int rowIndex = e.RowIndex;
            try
            {
                if (rowIndex != -1)
                {
                    if (dgvCP_Sent.Rows[rowIndex].Cells[0].Value.ToString() != "")
                    {
                        int docId = Convert.ToInt16(dgvCP_Sent.Rows[rowIndex].Cells[0].Value);
                        SentDocProperties sentDoc = new SentDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), txtProjCode.Text, docId, 4, _userName, dgvCP_Sent.Rows[rowIndex].Cells[1].Value, 'Y', mIsHeadOfSection);
                        sentDoc.StartPosition = FormStartPosition.CenterParent;
                        sentDoc.ShowDialog();
                        commCls.FillGridSentDocsInfo(Convert.ToInt16(lblProjID.Text), dgvCP_Sent, 4);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void cmbTenderDocStatus_Leave(object sender, EventArgs e)
        {
            if (cmbQsWorkingStatus.SelectedIndex == -1)
            {
                cmbQsWorkingStatus.Focus();
                MessageBox.Show("Please Select QsWorking Status");
                cmbTenderDocStatus.SelectedIndex = -1;
                return;
            }
        }
        private void msk_dtpEA_datesent_Leave(object sender, EventArgs e)
        {
            if (msk_dtpEA_datesent.Text != "")
            {
                if (ValidateDate(msk_dtpEA_datesent) == false)
                {
                    msk_dtpEA_datesent.Text = "";
                    msk_dtpEA_datesent.Focus();
                    return;
                }

                if (msk_dtpEA_stage1.Text == "")
                {
                    msk_dtpEA_datesent.Text = "";
                    msk_dtpEA_datesent.Focus();
                    MessageBox.Show("Tender Closing Date in Tender Stage is not updated. Please Update this prior to this field.");
                    return;
                }
                if (msk_dtpEA_stage1.Text != "")
                {
                    if (Convert.ToDateTime(msk_dtpEA_datesent.Text) < Convert.ToDateTime(msk_dtpEA_stage1.Text))
                    {
                        msk_dtpEA_stage2.Text = "";
                        msk_dtpEA_stage2.Focus();
                        MessageBox.Show("Date entered is earlier than Tender Closing Date. Please check and revise your entry.");
                        return;
                    }
                }
            }
        }
        private void msk_dtpEA_daterec_Leave(object sender, EventArgs e)
        {
            if (msk_dtpEA_daterec.Text != "")
            {
                if (ValidateDate(msk_dtpEA_daterec) == false)
                {
                    msk_dtpEA_daterec.Text = "";
                    msk_dtpEA_daterec.Focus();
                    return;
                }

                if (msk_dtpEA_datesent.Text == "")
                {
                    msk_dtpEA_daterec.Text = "";
                    msk_dtpEA_daterec.Focus();
                    MessageBox.Show("Update the Sent Date before updating this field.");
                    return;
                }
                if (Convert.ToDateTime(msk_dtpEA_datesent.Text) > Convert.ToDateTime(msk_dtpEA_daterec.Text))
                {
                    msk_dtpEA_daterec.Text = "";
                    msk_dtpEA_daterec.Focus();
                    MessageBox.Show("Date entered is earlier than Date Sent. Please check and revise your entry.");
                    return;
                }
            }
        }
        private void msk_dtpEA_datesentfin_Leave(object sender, EventArgs e)
        {

            if (msk_dtpEA_datesentfin.Text != "")
            {
                if (ValidateDate(msk_dtpEA_datesentfin) == false)
                {
                    msk_dtpEA_datesentfin.Text = "";
                    msk_dtpEA_datesentfin.Focus();
                    return;
                }
            }

            if (msk_dtpEA_datesentfin.Text != "")
            {
                if (msk_dtpEA_stage1.Text == "")
                {
                    msk_dtpEA_datesentfin.Text = "";
                    msk_dtpEA_datesentfin.Focus();
                    MessageBox.Show("Update the Sent Date before updating this field.");
                    return;
                }
                //if (msk_dtpEA_closeDate.Text != "")
                //{
                //    if (Convert.ToDateTime(msk_dtpEA_datesentfin.Text) < Convert.ToDateTime(msk_dtpEA_stage1.Text))
                //    {
                //        msk_dtpEA_datesentfin.Text = "";
                //        msk_dtpEA_datesentfin.Focus();
                //        MessageBox.Show("Date entered is earlier than Closing Date. Please check and revise your entry.");
                //        return;
                //    }
                //}
                if (msk_dtpEA_stage1.Text != "")
                {
                    if (Convert.ToDateTime(msk_dtpEA_datesentfin.Text) < Convert.ToDateTime(msk_dtpEA_stage1.Text))
                    {
                        msk_dtpEA_datesentfin.Text = "";
                        msk_dtpEA_datesentfin.Focus();
                        MessageBox.Show("Date entered is earlier than Closing Date. Please check and revise your entry.");
                        return;
                    }
                }
            }
        }
        private void msk_dtpEA_daterecFin_Leave(object sender, EventArgs e)
        {
            if (msk_dtpEA_daterecFin.Text != "")
            {
                if (ValidateDate(msk_dtpEA_daterecFin) == false)
                {
                    msk_dtpEA_daterecFin.Text = "";
                    msk_dtpEA_daterecFin.Focus();
                    return;
                }
                if (msk_dtpEA_datesentfin.Text == "")
                {
                    msk_dtpEA_daterecFin.Text = "";
                    msk_dtpEA_datesentfin.Focus();
                    MessageBox.Show("Update the Sent Date before updating this field");
                    return;
                }
                if (Convert.ToDateTime(msk_dtpEA_datesentfin.Text) > Convert.ToDateTime(msk_dtpEA_daterecFin.Text))
                {
                    msk_dtpEA_daterecFin.Text = "";
                    msk_dtpEA_datesentfin.Focus();
                    MessageBox.Show("Date entered is earlier than Date Sent. Please check and revise your entry.");
                    return;
                }
            }
        }
        private void msk_dtpEA_apprDate_Leave(object sender, EventArgs e)
        {
            if (msk_dtpEA_apprDate.Text != "")
            {
                if (ValidateDate(msk_dtpEA_apprDate) == false)
                {
                    msk_dtpEA_apprDate.Text = "";
                    msk_dtpEA_apprDate.Focus();
                    return;
                }
                if (msk_dtpEA_daterec.Text == "")
                {
                    msk_dtpEA_apprDate.Text = "";
                    msk_dtpEA_apprDate.Focus();
                    MessageBox.Show("Update Date Received for Financial Evaluation before entering data in the field.");
                    return;
                }
                if (Convert.ToDateTime(msk_dtpEA_daterec.Text) > Convert.ToDateTime(msk_dtpEA_apprDate.Text))
                {
                    msk_dtpEA_apprDate.Text = "";
                    msk_dtpEA_apprDate.Focus();
                    MessageBox.Show("Date entered is earlier than Technical Evaluation Received date. Please Check and revise your entry. ");
                    return;
                }
            }
        }

        private void msk_dtpFrwdDept_Leave(object sender, EventArgs e)
        {
            Control ctrl = sender as Control;
            if (ValidateDate(ctrl) == false)
            {
                msk_dtpFrwdDept.Text = "";
                msk_dtpFrwdDept.Focus();
                return;
            }

            if (msk_dtpFrwdDept.Text != "")
            {
                if (Convert.ToDateTime(msk_dtpRecievedOn.Text) > Convert.ToDateTime(msk_dtpFrwdDept.Text))
                {
                    msk_dtpFrwdDept.Text = "";
                    msk_dtpFrwdDept.Focus();
                    MessageBox.Show("The date entered cannot be less than the date in 'Received On'.Please check the date");
                    return;
                }
                if (cmbQsWorkingStatus.SelectedIndex == -1)
                {
                    msk_dtpFrwdDept.Text = "";
                    cmbQsWorkingStatus.Focus();
                    MessageBox.Show("Please update 'QS Working Status' before entering a date.");
                    return;
                }
                if (cmbTenderDocStatus.SelectedIndex == -1)
                {
                    msk_dtpFrwdDept.Text = "";
                    cmbTenderDocStatus.Focus();
                    MessageBox.Show("Please update 'Tender Document Current Status' before entering a date.");
                    return;
                }

            }
        }


        private void GetTenderStageClosingDates()
        {
            SqlConnection sqlConn = new SqlConnection(connStr);
            sqlConn.Open();
            sqlCom = new SqlCommand("SELECT ts_closing_s1,ts_closing_s2,ts_modified_closing FROM TenderDatesInfo Where proj_id = " + _projID + " and stage_id = 2 AND (ts_tender_issue IS NULL)", sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            if (sqlReader.HasRows)
            {
                while (sqlReader.Read())
                {
                    if (sqlReader[0].ToString() != "")
                    {
                        DateTime dt_dtpEA_stage1 = Convert.ToDateTime(sqlReader[0].ToString());
                        msk_dtpEA_stage1.Text = dt_dtpEA_stage1.ToString("dd-MMM-yyyy", CultureInfo.InvariantCulture);
                    }
                    if (sqlReader[1].ToString() != "")
                    {
                        DateTime dt_dtpEA_stage2 = Convert.ToDateTime(sqlReader[1].ToString());
                        msk_dtpEA_stage2.Text = dt_dtpEA_stage2.ToString("dd-MMM-yyyy", CultureInfo.InvariantCulture);
                    }
                    if (sqlReader[2].ToString() != "")
                    {
                        DateTime dt_dtpEA_closeDate = Convert.ToDateTime(sqlReader[2].ToString());
                        msk_dtpEA_closeDate.Text = dt_dtpEA_closeDate.ToString("dd-MMM-yyyy", CultureInfo.InvariantCulture);
                    }
                }
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        bool bblink = true;
        private void timer1_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (txtTenderNo.Text != "")
            {
                if (bblink)
                {
                    txtTenderNo.BackColor = Color.Blue;
                    txtTenderNo.ForeColor = Color.Red;
                }
                else
                {
                    txtTenderNo.BackColor = Color.Red;
                    txtTenderNo.ForeColor = Color.Blue;
                }
            }
            bblink = !bblink;
        }

        private void TE_AdminRigts()
        {
            if (mUserRightsColl.Contains("35"))
            {
                lblTE_bdgtAmt.Visible = false;
                lblTE_estimateAmnt.Visible = false;

                txtBudjetAmnt.Visible = false;
                txtEstimatedAmnt.Visible = false;
            }
            else
            {
                if (mUserRightsColl.Contains("36"))
                {
                    lblBondAmt.Visible = true;
                    lblDocAmt.Visible = true;
                    txtBudjetAmnt.Enabled = false;
                    txtEstimatedAmnt.Enabled = false;
                }
                else
                {
                    lblBondAmt.Visible = true;
                    lblDocAmt.Visible = true;
                    txtBudjetAmnt.Visible = true;
                    txtEstimatedAmnt.Visible = true;
                }
            }

        }
        private void TE_Validate(int dateId)
        {
            if (msk_dtpEA_reqdate.Text != "" && isCpContractorSign == false)
            {
                DateTime dt_dtpEA_OpenDate = Convert.ToDateTime(msk_dtpEA_reqdate.Text, CultureInfo.InvariantCulture);
                msk_dtpTV_OrgDate.Text = dt_dtpEA_OpenDate.AddDays(90).ToString("dd/MMM/yyyy");

                int iDays = 0;
                if (msk_dtpTV_SEdate.Text != "")
                {
                    iDays = (Convert.ToDateTime(msk_dtpTV_SEdate.Text) - System.DateTime.Now.Date).Days;
                    txtTV_exipre.Text = iDays.ToString();
                }
                else if (msk_dtpTV_FEdate.Text != "")
                {
                    iDays = (Convert.ToDateTime(msk_dtpTV_FEdate.Text) - System.DateTime.Now.Date).Days;
                    txtTV_exipre.Text = iDays.ToString();
                }
                else if (msk_dtpTV_OrgDate.Text != "")
                {
                    iDays = (Convert.ToDateTime(msk_dtpTV_OrgDate.Text) - System.DateTime.Now.Date).Days;
                    txtTV_exipre.Text = iDays.ToString();
                }
                clsForTS.UpdateTV_Original_Extension(iDays, tndrDate_ID);
            }

            if (msk_dtpEA_closeDate.Text != "" && isCpContractorSign == false)
            {
                DateTime dt_dtpEA_closeDate = Convert.ToDateTime(msk_dtpEA_closeDate.Text);
                msk_dtpTBV_OrgDate.Text = dt_dtpEA_closeDate.AddDays(120).ToString("dd/MMM/yyyy");

                int iDays = 0;
                if (msk_dtpTBV_SEdate.Text != "")
                {
                    iDays = (Convert.ToDateTime(msk_dtpTBV_SEdate.Text) - System.DateTime.Now.Date).Days;
                    txtTBV_exipre.Text = iDays.ToString();
                }
                else if (msk_dtpTBV_FEdate.Text != "")
                {
                    iDays = (Convert.ToDateTime(msk_dtpTBV_FEdate.Text) - System.DateTime.Now.Date).Days;
                    txtTBV_exipre.Text = iDays.ToString();
                }
                else if (msk_dtpTBV_OrgDate.Text != "")
                {
                    iDays = (Convert.ToDateTime(msk_dtpTBV_OrgDate.Text) - System.DateTime.Now.Date).Days;
                    txtTBV_exipre.Text = iDays.ToString();
                }
                clsForTS.UpdateTBV_Original_Extension(iDays, tndrDate_ID);
            }
            else if (msk_dtpEA_stage1.Text != "" && isCpContractorSign == false)
            {
                DateTime dt_dtpEA_stgeDate = Convert.ToDateTime(msk_dtpEA_stage1.Text);
                msk_dtpTBV_OrgDate.Text = dt_dtpEA_stgeDate.AddDays(120).ToString("dd/MMM/yyyy");

                int iDays = 0;
                if (msk_dtpTBV_SEdate.Text != "")
                {
                    iDays = (Convert.ToDateTime(msk_dtpTBV_SEdate.Text) - System.DateTime.Now.Date).Days;
                    txtTBV_exipre.Text = iDays.ToString();
                }
                else if (msk_dtpTBV_FEdate.Text != "")
                {
                    iDays = (Convert.ToDateTime(msk_dtpTBV_FEdate.Text) - System.DateTime.Now.Date).Days;
                    txtTBV_exipre.Text = iDays.ToString();
                }
                else if (msk_dtpTBV_OrgDate.Text != "")
                {
                    iDays = (Convert.ToDateTime(msk_dtpTBV_OrgDate.Text) - System.DateTime.Now.Date).Days;
                    txtTBV_exipre.Text = iDays.ToString();
                }
                clsForTS.UpdateTBV_Original_Extension(iDays, tndrDate_ID);
            }
        }

        private void TS_Validate()
        {
            if (mUserRightsColl.Contains("35"))
            {
                lblBondAmt.Visible = false;
                lblDocAmt.Visible = false;

                txtTenderBond.Visible = false;
                txtDocumentFee.Visible = false;
            }
            else
            {
                if (mUserRightsColl.Contains("36"))
                {
                    lblBondAmt.Visible = true;
                    lblDocAmt.Visible = true;
                    txtTenderBond.Enabled = false;
                    txtDocumentFee.Enabled = false;
                }
                else
                {
                    lblBondAmt.Visible = true;
                    lblDocAmt.Visible = true;
                    txtTenderBond.Visible = true;
                    txtDocumentFee.Visible = true;
                }
            }

            if (txtTenderNo.Text != "")
            {
                btnAssignTender.Visible = false;
            }
            else
            {
                btnAssignTender.Visible = true;
            }
        }

        private void CP_AdminRights()
        {
            if (mUserRightsColl.Contains("35"))
            {
                lblCP_bdgtAmnt.Visible = false;
                lblCP_estimateAmnt.Visible = false;

                txtCp_BudgetAmnt.Visible = false;
                txtCp_EstimatedAmnt.Visible = false;
            }
            else
            {
                if (mUserRightsColl.Contains("36"))
                {
                    lblCP_bdgtAmnt.Visible = true;
                    lblCP_estimateAmnt.Visible = true;
                    txtCp_BudgetAmnt.Enabled = false;
                    txtCp_EstimatedAmnt.Enabled = false;
                }
                else
                {
                    lblCP_bdgtAmnt.Visible = true;
                    lblCP_estimateAmnt.Visible = true;
                    txtCp_BudgetAmnt.Visible = true;
                    txtCp_EstimatedAmnt.Visible = true;
                }
            }
        }
        private void PC_AdminRights()
        {
            if (mUserRightsColl.Contains("35"))
            {
                lblPC_bdgtAmnt.Visible = false;
                lblPc_EstAmnt.Visible = false;

                txtPC_BudjetAmnt.Visible = false;
                txtPC_EstimatedAmnt.Visible = false;
            }
            else
            {
                if (mUserRightsColl.Contains("36"))
                {
                    lblPC_bdgtAmnt.Visible = true;
                    lblPc_EstAmnt.Visible = true;
                    txtPC_BudjetAmnt.Enabled = false;
                    txtPC_EstimatedAmnt.Enabled = false;
                }
                else
                {
                    lblPC_bdgtAmnt.Visible = true;
                    lblPc_EstAmnt.Visible = true;
                    txtPC_BudjetAmnt.Visible = true;
                    txtPC_EstimatedAmnt.Visible = true;
                }
            }
        }
        private void getEligibleTypes(ref bool isOnLoad)
        {
            try
            {
                clsDatabase clsDb = new clsDatabase(connStr);
                clsDb.ConnectDB();
                strEligibleTenderTypes = clsDb.ExecuteReader("select EligibleTenderTypes from PROJECTS where proj_id=" + _projID);
                clsDb.DisconnectDB();
                short loopCounter = 0;
                if (strEligibleTenderTypes != "")
                {
                    string[] strArrayTenderTypes = strEligibleTenderTypes.Split(',');
                    if (strArrayTenderTypes.Length > 0)
                    {
                        chkLocal.Checked = false;
                        chkInternational.Checked = false;
                        chkJointVenture.Checked = false;
                        while (loopCounter < strArrayTenderTypes.Length)
                        {
                            if (strArrayTenderTypes[loopCounter].ToString() == "Local")
                                chkLocal.Checked = true;

                            else if (strArrayTenderTypes[loopCounter].ToString() == "International")
                                chkInternational.Checked = true;

                            else if (strArrayTenderTypes[loopCounter].ToString() == "Joint Venture")
                                chkJointVenture.Checked = true;

                            loopCounter++;
                        }
                    }
                    else
                    {
                        if (strEligibleTenderTypes == "Local")
                            chkLocal.Checked = true;
                        else if (strEligibleTenderTypes == "International")
                            chkInternational.Checked = true;
                        else if (strEligibleTenderTypes == "Joint Venture")
                            chkJointVenture.Checked = true;

                    }
                }
                isOnLoad = true;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while retrieving Project type", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void PopulatingVariousStagesTabControlsOfProject()
        {
            // Direct Award Approval Date
            DAL dataLyr = new DAL();
            if (tabControl1.SelectedTab.Name == "ptdTabPage")
            {
                commCls.FillGridReceivedDocsInfo(_projID, dgvPTD_Rec, 1);
                commCls.FillGridSentDocsInfo(_projID, dgvPTD_Sent, 1);               
            }
            else if (tabControl1.SelectedTab.Name == "tsTabPage")
            {
                TS_Validate();                
                saveChk = false;

                saveChk = FillTenderStageInfo(ref dateID_Ts, ref mdfExistDate);     //Sree

                FillTender_ModifiedDates();

                if (msk_dtp_tsRecOn.Text == "" && msk_dtp_tsStage1.Text == "")
                {
                    btnIssueTender.Visible = true;
                }

                FillProjectCostDetailsOfTenderStage();

                int _bidCnt = clsForTS.GetbidderCount(_projID);
                if (_bidCnt != 0)
                {
                    btnViewBidder.Visible = true;
                    btnExportToPdf.Visible = true;
                    lblTotCircularIssued.Visible = true;
                    lblTotNoBidders.Visible = true;
                    txtCircular.Visible = true;
                    txt_bidders.Visible = true;
                }

                if (_tndrType == "L" || _tndrType == "DO")
                {
                    _chGetShortListed = 'Y';
                    int _totShortListCount = clsForTS.GetShortListCount(_projID);
                    if (_totShortListCount != 0)
                    {
                        btnViewShortList.Visible = true;
                        lblCompaniesInShortList.Visible = true;
                        txtTotCompInShortList.Visible = true;
                        txtTotCompInShortList.Text = _totShortListCount.ToString();
                    }
                    else
                    {
                        btnViewShortList.Visible = false;
                        lblCompaniesInShortList.Visible = false;
                        txtTotCompInShortList.Visible = false;
                        txtTotCompInShortList.Visible = false;
                    }
                }

                int _circularCnt = clsForTS.GetCircularCount(_projID);

                txt_bidders.Text = _bidCnt.ToString();
                txtCircular.Text = _circularCnt.ToString();

                getEligibleTypes(ref isOnLoad);

                commCls.FillGridReceivedDocsInfo(_projID, dgvTS_Rec, 2);
                commCls.FillGridSentDocsInfo(_projID, dgvTS_Sent, 2);               

                // Added by sreedhar on jan 26th 2014

                getData(ProjectId);

                if ((_userName.Equals("ceba_sjoy")) || (_userName.Equals("ceba_mfaisal")) || (_userName.Equals("ebsd_svadakapuram")) || (_userName.Equals("ceba_mriyas")))
                {
                    txtCmpType.Visible = true;
                    lbltype.Visible = true;
                    btnClk.Visible = true;
                }

            }
            else if (tabControl1.SelectedTab.Name == "teaTabPage")
            {
                EnableTabs_BasedOn_UserRights(); // Added by Varun on 6 Feb 2014 for checking if Tender_Status_id is (7,14,15) if yes then do not calculate and display expiry days
                TE_AdminRigts();
                saveTEAChk = false;
                FillCp_ContractsInformation();                 //Sree
                saveTEAChk = FillTenderEvaluationInfo(ref dateID_TEA);
                FillProjectCostDetailsOfTenderEvaluation();
                GetTenderStageClosingDates();
                Get_original_TenderDates();

                if (mUserRightsColl.Contains("70") && txtTenderNo.Text != "")
                {
                    btnTenderSubmission.Visible = false;                     
                }
                else if (!(mUserRightsColl.Contains("70")) && txtTenderNo.Text != "")
                {
                    btnTenderSubmission.Visible = true;
                    //btnWOTenderSubmission.Visible = true;
                }
                else if (mUserRightsColl.Count == 0 && txtTenderNo.Text != "") //Added by Varun on 16 May 2014 based on new TenderSubmission requirement                                 
                {
                    btnTenderSubmission.Visible = true;
                    //btnWOTenderSubmission.Visible = true;
                }
                //if ((msk_dtpEA_stage1.Text != "" && Convert.ToDateTime(msk_dtpEA_stage1.Text) <= Convert.ToDateTime(DateTime.Now.ToShortDateString())) || (msk_dtpEA_closeDate.Text != "" && Convert.ToDateTime(msk_dtpEA_closeDate.Text) <= Convert.ToDateTime(DateTime.Now.ToShortDateString())))

                //else
                //    btnTenderSubmission.Visible = false;

                if (isCpContractorSign == false)
                {
                    GetExtendDates();   // Function read Validate extend dates                     
                    TE_Validate(tndrDate_ID);
                    //GetTenderExpiryDays_UpdateDays(tndrDate_ID);
                }
                //Get_original_TenderDates();

                commCls.FillGridReceivedDocsInfo(_projID, dgvTE_Rec, 3);
                commCls.FillGridSentDocsInfo(_projID, dgvTE_Sent, 3);
                 
            }
            else if (tabControl1.SelectedTab.Name == "cpTabPage")
            {               
                CP_AdminRights();
                FillContractsProcessData();                 
                commCls.FillGridReceivedDocsInfo(_projID, dgvCP_Rec, 4);
                commCls.FillGridSentDocsInfo(_projID, dgvCP_Sent, 4);                
                FillProjectCostDetailsOfContractProcess();

            }
            else if (tabControl1.SelectedTab.Name == "pcsTabPage")
            {
                PC_AdminRights();
                if (dgvPC_Contracts.ColumnCount > 0)
                    clspC.refreshPCContracts_Data(dgvPC_Contracts, _projID);
                else
                    clspC.FillPostContractInformation(dgvPC_Contracts, _projID);

                if (dgvPC.ColumnCount == 0)
                {
                    clspC.CreatePostContractGridColumns(dgvPC);
                    clspC.FillPostContractsData(dgvPC, _projID);
                }
                else
                    clspC.FillPostContractsData(dgvPC, _projID);


                if (dgvPC.Rows.Count != 0)
                    //txtPC_Remarks.Text = dgvPC.Rows[0].Cells[3].Value.ToString();

                    dgvPC_Contracts.Columns[8].Visible = false;

                FillProjectCostDetailsOfPostContract();
            }
        }

        string mdfExistDate = string.Empty;

        private void tabControl1_MouseClick(object sender, MouseEventArgs e)           //sree
        {
            PopulatingVariousStagesTabControlsOfProject();
        }

        int tndrDate_ID = 0;
        private void Get_original_TenderDates()
        {
            // if (msk_dtpTV_OrgDate.Text != "")

            DateTime? validityDate;
            validityDate = null;

            DateTime? bondValidityDate;
            bondValidityDate = null;

            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {

                sqlConn.Open();
                SqlCommand sqlCom = new SqlCommand("SELECT org_tender_validity,org_tenderbond_validity,date_ID FROM TenderDatesInfo Where proj_id = " + _projID + " and stage_id = 2 and ts_tender_issue is null", sqlConn);
                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    if (sqlReader.HasRows)
                    {
                        while (sqlReader.Read())
                        {
                            if (sqlReader[0].ToString() != "")
                            {
                                validityDate = Convert.ToDateTime(sqlReader[0].ToString());
                                msk_dtpTV_OrgDate.Text = validityDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture);
                                //msk_dtpTV_FEdate.Text = dt_dtpEA_TV_FstExt.ToString("dd/MMM/yyyy");
                            }
                            if (sqlReader[1].ToString() != "")
                            {
                                bondValidityDate = Convert.ToDateTime(sqlReader[1].ToString());
                                msk_dtpTBV_OrgDate.Text = bondValidityDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture);
                            }

                            tndrDate_ID = Convert.ToInt16(sqlReader[2].ToString());
                        }
                    }
                }
            }
            // Delete the code which will update the tender bond validity dates, because not required to retrieve and then update by Varun 5 Feb 2014

        }
        private void Update_tenderValidityDate(int _dateID_vldty)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"UPDATE TenderDatesInfo SET [org_tender_validity]= @originalValidityDate Where date_id=@dateId";
                        cmd.Parameters.AddWithValue("@dateId", _dateID_vldty);
                        cmd.Parameters.AddWithValue("@originalValidityDate", Convert.ToDateTime(msk_dtpTV_OrgDate.Text));
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void Update_tender_BondValidityDate(int _dateID_Bondvldty)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"UPDATE TenderDatesInfo SET [org_tenderbond_validity]= @originalBondValidityDate Where date_id=@dateId";
                        cmd.Parameters.AddWithValue("@dateId", _dateID_Bondvldty);
                        cmd.Parameters.AddWithValue("@originalBondValidityDate", Convert.ToDateTime(msk_dtpTBV_OrgDate.Text));
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void GetExtendDates()
        {
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                sqlConn.Open();
                SqlCommand sqlCom = new SqlCommand("SELECT tender_validity_ext1,tender_validity_ext2,tenderbond_validity_ext1,tenderbond_validity_ext2 FROM TenderDatesInfo Where proj_id = " + _projID + " and stage_id = 2 and ts_tender_issue is null", sqlConn);
                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    if (sqlReader.HasRows)
                    {
                        while (sqlReader.Read())
                        {
                            if (sqlReader[0].ToString() != "")
                            {
                                DateTime dt_dtpEA_TV_FstExt = Convert.ToDateTime(sqlReader[0].ToString());
                                msk_dtpTV_FEdate.Text = dt_dtpEA_TV_FstExt.ToString("dd/MMM/yyyy");
                            }
                            if (sqlReader[1].ToString() != "")
                            {
                                DateTime dt_dtpEA_TV_LstExt = Convert.ToDateTime(sqlReader[1].ToString());
                                msk_dtpTV_SEdate.Text = dt_dtpEA_TV_LstExt.ToString("dd/MMM/yyyy");
                            }
                            if (sqlReader[2].ToString() != "")
                            {
                                DateTime dt_dtpEA_TBV_FstExt = Convert.ToDateTime(sqlReader[2].ToString());
                                msk_dtpTBV_FEdate.Text = dt_dtpEA_TBV_FstExt.ToString("dd/MMM/yyyy");
                            }
                            if (sqlReader[3].ToString() != "")
                            {
                                DateTime dt_dtpEA_TBV_LstExt = Convert.ToDateTime(sqlReader[3].ToString());
                                msk_dtpTBV_SEdate.Text = dt_dtpEA_TBV_LstExt.ToString("dd/MMM/yyyy");
                            }
                        }
                    }
                }
            }
        }


        private void GetTenderExpiryDays_UpdateDays(int dateID)
        {
            if (msk_dtpTV_OrgDate.Text != "" && isCpContractorSign == false)
            {
                // Modified by Varun on 05 Feb 2014 because txtTBV_exipre.Text==""
                if (txtTBV_exipre.Text != "")
                {
                    int expiryDays = Convert.ToInt16(txtTV_exipre.Text);
                    // modified function params by Varun on 05 Feb 2014 because projId not required
                    // commented by varun on 5 Feb 2014 because no need to update immediately after retrieving
                    clsForTS.UpdateTV_Original_Extension(expiryDays, dateID);
                }

            }
            if (msk_dtpTBV_OrgDate.Text != "" && isCpContractorSign == false)
            {
                // Modified by Varun on 05 Feb 2014 because txtTBV_exipre.Text==""
                if (txtTBV_exipre.Text != "")
                {
                    int bond_ExpiryDays = Convert.ToInt16(txtTBV_exipre.Text);
                    // modified function params by Varun on 05 Feb 2014 because projId not required
                    // commented by varun on 5 Feb 2014 because no need to update immediately after retrieving
                    clsForTS.UpdateTBV_Original_Extension(bond_ExpiryDays, dateID);
                }
            }
        }




        private void txtTenderBond_Leave(object sender, EventArgs e)
        {
            if (txtTenderBond.Text != "")
            {
                if (clsForTE.CheckProjectCostDataExist(_projID) == false)
                {
                    clsForTS.InsertTS_TenderBond_ProjectCostData(txtTenderBond.Text, _projID);
                }
                else
                {
                    clsForTS.UpdateTS_TenderBond_ProjectCostData(txtTenderBond.Text, _projID);
                }
                txtTenderBond.Text = string.Format("{0:#,##0.00}", double.Parse(txtTenderBond.Text));
            }
            else
            {
                clsForTS.UpdateTS_TenderBond_ProjectCostData(txtTenderBond.Text, _projID);
            }
        }


        private void txtDocumentFree_Leave(object sender, EventArgs e)
        {
            if (txtDocumentFee.Text != "")
            {
                if (clsForTE.CheckProjectCostDataExist(_projID) == false)
                {
                    clsForTS.InsertTS_DocFee_ProjectCostData(txtDocumentFee.Text, _projID);
                }
                else
                {
                    clsForTS.UpdateTS_DocFee_ProjectCostData(txtDocumentFee.Text, _projID);
                }
                txtDocumentFee.Text = string.Format("{0:#,##0.00}", double.Parse(txtDocumentFee.Text));
            }
            else
                clsForTS.UpdateTS_DocFee_ProjectCostData(txtDocumentFee.Text, _projID);
        }



        private bool nonNumberEntered = false;

        private void btnPC_Click(object sender, EventArgs e)
        {

            if (mUserRightsColl.Contains("52"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            //Added by Varun on 27 Dec 2015
            if (dgvPC.Rows[0].Cells[0].Value !=null)
                fillStage6(); // For PostContract Stage                       
            else
                MessageBox.Show("Staff Incharge cannot be left blank");
            
        }

        private void txtPC_BudjetAmnt_Leave(object sender, EventArgs e)
        {
            if (txtPC_BudjetAmnt.Text != "")
            {
                if (clsForTE.CheckProjectCostDataExist(_projID) == false)
                {
                    clsForTE.InsertTE_Budget_ProjectCostData(txtPC_BudjetAmnt.Text, _projID);
                }
                else
                {
                    clsForTE.UpdateTE_BudgetAmount_ProjectCostData(txtPC_BudjetAmnt.Text, _projID);
                }
                txtPC_BudjetAmnt.Text = string.Format("{0:#,##0.00}", double.Parse(txtPC_BudjetAmnt.Text));
            }
            else
                clsForTE.UpdateTE_BudgetAmount_ProjectCostData(txtPC_BudjetAmnt.Text, _projID);
        }
        private void txtPC_EstimatedAmnt_Leave(object sender, EventArgs e)
        {
            if (txtPC_EstimatedAmnt.Text != "")
            {
                if (clsForTE.CheckProjectCostDataExist(_projID) == false)
                {
                    clsForTE.InsertTE_Estimate_ProjectCostData(txtPC_EstimatedAmnt.Text, _projID);
                }
                else
                {
                    clsForTE.UpdateTE_Estimate_ProjectCostData(txtPC_EstimatedAmnt.Text, _projID);
                }
                txtPC_EstimatedAmnt.Text = string.Format("{0:#,##0.00}", double.Parse(txtPC_EstimatedAmnt.Text));
            }
            else
                clsForTE.UpdateTE_Estimate_ProjectCostData(txtPC_EstimatedAmnt.Text, _projID);
        }
        private void btnRecCp_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Contains("19"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }
            ReceivedDocProperties receivedDoc = new ReceivedDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), 4, _userName);
            receivedDoc.StartPosition = FormStartPosition.CenterParent;
            receivedDoc.ShowDialog();
            commCls.FillGridReceivedDocsInfo(Convert.ToInt16(lblProjID.Text), dgvCP_Rec, 4);
        }
        private void btnSentCp_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Contains("19"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }
            SentDocProperties sentDocProp = new SentDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), 4, _userName);
            sentDocProp.StartPosition = FormStartPosition.CenterParent;
            sentDocProp.ShowDialog();
            commCls.FillGridSentDocsInfo(Convert.ToInt16(lblProjID.Text), dgvCP_Sent, 4);
        }

        private void txtCp_BudgetAmnt_Leave(object sender, EventArgs e)
        {
            if (txtCp_BudgetAmnt.Text != "")
            {
                if (clsForTE.CheckProjectCostDataExist(_projID) == false)
                {
                    clsForTE.InsertTE_Budget_ProjectCostData(txtCp_BudgetAmnt.Text, _projID);
                }
                else
                {
                    clsForTE.UpdateTE_BudgetAmount_ProjectCostData(txtCp_BudgetAmnt.Text, _projID);
                }
                txtCp_BudgetAmnt.Text = string.Format("{0:#,##0.00}", double.Parse(txtCp_BudgetAmnt.Text));
            }
            else
                clsForTE.UpdateTE_BudgetAmount_ProjectCostData(txtCp_BudgetAmnt.Text, _projID);
        }
        private void txtCp_EstimatedAmnt_Leave(object sender, EventArgs e)
        {
            if (txtCp_EstimatedAmnt.Text != "")
            {
                if (clsForTE.CheckProjectCostDataExist(_projID) == false)
                {
                    clsForTE.InsertTE_Estimate_ProjectCostData(txtCp_EstimatedAmnt.Text, _projID);
                }
                else
                {
                    clsForTE.UpdateTE_Estimate_ProjectCostData(txtCp_EstimatedAmnt.Text, _projID);
                }
                txtCp_EstimatedAmnt.Text = string.Format("{0:#,##0.00}", double.Parse(txtCp_EstimatedAmnt.Text));
            }
            else
                clsForTE.UpdateTE_Estimate_ProjectCostData(txtCp_EstimatedAmnt.Text, _projID);
        }

        #region           // For PostContracts Data

        private void FillPostContractStaffData()
        {
            DataSet ds = new DataSet();
            string strQuery = "";
            strQuery = "Select employee_id,ShortName From Contacts Where ShortName <> '' order by shortname asc";
            try
            {
                using (SqlConnection sqlCn = new SqlConnection(connStr))
                {
                    sqlCn.Open();
                    using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                    {
                        SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                        sqlda.Fill(ds);
                    }
                }
            }
            catch (Exception ex)
            {

            }
            DataGridViewComboBoxColumn colCboxCategory = new DataGridViewComboBoxColumn();
            colCboxCategory.HeaderText = "Successfull Bidder";
            colCboxCategory.Width = 90;
            colCboxCategory.Name = "colBoc";
            colCboxCategory.DataSource = ds.Tables[0];
            colCboxCategory.ValueMember = "ShortName";
            colCboxCategory.DisplayMember = "ShortName";

            dgvPC.Columns.Add(colCboxCategory);

            CalendarColumn colFromDate = new CalendarColumn();
            colFromDate.HeaderText = "From Date";
            this.dgvPC.Columns.Add(colFromDate);

            CalendarColumn colTodDate = new CalendarColumn();
            colTodDate.HeaderText = "To Date";
            this.dgvPC.Columns.Add(colTodDate);

            DataSet ds1 = new DataSet();
            string strQuery1 = "";
            strQuery1 = "Select StaffInCharge,FromDate,ToDate From TenderDatesInfo Where Proj_ID = " + _projID + " and Stage_ID= 6 and employee_id IS NOT NULL";
            try
            {
                using (SqlConnection sqlCn = new SqlConnection(connStr))
                {
                    sqlCn.Open();
                    using (SqlCommand sqlCmd = new SqlCommand(strQuery1, sqlCn))
                    {
                        SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);

                        sqlda.Fill(ds1);
                    }
                }
            }
            catch (Exception ex)
            {

            }
            dgvPC.AllowUserToAddRows = false;

            dgvPC.Columns[0].DataPropertyName = "StaffIncharge";
            dgvPC.Columns[1].DataPropertyName = "FromDate";
            dgvPC.Columns[2].DataPropertyName = "ToDate";

            //  dataGridView1.Columns[3].DataPropertyName = "bidder_id";
            dgvPC.DataSource = ds1.Tables[0];             
        }
        void dgvPC_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            e.Cancel = true;
        }
        private void txtPC_BudjetAmnt_KeyDown(object sender, KeyEventArgs e)
        {
            nonNumberEntered = false;
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            {
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    if ((e.KeyCode != Keys.Back) & (e.KeyCode != Keys.Enter))
                    {
                        nonNumberEntered = true;
                    }
                }
            }


            //nonNumberEntered = false;
            //if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            //{
            //    if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
            //    {
            //        if ((e.KeyCode != Keys.Back) & (e.KeyCode != Keys.Enter))
            //        {
            //            nonNumberEntered = true;
            //        }
            //    }
            //}
        }

        private void txtPC_EstimatedAmnt_KeyDown(object sender, KeyEventArgs e)
        {
            nonNumberEntered = false;
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            {
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    if ((e.KeyCode != Keys.Back) & (e.KeyCode != Keys.Enter))
                    {
                        nonNumberEntered = true;
                    }
                }
            }
        }

        #endregion

        private void txtBudjetAmnt_KeyDown(object sender, KeyPressEventArgs e)
        {

            nonNumberEntered = false;


            //if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            //{
            //    if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
            //    {
            //        if ((e.KeyCode != Keys.Back) & (e.KeyCode != Keys.Enter) & e.KeyValue == 190)
            //        {
            //            nonNumberEntered = true;
            //        }
            //    }
            //}

            //if (txtBudjetAmnt.Text != "")
            //{
            //    Regex re = new Regex(@"^(0|(-?(((0|[1-9]\d*)\.\d+)|([1-9]\d*))))$");
            //    if (re.IsMatch(txtBudjetAmnt.Text) == false)
            //    {
            //        MessageBox.Show("Please enter double value only");
            //        txtBudjetAmnt.Text = "";
            //    }
            //}
        }


        # region

        // ================ Contract Process Tab Data Function==============================================================================================


        private void Status_ContractProcess()
        {
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    if (sqlConn.State == ConnectionState.Closed)
                        sqlConn.Open();
                    cmd.Connection = sqlConn;
                    cmd.CommandText = @"Update Projects set Tender_Status_id = @status,stage_id = @stgID where proj_id=@projId";
                    cmd.Parameters.AddWithValue("@projId", Convert.ToInt16(lblProjID.Text));
                    cmd.Parameters.AddWithValue("@status", 7);
                    cmd.Parameters.AddWithValue("@stgID", 4);

                    cmd.Parameters.AddWithValue("@update_date", DateTime.Now.ToString());
                    //cmd.Parameters.AddWithValue("@update_user", "");

                    int exUpdated = cmd.ExecuteNonQuery();

                    cmd.Parameters.Clear();
                }
            }
        }

        private void btnCP_Save_Click(object sender, EventArgs e)
        {
            // CPMultipleRecords_InsertUpdate();
            //CP_Contract_InsertUpdate(dgvContracts);
            CommonClass commCls = null;
            if (mUserRightsColl.Contains("48") && mUserRightsColl.Contains("50"))     // 50 for DA
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            if (dgvContracts.Rows[0].Cells[0].Value == null)
                return;
            if (dgvCpDataEntry.Rows[0].Cells[0].Value == null)
                return;

            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        if (sqlConn.State == ConnectionState.Closed)
                            sqlConn.Open();
                        cmd.Connection = sqlConn;
                        clsForCP.UpdateContractsData(dgvContracts, cmd, sqlConn, ProjectId);

                        clsForCP.UpdateContractsMultipleData(dgvCpDataEntry, dgvContracts, cmd, sqlConn, ProjectId, lblContractNoDisplay);
                    }
                }
                //modified by Varun
                // MessageBox.Show("Data Updated Successfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE DATES Contracts records, Try again.", ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            int stsID = getStatusID(ProjectId);
            Boolean chkCommit = false;
            Boolean chkStatus = false;
            foreach (DataGridViewRow row in this.dgvCpDataEntry.Rows)
            {
                if (row.Cells[7].Value != null || row.Cells[7].Value.ToString() != "")
                {
                    string strVal = row.Cells[7].Value.ToString();
                    if (strVal != "")
                    {
                        if (!cmbTenderStatus.Text.Equals("Committed"))
                        {
                            clsForCP.Status_Commit(7, ProjectId.ToString());
                            // added by Varun on 11/05/2015
                            FillProjectInfo();
                        }
                        else
                        {
                            chkCommit = true;  // committed
                            commCls = new CommonClass(_userName);
                            commCls.DisplayContractNumber(lblContractNoDisplay, lblContractNo, btnWorkOrder, _projID);
                        }

                        return;
                    }
                    else
                    {
                        string cellVal2 = string.Empty; string cellVal3 = string.Empty; string cellVal4 = string.Empty; string cellVal1 = string.Empty;
                        cellVal2 = row.Cells[2].Value.ToString();
                        cellVal3 = row.Cells[3].Value.ToString();
                        cellVal4 = row.Cells[4].Value.ToString();
                        cellVal1 = row.Cells[1].Value.ToString();

                        if (cellVal2 != "" || cellVal3 != "" || cellVal4 != "")
                        {
                            if (stsID <= 15)
                            {
                                clsForCP.Status_Commit(15, ProjectId.ToString());
                                chkStatus = true;
                                // added by Varun on 11/05/2015
                                FillProjectInfo();
                            }
                        }
                        else if (cellVal1 != "")
                        {
                            if (stsID <= 14)
                            {
                                clsForCP.Status_Commit(14, ProjectId.ToString());
                                chkStatus = true;
                                // added by Varun on 11/05/2015
                                FillProjectInfo();
                            }
                        }
                    }
                }

            }
            foreach (DataGridViewRow row in this.dgvContracts.Rows)
            {
                string cellVal7 = string.Empty; string cellVal5 = string.Empty;
                cellVal7 = row.Cells[7].Value.ToString();
                cellVal5 = row.Cells[5].Value.ToString();

                if (chkCommit == false)
                {
                    if (chkStatus == false)
                    {
                        if (cellVal7 != "")
                        {
                            if (stsID <= 13)
                            {
                                clsForCP.Status_Commit(13, ProjectId.ToString());
                                // added by Varun on 11/05/2015
                                FillProjectInfo();
                            }
                        }
                        else if (cellVal5 != "")
                        {
                            if (stsID <= 12)
                            {
                                clsForCP.Status_Commit(12, ProjectId.ToString());
                                // added by Varun on 11/05/2015
                                FillProjectInfo();
                            }
                        }
                    }
                }
            }
            commCls = new CommonClass(_userName);
            commCls.DisplayContractNumber(lblContractNoDisplay, lblContractNo, btnWorkOrder, _projID);            

        }
        private void FillContractsProcessData_Old()
        {
            // FillContractsProcessColumnData();                  // Fill above 5 Columns data
            clsForCP.FillCP_MultiplerecordsDara(dgvCpDataEntry, _projID);
            FillCp_ContractsInformation();
        }
        private void FillContractsProcessData()
        {
            //Added by Varun for clearing the rows
            //dgvContracts.Rows.Clear();
            //dgvContracts.AllowUserToAddRows = false;

            if (dgvContracts.ColumnCount == 0)
            {
                clsForCP.CreateColumnsForCP_Contractors(ref dgvContracts, _projID);
            }

            clsForCP.FillContractsGrid(ref dgvContracts, _projID);
            

            if (dgvCpDataEntry.ColumnCount == 0)
            {
                clsForCP.CreateColumnsForCP_ContractorsMultiple(dgvCpDataEntry, _projID);
            }
            clsForCP.FillContractsGrid_Multiple(dgvCpDataEntry, _projID);
            
            //dgvCpDataEntry.AllowUserToAddRows = false;
        }
        //public void FillCP_ContractsGrid(DataGridView dgvCpDataEntry, int cp_PrjID)
        //{
        //    if (dgvCpDataEntry.ColumnCount == 0)
        //        CreateColumnsForCP_ContractsData(dgvCpDataEntry);

        //    string strQuery = "";
        //    strQuery = "SELECT COMPANY.co_name,TenderDatesInfo.cp_sent_dep_sign, TenderDatesInfo.cp_receive_dep_sent_prsd, TenderDatesInfo.cp_sent_fd_commit, " +
        //               " TenderDatesInfo.cp_receive_fd_commit, TenderDatesInfo.cp_distribution, TenderDatesInfo.remarks, TenderDatesInfo.StaffInCharge AS staff, " +
        //               " TenderDatesInfo.date_id, TenderDatesInfo.cp_received_of_doc, TenderDatesInfo.cp_request_start_date, TenderDatesInfo.cp_start_date_receive, " +
        //               " TenderDatesInfo.cp_notice_contractor_to_sign, TenderDatesInfo.cp_due_date_pb, TenderDatesInfo.Tndr_BidID, TenderDatesInfo.Tndr_BidName " +
        //               " FROM  TenderDatesInfo INNER JOIN COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id INNER JOIN " +
        //               " CONTRACTORS ON TenderDatesInfo.Tndr_BidID = CONTRACTORS.bidder_id WHERE (TenderDatesInfo.proj_id = " + cp_PrjID + ") AND (TenderDatesInfo.stage_id = 4)";

        //    //strQuery = "select cp_sent_dep_sign,cp_receive_dep_sent_prsd,cp_sent_fd_commit,cp_receive_fd_commit,cp_distribution,remarks," +
        //    //    " [StaffInCharge] as staff,date_id,cp_received_of_doc,cp_request_start_date,cp_start_date_receive,cp_notice_contractor_to_sign, " +
        //    //" cp_due_date_pb,Tndr_BidID,Tndr_BidName from TenderDatesInfo WHERE (proj_id = " + cp_PrjID + ") AND (stage_id = 4)";

        //    using (SqlConnection sqlCn = new SqlConnection(connStr))
        //    {
        //        sqlCn.Open();
        //        using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
        //        {
        //            SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
        //            DataSet ds = new DataSet();
        //            sqlda.Fill(ds);
        //            dgvCpDataEntry.AllowUserToAddRows = false;

        //            dgvCpDataEntry.Columns[0].DataPropertyName = "Tndr_Bidname";
        //            dgvCpDataEntry.Columns[1].DataPropertyName = "cp_sent_dep_sign";
        //            dgvCpDataEntry.Columns[2].DataPropertyName = "cp_receive_dep_sent_prsd";
        //            dgvCpDataEntry.Columns[3].DataPropertyName = "cp_sent_fd_commit";
        //            dgvCpDataEntry.Columns[4].DataPropertyName = "cp_receive_fd_commit";
        //            dgvCpDataEntry.Columns[5].DataPropertyName = "cp_distribution";
        //            dgvCpDataEntry.Columns[6].DataPropertyName = "remarks";
        //            dgvCpDataEntry.Columns[7].DataPropertyName = "staff";
        //            dgvCpDataEntry.Columns[8].DataPropertyName = "date_id";

        //            dgvCpDataEntry.Columns[9].DataPropertyName = "cp_received_of_doc";
        //            dgvCpDataEntry.Columns[10].DataPropertyName = "cp_request_start_date";
        //            dgvCpDataEntry.Columns[11].DataPropertyName = "cp_start_date_receive";
        //            dgvCpDataEntry.Columns[12].DataPropertyName = "cp_notice_contractor_to_sign";
        //            dgvCpDataEntry.Columns[13].DataPropertyName = "cp_due_date_pb";
        //            dgvCpDataEntry.Columns[14].DataPropertyName = "Tndr_BidID";


        //            dgvCpDataEntry.DataSource = ds.Tables[0];
        //            dgvCpDataEntry.AllowUserToAddRows = true;
        //        }
        //        sqlCn.Close();
        //    }

        //    dgvCpDataEntry.Columns[7].Visible = false;


        //    try
        //    {
        //        for (int i = 0; i < dgvCpDataEntry.Rows.Count; i++)
        //        {
        //            if (i == (dgvCpDataEntry.Rows.Count - 1))
        //            {
        //                dgvCpDataEntry.Rows[i].Cells[1].Value = "";
        //                dgvCpDataEntry.Rows[i].Cells[2].Value = "";
        //                dgvCpDataEntry.Rows[i].Cells[3].Value = "";
        //                dgvCpDataEntry.Rows[i].Cells[4].Value = "";
        //                dgvCpDataEntry.Rows[i].Cells[5].Value = "";

        //                // dgvCpDataEntry.Rows[i].Cells[5].Value = "";

        //                dgvCpDataEntry.Rows[i].Cells[7].Value = "";
        //                dgvCpDataEntry.Rows[i].Cells[8].Value = "";
        //                dgvCpDataEntry.Rows[i].Cells[9].Value = "";
        //                dgvCpDataEntry.Rows[i].Cells[10].Value = "";
        //                dgvCpDataEntry.Rows[i].Cells[11].Value = "";

        //                dgvCpDataEntry.Rows[i].Cells[12].Value = "";
        //                dgvCpDataEntry.Rows[i].Cells[13].Value = "";
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }
        //}


        //clsCP_Stage clsCp = new clsCP_Stage("", mIsHeadOfSection);
        private void CPMultipleRecords_InsertUpdate()
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        if (sqlConn.State == ConnectionState.Closed)
                            sqlConn.Open();
                        cmd.Connection = sqlConn;

                        clsForCP.CPMultipleRecords_Insert_Update(dgvCpDataEntry, sqlConn, cmd, _projID);

                        // MessageBox.Show("Contract Process data added Succesfully");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE DATES StaffIncharge records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            clsForCP.FillCP_MultiplerecordsDara(dgvCpDataEntry, _projID);      //DataGridView dgvCpDataEntry,int cp_PrjID
        }
        private void FillCp_ContractsInformation()
        {
            //Modified By Varun on 16 Feb 2014
            dgvCntrStage3.Columns.Clear();
            //if (dgvCntrStage3.Columns.Count == 0)

            clsForCP.CreateColumnsForCP_Contracors_TE(dgvCntrStage3, _projID);
            //clsForCP.CreateColumnsForCP_Contracors(dgvContractsTemp, _projID);
            //FillCP_ContractsData();
            clsForCP.FillContractsGrid_TE(dgvCntrStage3, _projID, 0);
            dgvCntrStage3.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
        }
        private void CP_Contract_InsertUpdate(DataGridView dgvCntr, bool isHeadOfSection)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        if (sqlConn.State == ConnectionState.Closed)
                            sqlConn.Open();
                        cmd.Connection = sqlConn;
                        clsForCP.CP_Contracts_Insert_UpdateData(dgvCntr, cmd, _projID, txtproj.Text, isHeadOfSection);
                        //tabControl1.TabPages[3].Focus();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the Contracts records, Try again.", ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void dgvCP_Rec_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (mUserRightsColl.Contains("21"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            int rowIndex = e.RowIndex;
            try
            {
                if (rowIndex != -1)
                {
                    if (dgvCP_Rec.Rows[rowIndex].Cells[3].Value.ToString() != "")
                    {
                        int docId = Convert.ToInt16(dgvCP_Rec.Rows[rowIndex].Cells[3].Value);
                        ReceivedDocProperties receivedDoc = new ReceivedDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), txtProjCode.Text, docId, 4, _userName);
                        receivedDoc.StartPosition = FormStartPosition.CenterParent;
                        receivedDoc.ShowDialog();

                        commCls.FillGridReceivedDocsInfo(Convert.ToInt16(lblProjID.Text), dgvCP_Rec, 4);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void txtDA_BdjtAmnt_KeyDown(object sender, KeyEventArgs e)
        {
            nonNumberEntered = false;
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            {
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    if ((e.KeyCode != Keys.Back) & (e.KeyCode != Keys.Enter))
                    {
                        nonNumberEntered = true;
                    }
                }
            }
        }
        private void txtDA_EstimateAmnt_KeyDown(object sender, KeyEventArgs e)
        {
            nonNumberEntered = false;
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            {
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    if ((e.KeyCode != Keys.Back) & (e.KeyCode != Keys.Enter))
                    {
                        nonNumberEntered = true;
                    }
                }
            }
        }
        private void txtCp_BudgetAmnt_KeyDown(object sender, KeyEventArgs e)
        {
            nonNumberEntered = false;
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            {
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    if ((e.KeyCode != Keys.Back) & (e.KeyCode != Keys.Enter))
                    {
                        nonNumberEntered = true;
                    }
                }
            }
        }
        private void txtCp_EstimatedAmnt_KeyDown(object sender, KeyEventArgs e)
        {
            nonNumberEntered = false;
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            {
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    if ((e.KeyCode != Keys.Back) & (e.KeyCode != Keys.Enter))
                    {
                        nonNumberEntered = true;
                    }
                }
            }
        }
        //Added By Varun
        //private void dgvContracts_CellValidated(object sender, DataGridViewCellEventArgs e)
        //{
        //    // the cells under the column of index 1 are going to display
        //    //the property of a complex type
        //    if (dgvContracts.CurrentCell.GetType() == typeof(DataGridViewComboBoxCell))
        //    {
        //        DataGridViewCell cell =
        //        dgvContracts.Rows[e.RowIndex].Cells[e.ColumnIndex];
        //        cell.Value = newEnteredValue;
        //        cell.Selected = true;
        //        dgvContracts.CurrentCell.DataGridView.EndEdit(DataGridViewDataErrorContexts.Commit);
        //    }
        //}
        //Object newEnteredValue = null;
        //private void dgvContracts_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        //{
        //    if (e.ColumnIndex == 3)
        //    {
        //        if (dgvContracts.CurrentCell.IsInEditMode)
        //        {
        //            if (dgvContracts.CurrentCell.GetType() ==
        //            typeof(DataGridViewComboBoxCell))
        //            {
        //                DataGridViewComboBoxCell cell =
        //                (DataGridViewComboBoxCell)dgvContracts.Rows[e.RowIndex].Cells[e.ColumnIndex];
        //                cell.Items.Add(e.FormattedValue);
        //                cell.Selected = true;
        //                newEnteredValue = e.FormattedValue;

        //            }
        //        }
        //    }
        //}

        //void combo_ConfirmSelectionChange(object sender, EventArgs e)
        //{
        //if (dgvCpDataEntry.CurrentCell.ColumnIndex != col_ConfirmCmb.Index) return;

        //ComboBox combo = sender as ComboBox;
        //if (combo == null) return;

        //MessageBox.Show(combo.SelectedText);// returns Null for the first time
        //}
        //private void dgvContracts_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        //{
        //    ////if (e.Control is ComboBox)
        //    ////{
        //    ////    ComboBox comboBox = e.Control as ComboBox;
        //    ////    comboBox.SelectedIndexChanged += LastColumnComboSelectionChanged;
        //    ////}
        //}
        //private void LastColumnComboSelectionChanged(object sender, EventArgs e)
        //{   
        //    var currentcell = dgvContracts.CurrentCellAddress;
        //    var sendingCB = sender as DataGridViewComboBoxEditingControl;
        //    DataGridViewComboBoxCell cel = (DataGridViewComboBoxCell)dgvContracts.Rows[currentcell.Y].Cells[0];
        //    if (sendingCB.SelectedValue != null)
        //    {
        //        cel.Value = sendingCB.SelectedValue.ToString();
        //        if (cel.Value.ToString() != "" & cel.Value.ToString() != "System.Data.DataRowView")
        //        {
        //            string _cmpName = FilldgvComboValue(Convert.ToInt16(cel.Value));

        //            dgvContracts.Rows[currentcell.Y].Cells[1].Value = _cmpName;
        //        }
        //    }

        //   // DataGridViewTextBoxCell celText = (DataGridViewTextBoxCell)dgvContracts.Rows[currentcell.Y].Cells[1];

        //}

        //int iCnt = 0;
        //private void dgvContracts_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        //{
        //    iCnt = iCnt + 1;
        //    DataGridView dgv = sender as DataGridView;


        //    if (dgv.CurrentCell != null)
        //    {

        //        if (dgv.CurrentCell.ColumnIndex == 0)
        //        {
        //            // ComboBox comboBox = e.Control as ComboBox;
        //            if (e.RowIndex >= 0) //check if combobox column
        //            {
        //                object selectedValue = dgvContracts.Rows[dgv.CurrentCell.RowIndex].Cells[dgv.CurrentCell.ColumnIndex].Value;

        //                if (selectedValue is int)
        //                {

        //                    string _cmpName = clsForCP.FillComapany_dgvComboValue(Convert.ToInt16(selectedValue));

        //                    dgvContracts.Rows[dgv.CurrentCell.RowIndex].Cells[dgv.CurrentCell.ColumnIndex + 1].Value = _cmpName;

                             
        //                }
        //            }
        //        }

        //    }

        //}


        private void dgvContracts_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {

            //Commented By Varun
            //if (dgvContracts.IsCurrentCellDirty)
            //{
            //    dgvContracts.CommitEdit(DataGridViewDataErrorContexts.Commit);
            //}

            //Added By Varun
            DataGridViewColumn col = dgvContracts.Columns[dgvContracts.CurrentCell.ColumnIndex];
            if (col is DataGridViewComboBoxColumn)
            {
                dgvContracts.CommitEdit(DataGridViewDataErrorContexts.Commit);
            }
        }

        private void dgvContracts_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            //ComboBox cb = e.Control as ComboBox;
            //if (cb != null)
            //{
            //    // first remove event handler to keep from attaching multiple:
            //    cb.SelectedIndexChanged -= new EventHandler(cb_SelectedIndexChanged);

            //    // now attach the event handler
            //    cb.SelectedIndexChanged += new EventHandler(cb_SelectedIndexChanged);
            //}


            //Added By Varun
            ComboBox cb = e.Control as ComboBox;
            if (cb != null)
            {
                ComboBox comboBox = e.Control as ComboBox;
                if (comboBox != null)
                {
                    ((ComboBox)e.Control).DropDownStyle = ComboBoxStyle.DropDown;
                    return;
                }
            }
        }

        void cb_SelectedIndexChanged(object sender, EventArgs e)
        {
            // MessageBox.Show("Selected index changed");
        }

        #endregion

        char chProjTransfered = ' ';
        public char ProjTransferedToComm
        {
            get { return chProjTransfered; }
            set { chProjTransfered = value; }
        }

        char chProjReTendered = ' ';
        public char ProjReTendered
        {
            get { return chProjReTendered; }
            set { chProjReTendered = value; }
        }

        private void cmbTenderStatus_SelectionChangeCommitted(object sender, EventArgs e)
        {
            chkOnHold = false;

            if (cmbTenderStatus.SelectedValue.ToString() == "10")           // Transferred To Other Committee
            {
                if (txtTenderNo.Text != "")
                {
                    if (_cmtName.Equals("EUWC"))
                    {
                        MessageBox.Show("Not Transferable");
                        return;
                    }
                    if (_cmtName.Equals("MRPSC"))
                    {
                        MessageBox.Show("Not Transferable");
                        return;
                    }
                    if (_cmtName.Equals("NC"))
                    {
                        MessageBox.Show("Not Transferable");
                        return;
                    }
                    frmTransforProject transforProject = new frmTransforProject(_projID, _tndrType, _cmtName, mUserRightsColl, cmbTenderStatus.SelectedValue.ToString(), txtProjCode.Text, txtTenderNo.Text, _userName, _fiscalYear, txtproj.Text);
                    transforProject.StartPosition = FormStartPosition.CenterParent;
                    transforProject.ShowDialog();
                    chkProjectTrnsfor = true;
                    ProjTransferedToComm = transforProject.ProjTransfered;

                    //Updated by Varun
                    if (ProjTransferedToComm == 'Y')
                    {
                        ProjectId = transforProject.GetNewProjId();
                        this.Close();
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Tender Status. Tender No. is not yet assigned for this project");
                    return;
                }
            }
            if (cmbTenderStatus.SelectedValue.ToString() == "9")            // Re-Tender
            {
                if (txtTenderNo.Text != "")
                {
                    frmTransforProject transforProject = new frmTransforProject(_projID, _tndrType, _cmtName, mUserRightsColl, cmbTenderStatus.SelectedValue.ToString(), txtProjCode.Text, txtTenderNo.Text, _userName, _fiscalYear, txtproj.Text); //+ "-" + (Convert.ToInt16(DateTime.Today.ToString().Split('/')[2].Split(' ')[0].ToString()) + 1).ToString()
                    transforProject.StartPosition = FormStartPosition.CenterParent;
                    transforProject.ShowDialog();
                    this.Close();
                    ProjReTendered = transforProject.ProjReTender;
                    chkProjectTrnsfor = true;
                }
                else
                {
                    MessageBox.Show("Invalid Tender Status. Tender No. is not yet assigned for this project");
                    return;
                }
            }
            if (cmbTenderStatus.SelectedValue.ToString() == "11")           // On Hold
            {
                chkOnHold = true;

                Status_Onhold();

                // Tender Stages are all read only
                // ProjectStages frmPrjStages = new ProjectStages();
                // frmPrjStages.ShowDialog();
            }
            if (cmbTenderStatus.SelectedValue.ToString() == "8")            // Cancelled
            {
                UserList_ForAlert(1);

                if (userListColl.Count == 0)
                {
                    MessageBox.Show("Information for Tender Cancelation is required to be sent to a user who handles " + _cmtName + " projects, " +
                      " but there is no identified user to receive the email. Please contact system administrator for information.");
                    return;
                }

                DialogResult dlgResult = DialogResult.No;
                dlgResult = MessageBox.Show("This project shall be sent to Archives if you set the status to Cancelled.  Are you sure want to Cancel this project.", "Tender Status Changing", MessageBoxButtons.YesNo);

                if (dlgResult.ToString() == "Yes")
                {
                    using (SqlConnection sqlConn = new SqlConnection(connStr))
                    {
                        using (SqlCommand cmd = new SqlCommand())
                        {
                            if (sqlConn.State == ConnectionState.Closed)
                                sqlConn.Open();
                            cmd.Connection = sqlConn;
                            cmd.CommandText = @"Update Projects set Tender_Status_id = @status,update_date=@update_date,update_user=@update_user where proj_id=@projId";
                            cmd.Parameters.AddWithValue("@projId",_projID);
                            cmd.Parameters.AddWithValue("@status", 8);
                            cmd.Parameters.AddWithValue("@update_date", DateTime.Now.ToString());
                            cmd.Parameters.AddWithValue("@update_user", _userName);

                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();

                            // Added by Varun on 3rd Nov 2015
                            cmd.CommandText = @"Update TenderDatesInfo set remarks = @remarks,update_date=@update_date,update_user=@update_user where proj_id=@projId and ts_tender_issue is NULL and stage_id=2";
                            cmd.Parameters.AddWithValue("@projId", _projID);
                            cmd.Parameters.AddWithValue("@remarks", "This tender was cancelled by "+_userName+" Dated "+DateTime.Now.ToString());
                            cmd.Parameters.AddWithValue("@update_date", DateTime.Now.ToString());
                            cmd.Parameters.AddWithValue("@update_user", _userName);
                            exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();

                            cmd.CommandText = @"Update TenderDatesInfo set remarks = @remarks,update_date=@update_date,update_user=@update_user where proj_id=@projId and stage_id=3";
                            cmd.Parameters.AddWithValue("@projId", _projID);
                            cmd.Parameters.AddWithValue("@remarks", "This tender was cancelled by " + _userName + " Dated " + DateTime.Now.ToString());
                            cmd.Parameters.AddWithValue("@update_date", DateTime.Now.ToString());
                            cmd.Parameters.AddWithValue("@update_user", _userName);
                            exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                    }
                    MessageBox.Show("Cancellation of the Project was successful.The record was sent to Archives.");                     
                                        

                    //string DisplayName = ""; string Email = ""; string Department = ""; string Title = "";                     
                    // AlertOnNewTenderNo(tenderNo, _projID.ToString(), "New Project");

                    CommonClass comCls = new CommonClass(_userName);
                    string fromUser = null;
                    fromUser = comCls.getUserEmailID(_userName);
                    // Added by Varun on 3rd Nov 2015
                    string tenderTypeFullName = null;
                    if (_tndrType == "L")
                        tenderTypeFullName = "Limited";
                    else if (_tndrType == "DO")
                        tenderTypeFullName = "Direct Order";
                    else
                        tenderTypeFullName = "Public Tender";

                    try
                    {
                        //if (GetUserInformation4rmActiveDirectory(fromUser, "ashghal.gov.qa", ref user_DisplayName, ref user_Email, ref  user_Department, ref user_Title) == true)
                        //{
                        foreach (string strname in userListColl)
                        {

                            // if (GetUserInformation4rmActiveDirectory(strname, "ashghal.gov.qa", ref DisplayName, ref Email, ref  Department, ref Title) == true)

                            MailMessage mailMessage = new MailMessage();
                            //mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["MailFrom"].ToString());

                            mailMessage.From = new MailAddress(fromUser);
                            mailMessage.To.Add(new MailAddress(strname));
                            mailMessage.Subject = "TCMS Alert: Tender Cancelled with Tender No. " + txtTenderNo.Text;
                            mailMessage.IsBodyHtml = true;                            

                            mailMessage.Body = "<html><body><i style='font-family:Calibri; font-size:15'>Dear Sir/Madam,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Tender & Contract Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>" +
                            "Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'> Tender No. " + txtTenderNo.Text + "</i><i style='font-family:Calibri; font-size:15'> has been cancelled by " + _cmtName + " dated on " + System.DateTime.Now.ToString("dd-MMM-yyyy HH:mm:ss tt") + "</i><br /><br />" +
                            "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:Red;color:White;font-family:Calibri;font-size:18;font-weight:bold'>TENDER NO: " + txtTenderNo.Text + "</td>" +
                            "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Code</i></td><td style='font-family:Calibri;font-size:15'>" + _prjCode + "</td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Title</i></td><td style='font-family:Calibri;font-size:15'>" + proj_Title + "</td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Type of Tender</i></td><td style='font-family:Calibri;font-size:15'>" + tenderTypeFullName + "</td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Tender Committee</i></td><td style='font-family:Calibri;font-size:15'>" + _cmtName + "</td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Financial Year</i></td><td style='font-family:Calibri;font-size:15'>" + _fiscalYear + "</td></tr>" +       //+ "(" + _AffairsName + ")
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>User Dept.</i></td><td style='font-family:Calibri;font-size:15'>" + _userDept + " / " + _AffairsName + " </td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now.ToString("dd-MMM-yyyy HH:mm:ss tt") + "</td></tr>" +
                            "</table><br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>TCMS Team</div></body></html>";

                            //mailMessage.Body = "This is an automated alert from TCMS." + "\n" + "\n" + "Project Code     : " + _prjCode + "\n" + "Project Title    : " + proj_Title + "\n" +   "Type of Tender   : " + _tndrTypeName + " " +
                            // "\n"  + "Tender Committee : " + _cmtName + " " +
                            // "\n" +  "User Department  : " + _userDept + " " +
                            // "\n" +  "Date Created     : " + System.DateTime.Now.ToString() + " " +
                            //" \n" +  "\n" + "Tender No. " + strTenderNo + " was assigned to above project.";

                            SmtpClient client = new SmtpClient();
                            client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                            client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                            client.Send(mailMessage);
                        }


                        //}
                        MessageBox.Show("Tender Alert E-mail send to the users", "Create Tender Number");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Exception occurred while sending the email notification to Tender Committee, Please inform them Personally", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }

                }
            }
            if (cmbTenderStatus.SelectedValue.ToString() == "1")           // Tender Preparation
            {
                UpdateStatus("Tender Preparation", 1);
                chkProjectTrnsfor = true;
            }
            if (cmbTenderStatus.SelectedValue.ToString() == "2")           // Tendering
            {
                UpdateStatus("Tendering", 2);
                chkProjectTrnsfor = true;
            }
            if (cmbTenderStatus.SelectedValue.ToString() == "3")           // Technical Evaluation
            {
                UpdateStatus("Technical Evaluation", 3);
                chkProjectTrnsfor = true;
            }
            if (cmbTenderStatus.SelectedValue.ToString() == "4")           // Financial Evaluation
            {
                UpdateStatus("Financial Evaluation", 4);
                chkProjectTrnsfor = true;
            }
            if (cmbTenderStatus.SelectedValue.ToString() == "5")           //Technical and Financial Evaluation
            {
                UpdateStatus("Technical and Financial Evaluation", 5);
                chkProjectTrnsfor = true;
            }
            if (cmbTenderStatus.SelectedValue.ToString() == "6")           //Award
            {
                UpdateStatus("Award", 6);
                chkProjectTrnsfor = true;
            }
            if (cmbTenderStatus.SelectedValue.ToString() == "7")           //Committed
            {
                UpdateStatus("Committed", 7);
                chkProjectTrnsfor = true;
            }

            if (cmbTenderStatus.SelectedValue.ToString() == "12")           //Start Date Requested
            {
                UpdateStatus("Start Date Requested", 12);
                chkProjectTrnsfor = true;
            }
            if (cmbTenderStatus.SelectedValue.ToString() == "13")           //NOA Issued
            {
                UpdateStatus("NOA Issued", 13);
                chkProjectTrnsfor = true;
            }

            if (cmbTenderStatus.SelectedValue.ToString() == "14")           //Contract Signed
            {
                UpdateStatus("Contract Signed", 14);
                chkProjectTrnsfor = true;
            }

            if (cmbTenderStatus.SelectedValue.ToString() == "15")           //Signature Processing
            {
                UpdateStatus("Signature Processing", 15);
                chkProjectTrnsfor = true;
            }
            if (cmbTenderStatus.SelectedValue.ToString() == "16")           // Transferred To Other Committee
            {
                UpdateStatus("Revert Deleted Project", 16);
                chkProjectTrnsfor = true;
            }
        }
        private void Status_Onhold()
        {
            DialogResult dlgResult = DialogResult.No;
            dlgResult = MessageBox.Show("Entering and editing of data for this project will be disabled if you set tender status to 'On Hold' . Are you sure you want to put the tender 'On Hold' ? ", " On-Hold confirmation ", MessageBoxButtons.YesNo);

            if (dlgResult.ToString() == "Yes")
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        if (sqlConn.State == ConnectionState.Closed)
                            sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"Update Projects set Tender_Status_id = @status where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@projId", _projID);
                        cmd.Parameters.AddWithValue("@status", 11);
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();

                        // Added by Varun on 5th Nov 2015
                        cmd.CommandText = @"select proj_id from TenderDatesInfo where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@projId", _projID);
                        SqlDataReader sqlDtReader = cmd.ExecuteReader();
                        if (sqlDtReader.Read())
                        {
                            sqlDtReader.Close();
                            cmd.Parameters.Clear();
                            cmd.CommandText = @"Update TenderDatesInfo set remarks = @remarks,update_date=@update_date,update_user=@update_user where proj_id=@projId and ts_tender_issue is NULL and stage_id=2";
                            cmd.Parameters.AddWithValue("@projId", _projID);
                            cmd.Parameters.AddWithValue("@remarks", "This tender status was set on Hold by " + _userName + " Dated " + DateTime.Now.ToString());
                            cmd.Parameters.AddWithValue("@update_date", DateTime.Now.ToString());
                            cmd.Parameters.AddWithValue("@update_user", _userName);
                            exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();

                            cmd.CommandText = @"Update TenderDatesInfo set remarks = @remarks,update_date=@update_date,update_user=@update_user where proj_id=@projId and stage_id=3";
                            cmd.Parameters.AddWithValue("@projId", _projID);
                            cmd.Parameters.AddWithValue("@remarks", "This tender status was set on Hold by " + _userName + " Dated " + DateTime.Now.ToString());
                            cmd.Parameters.AddWithValue("@update_date", DateTime.Now.ToString());
                            cmd.Parameters.AddWithValue("@update_user", _userName);
                            exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                        else
                        {                             
                             
                            sqlDtReader.Close();
                            int dateID = MaxDateID();                                                          
                            sqlCom = new SqlCommand();
                            sqlCom.Connection = sqlConn;
                            sqlCom.CommandText = @"insert into TenderDatesInfo(proj_id,date_id,stage_id,remarks,update_date,update_user) values(" + _projID + "," + dateID + ",2,'This tender status was set on Hold by " + _userName + " Dated " + DateTime.Now.ToString() + "','" + DateTime.Now.ToString() + "','" +
                            _userName + "')";
                            sqlCom.ExecuteNonQuery();
                            sqlCom.Parameters.Clear();

                            dateID = MaxDateID();                             
                            sqlCom = new SqlCommand();
                            sqlCom.Connection = sqlConn;
                            sqlCom.CommandText = @"insert into TenderDatesInfo(proj_id,date_id,stage_id,remarks,update_date,update_user) values(" + _projID + "," + dateID + ",3,'This tender status was set on Hold by " + _userName + " Dated " + DateTime.Now.ToString() + "','" + DateTime.Now.ToString() + "','" +
                            _userName + "')";
                            sqlCom.ExecuteNonQuery();
                            sqlCom.Parameters.Clear();                       
                        }
                    }
                }
                txt_tsRemarks.Enabled = false;
                txtTE_remarks.Enabled = false;

                MessageBox.Show("Tendering of the project is now On Hold");

                //tabControl1.Enabled = false;
            }
        }
        private void UpdateStatus(string statusName, int statusID)
        {
            DialogResult dlgResult = DialogResult.No;
            if(statusID!=16)
                dlgResult = MessageBox.Show("Are you sure want to update this project status to " + statusName, "Tender Status Changing", MessageBoxButtons.YesNo);
            else
                dlgResult = MessageBox.Show("Are you sure want to undo the project deletion", "Undo Project Deletion", MessageBoxButtons.YesNo);

            if (dlgResult.ToString() == "Yes")
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        if (sqlConn.State == ConnectionState.Closed)
                            sqlConn.Open();
                        cmd.Connection = sqlConn;
                        //Modified by Varun on 15-Nov-2015 and 11-Jan-2016
                        if (statusID != 16)
                        {
                            cmd.CommandText = @"Update Projects set Tender_Status_id = @status,stage_id=@stage_id where proj_id=@projId";
                            cmd.Parameters.AddWithValue("@projId", _projID);
                            cmd.Parameters.AddWithValue("@status", statusID);
                            cmd.Parameters.AddWithValue("@stage_id", 6); //Post Contract Stage
                        }
                        else
                        {
                            cmd.CommandText = @"Update Projects set isDeleted = @isDeleted where proj_id=@projId";
                            cmd.Parameters.AddWithValue("@projId", _projID);
                            cmd.Parameters.AddWithValue("@isDeleted", 0);                             
                        }                       

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();


                    }
                }
                if (statusID == 8)
                {
                    MessageBox.Show("Cancellation of the Project was successful.The record was sent to Archives.");
                }
                chkProjectTrnsfor = true;
            }
        }



        private void dgvCpDataEntry_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {
            try
            {
                for (int i = 0; i < dgvCpDataEntry.Rows.Count; i++)
                {
                    if (i == (dgvCpDataEntry.Rows.Count - 1))
                    {
                        dgvCpDataEntry.Rows[i].Cells[0].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[1].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[2].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[3].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[4].Value = "";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dgvPTD_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (mUserRightsColl.Contains("38"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            if (e.RowIndex != -1)
            {

                int rowIndex = Convert.ToInt16(dgvPTD.Rows[e.RowIndex].Index);
                for (int iCnt = 0; iCnt < dgvPTD.Rows.Count; iCnt++)
                {
                    if (iCnt.Equals(rowIndex))
                    {
                        chkUpdateStatus = true;
                        
                        if (dgvPTD.Rows[iCnt].Cells[0].Value != DBNull.Value)
                        {
                            //dtpRecievedOn.CustomFormat = "dd/MMM/yyyy";
                            //Modified by Varun on 13th Feb 2014 for displaying arabic as well as gregorian date in the textbox
                            //Convert.ToDateTime(dtpRecievedOn.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString()
                            msk_dtpRecievedOn.Text = Convert.ToDateTime(dgvPTD.Rows[iCnt].Cells[0].Value).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture); //Convert.ToDateTime(.ToString("dd/MMM/yyyy")
                        }
                        else
                        {
                            msk_dtpRecievedOn.Text = "";
                        }


                        cmbPurpose.Text = dgvPTD.Rows[iCnt].Cells[1].Value.ToString();
                        cmbAssignedQs.Text = dgvPTD.Rows[iCnt].Cells[2].Value.ToString();

                        if (dgvPTD.Rows[iCnt].Cells[3].Value.ToString() != "")
                        {
                            //dtpReview.CustomFormat = "dd/MMM/yyyy";
                            //Modified by Varun on 13th Feb 2014 for displaying arabic as well as gregorian date in the textbox
                            msk_dtpReview.Text = Convert.ToDateTime(dgvPTD.Rows[iCnt].Cells[3].Value).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture);//"dd/MMM/yyyy");
                        }
                        else
                        {
                            msk_dtpReview.Text = "";
                        }


                        cmbQsWorkingStatus.Text = dgvPTD.Rows[iCnt].Cells[4].Value.ToString();
                        cmbTenderDocStatus.Text = dgvPTD.Rows[iCnt].Cells[5].Value.ToString();
                        if (dgvPTD.Rows[iCnt].Cells[6].Value.ToString() != "")
                        {
                            //dtpFrwdDept.CustomFormat = "dd/MMM/yyyy";
                            //Modified by Varun on 13th Feb 2014 for displaying arabic as well as gregorian date in the textbox
                            msk_dtpFrwdDept.Text = Convert.ToDateTime(dgvPTD.Rows[iCnt].Cells[6].Value).ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture);//"dd/MMM/yyyy");
                        }
                        else
                        {
                            msk_dtpFrwdDept.Text = "";
                        }
                        txtRemarks.Text = dgvPTD.Rows[iCnt].Cells[7].Value.ToString();
                        lblDateID.Text = dgvPTD.Rows[iCnt].Cells[8].Value.ToString();

                        lblGridIndex.Text = e.RowIndex.ToString();

                        if (dgvPTD.Rows[iCnt].Cells[5].Value.ToString() == "Approved")
                        {
                            if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                            {
                                msk_dtpRecievedOn.Enabled = false;
                                dtpRecievedOn.Enabled = false;
                                cmbPurpose.Enabled = false;
                                cmbAssignedQs.Enabled = false;
                                cmbQsWorkingStatus.Enabled = false;
                                msk_dtpReview.Enabled = false;
                                dtpReview.Enabled = false;
                                cmbTenderDocStatus.Enabled = false;
                                msk_dtpFrwdDept.Enabled = false;
                                dtpFrwdDept.Enabled = false;
                                txtRemarks.Enabled = false;
                            }
                        }
                        else
                        {
                            if (!msk_dtpRecievedOn.Enabled)
                            {
                                msk_dtpRecievedOn.Enabled = true;
                                dtpRecievedOn.Enabled = true;
                                cmbPurpose.Enabled = true;
                                cmbAssignedQs.Enabled = true;
                                cmbQsWorkingStatus.Enabled = true;
                                msk_dtpReview.Enabled = true;
                                dtpReview.Enabled = true;
                                cmbTenderDocStatus.Enabled = true;
                                msk_dtpFrwdDept.Enabled = true;
                                dtpFrwdDept.Enabled = true;
                                txtRemarks.Enabled = true;
                            }
                        }
                    }
                }
            }
        }

        private void txtEstimatedAmnt_Leave(object sender, EventArgs e)
        {
            if (txtEstimatedAmnt.Text != "")
            {
                if (clsForTE.CheckProjectCostDataExist(_projID) == false)
                {
                    clsForTE.InsertTE_Estimate_ProjectCostData(txtEstimatedAmnt.Text, _projID);
                }
                else
                {
                    clsForTE.UpdateTE_Estimate_ProjectCostData(txtEstimatedAmnt.Text, _projID);
                }
                txtEstimatedAmnt.Text = string.Format("{0:#,##0.00}", double.Parse(txtEstimatedAmnt.Text));//#,##0}
            }
            else
                clsForTE.UpdateTE_Estimate_ProjectCostData(txtEstimatedAmnt.Text, _projID);
        }
        private void txtBudjetAmnt_Leave(object sender, EventArgs e)
        {
            if (txtBudjetAmnt.Text != "")
            {
                if (clsForTE.CheckProjectCostDataExist(_projID) == false)
                {
                    clsForTE.InsertTE_Budget_ProjectCostData(txtBudjetAmnt.Text, _projID);
                }
                else
                {
                    clsForTE.UpdateTE_BudgetAmount_ProjectCostData(txtBudjetAmnt.Text, _projID);
                }
                txtBudjetAmnt.Text = string.Format("{0:#,##0.00}", double.Parse(txtBudjetAmnt.Text));
            }
            else
                clsForTE.UpdateTE_BudgetAmount_ProjectCostData(txtBudjetAmnt.Text, _projID);
        }
        private void dtpEA_reqdate_ValueChanged_1(object sender, EventArgs e)
        {
            //msk_dtpEA_reqdate.Text = Convert.ToDateTime(dtpEA_reqdate.Value).ToString("dd/MMM/yyyy");
            //Modified by Varun on 12/02/2014 for inserting dates when the regional settings of the system is Arabic, this will work for en-US settings             
            msk_dtpEA_reqdate.Text = Convert.ToDateTime(dtpEA_reqdate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd/MMM/yyyy");
            msk_dtpEA_reqdate.Focus();
        }

        private void txtEA_Noofmeetings_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }

        private void txtEA_Noofmeetings_KeyDown(object sender, KeyEventArgs e)
        {
            nonNumberEntered = false;
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            {
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    if ((e.KeyCode != Keys.Back) & (e.KeyCode != Keys.Enter))
                    {
                        nonNumberEntered = true;
                    }
                }
            }
        }
        private void txtBudjetAmnt_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }
        private void txtEstimatedAmnt_KeyDown(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }

        //Added by Varun on 11th May 2014 Modified the Validation process for checking the numerics and decimals in the textboxes where only these inputs are expected 
        private void ValidateNumericAndDecimalInput(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != 8 && e.KeyChar != 13) //&& e.KeyChar.ToString().Contains('.').ToString().Length>=2
            {
                nonNumberEntered = true;
            }
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                nonNumberEntered = true;
                e.Handled = true;
            }

            if (nonNumberEntered == true)
            {
                MessageBox.Show("Please enter number only...");
                e.Handled = true;
            }

            nonNumberEntered = false;
        }

        private void txtEstimatedAmnt_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }
        private void txtCp_BudgetAmnt_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }
        private void txtCp_EstimatedAmnt_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }
        private void txtPC_BudjetAmnt_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }

        private void txtPC_EstimatedAmnt_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }

        private void dgvContracts_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {
            try
            {
                for (int i = 0; i < dgvContracts.Rows.Count; i++)
                {
                    if (i == (dgvContracts.Rows.Count - 1))
                    {
                        //dgvContracts.Rows[i].Cells[0].Value = "";
                        //dgvContracts.Rows[i].Cells[1].Value = "";
                        //dgvContracts.Rows[i].Cells[2].Value = "";
                        dgvContracts.Rows[i].Cells[3].Value = "";
                        //dgvContracts.Rows[i].Cells[4].Value = "";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cmbPurpose_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (msk_dtpRecievedOn.Text == "")
            {
                MessageBox.Show("Please Select Received On Date", "Received On Date", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cmbPurpose.SelectedIndex = -1;
                msk_dtpRecievedOn.Focus();
                return;
            }
        }

        // Added by Varun on 21 May 2014 for checking the duplicate ContractNo.
        public bool ValidateContractNo(string contractNo)
        {
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                sqlConn.Open();
                SqlCommand sqlCom = new SqlCommand(@"select contract_no from [CONTRACTORS] where contract_no = @cntrNo and bidder_id<>" + currentBidderID, sqlConn);
                contractNo = contractNo.Replace(" ", "").Replace("-", "/");
                while (Regex.Match(contractNo, "/0").Success)
                    contractNo = contractNo.Replace("/0", "/");
                sqlCom.Parameters.AddWithValue("@cntrNo", contractNo.ToUpper());
                sqlDtReader = sqlCom.ExecuteReader();
                if (sqlDtReader.HasRows)
                {
                    if (sqlDtReader.Read())
                    {
                        MessageBox.Show("Entered ContractNo. already assigned to some other bidder, Please enter a unique ContractNo.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return false;
                    }
                }
                else
                    txtContractNo.Text = contractNo.ToUpper();
                sqlDtReader.Close();
                sqlCom = null;
                sqlConn.Close();
            }
            return true;
        }
        public bool ValidateDate(Control ctrl)
        {
            if (string.IsNullOrEmpty(ctrl.Text))
            {
                return false;
            }
            else
            {
                return true;
            }

        }

        private void msk_dtpRecievedOn_Leave(object sender, EventArgs e)
        {
            if (msk_dtpRecievedOn.Text != "")
            {
                Control ctrl = sender as Control;
                Boolean chkDate = ValidateDate(ctrl);

                if (chkDate == false)
                {
                    msk_dtpRecievedOn.Text = "";
                    msk_dtpRecievedOn.Focus();
                    return;
                }
            }

        }

        private void msk_dtpReview_Leave(object sender, EventArgs e)
        {
            Control ctrl = sender as Control;
            if (ValidateDate(ctrl) == false)
            {
                msk_dtpReview.Text = "";
                msk_dtpReview.Focus();
                return;
            }
        }


        private void msk_dtp_tsRecOn_Leave(object sender, EventArgs e)
        {
            if (msk_dtp_tsRecOn.Text != "")
            {
                if (ValidateDate(msk_dtp_tsRecOn) == false)
                {
                    msk_dtp_tsRecOn.Text = "";
                    msk_dtp_tsRecOn.Focus();
                    return;
                }
            }
        }

        private void msk_dtpEA_recfromcd_Leave(object sender, EventArgs e)
        {
            if (msk_dtpEA_recfromcd.Text != "")
            {
                if (ValidateDate(msk_dtpEA_recfromcd) == false)
                {
                    msk_dtpEA_recfromcd.Text = "";
                    msk_dtpEA_recfromcd.Focus();
                    return;
                }
            }
        }


        //Boolean chkdgvContracts = false;
        //private void dgvContracts_CellClick(object sender, DataGridViewCellEventArgs e)
        //{
        //    chkdgvContracts = true;
        //}

        private void txtTenderBond_KeyDown(object sender, KeyEventArgs e)
        {
            nonNumberEntered = false;
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            {
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    if ((e.KeyCode != Keys.Back) & (e.KeyCode != Keys.Enter))
                    {
                        nonNumberEntered = true;
                    }
                }
            }
        }

        private void txtTenderBond_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (nonNumberEntered == true)
            {
                MessageBox.Show("Please enter number only...");
                e.Handled = true;
            }
        }

        private void txtDocumentFree_KeyDown(object sender, KeyEventArgs e)
        {
            nonNumberEntered = false;
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9) //|| e.KeyCode == Keys.Decimal
            {
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    if ((e.KeyCode != Keys.Back) & (e.KeyCode != Keys.Enter))
                    {
                        nonNumberEntered = true;
                    }
                }
            }
        }
        private void txtDocumentFree_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }

        private void msk_dtpTV_FEdate_ModifiedChanged(object sender, EventArgs e)
        {
            //Modified by Varun on 04 Feb 2014 based on Adonis req.

            if (msk_dtpTV_FEdate.Text != "")
            {
                if (ValidateDate(msk_dtpTV_FEdate) == false)
                {
                    msk_dtpTV_FEdate.Text = "";
                    msk_dtpTV_FEdate.Focus();
                    return;
                }
                if (msk_dtpTV_SEdate.Text == "" && msk_dtpTV_OrgDate.Text != "" && isCpContractorSign == false)
                {
                    if (Convert.ToDateTime(msk_dtpTV_OrgDate.Text) > Convert.ToDateTime(msk_dtpTV_FEdate.Text))
                    {
                        MessageBox.Show("Extension Date should be greater than Original Date");
                        msk_dtpTV_FEdate.Text = "";
                        msk_dtpTV_FEdate.Focus();
                        return;
                    }

                    if (msk_dtpTV_FEdate.Text != "")
                    {
                        int iDays = (Convert.ToDateTime(msk_dtpTV_FEdate.Text) - System.DateTime.Now.Date).Days;
                        txtTV_exipre.Text = iDays.ToString();
                    }
                }
            }
            if (msk_dtpTV_FEdate.Text != "" && isCpContractorSign == false)
            {
                int iDays = (Convert.ToDateTime(msk_dtpTV_FEdate.Text) - System.DateTime.Now.Date).Days;
                txtTV_exipre.Text = iDays.ToString();
            }
        }

        private void msk_dtpTV_SEdate_TextChanged(object sender, EventArgs e)
        {
            //UpdateTV_FirstExtension(msk_dtpTV_FEdate.Text);
        }

        private void msk_dtpTV_FEdate_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Modified by Varun on 04 Feb 2014 based on Adonis req.

            if (msk_dtpTV_FEdate.Text != "")
            {
                if (ValidateDate(msk_dtpTV_FEdate) == false)
                {
                    msk_dtpTV_FEdate.Text = "";
                    msk_dtpTV_FEdate.Focus();
                    return;
                }
                if (msk_dtpTV_SEdate.Text == "" && isCpContractorSign == false)
                {
                    if (Convert.ToDateTime(msk_dtpTV_OrgDate.Text) > Convert.ToDateTime(msk_dtpTV_FEdate.Text))
                    {
                        MessageBox.Show("Extension Date should be greater than Original Date");
                        msk_dtpTV_FEdate.Text = "";
                        msk_dtpTV_FEdate.Focus();
                        return;
                    }

                    if (msk_dtpTV_FEdate.Text != "")
                    {
                        int iDays = (Convert.ToDateTime(msk_dtpTV_FEdate.Text) - System.DateTime.Now.Date).Days;
                        txtTV_exipre.Text = iDays.ToString();
                    }
                }
            }
            //Modified by Varun on 04 Feb 2014 based on Adonis req.
            if (msk_dtpTV_FEdate.Text != "" && isCpContractorSign == false)
            {
                int iDays = (Convert.ToDateTime(msk_dtpTV_FEdate.Text) - System.DateTime.Now.Date).Days;
                txtTV_exipre.Text = iDays.ToString();
            }
        }


        

        private void btnDatesExtend_Click(object sender, EventArgs e)
        {
            frmExtDatesInfo tenderDatesExtend = new frmExtDatesInfo(_projID);
            // tenderDatesExtend.StartPosition = FormStartPosition.CenterParent;
            tenderDatesExtend.ShowDialog();
        }

        private void dgvPC_Contracts_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //if (userRightsColl.Contains("38"))
            //{
            //    MessageBox.Show("You have no privilege,Contact administrator");
            //    return;
            //}            
            //Modified by Varun on 30 Jan 2014 based on Sridher request
            int rowIndex = e.RowIndex;
            int colIndex = e.ColumnIndex;
            try
            {
                if (rowIndex != -1)
                {
                    if (colIndex == 0)
                    {
                        int bidId = Convert.ToInt16(dgvPC_Contracts.Rows[rowIndex].Cells[8].Value);
                        frmContractsEntry cntrEntry = null;
                        //if (dgvPC_Contracts.Rows[rowIndex].Cells[2].Value.ToString().ToLower() != "framework")
                        //{
                            cntrEntry = new frmContractsEntry(mUserRightsColl, bidId, _projID, null, _userName, mIsHeadOfSection, txtproj.Text, null, null, null);
                        //}
                        //else if (dgvPC_Contracts.Rows[rowIndex].Cells[2].Value.ToString().ToLower() == "framework")
                        //{
                        //    cntrEntry = new frmContractsEntry(mUserRightsColl, bidId, _projID, dgvPC_Contracts.Rows[rowIndex].Cells[9].Value.ToString(), _userName, mIsHeadOfSection, txtproj.Text, txtTenderNo.Text, msk_dtpEA_closeDate.Text, msk_dtpEA_stage1.Text);
                        //}

                        cntrEntry.StartPosition = FormStartPosition.CenterParent;
                        cntrEntry.ShowDialog();
                        clspC.refreshPCContracts_Data(dgvPC_Contracts, _projID);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void btnCntrSave_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Contains("46"))         // For TE
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            int statusID = getStatusID(ProjectId);           // statusID = 7 for contractProcess

            CP_Contract_InsertUpdate(dgvCntrStage3, mIsHeadOfSection);

            //tabControl1.SelectedIndex = 3;


            foreach (DataGridViewRow row in this.dgvCntrStage3.Rows)
            {
                if (row.Cells[4].Value != null)
                {
                    if (row.Cells[4].Value.ToString() != "")
                    {
                        if (statusID < 7)
                        {
                            clsCP_Stage clsCP = new clsCP_Stage(_userName,mIsHeadOfSection);
                            clsCP.Status_Award(6, lblProjID.Text);

                            // added by Varun on 11/05/2015                             
                            FillProjectInfo();
                            // Attempted by Varun on 11/05/2015 for refreshing the All Projects GridView but its not working, let user click on refresh button to do it manually
                            //TMS_MainView tmsMainView = new TMS_MainView(_userName);                                                
                        }
                    }
                }
            }

        }
         
        private void dgvCntrStage3_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvCntrStage3.IsCurrentCellDirty)
            {                 
                DataGridView dgv = sender as DataGridView;
                if (dgv.CurrentCell != null)
                {
                    if (dgv.CurrentCell.ColumnIndex == 0)
                    {
                        // ComboBox comboBox = e.Control as ComboBox;
                        if (e.RowIndex >= 0) //check if combobox column
                        {
                            object selectedValue = dgvCntrStage3.Rows[dgv.CurrentCell.RowIndex].Cells[dgv.CurrentCell.ColumnIndex].Value;

                            if (selectedValue is int)
                            {
                                string _cmpName = clsForCP.FillComapany_dgvComboValue(Convert.ToInt16(selectedValue));
                                dgvCntrStage3.Rows[dgv.CurrentCell.RowIndex].Cells[dgv.CurrentCell.ColumnIndex + 1].Value = _cmpName;
                            }
                        }
                        // comboBox.SelectedIndexChanged += LastColumnComboSelectionChanged;
                    }

                }
            }
            // suspendEventCellValueChanged = false;
        }

        //private void dgvCntrStage3_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        //{
        //    string CurrentRow = e.Row.Cells[5].Value.ToString();
        //    if (CurrentRow != null)
        //    {
        //        string sqlUpdate = "Delete from Contractors where Bidder_ID = @bidID";
        //        using (SqlConnection sqlCn = new SqlConnection(connStr))
        //        {
        //            sqlCn.Open();
        //            using (SqlCommand sqlCmd = new SqlCommand(sqlUpdate, sqlCn))
        //            {
        //                sqlCmd.Parameters.AddWithValue("@bidID", CurrentRow);
        //                sqlCmd.ExecuteNonQuery();
        //            }
        //            sqlCn.Close();
        //        }
        //    }
        //    DataGridView dgv = (DataGridView)sender;
        //    dgv.EditMode = DataGridViewEditMode.EditOnEnter;
        //    //ChkBidderProjectCostExist(CurrentRow);
        //}
        private void ChkBidderProjectCostExist(string CurrentRowData)
        {
            int _bidID = 0;
            string sqlQuery = "SELECT bidder_id from ProjectCost Where Bidder_ID = CurrentRowData";
            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(sqlQuery, sqlCn))
                {
                    using (SqlDataReader dr = sqlCmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                _bidID = Convert.ToInt16(dr[0]);
                            }
                        }
                    }
                }
                sqlCn.Close();
            }
            if (_bidID != 0)
            {
                string sqlUpdate = "Delete from ProjectCost where Bidder_ID = @bidID";
                using (SqlConnection sqlCn = new SqlConnection(connStr))
                {

                    sqlCn.Open();
                    using (SqlCommand sqlCmd = new SqlCommand(sqlUpdate, sqlCn))
                    {
                        sqlCmd.Parameters.AddWithValue("@bidID", _bidID);
                        sqlCmd.ExecuteNonQuery();
                    }
                    sqlCn.Close();
                }
            }
        }
        private void btnMinistry_Click(object sender, EventArgs e)
        {
            frmNewCodes frmMinCodes = new frmNewCodes();
            frmMinCodes.StartPosition = FormStartPosition.CenterScreen;
            frmMinCodes.ShowDialog();
        }
        private void btnBudgetRef_Click(object sender, EventArgs e)
        {
            frmNewCodes frmMinCodes = new frmNewCodes();
            frmMinCodes.StartPosition = FormStartPosition.CenterScreen;
            frmMinCodes.ShowDialog();
        }
        private void txtProvisionNo_Leave(object sender, EventArgs e)
        {
            if (txtProvisionNo.Text != "")
            {
                txtProvisionNo.Text.Trim().Replace(" ", "-").Replace("/", "-").Replace(".", "-");
                string[] provisionNoArray = null;
                bool isWrong = true;
                if (txtProvisionNo.Text.Contains("-"))
                {
                    provisionNoArray = txtProvisionNo.Text.Split('-');
                    int totalArrayIndex = 0;
                    while (totalArrayIndex < provisionNoArray.Length)
                    {
                        if (totalArrayIndex == 0)
                        {
                            if (provisionNoArray[totalArrayIndex].Length > 4)
                                isWrong = false;
                        }
                        else if (totalArrayIndex == 1)
                        {
                            if (provisionNoArray[totalArrayIndex].Length > 2)
                                isWrong = false;
                        }
                        else if (totalArrayIndex == 2)
                        {
                            if (provisionNoArray[totalArrayIndex].Length > 4)
                                isWrong = false;
                        }
                        totalArrayIndex++;
                    }
                }
                else
                    isWrong = false;

                if (isWrong == false)
                {
                    MessageBox.Show("Provision Number must be in the xxxx-xx-xxxx format");
                    return;
                }

                if (isWrong == true && provisionNoArray != null)
                {
                    if (provisionNoArray.Length < 3)
                    {
                        MessageBox.Show("Provision Number must be in the xxxx-xx-xxxx format");
                        return;
                    }
                }
                else if (isWrong == true && provisionNoArray == null)
                {
                    MessageBox.Show("Provision Number must be in the xxxx-xx-xxxx format");
                    return;
                }

                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        if (sqlConn.State == ConnectionState.Closed)
                            sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"Update Projects set Provision_Number = @ProvNumber where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@projId", Convert.ToInt16(lblProjID.Text));
                        cmd.Parameters.AddWithValue("@ProvNumber", txtProvisionNo.Text);
                        int exUpdated = cmd.ExecuteNonQuery();

                        cmd.Parameters.Clear();
                    }
                }
            }
        }

        private bool UpdateMinistryCode()
        {
            bool isTrue = false;
            if (cmbMinistryCode.Text != "")
            {
                if (cmbMinistryCode.Text.Length > 5)
                {
                    MessageBox.Show("Cannot enter more than five characters in the Ministry Code");
                    cmbMinistryCode.Focus();
                    return isTrue;
                }
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        if (sqlConn.State == ConnectionState.Closed)
                            sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"Update Projects set Ministry_Code = @Minstry_Code where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@projId", Convert.ToInt16(lblProjID.Text));
                        cmd.Parameters.AddWithValue("@Minstry_Code", cmbMinistryCode.Text);
                        int exUpdated = cmd.ExecuteNonQuery();

                        cmd.Parameters.Clear();
                        isTrue = true;
                    }
                }
            }
            else
                isTrue = true;
            return isTrue;
        }
        private bool UpdateBudgetCode()
        {
            bool isTrue = true;
            if (cmbBudgetRef.Text.Length > 7)
            {
                MessageBox.Show("Cannot enter more than seven characters in the Budget Ref No.");
                cmbBudgetRef.Focus();
                isTrue = false;
                return isTrue;
            }
            else
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        if (sqlConn.State == ConnectionState.Closed)
                            sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"Update Projects set Budget_Reference_No = @BudgetCode where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@projId", Convert.ToInt16(lblProjID.Text));
                        cmd.Parameters.AddWithValue("@BudgetCode", cmbBudgetRef.Text);
                        int exUpdated = cmd.ExecuteNonQuery();

                        cmd.Parameters.Clear();
                        isTrue = true;
                    }
                }
            }
            return isTrue;
        }
        private void btnExportToPdf_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Contains("44"))
            {
                MessageBox.Show("You have no privilege to View Tender Collection Summary Report. Please Contact system administrator.");
                return;
            }
            CommonClass comCls = new CommonClass(_userName);
            DataTable dtViewBidders = null;
            dtViewBidders = comCls.LoadCircularOrNonCircularData(0, 'N', null, _projID, null, null, null, 'N', _chGetShortListed);
            int circularCnt = clsForTS.GetCircularCount(_projID);
            short modifiedClosingDateCount = clsForTS.GetModifiedClosingDateCount(_projID);
            //Modified By Varun on 16th Feb 2014 replace prAdvDate by tenderIssueDate based on Riyas request

            // comCls.ExportToPDF(connStr, sqlCom, null, dtViewBidders.DefaultView, txtTenderNo.Text, txtProjCode.Text, txtproj.Text, _projID, msk_dtp_tsStage1.Text, msk_dtp_tsModifiedDate.Text.Split(' ')[0].ToString(), circularCnt, txtTenderBond.Text, txtDocumentFee.Text, msk_dtp_tsInvitation.Text, 'N', 'N', strEligibleTenderTypes, _tndrType, modifiedClosingDateCount, null, ref outTenderSubmissionDateAndTime,1,""); //msk_dtp_tsAdvertisement

            comCls.ExportToPDF(connStr, sqlCom, null, dtViewBidders.DefaultView, txtTenderNo.Text, txtProjCode.Text, txtproj.Text, _projID, msk_dtp_tsStage1.Text, msk_dtp_tsModifiedDate.Text.Split(' ')[0].ToString(), circularCnt, txtTenderBond.Text, txtDocumentFee.Text, msk_dtp_tsInvitation.Text, 'N', 'N', strEligibleTenderTypes, _tndrType, modifiedClosingDateCount, null, 1, "", 1, null, false); //msk_dtp_tsAdvertisement
            //>>>>>>> .r21
        }

        private void btnViewShortList_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Contains("69"))
            {
                MessageBox.Show("You have no privilege to View Short List. Please Contact system administrator.");
                return;
            }

            string strSelectedCompanies = string.Empty;
            strSelectedCompanies = commCls.chkAccessRightsAndSelectedCompanies('S', mUserRightsColl, null, null, chkLocal, chkInternational, chkJointVenture);
            if (strSelectedCompanies == "R")
                return;
            //Modified By Varun on 16th Feb 2014 replace msk_dtp_tsAdvertisement by tenderIssueDate based on Riyas request
            MDI_ParenrForm.Projects.frmBidderInfo frmbidders = new MDI_ParenrForm.Projects.frmBidderInfo(mUserRightsColl, _projID, txtProjCode.Text, txtproj.Text, txtTenderNo.Text, strSelectedCompanies, _userName, txtTenderBond.Text, txtDocumentFee.Text, msk_dtp_tsInvitation.Text, 'S', strEligibleTenderTypes, 'Y', _tndrType, 1);
            frmbidders.Text = "ShortList Information Window";
            Control[] ctrlColl = frmbidders.Controls.Find("groupBox1", false);
            ctrlColl[0].Text = "ShortList Information";
            frmbidders.StartPosition = FormStartPosition.CenterScreen;
            frmbidders.ShowDialog();
        }

        // Added By Varun

        // For update combo value
        Object newEnteredValue = null;
        private void dgvContracts_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            if (e.ColumnIndex == 3)
            {
                if (dgvContracts.CurrentCell.IsInEditMode)
                {
                    if (dgvContracts.CurrentCell.GetType() == typeof(DataGridViewComboBoxCell))
                    {
                        DataGridViewComboBoxCell cell =
                        (DataGridViewComboBoxCell)dgvContracts.Rows[e.RowIndex].Cells[e.ColumnIndex];
                        cell.Value = e.FormattedValue;
                        cell.Selected = true;
                        newEnteredValue = e.FormattedValue;
                    }
                }
            }
        }
        // Added By Varun

        // For update combo value
        private void dgvContracts_CellValidated(object sender, DataGridViewCellEventArgs e)
        {
            // the cells under the column of index 1 are going to display
            //the property of a complex type
            if (dgvContracts.CurrentCell.GetType() == typeof(DataGridViewComboBoxCell))
            {
                DataGridViewCell cell = dgvContracts.Rows[e.RowIndex].Cells[e.ColumnIndex];
                cell.Value = newEnteredValue;
                cell.Selected = true;
                dgvContracts.CurrentCell.DataGridView.EndEdit(DataGridViewDataErrorContexts.Commit);
            }
            
        }

        clsDatabase dalCls = new clsDatabase("");
        string strEligibleTenderTypes = null;

        private void grpEligibleCompaniesCheckBoxes_CheckedChanged(object sender, EventArgs e)
        {
            if (isOnLoad != false)
            {
                StringBuilder strBuild = new StringBuilder();
                var checked_boxes = grpEligibleCompanies.Controls.OfType<CheckBox>().Where(c => c.Checked);
                foreach (CheckBox cbx in checked_boxes)
                {

                    if (cbx.Text == "Local")
                    {
                        if (strBuild.Length != 0)
                            strBuild.Append(",Local");
                        else
                            strBuild.Append("Local");
                    }
                    if (cbx.Text == "International")
                    {
                        if (strBuild.Length != 0)
                            strBuild.Append(",International");
                        else
                            strBuild.Append("International");
                    }
                    if (cbx.Text == "Joint Venture")
                    {
                        if (strBuild.Length != 0)
                            strBuild.Append(",Joint Venture");
                        else
                            strBuild.Append("Joint Venture");
                    }
                }
                try
                {
                    clsDatabase clsDb = new clsDatabase(connStr);
                    clsDb.ConnectDB();
                    strEligibleTenderTypes = strBuild.ToString();
                    clsDb.ExecuteNonQuery("update PROJECTS set EligibleTenderTypes='" + strBuild.ToString() + "' where proj_id=" + _projID);
                    clsDb.DisconnectDB();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while updating eligible tender types", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void txtTenderBond_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }
        private void txtTenderBond_KeyDown_1(object sender, KeyEventArgs e)
        {
            nonNumberEntered = false;
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9) //|| e.KeyCode == Keys.Decimal
            {
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    if ((e.KeyCode != Keys.Back) & (e.KeyCode != Keys.Enter))
                    {
                        nonNumberEntered = true;
                    }
                }
            }
            if (txtTenderBond.Text == "")
            {
                if ((e.KeyData != Keys.Back) & (e.KeyCode != Keys.Enter))
                {
                    if (clsForTE.CheckProjectCostDataExist(_projID) == false)
                    {
                        clsForTS.InsertTS_TenderBond_ProjectCostData(txtTenderBond.Text, _projID);
                    }
                    else
                    {
                        clsForTS.UpdateTS_TenderBond_ProjectCostData(txtTenderBond.Text, _projID);
                    }
                }
            }
        }
        private void InsertData()
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"INSERT INTO ProjectTypes(prjID,prjType,Create_Date,Create_User) VALUES " +
                        " (@projId,@prjType,@CreateDate,@CreateUser)";

                        cmd.Parameters.AddWithValue("@projId", ProjectId);
                        cmd.Parameters.AddWithValue("@prjType", txtCmpType.Text.Trim());
                        cmd.Parameters.AddWithValue("@CreateDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@CreateUser", _userName);
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void UpdateData(string updateVal)
        {
            string strVal = txtCmpType.Text;
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"Update ProjectTypes SET prjType = @prjType,Update_Date = @UpdateDate,Update_User = @UpdateUser where prjID = @projId";
                        cmd.Parameters.AddWithValue("@projId", ProjectId);
                        cmd.Parameters.AddWithValue("@prjType", updateVal);
                        cmd.Parameters.AddWithValue("@UpdateDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@UpdateUser", _userName);
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private Boolean getData(int prjID)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = "SELECT prjType FROM ProjectTypes where prjID = " + prjID + "";
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                txtCmpType.Text = dr[0].ToString();
                                return true;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            return false;
        }
        // Functionality added by sreedhar on Jan 21st 14 for faisal request
        private void button1_Click(object sender, EventArgs e)
        {
            string strVal = string.Empty;
            strVal = txtCmpType.Text;

            if (getData(ProjectId) == false)
            {
                InsertData();
                getData(ProjectId);
            }
            else
            {
                UpdateData(strVal);
                getData(ProjectId);
            }
        }

        // Added by Varun on 23/02/14 for formatting the amount
        private void dgvContracts_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.ColumnIndex == 1)
            {
                object val = dgvContracts.Rows[e.RowIndex].Cells[1].Value;
                if ((val != null) && !object.ReferenceEquals(val, DBNull.Value))
                {
                    e.Value = string.Format("{0:#,##0.00}", double.Parse(dgvContracts.Rows[e.RowIndex].Cells[1].Value.ToString()));//#,##0
                }
            }
        }

        frmTenderSubmission frmTndrSub = null;
        private void btnGenerateReceipt_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
            {
                if (mUserRightsColl.Contains("70"))
                {
                    MessageBox.Show("Do not have access rights to open Tender Submission, Please contact Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }

            string tenderClosingDate = "";

            if (msk_dtpEA_closeDate.Text != "")
                tenderClosingDate = msk_dtpEA_closeDate.Text;
            else
                tenderClosingDate = msk_dtpEA_stage1.Text;

            if (tenderClosingDate != "")
            {
                if (txtTenderNo.Text.Contains("STC"))
                    frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("STC", txtTenderNo.Text, proj_Title, _projID, _userName, tenderClosingDate, mUserRightsColl,null,null, mIsHeadOfSection, false);
                else if (txtTenderNo.Text.Contains("GTC"))
                    frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("GTC", txtTenderNo.Text, proj_Title, _projID, _userName, tenderClosingDate, mUserRightsColl, null,null, mIsHeadOfSection, false);
                else if (txtTenderNo.Text.Contains("ITC"))
                    frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("ITC", txtTenderNo.Text, proj_Title, _projID, _userName, tenderClosingDate, mUserRightsColl, null,null, mIsHeadOfSection, false);
                else if (txtTenderNo.Text.Contains("MRPSC"))
                    frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("MRPSC", txtTenderNo.Text, proj_Title, _projID, _userName, tenderClosingDate, mUserRightsColl, null,null, mIsHeadOfSection, false);
                else if (txtTenderNo.Text.Contains("EUWC"))
                    frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("EUWC", txtTenderNo.Text, proj_Title, _projID, _userName, tenderClosingDate, mUserRightsColl, null,null, mIsHeadOfSection, false);
                else if (txtTenderNo.Text.Contains("NC"))
                    frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("NC", txtTenderNo.Text, proj_Title, _projID, _userName, tenderClosingDate, mUserRightsColl, null,null, mIsHeadOfSection, false);
                frmTndrSub.StartPosition = FormStartPosition.CenterParent;
                frmTndrSub.ShowDialog();
            }
            //commCls.ExportToPDF(strCon,sqlCom,null,null,txtTenderNo.Text,_prjCode,proj_Title,_projID,null,null,0,null,txtDocumentFee.Text,
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (mUserRightsColl.Contains("19"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            SentDocProperties sentDocProp = new SentDocProperties(mUserRightsColl, Convert.ToInt16(lblProjID.Text), 3, _userName, true);
            sentDocProp.StartPosition = FormStartPosition.CenterParent;
            sentDocProp.ShowDialog();

            commCls.FillGridSentDocsInfo(Convert.ToInt16(lblProjID.Text), dgvTE_Sent, 3);
        }

        private void txtTechEvalProposedWorkDays_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }

        private void txtFinEvalProposedWorkDays_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Contains("46"))
            {
                MessageBox.Show("You have no privilege, Contact administrator");
                return;
            }

            int iCnt = 0;
            for (int iCounter = 0; iCounter < dgvCntrStage3.RowCount; iCounter++)
            {
                DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgvCntrStage3.Rows[iCounter].Cells[0];
                if (chkactive.Value != null)
                {
                    if (chkactive.Value.ToString().ToLower() == "true")
                        iCnt = iCnt + 1;
                }
            }
            if (iCnt > 1)
            {
                MessageBox.Show("Please select only one record to delete", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else if (iCnt == 0)
            {
                MessageBox.Show("Please click the checkbox of the record you wish to delete", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            DialogResult dlgResult = DialogResult.Yes;
            dlgResult = MessageBox.Show(" Are you sure you want to DELETE the record?", "Delete Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (dlgResult.ToString() == "Yes")
            {
                clsForCP = new clsCP_Stage(_userName, mIsHeadOfSection);
                for (int iCounter = 0; iCounter < dgvCntrStage3.RowCount; iCounter++)
                {
                    DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgvCntrStage3.Rows[iCounter].Cells[0];
                    if (chkactive.Value != null)
                    {
                        if (chkactive.Value.ToString().ToLower() == "true")
                        {
                            string sqlUpdate = "Delete from Contractors where Bidder_ID = @bidID and proj_id=@projId";
                            using (SqlConnection sqlCn = new SqlConnection(connStr))
                            {
                                sqlCn.Open();
                                using (SqlCommand sqlCmd = new SqlCommand(sqlUpdate, sqlCn))
                                {
                                    sqlCmd.Parameters.AddWithValue("@bidID", dgvCntrStage3.Rows[iCounter].Cells[5].Value);
                                    sqlCmd.Parameters.AddWithValue("@projId", dgvCntrStage3.Rows[iCounter].Cells[6].Value);
                                    sqlCmd.ExecuteNonQuery();
                                }
                                sqlCn.Close();
                                bool isUpdated = false;
                                if (msk_dtpEA_datesent.Text != "" & msk_dtpEA_datesentfin.Text == "")
                                {
                                    clsForCP.FillContractsGrid_TE(dgvCntrStage3, _projID, 3);
                                    isUpdated = true;
                                }
                                else if (msk_dtpEA_datesent.Text != "" & msk_dtpEA_datesentfin.Text != "")
                                {
                                    if (Convert.ToDateTime(msk_dtpEA_datesent.Text.ToString()).CompareTo(Convert.ToDateTime(msk_dtpEA_datesentfin.Text.ToString())) == 0)
                                    {
                                        clsForCP.FillContractsGrid_TE(dgvCntrStage3, _projID, 3);
                                        isUpdated = true;
                                    }
                                    else if (Convert.ToDateTime(msk_dtpEA_datesent.Text.ToString()).CompareTo(Convert.ToDateTime(msk_dtpEA_datesentfin.Text.ToString())) != 0)
                                    {
                                        clsForCP.FillContractsGrid_TE(dgvCntrStage3, _projID, 5);
                                        isUpdated = true;
                                    }
                                }

                                if (isUpdated)
                                    FillProjectInfo();
                            }
                        }
                    }
                }
            }

        }

        private void btnSaveMinistry_Click(object sender, EventArgs e)
        {
            UpdateMinistryCode();
        }

        private void btnBudgetRefNo_Click(object sender, EventArgs e)
        {
            UpdateBudgetCode();
        }

        private void btnWOTenderSubmission_Click(object sender, EventArgs e)
        {
            
        }

        private void btnWorkOrder_Click(object sender, EventArgs e)
        {           
            frmWorkOrders frmWorkOrders = null;
            frmWorkOrders = new MDI_ParenrForm.Projects.frmWorkOrders(mUserRightsColl, _projID, txtTenderNo.Text, txtproj.Text, _userName, mIsHeadOfSection);            
            frmWorkOrders.StartPosition = FormStartPosition.CenterParent;
            frmWorkOrders.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Count!=0)         // For TE
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }
            
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        if(cmbTenderStatusChange.SelectedValue.ToString()=="1")
                            cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]=" + cmbTenderStatusChange.SelectedValue + ",stage_id=1,update_user='" + _userName + "',update_date='"+DateTime.Now.ToString()+"' Where proj_id=@projId";
                        else if (cmbTenderStatusChange.SelectedValue.ToString() == "2")
                            cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]=" + cmbTenderStatusChange.SelectedValue + ",stage_id=2,update_user='" + _userName + "',update_date='" + DateTime.Now.ToString() + "' Where proj_id=@projId";
                        else if (cmbTenderStatusChange.SelectedValue.ToString() == "3")
                            cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]=" + cmbTenderStatusChange.SelectedValue + ",stage_id=3,update_user='" + _userName + "',update_date='" + DateTime.Now.ToString() + "' Where proj_id=@projId";
                        else if (cmbTenderStatusChange.SelectedValue.ToString() == "4")
                            cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]=" + cmbTenderStatusChange.SelectedValue + ",stage_id=3,update_user='" + _userName + "',update_date='" + DateTime.Now.ToString() + "' Where proj_id=@projId";
                        else if (cmbTenderStatusChange.SelectedValue.ToString() == "5")
                            cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]=" + cmbTenderStatusChange.SelectedValue + ",stage_id=3,update_user='" + _userName + "',update_date='" + DateTime.Now.ToString() + "' Where proj_id=@projId";
                        else if (cmbTenderStatusChange.SelectedValue.ToString() == "6")
                            cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]=" + cmbTenderStatusChange.SelectedValue + ",stage_id=4,update_user='" + _userName + "',update_date='" + DateTime.Now.ToString() + "' Where proj_id=@projId";
                        else if (cmbTenderStatusChange.SelectedValue.ToString() == "7")
                            cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]=" + cmbTenderStatusChange.SelectedValue + ",stage_id=4,update_user='" + _userName + "',update_date='" + DateTime.Now.ToString() + "' Where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@projId", _projID);
                       
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
                FillProjectInfo();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
         
        }
       
       
    }

}
