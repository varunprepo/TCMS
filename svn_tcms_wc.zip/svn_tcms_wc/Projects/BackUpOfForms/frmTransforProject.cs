﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq; 
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Transactions;
using MDI_ParenrForm;
using TenderTrackingSystem;
using System.Net.Mail;
using System.DirectoryServices;


namespace MDI_ParenrForm.Projects
{
    public partial class frmTransforProject : Form
    {         
        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();        
        protected SqlConnection sqlConn = null;
        protected SqlCommand sqlCom = null;
        IList<string> userRightsColl = new List<string>();
        int _prjIDExist = 0; string _committee = string.Empty;
        string _tndrStatus = string.Empty;
        string _tndrType = string.Empty; string _prjCodeExisted = string.Empty;
        string _tenderNo = string.Empty;
        string _userName = string.Empty;
        string _fiscalYear = string.Empty;
        string _projTitle = string.Empty;
        int _newPrjID = 0;

        char chProjTransfered = ' ';
        public char ProjTransfered
        {
            get { return chProjTransfered; }
            set { chProjTransfered = value; }
        }

        char chProjReTendered = ' ';
        public char ProjReTender
        {
            get { return chProjReTendered; }
            set { chProjReTendered = value; }
        }
        
        public frmTransforProject(int prjID, string tndrType, string cmtName, IList<string> userRightsCollContacts, string tenderStatus, string strPrjCode, string strTenderNo, string userName, string fiscalYear, string strProjTitle)
        {
            InitializeComponent();
            userRightsColl = userRightsCollContacts;
            _prjIDExist = prjID;
            _committee = cmtName;
            _tndrType = tndrType;
            _tndrStatus = tenderStatus;
            _prjCodeExisted = strPrjCode;
            _tenderNo = strTenderNo;
            _newPrjID = GetMaxID("SELECT MAX(proj_id) from Projects");
            _userName = userName;
            _fiscalYear = fiscalYear;
            _projTitle = strProjTitle;
        }

        public int GetNewProjId()
        {
           return _newPrjID;         
        }
        int _maxPrjiD = 0;
        private int GetMaxID(string sqlQuery)
        {
            SqlConnection sqlCon = new SqlConnection(strCon);        
            sqlCon.Open();
            try
            {                 
                SqlCommand sqlCommand = new SqlCommand(sqlQuery, sqlCon);
                _maxPrjiD = Convert.ToInt16(sqlCommand.ExecuteScalar());
                _maxPrjiD = _maxPrjiD + 1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlCon.Close();
            }
            return _maxPrjiD;
        }

        string newTndrNo = null;         
        DataSet dsStg2 = new DataSet();
        DataSet dsStg3 = new DataSet();

        private void transforTenderDates_Stage2_TEMP()
        {
            string sqlQuery = "SELECT date_id, proj_id, stage_id, ts_receive_on, ts_issue_handling, ts_return_to_dept, ts_receive_from_dept, ts_pr_advertise, ts_tender_invitation, ts_closing_s1," +
            "ts_closing_s2, ts_modified_closing, ts_tender_issue, ts_receipt_no,co_id,employee_id,remarks,org_tender_validity,org_tenderbond_validity,org_tender_to_expire,org_tenderbond_to_expire," +
            "tender_validity_ext1,tender_validity_ext2,tenderbond_validity_ext1,tenderbond_validity_ext2,Tender_Issued,SN,create_date,update_date,create_user,update_user,Alert,Company_EmailID FROM TenderDatesInfo WHERE (proj_id = " + 1304 + ") AND (stage_id = 2) ORDER BY date_id asc";

            SqlConnection sqlConn = new SqlConnection(strCon);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataAdapter daStage2 = new SqlDataAdapter(sqlCom);
            daStage2.Fill(dsStg2);
            sqlConn.Close();
            if (dsStg2.Tables[0].Rows.Count > 0)
            {
                InsertTenderStageInfo_Temp(dsStg2);
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            CommonClass comCls = new CommonClass(_userName);
            if (_tndrStatus.Equals("9"))
            {
                userListColl.Clear();
                UserList_ForAlert(1, _committee);

                if (userListColl.Count == 0)
                {
                    MessageBox.Show("Information for Tender No.assignment is required to be sent to a user who handles " + _committee + " projects, " +
                      " but there is no identified user to receive the email. Please contact system administrator for information.");
                    return;
                }
                // this.Visible = false;
                DialogResult dlgResult = DialogResult.Yes;
                dlgResult = MessageBox.Show("A copy of this Project will be created and this version shall be sent to Archives if you choose to Re-tender this Project." +
                " Are you sure want to re-tender this project? ", "", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                string reTenderNo = null;
                if (dlgResult.ToString() == "Yes")
                {                   

                    // Modified on Dec 30th 2013
                    string[] strTndrNoColl = _tenderNo.Split('-');
                    string strTndr = strTndrNoColl[strTndrNoColl.Length - 1];

                    string strPrjPrefix = string.Empty;
                    if (strTndr.Contains("R"))
                    {
                        strPrjPrefix = _tenderNo.Substring(_tenderNo.LastIndexOf('/'));
                        strPrjPrefix = strPrjPrefix.Substring(2);
                        if (strPrjPrefix != "")
                        {
                            int incrementedIdx = Convert.ToInt16(strPrjPrefix) + 1;
                            strPrjPrefix = "/R" + incrementedIdx;
                        }
                        else
                            strPrjPrefix = "/R1";
                    }
                    else
                    {
                        strPrjPrefix = "/R";
                    }

                    // added by Varun on 3 Jun 2015
                    string pubOrLim = null;
                    if (grpBoxTenderType.Visible)
                    {
                        if (rdbLimited.Checked)
                            pubOrLim = "L";
                    }
                    if (Regex.Matches(_tenderNo, "/").Count == 4 && _tenderNo.Split('/')[0].ToString() == "PWA" && !strTndr.Contains("R"))
                    {
                        if (pubOrLim != null)
                        {
                            if (!_tenderNo.Contains("/L"))
                                reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + "/" + _tenderNo.Split('/')[3] + "/" + _tenderNo.Split('/')[4] + "/" + pubOrLim + strPrjPrefix;
                            else
                                reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + "/" + _tenderNo.Split('/')[3] + "/" + _tenderNo.Split('/')[4] + strPrjPrefix;
                        }
                        else
                            reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + "/" + _tenderNo.Split('/')[3] + "/" + _tenderNo.Split('/')[4] + strPrjPrefix;
                    }
                    else if (Regex.Matches(_tenderNo, "/").Count == 3 && _tenderNo.Split('/')[0].ToString() == "PWA" && !strTndr.Contains("R"))
                    {
                        if (pubOrLim != null)
                        {
                            if (!_tenderNo.Contains("/L"))
                                reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + "/" + _tenderNo.Split('/')[3] + "/" + pubOrLim + strPrjPrefix;
                            else
                                reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + "/" + _tenderNo.Split('/')[3] + strPrjPrefix;
                        }
                        else
                            reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + "/" + _tenderNo.Split('/')[3] + strPrjPrefix;
                    }
                    else if (Regex.Matches(_tenderNo, "/").Count == 4 && _tenderNo.Split('/')[0].ToString() == "MRPSC" && !strTndr.Contains("R"))
                    {
                        if (pubOrLim != null)
                        {
                            if (!_tenderNo.Contains("/L"))
                                reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + "/" + _tenderNo.Split('/')[3] + "/" + _tenderNo.Split('/')[4] + "/" + pubOrLim + strPrjPrefix;
                            else
                                reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + "/" + _tenderNo.Split('/')[3] + "/" + _tenderNo.Split('/')[4] + strPrjPrefix;
                        }
                        else
                            reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + "/" + _tenderNo.Split('/')[3] + "/" + _tenderNo.Split('/')[4] + strPrjPrefix;
                    }
                    else if (Regex.Matches(_tenderNo, "/").Count == 3 && _tenderNo.Split('/')[0].ToString() == "MRPSC" && !strTndr.Contains("R"))
                    {
                        if (pubOrLim != null)
                        {
                            if (!_tenderNo.Contains("/L"))
                                reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + "/" + _tenderNo.Split('/')[3] + "/" + pubOrLim + strPrjPrefix;
                            else
                                reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + "/" + _tenderNo.Split('/')[3] + strPrjPrefix;
                        }
                        else
                            reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + "/" + _tenderNo.Split('/')[3] + strPrjPrefix;
                    }
                    else if (Regex.Matches(_tenderNo, "/").Count == 2 && _tenderNo.Split('/')[0].ToString() == "MRPSC" && !strTndr.Contains("R"))
                    {
                        if (pubOrLim != null)
                        {
                            if (!_tenderNo.Contains("/L"))
                                reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + "/" + pubOrLim + strPrjPrefix;
                            else
                                reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + strPrjPrefix;
                        }
                        else
                            reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + strPrjPrefix;
                    }
                    else if (Regex.Matches(_tenderNo, "/").Count == 2 && (_tenderNo.Split('/')[0].ToString() == "U&EWTC" || _tenderNo.Split('/')[0].ToString() == "EUWC") && !strTndr.Contains("R"))
                    {
                        if (pubOrLim != null)
                        {
                            if (!_tenderNo.Contains("/L"))
                                reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + "/" + pubOrLim + strPrjPrefix;
                            else
                                reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + strPrjPrefix;
                        }
                        else
                            reTenderNo = _tenderNo.Split('/')[0] + "/" + _tenderNo.Split('/')[1] + "/" + _tenderNo.Split('/')[2] + strPrjPrefix;
                    }
                    else
                    {                         
                        reTenderNo = _tenderNo.Substring(0, _tenderNo.LastIndexOf('/'));                      

                        if (pubOrLim != null)
                        {
                            if (!reTenderNo.Contains("/L"))
                                reTenderNo = reTenderNo + "/" + pubOrLim + strPrjPrefix;
                            else
                                reTenderNo = reTenderNo + strPrjPrefix;
                        }
                        else
                            reTenderNo = reTenderNo + strPrjPrefix;
                    }
                    if (pubOrLim != null)
                        _tndrType = pubOrLim;

                    transforProjectsInfo(strPrjPrefix, _tndrStatus, reTenderNo);
                    dateID = MaxDateID();
                    transforTenderDates_Stage1();
                    // transforTenderDates_Stage2();
                    //transforTenderDates_Stage3();      

                    transfor_ProjectCost();

                    UpdateDocumnts_ProjectID();

                    UpdateProjectStatus(9);

                    // Added by Varun on 5th Nov 2015
                    dateID = MaxDateID();
                    using (SqlConnection sqlConn = new SqlConnection(strCon))
                    {
                        sqlConn.Open();
                        sqlCom = new SqlCommand();
                        sqlCom.Connection = sqlConn;
                        sqlCom.CommandText = @"insert into TenderDatesInfo(proj_id,date_id,stage_id,remarks,update_date,update_user) values("+_prjIDExist+","+ dateID +",2,'This tender was Re-Tendered by " + _userName + " Dated " + DateTime.Now.ToString() + "','" + DateTime.Now.ToString() + "','" +
                        _userName+"')";                         
                        sqlCom.ExecuteNonQuery();
                        sqlCom.Parameters.Clear();

                        dateID = MaxDateID();
                        sqlCom.CommandText = @"insert into TenderDatesInfo(proj_id,date_id,stage_id,remarks,update_date,update_user) values("+_prjIDExist+","+ dateID + ",3,'This tender was Re-Tendered by " + _userName + " Dated " + DateTime.Now.ToString() + "','" + DateTime.Now.ToString() + "','" +
                        _userName + "')";
                        sqlCom.ExecuteNonQuery();
                        sqlCom.Parameters.Clear();                        
                    }

                    MessageBox.Show("Copy of Project for Retender is now ready for updating the record. Old version of the record was sent to Archives");
                    
                    //string DisplayName = ""; string Email = ""; string Department = ""; string Title = "";
                    string user_Department = ""; string affair_Name = ""; //string user_Title = ""
                    // AlertOnNewTenderNo(tenderNo, _projID.ToString(), "New Project");

                    clsTs_Stage clsForTS = new clsTs_Stage(_userName);

                    clsForTS.GetAffairsName(_prjIDExist, ref user_Department, ref affair_Name);
                    string fromUser = null;
                    fromUser = comCls.getUserEmailID(_userName);
                    string tenderTypeFullName = null;
                    if (_tndrType == "L")
                        tenderTypeFullName = "Limited";
                    else if (_tndrType == "DO")
                        tenderTypeFullName = "Direct Order";
                    else if (_tndrType == "PT")
                        tenderTypeFullName = "Public Tender";
                    else
                        tenderTypeFullName = "Re-Tender";

                    try
                    {
                        // Modified the parameters of the function GetUserInformation4rmActiveDirectory by Varun on 04/03/14 because its fetching the department of the person not the committee                        
                        foreach (string strname in userListColl)
                        {           

                            MailMessage mailMessage = new MailMessage();
                            //mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["MailFrom"].ToString());

                            mailMessage.From = new MailAddress(fromUser);
                            mailMessage.To.Add(new MailAddress(strname));
                            mailMessage.Subject = "TCMS Alert: Tender No. " + _tenderNo + " is Re-Tendered";
                            mailMessage.IsBodyHtml = true;

                            mailMessage.Body = "<html><body><i style='font-family:Calibri; font-size:15'>Dear Sir/Madam,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Tender & Contract Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>" +
                            "Please be noted that</i><i style='color:Maroon;font-family:Calibri; font-size:15'> Tender No. " + _tenderNo + "</i><i style='font-family:Calibri; font-size:15'> has been Re-Tendered and the new Tender No. is <i style='color:Maroon;font-family:Calibri; font-size:15'>" + reTenderNo + "</i> and the details are as follows:-</i><br /><br />" +
                            "<table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:#548DD4;color:White;font-family:Calibri;font-size:18;font-weight:bold'>TENDER NO: " + reTenderNo + "</td>" +
                            "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Code</i></td><td style='font-family:Calibri;font-size:15'>" + _prjCodeExisted + "</td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Project Title</i></td><td style='font-family:Calibri;font-size:15'>" + _projTitle + "</td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Type of Tender</i></td><td style='font-family:Calibri;font-size:15'>" + tenderTypeFullName + "</td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Tender Committee</i></td><td style='font-family:Calibri;font-size:15'>" + _committee + "</td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Financial Year</i></td><td style='font-family:Calibri;font-size:15'>" + _fiscalYear + "</td></tr>" +       //+ "(" + _AffairsName + ")
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>User Dept.</i></td><td style='font-family:Calibri;font-size:15'>" + user_Department + " / " + affair_Name + " </td></tr>" +
                            "<tr><td style='background-color:#B58AA5;font-family:Calibri;font-size:15'><i>Date of Creation</i></td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr>" +
                            "</table><br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>TCMS Team</div></body></html>"; 

                            SmtpClient client = new SmtpClient();
                            client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                            client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                            client.Send(mailMessage);
                        }
                        
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Exception occurred while sending the email notification to Tender Committee, Please inform them Personally", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
                ProjReTender = 'Y';
                this.Close();
            }
            else
            {
                userListColl.Clear();
                UserList_ForAlert(3, _committee);

                if (userListColl.Count == 0)
                {
                    MessageBox.Show("Information for Tender Number Assignment is required to be sent to a user who handles " + _committee + " projects, " +
                      " but there is no identified user to receive the email. Please contact system administrator for information.");
                    return;
                }
               
                DialogResult dlgResult = DialogResult.Yes;
                dlgResult = MessageBox.Show("Are you sure want to transfer this Project to " + cmbCommittee.Text + "?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                DataTable dtTenderDatesInfoData = null;

                Int16 loopCtr = 0;
                DAL dalObj = new DAL();
                string sqlQuery = null;

                if (dlgResult.ToString() == "Yes")
                {
                    try
                    {
                        string strType = string.Empty;
                        strType = "Transfer";
                        string strPrjPrefix = " - (From " + _committee + ")";                       
                        transforProjectsInfo(strPrjPrefix, strType, null);

                        transforTenderDates_Stage1();
                        transforTenderDates_Stage2();                         
                        transforTenderDates_Stage3();                      

                        transfor_ProjectCost();
                        UpdateProjectStatus(10); //10==Transferred To Other Committee

                        string _tndrTypeName = string.Empty;
                        string _userDept = string.Empty;
                        string _prjCreaedOn = string.Empty;
                        string _AffairsName = string.Empty;
                        string _newFiscalYear = string.Empty;

                        newTndrNo = comCls.AssignTenderNo_For_Transfor(userRightsColl, _newPrjID, _tndrType, currentProjCode, _projTitle, 'T', _committee, _tenderNo, ref  _tndrTypeName, ref _userDept, ref _prjCreaedOn, ref _AffairsName, ref _newFiscalYear);

                        int exeStatus = 0;
                        string newCommitteeName = newTndrNo.Split('/')[1].ToString();
                        UserList_ForAlert(3, newCommitteeName);
                        // Modified by Varun on 5th Nov 2015
                        string strMsgToTransfer = " **Note: This tender was transferred to " + newCommitteeName + " under Tender No. " + newTndrNo;
                        sqlConn = new SqlConnection(strCon);
                        sqlConn.Open();
                        if (dsStg2.Tables[0].Rows.Count != 0 && dsStg2.Tables[0].Rows[0][9].ToString() != "")
                        {
                            if (dsStg2.Tables[0].Rows[0][16].ToString()=="")
                                sqlQuery = "Update TenderDatesInfo Set Remarks = 'This tender was transferred by " + _userName + " Dated " + DateTime.Now.ToString() + strMsgToTransfer + "',update_date='" + DateTime.Now.ToString() + "',update_user='" + _userName + "' Where Proj_id = " + Convert.ToInt32(dsStg2.Tables[0].Rows[0][1]) + " and stage_id =2 and ts_closing_s1 is not null";
                            else
                                sqlQuery = "Update TenderDatesInfo Set Remarks = 'This tender was transferred by " + _userName + " Dated " + DateTime.Now.ToString() + " " + dsStg2.Tables[0].Rows[0][16] + strMsgToTransfer + "',update_date='" + DateTime.Now.ToString() + "',update_user='" + _userName + "' Where Proj_id = " + Convert.ToInt32(dsStg2.Tables[0].Rows[0][1]) + " and stage_id =2 and ts_closing_s1 is not null";
                            sqlCom = new SqlCommand(sqlQuery, sqlConn);
                            sqlCom.ExecuteNonQuery();
                            sqlCom.Dispose();
                        }
                        else
                        {
                            // Added by Varun on 5th Nov 2015
                            dateID = MaxDateID();
                            using (sqlConn = new SqlConnection(strCon))
                            {
                                sqlConn.Open();
                                sqlCom = new SqlCommand();
                                sqlCom.Connection = sqlConn;
                                sqlCom.CommandText = @"insert into TenderDatesInfo(proj_id,date_id,stage_id,remarks,update_date,update_user) values(" + _prjIDExist + "," + dateID + ",2,'This tender was transferred by " + _userName + " Dated " + DateTime.Now.ToString() +strMsgToTransfer+"','" + DateTime.Now.ToString() +"','" +
                                _userName + "')";
                                sqlCom.ExecuteNonQuery();
                                sqlCom.Parameters.Clear();                               
                            }
                        }

                        if (dsStg3.Tables[0].Rows.Count != 0)
                        {
                            if (dsStg3.Tables[0].Rows[0][7].ToString() == "")
                                sqlQuery = "Update TenderDatesInfo Set Remarks = 'This tender was transferred by " + _userName + " Dated " + DateTime.Now.ToString() + strMsgToTransfer + "',update_date='" + DateTime.Now.ToString() + "',update_user='" + _userName + "' Where Proj_id = " + Convert.ToInt32(dsStg3.Tables[0].Rows[0][1]) + " and stage_id=3";
                            else
                                sqlQuery = "Update TenderDatesInfo Set Remarks = 'This tender was transferred by " + _userName + " Dated " + DateTime.Now.ToString() + " " + dsStg3.Tables[0].Rows[0][7] + strMsgToTransfer + "',update_date='" + DateTime.Now.ToString() + "',update_user='" + _userName + "' Where Proj_id = " + Convert.ToInt32(dsStg3.Tables[0].Rows[0][1]) + " and stage_id=3";
                            sqlCom = new SqlCommand(sqlQuery, sqlConn);
                            sqlCom.ExecuteNonQuery();
                            sqlCom.Dispose();
                        }
                        else
                        {
                            // Added by Varun on 5th Nov 2015
                            dateID = MaxDateID();
                            using (sqlConn = new SqlConnection(strCon))
                            {
                                sqlConn.Open();
                                sqlCom = new SqlCommand();
                                sqlCom.Connection = sqlConn;
                                sqlCom.CommandText = @"insert into TenderDatesInfo(proj_id,date_id,stage_id,remarks,update_date,update_user) values(" + _prjIDExist + "," + dateID + ",3,'This tender was transferred by " + _userName + " Dated " + DateTime.Now.ToString() +strMsgToTransfer+"','" + DateTime.Now.ToString() + "','" +
                                _userName + "')";
                                sqlCom.ExecuteNonQuery();
                                sqlCom.Parameters.Clear();
                            }
                        }

                        dtTenderDatesInfoData = null;
                        sqlQuery = "select date_id, co_id from TenderDatesInfo where proj_id=" + _newPrjID + " and co_id is not null";
                        dtTenderDatesInfoData = dalObj.GetDataFromDB("TenderDatesInfoData", sqlQuery);
                        loopCtr = 0;

                        sqlConn = new SqlConnection(strCon);
                        sqlConn.Open();

                        while (loopCtr < dtTenderDatesInfoData.Rows.Count)
                        {
                            sqlQuery = "Update DOCUMENTS Set proj_id = " + _newPrjID + ",date_id=" + Convert.ToInt32(dtTenderDatesInfoData.Rows[loopCtr][0]) + " Where Proj_id = " + _prjIDExist + " and date_id is not null and co_id =" + Convert.ToInt16(dtTenderDatesInfoData.Rows[loopCtr][1]);
                            sqlCom = new SqlCommand(sqlQuery, sqlConn);
                            exeStatus = sqlCom.ExecuteNonQuery();
                            loopCtr++;
                        }


                        string sqlUpdate = "Update DOCUMENTS Set proj_id = " + _newPrjID + " Where Proj_id = " + _prjIDExist + " and date_id is null and co_id is not null";
                        if (sqlCom != null)
                            sqlCom.Dispose();
                        sqlCom = new SqlCommand(sqlUpdate, sqlConn);
                        exeStatus = sqlCom.ExecuteNonQuery();
                        MessageBox.Show("Selected Project Transferred to other committee.");
                        sqlConn.Close();                       

                        //string DisplayName = ""; string Email = ""; string Department = ""; string Title = "";                         
                        // AlertOnNewTenderNo(tenderNo, _projID.ToString(), "New Project");

                        string fromUser = null;                                               
                        fromUser = comCls.getUserEmailID(_userName);

                        try
                        {
                            
                            foreach (string strname in userListColl)
                            {
                            // if (GetUserInformation4rmActiveDirectory(strname, "ashghal.gov.qa", ref DisplayName, ref Email, ref  Department, ref Title) == true)
                                     
                                MailMessage mailMessage = new MailMessage();
                                //mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["MailFrom"].ToString());

                                mailMessage.From = new MailAddress(fromUser);
                                // mailMessage.To.Add(new MailAddress(ConfigurationManager.AppSettings["MailTo"].ToString()));
                                mailMessage.To.Add(new MailAddress(strname));
                                
                                mailMessage.Subject = "TCMS Alert: Project Transferred From. " + _committee + " To: " + newCommitteeName + " with Tender No.:" + newTndrNo;
                                mailMessage.IsBodyHtml = true;

                                mailMessage.Body = "<i style='font-family:Calibri; font-size:15'>Dear Sir/Madam,</i><br/><br/><i style='font-family:Calibri; font-size:15'></i><i style='font-family:Calibri; font-size:15'>This is an automated alert from Tender & Contract Management System.</i><br/><br/>" +
                                "<i style='font-family:Calibri; font-size:15'>Please be noted that the tender </i><i style='color:Blue;font-family:Calibri; font-size:15'>" + _tenderNo + "</i><i style='font-family:Calibri; font-size:15'>" +
                                " has been transferred to Tender Committee <i style='font-family:Calibri;font-size:15;color:Maroon'>" + newCommitteeName + "</i>, with Tender No. <i style='color:Maroon;font-family:Calibri; font-size:15'>" + newTndrNo + ".</i></i><br /><i>And the details are as follows:-</i>" +
                                "<br /><br /><table style='width:80%' border='1'><tr><td align='center' colspan='2' style='background-color:#76923C;color:White;font-family:Calibri; font-size:18;font-weight:bold'>TENDER NO: " + newTndrNo + "</td>" +
                                "</tr><tr><td style='background-color:#B58AA5;font-family:Calibri; font-size:15;font-weight:bold'><i>Project Code</i></td><td style='font-family:Calibri;font-size:15'>" + _prjCodeExisted + "</td></tr><tr>" +
                                "<td style='background-color:#B58AA5;font-family:Calibri; font-size:15;font-weight:bold'><i>Project Title</i></td><td style='font-family:Calibri;font-size:15'>" + _projTitle + "</td></tr><tr>" +
                                "<td style='background-color:#B58AA5;font-family:Calibri; font-size:15;font-weight:bold'><i>Type of Tender</i></td><td style='font-family:Calibri;font-size:15'>" + _tndrTypeName + "</td></tr><tr>" +
                                "<td style='background-color:#B58AA5;font-family:Calibri; font-size:15;font-weight:bold'><i>Previous Tender Committee</i></td><td style='font-family:Calibri;font-size:15'>" + _committee + "</td></tr><tr>" +
                                "<td style='background-color:#B58AA5;font-family:Calibri; font-size:15;font-weight:bold'><i>New Tender Committee</i></td><td style='font-family:Calibri;font-size:15'>" + newCommitteeName + "</td></tr><tr>" +
                                "<td style='background-color:#B58AA5;font-family:Calibri; font-size:15;font-weight:bold'><i>Financial Year</i></td><td style='font-family:Calibri;font-size:15'>" + _newFiscalYear + "</td></tr><tr>" +               //newTndrNo.Split('/')[3].ToString()
                                "<td style='background-color:#B58AA5;font-family:Calibri; font-size:15;font-weight:bold'><i>User Dept.</i></td><td style='font-family:Calibri;font-size:15'>" + _userDept + " / " + _AffairsName + "</td></tr><tr>" +
                                "<td style='background-color:#B58AA5;font-family:Calibri; font-size:15;font-weight:bold'>Date of Creation</td><td style='font-family:Calibri;font-size:15'>" + System.DateTime.Now + "</td></tr></table>" +
                                "<br /><br /><div style='font-family:Calibri;font-size:15'>Best Regards,<br />TCMS Team</div>";


                                SmtpClient client = new SmtpClient();
                                client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                                client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                                client.Send(mailMessage);
                            }                                
                            
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Exception occurred while sending the email notification to Tender Committee, Please inform them Personally", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }

                        ProjTransfered = 'Y';
                        this.Close();

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error occurred while creating the duplicate records for the project to be transferred.", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
            }
        }
        IList<string> userListColl = new List<string>();
        private void UserList_ForAlert(int categryID, string committeeName)
        {            
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        string sqlQuery = "SELECT DISTINCT EmailAlertRecipients.user_id, USERS.email_address, USERS.user_name, EmailAlertCategory.AlertCategory, EmailAlertRecipients.alert_cat_id, " +
                         " Committee.committee_short_name FROM EmailAlertCategory INNER JOIN EmailAlertRecipients ON EmailAlertCategory.alert_cat_id = EmailAlertRecipients.alert_cat_id INNER JOIN " +
                         " USERS ON EmailAlertRecipients.user_id = USERS.user_id INNER JOIN Committee ON EmailAlertRecipients.committee_id = Committee.committee_id " +
                         " WHERE (EmailAlertRecipients.alert_cat_id = " + categryID + ") AND (USERS.email_address <> N'') AND (Committee.committee_short_name ='" + committeeName + "')";
                         

                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                string strData = dr[1].ToString();
                                if (!userListColl.Contains(strData))
                                    userListColl.Add(strData);
                            }
                            dr.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE DATES records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        public Boolean GetUserInformation4rmActiveDirectory(string userId, string Domain, ref string DisplayName, ref string Email)
        {
            Boolean chkUserExist = false;
            try
            {
                string filter = string.Format("(&(ObjectClass={0})(sAMAccountName={1}))", "person", userId);

                DirectoryEntry activeDirectoryaddress = new DirectoryEntry("LDAP://" + Domain, null, null, AuthenticationTypes.Secure);
                DirectorySearcher searcher = new DirectorySearcher(activeDirectoryaddress);
                searcher.SearchScope = SearchScope.Subtree;

                searcher.Filter = filter;
                SearchResult result = searcher.FindOne();
                DirectoryEntry directoryEntry = result.GetDirectoryEntry();

                DisplayName = directoryEntry.Properties["displayName"][0].ToString();
                Email = directoryEntry.Properties["mail"][0].ToString();                 

                if (Email != null)
                {
                    chkUserExist = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Sorry unable to get your mail id from outlook", "ASHGHAL - EBSD");
            }

            return chkUserExist;
        }


        private void insertStatementParameters(SqlCommand cmd, DataTable dtTenderDatesInfoData, int loopCtr, int _dateId, char stageId)
        {
            if (stageId=='1')
                cmd.Parameters.AddWithValue("@stageId", 1);
            else if (stageId == '2')
                cmd.Parameters.AddWithValue("@stageId", 2);
            else if (stageId == '3')
                cmd.Parameters.AddWithValue("@stageId", 3);

            cmd.Parameters.AddWithValue("@projId", _newPrjID);
            cmd.Parameters.AddWithValue("@dateId", _dateId);

            if (dtTenderDatesInfoData.Rows[loopCtr][1] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ptd_receive_on", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][1]));
            else
                cmd.Parameters.AddWithValue("@ptd_receive_on", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][2] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ptd_purpose", dtTenderDatesInfoData.Rows[loopCtr][2].ToString());
            else
                cmd.Parameters.AddWithValue("@ptd_purpose", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][3] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ptd_assign_qs", dtTenderDatesInfoData.Rows[loopCtr][3].ToString());
            else
                cmd.Parameters.AddWithValue("@ptd_assign_qs", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][4] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ptd_sent_for_rev", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][4].ToString()));
            else
                cmd.Parameters.AddWithValue("@ptd_sent_for_rev", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][5] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ptd_qs_working_status", dtTenderDatesInfoData.Rows[loopCtr][5].ToString());
            else
                cmd.Parameters.AddWithValue("@ptd_qs_working_status", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][6] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ptd_tendec_doc_cur_status", dtTenderDatesInfoData.Rows[loopCtr][6].ToString());
            else
                cmd.Parameters.AddWithValue("@ptd_tendec_doc_cur_status", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][7] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ptd_forwarded_to_dep", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][7]));
            else
                cmd.Parameters.AddWithValue("@ptd_forwarded_to_dep", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][8] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ts_receive_on", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][8]));
            else
                cmd.Parameters.AddWithValue("@ts_receive_on", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][9] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ts_issue_handling", dtTenderDatesInfoData.Rows[loopCtr][9].ToString());
            else
                cmd.Parameters.AddWithValue("@ts_issue_handling", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][10] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ts_return_to_dept", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][10]));
            else
                cmd.Parameters.AddWithValue("@ts_return_to_dept", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][11] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ts_receive_from_dept", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][11]));
            else
                cmd.Parameters.AddWithValue("@ts_receive_from_dept", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][12] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ts_pr_advertise", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][12]));
            else
                cmd.Parameters.AddWithValue("@ts_pr_advertise", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][13] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ts_tender_invitation", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][13]));
            else
                cmd.Parameters.AddWithValue("@ts_tender_invitation", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][14] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ts_closing_s1", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][14]));
            else
                cmd.Parameters.AddWithValue("@ts_closing_s1", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][15] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ts_closing_s2", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][15]));
            else
                cmd.Parameters.AddWithValue("@ts_closing_s2", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][16] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ts_modified_closing", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][16]));
            else
                cmd.Parameters.AddWithValue("@ts_modified_closing", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][17] != DBNull.Value)
                cmd.Parameters.AddWithValue("@ts_tender_issue", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][17]));
            else
                cmd.Parameters.AddWithValue("@ts_tender_issue", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][18] != DBNull.Value)
            {
                if (dtTenderDatesInfoData.Rows[loopCtr][18].ToString() != "")
                    cmd.Parameters.AddWithValue("@ts_receipt_no", dtTenderDatesInfoData.Rows[loopCtr][18].ToString());
            }
            else
                cmd.Parameters.AddWithValue("@ts_receipt_no", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][19] != DBNull.Value)
                cmd.Parameters.AddWithValue("@eval_tender_opening", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][19]));
            else
                cmd.Parameters.AddWithValue("@eval_tender_opening", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][20] != DBNull.Value)
                cmd.Parameters.AddWithValue("@eval_doc_receive_from_cd", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][20]));
            else
                cmd.Parameters.AddWithValue("@eval_doc_receive_from_cd", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][21] != DBNull.Value)
                cmd.Parameters.AddWithValue("@eval_tech_sent", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][21]));
            else
                cmd.Parameters.AddWithValue("@eval_tech_sent", DBNull.Value);

            if (dtTenderDatesInfoData.Rows[loopCtr][22] != DBNull.Value)
                cmd.Parameters.AddWithValue("@eval_tech_receive", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][22]));
            else
                cmd.Parameters.AddWithValue("@eval_tech_receive", DBNull.Value);
        
                if (dtTenderDatesInfoData.Rows[loopCtr][23] != DBNull.Value)
                    cmd.Parameters.AddWithValue("@org_tender_validity", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][23]));
                else
                    cmd.Parameters.AddWithValue("@org_tender_validity", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][24] != DBNull.Value)
                    cmd.Parameters.AddWithValue("@org_tenderbond_validity", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][24]));
                else
                    cmd.Parameters.AddWithValue("@org_tenderbond_validity", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][25] != DBNull.Value)
                {
                    if (dtTenderDatesInfoData.Rows[loopCtr][25].ToString() != "")
                        cmd.Parameters.AddWithValue("@org_tender_to_expire", Convert.ToInt16(dtTenderDatesInfoData.Rows[loopCtr][25]));
                    else
                        cmd.Parameters.AddWithValue("@org_tender_to_expire", DBNull.Value);
                }
                else
                    cmd.Parameters.AddWithValue("@org_tender_to_expire", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][26] != DBNull.Value)
                {
                    if (dtTenderDatesInfoData.Rows[loopCtr][26].ToString() != "")
                        cmd.Parameters.AddWithValue("@org_tenderbond_to_expire", Convert.ToInt16(dtTenderDatesInfoData.Rows[loopCtr][26]));
                    else
                        cmd.Parameters.AddWithValue("@org_tenderbond_to_expire", DBNull.Value);
                }
                else
                    cmd.Parameters.AddWithValue("@org_tenderbond_to_expire", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][27] != DBNull.Value)
                    cmd.Parameters.AddWithValue("@tender_validity_ext1", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][27]));
                else
                    cmd.Parameters.AddWithValue("@tender_validity_ext1", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][28] != DBNull.Value)
                    cmd.Parameters.AddWithValue("@tender_validity_ext2", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][28]));
                else
                    cmd.Parameters.AddWithValue("@tender_validity_ext2", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][29] != DBNull.Value)
                    cmd.Parameters.AddWithValue("@tenderbond_validity_ext1", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][29]));
                else
                    cmd.Parameters.AddWithValue("@tenderbond_validity_ext1", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][30] != DBNull.Value)
                    cmd.Parameters.AddWithValue("@tenderbond_validity_ext2", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][30]));
                else
                    cmd.Parameters.AddWithValue("@tenderbond_validity_ext2", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][31] != DBNull.Value)
                {
                    if (dtTenderDatesInfoData.Rows[loopCtr][31].ToString() != "")
                        cmd.Parameters.AddWithValue("@eval_no_of_meetings", Convert.ToInt16(dtTenderDatesInfoData.Rows[loopCtr][31]));
                    else
                        cmd.Parameters.AddWithValue("@eval_no_of_meetings", DBNull.Value);
                }
                else
                    cmd.Parameters.AddWithValue("@eval_no_of_meetings", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][32] != DBNull.Value)
                {
                    if (dtTenderDatesInfoData.Rows[loopCtr][32].ToString() != "")
                        cmd.Parameters.AddWithValue("@remarks", dtTenderDatesInfoData.Rows[loopCtr][32].ToString());
                    else
                        cmd.Parameters.AddWithValue("@remarks", DBNull.Value);
                }
                else
                    cmd.Parameters.AddWithValue("@remarks", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][33] != DBNull.Value)
                {
                    if (dtTenderDatesInfoData.Rows[loopCtr][33].ToString() != "")
                        cmd.Parameters.AddWithValue("@staff_In_Charge", dtTenderDatesInfoData.Rows[loopCtr][33].ToString());
                    else
                        cmd.Parameters.AddWithValue("@staff_In_Charge", DBNull.Value);
                }
                else
                    cmd.Parameters.AddWithValue("@staff_In_Charge", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][34] != DBNull.Value)
                    cmd.Parameters.AddWithValue("@fromDate", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][34]));
                else
                    cmd.Parameters.AddWithValue("@fromDate", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][35] != DBNull.Value)
                    if (dtTenderDatesInfoData.Rows[loopCtr][35].ToString() != "")
                        cmd.Parameters.AddWithValue("@toDate", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][35]));
                    else
                        cmd.Parameters.AddWithValue("@toDate", DBNull.Value);
                else
                    cmd.Parameters.AddWithValue("@toDate", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][36] != DBNull.Value)
                {
                    if (dtTenderDatesInfoData.Rows[loopCtr][36].ToString() != "")
                        cmd.Parameters.AddWithValue("@employee_id", Convert.ToInt32(dtTenderDatesInfoData.Rows[loopCtr][36]));
                    else
                        cmd.Parameters.AddWithValue("@employee_id", DBNull.Value);
                }
                else
                    cmd.Parameters.AddWithValue("@employee_id", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][37] != DBNull.Value)
                {
                    if (dtTenderDatesInfoData.Rows[loopCtr][37].ToString() != "")
                        cmd.Parameters.AddWithValue("@co_id", Convert.ToInt32(dtTenderDatesInfoData.Rows[loopCtr][37]));
                    else
                        cmd.Parameters.AddWithValue("@co_id", DBNull.Value);
                }
                else
                    cmd.Parameters.AddWithValue("@co_id", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][38] != DBNull.Value)
                    cmd.Parameters.AddWithValue("@create_date", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][38]));
                else
                    cmd.Parameters.AddWithValue("@create_date", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][39] != DBNull.Value)
                    cmd.Parameters.AddWithValue("@update_date", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][39]));
                else
                    cmd.Parameters.AddWithValue("@update_date", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][40] != DBNull.Value)
                {
                    if (dtTenderDatesInfoData.Rows[loopCtr][40].ToString() != "")
                        cmd.Parameters.AddWithValue("@create_user", dtTenderDatesInfoData.Rows[loopCtr][40].ToString());
                    else
                        cmd.Parameters.AddWithValue("@create_user", DBNull.Value);
                }
                else
                    cmd.Parameters.AddWithValue("@create_user", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][41] != DBNull.Value)
                {
                    if (dtTenderDatesInfoData.Rows[loopCtr][41].ToString() != "")
                        cmd.Parameters.AddWithValue("@update_user", dtTenderDatesInfoData.Rows[loopCtr][41].ToString());
                    else
                        cmd.Parameters.AddWithValue("@update_user", DBNull.Value);
                }
                else
                    cmd.Parameters.AddWithValue("@update_user", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][42] != DBNull.Value)
                {
                    if (dtTenderDatesInfoData.Rows[loopCtr][42].ToString() != "")
                        cmd.Parameters.AddWithValue("@alert", Convert.ToInt16(dtTenderDatesInfoData.Rows[loopCtr][42]));
                    else
                        cmd.Parameters.AddWithValue("@alert", DBNull.Value);
                }
                else
                    cmd.Parameters.AddWithValue("@alert", DBNull.Value);           

            if (stageId == '1' || stageId == '2')
            {
                if (dtTenderDatesInfoData.Rows[loopCtr][43] != DBNull.Value)
                    cmd.Parameters.AddWithValue("@eval_com_sent", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][43]));
                else
                    cmd.Parameters.AddWithValue("@eval_com_sent", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][44] != DBNull.Value)
                    cmd.Parameters.AddWithValue("@eval_com_receive", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][44]));
                else
                    cmd.Parameters.AddWithValue("@eval_com_receive", DBNull.Value);

                if (dtTenderDatesInfoData.Rows[loopCtr][45] != DBNull.Value)
                    cmd.Parameters.AddWithValue("@eval_award_approval", Convert.ToDateTime(dtTenderDatesInfoData.Rows[loopCtr][45]));
                else
                    cmd.Parameters.AddWithValue("@eval_award_approval", DBNull.Value);
                
            }
            

        }
        private void UpdateMoazanahProjectID()
        {
            string sqlUpdate = "Update Projects Set moazanah_proj_id = @mozID Where Proj_id = @prjID";
            using (SqlConnection sqlConn = new SqlConnection(strCon))
            {
                sqlConn.Open();
                using (SqlCommand sqlCom = new SqlCommand(sqlUpdate, sqlConn))
                {
                    sqlCom.Parameters.AddWithValue("@prjID", _prjIDExist);
                    sqlCom.Parameters.AddWithValue("@mozID", DBNull.Value);                    
                    sqlCom.ExecuteNonQuery();
                }
                sqlConn.Close();
            }
        }
        private void transforProjectsInfo(string prjPrifix, string statusType, string reTenderNo)
        {
            DataSet dsProjects = new DataSet();
            string sqlQuery = "Select proj_id,project_code,project_newname_en,committee_id, " +
                        " FYID, Affair_id, department_id, contract_type_id, tender_type_id, project_newname_en,project_name_ar,stage_id, " +
                        " SelectPrj,Tender_Status_id,[Ministry_Code],[Budget_Reference_No],[Provision_Number],moazanah_proj_id,tender_no From Projects Where proj_id = " + _prjIDExist +"";
            using (SqlConnection sqlConn = new SqlConnection(strCon))
            {
                sqlConn.Open();
                using (SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn))
                {                    
                    SqlDataAdapter daPrj = new SqlDataAdapter(sqlCom);
                    daPrj.Fill(dsProjects);
                }
                sqlConn.Close();
            }
            InsertProjectsInfo(dsProjects, prjPrifix, statusType, reTenderNo);            
        }
        private int GetStatus_ID()
        {
            int cmtID =0;
            string sqlUpdate = "SELECT committee_id FROM Committee WHERE (committee_short_name = '" + cmbCommittee.Text + "')";
            using (SqlConnection sqlConn = new SqlConnection(strCon))
            {
                sqlConn.Open();
                using (SqlCommand sqlCom = new SqlCommand(sqlUpdate, sqlConn))
                {
                     cmtID = Convert.ToInt16(sqlCom.ExecuteScalar());
                }
                sqlConn.Close();
            }
            return cmtID;
        }
        string currentProjCode = null;
        private void InsertProjectsInfo(DataSet dsProj, string prjCodePrefix, string _statusType, string reTenderNo)
        {              
            DAL dalObj = new DAL();
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    int _getcmtID = 0;
                    sqlConn.Open();
                    for (int i = 0; i < dsProj.Tables[0].Rows.Count; i++)
                    {
                        // DataRow dRow = ds.Tables[0].Rows[i][0];

                        if (_statusType.Contains("Transfer"))
                        {
                            _getcmtID = GetStatus_ID();
                        }

                        string insertQuery = "INSERT INTO PROJECTS(proj_id,project_code, project_newname_en,committee_id, " +
                             " FYID, Affair_id, department_id, contract_type_id, tender_type_id, project_name_en,project_name_ar,stage_id,SelectPrj,Tender_Status_id,[Ministry_Code],[Budget_Reference_No],[Provision_Number],moazanah_proj_id,tender_no,dummyfield,create_date," +
                             "create_user) " +
                             " VALUES(@prjID,@PrjCode,@PrjTitleEnNew,@CmtId,@FiscalID,@AffairID,@UserDept,@TypeOfPrj,@TypeOfTndr,@PrjTitleEn, @PrjTitleArb,@StageID,@SelPrj,@TndrStatusId,@MinistryCode,@BudgetRefNo,@ProvisionNo,@moazanah_id,@tndrNO,@dummy_field,@createDate," +
                             "@createUser)";

                        using (SqlCommand cmd = new SqlCommand(insertQuery, sqlConn))
                        {
                            cmd.Parameters.AddWithValue("@prjID", _newPrjID);

                            // Modified as per faisal request on Dec 30th 2013 By Sreedhar
                            // Modified by Varun on Jan 29 2013
                            // Modified by Varun on Aug 12 2014
                            if (!(_statusType.Contains("Transfer")))
                            {
                                currentProjCode = dsProj.Tables[0].Rows[i][1].ToString();
                            }
                            else
                            {
                                currentProjCode = dsProj.Tables[0].Rows[i][1].ToString() + prjCodePrefix;
                            }

                            //currentProjCode = dsProj.Tables[0].Rows[i][1].ToString();
                            cmd.Parameters.AddWithValue("@PrjCode", currentProjCode);

                            cmd.Parameters.AddWithValue("@PrjTitleEnNew", dsProj.Tables[0].Rows[i][2].ToString());

                            if (_statusType.Contains("Transfer"))
                            {
                                cmd.Parameters.AddWithValue("@CmtId", _getcmtID);
                                if (dsProj.Tables[0].Rows[i][13].ToString() == "")
                                {
                                    cmd.Parameters.AddWithValue("@StageID", 1);
                                    cmd.Parameters.AddWithValue("@TndrStatusId", 1);
                                }
                                else if (Convert.ToInt32(dsProj.Tables[0].Rows[i][13].ToString()) >= 4)
                                {
                                    cmd.Parameters.AddWithValue("@StageID", 3); //3==Tender Evaluation & Award
                                    cmd.Parameters.AddWithValue("@TndrStatusId", 3); //3==Technical Evaluation
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@StageID", dsProj.Tables[0].Rows[i][11].ToString());
                                    cmd.Parameters.AddWithValue("@TndrStatusId", dsProj.Tables[0].Rows[i][13].ToString());  
                                }
                            }
                            else
                            {
                                cmd.Parameters.AddWithValue("@CmtId", Convert.ToInt16(dsProj.Tables[0].Rows[i][3]));
                                cmd.Parameters.AddWithValue("@StageID", 1);
                                cmd.Parameters.AddWithValue("@TndrStatusId", 1);
                            }                            
                            
                           
                            cmd.Parameters.AddWithValue("@FiscalID", Convert.ToInt16(dsProj.Tables[0].Rows[i][4]));

                            cmd.Parameters.AddWithValue("@AffairID", Convert.ToInt16(dsProj.Tables[0].Rows[i][5]));
                            cmd.Parameters.AddWithValue("@UserDept", Convert.ToInt16(dsProj.Tables[0].Rows[i][6]));
                            cmd.Parameters.AddWithValue("@TypeOfPrj", Convert.ToInt16(dsProj.Tables[0].Rows[i][7]));
                            cmd.Parameters.AddWithValue("@TypeOfTndr", Convert.ToInt16(dsProj.Tables[0].Rows[i][8]));
                            cmd.Parameters.AddWithValue("@PrjTitleEn", dsProj.Tables[0].Rows[i][9]);
                            cmd.Parameters.AddWithValue("@PrjTitleArb", dsProj.Tables[0].Rows[i][10]);
                         
                            cmd.Parameters.AddWithValue("@SelPrj", 1);                            
                            cmd.Parameters.AddWithValue("@MinistryCode", dsProj.Tables[0].Rows[i][14]);
                            cmd.Parameters.AddWithValue("@BudgetRefNo", dsProj.Tables[0].Rows[i][15]);
                            if (dsProj.Tables[0].Rows[i][16].ToString() != "")
                                cmd.Parameters.AddWithValue("@ProvisionNo", dsProj.Tables[0].Rows[i][16]);
                            else
                                cmd.Parameters.AddWithValue("@ProvisionNo", DBNull.Value);

                            cmd.Parameters.AddWithValue("@moazanah_id", dsProj.Tables[0].Rows[i][17]);

                            if (!_statusType.Contains("Transfer"))
                            {
                                string newTndrCode = null;
                                if (reTenderNo != null)
                                {
                                    if (reTenderNo.Contains("R"))
                                    {
                                        //newTndrCode = dsProj.Tables[0].Rows[0][18].ToString().Trim().Replace("-R", "");
                                        //newTndrCode = newTndrCode + prjCodePrefix;
                                        cmd.Parameters.AddWithValue("@tndrNO", reTenderNo);
                                    }
                                    else
                                    {
                                        newTndrCode = dsProj.Tables[0].Rows[i][18].ToString() + prjCodePrefix;
                                        cmd.Parameters.AddWithValue("@tndrNO", newTndrCode);
                                    }
                                }
                                else
                                    cmd.Parameters.AddWithValue("@tndrNO", DBNull.Value);                                
                            }
                            else
                                cmd.Parameters.AddWithValue("@tndrNO", DBNull.Value);

                            cmd.Parameters.AddWithValue("@dummy_field", System.DateTime.Now);
                            cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                            cmd.Parameters.AddWithValue("@createUser", _userName);


                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                    }
                    sqlConn.Close();
                }
            }
            catch (Exception ex)
            { 
                MessageBox.Show("Error occurred while inserting projects info" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void transforTenderDates_Stage1()
        {
            string sqlQuery = "SELECT date_id, proj_id, stage_id, ptd_receive_on, ptd_purpose, ptd_assign_qs, ptd_sent_for_rev, ptd_qs_working_status, ptd_tendec_doc_cur_status, " +
            " ptd_forwarded_to_dep,remarks,create_date,update_date,create_user,update_user,Alert FROM TenderDatesInfo WHERE (proj_id = " + _prjIDExist + ") AND (stage_id = 1)";

            SqlConnection sqlConn = new SqlConnection(strCon);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            DataSet dsStg1 = new DataSet();
            SqlDataAdapter daStage1 = new SqlDataAdapter(sqlCom);
            daStage1.Fill(dsStg1);
            sqlConn.Close();
            if (dsStg1.Tables[0].Rows.Count > 0)
            {                
                InsertDocumentPreparationInfo(dsStg1);
            }
             
        }
        
        private void transforTenderDates_Stage2()
        {
            string sqlQuery = "SELECT date_id, proj_id, stage_id, ts_receive_on, ts_issue_handling, ts_return_to_dept, ts_receive_from_dept, ts_pr_advertise, ts_tender_invitation, ts_closing_s1," +
            "ts_closing_s2, ts_modified_closing, ts_tender_issue, ts_receipt_no,co_id,employee_id,remarks,org_tender_validity,org_tenderbond_validity,org_tender_to_expire,org_tenderbond_to_expire," +
            "tender_validity_ext1,tender_validity_ext2,tenderbond_validity_ext1,tenderbond_validity_ext2,Tender_Issued,SN,create_date,update_date,create_user,update_user,Alert,Company_EmailID FROM TenderDatesInfo WHERE (proj_id = " + _prjIDExist + ") AND (stage_id = 2) ORDER BY date_id asc";

            SqlConnection sqlConn = new SqlConnection(strCon);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);            
            SqlDataAdapter daStage2 = new SqlDataAdapter(sqlCom);
            daStage2.Fill(dsStg2);
            sqlConn.Close();
            if (dsStg2.Tables[0].Rows.Count > 0)
            {                 
                InsertTenderStageInfo(dsStg2);
            }
        }
        private void transforTenderDates_Stage3()
        {
            string sqlQuery = "SELECT date_id, proj_id, stage_id, eval_tender_opening, eval_tender_doc_receive_from_cd, eval_tech_sent, eval_tech_receive,remarks," +
            "create_date,update_date,create_user,update_user,Alert FROM TenderDatesInfo WHERE (proj_id = " + _prjIDExist + ") AND (stage_id = 3)";

            SqlConnection sqlConn = new SqlConnection(strCon);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);             
            SqlDataAdapter daStage3 = new SqlDataAdapter(sqlCom);
            daStage3.Fill(dsStg3);
            sqlConn.Close();
            if (dsStg3.Tables[0].Rows.Count > 0)
            {                 
                InsertTenderEvaluationData(dsStg3);
            }
        }
        
        private void transfor_ProjectCost()
        {
            string sqlQuery = "update ProjectCost set proj_id =" + _newPrjID + " WHERE (proj_id =" + _prjIDExist + ") AND (stage_id = 4) ";                     
            SqlConnection sqlConn = new SqlConnection(strCon);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            sqlCom.ExecuteNonQuery();          
        }

        private void UpdateProjectStatus(int statusID)
        {
            SqlConnection sqlConn = new SqlConnection(strCon);
            sqlConn.Open();
            string insertQuery = "UPDATE PROJECTS SET Tender_Status_id = @tndtStatus,moazanah_proj_id = @MoazID WHERE proj_id = @prjID";
            using (SqlCommand cmd = new SqlCommand(insertQuery, sqlConn))
            {
                cmd.Parameters.AddWithValue("@prjID", _prjIDExist);
                cmd.Parameters.AddWithValue("@tndtStatus", statusID);
                cmd.Parameters.AddWithValue("@MoazID", DBNull.Value); 
                int exUpdated = cmd.ExecuteNonQuery();
                cmd.Parameters.Clear();
            }            
        }
        private int MaxDateID()
        {
            int dateId = 0;
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"SELECT MAX(DATE_ID) FROM TenderDatesInfo";
                        dateId = Convert.ToInt16(cmd.ExecuteScalar());
                        dateId = dateId + 1;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            return dateId;
        }
        private void InsertTenderStageInfo(DataSet stg2Ds)
        {

            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;                         
                        int totRowsCount = stg2Ds.Tables[0].Rows.Count;
                        for (int i = 0; i < totRowsCount; i++)
                        {
                            dateID = MaxDateID();
                            if (stg2Ds.Tables[0].Rows[0][9].ToString() != "")   // Tender Closing date 
                            {                               
                               
                                if (i == 0)
                                    cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,ts_receive_on,ts_issue_handling,ts_return_to_dept, " +
                                    " ts_receive_from_dept,ts_pr_advertise,ts_tender_invitation,ts_closing_s1,ts_closing_s2,ts_modified_closing,ts_tender_issue,ts_receipt_no,co_id,employee_id,remarks,org_tender_validity," +
                                    "org_tenderbond_validity,org_tender_to_expire,org_tenderbond_to_expire,tender_validity_ext1,tender_validity_ext2,tenderbond_validity_ext1,tenderbond_validity_ext2,Tender_Issued,SN,create_date,update_date,create_user,update_user,Alert,Company_EmailID) VALUES " +
                                    "(@dateId,@projId,@stageId,@receiveOn,@issueHandling,@returnDept,@receivedFromDept,@advertisement,@invitation,@closingDate,@closingDate2,@tsModifyDate,@issueTndrDate,@receiptNo,@coID,@empID,@Remarks," +
                                    "@orgTenderValidity,@orgTenderbondValidity,@orgTenderToExpire,@orgTenderbondExpire,@tenderValidityExt1,@tenderValidityExt2,@tenderbondValidityExt1,@tenderbondValidityExt2,@tenderIssued,@sn,@createDate,@updateDate,@createUser,@updateUser,@alert,@companyEmailID)";
                                else if (i >= 1)
                                    cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,ts_receive_on,ts_issue_handling,ts_return_to_dept, " +
                                    " ts_receive_from_dept,ts_pr_advertise,ts_tender_invitation,ts_closing_s2,ts_modified_closing,ts_tender_issue,ts_receipt_no,co_id,employee_id,remarks,org_tender_validity,org_tenderbond_validity," +
                                    "org_tender_to_expire,org_tenderbond_to_expire,tender_validity_ext1,tender_validity_ext2,tenderbond_validity_ext1,tenderbond_validity_ext2,Tender_Issued,SN,create_date,update_date,create_user,update_user,Alert,Company_EmailID) VALUES " +
                                    "(@dateId,@projId,@stageId,@receiveOn,@issueHandling,@returnDept,@receivedFromDept,@advertisement,@invitation,@closingDate2,@tsModifyDate,@issueTndrDate,@receiptNo,@coID,@empID,@Remarks," +
                                    "@orgTenderValidity,@orgTenderbondValidity,@orgTenderToExpire,@orgTenderbondExpire,@tenderValidityExt1,@tenderValidityExt2,@tenderbondValidityExt1,@tenderbondValidityExt2,@tenderIssued,@sn,@createDate,@updateDate,@createUser,@updateUser,@alert,@companyEmailID)";

                                cmd.Parameters.AddWithValue("@stageId", 2);

                                cmd.Parameters.AddWithValue("@projId", _newPrjID);

                                cmd.Parameters.AddWithValue("@receiveOn", stg2Ds.Tables[0].Rows[i][3]);

                                if (stg2Ds.Tables[0].Rows[i][4].ToString() != "")
                                    cmd.Parameters.AddWithValue("@issueHandling", stg2Ds.Tables[0].Rows[i][4]);
                                else
                                    cmd.Parameters.AddWithValue("@issueHandling", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][5].ToString() != "")
                                    cmd.Parameters.AddWithValue("@returnDept", stg2Ds.Tables[0].Rows[i][5]);
                                else
                                    cmd.Parameters.AddWithValue("@returnDept", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][6].ToString() != "")
                                    cmd.Parameters.AddWithValue("@receivedFromDept", stg2Ds.Tables[0].Rows[i][6]);
                                else
                                    cmd.Parameters.AddWithValue("@receivedFromDept", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][7].ToString() != "")
                                    cmd.Parameters.AddWithValue("@advertisement", stg2Ds.Tables[0].Rows[i][7]);
                                else
                                    cmd.Parameters.AddWithValue("@advertisement", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][8].ToString() != "")
                                    cmd.Parameters.AddWithValue("@invitation", stg2Ds.Tables[0].Rows[i][8]);
                                else
                                    cmd.Parameters.AddWithValue("@invitation", DBNull.Value);

                                if (i == 0)
                                {
                                    if (stg2Ds.Tables[0].Rows[i][9].ToString() != "")
                                        cmd.Parameters.AddWithValue("@closingDate", stg2Ds.Tables[0].Rows[i][9]);
                                }                                 
                                
                                if (stg2Ds.Tables[0].Rows[i][10].ToString() != "")
                                    cmd.Parameters.AddWithValue("@closingDate2", stg2Ds.Tables[0].Rows[i][10]);
                                else
                                    cmd.Parameters.AddWithValue("@closingDate2", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][11].ToString() != "")
                                    cmd.Parameters.AddWithValue("@tsModifyDate", stg2Ds.Tables[0].Rows[i][11]);
                                else
                                    cmd.Parameters.AddWithValue("@tsModifyDate", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][12].ToString() != "")
                                    cmd.Parameters.AddWithValue("@issueTndrDate", stg2Ds.Tables[0].Rows[i][12]);
                                else
                                    cmd.Parameters.AddWithValue("@issueTndrDate", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][13].ToString() != "")
                                    cmd.Parameters.AddWithValue("@receiptNo", stg2Ds.Tables[0].Rows[i][13]);
                                else
                                    cmd.Parameters.AddWithValue("@receiptNo", DBNull.Value);
                                
                                if (stg2Ds.Tables[0].Rows[i][14].ToString() != "")
                                    cmd.Parameters.AddWithValue("@coID", stg2Ds.Tables[0].Rows[i][14]);
                                else
                                    cmd.Parameters.AddWithValue("@coID", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][15].ToString() != "")
                                    cmd.Parameters.AddWithValue("@empID", stg2Ds.Tables[0].Rows[i][15]);
                                else
                                    cmd.Parameters.AddWithValue("@empID", DBNull.Value);

                                if (i == 0)
                                {
                                    if (stg2Ds.Tables[0].Rows[i][16].ToString() == "")
                                        cmd.Parameters.AddWithValue("@Remarks", " **Note: This tender was formerly Assigned to " + _committee + " with assigned Tender No.  " + _tenderNo);
                                    else
                                        cmd.Parameters.AddWithValue("@Remarks", stg2Ds.Tables[0].Rows[i][16] + " **Note: This tender was formerly Assigned to " + _committee + " with assigned Tender No.  " + _tenderNo);                                    
                                }
                                else
                                    cmd.Parameters.AddWithValue("@Remarks", stg2Ds.Tables[0].Rows[i][16].ToString());

                                cmd.Parameters.AddWithValue("@dateId", dateID);

                                if (stg2Ds.Tables[0].Rows[i][17].ToString() != "")
                                    cmd.Parameters.AddWithValue("@orgTenderValidity", stg2Ds.Tables[0].Rows[i][17]);
                                else
                                    cmd.Parameters.AddWithValue("@orgTenderValidity", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][18].ToString() != "")
                                    cmd.Parameters.AddWithValue("@orgTenderbondValidity", stg2Ds.Tables[0].Rows[i][18]);
                                else
                                    cmd.Parameters.AddWithValue("@orgTenderbondValidity", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][19] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][19].ToString() != "")
                                        cmd.Parameters.AddWithValue("@orgTenderToExpire", Convert.ToInt16(stg2Ds.Tables[0].Rows[i][19]));
                                    else
                                        cmd.Parameters.AddWithValue("@orgTenderToExpire", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@orgTenderToExpire", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][20] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][20].ToString() != "")
                                        cmd.Parameters.AddWithValue("@orgTenderbondExpire", Convert.ToInt16(stg2Ds.Tables[0].Rows[i][20]));
                                    else
                                        cmd.Parameters.AddWithValue("@orgTenderbondExpire", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@orgTenderbondExpire", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][21] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][21].ToString() != "")
                                        cmd.Parameters.AddWithValue("@tenderValidityExt1", stg2Ds.Tables[0].Rows[i][21]);
                                    else
                                        cmd.Parameters.AddWithValue("@tenderValidityExt1", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@tenderValidityExt1", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][22] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][22].ToString() != "")
                                        cmd.Parameters.AddWithValue("@tenderValidityExt2", stg2Ds.Tables[0].Rows[i][22]);
                                    else
                                        cmd.Parameters.AddWithValue("@tenderValidityExt2", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@tenderValidityExt2", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][23] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][23].ToString() != "")
                                        cmd.Parameters.AddWithValue("@tenderbondValidityExt1", stg2Ds.Tables[0].Rows[i][23]);
                                    else
                                        cmd.Parameters.AddWithValue("@tenderbondValidityExt1", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@tenderbondValidityExt1", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][24] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][24].ToString() != "")
                                        cmd.Parameters.AddWithValue("@tenderbondValidityExt2", stg2Ds.Tables[0].Rows[i][24]);
                                    else
                                        cmd.Parameters.AddWithValue("@tenderbondValidityExt2", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@tenderbondValidityExt2", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][25] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][25].ToString() != "")
                                        cmd.Parameters.AddWithValue("@tenderIssued", stg2Ds.Tables[0].Rows[i][25]);
                                    else
                                        cmd.Parameters.AddWithValue("@tenderIssued", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@tenderIssued", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][26] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][26].ToString() != "")
                                        cmd.Parameters.AddWithValue("@sn", Convert.ToInt16(stg2Ds.Tables[0].Rows[i][26]));
                                    else
                                        cmd.Parameters.AddWithValue("@sn", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@sn", DBNull.Value);
                                                                
                                cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                                                               
                                cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                                cmd.Parameters.AddWithValue("@createUser", _userName);
                                cmd.Parameters.AddWithValue("@updateUser", _userName);

                                if (stg2Ds.Tables[0].Rows[i][31] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][31].ToString() != "")
                                        cmd.Parameters.AddWithValue("@alert", stg2Ds.Tables[0].Rows[i][31]);
                                    else
                                        cmd.Parameters.AddWithValue("@alert", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@alert", DBNull.Value);

                                // Added by Varun on 08 May 2014 for copying the newly added column data
                                if (stg2Ds.Tables[0].Rows[i][32] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][32].ToString() != "")
                                        cmd.Parameters.AddWithValue("@companyEmailID", stg2Ds.Tables[0].Rows[i][32]);
                                    else
                                        cmd.Parameters.AddWithValue("@companyEmailID", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@companyEmailID", DBNull.Value);

                                int exUpdated = cmd.ExecuteNonQuery();
                                cmd.Parameters.Clear();
                                 
                            }
                            else
                                i = stg2Ds.Tables[0].Rows.Count;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while copying the records." + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void frmTransforProject_Load(object sender, EventArgs e)
        {
            if (_tndrStatus.Equals("10"))
            {
                cmbCommittee.Items.Clear();
                if (_committee.Equals("ITC"))
                {
                    cmbCommittee.Items.Add("GTC");
                    //commented by Varun on 11/08/14
                    //cmbCommittee.Items.Add("U&EWTC");
                    cmbCommittee.Items.Add("EUWC");
                    cmbCommittee.Items.Add("MRPSC");
                }
                if (_committee.Equals("STC"))
                {
                    cmbCommittee.Items.Add("ITC");
                    cmbCommittee.Items.Add("GTC");
                    //commented by Varun on 11/08/14
                    //cmbCommittee.Items.Add("U&EWTC");
                    cmbCommittee.Items.Add("EUWC");
                }
                if (_committee.Equals("WPC"))
                {
                    cmbCommittee.Items.Add("STC");
                    cmbCommittee.Items.Add("ITC");
                    cmbCommittee.Items.Add("GTC");
                    //commented by Varun on 11/08/14
                    //cmbCommittee.Items.Add("U&EWTC");
                    cmbCommittee.Items.Add("EUWC");
                }
                if (_committee.Equals("GTC"))
                {
                    //commented by Varun on 11/08/14
                    //cmbCommittee.Items.Add("U&EWTC");
                    cmbCommittee.Items.Add("EUWC");
                    cmbCommittee.Items.Add("MRPSC");                    
                }                
            }
            else if (_tndrStatus.Equals("9"))
            {
                this.Text = "Re-Tender Project";
                lblCommitteName.Visible = false; 
                cmbCommittee.Visible = false;
                grpBoxTenderType.Visible = true;
            }
        }
         
       
        int dateID = 0;
        private void InsertDocumentPreparationInfo(DataSet stg1Ds)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    sqlConn.Open();
                    int totRows = stg1Ds.Tables[0].Rows.Count;
                    for (int i = 0; i < totRows; i++)
                    {
                        dateID = MaxDateID();
                        string insertQuery = "INSERT INTO TenderDatesInfo(date_id,proj_id, stage_id, ptd_receive_on, ptd_purpose, ptd_assign_qs," +
                        " ptd_sent_for_rev, ptd_qs_working_status, ptd_tendec_doc_cur_status,ptd_forwarded_to_dep, remarks,create_date,update_date,create_user,update_user,Alert) VALUES " +
                        " (@dateId,@projId,@stageId,@PTDreceiveOn,@PTDPurpose,@PTDassignQs,@PTDForReview,@PTDQsStatus,@PTDdocStatus,@PTDfrwdDept,@PTDRemarks,@createDate,@updateDate,@createUser,@updateUser,@alert)";

                        SqlCommand cmd = new SqlCommand(insertQuery, sqlConn);
                        cmd.Parameters.AddWithValue("@dateId", dateID);
                        cmd.Parameters.AddWithValue("@projId", _newPrjID);
                        cmd.Parameters.AddWithValue("@stageId", 1);

                        if (stg1Ds.Tables[0].Rows[i][3].ToString() != "")
                            cmd.Parameters.AddWithValue("@PTDreceiveOn", stg1Ds.Tables[0].Rows[i][3]);
                        else
                            cmd.Parameters.AddWithValue("@PTDreceiveOn", DBNull.Value);

                        if (stg1Ds.Tables[0].Rows[i][4].ToString() != "")
                            cmd.Parameters.AddWithValue("@PTDPurpose", stg1Ds.Tables[0].Rows[i][4].ToString());
                        else
                            cmd.Parameters.AddWithValue("@PTDPurpose", DBNull.Value);

                        if (stg1Ds.Tables[0].Rows[i][5].ToString() != "")
                            cmd.Parameters.AddWithValue("@PTDassignQs", stg1Ds.Tables[0].Rows[i][5].ToString());
                        else
                            cmd.Parameters.AddWithValue("@PTDassignQs", DBNull.Value);

                        if (stg1Ds.Tables[0].Rows[i][6].ToString() != "")
                            cmd.Parameters.AddWithValue("@PTDForReview", stg1Ds.Tables[0].Rows[i][6]);
                        else
                            cmd.Parameters.AddWithValue("@PTDForReview", DBNull.Value);

                        if (stg1Ds.Tables[0].Rows[i][7].ToString() != "")
                            cmd.Parameters.AddWithValue("@PTDQsStatus", stg1Ds.Tables[0].Rows[i][7].ToString());
                        else
                            cmd.Parameters.AddWithValue("@PTDQsStatus", DBNull.Value);

                        if (stg1Ds.Tables[0].Rows[i][8].ToString() != "")
                            cmd.Parameters.AddWithValue("@PTDdocStatus", stg1Ds.Tables[0].Rows[i][8].ToString());
                        else
                            cmd.Parameters.AddWithValue("@PTDdocStatus", DBNull.Value);

                        if (stg1Ds.Tables[0].Rows[i][9].ToString() != "")
                            cmd.Parameters.AddWithValue("@PTDfrwdDept", stg1Ds.Tables[0].Rows[i][9]);
                        else
                            cmd.Parameters.AddWithValue("@PTDfrwdDept", DBNull.Value);

                        cmd.Parameters.AddWithValue("@PTDRemarks", stg1Ds.Tables[0].Rows[i][10].ToString()); // + "**Note: This tender was formerly Assigned to "  + _committee + " with assigned Tender No. PWA/ITC/039/2011-12"
                        cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@createUser", _userName);
                        cmd.Parameters.AddWithValue("@updateUser", _userName);

                        if (stg1Ds.Tables[0].Rows[i][15] != DBNull.Value)
                            if (stg1Ds.Tables[0].Rows[i][15].ToString() != "")
                                cmd.Parameters.AddWithValue("@alert", stg1Ds.Tables[0].Rows[i][15]);
                            else
                                cmd.Parameters.AddWithValue("@alert", DBNull.Value);
                        else
                            cmd.Parameters.AddWithValue("@alert", DBNull.Value);

                        cmd.ExecuteNonQuery();
                        
                        //MessageBox.Show("Tender Document Preparation Data Added Successfully!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while copying the records." + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {                
            }
        }
        //private void InsertTenderPreparationInfo(DataSet stg2Ds)
        //{
        //    try
        //    {
        //        using (SqlConnection sqlConn = new SqlConnection(strCon))
        //        {
        //            using (SqlCommand cmd = new SqlCommand())
        //            {
        //                sqlConn.Open();
        //                cmd.Connection = sqlConn;
        //                int stgeId = 0;
        //                stgeId = 2;

        //                for (int i = 0; i < stg2Ds.Tables[0].Rows.Count; i++)
        //                {
        //                    int dateID = MaxDateID();

        //                    cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,ts_receive_on,ts_issue_handling,ts_return_to_dept, " +
        //                    " ts_receive_from_dept,ts_pr_advertise,ts_tender_invitation,ts_closing_s1,ts_closing_s2,ts_modified_closing,ts_tender_issue,ts_receipt_no,co_id,employee_id,remarks) VALUES " +
        //                    " (@dateId,@projId,@stageId,@receiveOn,@issueHandling,@returnDept,@receivedFromDept,@advertisement,@invitation,@closingDate,@closingDate2,@tsModifyDate,@issueTndrDate,@receiptNo,@coID,@empID,@Remarks)";

        //                    cmd.Parameters.AddWithValue("@stageId", stgeId);
        //                    cmd.Parameters.AddWithValue("@projId", maxPrjiD);
        //                    cmd.Parameters.AddWithValue("@receiveOn", stg2Ds.Tables[0].Rows[i][3]);

        //                    if (stg2Ds.Tables[0].Rows[i][4].ToString() != "")
        //                        cmd.Parameters.AddWithValue("@issueHandling", stg2Ds.Tables[0].Rows[i][4]);
        //                    else
        //                        cmd.Parameters.AddWithValue("@issueHandling", DBNull.Value);

        //                    if (stg2Ds.Tables[0].Rows[i][5].ToString() != "")
        //                        cmd.Parameters.AddWithValue("@returnDept", stg2Ds.Tables[0].Rows[i][5]);
        //                    else
        //                        cmd.Parameters.AddWithValue("@returnDept", DBNull.Value);

        //                    if (stg2Ds.Tables[0].Rows[i][6].ToString() != "")
        //                        cmd.Parameters.AddWithValue("@receivedFromDept", stg2Ds.Tables[0].Rows[i][6]);
        //                    else
        //                        cmd.Parameters.AddWithValue("@receivedFromDept", DBNull.Value);

        //                    if (stg2Ds.Tables[0].Rows[i][7].ToString() != "")
        //                        cmd.Parameters.AddWithValue("@advertisement", stg2Ds.Tables[0].Rows[i][7]);
        //                    else
        //                        cmd.Parameters.AddWithValue("@advertisement", DBNull.Value);

        //                    if (stg2Ds.Tables[0].Rows[i][8].ToString() != "")
        //                        cmd.Parameters.AddWithValue("@invitation", stg2Ds.Tables[0].Rows[i][8]);
        //                    else
        //                        cmd.Parameters.AddWithValue("@invitation", DBNull.Value);

        //                    if (stg2Ds.Tables[0].Rows[i][9].ToString() != "")
        //                        cmd.Parameters.AddWithValue("@closingDate", stg2Ds.Tables[0].Rows[i][9]);
        //                    else
        //                        cmd.Parameters.AddWithValue("@closingDate", DBNull.Value);

        //                    if (stg2Ds.Tables[0].Rows[i][10].ToString() != "")
        //                        cmd.Parameters.AddWithValue("@closingDate2", stg2Ds.Tables[0].Rows[i][10]);
        //                    else
        //                        cmd.Parameters.AddWithValue("@closingDate2", DBNull.Value);

        //                    if (stg2Ds.Tables[0].Rows[i][11].ToString() != "")
        //                        cmd.Parameters.AddWithValue("@tsModifyDate", stg2Ds.Tables[0].Rows[i][11]);
        //                    else
        //                        cmd.Parameters.AddWithValue("@tsModifyDate", DBNull.Value);

        //                    if (stg2Ds.Tables[0].Rows[i][12].ToString() != "")
        //                        cmd.Parameters.AddWithValue("@issueTndrDate", stg2Ds.Tables[0].Rows[i][12]);
        //                    else
        //                        cmd.Parameters.AddWithValue("@issueTndrDate", DBNull.Value);

        //                    if (stg2Ds.Tables[0].Rows[i][13].ToString() != "")
        //                        cmd.Parameters.AddWithValue("@receiptNo", stg2Ds.Tables[0].Rows[i][13]);
        //                    else
        //                        cmd.Parameters.AddWithValue("@receiptNo", DBNull.Value);

        //                    if (stg2Ds.Tables[0].Rows[i][14].ToString() != "")
        //                        cmd.Parameters.AddWithValue("@coID", stg2Ds.Tables[0].Rows[i][14]);
        //                    else
        //                        cmd.Parameters.AddWithValue("@coID", DBNull.Value);

        //                    if (stg2Ds.Tables[0].Rows[i][15].ToString() != "")
        //                        cmd.Parameters.AddWithValue("@empID", stg2Ds.Tables[0].Rows[i][15]);
        //                    else
        //                        cmd.Parameters.AddWithValue("@empID", DBNull.Value);

        //                    cmd.Parameters.AddWithValue("@Remarks", stg2Ds.Tables[0].Rows[i][16] + " **Note: This tender was formerly Assigned to " + _committee + " with assigned Tender No.  " + _tenderNo);
                            
        //                    cmd.Parameters.AddWithValue("@dateId", dateID);

        //                    int exUpdated = cmd.ExecuteNonQuery();
        //                    cmd.Parameters.Clear();
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //    }
        //}


        private void InsertTenderEvaluationData(DataSet stg3Ds)
        {
            int totRowCount = stg3Ds.Tables[0].Rows.Count;
            for (int i = 0; i < totRowCount; i++)
            {                
                try
                {
                    using (SqlConnection sqlConn = new SqlConnection(strCon))
                    {
                        using (SqlCommand cmd = new SqlCommand())
                        {
                            sqlConn.Open();
                            cmd.Connection = sqlConn;                            
                            dateID = MaxDateID();
                            cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,eval_tender_opening,eval_tender_doc_receive_from_cd, " +
                            " eval_tech_sent,eval_tech_receive,remarks,create_date,update_date,create_user,update_user,Alert) " +
                            " VALUES(@dateId,@projId,@stageId,@evltendrReq,@fromCd,@senttoTech,@recfromtech,@remarksTE,@createDate,@updateDate,@createUser,@updateUser,@alert)";
                            
                            cmd.Parameters.AddWithValue("@dateId", dateID);
                            cmd.Parameters.AddWithValue("@projId", _newPrjID);
                            cmd.Parameters.AddWithValue("@stageId", 3);                           

                            if (stg3Ds.Tables[0].Rows[i][3].ToString() != "")
                                cmd.Parameters.AddWithValue("@evltendrReq", stg3Ds.Tables[0].Rows[i][3].ToString());
                            else
                                cmd.Parameters.AddWithValue("@evltendrReq", DBNull.Value);

                            if (stg3Ds.Tables[0].Rows[i][4].ToString() != "")
                                cmd.Parameters.AddWithValue("@fromCd", stg3Ds.Tables[0].Rows[i][4].ToString());
                            else
                                cmd.Parameters.AddWithValue("@fromCd", DBNull.Value);

                            if (stg3Ds.Tables[0].Rows[i][5].ToString() != "")
                                cmd.Parameters.AddWithValue("@senttoTech", stg3Ds.Tables[0].Rows[i][5].ToString());
                            else
                                cmd.Parameters.AddWithValue("@senttoTech", DBNull.Value);

                            if (stg3Ds.Tables[0].Rows[i][6].ToString() != "")
                                cmd.Parameters.AddWithValue("@recfromtech", stg3Ds.Tables[0].Rows[i][6].ToString());
                            else
                                cmd.Parameters.AddWithValue("@recfromtech", DBNull.Value);

                            if (i == 0)
                            {
                                if (stg3Ds.Tables[0].Rows[i][7].ToString() != "")
                                    cmd.Parameters.AddWithValue("@remarksTE", stg3Ds.Tables[0].Rows[i][7].ToString() + " **Note: This tender was formerly Assigned to " + _committee + " with assigned Tender No.  " + _tenderNo);
                                else
                                    cmd.Parameters.AddWithValue("@remarksTE", " **Note: This tender was formerly Assigned to " + _committee + " with assigned Tender No.  " + _tenderNo);                                
                            }
                            else
                                cmd.Parameters.AddWithValue("@remarksTE", stg3Ds.Tables[0].Rows[i][7].ToString());
                            
                            cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                            cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                            cmd.Parameters.AddWithValue("@createUser", _userName);
                            cmd.Parameters.AddWithValue("@updateUser", _userName);

                            if (stg3Ds.Tables[0].Rows[i][12] != DBNull.Value)
                                if (stg3Ds.Tables[0].Rows[i][12].ToString() != "")
                                    cmd.Parameters.AddWithValue("@alert", stg3Ds.Tables[0].Rows[i][12]);
                                else
                                    cmd.Parameters.AddWithValue("@alert", DBNull.Value);
                            else
                                cmd.Parameters.AddWithValue("@alert", DBNull.Value);

                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                            
                           // MessageBox.Show("Tender Evaluation & Award data added Succesfully");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while copying the records." + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }            
        private void UpdateDocumentProjectID()
        {
            //string sqlQuery = "SELECT project_id FROM DOCUMENTS WHERE PROJ_ID = " +  _prjCodeExisted + " and STAGE_ID = 1";

            string sqlQuery = "UPDATE DOCUMENTS SET project_id =@projId FROM DOCUMENTS WHERE PROJ_ID = " + _prjCodeExisted + " and STAGE_ID = 1";
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn; 
                        cmd.CommandText = sqlQuery;

                        cmd.Parameters.AddWithValue("@projId", _newPrjID);
                        //cmd.Parameters.AddWithValue("@stageId", stage_Id);

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();                       
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while UPDATING DOCUMENTS", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void cmbCommittee_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbCommittee.Text == "Re-Tender")
            {
                grpBoxTenderType.Visible = true;
            }
        }


        private void UpdateProjectCost(DataSet ds_Cost)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        int stgeId = 0;
                        stgeId = 4;

                        for (int i = 0; i < ds_Cost.Tables[0].Rows.Count; i++)
                        {
                            int _costID = MaxCostID();

                            cmd.CommandText = @"INSERT INTO ProjectCost(stage_id, proj_id, budgeted_cost, estimated_cost, tender_bond, doc_fee, Remarks) VALUES " +
                            " (@stageId,@projId,@budgeted_cost,@estimated_cost,@tender_bond,@doc_fee,@Remarks)";

                            //cmd.Parameters.AddWithValue("@cost_item_id", _costID);
                            cmd.Parameters.AddWithValue("@stageId", stgeId);
                            cmd.Parameters.AddWithValue("@projId", _newPrjID);
                           
                            if (ds_Cost.Tables[0].Rows[i][3].ToString() != "")
                                cmd.Parameters.AddWithValue("@budgeted_cost", ds_Cost.Tables[0].Rows[i][3]);
                            else
                                cmd.Parameters.AddWithValue("@budgeted_cost", DBNull.Value);

                            if (ds_Cost.Tables[0].Rows[i][4].ToString() != "")
                                cmd.Parameters.AddWithValue("@estimated_cost", ds_Cost.Tables[0].Rows[i][4]);
                            else
                                cmd.Parameters.AddWithValue("@estimated_cost", DBNull.Value);

                            if (ds_Cost.Tables[0].Rows[i][5].ToString() != "")
                                cmd.Parameters.AddWithValue("@tender_bond", ds_Cost.Tables[0].Rows[i][5]);
                            else
                                cmd.Parameters.AddWithValue("@tender_bond", DBNull.Value);

                            if (ds_Cost.Tables[0].Rows[i][6].ToString() != "")
                                cmd.Parameters.AddWithValue("@doc_fee", ds_Cost.Tables[0].Rows[i][6]);
                            else
                                cmd.Parameters.AddWithValue("@doc_fee", DBNull.Value);

                            if (ds_Cost.Tables[0].Rows[i][7].ToString() != "")
                                cmd.Parameters.AddWithValue("@Remarks", ds_Cost.Tables[0].Rows[i][7] + " **Note: This tender was formerly Assigned to " + _committee + " with assigned Tender No.  " + _tenderNo);
                            else
                                cmd.Parameters.AddWithValue("@Remarks", " **Note: This tender was formerly Assigned to " + _committee + " with assigned Tender No.  " + _tenderNo);

                         
                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private int MaxCostID()
        {
            int costID = 0;
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"SELECT MAX(Cost_item_ID) FROM ProjectCost";
                        costID = Convert.ToInt16(cmd.ExecuteScalar());
                        costID = costID + 1;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            return costID;
        }



        private void UpdateDocumnts_ProjectID()
        {
            SqlConnection sqlConn = new SqlConnection(strCon);
            sqlConn.Open();
            //doc_type_id<>2 Added by Varun on 04 Feb 2014 Based on req. from Adonis
            string insertQuery = "UPDATE DOCUMENTS SET Proj_ID =  " + _newPrjID + " WHERE Proj_ID = " + _prjIDExist + " and doc_type_id<>2";  
            using (SqlCommand cmd = new SqlCommand(insertQuery, sqlConn))
            {
                int exUpdated = cmd.ExecuteNonQuery();
                cmd.Parameters.Clear();
            }
            sqlConn.Close();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            transforTenderDates_Stage2_TEMP();
        }


        private void InsertTenderStageInfo_Temp(DataSet stg2Ds)
        {


            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        int stgeId = 0;
                        stgeId = 2;
                        int totRowsCount = stg2Ds.Tables[0].Rows.Count;
                        for (int i = 0; i < totRowsCount; i++)
                        {
                            dateID = MaxDateID();
                            if (stg2Ds.Tables[0].Rows[0][9].ToString() != "")   // Tender Closing date 
                            {

                                if (i == 0)
                                    cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,ts_receive_on,ts_issue_handling,ts_return_to_dept, " +
                                    " ts_receive_from_dept,ts_pr_advertise,ts_tender_invitation,ts_closing_s1,ts_closing_s2,ts_modified_closing,ts_tender_issue,ts_receipt_no,co_id,employee_id,remarks,org_tender_validity," +
                                    "org_tenderbond_validity,org_tender_to_expire,org_tenderbond_to_expire,tender_validity_ext1,tender_validity_ext2,tenderbond_validity_ext1,tenderbond_validity_ext2,Tender_Issued,SN,create_date,update_date,create_user,update_user,Alert,Company_EmailID) VALUES " +
                                    "(@dateId,@projId,@stageId,@receiveOn,@issueHandling,@returnDept,@receivedFromDept,@advertisement,@invitation,@closingDate,@closingDate2,@tsModifyDate,@issueTndrDate,@receiptNo,@coID,@empID,@Remarks," +
                                    "@orgTenderValidity,@orgTenderbondValidity,@orgTenderToExpire,@orgTenderbondExpire,@tenderValidityExt1,@tenderValidityExt2,@tenderbondValidityExt1,@tenderbondValidityExt2,@tenderIssued,@sn,@createDate,@updateDate,@createUser,@updateUser,@alert,@companyEmailID)";
                                else if (i >= 1)
                                    cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,ts_receive_on,ts_issue_handling,ts_return_to_dept, " +
                                    " ts_receive_from_dept,ts_pr_advertise,ts_tender_invitation,ts_closing_s2,ts_modified_closing,ts_tender_issue,ts_receipt_no,co_id,employee_id,remarks,org_tender_validity,org_tenderbond_validity," +
                                    "org_tender_to_expire,org_tenderbond_to_expire,tender_validity_ext1,tender_validity_ext2,tenderbond_validity_ext1,tenderbond_validity_ext2,Tender_Issued,SN,create_date,update_date,create_user,update_user,Alert,Company_EmailID) VALUES " +
                                    "(@dateId,@projId,@stageId,@receiveOn,@issueHandling,@returnDept,@receivedFromDept,@advertisement,@invitation,@closingDate2,@tsModifyDate,@issueTndrDate,@receiptNo,@coID,@empID,@Remarks," +
                                    "@orgTenderValidity,@orgTenderbondValidity,@orgTenderToExpire,@orgTenderbondExpire,@tenderValidityExt1,@tenderValidityExt2,@tenderbondValidityExt1,@tenderbondValidityExt2,@tenderIssued,@sn,@createDate,@updateDate,@createUser,@updateUser,@alert,@companyEmailID)";

                                cmd.Parameters.AddWithValue("@stageId", stgeId);

                                cmd.Parameters.AddWithValue("@projId", 1465);


                                cmd.Parameters.AddWithValue("@receiveOn", stg2Ds.Tables[0].Rows[i][3]);

                                if (stg2Ds.Tables[0].Rows[i][4].ToString() != "")
                                    cmd.Parameters.AddWithValue("@issueHandling", stg2Ds.Tables[0].Rows[i][4]);
                                else
                                    cmd.Parameters.AddWithValue("@issueHandling", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][5].ToString() != "")
                                    cmd.Parameters.AddWithValue("@returnDept", stg2Ds.Tables[0].Rows[i][5]);
                                else
                                    cmd.Parameters.AddWithValue("@returnDept", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][6].ToString() != "")
                                    cmd.Parameters.AddWithValue("@receivedFromDept", stg2Ds.Tables[0].Rows[i][6]);
                                else
                                    cmd.Parameters.AddWithValue("@receivedFromDept", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][7].ToString() != "")
                                    cmd.Parameters.AddWithValue("@advertisement", stg2Ds.Tables[0].Rows[i][7]);
                                else
                                    cmd.Parameters.AddWithValue("@advertisement", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][8].ToString() != "")
                                    cmd.Parameters.AddWithValue("@invitation", stg2Ds.Tables[0].Rows[i][8]);
                                else
                                    cmd.Parameters.AddWithValue("@invitation", DBNull.Value);

                                if (i == 0)
                                {
                                    if (stg2Ds.Tables[0].Rows[i][9].ToString() != "")
                                        cmd.Parameters.AddWithValue("@closingDate", stg2Ds.Tables[0].Rows[i][9]);
                                }

                                if (stg2Ds.Tables[0].Rows[i][10].ToString() != "")
                                    cmd.Parameters.AddWithValue("@closingDate2", stg2Ds.Tables[0].Rows[i][10]);
                                else
                                    cmd.Parameters.AddWithValue("@closingDate2", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][11].ToString() != "")
                                    cmd.Parameters.AddWithValue("@tsModifyDate", stg2Ds.Tables[0].Rows[i][11]);
                                else
                                    cmd.Parameters.AddWithValue("@tsModifyDate", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][12].ToString() != "")
                                    cmd.Parameters.AddWithValue("@issueTndrDate", stg2Ds.Tables[0].Rows[i][12]);
                                else
                                    cmd.Parameters.AddWithValue("@issueTndrDate", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][13].ToString() != "")
                                    cmd.Parameters.AddWithValue("@receiptNo", stg2Ds.Tables[0].Rows[i][13]);
                                else
                                    cmd.Parameters.AddWithValue("@receiptNo", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][14].ToString() != "")
                                    cmd.Parameters.AddWithValue("@coID", stg2Ds.Tables[0].Rows[i][14]);
                                else
                                    cmd.Parameters.AddWithValue("@coID", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][15].ToString() != "")
                                    cmd.Parameters.AddWithValue("@empID", stg2Ds.Tables[0].Rows[i][15]);
                                else
                                    cmd.Parameters.AddWithValue("@empID", DBNull.Value);

                                if (i == 0)
                                {
                                    if (stg2Ds.Tables[0].Rows[i][16].ToString() == "")
                                        cmd.Parameters.AddWithValue("@Remarks", " **Note: This tender was formerly Assigned to " + "STC" + " with assigned Tender No.  " + "PWA/STC/050/2013-2014");
                                    else
                                        cmd.Parameters.AddWithValue("@Remarks", stg2Ds.Tables[0].Rows[i][16] + " **Note: This tender was formerly Assigned to " + "STC" + " with assigned Tender No.  " + "PWA/STC/050/2013-2014");
                                }
                                else
                                    cmd.Parameters.AddWithValue("@Remarks", stg2Ds.Tables[0].Rows[i][16].ToString());

                                cmd.Parameters.AddWithValue("@dateId", dateID);

                                if (stg2Ds.Tables[0].Rows[i][17].ToString() != "")
                                    cmd.Parameters.AddWithValue("@orgTenderValidity", stg2Ds.Tables[0].Rows[i][17]);
                                else
                                    cmd.Parameters.AddWithValue("@orgTenderValidity", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][18].ToString() != "")
                                    cmd.Parameters.AddWithValue("@orgTenderbondValidity", stg2Ds.Tables[0].Rows[i][18]);
                                else
                                    cmd.Parameters.AddWithValue("@orgTenderbondValidity", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][19] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][19].ToString() != "")
                                        cmd.Parameters.AddWithValue("@orgTenderToExpire", Convert.ToInt16(stg2Ds.Tables[0].Rows[i][19]));
                                    else
                                        cmd.Parameters.AddWithValue("@orgTenderToExpire", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@orgTenderToExpire", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][20] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][20].ToString() != "")
                                        cmd.Parameters.AddWithValue("@orgTenderbondExpire", Convert.ToInt16(stg2Ds.Tables[0].Rows[i][20]));
                                    else
                                        cmd.Parameters.AddWithValue("@orgTenderbondExpire", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@orgTenderbondExpire", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][21] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][21].ToString() != "")
                                        cmd.Parameters.AddWithValue("@tenderValidityExt1", stg2Ds.Tables[0].Rows[i][21]);
                                    else
                                        cmd.Parameters.AddWithValue("@tenderValidityExt1", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@tenderValidityExt1", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][22] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][22].ToString() != "")
                                        cmd.Parameters.AddWithValue("@tenderValidityExt2", stg2Ds.Tables[0].Rows[i][22]);
                                    else
                                        cmd.Parameters.AddWithValue("@tenderValidityExt2", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@tenderValidityExt2", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][23] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][23].ToString() != "")
                                        cmd.Parameters.AddWithValue("@tenderbondValidityExt1", stg2Ds.Tables[0].Rows[i][23]);
                                    else
                                        cmd.Parameters.AddWithValue("@tenderbondValidityExt1", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@tenderbondValidityExt1", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][24] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][24].ToString() != "")
                                        cmd.Parameters.AddWithValue("@tenderbondValidityExt2", stg2Ds.Tables[0].Rows[i][24]);
                                    else
                                        cmd.Parameters.AddWithValue("@tenderbondValidityExt2", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@tenderbondValidityExt2", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][25] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][25].ToString() != "")
                                        cmd.Parameters.AddWithValue("@tenderIssued", stg2Ds.Tables[0].Rows[i][25]);
                                    else
                                        cmd.Parameters.AddWithValue("@tenderIssued", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@tenderIssued", DBNull.Value);

                                if (stg2Ds.Tables[0].Rows[i][26] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][26].ToString() != "")
                                        cmd.Parameters.AddWithValue("@sn", Convert.ToInt16(stg2Ds.Tables[0].Rows[i][26]));
                                    else
                                        cmd.Parameters.AddWithValue("@sn", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@sn", DBNull.Value);

                                cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now);

                                cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                                cmd.Parameters.AddWithValue("@createUser", _userName);
                                cmd.Parameters.AddWithValue("@updateUser", _userName);

                                if (stg2Ds.Tables[0].Rows[i][31] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][31].ToString() != "")
                                        cmd.Parameters.AddWithValue("@alert", stg2Ds.Tables[0].Rows[i][31]);
                                    else
                                        cmd.Parameters.AddWithValue("@alert", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@alert", DBNull.Value);

                                // Added by Varun on 08 May 2014 for copying the newly added column data
                                if (stg2Ds.Tables[0].Rows[i][32] != DBNull.Value)
                                    if (stg2Ds.Tables[0].Rows[i][32].ToString() != "")
                                        cmd.Parameters.AddWithValue("@companyEmailID", stg2Ds.Tables[0].Rows[i][32]);
                                    else
                                        cmd.Parameters.AddWithValue("@companyEmailID", DBNull.Value);
                                else
                                    cmd.Parameters.AddWithValue("@companyEmailID", DBNull.Value);

                                int exUpdated = cmd.ExecuteNonQuery();
                                cmd.Parameters.Clear();

                            }
                            else
                                i = stg2Ds.Tables[0].Rows.Count;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while copying the records." + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

    }
}
