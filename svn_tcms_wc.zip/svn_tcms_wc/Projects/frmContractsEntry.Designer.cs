﻿namespace MDI_ParenrForm.Projects
{
    partial class frmContractsEntry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btnAddVarOrderDet = new System.Windows.Forms.Button();
            this.btnAddSiteInstruction = new System.Windows.Forms.Button();
            this.btnAddVariationOrder = new System.Windows.Forms.Button();
            this.cmbContractStatus = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtContractNo = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtOriginalCntrSum = new System.Windows.Forms.TextBox();
            this.txtPerfomenceBond = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txtVariationOrder = new System.Windows.Forms.TextBox();
            this.txtApprovedEOT = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.txtAdjustedCntrSum = new System.Windows.Forms.TextBox();
            this.txtNoOfClaims = new System.Windows.Forms.TextBox();
            this.txtCmpType = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.txtDaysElapsed = new System.Windows.Forms.TextBox();
            this.txtCntrDuration = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtMaintenencePeriod = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dtpCntrStartDate = new System.Windows.Forms.DateTimePicker();
            this.dtpEndDate = new System.Windows.Forms.DateTimePicker();
            this.dtpRevisedDate = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dtpPB_Ext2 = new System.Windows.Forms.DateTimePicker();
            this.dtpPB_Ext1 = new System.Windows.Forms.DateTimePicker();
            this.dtpPerfomenseDate = new System.Windows.Forms.DateTimePicker();
            this.label18 = new System.Windows.Forms.Label();
            this.txtPBtoExpire = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.txtContractTitle = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvCP_Sent = new System.Windows.Forms.DataGridView();
            this.dgvCP_Rec = new System.Windows.Forms.DataGridView();
            this.btnSentDoc = new System.Windows.Forms.Button();
            this.btnReceiveDoc = new System.Windows.Forms.Button();
            this.cmbCompany = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.txtPCRemarks = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCP_Sent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCP_Rec)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.btnAddVarOrderDet);
            this.groupBox1.Controls.Add(this.btnAddSiteInstruction);
            this.groupBox1.Controls.Add(this.btnAddVariationOrder);
            this.groupBox1.Controls.Add(this.cmbContractStatus);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtContractNo);
            this.groupBox1.Controls.Add(this.tableLayoutPanel4);
            this.groupBox1.Controls.Add(this.txtCmpType);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.tableLayoutPanel2);
            this.groupBox1.Controls.Add(this.tableLayoutPanel1);
            this.groupBox1.Controls.Add(this.dgvCP_Sent);
            this.groupBox1.Controls.Add(this.dgvCP_Rec);
            this.groupBox1.Controls.Add(this.btnSentDoc);
            this.groupBox1.Controls.Add(this.btnReceiveDoc);
            this.groupBox1.Controls.Add(this.cmbCompany);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.btnSave);
            this.groupBox1.Controls.Add(this.btnCancel);
            this.groupBox1.Controls.Add(this.txtPCRemarks);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1016, 745);
            this.groupBox1.TabIndex = 27;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Contracts Information Update Window";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(639, 262);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(190, 23);
            this.button1.TabIndex = 143;
            this.button1.Text = "Add Site Instruction Details";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnAddVarOrderDet
            // 
            this.btnAddVarOrderDet.Location = new System.Drawing.Point(639, 209);
            this.btnAddVarOrderDet.Name = "btnAddVarOrderDet";
            this.btnAddVarOrderDet.Size = new System.Drawing.Size(190, 23);
            this.btnAddVarOrderDet.TabIndex = 142;
            this.btnAddVarOrderDet.Text = "Add Variation Order Details";
            this.btnAddVarOrderDet.UseVisualStyleBackColor = true;
            this.btnAddVarOrderDet.Click += new System.EventHandler(this.btnAddVarOrderDet_Click);
            // 
            // btnAddSiteInstruction
            // 
            this.btnAddSiteInstruction.BackColor = System.Drawing.Color.Maroon;
            this.btnAddSiteInstruction.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAddSiteInstruction.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddSiteInstruction.ForeColor = System.Drawing.Color.White;
            this.btnAddSiteInstruction.Location = new System.Drawing.Point(165, 505);
            this.btnAddSiteInstruction.Name = "btnAddSiteInstruction";
            this.btnAddSiteInstruction.Size = new System.Drawing.Size(129, 26);
            this.btnAddSiteInstruction.TabIndex = 140;
            this.btnAddSiteInstruction.Text = "Add Site Instruction";
            this.btnAddSiteInstruction.UseVisualStyleBackColor = false;
            this.btnAddSiteInstruction.Click += new System.EventHandler(this.btnAddSiteInstruction_Click);
            // 
            // btnAddVariationOrder
            // 
            this.btnAddVariationOrder.BackColor = System.Drawing.Color.Maroon;
            this.btnAddVariationOrder.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAddVariationOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddVariationOrder.ForeColor = System.Drawing.Color.White;
            this.btnAddVariationOrder.Location = new System.Drawing.Point(296, 505);
            this.btnAddVariationOrder.Name = "btnAddVariationOrder";
            this.btnAddVariationOrder.Size = new System.Drawing.Size(130, 26);
            this.btnAddVariationOrder.TabIndex = 141;
            this.btnAddVariationOrder.Text = "Add Variation Order";
            this.btnAddVariationOrder.UseVisualStyleBackColor = false;
            // 
            // cmbContractStatus
            // 
            this.cmbContractStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbContractStatus.FormattingEnabled = true;
            this.cmbContractStatus.Location = new System.Drawing.Point(455, 127);
            this.cmbContractStatus.Name = "cmbContractStatus";
            this.cmbContractStatus.Size = new System.Drawing.Size(162, 21);
            this.cmbContractStatus.TabIndex = 27;
            this.cmbContractStatus.SelectionChangeCommitted += new System.EventHandler(this.cmbContractStatus_SelectionChangeCommitted);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(365, 131);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 13);
            this.label2.TabIndex = 28;
            this.label2.Text = "Contract Status";
            // 
            // txtContractNo
            // 
            this.txtContractNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContractNo.Location = new System.Drawing.Point(143, 128);
            this.txtContractNo.Name = "txtContractNo";
            this.txtContractNo.Size = new System.Drawing.Size(199, 20);
            this.txtContractNo.TabIndex = 25;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 51.15385F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 48.84615F));
            this.tableLayoutPanel4.Controls.Add(this.label16, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.label17, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.txtOriginalCntrSum, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.txtPerfomenceBond, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.label19, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.label20, 1, 2);
            this.tableLayoutPanel4.Controls.Add(this.txtVariationOrder, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.txtApprovedEOT, 1, 3);
            this.tableLayoutPanel4.Controls.Add(this.label22, 0, 4);
            this.tableLayoutPanel4.Controls.Add(this.label23, 1, 4);
            this.tableLayoutPanel4.Controls.Add(this.txtAdjustedCntrSum, 0, 5);
            this.tableLayoutPanel4.Controls.Add(this.txtNoOfClaims, 1, 5);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(639, 29);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 6;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(260, 148);
            this.tableLayoutPanel4.TabIndex = 139;
            this.tableLayoutPanel4.Visible = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(3, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(109, 13);
            this.label16.TabIndex = 32;
            this.label16.Text = "Original Contract Sum";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(136, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(92, 13);
            this.label17.TabIndex = 41;
            this.label17.Text = "Perfomence Bond";
            // 
            // txtOriginalCntrSum
            // 
            this.txtOriginalCntrSum.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOriginalCntrSum.Location = new System.Drawing.Point(3, 24);
            this.txtOriginalCntrSum.Name = "txtOriginalCntrSum";
            this.txtOriginalCntrSum.Size = new System.Drawing.Size(120, 20);
            this.txtOriginalCntrSum.TabIndex = 137;
            // 
            // txtPerfomenceBond
            // 
            this.txtPerfomenceBond.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPerfomenceBond.Location = new System.Drawing.Point(136, 24);
            this.txtPerfomenceBond.Name = "txtPerfomenceBond";
            this.txtPerfomenceBond.Size = new System.Drawing.Size(115, 20);
            this.txtPerfomenceBond.TabIndex = 138;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(3, 50);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(77, 13);
            this.label19.TabIndex = 38;
            this.label19.Text = "Variation Order";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(136, 50);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(78, 13);
            this.label20.TabIndex = 36;
            this.label20.Text = "Approved EOT";
            // 
            // txtVariationOrder
            // 
            this.txtVariationOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVariationOrder.Location = new System.Drawing.Point(3, 73);
            this.txtVariationOrder.Name = "txtVariationOrder";
            this.txtVariationOrder.Size = new System.Drawing.Size(120, 20);
            this.txtVariationOrder.TabIndex = 141;
            // 
            // txtApprovedEOT
            // 
            this.txtApprovedEOT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtApprovedEOT.Location = new System.Drawing.Point(136, 73);
            this.txtApprovedEOT.Name = "txtApprovedEOT";
            this.txtApprovedEOT.Size = new System.Drawing.Size(120, 20);
            this.txtApprovedEOT.TabIndex = 139;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(3, 95);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(115, 13);
            this.label22.TabIndex = 34;
            this.label22.Text = "Adjusted Contract Sum";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(136, 95);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(66, 13);
            this.label23.TabIndex = 30;
            this.label23.Text = "No of Claims";
            // 
            // txtAdjustedCntrSum
            // 
            this.txtAdjustedCntrSum.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAdjustedCntrSum.Location = new System.Drawing.Point(3, 118);
            this.txtAdjustedCntrSum.Name = "txtAdjustedCntrSum";
            this.txtAdjustedCntrSum.Size = new System.Drawing.Size(115, 20);
            this.txtAdjustedCntrSum.TabIndex = 140;
            // 
            // txtNoOfClaims
            // 
            this.txtNoOfClaims.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNoOfClaims.Location = new System.Drawing.Point(136, 118);
            this.txtNoOfClaims.Name = "txtNoOfClaims";
            this.txtNoOfClaims.Size = new System.Drawing.Size(115, 20);
            this.txtNoOfClaims.TabIndex = 142;
            // 
            // txtCmpType
            // 
            this.txtCmpType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCmpType.Location = new System.Drawing.Point(455, 160);
            this.txtCmpType.Name = "txtCmpType";
            this.txtCmpType.Size = new System.Drawing.Size(162, 20);
            this.txtCmpType.TabIndex = 138;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(41, 131);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(61, 13);
            this.label12.TabIndex = 26;
            this.label12.Text = "ContractNo";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(418, 164);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(31, 13);
            this.label15.TabIndex = 137;
            this.label15.Text = "Type";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.Honeydew;
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 53.33333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 46.66667F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 153F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 262F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Controls.Add(this.txtDaysElapsed, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.txtCntrDuration, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.label5, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label13, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.label14, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.txtMaintenencePeriod, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.label8, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.label10, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.label7, 2, 3);
            this.tableLayoutPanel2.Controls.Add(this.dtpCntrStartDate, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.dtpEndDate, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.dtpRevisedDate, 2, 4);
            this.tableLayoutPanel2.Controls.Add(this.label6, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.label4, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.label3, 2, 5);
            this.tableLayoutPanel2.Controls.Add(this.dtpPB_Ext2, 2, 6);
            this.tableLayoutPanel2.Controls.Add(this.dtpPB_Ext1, 1, 6);
            this.tableLayoutPanel2.Controls.Add(this.dtpPerfomenseDate, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.label18, 3, 5);
            this.tableLayoutPanel2.Controls.Add(this.txtPBtoExpire, 3, 6);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(38, 205);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 7;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 15F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 13F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 69F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(582, 190);
            this.tableLayoutPanel2.TabIndex = 136;
            // 
            // txtDaysElapsed
            // 
            this.txtDaysElapsed.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDaysElapsed.Location = new System.Drawing.Point(169, 23);
            this.txtDaysElapsed.Name = "txtDaysElapsed";
            this.txtDaysElapsed.Size = new System.Drawing.Size(120, 20);
            this.txtDaysElapsed.TabIndex = 138;
            // 
            // txtCntrDuration
            // 
            this.txtCntrDuration.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCntrDuration.Location = new System.Drawing.Point(3, 23);
            this.txtCntrDuration.Name = "txtCntrDuration";
            this.txtCntrDuration.Size = new System.Drawing.Size(83, 20);
            this.txtCntrDuration.TabIndex = 137;
            this.txtCntrDuration.Leave += new System.EventHandler(this.txtCntrDuration_Leave);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(3, 4);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 16);
            this.label5.TabIndex = 32;
            this.label5.Text = "Contract Duration";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(92, 4);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(69, 16);
            this.label13.TabIndex = 41;
            this.label13.Text = "Maintenence Period";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(169, 4);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(146, 13);
            this.label14.TabIndex = 42;
            this.label14.Text = "Days Elapsed from Start Date";
            // 
            // txtMaintenencePeriod
            // 
            this.txtMaintenencePeriod.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaintenencePeriod.Location = new System.Drawing.Point(92, 23);
            this.txtMaintenencePeriod.Name = "txtMaintenencePeriod";
            this.txtMaintenencePeriod.Size = new System.Drawing.Size(71, 20);
            this.txtMaintenencePeriod.TabIndex = 138;
            this.txtMaintenencePeriod.Leave += new System.EventHandler(this.txtMaintenencePeriod_Leave);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(3, 57);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(80, 15);
            this.label8.TabIndex = 38;
            this.label8.Text = "Contracts Start Date";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(92, 57);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 15);
            this.label10.TabIndex = 36;
            this.label10.Text = "Original Finish Date";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(169, 57);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(102, 13);
            this.label7.TabIndex = 40;
            this.label7.Text = "Revised Finish Date";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // dtpCntrStartDate
            // 
            this.dtpCntrStartDate.Checked = false;
            this.dtpCntrStartDate.CustomFormat = " ";
            this.dtpCntrStartDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpCntrStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpCntrStartDate.Location = new System.Drawing.Point(3, 75);
            this.dtpCntrStartDate.Name = "dtpCntrStartDate";
            this.dtpCntrStartDate.Size = new System.Drawing.Size(83, 20);
            this.dtpCntrStartDate.TabIndex = 37;
            this.dtpCntrStartDate.ValueChanged += new System.EventHandler(this.dtpStartDate_ValueChanged);
            this.dtpCntrStartDate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dtpStartDate_KeyDown);
            this.dtpCntrStartDate.Leave += new System.EventHandler(this.dtpStartDate_Leave);
            // 
            // dtpEndDate
            // 
            this.dtpEndDate.Checked = false;
            this.dtpEndDate.CustomFormat = " ";
            this.dtpEndDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpEndDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpEndDate.Location = new System.Drawing.Point(92, 75);
            this.dtpEndDate.Name = "dtpEndDate";
            this.dtpEndDate.Size = new System.Drawing.Size(71, 20);
            this.dtpEndDate.TabIndex = 35;
            this.dtpEndDate.ValueChanged += new System.EventHandler(this.dtpEndDate_ValueChanged);
            this.dtpEndDate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dtpEndDate_KeyDown);
            this.dtpEndDate.Leave += new System.EventHandler(this.dtpEndDate_Leave);
            // 
            // dtpRevisedDate
            // 
            this.dtpRevisedDate.Checked = false;
            this.dtpRevisedDate.CustomFormat = " ";
            this.dtpRevisedDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpRevisedDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpRevisedDate.Location = new System.Drawing.Point(169, 75);
            this.dtpRevisedDate.Name = "dtpRevisedDate";
            this.dtpRevisedDate.Size = new System.Drawing.Size(121, 20);
            this.dtpRevisedDate.TabIndex = 39;
            this.dtpRevisedDate.ValueChanged += new System.EventHandler(this.dtpRevisedDate_ValueChanged);
            this.dtpRevisedDate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dtpRevisedDate_KeyDown);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(3, 108);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 13);
            this.label6.TabIndex = 34;
            this.label6.Text = "Perfomence Bond Expiry Date";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(92, 108);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 13);
            this.label4.TabIndex = 30;
            this.label4.Text = "PB First Extension";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(169, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "PB Last Extension";
            // 
            // dtpPB_Ext2
            // 
            this.dtpPB_Ext2.Checked = false;
            this.dtpPB_Ext2.CustomFormat = " ";
            this.dtpPB_Ext2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpPB_Ext2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpPB_Ext2.Location = new System.Drawing.Point(169, 124);
            this.dtpPB_Ext2.Name = "dtpPB_Ext2";
            this.dtpPB_Ext2.Size = new System.Drawing.Size(121, 20);
            this.dtpPB_Ext2.TabIndex = 3;
            this.dtpPB_Ext2.ValueChanged += new System.EventHandler(this.dtpPB_Ext2_ValueChanged);
            this.dtpPB_Ext2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dtpPB_Ext2_KeyDown);
            this.dtpPB_Ext2.Leave += new System.EventHandler(this.dtpPB_Ext2_Leave);
            // 
            // dtpPB_Ext1
            // 
            this.dtpPB_Ext1.Checked = false;
            this.dtpPB_Ext1.CustomFormat = "   ";
            this.dtpPB_Ext1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpPB_Ext1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpPB_Ext1.Location = new System.Drawing.Point(92, 124);
            this.dtpPB_Ext1.Name = "dtpPB_Ext1";
            this.dtpPB_Ext1.Size = new System.Drawing.Size(71, 20);
            this.dtpPB_Ext1.TabIndex = 29;
            this.dtpPB_Ext1.ValueChanged += new System.EventHandler(this.dtpPB_Ext1_ValueChanged);
            this.dtpPB_Ext1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dtpPB_Ext1_KeyDown);
            this.dtpPB_Ext1.Leave += new System.EventHandler(this.dtpPB_Ext1_Leave);
            // 
            // dtpPerfomenseDate
            // 
            this.dtpPerfomenseDate.Checked = false;
            this.dtpPerfomenseDate.CustomFormat = " ";
            this.dtpPerfomenseDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpPerfomenseDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpPerfomenseDate.Location = new System.Drawing.Point(3, 124);
            this.dtpPerfomenseDate.Name = "dtpPerfomenseDate";
            this.dtpPerfomenseDate.Size = new System.Drawing.Size(83, 20);
            this.dtpPerfomenseDate.TabIndex = 33;
            this.dtpPerfomenseDate.ValueChanged += new System.EventHandler(this.dtpPerfomenseDate_ValueChanged);
            this.dtpPerfomenseDate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dtpPerfomenseDate_KeyDown);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(322, 108);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(119, 13);
            this.label18.TabIndex = 139;
            this.label18.Text = "No of days PB to Expire";
            this.label18.Visible = false;
            // 
            // txtPBtoExpire
            // 
            this.txtPBtoExpire.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPBtoExpire.Location = new System.Drawing.Point(322, 124);
            this.txtPBtoExpire.Name = "txtPBtoExpire";
            this.txtPBtoExpire.Size = new System.Drawing.Size(120, 20);
            this.txtPBtoExpire.TabIndex = 140;
            this.txtPBtoExpire.Visible = false;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.69759F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 82.30241F));
            this.tableLayoutPanel1.Controls.Add(this.txtContractTitle, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(38, 29);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 74.63768F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(582, 90);
            this.tableLayoutPanel1.TabIndex = 135;
            // 
            // txtContractTitle
            // 
            this.txtContractTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContractTitle.Location = new System.Drawing.Point(105, 3);
            this.txtContractTitle.Multiline = true;
            this.txtContractTitle.Name = "txtContractTitle";
            this.txtContractTitle.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtContractTitle.Size = new System.Drawing.Size(474, 84);
            this.txtContractTitle.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Contract Title";
            // 
            // dgvCP_Sent
            // 
            this.dgvCP_Sent.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCP_Sent.BackgroundColor = System.Drawing.Color.White;
            this.dgvCP_Sent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCP_Sent.Location = new System.Drawing.Point(413, 620);
            this.dgvCP_Sent.Name = "dgvCP_Sent";
            this.dgvCP_Sent.RowHeadersVisible = false;
            this.dgvCP_Sent.Size = new System.Drawing.Size(369, 119);
            this.dgvCP_Sent.TabIndex = 134;
            this.dgvCP_Sent.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCP_Sent_CellClick);
            // 
            // dgvCP_Rec
            // 
            this.dgvCP_Rec.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCP_Rec.BackgroundColor = System.Drawing.Color.White;
            this.dgvCP_Rec.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCP_Rec.Location = new System.Drawing.Point(38, 620);
            this.dgvCP_Rec.Name = "dgvCP_Rec";
            this.dgvCP_Rec.RowHeadersVisible = false;
            this.dgvCP_Rec.Size = new System.Drawing.Size(369, 119);
            this.dgvCP_Rec.TabIndex = 133;
            this.dgvCP_Rec.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCP_Rec_CellClick);
            // 
            // btnSentDoc
            // 
            this.btnSentDoc.BackColor = System.Drawing.Color.Maroon;
            this.btnSentDoc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSentDoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSentDoc.ForeColor = System.Drawing.Color.White;
            this.btnSentDoc.Location = new System.Drawing.Point(413, 591);
            this.btnSentDoc.Name = "btnSentDoc";
            this.btnSentDoc.Size = new System.Drawing.Size(119, 23);
            this.btnSentDoc.TabIndex = 132;
            this.btnSentDoc.Text = "Sent Document";
            this.btnSentDoc.UseVisualStyleBackColor = false;
            this.btnSentDoc.Click += new System.EventHandler(this.btnSentDoc_Click);
            // 
            // btnReceiveDoc
            // 
            this.btnReceiveDoc.BackColor = System.Drawing.Color.Maroon;
            this.btnReceiveDoc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReceiveDoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReceiveDoc.ForeColor = System.Drawing.Color.White;
            this.btnReceiveDoc.Location = new System.Drawing.Point(38, 591);
            this.btnReceiveDoc.Name = "btnReceiveDoc";
            this.btnReceiveDoc.Size = new System.Drawing.Size(119, 23);
            this.btnReceiveDoc.TabIndex = 131;
            this.btnReceiveDoc.Text = "Recieved Document";
            this.btnReceiveDoc.UseVisualStyleBackColor = false;
            this.btnReceiveDoc.Click += new System.EventHandler(this.btnReceiveDoc_Click);
            // 
            // cmbCompany
            // 
            this.cmbCompany.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCompany.FormattingEnabled = true;
            this.cmbCompany.Location = new System.Drawing.Point(143, 160);
            this.cmbCompany.Name = "cmbCompany";
            this.cmbCompany.Size = new System.Drawing.Size(199, 21);
            this.cmbCompany.TabIndex = 41;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(41, 164);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(96, 13);
            this.label11.TabIndex = 42;
            this.label11.Text = "Company / Vendor";
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.Maroon;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Location = new System.Drawing.Point(38, 505);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(60, 26);
            this.btnSave.TabIndex = 13;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.Maroon;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.ForeColor = System.Drawing.Color.White;
            this.btnCancel.Location = new System.Drawing.Point(99, 505);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(60, 26);
            this.btnCancel.TabIndex = 14;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            // 
            // txtPCRemarks
            // 
            this.txtPCRemarks.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPCRemarks.Location = new System.Drawing.Point(38, 422);
            this.txtPCRemarks.Multiline = true;
            this.txtPCRemarks.Name = "txtPCRemarks";
            this.txtPCRemarks.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtPCRemarks.Size = new System.Drawing.Size(582, 77);
            this.txtPCRemarks.TabIndex = 12;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(38, 406);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 13);
            this.label9.TabIndex = 18;
            this.label9.Text = "Remarks";
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Work Order No.";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 179;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Project Title";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 179;
            // 
            // frmContractsEntry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FloralWhite;
            this.ClientSize = new System.Drawing.Size(1040, 779);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmContractsEntry";
            this.Text = "Update Contracts Info Window";
            this.Load += new System.EventHandler(this.frmContractsEntry_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCP_Sent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCP_Rec)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtContractNo;
        private System.Windows.Forms.DateTimePicker dtpPB_Ext2;
        private System.Windows.Forms.TextBox txtContractTitle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TextBox txtPCRemarks;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dtpPerfomenseDate;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dtpPB_Ext1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbContractStatus;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbCompany;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker dtpRevisedDate;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker dtpCntrStartDate;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker dtpEndDate;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridView dgvCP_Sent;
        private System.Windows.Forms.DataGridView dgvCP_Rec;
        private System.Windows.Forms.Button btnSentDoc;
        private System.Windows.Forms.Button btnReceiveDoc;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TextBox txtDaysElapsed;
        private System.Windows.Forms.TextBox txtCntrDuration;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtMaintenencePeriod;
        private System.Windows.Forms.TextBox txtCmpType;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.TextBox txtOriginalCntrSum;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtPerfomenceBond;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtVariationOrder;
        private System.Windows.Forms.TextBox txtApprovedEOT;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtPBtoExpire;
        private System.Windows.Forms.TextBox txtAdjustedCntrSum;
        private System.Windows.Forms.TextBox txtNoOfClaims;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.Button btnAddSiteInstruction;
        private System.Windows.Forms.Button btnAddVariationOrder;
        private System.Windows.Forms.Button btnAddVarOrderDet;
        private System.Windows.Forms.Button button1;

    }
}