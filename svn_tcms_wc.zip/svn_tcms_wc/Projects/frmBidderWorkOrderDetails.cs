﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace MDI_ParenrForm.Projects
{
    public partial class frmBidderWorkOrderDetails : Form
    {
        string mWorkOrderBidderID = null;
        string mUserName = null;
        string mCoID = null;
        string mWorkOrderID = null;
        bool mIsHeadOfSection = false;
        int mPrjID = 0;
        bool isProgrammaticEvent = false;
        DataGridView mDgvAwardedBidders = null;
        public frmBidderWorkOrderDetails(string[] workOrderBidderID, string userName, int prjID, string workOrderID, bool isHeadOfSection, DataGridView dgvAwardedBidders)
        {
            InitializeComponent();
            mUserName = userName;
            mCoID = workOrderBidderID[0];
            cmpName.Text = workOrderBidderID[1];
            mPrjID = prjID;
            mWorkOrderID = workOrderID;
            mIsHeadOfSection = isHeadOfSection;
            mDgvAwardedBidders = dgvAwardedBidders;
            mWorkOrderBidderID = workOrderBidderID[4];
            if (mWorkOrderBidderID=="")
            {
                btnBidderWOUpdate.Text = "Save";
            }
            else
            {
                btnBidderWOUpdate.Text = "Update";
            } 
            if (workOrderBidderID[2] != "")
                txtWOAmount.Text = string.Format("{0:#,##0.00}", double.Parse(workOrderBidderID[2].ToString()));

            if (workOrderBidderID[3] != "")
                mskTxtRecOfAwardDoc.Text = Convert.ToDateTime(workOrderBidderID[3]).ToString("dd/MMM/yyyy");

            if (workOrderBidderID[5] != "")
                mskTxtReqDeptStartDate.Text = Convert.ToDateTime(workOrderBidderID[5]).ToString("dd/MMM/yyyy");
            if (workOrderBidderID[6] != "")
                mskTxtStartDateReceive.Text = Convert.ToDateTime(workOrderBidderID[6]).ToString("dd/MMM/yyyy");
            if (workOrderBidderID[7] != "")
                mskTxtNoticeSendSignContract.Text = Convert.ToDateTime(workOrderBidderID[7]).ToString("dd/MMM/yyyy");
            if (workOrderBidderID[8] != "")
                mskTxtDueDateOfSubPBSign.Text = Convert.ToDateTime(workOrderBidderID[8]).ToString("dd/MMM/yyyy");

            if (workOrderBidderID[9] != "")
                mskTxtSentDeptForSign.Text = Convert.ToDateTime(workOrderBidderID[9]).ToString("dd/MMM/yyyy");
            if (workOrderBidderID[10] != "")
                mskTxtRcvdDeptSentPRSDForSign.Text = Convert.ToDateTime(workOrderBidderID[10]).ToString("dd/MMM/yyyy");
            if (workOrderBidderID[11] != "")
                mskTxtSentFinanceDeptForCommittment.Text = Convert.ToDateTime(workOrderBidderID[11]).ToString("dd/MMM/yyyy");
            if (workOrderBidderID[12] != "")
                mskTxtRcvdFromFinanceDeptForCommittment.Text = Convert.ToDateTime(workOrderBidderID[12]).ToString("dd/MMM/yyyy");
            if (workOrderBidderID[13] != "")
                mskTxtDistribution.Text = Convert.ToDateTime(workOrderBidderID[13]).ToString("dd/MMM/yyyy");

            //if (workOrderBidderID[12] != "")
            //    txtWOTenderEstimate.Text = string.Format("{0:#,##0.00}", double.Parse(workOrderBidderID[12].ToString()));

            if (workOrderBidderID[14] != "")
                textRemarks.Text = workOrderBidderID[14].ToString().Replace("Char(13)", "\r").Replace("Char(10)", "\n");

            if (workOrderBidderID[15] != "")
                txtContractNo.Text = workOrderBidderID[15].ToString();
            if (workOrderBidderID[16] != "")
                mskTxtDateOfSignContract.Text = Convert.ToDateTime(workOrderBidderID[16]).ToString("dd/MMM/yyyy");
            //txtWOAmount.Text = 
        }
        

        private void dtpReqDeptStartDate_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                dtpReqDeptStartDate.CustomFormat = "dd/MMM/yyyy";
                if (mskTxtRecOfAwardDoc.Text.Trim() != "" && mskTxtReqDeptStartDate.Text.Trim() == "")
                {
                    dtpReqDeptStartDate.Value = Convert.ToDateTime(mskTxtRecOfAwardDoc.Text.ToString()).AddDays(1);
                }
                mskTxtReqDeptStartDate.Text = dtpReqDeptStartDate.Value.ToString("dd/MMM/yyyy");
                mskTxtReqDeptStartDate.Focus();
            }
            else
            {
                dtpStartDateReceive.Value = dtpReqDeptStartDate.Value.AddDays(1);                
            }
        }

        // Added by Varun on 21 May 2014 for checking the duplicate ContractNo.
        public bool ValidateContractNo(string contractNo)
        {
            using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
            {
                sqlConn.Open();
                string sqlQuery = null;
                //if (contractorID != "")
                //    sqlQuery = "select contract_no from [CONTRACTORS] where contract_no = @cntrNo and bidder_id<>" + contractorID;
                //else
                sqlQuery = "select contract_no from [CONTRACTORS] where contract_no = @cntrNo";
                SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
                contractNo = contractNo.Replace(" ", "").Replace("-", "/");
                while (Regex.Match(contractNo, "/0").Success)
                    contractNo = contractNo.Replace("/0", "/");
                sqlCom.Parameters.AddWithValue("@cntrNo", contractNo.ToUpper());
                txtContractNo.Text = contractNo;
                SqlDataReader sqlDtReader = sqlCom.ExecuteReader();
                if (sqlDtReader.HasRows)
                {
                    if (sqlDtReader.Read())
                    {
                        MessageBox.Show("Entered Contract Number already assigned to some other Contractor, Please enter a unique Contract Number", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return false;
                    }
                }
                else
                    //txtContractNo.Text = contractNo.ToUpper();
                    sqlDtReader.Close();
                sqlCom = null;
                sqlConn.Close();
            }
            return true;
        }

        private void txtContractNo_Leave(object sender, EventArgs e)
        {
            if (txtContractNo.Text.Trim() != "")
            {
                if (ValidateContractNo(txtContractNo.Text) == false)
                    txtContractNo.Focus();
            }
        }

        private void dtpStartDateReceive_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                dtpStartDateReceive.CustomFormat = "dd/MMM/yyyy";
                if (mskTxtReqDeptStartDate.Text.Trim() != "" && mskTxtStartDateReceive.Text.Trim() == "")
                {
                    dtpStartDateReceive.Value = Convert.ToDateTime(mskTxtReqDeptStartDate.Text.ToString()).AddDays(1);

                }
                mskTxtStartDateReceive.Text = dtpStartDateReceive.Value.ToString("dd/MMM/yyyy");
                mskTxtStartDateReceive.Focus();
            }
            else
            {
                dtpNoticeSendSignContract.Value = dtpStartDateReceive.Value.AddDays(1);
            }
        }

        private void dtpNoticeSendSignContract_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                dtpNoticeSendSignContract.CustomFormat = "dd/MMM/yyyy";
                if (mskTxtStartDateReceive.Text.Trim() != "" && mskTxtNoticeSendSignContract.Text.Trim() == "")
                {
                    dtpNoticeSendSignContract.Value = Convert.ToDateTime(mskTxtStartDateReceive.Text.ToString()).AddDays(1);
                }
                mskTxtNoticeSendSignContract.Text = dtpNoticeSendSignContract.Value.ToString("dd/MMM/yyyy");
                mskTxtNoticeSendSignContract.Focus();
            }
            else
            {
                dtpDueDateOfSubPBSign.Value = dtpNoticeSendSignContract.Value.AddDays(1);
            }

        }

        private void dtpDueDateOfSubPBSign_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                dtpDueDateOfSubPBSign.CustomFormat = "dd/MMM/yyyy";
                if (mskTxtNoticeSendSignContract.Text.Trim() != "" && mskTxtDueDateOfSubPBSign.Text.Trim() == "")
                {
                    dtpDueDateOfSubPBSign.Value = Convert.ToDateTime(mskTxtNoticeSendSignContract.Text.ToString()).AddDays(1);
                }
                mskTxtDueDateOfSubPBSign.Text = dtpDueDateOfSubPBSign.Value.ToString("dd/MMM/yyyy");
                mskTxtDueDateOfSubPBSign.Focus();
            }
            else
            {
                dtpDateOfSignContract.Value = dtpDueDateOfSubPBSign.Value.AddDays(1);
            }

        }

        private void dtpDateOfSignContract_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                dtpDateOfSignContract.CustomFormat = "dd/MMM/yyyy";
                if (mskTxtDueDateOfSubPBSign.Text.Trim() != "" && mskTxtDateOfSignContract.Text.Trim() == "")
                {
                    dtpDateOfSignContract.Value = Convert.ToDateTime(mskTxtDueDateOfSubPBSign.Text.ToString()).AddDays(1);
                }
                mskTxtDateOfSignContract.Text = dtpDateOfSignContract.Value.ToString("dd/MMM/yyyy");
                mskTxtDateOfSignContract.Focus();
            }
            else
            {
                dtpSentDeptForSign.Value = dtpDateOfSignContract.Value.AddDays(1);
            }

        }

        private void dtpSentDeptForSign_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                dtpSentDeptForSign.CustomFormat = "dd/MMM/yyyy";
                if (mskTxtDateOfSignContract.Text.Trim() != "" && mskTxtSentDeptForSign.Text.Trim() == "")
                {
                    dtpSentDeptForSign.Value = Convert.ToDateTime(mskTxtDateOfSignContract.Text.ToString()).AddDays(1);
                }
                mskTxtSentDeptForSign.Text = dtpSentDeptForSign.Value.ToString("dd/MMM/yyyy");
                mskTxtSentDeptForSign.Focus();
            }
            else
            {
                dtpRcvdDeptSentPRSDForSign.Value = dtpSentDeptForSign.Value.AddDays(1);
            }

        }

        private void dtpRcvdDeptSentPRSDForSign_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                dtpRcvdDeptSentPRSDForSign.CustomFormat = "dd/MMM/yyyy";
                if (mskTxtSentDeptForSign.Text.Trim() != "" && mskTxtRcvdDeptSentPRSDForSign.Text.Trim() == "")
                {
                    dtpRcvdDeptSentPRSDForSign.Value = Convert.ToDateTime(mskTxtSentDeptForSign.Text.ToString()).AddDays(1);
                }
                mskTxtRcvdDeptSentPRSDForSign.Text = dtpRcvdDeptSentPRSDForSign.Value.ToString("dd/MMM/yyyy");
                mskTxtRcvdDeptSentPRSDForSign.Focus();
            }
            else
            {
                dtpSentFinanceDeptForCommittment.Value = dtpRcvdDeptSentPRSDForSign.Value.AddDays(1);
            }

        }

        private void dtpSentFinanceDeptForCommittment_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                dtpSentFinanceDeptForCommittment.CustomFormat = "dd/MMM/yyyy";
                if (mskTxtRcvdDeptSentPRSDForSign.Text.Trim() != "" && mskTxtSentFinanceDeptForCommittment.Text.Trim() == "")
                {
                    dtpSentFinanceDeptForCommittment.Value = Convert.ToDateTime(mskTxtRcvdDeptSentPRSDForSign.Text.ToString()).AddDays(1);
                }
                mskTxtSentFinanceDeptForCommittment.Text = dtpSentFinanceDeptForCommittment.Value.ToString("dd/MMM/yyyy");
                mskTxtSentFinanceDeptForCommittment.Focus();
            }
            else
            {
                dtpRcvdFromFinanceDeptForCommittment.Value = dtpSentFinanceDeptForCommittment.Value.AddDays(1);
            }
        }

        private void dtpRcvdFromFinanceDeptForCommittment_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                dtpRcvdFromFinanceDeptForCommittment.CustomFormat = "dd/MMM/yyyy";
                if (mskTxtSentFinanceDeptForCommittment.Text.Trim() != "" && mskTxtRcvdFromFinanceDeptForCommittment.Text.Trim() == "")
                {
                    dtpRcvdFromFinanceDeptForCommittment.Value = Convert.ToDateTime(mskTxtSentFinanceDeptForCommittment.Text.ToString()).AddDays(1);
                }
                mskTxtRcvdFromFinanceDeptForCommittment.Text = dtpRcvdFromFinanceDeptForCommittment.Value.ToString("dd/MMM/yyyy");
                mskTxtRcvdFromFinanceDeptForCommittment.Focus();                
            }
            else
            {
                dtpDistribution.Value = dtpRcvdFromFinanceDeptForCommittment.Value.AddDays(1);
            }
        }

        private void dtpDistribution_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                dtpDistribution.CustomFormat = "dd/MMM/yyyy";
                if (mskTxtRcvdFromFinanceDeptForCommittment.Text.Trim() != "" && mskTxtDistribution.Text.Trim() == "")
                {
                    dtpDistribution.Value = Convert.ToDateTime(mskTxtRcvdFromFinanceDeptForCommittment.Text.ToString()).AddDays(1);
                }
                mskTxtDistribution.Text = dtpDistribution.Value.ToString("dd/MMM/yyyy");
                mskTxtDistribution.Focus();
            }
            else
            {
                isProgrammaticEvent = false;
            }
        }

        private void btnBidderWOUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        if (sqlConn.State == ConnectionState.Closed)
                            sqlConn.Open();
                        cmd.Connection = sqlConn;
                        if (btnBidderWOUpdate.Text == "Update")
                        {
                            try
                            {
                                cmd.CommandText = @"Update [WorkOrderSuccessfulBidders] set update_date=@update_date,update_user=@update_user,co_id=@coId,proj_Id=@projId,woContractAmount=@woContractAmount,cp_received_of_doc=@cpReceivedofDoc," +
                                "cp_request_start_date=@cpRequestStartDate,cp_start_date_receive=@cpStartDateReceive,cp_notice_contractor_to_sign=@cpNoticeContractorToSign,cp_due_date_pb=@cpDueDatePb,cp_sent_dep_sign=@cpSentDepSign,cp_receive_dep_sent_prsd=@cpReceiveDepSentPrsd, " +
                                "cp_sent_fd_commit=@cpSentFdCommit,cp_receive_fd_commit=@cpReceiveFdCommit,cp_distribution=@cpDistribution,remarks=@remarks,contract_no=@contractNo,cp_contractor_sign=@cpContractorSign where workOrderBidderID=@workOrderBidderID";
                                cmd.Parameters.AddWithValue("@update_date", DateTime.Now.ToString());
                                cmd.Parameters.AddWithValue("@update_user", mUserName);  //ContractAmount
                                cmd.Parameters.AddWithValue("@coId", mCoID);
                                cmd.Parameters.AddWithValue("@projId", mPrjID);
                                if (txtWOAmount.Text.Trim() != "")
                                {
                                    cmd.Parameters.AddWithValue("@woContractAmount", txtWOAmount.Text.Trim().Replace(",",""));
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@woContractAmount", DBNull.Value);
                                }
                                if (mskTxtRecOfAwardDoc.Text.Trim() != "")
                                {
                                    cmd.Parameters.AddWithValue("@cpReceivedofDoc", Convert.ToDateTime(mskTxtRecOfAwardDoc.Text.Trim()).ToString("dd/MMM/yyyy"));
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@cpReceivedofDoc", DBNull.Value);
                                }
                                if (mskTxtReqDeptStartDate.Text.Trim() != "")
                                {
                                    cmd.Parameters.AddWithValue("@cpRequestStartDate", Convert.ToDateTime(mskTxtReqDeptStartDate.Text.Trim()).ToString("dd/MMM/yyyy"));
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@cpRequestStartDate", DBNull.Value);
                                }
                                if (mskTxtStartDateReceive.Text.Trim() != "")
                                {
                                    cmd.Parameters.AddWithValue("@cpStartDateReceive", Convert.ToDateTime(mskTxtStartDateReceive.Text.Trim()).ToString("dd/MMM/yyyy"));
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@cpStartDateReceive", DBNull.Value);
                                }
                                if (mskTxtNoticeSendSignContract.Text.Trim() != "")
                                {
                                    cmd.Parameters.AddWithValue("@cpNoticeContractorToSign", Convert.ToDateTime(mskTxtNoticeSendSignContract.Text.Trim()).ToString("dd/MMM/yyyy"));
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@cpNoticeContractorToSign", DBNull.Value);
                                }
                                if (mskTxtDueDateOfSubPBSign.Text.Trim() != "")
                                {
                                    cmd.Parameters.AddWithValue("@cpDueDatePb", Convert.ToDateTime(mskTxtDueDateOfSubPBSign.Text.Trim()).ToString("dd/MMM/yyyy"));
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@cpDueDatePb", DBNull.Value);
                                }
                                if (mskTxtSentDeptForSign.Text.Trim() != "")
                                {
                                    cmd.Parameters.AddWithValue("@cpSentDepSign", Convert.ToDateTime(mskTxtSentDeptForSign.Text.Trim()).ToString("dd/MMM/yyyy"));
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@cpSentDepSign", DBNull.Value);
                                }
                                if (mskTxtRcvdDeptSentPRSDForSign.Text.Trim() != "")
                                {
                                    cmd.Parameters.AddWithValue("@cpReceiveDepSentPrsd", Convert.ToDateTime(mskTxtRcvdDeptSentPRSDForSign.Text.Trim()).ToString("dd/MMM/yyyy"));
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@cpReceiveDepSentPrsd", DBNull.Value);
                                }
                                if (mskTxtSentFinanceDeptForCommittment.Text.Trim() != "")
                                {
                                    cmd.Parameters.AddWithValue("@cpSentFdCommit", Convert.ToDateTime(mskTxtSentFinanceDeptForCommittment.Text.Trim()).ToString("dd/MMM/yyyy"));
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@cpSentFdCommit", DBNull.Value);
                                }
                                if (mskTxtRcvdFromFinanceDeptForCommittment.Text.Trim() != "")
                                {
                                    cmd.Parameters.AddWithValue("@cpReceiveFdCommit", Convert.ToDateTime(mskTxtRcvdFromFinanceDeptForCommittment.Text.Trim()).ToString("dd/MMM/yyyy"));
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@cpReceiveFdCommit", DBNull.Value);
                                }
                                if (mskTxtDistribution.Text.Trim() != "")
                                {
                                    cmd.Parameters.AddWithValue("@cpDistribution", Convert.ToDateTime(mskTxtDistribution.Text.Trim()).ToString("dd/MMM/yyyy"));
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@cpDistribution", DBNull.Value);
                                }
                                if (textRemarks.Text.Trim() != "")
                                {
                                    cmd.Parameters.AddWithValue("@remarks", textRemarks.Text.Trim());
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@remarks", DBNull.Value);
                                }
                                if (txtContractNo.Text.Trim() != "")
                                {
                                    cmd.Parameters.AddWithValue("@contractNo", txtContractNo.Text.Trim());
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@contractNo", DBNull.Value);
                                }
                                if (mskTxtDateOfSignContract.Text.Trim() != "")
                                {
                                    cmd.Parameters.AddWithValue("@cpContractorSign", Convert.ToDateTime(mskTxtDateOfSignContract.Text.Trim()).ToString("dd/MMM/yyyy"));
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@cpContractorSign", DBNull.Value);
                                }

                                cmd.Parameters.AddWithValue("@workOrderBidderID",mWorkOrderBidderID);
                                int updated = cmd.ExecuteNonQuery();
                                cmd.Parameters.Clear();
                                MessageBox.Show("Successfully updated successful bidder information.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Error occurred while Updating the Successful Bidder information.", ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                        else
                        {
                            try
                            {
                                cmd.CommandText = @"insert into [WorkOrderSuccessfulBidders] (update_date,update_user,co_id,proj_Id,woContractAmount,cp_received_of_doc,cp_request_start_date,cp_start_date_receive,cp_notice_contractor_to_sign,cp_due_date_pb," +
                                "cp_sent_dep_sign,cp_receive_dep_sent_prsd,cp_sent_fd_commit,cp_receive_fd_commit,cp_distribution,remarks,contract_no,cp_contractor_sign,workOrderID) " +
                                " values(@update_date,@update_user,@coId,@projId,@woContractAmount,@cpReceivedofDoc,@cpRequestStartDate,@cpStartDateReceive,@cpNoticeContractorToSign,@cpDueDatePb,@cpSentDepSign,@cpReceiveDepSentPrsd,@cpSentFdCommit," +
                                "@cpReceiveFdCommit,@cpDistribution,@remarks,@contractNo,@cpContractorSign,@workOrderID)";
                                cmd.Parameters.AddWithValue("@update_date", DateTime.Now.ToString());
                                cmd.Parameters.AddWithValue("@update_user", mUserName);  //ContractAmount
                                cmd.Parameters.AddWithValue("@coId", mCoID);
                                cmd.Parameters.AddWithValue("@projId", mPrjID);
                                if (txtWOAmount.Text.Trim() != "")
                                {
                                    cmd.Parameters.AddWithValue("@woContractAmount", txtWOAmount.Text.Trim().Replace(",",""));
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@woContractAmount", DBNull.Value);
                                }
                                if (mskTxtRecOfAwardDoc.Text.Trim() != "")
                                {
                                    cmd.Parameters.AddWithValue("@cpReceivedofDoc", Convert.ToDateTime(mskTxtRecOfAwardDoc.Text.Trim()).ToString("dd/MMM/yyyy"));
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@cpReceivedofDoc", DBNull.Value);
                                }
                                if (mskTxtReqDeptStartDate.Text.Trim() != "")
                                {
                                    cmd.Parameters.AddWithValue("@cpRequestStartDate", Convert.ToDateTime(mskTxtReqDeptStartDate.Text.Trim()).ToString("dd/MMM/yyyy"));
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@cpRequestStartDate", DBNull.Value);
                                }
                                if (mskTxtStartDateReceive.Text.Trim() != "")
                                {
                                    cmd.Parameters.AddWithValue("@cpStartDateReceive", Convert.ToDateTime(mskTxtStartDateReceive.Text.Trim()).ToString("dd/MMM/yyyy"));
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@cpStartDateReceive", DBNull.Value);
                                }
                                if (mskTxtNoticeSendSignContract.Text.Trim() != "")
                                {
                                    cmd.Parameters.AddWithValue("@cpNoticeContractorToSign", Convert.ToDateTime(mskTxtNoticeSendSignContract.Text.Trim()).ToString("dd/MMM/yyyy"));
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@cpNoticeContractorToSign", DBNull.Value);
                                }
                                if (mskTxtDueDateOfSubPBSign.Text.Trim() != "")
                                {
                                    cmd.Parameters.AddWithValue("@cpDueDatePb", Convert.ToDateTime(mskTxtDueDateOfSubPBSign.Text.Trim()).ToString("dd/MMM/yyyy"));
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@cpDueDatePb", DBNull.Value);
                                }
                                if (mskTxtSentDeptForSign.Text.Trim() != "")
                                {
                                    cmd.Parameters.AddWithValue("@cpSentDepSign", Convert.ToDateTime(mskTxtSentDeptForSign.Text.Trim()).ToString("dd/MMM/yyyy"));
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@cpSentDepSign", DBNull.Value);
                                }
                                if (mskTxtRcvdDeptSentPRSDForSign.Text.Trim() != "")
                                {
                                    cmd.Parameters.AddWithValue("@cpReceiveDepSentPrsd", Convert.ToDateTime(mskTxtRcvdDeptSentPRSDForSign.Text.Trim()).ToString("dd/MMM/yyyy"));
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@cpReceiveDepSentPrsd", DBNull.Value);
                                }
                                if (mskTxtSentFinanceDeptForCommittment.Text.Trim() != "")
                                {
                                    cmd.Parameters.AddWithValue("@cpSentFdCommit", Convert.ToDateTime(mskTxtSentFinanceDeptForCommittment.Text.Trim()).ToString("dd/MMM/yyyy"));
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@cpSentFdCommit", DBNull.Value);
                                }
                                if (mskTxtRcvdFromFinanceDeptForCommittment.Text.Trim() != "")
                                {
                                    cmd.Parameters.AddWithValue("@cpReceiveFdCommit", Convert.ToDateTime(mskTxtRcvdFromFinanceDeptForCommittment.Text.Trim()).ToString("dd/MMM/yyyy"));
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@cpReceiveFdCommit", DBNull.Value);
                                }
                                if (mskTxtDistribution.Text.Trim() != "")
                                {
                                    cmd.Parameters.AddWithValue("@cpDistribution", Convert.ToDateTime(mskTxtDistribution.Text.Trim()).ToString("dd/MMM/yyyy"));
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@cpDistribution", DBNull.Value);
                                }
                                if (textRemarks.Text.Trim() != "")
                                {
                                    cmd.Parameters.AddWithValue("@remarks", textRemarks.Text.Trim());
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@remarks", DBNull.Value);
                                }
                                if (txtContractNo.Text.Trim() != "")
                                {
                                    cmd.Parameters.AddWithValue("@contractNo", txtContractNo.Text.Trim());
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@contractNo", DBNull.Value);
                                }
                                if (mskTxtDateOfSignContract.Text.Trim() != "")
                                {
                                    cmd.Parameters.AddWithValue("@cpContractorSign", Convert.ToDateTime(mskTxtDateOfSignContract.Text.Trim()).ToString("dd/MMM/yyyy"));
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@cpContractorSign", DBNull.Value);
                                }

                                cmd.Parameters.AddWithValue("@workOrderID", mWorkOrderID);
                                int inserted = cmd.ExecuteNonQuery();
                                cmd.Parameters.Clear();
                                MessageBox.Show("Successfully inserted Successful bidder information.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Error occurred while inserting the Successful Bidder record.", ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }
                }

                //dgvAwardedBidders.Columns.Clear();
                ////if (dgvCntrStage3.Columns.Count == 0)
                clsCP_Stage clsForCP = new clsCP_Stage(mUserName, mIsHeadOfSection);
                //clsForCP.CreateColumnsForWOContracors(dgvAwardedBidders, prjId);
                ////clsForCP.CreateColumnsForCP_Contracors(dgvContractsTemp, _projID);
                ////FillCP_ContractsData();
                clsForCP.FillWOBiddersGrid(mDgvAwardedBidders, mPrjID, mWorkOrderID);   
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while connecting to the database.", ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }              
           
        }        

        private void dtpRecOfAwardDoc_ValueChanged(object sender, EventArgs e)
        {
            dtpRecOfAwardDoc.CustomFormat = "dd/MMM/yyyy";
            mskTxtRecOfAwardDoc.Text = dtpRecOfAwardDoc.Value.ToString("dd/MMM/yyyy");
            mskTxtRecOfAwardDoc.Focus();
        }

        private void txtWOAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }

        private bool nonNumberEntered = false;
        private void ValidateNumericAndDecimalInput(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != 8 && e.KeyChar != 13) //&& e.KeyChar.ToString().Contains('.').ToString().Length>=2
            {
                nonNumberEntered = true;
            }
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                nonNumberEntered = true;
                e.Handled = true;
            }

            if (nonNumberEntered == true)
            {
                MessageBox.Show("Please enter number only...");
                e.Handled = true;
            }
            nonNumberEntered = false;
        }

        private void txtWOAmount_Leave(object sender, EventArgs e)
        {
            if (txtWOAmount.Text.Trim() != "")
                txtWOAmount.Text = string.Format("{0:#,##0.00}", double.Parse(txtWOAmount.Text));
        }

        private void close_Click(object sender, EventArgs e)
        {
            this.Close();   
        }

       
    }
}
