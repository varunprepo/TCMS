﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Transactions;
using TenderTrackingSystem;
using System.Globalization;
using System.Net.Mail;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;

namespace MDI_ParenrForm.Projects
{
    public partial class frmProjectInfo : Form
    {
        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();
        
        // Protected Connection.
        protected SqlConnection sqlConn;
        protected SqlCommand sqlCom;                  

        protected SqlDataReader sqlReader;

        IList<string> userRightsColl = new List<string>();
        string _userName = string.Empty;
        bool _isHeadOfSection = false;

        public frmProjectInfo(IList<string> userRightsCollTemp, string user,bool isHeadOfSection)
        {
            InitializeComponent();
            userRightsColl = userRightsCollTemp; 
            _userName = user;
            _isHeadOfSection = isHeadOfSection;
        }
        private void tabPage1_Click(object sender, EventArgs e)
        {

        }
        private void btnCheckMoazhID_Click(object sender, EventArgs e)
        {
           // FillCombo();
        }
        private void MohzanahProjectInformation()
        {           
        }
        private Boolean ValidateMoazanahData()
        {
            bool chkMoaznahData = true;
            if (txtProjCode.Text == "")
            {
                chkMoaznahData = false;
                MessageBox.Show("Please Enter Project Code");
                txtProjCode.Focus();
                return chkMoaznahData;
            }       
            else
            {
                mohProjCode = txtProjCode.Text.Trim();
            }
            
            if (cmbMohAffairs.SelectedIndex == -1)
            {
                chkMoaznahData = false;
                MessageBox.Show("Please Select Affaires Code");
                cmbMohAffairs.Focus();
                return chkMoaznahData;;
            }
            else
            {
                mohAffairsId = cmbMohAffairs.SelectedValue.ToString();
            }
            if (cmbMohUserDept.SelectedIndex == -1)
            {
                chkMoaznahData = false;
                MessageBox.Show("Please Select User Department");
                cmbMohUserDept.Focus();
                return chkMoaznahData; ;
            }
            else
            {
                mohUserDeptId = cmbMohUserDept.SelectedValue.ToString();
            }

            if (txtProjTitleEn.Text == "")
            {
                chkMoaznahData = false;
                MessageBox.Show("Please Enter Project Title in English");
                txtProjTitleEn.Focus();
                return chkMoaznahData; ;
            }
            else
            {
                mohProjTitleEn = txtProjTitleEn.Text;
            }

            if (cmbMohTenderCommittee.SelectedIndex == -1)
            {
                chkMoaznahData = false;
                MessageBox.Show("Please Select Tender Committe");
                cmbMohTenderCommittee.Focus();
                 return chkMoaznahData;;
            }
            else
            {
                mohTenderCommitteeId = cmbMohTenderCommittee.SelectedValue.ToString();
            }

            if (cboMohTOTender.SelectedIndex == -1)
            {
                chkMoaznahData = false;
                MessageBox.Show("Please Select Tender Type");
                cboMohTOTender.Focus();
                return chkMoaznahData;;
            }
            else
            {
                mohTypeOfTenderId = cboMohTOTender.SelectedValue.ToString();
            }
            if (cmbMohTypeContract.SelectedIndex == -1)
            {
                chkMoaznahData = false;
                MessageBox.Show("Please Select Type Of Contract");
                cmbMohTypeContract.Focus();
                return chkMoaznahData; ;
            }
            else
            {
                mohTypeOfContractId = cmbMohTypeContract.SelectedValue.ToString();
            }

            if (cmbFiscalYear.SelectedIndex == -1)
            {
                chkMoaznahData = false;
                MessageBox.Show("Please Select Fiscal Year");
                cmbFiscalYear.Focus();
                return chkMoaznahData; ;
            }
            else
            {
                mohFiscalYrId = cmbFiscalYear.SelectedValue.ToString();
            }
            //if (cmbMozMinistryCode.SelectedIndex == -1)
            //{
            //    chkMoaznahData = false;
            //    MessageBox.Show("Please Select Ministry Code");
            //    cmbMozMinistryCode.Focus();
            //    return chkMoaznahData; ;
            //}
            //if (cmbMozBudjetRefNo.SelectedIndex == -1)
            //{
            //    chkMoaznahData = false;
            //    MessageBox.Show("Please Select Budget Reference No");
            //    cmbMozBudjetRefNo.Focus();
            //    return chkMoaznahData; ;
            //}            
            return chkMoaznahData;
        }
        private void GetMaxCustomID()
        {
            int _costID = 0;
            try
            {
                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                sqlCom = new SqlCommand("Select MAX(cost_item_id) from ProjectCost", sqlConn);
                _costID = Convert.ToInt16(sqlCom.ExecuteScalar());
                _costID = _costID + 1;
                sqlConn.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void InsertMoazanahData()
        {
            int _prjID = 0;

            //if (ValidateMoazanahData() == false)
            //{
            //    return;
            //}
             
            //bool isValidated = ValidateProjectCode(txtProjCode);
            //if (isValidated == true)
            //    txtProjCode.Enabled = false;            

            try
            {
                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                sqlCom = new SqlCommand("select MAX(proj_id) from Projects", sqlConn);
                _prjID = Convert.ToInt16(sqlCom.ExecuteScalar());
                _prjID = _prjID + 1;
                sqlConn.Close();
                //}
                //catch (Exception ex)
                //{
                //    throw ex;
                //}
                int _costID = 0;
                //try
                //{
                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                sqlCom = new SqlCommand("select MAX(cost_item_id) + 1 from Projectcost", sqlConn);
                _costID = Convert.ToInt16(sqlCom.ExecuteScalar());
                sqlConn.Close();
                //}
                //catch (Exception ex)
                //{
                //    throw ex;
                //}
                using (TransactionScope scope = new TransactionScope())
                {
                    using (SqlConnection sqlInnerConn = new SqlConnection(strCon))
                    {
                        sqlInnerConn.Open();
                        string insertQuery = "INSERT INTO PROJECTS(proj_id,project_code, project_newname_en,committee_id, " +
                        " FYID, Affair_id, department_id, contract_type_id, tender_type_id, project_name_en,project_name_ar,stage_id,SelectPrj,Tender_Status_id,[Ministry_Code],[Budget_Reference_No],[Provision_Number],moazanah_proj_id_new,dummyfield,Create_Date,Create_User,isDeleted) " +
                        " VALUES(@prjID,@PrjCode,@PrjTitleEnNew,@CmtId,@FiscalID,@AffairID,@UserDept,@TypeOfPrj,@TypeOfTndr,@PrjTitleEn, @PrjTitleArb,@StatusID,@SelPrj,@TndrStatusId,@MinistryCode,@BudgetRefNo,@ProvisionNo,@moazPrjID,@dumfield,@CreateDate,@CreateUser,@isDeleted)";

                        using (SqlCommand cmd = new SqlCommand(insertQuery, sqlInnerConn))
                        {
                            cmd.Parameters.AddWithValue("@prjID", Convert.ToInt16(_prjID));
                            cmd.Parameters.AddWithValue("@PrjCode", mohProjCode);
                            cmd.Parameters.AddWithValue("@PrjTitleEnNew", mohProjTitleEn);
                            cmd.Parameters.AddWithValue("@CmtId", mohTenderCommitteeId);

                            // Added by Varun on 29-Jun-2015
                            //if (Convert.ToInt16(((DataRowView)cmbFiscalYear.SelectedItem).Row.ItemArray[1].ToString().Split('-')[0]) < DateTime.Today.Subtract(TimeSpan.FromDays(365)).Year)
                            //{
                            //    DataTable dtFyID = null;
                            //    DAL dalObj = new DAL();                             
                            //    dtFyID = dalObj.GetDataFromDB("FiscalID", "select FYID from FiscalYear where FiscalYear like '%" + DateTime.Today.Subtract(TimeSpan.FromDays(365)).Year + "-%'");
                            //    cmd.Parameters.AddWithValue("@FiscalID", Convert.ToInt16(dtFyID.Rows[0][0]));
                            //}
                            //else
                            cmd.Parameters.AddWithValue("@FiscalID", mohFiscalYrId);
                            cmd.Parameters.AddWithValue("@AffairID", mohAffairsId);
                            cmd.Parameters.AddWithValue("@UserDept", mohUserDeptId);
                            cmd.Parameters.AddWithValue("@TypeOfPrj", mohTypeOfContractId);
                            cmd.Parameters.AddWithValue("@TypeOfTndr", mohTypeOfTenderId);
                            cmd.Parameters.AddWithValue("@PrjTitleEn", mohProjTitleEn);
                            cmd.Parameters.AddWithValue("@PrjTitleArb", mohProjTitleAr);
                            cmd.Parameters.AddWithValue("@StatusID", 1);
                            cmd.Parameters.AddWithValue("@SelPrj", 1);
                            cmd.Parameters.AddWithValue("@TndrStatusId", 1);

                            cmd.Parameters.AddWithValue("@MinistryCode", mohMinistryCode);
                            cmd.Parameters.AddWithValue("@BudgetRefNo", mohBudjetRef);

                            if (mohProvisionNo != "")
                                cmd.Parameters.AddWithValue("@ProvisionNo", mohProvisionNo);
                            else
                                cmd.Parameters.AddWithValue("@ProvisionNo", DBNull.Value);

                            cmd.Parameters.AddWithValue("@moazPrjID", mohProjId);
                            cmd.Parameters.AddWithValue("@dumfield", System.DateTime.Now);

                            cmd.Parameters.AddWithValue("@CreateDate", System.DateTime.Now);
                            cmd.Parameters.AddWithValue("@CreateUser", _userName);
                            cmd.Parameters.AddWithValue("@isDeleted", 0);

                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }

                        // string insertQueryBdgt = "INSERT INTO ProjectCost(cost_item_id,stage_id, proj_id, budgeted_cost,create_date,create_user) VALUES(@costID,@stgID,@PrjID,@budgetAmnt,@createDate,@createUser)";
                        string insertQueryBdgt = "INSERT INTO ProjectCost(stage_id, proj_id, budgeted_cost,create_date,create_user) VALUES(@stgID,@PrjID,@budgetAmnt,@createDate,@createUser)";
                        using (SqlCommand cmd = new SqlCommand(insertQueryBdgt, sqlInnerConn))
                        {
                            //cmd.Parameters.AddWithValue("@costID", Convert.ToInt16(_costID));
                            cmd.Parameters.AddWithValue("@stgID", 4);
                            cmd.Parameters.AddWithValue("@PrjID", Convert.ToInt16(_prjID));
                            if (mohBudgetAmt != "")
                            {
                                if (mohBudgetAmt.Contains("QAR"))
                                {

                                    // txtMozBudjet.Text = txtMozBudjet.Text.Substring(0, txtMozBudjet.Text.Length);
                                    cmd.Parameters.AddWithValue("@budgetAmnt", Convert.ToDouble(mohBudgetAmt.Substring(3, mohBudgetAmt.Length - 3)));
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@budgetAmnt", Convert.ToDouble(mohBudgetAmt));
                                }
                            }
                            else
                            {
                                cmd.Parameters.AddWithValue("@budgetAmnt", DBNull.Value);
                            }

                            cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                            cmd.Parameters.AddWithValue("@createUser", "FROM MOAZANAH");

                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                        sqlInnerConn.Close();
                    }
                    scope.Complete();
                    MessageBox.Show(projType + " Project Added Successfully ", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    //this.Close();

                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error while inserting the project details, Try again", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);                
                projType = "Error";
            }
            
            if (projType != "Error")
            {                 
                SendEmailsToEBSD(mohProjCode, mohBudjetRef);
            }
                        
        }

        private void SendEmailsToEBSD(string projCode, string budgetRefCode)
        {
            //IList<string> userListColl = new List<string>();
            //StringBuilder emailIds = new StringBuilder();
            //string [] emails = ConfigurationManager.AppSettings["EBSDStaffEmails"].ToString().Split(',');

            //for (int i = 0; i < emails.Length; i++)
            //{
            //    emailIds.Append(emails[i] + ";");
            //    //userListColl.Add(emails[i]+";"); 
            //}

            //string emails1 = string.Join(",", emails);
            try
            {                 
                //foreach (string strname in userListColl)
                //{                   

                    MailMessage mailMessage = new MailMessage();

                    mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["From"].ToString());
                    //mailMessage.To.Add(ConfigurationManager.AppSettings["EBSDStaffEmails"].ToString());
                    foreach (var address in ConfigurationManager.AppSettings["EBSDStaffEmails"].ToString().Split(','))
                    {
                        mailMessage.To.Add(new MailAddress(address.Trim(), ""));
                    }
                    mailMessage.Subject = "TCMS Alert: New Project with project code " + projCode + " has been added";

                    mailMessage.IsBodyHtml = true;

                    string emailBodyText = null;
                 
                    emailBodyText = "<html><body><i style='font-family:Calibri; font-size:15'>Dear Sir/Madam,</i><br/><br/><i style='font-family:Calibri; font-size:15'>This is an automated alert from Tender & Contract Management System.</i><br/><br/><i style='font-family:Calibri;font-size:15'>";
                    if (budgetRefCode != "")
                    {
                        string twoChars = budgetRefCode.Substring(0, 2);
                        if (twoChars.Equals("14"))
                        {
                            emailBodyText = emailBodyText + "Please be noted that</i><i style='color:#1F4E79;font-family:Calibri; font-size:15'> New Project with project code " + projCode + ", Budget Reference No." + budgetRefCode + " and Chapter-4 has been added to TCMS</i>";
                        }
                        else if (twoChars.Equals("12") || twoChars.Equals("13"))
                        {
                            emailBodyText = emailBodyText + "Please be noted that</i><i style='color:#1F4E79;font-family:Calibri; font-size:15'> New Project with project code " + projCode + ", Budget Reference No." + budgetRefCode + " and Chapter-2,3 has been added to TCMS</i>";
                        }
                    }
                    else
                    {
                        emailBodyText = emailBodyText + "Please be noted that</i><i style='color:#1F4E79;font-family:Calibri; font-size:15'> New Project with project code " + projCode + " has been added to TCMS, without any Chapter information</i>";
                    }

                    emailBodyText = emailBodyText + "<br/><br/><div style='font-family:Calibri; font-size:15'>Best Regards,<br/>TCMS Team</div></body></html>";

                    mailMessage.Body = emailBodyText;
                    SmtpClient client = new SmtpClient();
                    client.EnableSsl = true;                    
                    client.Credentials = new System.Net.NetworkCredential(@"Ashghal\tcms", ConfigurationManager.AppSettings["emailPass"].ToString());
                    ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                    client.Host = ConfigurationManager.AppSettings["SmtpHostIP"].ToString();
                    client.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpHostPort"]);
                    client.Send(mailMessage);
                    //projType = "EmailsToEBSD";
                    //SendEmail myAction = new SendEmail(SendCompletedCallback);
                    //myAction.BeginInvoke(client, mailMessage, null, null);      
                    

                //}
              
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while sending the email notification to Engineering Services Department, Please inform them Personally", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        string projType = null;
        private void CheckSendEmailWorking(string[] projData)
        {             
            try
            {      

                UserAuthentication emailAddAuth = new UserAuthentication(projData, null, null, false, false, false);
                emailAddAuth.StartPosition = FormStartPosition.CenterParent;
                emailAddAuth.ShowDialog();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to create New " + projType + " Project, Error occurred while opening the UserAuthorization window", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                projType = "Error";                 
            }            
        }


        

        string nonMohProjCode = null;
        string nonMohProjTitleEn = null;
        string nonMohProjTitleAr = null;
        string nonMohTenderCommitteeId = null;
        string nonMohFiscalYrId = null;
        string nonMohAffairId = null;
        string nonMohUserDeptId = null;
        string nonMohTypeOfProject = null;
        string nonMohTypeOfTender = null;        
        string nonMohMinistryCode = null;
        string nonMohBudjetRef = null;
        string nonMohProvisionNo = null;
        double nonMohBudgetAmt = 0;

        string mohProjId = null;
        string mohProjCode = null;
        string mohProjTitleEn = null;
        string mohProjTitleAr = null;
        string mohTenderCommitteeId = null;
        string mohFiscalYrId = null;
        string mohAffairsId = null;
        string mohUserDeptId = null;
        string mohTypeOfContractId = null;
        string mohTypeOfTenderId = null;
        string mohMinistryCode = null;
        string mohBudjetRef = null;
        string mohProvisionNo = null;
        string mohBudgetAmt = null;
            

        private void btnMoazzanahProceed_Click(object sender, EventArgs e)
        {
            if (ValidateMoazanahData() == false)
            {
                return;
            }

            mohProjId = cmbMozPrjID.Text;
            if (cmbMozMinistryCode.SelectedIndex != -1)
            {
                mohMinistryCode = cmbMozMinistryCode.Text;                
            }

            if (cmbMozBudjetRefNo.SelectedIndex != -1)
            {
                mohBudjetRef = cmbMozBudjetRefNo.Text;
            }

            mohProvisionNo = txtMozProvision.Text;
            mohBudgetAmt = txtMozBudget.Text;
            mohProjTitleAr = txtProjTitleAr.Text;             
             
            bool isValidated = ValidateProjectCode(txtProjCode);
            if (isValidated == true)
            {
                txtProjCode.Enabled = false;
            }
            else
            {
                return;
            }
            projType = "Moazanah";
            SetMohProjDetailsInTheArray();
            CheckSendEmailWorking(projData);
            this.Close();
             
            //if (!CheckSendEmailWorking("Moazanah"))
            //{
               
            //}
        }

        string[] projData = null;
        void SetMohProjDetailsInTheArray()
        {
            projData = new string[21];
            projData[0] = mohProjCode;
            projData[1] = txtProjTitleEn.Text;
            projData[2] = null;
            projData[3] = mohTenderCommitteeId;
            projData[4] = mohFiscalYrId;
            projData[5] = mohUserDeptId;
            projData[6] = mohAffairsId;
            projData[7] = _userName;
            projData[8] = null;
            projData[9] = mohTypeOfTenderId;
            projData[10] = null;   //Tender Number
            projData[11] = null;   //TndrStatus
            projData[12] = null;   //TndrStatus             
            projData[13] = cmbMozPrjID.Text;
            projData[14] = mohTypeOfContractId;             
            projData[15] = mohProjTitleAr;
            projData[16] = mohMinistryCode;
            projData[17] = mohBudjetRef;
            projData[18] = mohProvisionNo;
            projData[19] = mohBudgetAmt;
            projData[20] = projType;
        }

        void SetNonMohProjDetailsInTheArray()
        {
            projData = new string[21];
            projData[0] = nonMohProjCode;
            projData[1] = nonMohProjTitleEn;
            projData[2] = null;
            projData[3] = nonMohTenderCommitteeId;
            projData[4] = nonMohFiscalYrId;
            projData[5] = nonMohUserDeptId;
            projData[6] = nonMohAffairId;
            projData[7] = _userName;
            projData[8] = null;
            projData[9] = nonMohTypeOfTender;
            projData[10] = null;   //Tender Number
            projData[11] = null;   //TndrStatus
            projData[12] = null;   //TndrStatus             
            projData[13] = null;
            projData[14] = nonMohTypeOfProject;
            projData[15] = nonMohProjTitleAr;
            projData[16] = nonMohMinistryCode;
            projData[17] = nonMohBudjetRef;
            projData[18] = nonMohProvisionNo;
            projData[19] = nonMohBudgetAmt.ToString();
            projData[20] = projType;
        }
        private void btnMoazzanahCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            sqlConn = new SqlConnection(strCon); 
            switch ((sender as TabControl).SelectedIndex)
            {                
                case 1:

                    //if (tabSelector == 2)
                    //{
                    try
                    {
                        return;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error while checking the Project Code in the database. Please try again.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    finally
                    {
                        sqlConn.Close();
                    }
                    //tabSelector = 1;    Sree
                 //}
                    // Let's suppose TabPage index 1 is the one for the transactions.
                    break;
            }
        }
        private void btnNonMohProceed_Click(object sender, EventArgs e)
        {
            projType = "Non-Moazanah";
            Boolean chkContolrs = NonMoazanahControlsValidation();
            if (chkContolrs == false)
                return;
            nonMohProjCode = txtNonMohProjCode.Text.Replace(" ", "").Trim();
            nonMohTenderCommitteeId = cmbNonMohTenderCommittee.SelectedValue.ToString();
            nonMohFiscalYrId = cmbNonMohFiscalYr.SelectedValue.ToString();
            nonMohAffairId = cmbNonMohAffairs.SelectedValue.ToString();
            nonMohUserDeptId = cmbNonMohUserDept.SelectedValue.ToString();
            nonMohTypeOfProject = cmbNonMohTypeOfContract.SelectedValue.ToString();
            nonMohTypeOfTender = cmbNonMohTypeOfTender.SelectedValue.ToString();
            nonMohProjTitleEn = txtNonMohProjTitleEn.Text.ToString();
            nonMohProjTitleAr = txtNonMohProjTitleAr.Text.ToString();
            nonMohMinistryCode = cmbNonMozMinistryCode.Text.ToString();
            nonMohBudjetRef = cmbNonMozBudjetRef.Text.ToString();
            nonMohProvisionNo = txtNonProvisionNo.Text.ToString();
            if (txtNonBudgetAmt.Text != "")
                nonMohBudgetAmt = Convert.ToDouble(txtNonBudgetAmt.Text);

            SetNonMohProjDetailsInTheArray();
            CheckSendEmailWorking(projData);

            txtNonMohProjCode.Text = "";
            txtNonMohProjTitleAr.Text = "";
            txtNonMohProjTitleEn.Text = "";
            cmbNonMohTenderCommittee.SelectedIndex = -1;
            cmbNonMohAffairs.SelectedIndex = -1;
            cmbNonMohFiscalYr.SelectedIndex = -1;
            cmbNonMohTypeOfContract.SelectedIndex = -1;
            cmbNonMohTypeOfTender.SelectedIndex = -1;
            cmbNonMohUserDept.SelectedIndex = -1;
            this.Close();
                       
        }
        private Boolean NonMoazanahControlsValidation()
        {
            Boolean chkCntrls = true;            
           
            if (txtNonMohProjCode.Text == "")
            {
                MessageBox.Show("Please Enter ProjectCode ", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtProjCode.Focus();
                chkCntrls = false;
            }
            else if (cmbNonMohAffairs.SelectedIndex == -1)
            {
                MessageBox.Show("Please Select Affairs Type ", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cmbNonMohAffairs.Focus();
                chkCntrls = false;
            }
            else if (cmbNonMohUserDept.SelectedIndex == -1)
            {
                MessageBox.Show("Please Select depertment name", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cmbNonMohUserDept.Focus();
                chkCntrls = false;
            }
            else if (txtNonMohProjTitleEn.Text == "")
            {
                MessageBox.Show("Non Moazanah Project Title can not be left blank", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtNonMohProjTitleEn.Focus();
                chkCntrls = false;              
            }
            else if (cmbNonMohTenderCommittee.SelectedIndex == -1)
            {
                MessageBox.Show("Please Select Tender Committee", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cmbNonMohTenderCommittee.Focus();
                chkCntrls = false;               
            }
            else if (cmbNonMohTypeOfTender.SelectedIndex == -1)
            {
                MessageBox.Show("Please select Type of Tender", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cmbNonMohTypeOfTender.Focus();
                chkCntrls = false;               
            }
            else if (cmbNonMohFiscalYr.SelectedIndex == -1)
            {
                MessageBox.Show("Please select Fiscal Year", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cmbNonMohFiscalYr.Focus();
                chkCntrls = false;               
            }
            else if (cmbNonMohTypeOfContract.SelectedIndex == -1)
            {
                MessageBox.Show("Please Select Type of Contract", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cmbNonMohTypeOfContract.Focus();
                chkCntrls = false;
            }
            //else if (cmbNonMozMinistryCode.SelectedIndex == -1)
            //{
            //    MessageBox.Show("Please select MinistryCode", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //    cmbNonMozMinistryCode.Focus();
            //    chkCntrls = false;
            //}
            //else if (cmbNonMozBudjetRef.SelectedIndex == -1)
            //{
            //    MessageBox.Show("Please select budget ref no", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //    cmbNonMozBudjetRef.Focus();
            //    chkCntrls = false;
            //}
                    
            return chkCntrls;
        }
        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tabControl1_DrawItem(object sender, DrawItemEventArgs e)
        {
            Graphics g = e.Graphics;
            Brush _TextBrush;

            // Get the item from the collection.
            TabPage _TabPage = tabControl1.TabPages[e.Index];

            // Get the real bounds for the tab rectangle.
            Rectangle _TabBounds = tabControl1.GetTabRect(e.Index);

            if (e.State == DrawItemState.Selected)
            {
                // Draw a different background color, and don't paint a focus rectangle.
                _TextBrush = new SolidBrush(Color.Blue);
                g.FillRectangle(Brushes.Gray, e.Bounds);
            }
            else
            {
                _TextBrush = new System.Drawing.SolidBrush(e.ForeColor);
                // e.DrawBackground();
            }

            // Use our own font. Because we CAN.
            Font _TabFont = new Font(e.Font.FontFamily, (float)18, FontStyle.Regular, GraphicsUnit.Pixel);
            //Font fnt = new Font(e.Font.FontFamily, (float)7.5, FontStyle.Bold);

            // Draw string. Center the text.
            StringFormat _StringFlags = new StringFormat();
            _StringFlags.Alignment = StringAlignment.Center;
            _StringFlags.LineAlignment = StringAlignment.Center;
            g.DrawString(tabControl1.TabPages[e.Index].Text, _TabFont, _TextBrush, _TabBounds, new StringFormat(_StringFlags));
        }
        private void frmProjectInfo_Paint(object sender, PaintEventArgs e)
        {
            tabControl1.DrawMode = TabDrawMode.OwnerDrawFixed;
        }

        private void frmProjectInfo_Load(object sender, EventArgs e)
        {
            txtNonMohProjCode.Focus();
            txtProjCode.Enabled = false;
            cmbMohAffairs.Enabled = false;
            cmbMohUserDept.Enabled = false;
            txtProjTitleEn.Enabled = false;
            txtProjTitleAr.Enabled = false;
            cmbMohTenderCommittee.Enabled = false;
            cboMohTOTender.Enabled = false;
            cmbMohTypeContract.Enabled = false;
            cmbFiscalYear.Enabled = false;
            cmbMozMinistryCode.Enabled = false;
            cmbMozBudjetRefNo.Enabled = false;
            txtMozProvision.Enabled = false;
            txtMozBudget.Enabled = false;
            btnMoazzanahProceed.Enabled = false;             
            FillMoazanahCombo();
            FillNonMoazanahCombo();
           // tabControl1.TabPages.Remove(tabPage1);

        }
        private void panelNewProjFromMoazzanah_Paint(object sender, PaintEventArgs e)
        {
           // FillMoazanahCombo();
        }
        private void FillCombo()
        {
            SqlConnection sqlConn = new SqlConnection(strCon);            
            try
            {
                sqlConn.Open();
                sqlCom = new SqlCommand("select Affair_id,Affairs_Short_name,[Affairs_Name] from AFFAIRS2 where isActive=1", sqlConn);
                sqlReader = sqlCom.ExecuteReader();
                cmbMohAffairs.Items.Add("Select AFFAIRS Type");
                while (sqlReader.Read())
                {
                    cmbMohAffairs.Items.Add(sqlReader.GetString(2));
                }
                cmbMohAffairs.SelectedIndex = 0;
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
            finally
            {
                sqlReader.Close();
                sqlConn.Close();
            }
            ////try
            ////{
            ////    sqlConn.Open();
            ////    sqlCom = new SqlCommand("select department_id,department_short_name,[Department] from Department", sqlConn);
            ////    sqlReader = sqlCom.ExecuteReader();
            ////    cmbMohUserDept.Items.Add("Select Department Type");
            ////    while (sqlReader.Read())
            ////    {
            ////        cmbMohUserDept.Items.Add(sqlReader.GetString(1));
            ////    }
            ////    cmbMohUserDept.SelectedIndex = 0;
            ////}
            ////catch (Exception Ex)
            ////{
            ////    throw Ex;
            ////}
            ////finally
            ////{
            ////    sqlReader.Close();
            ////    sqlConn.Close();
            ////}
            try
            {
                sqlConn.Open();
                sqlCom = new SqlCommand("select committee_id,committee_short_name,[committee_name] from Committee", sqlConn);
                sqlReader = sqlCom.ExecuteReader();
                cmbMohTenderCommittee.Items.Add("Select Tender Type");
                while (sqlReader.Read())
                {
                    cmbMohTenderCommittee.Items.Add(sqlReader.GetString(1));
                }
                cmbMohTenderCommittee.SelectedIndex = 0;
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
            finally
            {
                sqlReader.Close();
                sqlConn.Close();
            }
            try
            {
                sqlConn.Open();
                sqlCom = new SqlCommand("select tender_type_id,tender_type_short_name,[tender_type_name] from [TenderTypes]", sqlConn);
                sqlReader = sqlCom.ExecuteReader();
                cboMohTOTender.Items.Add("Select Tender Type");
                while (sqlReader.Read())
                {
                    cboMohTOTender.Items.Add(sqlReader.GetString(1));
                }
                cboMohTOTender.SelectedIndex = 0;
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
            finally
            {
                sqlReader.Close();
                sqlConn.Close();
            }

            try
            {
                sqlConn.Open();
                sqlCom = new SqlCommand("select FYID,[FiscalYear] from [FiscalYear] where FYID>=15", sqlConn);
                sqlReader = sqlCom.ExecuteReader();
                cmbFiscalYear.Items.Add("Select Fiscal Year");
                while (sqlReader.Read())
                {
                    cmbFiscalYear.Items.Add(sqlReader.GetString(1));
                }
                cmbFiscalYear.SelectedIndex = 0;                               
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
            finally
            {
                sqlReader.Close();
                sqlConn.Close();
            }

            sqlConn.Open();
            sqlCom = new SqlCommand("select contract_type_id,type_short_name,[TypeofContract] from [ContractTypes]", sqlConn);
            sqlReader = sqlCom.ExecuteReader();
            cmbMohTypeContract.Items.Add("Select Contract Type");
            while (sqlReader.Read())
            {
                cmbMohTypeContract.Items.Add(sqlReader.GetString(2));
            }
            cmbMohTypeContract.SelectedIndex = 0;
            sqlReader.Close();
            sqlConn.Close();
        }
        private void PopulateComboBox(ComboBox cmbBox, string sqlQuery, string valueMember, string displayName)
        {
            DataTable table = new DataTable();
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn)) //@"select Affair_id,[PWA Affairs]as AffairName from AFFAIRS"
                        da.Fill(table);
                }

                cmbBox.DataSource = null;
                cmbBox.Items.Add("Select");
                cmbBox.DataSource = table;

                cmbBox.DisplayMember = displayName;
                cmbBox.ValueMember = valueMember;
                cmbBox.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Occurred while retrieving the data for the specific item selected from the dropdownlist " + cmbBox.Name, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                 
            }            
        }
        private void FillNonMoazanahCombo()
        {  
            PopulateComboBox(cmbNonMohAffairs, @"Select Affair_id,Affairs_Short_name,[Affairs_Name]as AffairName from AFFAIRS2 where isActive=1", "Affair_id", "AffairName");
          //  PopulateComboBox(cmbNonMohUserDept, @"Select department_id,department_short_name,Department from Department", "department_id", "Department");
            PopulateComboBox(cmbNonMohTenderCommittee, @"Select committee_id,committee_name from Committee", "committee_id", "committee_name");
            PopulateComboBox(cmbNonMohTypeOfTender, @"select tender_type_id,tender_type_short_name,[tender_type_name] as TenderTypeName from [TenderTypes]", "tender_type_id", "TenderTypeName");

            PopulateComboBox(cmbNonMohFiscalYr, @"select FYID,[FiscalYear] as fiscalYear from [FiscalYear] where FYID>=15 ORDER BY FiscalYear", "FYID", "fiscalYear");
            PopulateComboBox(cmbNonMohTypeOfContract, @"select contract_type_id,type_short_name,[TypeofContract] as TypeOfContract from [ContractTypes]", "contract_type_id", "TypeOfContract");

            PopulateComboBox(cmbNonMozMinistryCode, @"SELECT Ministry_id,[MinistryCode] as MinistryCode FROM [MinistryCodes] where (MinistryCode is not NULL OR MinistryCode<>'') ORDER BY MinistryCode", "Ministry_id", "MinistryCode");
            PopulateComboBox(cmbNonMozBudjetRef, @"SELECT [BudgetRef_id] as BudRefID, [BudgetRefNumber] as BudgeRefCode FROM [BudgetReferenceCodes] ORDER BY BudgeRefCode", "BudRefID", "BudgeRefCode");             
             
        }
        private void FillMoazanahCombo()
        {
           // PopulateComboBox(cmbMozPrjID, @"SELECT proj_id, moazanah_proj_id_new FROM MOAZANAH", "proj_id", "moazanah_proj_id_new");

            PopulateComboBox(cmbMozPrjID, @"SELECT moazanah_proj_id, moazanah_proj_id FROM MOAZANAH", "moazanah_proj_id", "moazanah_proj_id");
            PopulateComboBox(cmbMohAffairs, @"Select Affair_id,Affairs_Short_name,[Affairs_Name]as AffairName from AFFAIRS2 where isActive=1", "Affair_id", "AffairName");
           // PopulateComboBox(cmbMohUserDept, @"Select department_id,department_short_name,Department from Department", "department_id", "Department");
            PopulateComboBox(cmbMohTenderCommittee, @"Select committee_id,committee_short_name,committee_name from Committee WHERE committee_id<>8", "committee_id", "committee_name");
            PopulateComboBox(cboMohTOTender, @"select tender_type_id,tender_type_short_name,[tender_type_name] as TenderTypeName from [TenderTypes] where tender_type_id <> 2 and tender_type_id <> 4", "tender_type_id", "TenderTypeName");

            PopulateComboBox(cmbFiscalYear, @"select FYID,[FiscalYear] as fiscalYear from [FiscalYear] ORDER BY FiscalYear", "FYID", "fiscalYear");
            PopulateComboBox(cmbMohTypeContract, @"select contract_type_id,type_short_name,[TypeofContract] as TypeOfContract from [ContractTypes]", "contract_type_id", "TypeOfContract");
            //PopulateComboBox(cmbMozMinistryCode, @"SELECT Ministry_id, [Ministry Name] as MinistryName FROM [Ministry Code] ORDER BY Ministry_id", "Ministry_id", "MinistryName");

            PopulateComboBox(cmbMozMinistryCode, @"SELECT Ministry_id,[MinistryCode] as MinistryCode FROM [MinistryCodes] where (MinistryCode is not NULL OR MinistryCode<>'') ORDER BY MinistryCode", "Ministry_id", "MinistryCode");
            PopulateComboBox(cmbMozBudjetRefNo, @"SELECT [BudgetRef_id] as BudRefID, [BudgetRefNumber] as BudgeRefCode FROM [BudgetReferenceCodes] ORDER BY BudgeRefCode", "BudRefID", "BudgeRefCode");  
        }
        private void panelNewProjFromNonMoazzanah_Paint(object sender, PaintEventArgs e)
        {
            //FillNonMoazanahCombo();
        }
        private void btnNonMohCancel_Click(object sender, EventArgs e)
        {
            //txtNonMohProjCode.Text = "";
            //txtNonMohProjTitleAr.Text = "";
            //txtNonMohProjTitleEn.Text = "";

            this.Close();
        }
        private void tabControl1_MouseClick(object sender, MouseEventArgs e)
        {
            
            //FillMoazanahCombo();
        }
        private void cmbMozMinistry_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void getMaxMoazanahID()
        {
           
        }
        private bool GetMoazanahID()
        {
            Int16 cmbSelected = 0;
            try
            {
                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                if (cmbMozPrjID.SelectedValue != null)
                {
                    sqlCom = new SqlCommand("Select moazanah_proj_id_new from Projects Where moazanah_proj_id_new ='" + cmbMozPrjID.SelectedValue + "'", sqlConn);
                    cmbSelected = 1;
                }
                else
                {
                    sqlCom = new SqlCommand("Select moazanah_proj_id_new from Projects Where moazanah_proj_id_new ='" + cmbMozPrjID.Text + "'", sqlConn);
                    cmbSelected = 0;
                }

                sqlReader = sqlCom.ExecuteReader();
                DialogResult dlgResult = DialogResult.Yes;
                
                if (sqlReader.HasRows == true)
                {
                    dlgResult = MessageBox.Show("Moazanah Project ID is already in the system. Please provide unique Moazanah ID", "Invalid Entry", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cmbMozPrjID.Focus();
                    sqlReader.Close();
                    sqlConn.Close();
                    return false;
                }
                else if(cmbSelected == 0)
                {
                    dlgResult = MessageBox.Show("Moazanah Project ID does not exists in the system. Please enter correct Moazanah ID", "Invalid Entry", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cmbMozPrjID.Focus();
                    sqlReader.Close();
                    sqlConn.Close();
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            
        }
        private void btnMozanah_Click(object sender, EventArgs e)
        {
            bool isValidated = GetMoazanahID();
            if (isValidated == true)
            {
                txtProjCode.Enabled = true;
                cmbMohAffairs.Enabled = true;
                cmbMohUserDept.Enabled = true;
                txtProjTitleEn.Enabled = true;
                txtProjTitleAr.Enabled = true;
                cmbMohTenderCommittee.Enabled = true;
                cboMohTOTender.Enabled = true;
                cmbMohTypeContract.Enabled = true;
                cmbFiscalYear.Enabled = true;
                cmbMozMinistryCode.Enabled = true;
                cmbMozBudjetRefNo.Enabled = true;
                txtMozProvision.Enabled = true;
                txtMozBudget.Enabled = true;
                btnMozanah.Visible = false;
                cmbMozPrjID.Enabled = false;
                btnMoazzanahProceed.Enabled = true;                
            }
            try
            {
                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                string sqlQuery = "SELECT MOAZANAH.project_name_en, MOAZANAH.project_name_ar, MOAZANAH.[Budget Reference No], MOAZANAH.[Ministry Code], MOAZANAH.[Provision Number], " +
                 "  'QAR '+CONVERT(VARCHAR, MOAZANAH.budgeted_cost,1), [FiscalYear].[FiscalYear], [ContractTypes].[TypeofContract], MOAZANAH.moazanah_proj_id " +
                 " FROM MOAZANAH INNER JOIN [FiscalYear] ON MOAZANAH.FYID = [FiscalYear].FYID INNER JOIN [ContractTypes] ON MOAZANAH.contract_type_id = [ContractTypes].contract_type_id WHERE (MOAZANAH.moazanah_proj_id = '" + cmbMozPrjID.Text + "')";

                sqlCom = new SqlCommand(sqlQuery, sqlConn);
                sqlReader = sqlCom.ExecuteReader();
                if (sqlReader.HasRows == true)
                {
                    while (sqlReader.Read())
                    {
                        txtProjTitleEn.Text = sqlReader[0].ToString();
                        txtProjTitleAr.Text = sqlReader[1].ToString();
                        cmbFiscalYear.Text = sqlReader[6].ToString();
                        cmbMohTypeContract.Text = sqlReader[7].ToString();
                        cmbMozMinistryCode.Text = sqlReader[3].ToString();
                        txtMozBudget.Text = sqlReader[5].ToString();
                        txtMozProvision.Text = sqlReader[4].ToString();
                        cmbMozBudjetRefNo.Text = sqlReader[2].ToString();                         
                    }
                }
                sqlReader.Close();
                sqlConn.Close();
                mohProjId = cmbMozPrjID.SelectedValue.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cmbMozPrjID_Leave(object sender, EventArgs e)
        {
            //try
            //{
            //    sqlConn = new SqlConnection(strCon);
            //    sqlConn.Open();
            //    sqlCom = new SqlCommand("Select moazanah_proj_id_new from Projects Where moazanah_proj_id_new ='" + cmbMozPrjID.Text + "'", sqlConn);
            //    sqlReader = sqlCom.ExecuteReader();
            //    DialogResult dlgResult = DialogResult.Yes;

            //    if (sqlReader.HasRows == true)
            //    {
            //        dlgResult = MessageBox.Show("Moazanah Project ID is already in the system. Please check the ID that you intend to add", "Invalid Entry", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //        cmbMozPrjID.Focus();
            //        return;
            //    }
            //    sqlReader.Close();
            //    sqlConn.Close();

            //}
            //catch (Exception ex)
            //{
            //    throw ex;
            //}
        }

      

        private void cmbMohAffairs_SelectionChangeCommitted(object sender, EventArgs e)
        {
            string sqlQuery = "SELECT Department2.department_id,Department2.Department, AFFAIRS2.Affair_id FROM AFFAIRS2 INNER JOIN Department2 ON AFFAIRS2.Affair_id = Department2.Affair_id " +
               " WHERE (AFFAIRS2.Affair_id = " + cmbMohAffairs.SelectedValue + ") and Department2.isActive=1 and Department2.department_id not in(46,47,48)";

            cmbMohUserDept.DataSource = null; 

            PopulateComboBox(cmbMohUserDept, sqlQuery, "department_id", "Department"); 

        }

        private void cmbNonMohAffairs_SelectionChangeCommitted(object sender, EventArgs e)
        {
            string sqlQuery = "SELECT  Department2.department_id,Department2.Department, AFFAIRS2.Affair_id FROM AFFAIRS2 INNER JOIN Department2 ON AFFAIRS2.Affair_id = Department2.Affair_id " +
               " WHERE (AFFAIRS2.Affair_id = " + cmbNonMohAffairs.SelectedValue + ") and Department2.isActive=1 and Department2.department_id not in(46,47,48)";

            cmbNonMohUserDept.DataSource = null;

            PopulateComboBox(cmbNonMohUserDept, sqlQuery, "department_id", "Department"); 
        }
        private bool nonNumberEntered = false;
        private void txtNonBudjet_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (nonNumberEntered == true)
            {
                MessageBox.Show("Please enter number only...");
                e.Handled = true;
            } 
        }

        private void txtNonBudjet_KeyDown(object sender, KeyEventArgs e)
        {
            nonNumberEntered = false;
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            {
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    if ((e.KeyCode != Keys.Back) & (e.KeyCode != Keys.Enter))
                    {
                        nonNumberEntered = true;
                    }
                }
            }
        }
        private void txtMozBudjet_KeyDown(object sender, KeyEventArgs e)
        {
            nonNumberEntered = false;
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            {
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    if ((e.KeyCode != Keys.Back) & (e.KeyCode != Keys.Enter))
                    {
                        nonNumberEntered = true;
                    }
                }
            }
        }

        private void txtMozBudjet_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (nonNumberEntered == true)
            {
                MessageBox.Show("Please enter number only...");
                e.Handled = true;
            }
        }

        private void txtMozBudjet_Leave(object sender, EventArgs e)
        {
            
        }

        private void txtNonBudjet_Leave(object sender, EventArgs e)
        {
            
        }

        private void cmbMozPrjID_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (cmbMozPrjID.SelectedIndex != -1)
            {
                GetMoazanahID();
            }
        }
       
        private void cmbMozMinistryCode_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Delete)
            {
                if (sender is ComboBox)
                {
                    ComboBox cmbBox = sender as ComboBox;
                    cmbBox.SelectedIndex = -1;
                }
            }
        }

        private void cmbMozBudjetRefNo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Delete)
            {
                if (sender is ComboBox)
                {
                    ComboBox cmbBox = sender as ComboBox;
                    cmbBox.SelectedIndex = -1;
                }
            }
        }

        private void cmbNonMozMinistryCode_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Delete)
            {
                if (sender is ComboBox)
                {
                    ComboBox cmbBox = sender as ComboBox;
                    cmbBox.SelectedIndex = -1;
                }
            }
        }

        private void cmbNonMozBudjetRef_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Delete)
            {
                if (sender is ComboBox)
                {
                    ComboBox cmbBox = sender as ComboBox;
                    cmbBox.SelectedIndex = -1;
                }
            }
        }
         
        private bool ValidateProjectCode(TextBox txtPrjCode)
        {
            try
            {
                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                sqlCom = new SqlCommand("Select project_code from Projects Where project_code ='" + txtPrjCode.Text.ToString().Replace(" ","").Trim() + "'", sqlConn);
                sqlReader = sqlCom.ExecuteReader();
                DialogResult dlgResult = DialogResult.Yes;

                if (sqlReader.HasRows == true)
                {
                    dlgResult = MessageBox.Show("Entered Project Code is already used in other project. Duplicate project code is not allowed. ", "Duplicate Entry", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtPrjCode.Focus();
                    return false;
                }               
                sqlReader.Close();
                sqlConn.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return true;
        }

        private void txtNonMohProjCode_Leave(object sender, EventArgs e)
        {
            if (txtNonMohProjCode.Text == "")
            {
                MessageBox.Show("Please Enter Project Code");
                txtNonMohProjCode.Focus();
            }
            else
            {
                ValidateProjectCode(txtNonMohProjCode);
            }
        }

        private void txtProjCode_Leave(object sender, EventArgs e)
        {
            if (txtProjCode.Text == "")
            {
                MessageBox.Show("Please Enter Project Code");
                txtProjCode.Focus();
            }
            else
            {
                ValidateProjectCode(txtProjCode);
            }
        }

        private void cmbNonMohTenderCommittee_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (Convert.ToInt16(cmbNonMohTenderCommittee.SelectedValue) ==8) //Check for Pre-Qualification
            //{                
            //    cmbNonMohTypeOfTender.DataSource = null;
            //    DataTable dtTenderType = new DataTable();
            //    dtTenderType.Columns.Add("tender_type_id");
            //    dtTenderType.Columns.Add("TenderTypeName");
            //    dtTenderType.AcceptChanges();

            //    DataRow drTenderType = dtTenderType.NewRow();
            //    drTenderType[0] = 1;
            //    drTenderType[1] = "Public Tender";
            //    dtTenderType.Rows.Add(drTenderType);
            //    dtTenderType.AcceptChanges();
            //    cmbNonMohTypeOfTender.DataSource = dtTenderType;
            //    cmbNonMohTypeOfTender.DisplayMember = "TenderTypeName";
            //    cmbNonMohTypeOfTender.ValueMember = "tender_type_id";
                
            //}
            //else
            //{
                PopulateComboBox(cmbNonMohTypeOfTender, @"select tender_type_id,tender_type_short_name,[tender_type_name] as TenderTypeName from [TenderTypes]", "tender_type_id", "TenderTypeName");
            //}
            
        }        
    }
}
