﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Transactions;
using System.Configuration;

namespace MDI_ParenrForm.Projects
{
    public partial class frmProjectEdit : Form
    {
        int _prjId = 0;

        static string staticUserName = string.Empty;
        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();
        //private string strCon = @"Data Source=PWACATO\PWACATO;Initial Catalog=TCMS-TEST;Integrated Security=True";        
        IList<string> userRightsColl = new List<string>();
        //string staticUserName = string.Empty;

        static string tndrNo = string.Empty;
        public frmProjectEdit(IList<string> userRightsCollRec, int projectId, string prjCode, string user)
        {
            InitializeComponent();
            _prjId = projectId;
            FillComboInforForUpdateProject();
            userRightsColl = userRightsCollRec;
            staticUserName = user;
            GetProjectInfo();
        }

        int existedCmtID = 0;
        int existedFiscalID = 0;
        private void GetProjectInfo()
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        string sqlQuery = "SELECT PROJECTS.proj_id, PROJECTS.project_code, PROJECTS.project_newname_en, PROJECTS.project_name_ar, Committee.committee_short_name, " +
                      " STAGES.Stage_Name,PROJECTS.tender_no, [TenderTypes].tender_type_name, [FiscalYear].[FiscalYear], " +
                      " [ContractTypes].[TypeofContract], PROJECTS.SelectPrj, d2.Department, [TenderStatus].[Status_Name], " +
                      " [TenderStatus].[TenderStatusShortName], Committee.committee_name, AFFAIRS2.[Affairs_Name], " +
                      " PROJECTS.[Ministry_Code], PROJECTS.[Budget_Reference_No], PROJECTS.[Provision_Number], PROJECTS.[moazanah_proj_id_new],Committee.committee_id,FiscalYear.FYID" +
                      " FROM STAGES INNER JOIN [TenderTypes] INNER JOIN [ContractTypes] INNER JOIN [FiscalYear] INNER JOIN Committee RIGHT OUTER JOIN " +
                      " AFFAIRS2 INNER JOIN PROJECTS ON AFFAIRS2.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON [FiscalYear].FYID = PROJECTS.FYID ON [ContractTypes].contract_type_id = PROJECTS.contract_type_id ON " +
                      " [TenderTypes].tender_type_id = PROJECTS.tender_type_id INNER JOIN Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id ON STAGES.stage_id = PROJECTS.stage_id LEFT OUTER JOIN " +
                      " [TenderStatus] ON PROJECTS.Tender_Status_id = [TenderStatus].Tender_Status_id WHERE (PROJECTS.proj_id = " + _prjId + ") ORDER BY PROJECTS.proj_id DESC";

                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        SqlDataReader sqlDr = cmd.ExecuteReader();

                        while (sqlDr.Read())
                        {
                            txtPrjCode.Text = sqlDr[1].ToString();
                            txtPrjnameEn.Text = sqlDr[2].ToString();
                            txtPrjnameArb.Text = sqlDr[3].ToString();
                            txtTenderNo.Text = sqlDr[6].ToString();
                            cmbAffairs.Text = sqlDr[15].ToString();
                            cmbDept.Text = sqlDr[11].ToString();
                            cmbFiscalYear.Text = sqlDr[8].ToString();
                            cmbTndrCommitte.Text = sqlDr[14].ToString();
                            cmbTndrType.Text = sqlDr[7].ToString();
                            cmbTypeOfContract.Text = sqlDr[9].ToString();

                            cmbMinistryCode.Text = sqlDr[16].ToString();
                            cmbBudjetRefNo.Text = sqlDr[17].ToString();
                            txtProvision.Text = sqlDr[18].ToString();
                            //txtBudgetAmnt.Text = sqlDr[21].ToString();

                            txtMoazanah.Text = sqlDr[19].ToString();

                            existedCmtID = Convert.ToInt16(sqlDr[20]);
                            existedFiscalID = Convert.ToInt16(sqlDr[21]);

                        }
                        sqlDr.Close();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error While Reading Project Data for Update");
            }
            finally
            {

            }
            GetProjectCost();
        }
        private void GetProjectCost()
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        string sqlQuery = "SELECT budgeted_cost FROM PROJECTCOST WHERE (proj_id = " + _prjId + ")";

                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        SqlDataReader sqlDr = cmd.ExecuteReader();
                        if (sqlDr.HasRows)
                            while (sqlDr.Read())
                            {
                                if (sqlDr[0].ToString() != "")
                                    txtBudgetAmnt.Text = sqlDr[0].ToString();
                            }
                        sqlDr.Close();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error While Reading Project Data for Update");
            }
            finally
            {
            }
        }
        private void FillComboInforForUpdateProject()
        {
            PopulateComboBox(cmbAffairs, @"Select Affair_id,Affairs_Short_name,[Affairs_Name]as AffairName from AFFAIRS2", "Affair_id", "AffairName");
            PopulateComboBox(cmbDept, @"Select department_id,department_short_name,Department from Department2", "department_id", "Department");
            PopulateComboBox(cmbTndrCommitte, @"Select committee_id,committee_short_name,committee_name from Committee", "committee_id", "committee_name");
            PopulateComboBox(cmbTndrType, @"select tender_type_id,tender_type_short_name,[tender_type_name] as TenderTypeName from [TenderTypes]", "tender_type_id", "TenderTypeName");
            PopulateComboBox(cmbFiscalYear, @"select FYID,[FiscalYear] as fiscalYear from [FiscalYear]", "FYID", "fiscalYear");
            PopulateComboBox(cmbTypeOfContract, @"select contract_type_id,type_short_name,[TypeofContract] as TypeOfContract from [ContractTypes]", "contract_type_id", "TypeOfContract");
            PopulateComboBox(cmbMinistryCode, @"SELECT Ministry_id,[MinistryCode] as MinistryCode FROM [MinistryCodes] ORDER BY Ministry_id", "Ministry_id", "MinistryCode");
            PopulateComboBox(cmbBudjetRefNo, @"SELECT [BudgetRef_id] as BudRefID, [BudgetRefNumber] as BudgeRefCode FROM [BudgetReferenceCodes] ORDER BY BudgetRef_id", "BudRefID", "BudgeRefCode");
        }
        private void PopulateComboBox(ComboBox cmbBox, string sqlQuery, string displayName, string valueMember)
        {
            DataTable table = new DataTable();
            try
            {
                using (SqlConnection sqlCon = new SqlConnection(strCon))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlCon)) //@"select Affair_id,[PWA Affairs]as AffairName from AFFAIRS"
                        da.Fill(table);
                }
                cmbBox.DataSource = table;
                cmbBox.DisplayMember = valueMember;
                cmbBox.ValueMember = displayName;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            cmbBox.SelectedIndex = -1;
        }

        private void UpdateProjectInfo()
        {
            int _costItemID = GetCostID(_prjId);       // Get BuggetAmount by ProjectID

            try
            {
                using (TransactionScope scope = new TransactionScope())
                {
                    using (SqlConnection sqlConn = new SqlConnection(strCon))
                    {
                        using (SqlCommand cmd = new SqlCommand())
                        {
                            sqlConn.Open();
                            cmd.Connection = sqlConn;


                            // cmd.CommandText = " UPDATE PROJECTS SET project_code = @projectCode,committee_id =@committeeId," +
                            //" FYID=@fiscId,Affair_id =@AffairId,department_id =@deptId,contract_type_id =@cntrType,tender_type_id =@tndrType, " +
                            //" project_newname_en =@prnNameEn,project_name_ar = @prnNameArb,stage_id = @StageId,tender_no =@tndrNo,[Ministry_Code] =@MinistryCode, " +
                            //" [Budget_Reference_No] =@BudgetRefNo,[Provision_Number]= @ProvisionNo," +
                            //" dummyfield =@dumfield,Update_Date = @UpdateDate, Update_User = @UpdateUser, WHERE proj_id = @prjId";

                            cmd.CommandText = " UPDATE PROJECTS SET project_code = @projectCode,committee_id =@committeeId," +
                            " FYID=@fiscId,Affair_id =@AffairId,department_id =@deptId,contract_type_id =@cntrType,tender_type_id =@tndrType, " +
                            " project_newname_en =@prnNameEn,project_name_ar = @prnNameArb,stage_id = @StageId,tender_no =@tndrNo,[Ministry_Code] =@MinistryCode, " +
                            " [Budget_Reference_No] =@BudgetRefNo,[Provision_Number]= @ProvisionNo,moazanah_proj_id_new = @moazID," +
                            " Update_Date = @UpdateDate, Update_User = @UpdateUser,dummyfield=@dummyfield WHERE proj_id = @prjId";


                            //Varun ,moazanah_proj_id = @moazID

                            cmd.Parameters.AddWithValue("@prjId", _prjId);
                            cmd.Parameters.AddWithValue("@projectCode", txtPrjCode.Text.Replace(" ", "").Trim());
                            cmd.Parameters.AddWithValue("@committeeId", cmbTndrCommitte.SelectedValue);
                            cmd.Parameters.AddWithValue("@fiscId", cmbFiscalYear.SelectedValue);
                            cmd.Parameters.AddWithValue("@AffairId", cmbAffairs.SelectedValue);
                            cmd.Parameters.AddWithValue("@deptId", cmbDept.SelectedValue);
                            cmd.Parameters.AddWithValue("@cntrType", cmbTypeOfContract.SelectedValue);
                            cmd.Parameters.AddWithValue("@tndrType", cmbTndrType.SelectedValue);
                            cmd.Parameters.AddWithValue("@prnNameEn", txtPrjnameEn.Text);
                            cmd.Parameters.AddWithValue("@prnNameArb", txtPrjnameArb.Text);
                            cmd.Parameters.AddWithValue("@StageId", 1);

                            if (txtTenderNo.Text == "")
                                cmd.Parameters.AddWithValue("@tndrNo", System.DBNull.Value);
                            else
                                cmd.Parameters.AddWithValue("@tndrNo", txtTenderNo.Text);

                            cmd.Parameters.AddWithValue("@MinistryCode", cmbMinistryCode.Text);
                            cmd.Parameters.AddWithValue("@BudgetRefNo", cmbBudjetRefNo.Text);
                            cmd.Parameters.AddWithValue("@ProvisionNo", txtProvision.Text);

                            //Varun cmd.Parameters.AddWithValue("@moazID", txtMoazanah.Text);

                            cmd.Parameters.AddWithValue("@moazID", txtMoazanah.Text);

                            cmd.Parameters.AddWithValue("@dummyfield", System.DateTime.Now);

                            cmd.Parameters.AddWithValue("@UpdateDate", System.DateTime.Now);
                            cmd.Parameters.AddWithValue("@UpdateUser", staticUserName);

                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }

                        string updateQueryBdgt = "UPDATE ProjectCost SET budgeted_cost =@budgetAmnt,update_date = @updateDate,update_user = @updateUser Where cost_item_id = @costID";
                        using (SqlCommand cmd = new SqlCommand(updateQueryBdgt, sqlConn))
                        {
                            cmd.Parameters.AddWithValue("@costID", _costItemID);

                            if (txtBudgetAmnt.Text != "")
                                cmd.Parameters.AddWithValue("@budgetAmnt", Convert.ToDouble(txtBudgetAmnt.Text));
                            else
                                cmd.Parameters.AddWithValue("@budgetAmnt", DBNull.Value);

                            cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                            cmd.Parameters.AddWithValue("@updateUser", staticUserName);

                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }

                        sqlConn.Close();
                        MessageBox.Show("Project Updated Succesfully");
                        this.Close();
                    }
                    scope.Complete();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating Project records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {

            }
        } 
        
        private void btnNonMohProceed_Click(object sender, EventArgs e)
        {
            if (userRightsColl.Contains("3"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }
            UpdateProjectInfo(); 
        }
        private int GetCostID(int PrjiD)
        {
            int _custID = 0;
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    sqlConn.Open();
                    SqlCommand sqlCom = new SqlCommand("Select cost_item_id from ProjectCost Where proj_id = " + PrjiD + " and stage_id = 4", sqlConn);
                    _custID = Convert.ToInt16(sqlCom.ExecuteScalar());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return _custID;
        }
        private void frmProjectEdit_Load(object sender, EventArgs e)
        {
            tndrNo = txtTenderNo.Text;

            if (userRightsColl.Contains("4"))
            {
                txtTenderNo.Enabled = false;
                //MessageBox.Show("You dont have previliges to edit TenderNo,Please contact administrator");
            }
            if (userRightsColl.Contains("5"))
            {
                txtPrjCode.Enabled = false;
            }
            if (userRightsColl.Contains("6"))
            {
                txtMoazanah.Enabled = false;
                // MessageBox.Show("You dont have previliges to edit MoaganahID,Please contact administrator");
            }
            if (userRightsColl.Contains("7"))
            {
                cmbTndrType.Enabled = false;
                //MessageBox.Show("You dont have previliges to Edit Type Of Tender,Please contact administrator");
            }
            if (userRightsColl.Contains("8"))
            {
                cmbAffairs.Enabled = false;
                cmbDept.Enabled = false;

                // MessageBox.Show("You dont have previliges to Edit Affairs and User Department,Please contact administrator");
            }
            if (userRightsColl.Contains("9"))
            {
                // txtPrjCode.ReadOnly = true;
                txtPrjnameEn.Enabled = false;
                txtPrjnameArb.Enabled = false;


                //MessageBox.Show("You dont have previliges to Edit Project Code and Project Title,Please contact administrator");
            }
            if (userRightsColl.Contains("10"))
            {
                cmbTndrCommitte.Enabled = false;
                cmbFiscalYear.Enabled = false;
                cmbTypeOfContract.Enabled = false;
                //txtPrjCode.Enabled = false;
                //MessageBox.Show("You dont have previliges to  Edit Tender Committee and Project Codes,Please contact administrator");
            }
            if (userRightsColl.Contains("16"))
            {
                cmbMinistryCode.Enabled = false;
                cmbBudjetRefNo.Enabled = false;
                txtProvision.Enabled = false;
                //MessageBox.Show("You dont have previliges to Edit Type Of Tender,Please contact administrator");
            }
            if (userRightsColl.Contains("17"))
            {
                cmbMinistryCode.Enabled = false;
                cmbBudjetRefNo.Enabled = false;
                txtProvision.Enabled = false;
                //MessageBox.Show("You dont have previliges to Edit Type Of Tender,Please contact administrator");
            }

            if (userRightsColl.Contains("36"))
            {
                txtBudgetAmnt.Enabled = false;
            }
            if (userRightsColl.Contains("35"))
            {
                lblBudget.Visible = false;
                txtBudgetAmnt.Visible = false;
            }
        }       

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void cmbAffairs_SelectionChangeCommitted(object sender, EventArgs e)
        {
            string sqlQuery = "SELECT Department2.department_id,Department2.Department, AFFAIRS2.Affair_id FROM AFFAIRS2 INNER JOIN Department2 ON AFFAIRS2.Affair_id = Department2.Affair_id " +
             " WHERE (AFFAIRS2.Affair_id = " + cmbAffairs.SelectedValue + ")";

            cmbDept.DataSource = null;

            PopulateComboBox(cmbDept, sqlQuery, "department_id", "Department");
        }
        private void txtPrjCode_Leave(object sender, EventArgs e)
        {
            ValidateProjectCode(txtPrjCode.Text.ToString().Replace(" ","").Trim());
        }
        private void ValidateProjectCode(string prjCode)
        {
            try
            {
                SqlConnection sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                SqlCommand sqlCom = new SqlCommand("Select project_code from Projects Where project_code ='" + prjCode + "'", sqlConn);
                SqlDataReader sqlReader = sqlCom.ExecuteReader();
                DialogResult dlgResult = DialogResult.Yes;

                if (sqlReader.HasRows == true)
                {
                    dlgResult = MessageBox.Show("Entered Project Code is already used in other project. Duplicate project code is not allowed. ", "Duplicate Entry", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                sqlReader.Close();
                sqlConn.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        string strCmtExistedValue = string.Empty;
        string strFiscalExistedValue = string.Empty;
        private void cmbTndrCommitte_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (sender is ComboBox)
            {
                ComboBox cmbBox = sender as ComboBox;
                strCmtExistedValue = cmbBox.Text;
            }
            if (txtTenderNo.Text != "")
            {
                MessageBox.Show("Tender No. is already assigned for this project." + Environment.NewLine + "Please check with system administrator before changing the Tender Committee.");

                cmbTndrCommitte.Text = strCmtExistedValue;
            }
        }

        private void cmbFiscalYear_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (sender is ComboBox)
            {
                ComboBox cmbBox = sender as ComboBox;
                strFiscalExistedValue = cmbBox.Text;
            }
            if (txtTenderNo.Text != "")
            {
                MessageBox.Show("Tender No. is already assigned for this project." + Environment.NewLine + "Please check with system administrator before changing the Fiscal Year.");

                cmbFiscalYear.Text = strFiscalExistedValue;
            }

            //if (txtTenderNo.Text != "")
            //{
            //    MessageBox.Show("Tender No. is already assigned for this project. /n Please check with system administrator before changing the Fiscal Year.");

            //    cmbFiscalYear.SelectedIndex = existedCmtID;
            //}
        }
        private void cmbTndrCommitte_Leave(object sender, EventArgs e)
        {

        }

        private void cmbTndrCommitte_DisplayMemberChanged(object sender, EventArgs e)
        {

        }

        
        public void MyKeyPress(object sender, KeyEventArgs e)
        {
            e.SuppressKeyPress = true;
            string first = e.Modifiers.ToString();

            if (first != "None")
            {
                if ((e.KeyCode != Keys.ShiftKey) && (e.KeyCode != Keys.Alt) && (e.KeyCode != Keys.ControlKey))
                {
                    txtTenderNo.Text = tndrNo;
                }
            }
            else
            {
                txtTenderNo.Text = tndrNo;
            }
            e.Handled = true;
        }        


        private void txtMoazanah_Leave(object sender, EventArgs e)
        {
            if (checkMozanahProjectID())
            {
                MessageBox.Show("This Mozanah projectID is already assigned to other project.Please check your entry.");
                return;
            }
        }
        private Boolean checkMozanahProjectID()
        {
            using (SqlConnection sqlConn = new SqlConnection(strCon))
            {
                sqlConn.Open();
                SqlCommand sqlCom = new SqlCommand("SELECT moazanah_proj_id_new FROM Projects Where moazanah_proj_id_new = '" + txtMoazanah.Text + "'", sqlConn);
                using (SqlDataReader sqlReader = sqlCom.ExecuteReader())
                {
                    if (sqlReader.HasRows)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
    }
}
