﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace MDI_ParenrForm.Projects
{
    public partial class frmWorkOrders : Form
    {
        string _contractorNo = string.Empty;
        CommonClass cmnCls = null;
        int _bidID = 0;
        int _prjID = 0;        

        IList<string> mUserRightsColl = new List<string>();
        string _userName = string.Empty;        
        bool _isHeadOfSection = false;
        string mProjectTitle = null;
        string mTenderNo = null;

        public frmWorkOrders(IList<string> userRightsCollContracts, int PrjID, string tenderNo,string projectTitle, string user, bool isHeadOfSection)
        {
            InitializeComponent();
            mUserRightsColl = userRightsCollContracts;
            mProjectTitle = projectTitle;             
            _userName = user;          
            _prjID = PrjID;
            _isHeadOfSection = isHeadOfSection;
            mTenderNo = tenderNo;
            cmnCls = new CommonClass(user);
            cmnCls.CreateWorkOrderGridViewColumns(dgvWorkOrders, _prjID,0);
        }

        private void btnNewWorkOrder_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Count != 0 && _isHeadOfSection == false)
            {
                if (mUserRightsColl.Contains("73"))
                {
                    MessageBox.Show("Do not have access rights to create Work Order, Please contact the Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            frmNewWorkOrder frmNewWorkOrder = new frmNewWorkOrder(mUserRightsColl, _prjID, _userName, _isHeadOfSection, dgvWorkOrders);
            frmNewWorkOrder.StartPosition = FormStartPosition.CenterParent;
            frmNewWorkOrder.ShowDialog(); 
        }

        //private void dgvWorkOrders_CellContentClick(object sender, DataGridViewCellEventArgs e)
        //{
        //    if (mUserRightsColl.Count != 0 && _isHeadOfSection == false)
        //    {
        //        if (mUserRightsColl.Contains("76"))
        //        {
        //            MessageBox.Show("You do not have permission to View Contractors Details In Work Orders, Please contact the Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //            return;
        //        }
        //    }
        //    int rowIndex = e.RowIndex;
        //    int colIndex = e.ColumnIndex;
        //    try
        //    {
        //        if (rowIndex != -1)
        //        {
        //            if (colIndex == 1)
        //            {
        //                frmWorkOrderContractProcessDetails frmWOContract = null;
        //                string[] workOrderInfo = new string[14];
        //                workOrderInfo[0] = dgvWorkOrders.Rows[rowIndex].Cells[1].Value.ToString();
        //                workOrderInfo[1] = dgvWorkOrders.Rows[rowIndex].Cells[2].Value.ToString();
        //                workOrderInfo[2] = dgvWorkOrders.Rows[rowIndex].Cells[3].Value.ToString();
        //                workOrderInfo[3] = dgvWorkOrders.Rows[rowIndex].Cells[4].Value.ToString();
        //                workOrderInfo[4] = dgvWorkOrders.Rows[rowIndex].Cells[5].Value.ToString();
        //                workOrderInfo[5] = dgvWorkOrders.Rows[rowIndex].Cells[6].Value.ToString();
        //                workOrderInfo[6] = dgvWorkOrders.Rows[rowIndex].Cells[7].Value.ToString();
        //                workOrderInfo[7] = dgvWorkOrders.Rows[rowIndex].Cells[8].Value.ToString(); //Convert.ToDateTime(dgvWorkOrders.Rows[rowIndex].Cells[8].Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy")
        //                workOrderInfo[8] = dgvWorkOrders.Rows[rowIndex].Cells[9].Value.ToString();
        //                workOrderInfo[9] = dgvWorkOrders.Rows[rowIndex].Cells[10].Value.ToString();
        //                workOrderInfo[10] = dgvWorkOrders.Rows[rowIndex].Cells[11].Value.ToString();
        //                workOrderInfo[11] = dgvWorkOrders.Rows[rowIndex].Cells[12].Value.ToString();
        //                workOrderInfo[12] = dgvWorkOrders.Rows[rowIndex].Cells[13].Value.ToString();
        //                workOrderInfo[13] = dgvWorkOrders.Rows[rowIndex].Cells[14].Value.ToString();

        //                frmWOContract = new frmWorkOrderContractProcessDetails(mUserRightsColl, _userName, workOrderInfo, _prjID, dgvWorkOrders, _isHeadOfSection, mProjectTitle);
        //                frmWOContract.StartPosition = FormStartPosition.CenterParent;
        //                frmWOContract.ShowDialog();
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("Exception occurred while displaying the Work Orders", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //    }

        //} 

        private void dgvWorkOrders_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (mUserRightsColl.Count != 0 && _isHeadOfSection == false)
            {
                if (mUserRightsColl.Contains("76"))
                {
                    MessageBox.Show("You do not have permission to View Contractors Details In Work Orders, Please contact the Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            int rowIndex = e.RowIndex;
            int colIndex = e.ColumnIndex;
            try
            {
                if (rowIndex != -1)
                {
                    if (colIndex == 1)
                    {
                        frmWorkOrderContractProcessDetails frmWOContract = null;
                        string[] workOrderInfo = new string[29];
                        workOrderInfo[0] = dgvWorkOrders.Rows[rowIndex].Cells[1].Value.ToString();
                        workOrderInfo[1] = dgvWorkOrders.Rows[rowIndex].Cells[2].Value.ToString();
                        workOrderInfo[2] = dgvWorkOrders.Rows[rowIndex].Cells[3].Value.ToString();
                        workOrderInfo[3] = dgvWorkOrders.Rows[rowIndex].Cells[4].Value.ToString();
                        workOrderInfo[4] = dgvWorkOrders.Rows[rowIndex].Cells[5].Value.ToString();
                        workOrderInfo[5] = dgvWorkOrders.Rows[rowIndex].Cells[6].Value.ToString();
                        workOrderInfo[6] = dgvWorkOrders.Rows[rowIndex].Cells[7].Value.ToString();
                        workOrderInfo[7] = dgvWorkOrders.Rows[rowIndex].Cells[8].Value.ToString(); //Convert.ToDateTime(dgvWorkOrders.Rows[rowIndex].Cells[8].Value.ToString().Split(' ')[0]).ToString("dd/MMM/yyyy")
                        workOrderInfo[8] = dgvWorkOrders.Rows[rowIndex].Cells[9].Value.ToString();
                        workOrderInfo[9] = dgvWorkOrders.Rows[rowIndex].Cells[10].Value.ToString();
                        workOrderInfo[10] = dgvWorkOrders.Rows[rowIndex].Cells[11].Value.ToString();
                        workOrderInfo[11] = dgvWorkOrders.Rows[rowIndex].Cells[12].Value.ToString();
                        workOrderInfo[12] = dgvWorkOrders.Rows[rowIndex].Cells[13].Value.ToString();
                        workOrderInfo[13] = dgvWorkOrders.Rows[rowIndex].Cells[14].Value.ToString();
                        workOrderInfo[14] = dgvWorkOrders.Rows[rowIndex].Cells[15].Value.ToString();
                        workOrderInfo[15] = dgvWorkOrders.Rows[rowIndex].Cells[16].Value.ToString();
                        workOrderInfo[16] = dgvWorkOrders.Rows[rowIndex].Cells[17].Value.ToString();
                        workOrderInfo[17] = dgvWorkOrders.Rows[rowIndex].Cells[18].Value.ToString();
                        workOrderInfo[18] = dgvWorkOrders.Rows[rowIndex].Cells[19].Value.ToString();
                        workOrderInfo[19] = dgvWorkOrders.Rows[rowIndex].Cells[20].Value.ToString();
                        workOrderInfo[20] = dgvWorkOrders.Rows[rowIndex].Cells[21].Value.ToString();
                        workOrderInfo[21] = dgvWorkOrders.Rows[rowIndex].Cells[22].Value.ToString();
                        workOrderInfo[22] = dgvWorkOrders.Rows[rowIndex].Cells[23].Value.ToString();
                        workOrderInfo[23] = dgvWorkOrders.Rows[rowIndex].Cells[24].Value.ToString();
                        workOrderInfo[24] = dgvWorkOrders.Rows[rowIndex].Cells[25].Value.ToString();
                        workOrderInfo[25] = dgvWorkOrders.Rows[rowIndex].Cells[26].Value.ToString();
                        workOrderInfo[26] = dgvWorkOrders.Rows[rowIndex].Cells[27].Value.ToString();
                        workOrderInfo[27] = dgvWorkOrders.Rows[rowIndex].Cells[28].Value.ToString();
                        workOrderInfo[28] = dgvWorkOrders.Rows[rowIndex].Cells[29].Value.ToString();

                        frmWOContract = new frmWorkOrderContractProcessDetails(mUserRightsColl, _userName, workOrderInfo, _prjID, dgvWorkOrders, _isHeadOfSection, mProjectTitle);
                        frmWOContract.StartPosition = FormStartPosition.CenterParent;
                        frmWOContract.ShowDialog();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception occurred while displaying the Work Orders", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnWOTenderSubmission_Click(object sender, EventArgs e)
        {           

            int countChkSelection = checkGridViewSelection();
            if (countChkSelection > 1 || countChkSelection == 0)
                return;        
             
            frmTenderSubmission frmTndrSub = null;           
            if (mTenderNo.Contains("STC"))
                frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("STC", mTenderNo, mProjectTitle, _prjID, _userName, null, mUserRightsColl, checkedWorkOrderId.ToString(), workOrderProjTitle, _isHeadOfSection, true,false);
            else if (mTenderNo.Contains("GTC"))
                frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("GTC", mTenderNo, mProjectTitle, _prjID, _userName, null, mUserRightsColl, checkedWorkOrderId.ToString(), workOrderProjTitle, _isHeadOfSection, true, false);
            else if (mTenderNo.Contains("ITC"))
                frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("ITC", mTenderNo, mProjectTitle, _prjID, _userName, null, mUserRightsColl, checkedWorkOrderId.ToString(), workOrderProjTitle, _isHeadOfSection, true, false);
            else if (mTenderNo.Contains("MRPSC"))
                frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("MRPSC", mTenderNo, mProjectTitle, _prjID, _userName, null, mUserRightsColl, checkedWorkOrderId.ToString(), workOrderProjTitle, _isHeadOfSection, true, false);
            else if (mTenderNo.Contains("EUWC"))
                frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("EUWC", mTenderNo, mProjectTitle, _prjID, _userName, null, mUserRightsColl, checkedWorkOrderId.ToString(), workOrderProjTitle, _isHeadOfSection, true, false);
            else if (mTenderNo.Contains("NC"))
                frmTndrSub = new MDI_ParenrForm.Projects.frmTenderSubmission("NC", mTenderNo, mProjectTitle, _prjID, _userName, null, mUserRightsColl, checkedWorkOrderId.ToString(), workOrderProjTitle, _isHeadOfSection, true, false);
            frmTndrSub.Text = "Work Order Submission Window";
            frmTndrSub.StartPosition = FormStartPosition.CenterParent;
            frmTndrSub.ShowDialog();            

        }

         
        StringBuilder checkedWorkOrderId = null;
        string workOrderProjTitle = null;
        private int checkGridViewSelection()
        {
            int iCnt = 0;             
            checkedWorkOrderId = new StringBuilder();
            for (int iCounter = 0; iCounter < dgvWorkOrders.RowCount; iCounter++)
            {
                DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgvWorkOrders.Rows[iCounter].Cells[0];

                if (chkactive.Value != null)
                {
                    if (chkactive.Value.ToString().ToLower() == "true")
                    {
                        workOrderProjTitle = dgvWorkOrders.Rows[iCounter].Cells[2].Value.ToString();
                        checkedWorkOrderId.Append(dgvWorkOrders.Rows[iCounter].Cells[1].Value + "," + Convert.ToDateTime(dgvWorkOrders.Rows[iCounter].Cells[8].Value).ToString("dd/MMM/yyyy") + "," + dgvWorkOrders.Rows[iCounter].Cells[6].Value);
                        iCnt = iCnt + 1;
                    }
                }
            }             
            if (iCnt == 0)
            {
                MessageBox.Show("Please check at least one checkbox against the Work Order for which you wish to Issue Voucher", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return iCnt;
            }

            if (iCnt > 1)
            {
                MessageBox.Show("At a time, Please check only one checkbox against the Work Order for which you wish to Issue Voucher", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return iCnt;
            }

            return iCnt;
        }
    }
}
