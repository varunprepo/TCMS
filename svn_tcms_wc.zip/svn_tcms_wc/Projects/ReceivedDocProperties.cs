﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Configuration;
using System.Diagnostics;
using System.Drawing.Imaging;
using System.Text.RegularExpressions;
using MDI_ParenrForm;
using TenderTrackingSystem.Contacts;

namespace TenderTrackingSystem
{
    public partial class ReceivedDocProperties : Form
    {
        //string strTableName = null;
        static short sUpload = 0;
        DAL dalObj = null;

        static int _projId = 0;

        static string tenderNo = null;
        string strPrjCode = string.Empty;
        int _docId = 0; int _stageID = 0;
        string _docType = string.Empty;
        Boolean chkUpdateMode = false;
        IList<string> userRightsColl = new List<string>();
        string _userName = string.Empty;

        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();
        public ReceivedDocProperties(IList<string> userRightsCollRec, int PrjID, int stageID, string user)        // New Entry Form
        {
            InitializeComponent();
            _projId = PrjID;
            _stageID = stageID;
            userRightsColl = userRightsCollRec;
            _userName = user;
            //HideReceivedComboBox();
            //if (userRightsColl.Contains("20"))
            //{
            //    //MessageBox.Show("You have no privilege,Contact administrator");
            //    return;
            //}           


        }
        public ReceivedDocProperties(IList<string> userRightsCollRec, int PrjID, string prjCode, int docId, int stageID, string user)  // Edit Mode               // Update Form
        {
            InitializeComponent();

            _docId = docId;
            _projId = PrjID;
            strPrjCode = prjCode;

            _stageID = stageID;
            chkUpdateMode = true;
            userRightsColl = userRightsCollRec;

            _userName = user;
            //HideReceivedComboBox();
            //if (userRightsColl.Contains("21"))
            //{
            //    //MessageBox.Show("You have no privilege,Contact administrator");
            //    return;
            //}            


        }
        public ReceivedDocProperties(IList<string> userRightsCollRec, int docID, int ProjID, string docType, int stageID, string user)
        {
            InitializeComponent();
            _projId = ProjID;
            _docId = docID;
            _docType = docType;
            _stageID = stageID;
            chkUpdateMode = true;
            userRightsColl = userRightsCollRec;
            _userName = user;
            //HideReceivedComboBox();
        }
        //short paramSelectedValue, int prjID, string parmProjCode, string parmProjTitle, string paramUserName, string TenderNo,string ministry_Code, string budjet_RefNo,string provision_No,string tender_Status,string committeName


        //BASED on Riyas Request on 25/Sep/2017
        private void HideReceivedComboBox()
        {
            //if (stageID != 2)
            //{
                //lblReceFrom.Visible = false;
                //cmbRDPFrom.Visible = false;
                //label3.Visible = false;
                //button1.Visible = false;
                //button4.Visible = false;
            //}
            //else if (stageID == 2)
            //{
            //    lblReceFrom.Visible = true;
            //    cmbRDPFrom.Visible = true;
            //    label3.Visible = true;
            //    button1.Visible = true;
            //    button4.Visible = true;
            //}
        }

        public void populateRDPUploadFiles(ListBox lstBox, int paramProjId, short paramStageId, string paramTenderNo, string paramUserName)
        {
            for (int iCtrl = 0; iCtrl < lstBox.Items.Count; iCtrl++)
                this.lstRDPUploadedFiles.Items.Add(lstBox.Items[iCtrl].ToString());

            _projId = paramProjId;
            _stageID = paramStageId;
            tenderNo = paramTenderNo;
            userName = paramUserName;
        }
        private byte[] getImageForUpdate(ref string _fileName)
        {
            System.IO.FileStream fileStream = null;
            System.IO.BinaryReader binaryReader = null;
            string strFileName = null;
            byte[] buffer = null;
            long totBytes = 0;
            try
            {
                if (lstFileColl.Items.Count <= 1)
                    return buffer;

                foreach (string s in lstFileColl.Items)
                {
                    strFileName = s;

                    _fileName = s;
                    fileStream = new System.IO.FileStream(s, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                    binaryReader = new System.IO.BinaryReader(fileStream);
                    totBytes = new System.IO.FileInfo(s).Length;
                    buffer = binaryReader.ReadBytes((Int32)totBytes);
                }
                fileStream.Close();
                fileStream.Dispose();
                binaryReader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error While Uploading the images, try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            return buffer;
        }
        private byte[] getFileForUpdate(ref string _fileName)
        {
            System.IO.FileStream fileStream = null;
            System.IO.BinaryReader binaryReader = null;
            string strFileName = null;
            byte[] buffer = null;
            long totBytes = 0;
            try
            {
                if (lstFileColl.Items.Count <= 1)
                    return buffer;

                foreach (string s in lstFileColl.Items)
                {
                    strFileName = s;
                    _fileName = s;
                    fileStream = new System.IO.FileStream(s, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                    binaryReader = new System.IO.BinaryReader(fileStream);
                    totBytes = new System.IO.FileInfo(s).Length;
                    buffer = binaryReader.ReadBytes((Int32)totBytes);
                }
                fileStream.Close();
                fileStream.Dispose();
                binaryReader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error While Uploading the images, try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            return buffer;
        }

        private byte[] getImageFromList(string _fileName)
        {
            System.IO.FileStream fileStream = null;
            System.IO.BinaryReader binaryReader = null;
            byte[] buffer = null;
            try
            {
                long totBytes = 0;
                fileStream = new System.IO.FileStream(_fileName, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                binaryReader = new System.IO.BinaryReader(fileStream);
                totBytes = new System.IO.FileInfo(_fileName).Length;
                buffer = binaryReader.ReadBytes((Int32)totBytes);
                fileStream.Close();
                fileStream.Dispose();
                binaryReader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error While Uploading the images, try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            return buffer;
        }
        private byte[] getFile(ref string _fileName)
        {
            System.IO.FileStream fileStream = null;
            System.IO.BinaryReader binaryReader = null;
            byte[] buffer = null;
            try
            {
                OpenFileDialog op1 = new OpenFileDialog();
                op1.Multiselect = true;
                op1.ShowDialog();
                long totBytes = 0;

                if (op1.FileNames.Count() != 0)
                {
                    foreach (string sFile in op1.FileNames)
                    {
                        string[] strColl = sFile.Split('\\');
                        string strName = strColl[strColl.Length - 1];

                        if (strName.Contains("."))
                        {
                            fileStream = new System.IO.FileStream(sFile, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                            binaryReader = new System.IO.BinaryReader(fileStream);
                            totBytes = new System.IO.FileInfo(sFile).Length;
                            buffer = binaryReader.ReadBytes((Int32)totBytes);
                            strfileColl.Add(sFile);
                            ListViewItem lstItem = new ListViewItem();
                            lstItem.Text = strName;
                            lstItem.Tag = buffer;
                            lstFileColl.Items.Add(lstItem);                            
                        }
                        else
                            MessageBox.Show("Attached filename does not contain file extension, Please attach files with extensions", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    fileStream.Close();
                    fileStream.Dispose();
                    binaryReader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error While Uploading the images, try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return buffer;
        }

        private byte[] getImage(ref string _fileName)
        {
            System.IO.FileStream fileStream = null;
            System.IO.BinaryReader binaryReader = null;
            byte[] buffer = null;
            //lstRDPUploadedFiles.Items.Clear();
            try
            {
                OpenFileDialog op1 = new OpenFileDialog();
                op1.Multiselect = true;
                op1.ShowDialog();
                long totBytes = 0;
                if (op1.FileNames.Count() != 0)
                {
                    foreach (string s in op1.FileNames)
                    {
                        if (s.Contains("."))
                        {
                            string[] strColl = s.Split('\\');
                            string fileName = strColl[strColl.Length - 1];
                            fileStream = new System.IO.FileStream(s, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                            binaryReader = new System.IO.BinaryReader(fileStream);
                            totBytes = new System.IO.FileInfo(s).Length;
                            buffer = binaryReader.ReadBytes((Int32)totBytes);
                            // lstRDPUploadedFiles.Items.Add(buffer);

                            ListViewItem lstItem = new ListViewItem();
                            lstItem.Text = fileName;
                            lstItem.Tag = buffer;
                            lstRDPUploadedFiles.View = View.LargeIcon;
                            imageList1.ImageSize = new Size(32, 32);
                            //imageList1.LargeImageList = imageList1;
                            lstRDPUploadedFiles.Items.Add(lstItem);
                        }
                        else
                            MessageBox.Show("Attached filename does not contain file extension, Please attach files with extensions", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                    fileStream.Close();
                    fileStream.Dispose();
                    binaryReader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error While Uploading the images, try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            return buffer;
        }
        byte[] attFile = null;
        string attFileName = string.Empty;
        ImageList imageList1 = new ImageList();
        private void btnRDPFileUpload_Click(object sender, EventArgs e)
        {
            attFile = getImage(ref attFileName);
        }
        string projStage = null;
        public string setProjectStages
        {
            get
            {
                return projStage;
            }
            set
            {
                this.projStage = value;
            }
        }
        private Boolean ValidateReceivedDoc()
        {
            Boolean recDocChk = true;
            int sdNeedDaysLen = txtNeedDays.Text.Length;
            Int16 loopCounter = 0;
            if (txtRDPRefNo.Text == "")
            {
                MessageBox.Show("Please enter the document Reference No ");
                txtRDPRefNo.Focus();
                recDocChk = false;
                return recDocChk;
            }

            while (loopCounter < sdNeedDaysLen - 1)
            {
                if (!Char.IsDigit(txtNeedDays.Text, loopCounter))
                {
                    MessageBox.Show("Only Numbers or Digits are allowed");
                    txtNeedDays.Text = "";
                    txtNeedDays.Focus();
                    recDocChk = false;
                    return recDocChk;
                }
                loopCounter++;
            }

            if (dtpRDP_dateofdoc.Checked == false)
            {
                MessageBox.Show("Please enter the date of document ");
                dtpRDP_dateofdoc.Focus();
                recDocChk = false;
                return recDocChk;
            }
            if (dtpRDP_dateofrec.Checked == false)
            {
                MessageBox.Show("Please enter the date when the document was received");
                dtpRDP_dateofrec.Focus();
                recDocChk = false;
                return recDocChk;
            }
            if (txtRDPSubject.Text == "")
            {
                MessageBox.Show("Please enter the subject of the document.");
                txtRDPSubject.Focus();
                recDocChk = false;
                return recDocChk;
            }

            //if (_stageID == 2)
            //{
            //    if (cmbRDPFrom.Text == "")
            //    {
            //        MessageBox.Show("Please select received from");
            //        cmbRDPFrom.Focus();
            //        recDocChk = false;
            //        return recDocChk;
            //    }
            //}

            //if (_stageID != 2)
            //{
            //    if (cmbRDPFrom.Text == "")
            //    {
            //        MessageBox.Show("Please select received from");
            //        cmbRDPFrom.Focus();
            //        recDocChk = false;
            //        return recDocChk;
            //    }
            //}
            return recDocChk;
        }

        string userName = null;
        private void btnRDPSubmit_Click(object sender, EventArgs e)
        {
            if (userRightsColl.Contains("21"))    //   * Edit Document Details
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }
            Boolean chkCntrls = false;
            chkCntrls = ValidateReceivedDoc();
            if (chkCntrls == false)
                return;

            if (dtpRDP_dateofrec.Checked == true)
            {
                if (dtpRDP_dateofrec.Value < dtpRDP_dateofdoc.Value)
                {
                    MessageBox.Show("Date of received should not be less than date of document");
                    dtpRDP_dateofrec.Checked = false;
                    dtpRDP_dateofrec.Focus();
                    return;
                }
            }
            if (cmbCompany.SelectedValue == null)
            {
                MessageBox.Show("Company Name can not be left blank, Please select a company name");
                cmbCompany.Focus();
                return;
            }
            if (chkSaveMode == false)
            {
                if (checkDuplicateRefNo() == false)
                    return;
                if (lstFileColl.Items.Count != 0)
                {
                    SaveDocumentReceivedInfo();
                }
                else
                {
                    MessageBox.Show("Attachment cannot be blank. Please attach a file. Saving of the Received Document is not allowed without an attached file.");
                    lstFileColl.Focus();
                }
            }
            else
            {
                if (lstFileColl.Items.Count != 0)
                {
                    UpdateReceiveDocumentInfo(_stageID);
                }
                else
                {
                    MessageBox.Show("Attachment cannot be blank. Please attach a file. Saving of the Received Document is not allowed without an attached file.");
                    lstFileColl.Focus();
                }
            }
        }

        private void SaveDocumentReceivedInfo()
        {
            int docId = 0;

            using (SqlConnection sqlConn = new SqlConnection(strCon))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    try
                    {
                        cmd.CommandText = @"Select MAX(doc_id) FROM DOCUMENTS";
                        cmd.CommandTimeout = 80;
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        docId = Convert.ToInt32(cmd.ExecuteScalar());
                        docId = docId + 1;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error occurred while fetching the records from the database.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                    finally
                    {
                        sqlConn.Close();
                    }
                }
            }
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        if (lstFileColl.Items.Count == 0)
                        {
                            cmd.CommandTimeout = 80;
                            cmd.CommandText = @"Insert Into DOCUMENTS(doc_id,doc_category_id,doc_type_id, proj_id, stage_id, doc_status_id,ref_no,cross_ref_no,doc_date,doc_issue_date,days_to_act,subject,create_date,Create_User,co_id)" +
                            " values(@docid,@doccatId,@doctypeId,@projId,@stageId,@docStatusId,@refNo,@crsRefNo,@dateofDoc,@docRecdate,@daystoact,@Docsubject,@createDate,@createUser,@cmpID)";
                          
                            cmd.Parameters.AddWithValue("@docid", docId);
                            cmd.Parameters.AddWithValue("@doccatId", 2);
                            cmd.Parameters.AddWithValue("@doctypeId", cmbRDPDocType.SelectedValue);
                            cmd.Parameters.AddWithValue("@projId", _projId);
                            cmd.Parameters.AddWithValue("@stageId", _stageID);
                            cmd.Parameters.AddWithValue("@docStatusId", cmbStatus.SelectedValue);
                            cmd.Parameters.AddWithValue("@refNo", txtRDPRefNo.Text.Trim());
                            cmd.Parameters.AddWithValue("@crsRefNo", cmbRDPDocRefNoReply.Text);                            

                            cmd.Parameters.AddWithValue("@dateofDoc", dtpRDP_dateofdoc.Value.ToString("dd/MMM/yyyy"));
                            cmd.Parameters.AddWithValue("@docRecdate", dtpRDP_dateofrec.Value.ToString("dd/MMM/yyyy"));

                            if (txtNeedDays.Text != "")
                            { cmd.Parameters.AddWithValue("@daystoact", Convert.ToInt16(txtNeedDays.Text)); }
                            else
                            { cmd.Parameters.AddWithValue("@daystoact", 0); }
                            cmd.Parameters.AddWithValue("@Docsubject", txtRDPSubject.Text);

                            cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                            cmd.Parameters.AddWithValue("@createUser", _userName);

                            cmd.Parameters.AddWithValue("@cmpID", cmbCompany.SelectedValue);

                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                           
                        }
                        else
                        {
                            string FileName = strfileColl[0];
                            byte[] fileImage = getImageFromList(FileName);
                            string[] attFileColl = FileName.Split('\\');
                            string _fileName = attFileColl[attFileColl.Length - 1];
                            if (_fileName.Trim() != "")
                            {
                                _fileName = CheckArabicCharactersInFileName(_fileName);
                                string specialChars = "`~!@#$%^&*(){}:<>?|[];";
                                foreach (char item in specialChars)
                                {
                                    _fileName = _fileName.Replace(item.ToString(), "");
                                }
                            }

                            cmd.CommandTimeout = 80;
                            cmd.CommandText = @"Insert Into DOCUMENTS(doc_id,doc_category_id,doc_type_id, proj_id, stage_id, doc_status_id,ref_no,cross_ref_no,doc_date,doc_issue_date, attfile,attFileName,days_to_act,subject,co_id,create_date,Create_User,filePath)" +
                            " values(@docid,@doccatId,@doctypeId,@projId,@stageId,@docStatusId,@refNo,@crsRefNo,@dateofDoc,@docRecdate,@attFile,@attFileName,@daystoact,@Docsubject,@cmpID,@createDate,@createUser,@filePath)"; 
                            
                            cmd.Parameters.AddWithValue("@docid", docId);
                            cmd.Parameters.AddWithValue("@doccatId", 2);
                            cmd.Parameters.AddWithValue("@doctypeId", cmbRDPDocType.SelectedValue);
                            cmd.Parameters.AddWithValue("@projId", _projId);
                            cmd.Parameters.AddWithValue("@stageId", _stageID);
                            cmd.Parameters.AddWithValue("@docStatusId", cmbStatus.SelectedValue);
                            cmd.Parameters.AddWithValue("@refNo", txtRDPRefNo.Text);
                            cmd.Parameters.AddWithValue("@crsRefNo", cmbRDPDocRefNoReply.Text);
                            cmd.Parameters.AddWithValue("@filePath", docId + "_" + txtRDPRefNo.Text.Trim());
                             
                            cmd.Parameters.AddWithValue("@dateofDoc", dtpRDP_dateofdoc.Value.ToString("dd/MMM/yyyy"));
                            cmd.Parameters.AddWithValue("@docRecdate", dtpRDP_dateofrec.Value.ToString("dd/MMM/yyyy"));
                            
                            cmd.Parameters.AddWithValue("@attFile", fileImage);                               
                            cmd.Parameters.AddWithValue("@attFileName", _fileName);
                          
                            if (txtNeedDays.Text != "")
                            { cmd.Parameters.AddWithValue("@daystoact", Convert.ToInt16(txtNeedDays.Text)); }
                            else
                            { cmd.Parameters.AddWithValue("@daystoact", 0); }
                            cmd.Parameters.AddWithValue("@Docsubject", txtRDPSubject.Text);
                            cmd.Parameters.AddWithValue("@cmpID", cmbCompany.SelectedValue);

                            cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                            cmd.Parameters.AddWithValue("@createUser", _userName);

                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();                            
                        }

                        foreach (ListViewItem item in lstRDPUploadedFiles.Items)
                        {
                            using (SqlCommand command = new SqlCommand())
                            {
                                command.CommandTimeout = 80;
                                command.CommandText = @"INSERT INTO Attachments(attFileName, attFile,doc_ID,create_date,create_user,filePath) VALUES (@FileName, @File,@docID,@createDate,@createUser,@filePath)";

                                command.Connection = sqlConn;
                                string fileName = CheckArabicCharactersInFileName(item.Text);
                                string specialChars = "`~!@#$%^&*(){}:<>?|[];";
                                foreach (char fItem in specialChars)
                                {
                                    fileName = fileName.Replace(fItem.ToString(), "");
                                }
                                command.Parameters.AddWithValue("@FileName", fileName);
                                command.Parameters.AddWithValue("@File", item.Tag);
                                command.Parameters.AddWithValue("@docID", docId);
                                command.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                                command.Parameters.AddWithValue("@createUser", _userName);
                                command.Parameters.AddWithValue("@filePath", docId + "_" + fileName);
                                command.ExecuteNonQuery();
                                command.Dispose();
                            }
                        }
                        MessageBox.Show("Received Document details added Succesfully");
                        this.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Insert Documnt records, Try again." + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        //Added by Varun on 01 Dec 2015
        private string CheckArabicCharactersInFileName(string fileName)
        {
            StringBuilder strBuildFileName = new StringBuilder();
            foreach (char c in fileName)
            {
                if (c >= 32 && c <= 126)
                {
                    strBuildFileName.Append(c);
                }

            }
            string fileNameWithoutSpace = strBuildFileName.ToString().Replace(" ", "").ToString();
            if (fileNameWithoutSpace.Split('.')[0].Length == 0)
                fileName = "FileName_With_Arabic_Text." + fileName.Split('.')[1];
            else
                fileName = fileNameWithoutSpace;
            return fileName;
        }

        private void btnRDPRemoveAttachment_Click(object sender, EventArgs e)
        {
            if (lstRDPUploadedFiles.Items.Count > 0 && lstRDPUploadedFiles.SelectedIndices.Count == 0)
                MessageBox.Show("No Item is selected, Please select an Item", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
            {
                DialogResult dlgResult = DialogResult.Yes;
                dlgResult = MessageBox.Show("Are you sure you want to DELETE this Document?", "Delete Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (dlgResult.ToString() == "Yes")
                {
                    lstRDPUploadedFiles.Items.Remove(lstRDPUploadedFiles.SelectedItems[0]);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Contacts.frmContactPerson contacts = new Contacts.frmContactPerson(userRightsColl, _userName, false);
            contacts.StartPosition = FormStartPosition.CenterParent;
            contacts.ShowDialog();
        }
        Boolean chkSaveMode = false;
        string loadedFileInlist = string.Empty;
        CommonClass gnrlCls = new CommonClass("");
        private void ReceivedDocProperties_Load(object sender, EventArgs e)
        {
            //if (_docId != 0)
            //{
            //    if (userRightsColl.Contains("21"))
            //    {
            //        MessageBox.Show("You have no privilege,Contact administrator");
            //        return;
            //    }
            //}
            //if (_docId == 0)
            //{
            //    if (userRightsColl.Contains("20"))
            //    {
            //        MessageBox.Show("You have no privilege,Contact administrator");
            //        return;
            //    }
            //}

            dalObj = new DAL();
            lstRDPUploadedFiles.Items.Clear();

            dalObj.PopulateComboBox(cmbRDPDocType, "SELECT doc_type_id,doc_type_name From [DocumentType]", "doc_type_id", "doc_type_name");
            cmbRDPDocType.SelectedIndex = 0;

            string sqlQuery = null;
            //if (_stageID == 2)
            //{
            //    dalObj.PopulateComboBox(cmbRDPFrom, "SELECT Contacts.employee_id, Contacts.FirstName + ' ' + Contacts.LastName AS PersonName FROM Contacts join COMPANY on COMPANY.co_id=Contacts.co_id join COMPANY_CAT on COMPANY_CAT.co_category_id=COMPANY.co_category_id " +
            //    " where COMPANY_CAT.co_category_id=4 or COMPANY_CAT.co_category_id=1 Order by FirstName", "employee_id", "PersonName"); //
            //    cmbRDPFrom.SelectedIndex = -1;
            //}

            dalObj.PopulateComboBox(cmbStatus, "SELECT [DocumentStatus].[doc_status_id], [DocumentStatus].[doc_status_name] FROM [DocumentStatus] ORDER BY [doc_status_id]", "doc_status_id", "doc_status_name");
            cmbStatus.SelectedIndex = 3;

            if (_stageID != 2)
            {
                sqlQuery = @"SELECT co_id, co_name FROM COMPANY ORDER BY co_name";
            }
            else
            {
                sqlQuery = @"SELECT co_id, co_name FROM COMPANY where (co_name LIKE '%PWA%') ORDER BY co_name";
                //lblReceFrom.Visible = false;
                //cmbRDPFrom.Visible = false;
                //label3.Visible = false;
                //button1.Visible = false;
                //button4.Visible = false;
                label9.Text = "Department";
                button2.Visible = false;
                btnCmpRef.Visible = false;
                lblRDPStatus.Visible = false;
                cmbStatus.Visible = false;
                chkBoxRDPNoReply.Visible = false;
                lblRDPReply.Visible = false;
                txtNeedDays.Visible = false;
                lblDays.Visible = false;
            }
            gnrlCls.PopulateComboBox(cmbCompany, sqlQuery, "co_id", "co_name");
            cmbCompany.SelectedIndex = -1;

            dalObj.PopulateComboBox(cmbRDPDocRefNoReply, "SELECT ref_no FROM Documents Where Proj_id = " + _projId + "  and doc_category_id = 1 and cross_ref_no is not null and date_id is null", null, "ref_no");
            cmbRDPDocRefNoReply.SelectedIndex = -1;

            if (chkUpdateMode == true)
            {
                GetRecevedDocumentsData();
            }

            //attFile = getImageForUpdate(ref attFileName);
            // if (lstRDPUploadedFiles.Items.Count >0)
            //loadedFileInlist = lstRDPUploadedFiles.Items[0].ToString();            

        }

        Dictionary<int, string> existedRecAttachments = new Dictionary<int, string>();

        private void GetRecevedDocumentsData()
        {
            int docID = 0;
            SqlConnection sqlConn = new SqlConnection(strCon);
            try
            {
                sqlConn.Open();

                string sqlQuery = null;

                //if (_stageID == 2)
                //{
                //    sqlQuery = "SELECT DOCUMENTS.doc_id, DOCUMENTS.doc_category_id, DOCUMENTS.doc_type_id, DOCUMENTS.employee_id, DOCUMENTS.doc_status_id, " +
                //    " DOCUMENTS.ref_no, DOCUMENTS.cross_ref_no, DOCUMENTS.subject, DOCUMENTS.doc_date, DOCUMENTS.doc_issue_date, " +
                //    " DOCUMENTS.days_to_act, DOCUMENTS.no_need_to_reply, DOCUMENTS.remarks, DOCUMENTS.attFileName, DOCUMENTS.attFile, " +
                //    " DocumentCategory.doc_category_name, DocumentStatus.doc_status_name, DocumentType.doc_type_name, Contacts.FirstName, Contacts.LastName, " +
                //    " COMPANY.co_name FROM DOCUMENTS INNER JOIN DocumentCategory ON DOCUMENTS.doc_category_id = DocumentCategory.doc_category_id FULL OUTER JOIN " +
                //    " DocumentType ON DOCUMENTS.doc_type_id = DocumentType.doc_type_id FULL OUTER JOIN DocumentStatus ON DOCUMENTS.doc_status_id = DocumentStatus.doc_status_id FULL OUTER JOIN" +
                //    " Contacts ON DOCUMENTS.employee_id = Contacts.employee_id FULL OUTER JOIN COMPANY ON DOCUMENTS.co_id = COMPANY.co_id WHERE (DOCUMENTS.doc_id = " + _docId + ") ";
                //}
                //else
                //{
                    sqlQuery = "SELECT DOCUMENTS.doc_id, DOCUMENTS.doc_category_id, DOCUMENTS.doc_type_id, DOCUMENTS.employee_id,DOCUMENTS.doc_status_id, " +
                    " DOCUMENTS.ref_no, DOCUMENTS.cross_ref_no, DOCUMENTS.subject, DOCUMENTS.doc_date, DOCUMENTS.doc_issue_date, " +
                    " DOCUMENTS.days_to_act, DOCUMENTS.no_need_to_reply, DOCUMENTS.remarks, DOCUMENTS.attFileName, DOCUMENTS.attFile, " +
                    " DocumentCategory.doc_category_name, DocumentStatus.doc_status_name, DocumentType.doc_type_name, " +
                    " COMPANY.co_name FROM DOCUMENTS INNER JOIN DocumentCategory ON DOCUMENTS.doc_category_id = DocumentCategory.doc_category_id INNER JOIN " +
                    " DocumentType ON DOCUMENTS.doc_type_id = DocumentType.doc_type_id INNER JOIN DocumentStatus ON DOCUMENTS.doc_status_id = DocumentStatus.doc_status_id " +
                    " INNER JOIN COMPANY ON DOCUMENTS.co_id = COMPANY.co_id WHERE (DOCUMENTS.doc_id = " + _docId + ") ";
                //}


                SqlCommand sqlCommand = new SqlCommand(sqlQuery, sqlConn);
                SqlDataReader sqlReader = sqlCommand.ExecuteReader();
                if (sqlReader.HasRows)
                {
                    chkSaveMode = true;
                    while (sqlReader.Read())
                    {
                        docID = Convert.ToInt32(sqlReader[0].ToString());
                        txtRDPRefNo.Text = sqlReader[5].ToString();
                        txtRDPSubject.Text = sqlReader[7].ToString();
                        cmbRDPDocType.Text = sqlReader[17].ToString();
                        cmbRDPDocRefNoReply.Text = sqlReader[6].ToString();
                        //if (_stageID == 2)
                        //{
                        //    cmbRDPFrom.Text = sqlReader[18].ToString() + " " + sqlReader[19].ToString();
                        //}
                        txtNeedDays.Text = sqlReader[10].ToString();

                        ListViewItem lstItem = new ListViewItem();
                        lstItem.Text = sqlReader[13].ToString();
                        if (sqlReader[14].ToString() != "")
                        {
                            lstItem.Tag = (byte[])sqlReader[14];
                            lstFileColl.Items.Add(lstItem);
                        }

                        //lstFileColl.Items.Add(sqlReader[13].ToString());
                        cmbStatus.Text = sqlReader[16].ToString();
                        dtpRDP_dateofdoc.Text = sqlReader[8].ToString();
                        dtpRDP_dateofrec.Text = sqlReader[9].ToString(); 

                        //if (_stageID == 2)
                        //{
                        //    cmbCompany.Text = sqlReader[20].ToString();
                        //}
                        //else
                        //{
                            cmbCompany.Text = sqlReader[18].ToString();
                        //}
                        //dr[1] = sqlReader[9];
                        //dr[2]  = sqlReader[2];
                    }
                }
                sqlReader.Close();
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }

            existedRecAttachments.Clear();

            try
            {
                sqlConn.Open();
                string sqlQuery = "SELECT attFile,attFileName,doc_id,attId FROM Attachments WHERE (doc_id = " + _docId + ")";

                SqlCommand sqlCommand = new SqlCommand(sqlQuery, sqlConn);
                SqlDataReader sqlReader = sqlCommand.ExecuteReader();
                if (sqlReader.HasRows)
                {
                    chkSaveMode = true;
                    while (sqlReader.Read())
                    {
                        docID = Convert.ToInt32(sqlReader[2].ToString());

                        ListViewItem lstItem = new ListViewItem();
                        lstItem.Text = sqlReader[1].ToString();
                        lstItem.Tag = (byte[])sqlReader[0];
                        lstItem.ImageIndex = Convert.ToInt32(sqlReader[3].ToString());
                        lstRDPUploadedFiles.Items.Add(lstItem);

                        existedRecAttachments.Add(Convert.ToInt32(sqlReader[3].ToString()), sqlReader[1].ToString());
                    }
                }
                sqlReader.Close();
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }
        }

        private void updateLogo()
        {
            string _fileName = string.Empty;
            byte[] fileImage = null;

            fileImage = ReadImage(ref _fileName);

            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"UPDATE Logo SET " +
                        " LogoImage = @logo_Image Where LogoID = @lgID";

                        cmd.Parameters.AddWithValue("@lgID", 2);
                        cmd.Parameters.AddWithValue("@logo_Image", fileImage);

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void UpdateReceiveDocumentInfo(int stgID)
        {
            string attFileName = string.Empty;
            string _fileName = string.Empty;
            byte[] fileImage = null;

            if (lstFileColl.Items.Count > 0)
            {
                fileImage = ReadImage(ref _fileName);
            }

            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandTimeout = 80;
                        //if (_stageID == 2)
                        //{
                        if (fileImage == null)
                        {
                            cmd.CommandText = @"UPDATE DOCUMENTS SET " +
                            " doc_category_id = @docCatID ,doc_type_id = @docTypeID,stage_id =@stageId, " +
                            " doc_status_id = @docStatusId,ref_no = @refNo,cross_ref_no = @crsRefNo,subject = @Docsubject,doc_date =@dateofDoc, " +
                            " doc_issue_date = @docRecdate,days_to_act = @daystoact,attFileName = @att_FileName,co_id = @cmpID,update_date = @updateDate," +
                            "update_user = @updateUser,filePath=@filePath Where doc_id = @docId";
                        }
                        else
                        {
                            cmd.CommandText = @"UPDATE DOCUMENTS SET " +
                            " doc_category_id = @docCatID ,doc_type_id = @docTypeID,stage_id =@stageId, " +
                            " doc_status_id = @docStatusId,ref_no = @refNo,cross_ref_no = @crsRefNo,subject = @Docsubject,doc_date =@dateofDoc, " +
                            " doc_issue_date = @docRecdate,days_to_act = @daystoact,attFile = @attFile,attFileName = @att_FileName,co_id = @cmpID,update_date = @updateDate," +
                            "update_user = @updateUser,filePath=@filePath Where doc_id = @docId";
                        }
                        //}
                        //else
                        //{
                        //    cmd.CommandText = @"UPDATE DOCUMENTS SET " +
                        //     " doc_category_id = @docCatID ,doc_type_id = @docTypeID,stage_id =@stageId, " +
                        //     " doc_status_id = @docStatusId,ref_no = @refNo,cross_ref_no = @crsRefNo,subject = @Docsubject,doc_date =@dateofDoc, " +
                        //     " doc_issue_date = @docRecdate,days_to_act = @daystoact,attFile = @attFile,attFileName = @att_FileName,co_id = @cmpID," +
                        //     "update_date = @updateDate,update_user = @updateUser,filePath=@filePath Where doc_id = @docId";
                        //}

                        // co_id = @cmpID

                        cmd.Parameters.AddWithValue("@docid", _docId);
                        cmd.Parameters.AddWithValue("@docCatID", 2);
                        cmd.Parameters.AddWithValue("@docTypeID", cmbRDPDocType.SelectedValue);
                        //cmd.Parameters.AddWithValue("@prjID", projId);
                        cmd.Parameters.AddWithValue("@stageId", _stageID);
                        cmd.Parameters.AddWithValue("@docStatusId", cmbStatus.SelectedValue);
                        cmd.Parameters.AddWithValue("@refNo", txtRDPRefNo.Text.Trim());
                        cmd.Parameters.AddWithValue("@crsRefNo", cmbRDPDocRefNoReply.Text);
                        if (fileImage == null)
                        {
                            cmd.Parameters.AddWithValue("@filePath", DBNull.Value);
                        }
                        else
                        {
                            cmd.Parameters.AddWithValue("@filePath", _docId + "_" + txtRDPRefNo.Text);
                        }
                        //if (_stageID == 2)
                        //{
                        //    cmd.Parameters.AddWithValue("@empID", cmbRDPFrom.SelectedValue);
                        //}
                        cmd.Parameters.AddWithValue("@dateofDoc", dtpRDP_dateofdoc.Value.ToString("dd/MMM/yyyy"));
                        cmd.Parameters.AddWithValue("@docRecdate", dtpRDP_dateofrec.Value.ToString("dd/MMM/yyyy"));
                        if (fileImage == null)
                        {
                            //cmd.Parameters.AddWithValue("@attFile", DBNull.Value);
                            fileImage = new byte[1];
                            cmd.Parameters.AddWithValue("@att_FileName", fileImage);
                        }
                        else
                        {
                            cmd.Parameters.AddWithValue("@attFile", fileImage);
                            if (_fileName != "")
                            {
                                _fileName = CheckArabicCharactersInFileName(_fileName);
                                string specialChars = "`~!@#$%^&*(){}:<>?|[];";
                                foreach (char item in specialChars)
                                {
                                    _fileName = _fileName.Replace(item.ToString(), "");
                                }
                            }
                            cmd.Parameters.AddWithValue("@att_FileName", _fileName);
                        }
                        if (txtNeedDays.Text != "")
                        { cmd.Parameters.AddWithValue("@daystoact", Convert.ToInt16(txtNeedDays.Text)); }
                        else
                        { cmd.Parameters.AddWithValue("@daystoact", 0); }
                        cmd.Parameters.AddWithValue("@Docsubject", txtRDPSubject.Text);

                        cmd.Parameters.AddWithValue("@cmpID", cmbCompany.SelectedValue);

                        cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@updateUser", _userName);

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE DATES records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            attachmentsUpdate();
        }
        private void attachmentsUpdate()
        {
            //if (lstRDPUploadedFiles.Items.Count != 0)
            //{
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand command = new SqlCommand())
                    {
                        command.CommandText = @"DELETE FROM Attachments WHERE doc_Id = @docID";
                        command.CommandTimeout = 80;
                        command.Connection = sqlConn;
                        sqlConn.Open();
                        command.Parameters.AddWithValue("@docID", _docId);
                        command.ExecuteNonQuery();
                        command.Dispose();
                        sqlConn.Close();
                    }
                }
                foreach (ListViewItem attachedFile in lstRDPUploadedFiles.Items)
                {
                    using (SqlConnection sqlConn = new SqlConnection(strCon))
                    {
                        using (SqlCommand command = new SqlCommand())
                        {
                            command.CommandTimeout = 80;
                            command.CommandText = @"INSERT INTO Attachments(attFileName, attFile,doc_ID,create_date,create_user,filePath) VALUES (@FileName, @File,@docID,@createDate,@createUser,@filePath)";
                            command.Connection = sqlConn;
                            sqlConn.Open();
                            string fileName = CheckArabicCharactersInFileName(attachedFile.Text);
                            string specialChars = "`~!@#$%^&*(){}:<>?|[];";
                            foreach (char fItem in specialChars)
                            {
                                fileName = fileName.Replace(fItem.ToString(), "");
                            }
                            command.Parameters.AddWithValue("@FileName", fileName);
                            command.Parameters.AddWithValue("@File", attachedFile.Tag);
                            command.Parameters.AddWithValue("@docID", _docId);
                            command.Parameters.AddWithValue("@filePath", _docId + "_" + fileName);

                            command.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                            command.Parameters.AddWithValue("@createUser", _userName);

                            command.ExecuteNonQuery();
                            command.Dispose();
                            sqlConn.Close();
                        }
                    }
                }
            //}
            MessageBox.Show("Record Updated Sucessfully. ");
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (userRightsColl.Contains("22"))    //      * Delete Document
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            try
            {
                DialogResult dlgResult = DialogResult.Yes;
                dlgResult = MessageBox.Show("Are you sure you want to DELETE this record?", "Delete Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (dlgResult.ToString() == "Yes")
                {
                    using (SqlConnection sqlConn = new SqlConnection(strCon))
                    {
                        using (SqlCommand cmd = new SqlCommand())
                        {
                            sqlConn.Open();
                            cmd.Connection = sqlConn;
                            // "DELETE FROM DOCUMENTS WHERE (proj_id = 949)";
                            cmd.CommandTimeout = 80;
                            cmd.CommandText = @"DELETE FROM DOCUMENTS Where doc_id = @docId";
                            cmd.Parameters.AddWithValue("@docId", _docId);
                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                            
                            cmd.CommandText = @"DELETE FROM ATTACHMENTS Where doc_id=@docId";
                            cmd.Parameters.AddWithValue("@docId", _docId);
                            exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                            MessageBox.Show("Rocords deleted SuccessFully ");
                            this.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while deleting the records.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void lstRDPUploadedFiles_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        if (lstRDPUploadedFiles.SelectedItems.Count != 0)
                        {
                            //attFilename='" + lstRDPUploadedFiles.SelectedItem.ToString() + "' and
                            cmd.CommandTimeout = 80;
                            cmd.CommandText = @"Select attFile From Attachments WHERE attFileName = '" + lstRDPUploadedFiles.SelectedItems.ToString() + "' and doc_Id = " + _docId + " ";

                            sqlConn.Open();
                            cmd.Connection = sqlConn;

                            SqlDataReader dr = cmd.ExecuteReader();
                            while (dr.Read())
                            {
                                byte[] byteArray = (byte[])dr[0];
                                MemoryStream mstream = new MemoryStream();

                                mstream.Write(byteArray, 0, byteArray.Length);
                                mstream.Seek(0, SeekOrigin.Begin);
                                string ext = lstRDPUploadedFiles.SelectedItems.ToString().Split('.')[1];
                                var tempFileName = Path.ChangeExtension(Path.GetTempFileName(), ext);
                                // write the bytes of the file to the temp file
                                File.WriteAllBytes(tempFileName, byteArray);
                                // Ask the system to handle opening of this file
                                Process.Start(tempFileName);
                                mstream.Close();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while selecting the image, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void chkBoxRDPNoReply_CheckedChanged(object sender, EventArgs e)
        {
            if (chkBoxRDPNoReply.Checked == true)
            {
                txtNeedDays.Text = "";
            }

            //Based on Riyas Request on 20/Dec/2016 Doc Status will always remained closed
            //if ((chkBoxRDPNoReply.Checked == true) & (txtNeedDays.Text == ""))
            cmbStatus.SelectedIndex = 3;
            //else if ((chkBoxRDPNoReply.Checked == false) & (txtNeedDays.Text != ""))
            //    cmbStatus.SelectedIndex = 0;
            //else if ((chkBoxRDPNoReply.Checked == false) & (txtNeedDays.Text == ""))
            //    cmbStatus.SelectedIndex = 3;
        }
        private void txtNeedDays_TextChanged(object sender, EventArgs e)
        {
            if (txtNeedDays.Text != "")
            {
                chkBoxRDPNoReply.Checked = false;
            }
            //Based on Riyas Request on 20/Dec/2016 Doc Status will always remained closed
            //if ((chkBoxRDPNoReply.Checked == true) & (txtNeedDays.Text == ""))
            cmbStatus.SelectedIndex = 3;
            //else if ((chkBoxRDPNoReply.Checked == false) & (txtNeedDays.Text != ""))
            //    cmbStatus.SelectedIndex = 0;
            // else if ((chkBoxRDPNoReply.Checked == false) & (txtNeedDays.Text == ""))
            // cmbStatus.SelectedIndex = 2;
        }

        private void dtpRDP_dateofdoc_ValueChanged(object sender, EventArgs e)
        {
            dtpRDP_dateofdoc.CustomFormat = "dd/MMM/yyyy";
            dtpRDP_dateofdoc.Text = dtpRDP_dateofdoc.Value.ToString("dd/MMM/yyy");
            dtpRDP_dateofdoc.Focus();
        }

        private void dtpRDP_dateofrec_ValueChanged(object sender, EventArgs e)
        {
            dtpRDP_dateofrec.CustomFormat = "dd/MMM/yyyy";
            dtpRDP_dateofrec.Text = dtpRDP_dateofrec.Value.ToString("dd/MMM/yyy");
            dtpRDP_dateofrec.Focus();
        }

        private void dtpRDP_dateofdoc_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Delete)
            {
                if (sender is DateTimePicker)
                {
                    dtpRDP_dateofdoc.CustomFormat = " ";
                }
            }
        }
        private void dtpRDP_dateofrec_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Delete)
            {
                if (sender is DateTimePicker)
                {
                    dtpRDP_dateofrec.CustomFormat = " ";
                }
            }
        }
        IList<string> strfileColl = new List<string>();
        private void btnAddFile_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem item in lstFileColl.Items)
            {
                if (item.Text == "")
                {
                    lstFileColl.Items.Clear();
                }
            }
            if (lstFileColl.Items.Count >= 1)
            {
                MessageBox.Show("You can add single file only");
                return;
            }
            string strString = string.Empty;
            if (lstFileColl.Items.Count > 0)
            {
                if (strString == lstFileColl.Items[0].ToString())
                {
                    lstFileColl.Items.RemoveAt(0);
                }
            }
            attFile = getFile(ref attFileName);

        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (lstFileColl.Items.Count > 0 && lstFileColl.SelectedIndices.Count == 0)
                MessageBox.Show("No Item is selected, Please select an Item", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
            {
                DialogResult dlgResult = DialogResult.Yes;
                dlgResult = MessageBox.Show("Are you sure you want to DELETE this Document?", "Delete Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (dlgResult.ToString() == "Yes")
                {
                    foreach (ListViewItem item in lstFileColl.Items)
                    {
                        lstFileColl.Items.Remove(item);
                        lstFileColl.Items.Clear();
                        strfileColl.Clear();
                    }
                }
            }
        }
        
        
        private void lstFileColl_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        if (lstFileColl.SelectedItems[0] != null)
                        {
                            //attFilename='" + lstRDPUploadedFiles.SelectedItem.ToString() + "' and
                            cmd.CommandText = @"Select attFile From DOCUMENTS WHERE attFileName = '" + lstFileColl.SelectedItems[0].ToString() + "' and doc_Id = " + _docId + " ";

                            sqlConn.Open();
                            cmd.Connection = sqlConn;

                            SqlDataReader dr = cmd.ExecuteReader();
                            while (dr.Read())
                            {
                                byte[] byteArray = (byte[])dr[0];
                                MemoryStream mstream = new MemoryStream();

                                mstream.Write(byteArray, 0, byteArray.Length);
                                mstream.Seek(0, SeekOrigin.Begin);
                                string ext = lstFileColl.SelectedItems[0].ToString().Split('.')[1];
                                var tempFileName = Path.ChangeExtension(Path.GetTempFileName(), ext);
                                // write the bytes of the file to the temp file
                                File.WriteAllBytes(tempFileName, byteArray);
                                // Ask the system to handle opening of this file
                                Process.Start(tempFileName);
                                mstream.Close();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while selecting the image, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void lstRDPUploadedFiles_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void lstRDPUploadedFiles_MouseDoubleClick_1(object sender, MouseEventArgs e)
        {
            try
            {
                foreach (ListViewItem item in lstRDPUploadedFiles.Items)
                {
                    if (item.Text.Equals(lstRDPUploadedFiles.SelectedItems[0].Text))
                    {
                        string sName = item.Text;
                        byte[] _image = (byte[])item.Tag;

                        byte[] byteArray = _image;
                        MemoryStream mstream = new MemoryStream();
                        mstream.Write(byteArray, 0, byteArray.Length);
                        mstream.Seek(0, SeekOrigin.Begin);
                        //Modified By Varun on 29th Jan 2014 for opening the file with a specific ext. and to preserve the real name of the file
                        string ext = sName.Substring(sName.ToString().LastIndexOf('.'));
                        StringBuilder strBuild = new StringBuilder();
                        var tempFilePath = Path.ChangeExtension(Path.GetTempFileName(), ext);
                        strBuild.Append(tempFilePath.Substring(0, tempFilePath.LastIndexOf('\\')).ToString());
                        strBuild.Append("\\" + lstRDPUploadedFiles.SelectedItems[0].Text);
                        if (File.Exists(strBuild.ToString()))
                            File.Delete(strBuild.ToString());
                        File.WriteAllBytes(strBuild.ToString(), byteArray);
                        Process.Start(strBuild.ToString());
                        mstream.Close();
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("The process cannot access the file"))
                {
                    MessageBox.Show("Error occurred while opening the pdf file, the file is already opened, close the file and try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void lstFileColl_MouseDoubleClick_1(object sender, MouseEventArgs e)
        {
            try
            {
                foreach (ListViewItem item in lstFileColl.Items)
                {
                    if (item.Text.Equals(lstFileColl.SelectedItems[0].Text))
                    {
                        string sName = item.Text;
                        byte[] _image = (byte[])item.Tag;

                        byte[] byteArray = _image;
                        MemoryStream mstream = new MemoryStream();
                        mstream.Write(byteArray, 0, byteArray.Length);
                        mstream.Seek(0, SeekOrigin.Begin);
                        //Modified By Varun on 29th Jan 2014 for opening the file with a specific ext. and to preserve the real name of the file
                        string ext = sName.Substring(sName.ToString().LastIndexOf('.'));
                        StringBuilder strBuild = new StringBuilder();
                        var tempFilePath = Path.ChangeExtension(Path.GetTempFileName(), ext);
                        strBuild.Append(tempFilePath.Substring(0, tempFilePath.LastIndexOf('\\')).ToString());
                        strBuild.Append("\\" + lstFileColl.SelectedItems[0].Text);
                        if (File.Exists(strBuild.ToString()))
                            File.Delete(strBuild.ToString());
                        File.WriteAllBytes(strBuild.ToString(), byteArray);
                        Process.Start(strBuild.ToString());
                        mstream.Close();
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("The process cannot access the file"))
                {
                    MessageBox.Show("Error occurred while opening the pdf file, the file is already opened, close the file and try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }
        private byte[] ReadImage(ref string imageName)
        {
            byte[] byteArray = null;
            foreach (ListViewItem item in lstFileColl.Items)
            {
                string sName = item.Text;
                imageName = item.Text;
                byte[] _image = (byte[])item.Tag;
                byteArray = _image;
            }
            return byteArray;
        }


        private void txtNeedDays_Leave(object sender, EventArgs e)
        {
            if ((chkBoxRDPNoReply.Checked == true) & (txtNeedDays.Text == ""))
                cmbStatus.SelectedIndex = 3;
            else if ((chkBoxRDPNoReply.Checked == false) & (txtNeedDays.Text != ""))
                cmbStatus.SelectedIndex = 0;

        }
        public static bool IsItNumber(string inputvalue)
        {
            Regex isnumber = new Regex("[^0-9][^-]");
            return !isnumber.IsMatch(inputvalue);
        }

        private void cmbRDPDocRefNoReply_SelectionChangeCommitted(object sender, EventArgs e)
        {
            string tndrStatus = string.Empty;
            int docID = 0;
            SqlConnection sqlConn = new SqlConnection(strCon);
            try
            {
                sqlConn.Open();
                string sqlQuery = "SELECT DOCUMENTS.doc_status_id, [DocumentStatus].doc_status_name, DOCUMENTS.ref_no, DOCUMENTS.cross_ref_no, DOCUMENTS.doc_date, " +
                   " DOCUMENTS.doc_issue_date, DOCUMENTS.proj_id,DOCUMENTS.doc_id FROM [DocumentStatus] INNER JOIN DOCUMENTS ON [DocumentStatus].doc_status_id = DOCUMENTS.doc_status_id " +
                   " WHERE (DOCUMENTS.proj_id = " + _projId + ") AND (DOCUMENTS.ref_no LIKE '" + cmbRDPDocRefNoReply.SelectedText.ToString() + "')";

                SqlCommand sqlCommand = new SqlCommand(sqlQuery, sqlConn);
                SqlDataReader sqlReader = sqlCommand.ExecuteReader();
                if (sqlReader.HasRows)
                {
                    while (sqlReader.Read())
                    {
                        tndrStatus = sqlReader[1].ToString();
                        docID = Convert.ToInt32(sqlReader[7]);
                        MessageBox.Show(tndrStatus);
                    }
                }
                sqlReader.Close();
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }
            DialogResult dlgResult = DialogResult.No;

            if (tndrStatus.Equals("Open"))
            {
                dlgResult = MessageBox.Show("Do you want to close document?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            }
            if (dlgResult.ToString() == "Yes")
            {
                try
                {
                    using (SqlConnection sqlCon = new SqlConnection(strCon))
                    {
                        using (SqlCommand cmd = new SqlCommand())
                        {
                            sqlCon.Open();
                            cmd.Connection = sqlCon;
                            cmd.CommandText = @"UPDATE DOCUMENTS SET " +
                            " doc_status_id = @docStatusId " +
                            " Where doc_id = @docId";

                            cmd.Parameters.AddWithValue("@docStatusId", 4);
                            cmd.Parameters.AddWithValue("@docId", docID);
                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while Updating the UPDATE DATES records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                //FillGridSentDocsInfo(_projId, dgvPTD_Sent, 1);
            }
        }
        public void FillGridSentDocsInfo(int prjId, DataGridView dgGrid, int stageID)
        {
            try
            {
                DataTable finalDt = new DataTable("SentDocTbl");
                finalDt.Columns.Add("File Name");
                finalDt.Columns.Add("Referense No");
                finalDt.Columns.Add("Status");
                finalDt.Columns.Add("DocId");
                using (SqlConnection sqlCon = new SqlConnection(strCon))
                {
                    sqlCon.Open();

                    string sqlQuery = "SELECT DOCUMENTS.subject, DOCUMENTS.ref_no, [Document Status].doc_status_name, DOCUMENTS.attFile AS Expr1, " +
                      " DOCUMENTS.attFilename AS Expr2, DOCUMENTS.doc_id FROM DOCUMENTS INNER JOIN [DocumentStatus] ON DOCUMENTS.doc_status_id = [DocumentStatus].doc_status_id INNER JOIN " +
                      " [DocumentCategory] ON DOCUMENTS.doc_category_id = [DocumentCategory].doc_category_id " +
                      " WHERE ([DocumentCategory].doc_category_name = 'Sent') AND (DOCUMENTS.proj_id = " + prjId + ") AND (DOCUMENTS.stage_id = " + stageID + ")";


                    SqlCommand sqlCommand = new SqlCommand(sqlQuery, sqlCon);
                    SqlDataReader sqlReader = sqlCommand.ExecuteReader();

                    while (sqlReader.Read())
                    {
                        DataRow dr = finalDt.NewRow();
                        dr[0] = sqlReader[4];
                        dr[1] = sqlReader[1];
                        dr[2] = sqlReader[2];
                        dr[3] = sqlReader[5];
                        finalDt.Rows.Add(dr);

                        finalDt.AcceptChanges();
                    }
                    sqlReader.Close();
                }

                BindingSource myBindingSource = new BindingSource(finalDt, null);
                dgGrid.DataSource = myBindingSource;
                dgGrid.Columns[3].Visible = false;
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
        }

        private bool checkDuplicateRefNo()
        {
            bool isPassed = true;
            if (txtRDPRefNo.Text != "")
            {
                SqlConnection sqlConn = new SqlConnection(strCon);
                try
                {
                    sqlConn.Open();
                    string sqlQuery = "SELECT ref_no FROM DOCUMENTS WHERE (ref_no = '" + txtRDPRefNo.Text + "' and proj_id=" + _projId + ")";

                    SqlCommand sqlCommand = new SqlCommand(sqlQuery, sqlConn);
                    SqlDataReader sqlReader = sqlCommand.ExecuteReader();
                    if (sqlReader.HasRows)
                    {
                        MessageBox.Show("Document Reference No. is already used in this project. Please check the document reference No.");
                        txtRDPRefNo.Focus();
                        isPassed = false;
                        return isPassed;
                    }
                }
                catch (Exception ex)
                {
                    string exMsg = ex.Message;
                }
                finally
                {
                    sqlConn.Close();
                }
            }
            return isPassed;
        }

        private void txtRDPRefNo_Leave(object sender, EventArgs e)
        {
            if (checkDuplicateRefNo() == false)
                return;
        }


        private void button2_Click_1(object sender, EventArgs e)
        {
            if (userRightsColl.Contains("25"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }
            frmAddCompanyInfo frmCmp = new frmAddCompanyInfo(userRightsColl, _userName);
            frmCmp.StartPosition = FormStartPosition.CenterScreen;
            frmCmp.ShowDialog();
        }

        private void btnCmpRef_Click(object sender, EventArgs e)
        {
            gnrlCls.PopulateComboBox(cmbCompany, @"SELECT co_id, co_name, block_listed FROM COMPANY ORDER BY co_name", "co_id", "co_name");
        }

        private void cmbRDPFrom_SelectionChangeCommitted(object sender, EventArgs e)
        {
            //string sqlQuery = "SELECT COMPANY.co_id, COMPANY.co_name, Contacts.employee_id " +
            //                 " FROM COMPANY INNER JOIN Contacts ON COMPANY.co_id = Contacts.co_id INNER JOIN COMPANY_CAT ON COMPANY_CAT.co_category_id = COMPANY.co_category_id" +
            //                 " WHERE (Contacts.employee_id = " + cmbRDPFrom.SelectedValue + " and COMPANY_CAT.co_category_id=4)"; // Modified by Varun on 21/Jun/2015 set co_category_id=4 to owner
            //try
            //{
            //    using (SqlConnection sqlConn = new SqlConnection(strCon))
            //    {
            //        sqlConn.Open();
            //        using (SqlCommand cmd = new SqlCommand())
            //        {
            //            cmd.Connection = sqlConn;
            //            cmd.CommandText = sqlQuery;
            //            using (SqlDataReader dr = cmd.ExecuteReader())
            //            {
            //                while (dr.Read())
            //                {
            //                    cmbCompany.Text = dr[1].ToString();
            //                }
            //            }
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show("Error occurred while reading company blocklist, Try again.", ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}

        }
        private Boolean CheckBlockListCompany()
        {
            Boolean blkCmp = false;
            string sqlQuery = "SELECT block_listed From COMPANY WHERE Co_id = '" + cmbCompany.SelectedValue + "'";
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    sqlConn.Open();
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        blkCmp = Convert.ToBoolean(cmd.ExecuteScalar());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while reading company blocklist, Try again.", ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            return blkCmp;
        }
        CommonClass cmnCls = new CommonClass("");
        private void FillCompanyData()
        {
            //if (txtTenderNo.Text != "")
            //{
            //    string sqlQuery = "SELECT employee_id, FirstName + '  ' + LastName AS PersonName, ShortName, AuthorizedRep,co_id FROM Contacts WHERE (AuthorizedRep = 1) AND (co_id = " + cmbCompany.SelectedValue + ")";
            //    cmbRDPFrom.DataSource = null;
            //    gnrlCls.PopulateComboBox(cmbRDPFrom, sqlQuery, "employee_id", "PersonName");
            //}
            if (cmbRDPFrom.Items.Count == 0)
            {
                string sqlQuery = "SELECT employee_id, FirstName + ' ' + LastName AS PersonName, ShortName, AuthorizedRep,co_id FROM Contacts WHERE employee_id =117";

                cmbRDPFrom.DataSource = null;
                gnrlCls.PopulateComboBox(cmbRDPFrom, sqlQuery, "employee_id", "PersonName");
                cmbRDPFrom.SelectedIndex = 0;
            }
            else
            {
                string sqlQuery = "SELECT employee_id, FirstName + ' ' + LastName AS PersonName, ShortName, AuthorizedRep,co_id FROM Contacts WHERE (AuthorizedRep = 1) AND (co_id = " + cmbCompany.SelectedValue + ")";
                //cmbRDPFrom.DataSource = null;               
                //gnrlCls.PopulateComboBox(cmbRDPFrom, sqlQuery, "employee_id", "PersonName");

                cmbRDPFrom.SelectedIndex = -1;
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    sqlConn.Open();
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        SqlDataReader dr = cmd.ExecuteReader();
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                cmbRDPFrom.Text = dr[1].ToString();
                            }
                        }

                    }
                    sqlConn.Close();
                }

                if (cmbRDPFrom.Text == "")
                {
                    string sqlQueryNew = "SELECT employee_id, FirstName + ' ' + LastName AS PersonName, ShortName, AuthorizedRep,co_id FROM Contacts WHERE (AuthorizedRep = 1) AND (co_id = 425)";
                    using (SqlConnection sqlConn = new SqlConnection(strCon))
                    {
                        sqlConn.Open();
                        using (SqlCommand cmd = new SqlCommand())
                        {
                            cmd.Connection = sqlConn;
                            cmd.CommandText = sqlQueryNew;
                            SqlDataReader dr = cmd.ExecuteReader();
                            if (dr.HasRows)
                            {
                                while (dr.Read())
                                {
                                    if (dr[1].ToString().Contains("Authorized"))
                                        cmbRDPFrom.Text = dr[1].ToString();
                                }
                            }
                        }
                        sqlConn.Close();
                    }
                }
            }
        }
        private void cmbCompany_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (CheckBlockListCompany() == true)
            {
                MessageBox.Show("Selected Company " + cmbCompany.Text + " is currently blocklisted", "Block Listed Company Info", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                cmbCompany.SelectedIndex = -1;
                return;
            }
            //else
            //{
            //    FillCompanyData();
            //}
        }

        private void X(string sqlQuery)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    sqlConn.Open();
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        SqlDataReader dr = cmd.ExecuteReader();
                        while (dr.Read())
                        {
                            dr[0].ToString();
                        }
                    }
                    sqlConn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while reading company blocklist, Try again.", ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        char lastChar = ' ';

        private void cmbRDPFrom_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            string strToFind;

            // if first char
            if (lastChar == 0)
                strToFind = ch.ToString();
            else
                strToFind = lastChar.ToString() + ch;

            // set first char
            lastChar = ch;

            // find first item that exactly like strToFind
            int idx = cmbRDPFrom.FindStringExact(strToFind);

            // if not found, find first item that start with strToFind
            if (idx == -1) idx = cmbRDPFrom.FindString(strToFind);

            if (idx == -1) return;

            cmbRDPFrom.SelectedIndex = idx;

            e.Handled = true;
        }
        void comboBox1_GotFocus(object sender, EventArgs e)
        {
            // remove last char before select new item
            lastChar = (char)0;
        }

        private void cmbCompany_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            string strToFind;

            // if first char
            if (lastChar == 0)
                strToFind = ch.ToString();
            else
                strToFind = lastChar.ToString() + ch;

            // set first char
            lastChar = ch;

            // find first item that exactly like strToFind
            int idx = cmbCompany.FindStringExact(strToFind);

            // if not found, find first item that start with strToFind
            if (idx == -1) idx = cmbCompany.FindString(strToFind);

            if (idx == -1) return;

            cmbCompany.SelectedIndex = idx;

            e.Handled = true;
        }
        
    }
}
