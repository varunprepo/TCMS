﻿using System.IO;
using System.Configuration;
namespace TenderTrackingSystem
{
    partial class SentDocProperties
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);

            //if (sUpload == 1)
            //{
            //    foreach (string fileName in Directory.GetFiles(@ConfigurationManager.AppSettings["tmpFilePath"].ToString(), "tmp*.*"))
            //    {
            //        try
            //        {
            //            System.IO.File.Delete(fileName);
            //        }
            //        catch (IOException ex)
            //        {
            //        }
            //    }
            //}           
             
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lblSDPSubject = new System.Windows.Forms.Label();
            this.txtSDPSubject = new System.Windows.Forms.TextBox();
            this.lblSDPDateOfDoc = new System.Windows.Forms.Label();
            this.dtpSentdoc = new System.Windows.Forms.DateTimePicker();
            this.lblSDPDateSent = new System.Windows.Forms.Label();
            this.dtpSentDocRec = new System.Windows.Forms.DateTimePicker();
            this.lblSentTo = new System.Windows.Forms.Label();
            this.cmbSDPSentTo = new System.Windows.Forms.ComboBox();
            this.lblSDPReply = new System.Windows.Forms.Label();
            this.lblSDPStatus = new System.Windows.Forms.Label();
            this.txtSDactdays = new System.Windows.Forms.TextBox();
            this.chkBoxSDPNoResponse = new System.Windows.Forms.CheckBox();
            this.btnSDPFileUpload = new System.Windows.Forms.Button();
            this.btnSDPRemoveAttachment = new System.Windows.Forms.Button();
            this.cmbSentDocRefNo = new System.Windows.Forms.ComboBox();
            this.cmbSentStatus = new System.Windows.Forms.ComboBox();
            this.lblSDPDays = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblCircularNo = new System.Windows.Forms.Label();
            this.btnCmpRef = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.cmbCompany = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.lstFileCollSent = new System.Windows.Forms.ListView();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lstSDPUploadedFiles = new System.Windows.Forms.ListView();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnAddFile = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.btnRDPSubmit = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.cmbTypeOfDoc = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSDPRefNo = new System.Windows.Forms.TextBox();
            this.lblSDPRefNo = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(370, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 15);
            this.label1.TabIndex = 6;
            this.label1.Text = "This is in Reply to Doc Ref No.";
            // 
            // lblSDPSubject
            // 
            this.lblSDPSubject.AutoSize = true;
            this.lblSDPSubject.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSDPSubject.Location = new System.Drawing.Point(29, 93);
            this.lblSDPSubject.Name = "lblSDPSubject";
            this.lblSDPSubject.Size = new System.Drawing.Size(48, 15);
            this.lblSDPSubject.TabIndex = 8;
            this.lblSDPSubject.Text = "Subject";
            // 
            // txtSDPSubject
            // 
            this.txtSDPSubject.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSDPSubject.Location = new System.Drawing.Point(31, 111);
            this.txtSDPSubject.Multiline = true;
            this.txtSDPSubject.Name = "txtSDPSubject";
            this.txtSDPSubject.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtSDPSubject.Size = new System.Drawing.Size(614, 44);
            this.txtSDPSubject.TabIndex = 3;
            // 
            // lblSDPDateOfDoc
            // 
            this.lblSDPDateOfDoc.AutoSize = true;
            this.lblSDPDateOfDoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSDPDateOfDoc.Location = new System.Drawing.Point(29, 172);
            this.lblSDPDateOfDoc.Name = "lblSDPDateOfDoc";
            this.lblSDPDateOfDoc.Size = new System.Drawing.Size(106, 15);
            this.lblSDPDateOfDoc.TabIndex = 10;
            this.lblSDPDateOfDoc.Text = "Date of Document";
            // 
            // dtpSentdoc
            // 
            this.dtpSentdoc.Checked = false;
            this.dtpSentdoc.CustomFormat = " ";
            this.dtpSentdoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpSentdoc.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpSentdoc.Location = new System.Drawing.Point(31, 190);
            this.dtpSentdoc.Name = "dtpSentdoc";
            this.dtpSentdoc.ShowCheckBox = true;
            this.dtpSentdoc.Size = new System.Drawing.Size(182, 21);
            this.dtpSentdoc.TabIndex = 4;
            this.dtpSentdoc.ValueChanged += new System.EventHandler(this.dtpSentdoc_ValueChanged);
            // 
            // lblSDPDateSent
            // 
            this.lblSDPDateSent.AutoSize = true;
            this.lblSDPDateSent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSDPDateSent.Location = new System.Drawing.Point(243, 174);
            this.lblSDPDateSent.Name = "lblSDPDateSent";
            this.lblSDPDateSent.Size = new System.Drawing.Size(61, 15);
            this.lblSDPDateSent.TabIndex = 12;
            this.lblSDPDateSent.Text = "Date Sent";
            // 
            // dtpSentDocRec
            // 
            this.dtpSentDocRec.Checked = false;
            this.dtpSentDocRec.CustomFormat = " ";
            this.dtpSentDocRec.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpSentDocRec.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpSentDocRec.Location = new System.Drawing.Point(246, 192);
            this.dtpSentDocRec.Name = "dtpSentDocRec";
            this.dtpSentDocRec.ShowCheckBox = true;
            this.dtpSentDocRec.Size = new System.Drawing.Size(164, 21);
            this.dtpSentDocRec.TabIndex = 5;
            this.dtpSentDocRec.ValueChanged += new System.EventHandler(this.dtpSentDocRec_ValueChanged);
            this.dtpSentDocRec.Leave += new System.EventHandler(this.dtpSentDocRec_Leave);
            // 
            // lblSentTo
            // 
            this.lblSentTo.AutoSize = true;
            this.lblSentTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSentTo.Location = new System.Drawing.Point(28, 231);
            this.lblSentTo.Name = "lblSentTo";
            this.lblSentTo.Size = new System.Drawing.Size(49, 15);
            this.lblSentTo.TabIndex = 14;
            this.lblSentTo.Text = "Sent To";
            // 
            // cmbSDPSentTo
            // 
            this.cmbSDPSentTo.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSDPSentTo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSDPSentTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSDPSentTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSDPSentTo.FormattingEnabled = true;
            this.cmbSDPSentTo.Location = new System.Drawing.Point(31, 249);
            this.cmbSDPSentTo.Name = "cmbSDPSentTo";
            this.cmbSDPSentTo.Size = new System.Drawing.Size(430, 23);
            this.cmbSDPSentTo.TabIndex = 6;
            this.cmbSDPSentTo.SelectionChangeCommitted += new System.EventHandler(this.cmbSDPSentTo_SelectionChangeCommitted);
            this.cmbSDPSentTo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbSDPSentTo_KeyPress);
            // 
            // lblSDPReply
            // 
            this.lblSDPReply.AutoSize = true;
            this.lblSDPReply.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSDPReply.Location = new System.Drawing.Point(418, 368);
            this.lblSDPReply.Name = "lblSDPReply";
            this.lblSDPReply.Size = new System.Drawing.Size(121, 15);
            this.lblSDPReply.TabIndex = 16;
            this.lblSDPReply.Text = "Need to Reply Within";
            // 
            // lblSDPStatus
            // 
            this.lblSDPStatus.AutoSize = true;
            this.lblSDPStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSDPStatus.Location = new System.Drawing.Point(29, 349);
            this.lblSDPStatus.Name = "lblSDPStatus";
            this.lblSDPStatus.Size = new System.Drawing.Size(101, 15);
            this.lblSDPStatus.TabIndex = 19;
            this.lblSDPStatus.Text = "Document Status";
            this.lblSDPStatus.Click += new System.EventHandler(this.lblSDPStatus_Click);
            // 
            // txtSDactdays
            // 
            this.txtSDactdays.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSDactdays.Location = new System.Drawing.Point(545, 364);
            this.txtSDactdays.Name = "txtSDactdays";
            this.txtSDactdays.Size = new System.Drawing.Size(59, 21);
            this.txtSDactdays.TabIndex = 9;
            this.txtSDactdays.TextChanged += new System.EventHandler(this.txtSDactdays_TextChanged);
            // 
            // chkBoxSDPNoResponse
            // 
            this.chkBoxSDPNoResponse.AutoSize = true;
            this.chkBoxSDPNoResponse.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBoxSDPNoResponse.Location = new System.Drawing.Point(275, 367);
            this.chkBoxSDPNoResponse.Name = "chkBoxSDPNoResponse";
            this.chkBoxSDPNoResponse.Size = new System.Drawing.Size(120, 19);
            this.chkBoxSDPNoResponse.TabIndex = 8;
            this.chkBoxSDPNoResponse.Text = "No need to Reply";
            this.chkBoxSDPNoResponse.UseVisualStyleBackColor = true;
            this.chkBoxSDPNoResponse.CheckedChanged += new System.EventHandler(this.chkBoxSDPCheckResponse_CheckedChanged);
            // 
            // btnSDPFileUpload
            // 
            this.btnSDPFileUpload.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSDPFileUpload.Location = new System.Drawing.Point(527, 452);
            this.btnSDPFileUpload.Name = "btnSDPFileUpload";
            this.btnSDPFileUpload.Size = new System.Drawing.Size(56, 25);
            this.btnSDPFileUpload.TabIndex = 13;
            this.btnSDPFileUpload.Text = "Browse to Upload File";
            this.btnSDPFileUpload.UseVisualStyleBackColor = true;
            this.btnSDPFileUpload.Click += new System.EventHandler(this.btnSDPFileUpload_Click);
            // 
            // btnSDPRemoveAttachment
            // 
            this.btnSDPRemoveAttachment.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSDPRemoveAttachment.Location = new System.Drawing.Point(586, 452);
            this.btnSDPRemoveAttachment.Name = "btnSDPRemoveAttachment";
            this.btnSDPRemoveAttachment.Size = new System.Drawing.Size(62, 25);
            this.btnSDPRemoveAttachment.TabIndex = 14;
            this.btnSDPRemoveAttachment.Text = "Remove Attachment";
            this.btnSDPRemoveAttachment.UseVisualStyleBackColor = true;
            this.btnSDPRemoveAttachment.Click += new System.EventHandler(this.btnSDPRemoveAttachment_Click);
            // 
            // cmbSentDocRefNo
            // 
            this.cmbSentDocRefNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSentDocRefNo.FormattingEnabled = true;
            this.cmbSentDocRefNo.Location = new System.Drawing.Point(373, 60);
            this.cmbSentDocRefNo.Name = "cmbSentDocRefNo";
            this.cmbSentDocRefNo.Size = new System.Drawing.Size(270, 23);
            this.cmbSentDocRefNo.TabIndex = 2;
            // 
            // cmbSentStatus
            // 
            this.cmbSentStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSentStatus.FormattingEnabled = true;
            this.cmbSentStatus.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31"});
            this.cmbSentStatus.Location = new System.Drawing.Point(31, 367);
            this.cmbSentStatus.Name = "cmbSentStatus";
            this.cmbSentStatus.Size = new System.Drawing.Size(182, 23);
            this.cmbSentStatus.TabIndex = 7;
            // 
            // lblSDPDays
            // 
            this.lblSDPDays.AutoSize = true;
            this.lblSDPDays.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSDPDays.Location = new System.Drawing.Point(609, 367);
            this.lblSDPDays.Name = "lblSDPDays";
            this.lblSDPDays.Size = new System.Drawing.Size(34, 15);
            this.lblSDPDays.TabIndex = 30;
            this.lblSDPDays.Text = "Days";
            this.lblSDPDays.Click += new System.EventHandler(this.lblSDPDays_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblCircularNo);
            this.groupBox1.Controls.Add(this.btnCmpRef);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.cmbCompany);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.lstFileCollSent);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.lstSDPUploadedFiles);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.btnCancel);
            this.groupBox1.Controls.Add(this.btnAddFile);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.Controls.Add(this.btnRDPSubmit);
            this.groupBox1.Controls.Add(this.btnDelete);
            this.groupBox1.Controls.Add(this.button4);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.lblSDPDays);
            this.groupBox1.Controls.Add(this.btnSDPRemoveAttachment);
            this.groupBox1.Controls.Add(this.cmbTypeOfDoc);
            this.groupBox1.Controls.Add(this.btnSDPFileUpload);
            this.groupBox1.Controls.Add(this.cmbSentStatus);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtSDPRefNo);
            this.groupBox1.Controls.Add(this.cmbSentDocRefNo);
            this.groupBox1.Controls.Add(this.chkBoxSDPNoResponse);
            this.groupBox1.Controls.Add(this.lblSDPRefNo);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtSDPSubject);
            this.groupBox1.Controls.Add(this.lblSDPSubject);
            this.groupBox1.Controls.Add(this.dtpSentdoc);
            this.groupBox1.Controls.Add(this.txtSDactdays);
            this.groupBox1.Controls.Add(this.lblSDPStatus);
            this.groupBox1.Controls.Add(this.lblSDPDateOfDoc);
            this.groupBox1.Controls.Add(this.lblSDPReply);
            this.groupBox1.Controls.Add(this.dtpSentDocRec);
            this.groupBox1.Controls.Add(this.lblSDPDateSent);
            this.groupBox1.Controls.Add(this.cmbSDPSentTo);
            this.groupBox1.Controls.Add(this.lblSentTo);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(18, 10);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(683, 624);
            this.groupBox1.TabIndex = 31;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Document Sent Information";
            // 
            // lblCircularNo
            // 
            this.lblCircularNo.AutoSize = true;
            this.lblCircularNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblCircularNo.Location = new System.Drawing.Point(598, 195);
            this.lblCircularNo.Name = "lblCircularNo";
            this.lblCircularNo.Size = new System.Drawing.Size(48, 15);
            this.lblCircularNo.TabIndex = 65;
            this.lblCircularNo.Text = "label10";
            // 
            // btnCmpRef
            // 
            this.btnCmpRef.BackgroundImage = global::MDI_ParenrForm.Properties.Resources.Refresh;
            this.btnCmpRef.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnCmpRef.Location = new System.Drawing.Point(607, 306);
            this.btnCmpRef.Name = "btnCmpRef";
            this.btnCmpRef.Size = new System.Drawing.Size(40, 23);
            this.btnCmpRef.TabIndex = 63;
            this.btnCmpRef.UseVisualStyleBackColor = true;
            this.btnCmpRef.Click += new System.EventHandler(this.btnCmpRef_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.button2.Location = new System.Drawing.Point(511, 305);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(93, 23);
            this.button2.TabIndex = 62;
            this.button2.Text = "Add Company";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // cmbCompany
            // 
            this.cmbCompany.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbCompany.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCompany.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCompany.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCompany.FormattingEnabled = true;
            this.cmbCompany.Location = new System.Drawing.Point(31, 306);
            this.cmbCompany.Name = "cmbCompany";
            this.cmbCompany.Size = new System.Drawing.Size(430, 23);
            this.cmbCompany.TabIndex = 60;
            this.cmbCompany.SelectionChangeCommitted += new System.EventHandler(this.cmbCompany_SelectionChangeCommitted);
            this.cmbCompany.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbCompany_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(28, 288);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 15);
            this.label9.TabIndex = 61;
            this.label9.Text = "Company";
            // 
            // lstFileCollSent
            // 
            this.lstFileCollSent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstFileCollSent.Location = new System.Drawing.Point(31, 482);
            this.lstFileCollSent.Name = "lstFileCollSent";
            this.lstFileCollSent.Size = new System.Drawing.Size(305, 68);
            this.lstFileCollSent.TabIndex = 59;
            this.lstFileCollSent.UseCompatibleStateImageBehavior = false;
            this.lstFileCollSent.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.lstFileCollSent_MouseDoubleClick);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(651, 111);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(14, 18);
            this.label6.TabIndex = 58;
            this.label6.Text = "*";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(337, 61);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(14, 18);
            this.label5.TabIndex = 57;
            this.label5.Text = "*";
            // 
            // lstSDPUploadedFiles
            // 
            this.lstSDPUploadedFiles.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstSDPUploadedFiles.Location = new System.Drawing.Point(340, 482);
            this.lstSDPUploadedFiles.Name = "lstSDPUploadedFiles";
            this.lstSDPUploadedFiles.Size = new System.Drawing.Size(307, 68);
            this.lstSDPUploadedFiles.TabIndex = 56;
            this.lstSDPUploadedFiles.UseCompatibleStateImageBehavior = false;
            this.lstSDPUploadedFiles.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.lstSDPUploadedFiles_MouseDoubleClick);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label8.Location = new System.Drawing.Point(453, 457);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 13);
            this.label8.TabIndex = 55;
            this.label8.Text = "Attachment";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label7.Location = new System.Drawing.Point(186, 458);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(27, 13);
            this.label7.TabIndex = 54;
            this.label7.Text = "File";
            // 
            // btnCancel
            // 
            this.btnCancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(275, 452);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(61, 23);
            this.btnCancel.TabIndex = 12;
            this.btnCancel.Text = "Remove";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnAddFile
            // 
            this.btnAddFile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnAddFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddFile.Location = new System.Drawing.Point(219, 452);
            this.btnAddFile.Name = "btnAddFile";
            this.btnAddFile.Size = new System.Drawing.Size(56, 23);
            this.btnAddFile.TabIndex = 11;
            this.btnAddFile.Text = "Browse";
            this.btnAddFile.UseVisualStyleBackColor = true;
            this.btnAddFile.Click += new System.EventHandler(this.btnAddFile_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(467, 254);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(14, 18);
            this.label4.TabIndex = 48;
            this.label4.Text = "*";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(416, 193);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(14, 18);
            this.label3.TabIndex = 47;
            this.label3.Text = "*";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.Red;
            this.label29.Location = new System.Drawing.Point(219, 195);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(14, 18);
            this.label29.TabIndex = 46;
            this.label29.Text = "*";
            // 
            // btnRDPSubmit
            // 
            this.btnRDPSubmit.BackColor = System.Drawing.Color.Maroon;
            this.btnRDPSubmit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRDPSubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRDPSubmit.ForeColor = System.Drawing.Color.White;
            this.btnRDPSubmit.Location = new System.Drawing.Point(31, 580);
            this.btnRDPSubmit.Name = "btnRDPSubmit";
            this.btnRDPSubmit.Size = new System.Drawing.Size(60, 26);
            this.btnRDPSubmit.TabIndex = 10;
            this.btnRDPSubmit.Text = "Save";
            this.btnRDPSubmit.UseVisualStyleBackColor = false;
            this.btnRDPSubmit.Click += new System.EventHandler(this.btnRDPSubmit_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Maroon;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.Color.White;
            this.btnDelete.Location = new System.Drawing.Point(98, 580);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(60, 26);
            this.btnDelete.TabIndex = 11;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.button6_Click);
            // 
            // button4
            // 
            this.button4.BackgroundImage = global::MDI_ParenrForm.Properties.Resources.Refresh;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button4.Location = new System.Drawing.Point(607, 247);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(40, 24);
            this.button4.TabIndex = 41;
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Blue;
            this.button1.Location = new System.Drawing.Point(511, 247);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(91, 24);
            this.button1.TabIndex = 40;
            this.button1.Text = "Add Contact";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // cmbTypeOfDoc
            // 
            this.cmbTypeOfDoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTypeOfDoc.FormattingEnabled = true;
            this.cmbTypeOfDoc.Location = new System.Drawing.Point(451, 193);
            this.cmbTypeOfDoc.Name = "cmbTypeOfDoc";
            this.cmbTypeOfDoc.Size = new System.Drawing.Size(136, 23);
            this.cmbTypeOfDoc.TabIndex = 20;
            this.cmbTypeOfDoc.SelectionChangeCommitted += new System.EventHandler(this.cmbTypeOfDoc_SelectionChangeCommitted);
            this.cmbTypeOfDoc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbTypeOfDoc_EnterKeyPressed);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(448, 172);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 15);
            this.label2.TabIndex = 28;
            this.label2.Text = "Type Of Document";
            // 
            // txtSDPRefNo
            // 
            this.txtSDPRefNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSDPRefNo.Location = new System.Drawing.Point(31, 60);
            this.txtSDPRefNo.Name = "txtSDPRefNo";
            this.txtSDPRefNo.Size = new System.Drawing.Size(300, 21);
            this.txtSDPRefNo.TabIndex = 31;
            this.txtSDPRefNo.Leave += new System.EventHandler(this.txtSDPRefNo_Leave);
            // 
            // lblSDPRefNo
            // 
            this.lblSDPRefNo.AutoSize = true;
            this.lblSDPRefNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSDPRefNo.Location = new System.Drawing.Point(28, 42);
            this.lblSDPRefNo.Name = "lblSDPRefNo";
            this.lblSDPRefNo.Size = new System.Drawing.Size(139, 15);
            this.lblSDPRefNo.TabIndex = 4;
            this.lblSDPRefNo.Text = "Document Refrence No.";
            this.lblSDPRefNo.Click += new System.EventHandler(this.lblSDPRefNo_Click);
            // 
            // SentDocProperties
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FloralWhite;
            this.ClientSize = new System.Drawing.Size(717, 655);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "SentDocProperties";
            this.Text = "Sent Document Properties Window";
            this.Load += new System.EventHandler(this.SentDocProperties_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblSDPSubject;
        private System.Windows.Forms.TextBox txtSDPSubject;
        private System.Windows.Forms.Label lblSDPDateOfDoc;
        private System.Windows.Forms.DateTimePicker dtpSentdoc;
        private System.Windows.Forms.Label lblSDPDateSent;
        private System.Windows.Forms.DateTimePicker dtpSentDocRec;
        private System.Windows.Forms.Label lblSentTo;
        private System.Windows.Forms.ComboBox cmbSDPSentTo;
        private System.Windows.Forms.Label lblSDPReply;
        private System.Windows.Forms.Label lblSDPStatus;
        private System.Windows.Forms.TextBox txtSDactdays;
        private System.Windows.Forms.CheckBox chkBoxSDPNoResponse;
        private System.Windows.Forms.Button btnSDPFileUpload;
        private System.Windows.Forms.Button btnSDPRemoveAttachment;
        private System.Windows.Forms.Label lblSDPRefNo;
        private System.Windows.Forms.TextBox txtSDPRefNo;
        private System.Windows.Forms.ComboBox cmbSentDocRefNo;
        private System.Windows.Forms.ComboBox cmbSentStatus;
        private System.Windows.Forms.Label lblSDPDays;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cmbTypeOfDoc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnRDPSubmit;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnAddFile;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ListView lstSDPUploadedFiles;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListView lstFileCollSent;
        private System.Windows.Forms.Button btnCmpRef;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox cmbCompany;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblCircularNo;
    }
}