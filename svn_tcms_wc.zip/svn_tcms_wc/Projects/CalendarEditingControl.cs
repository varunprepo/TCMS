﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using MDI_ParenrForm; 
using System.Configuration;
using System.Data;

class CalendarEditingControl : DatePicker, IDataGridViewEditingControl
{    
    private bool valueChanged = false;
    int rowIndex;
    DataGridView dataGridView = null;
    public CalendarEditingControl()
    {
        this.Format = DateTimePickerFormat.Short;
    }

    // Implements the IDataGridViewEditingControl.EditingControlFormattedValue 
    // property.
    public object EditingControlFormattedValue
    {
        get
        {
            // return this.Value.ToShortDateString();
            return this.ToShortDateString();
        }
        set
        {
            if (value is String)
            {
                this.Value = DateTime.Parse((String)value);
            }
        }
    }

    private static DataGridView dgv = null;
    private static ComboBox cmb = null;
    private static char chCheckShortList = ' ';
    private static char chCheckIsCircular = ' ';
    public DataGridView DGControl
    {
        get 
        {
            return dgv;
        }
        set 
        {
            CalendarEditingControl.dgv = value;
        }
    }


    public ComboBox CmbCtrl
    {
        get
        {
            return cmb;
        }
        set
        {
            CalendarEditingControl.cmb = value;
        }
    }

    public char CheckShortList
    {
        get
        {
            return chCheckShortList;
        }
        set
        {
            CalendarEditingControl.chCheckShortList = value;
        }
    }

    public char CheckIsCircular
    {
        get
        {
            return chCheckIsCircular;
        }
        set
        {
            CalendarEditingControl.chCheckIsCircular = value;
        }
    }

    // Implements the 
    // IDataGridViewEditingControl.GetEditingControlFormattedValue method.
    public object GetEditingControlFormattedValue(
        DataGridViewDataErrorContexts context)
    {
        return EditingControlFormattedValue;
    }

    // Implements the 
    // IDataGridViewEditingControl.ApplyCellStyleToEditingControl method.
    public void ApplyCellStyleToEditingControl(
        DataGridViewCellStyle dataGridViewCellStyle)
    {
        this.Font = dataGridViewCellStyle.Font;
        this.CalendarForeColor = dataGridViewCellStyle.ForeColor;
        this.CalendarMonthBackground = dataGridViewCellStyle.BackColor;
    }

    // Implements the IDataGridViewEditingControl.EditingControlRowIndex 
    // property.
    public int EditingControlRowIndex
    {
        get
        {
            return rowIndex;
        }
        set
        {
            rowIndex = value;
        }
    }

    // Implements the IDataGridViewEditingControl.EditingControlWantsInputKey 
    // method.
    public bool EditingControlWantsInputKey(
        Keys key, bool dataGridViewWantsInputKey)
    {
        // Let the DateTimePicker handle the keys listed.
        switch (key & Keys.KeyCode)
        {
            case Keys.Left:
            case Keys.Up:
            case Keys.Down:
            case Keys.Right:
            case Keys.Home:
            case Keys.End:
            case Keys.PageDown:
            case Keys.PageUp:
                return true;
            default:
                return false;
        }
    }

    // Implements the IDataGridViewEditingControl.PrepareEditingControlForEdit 
    // method.
    public void PrepareEditingControlForEdit(bool selectAll)
    {
        // No preparation needs to be done.
    }

    // Implements the IDataGridViewEditingControl
    // .RepositionEditingControlOnValueChange property.
    public bool RepositionEditingControlOnValueChange
    {
        get
        {
            return false;
        }
    }

    // Implements the IDataGridViewEditingControl
    // .EditingControlDataGridView property.
    public DataGridView EditingControlDataGridView
    {
        get
        {
            return dataGridView;
        }
        set
        {
            dataGridView = value;
        }
    }

    // Implements the IDataGridViewEditingControl
    // .EditingControlValueChanged property.
    public bool EditingControlValueChanged
    {
        get
        {
            return valueChanged;
        }
        set
        {
            valueChanged = value;
        }
    }
     
    // Implements the IDataGridViewEditingControl
    // .EditingPanelCursor property.
    public Cursor EditingPanelCursor
    {
        get
        {
            return base.Cursor;
        }
    }
    DataGridView dgViewBidders = null;
    ComboBox cmbObj = null;
    private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();
    
    protected override void OnValueChanged(EventArgs eventargs)
    {
        // Notify the DataGridView that the contents of the cell
        // have changed.
        valueChanged = true;
        this.EditingControlDataGridView.NotifyCurrentCellDirty(true);
        base.OnValueChanged(eventargs);
        if (DGControl != null && CmbCtrl != null)
        {
            dgViewBidders = DGControl;
            cmbObj = CmbCtrl;
            chCheckShortList = CheckShortList;
            chCheckIsCircular = CheckIsCircular;
            //DGControl = null;
            //CmbCtrl = null;
            dgViewBidders.BeginInvoke(new DelegateUpdateDataGridView(UpdateDataGridView));
        }
    }

    private void UpdateDataGridView()
    {
        CommonClass comCls = null;
        if (dgViewBidders.ColumnCount == 18)
        {            
            try
            {
                int dateId = Convert.ToInt16(dgViewBidders.Rows[rowIndex].Cells[14].Value);
                int docId = Convert.ToInt16(dgViewBidders.Rows[rowIndex].Cells[15].Value);
                int circularNo = Convert.ToInt16(dgViewBidders.Rows[rowIndex].Cells[16].Value);
                int projID = Convert.ToInt16(dgViewBidders.Rows[rowIndex].Cells[17].Value);

                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                     
                        clsDatabase clsObj = new clsDatabase("");
                        DateTime? docIssueDate = null;
                        //CalendarEditingControl calEdCtrl = new CalendarEditingControl();
                        Object selectedDate = EditingControlFormattedValue;
                        if (selectedDate != null)
                        {
                            docIssueDate = Convert.ToDateTime(selectedDate);
                            clsObj.ExecuteNonQuery("update documents set CircularIssued=1, doc_issue_date='" + docIssueDate + "' where doc_id=" + docId + " and CircularNo =" + circularNo + " AND (stage_id = 2) AND (doc_type_id = 2)", sqlConn); //" and proj_id=" + projId + "                                  
                        }
                        else
                            clsObj.ExecuteNonQuery("update documents set CircularIssued=1, doc_issue_date='" + System.DateTime.Now + "' where doc_id=" + docId + " and CircularNo =" + circularNo + " AND (stage_id = 2) AND (doc_type_id = 2)", sqlConn); //" and proj_id=" + projId +                                                  

                        comCls = new CommonClass("");
                        if (dgViewBidders.Rows[rowIndex].Cells[1].Value.ToString() == "")
                        {
                            int iSNo = comCls.GetMaxInfo("SELECT MAX(sn) FROM TenderDatesInfo WHERE proj_id=" + projID, 'Y');
                            clsObj.ExecuteNonQuery("update TenderDatesInfo set sn=" + iSNo + " where date_id=" + dateId + " and proj_id=" + projID + " AND (stage_id = 2)", sqlConn); //" and proj_id=" + projId + "                                                                      
                        }
                         
                }

                // By Varun on Jan 29 14 Based Faisal request not to refresh the gridview when CollectionFile is checked or unchecked
                //comCls = new CommonClass("");
                //BindingSource bindSource = (BindingSource)dgViewBidders.DataSource;
                //DataTable dtViewBidders = (DataTable)bindSource.DataSource;
                //comCls.LoadCircularOrNonCircularData(2, 'Y', dgViewBidders, projID, cmbObj, null, dtViewBidders,'N','V');                 
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Occurred while Re-Populating the Bidders Informations" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        else
        {
            try
            {
                int dateId = 0;
                int projId = 0;
                if (chCheckShortList == 'S')
                {
                    dateId = Convert.ToInt16(dgViewBidders.Rows[rowIndex].Cells[11].Value);
                    projId = Convert.ToInt16(dgViewBidders.Rows[rowIndex].Cells[12].Value);                                
                }
                else
                {
                    dateId = Convert.ToInt16(dgViewBidders.Rows[rowIndex].Cells[14].Value);
                    projId = Convert.ToInt16(dgViewBidders.Rows[rowIndex].Cells[17].Value);                                
                }
                

                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {                    
                        clsDatabase clsObj = new clsDatabase("");
                        DateTime? docIssueDate = null;                         
                        Object selectedDate = EditingControlFormattedValue;
                        if (selectedDate != null)
                        {
                            docIssueDate = Convert.ToDateTime(selectedDate);                           
                            clsObj.ExecuteNonQuery("update TenderDatesInfo set Tender_Issued=1, ts_tender_issue='" + docIssueDate + "' where date_id=" + dateId + " and proj_id =" + projId + " AND (stage_id = 2)", sqlConn); //" and proj_id=" + projId + "                                  
                        }
                        else
                        {
                            clsObj.ExecuteNonQuery("update documents set Tender_Issued=1, ts_tender_issue='" + System.DateTime.Now + "' where date_id=" + dateId + " and proj_id =" + projId + " AND (stage_id = 2)", sqlConn); //" and proj_id=" + projId +
                        }

                        comCls = new CommonClass("");
                        if (dgViewBidders.Rows[rowIndex].Cells[1].Value.ToString() == "")
                        {
                            int iSNo = comCls.GetMaxInfo("SELECT MAX(sn) FROM TenderDatesInfo WHERE proj_id=" + projId, 'Y');                             
                            clsObj.ExecuteNonQuery("update TenderDatesInfo set sn=" + iSNo + " where date_id=" + dateId + " and proj_id=" + projId + " AND (stage_id = 2)", sqlConn); //" and proj_id=" + projId + "                                                                      
                        }                         
                }
                
                // By Varun on Jan 29 14 Based Faisal request not to refresh the gridview when CollectionFile is checked or unchecked
                //BindingSource bindSource = (BindingSource)dgViewBidders.DataSource;
                //DataTable dtViewBidders = (DataTable)bindSource.DataSource;

                //if (chCheckShortList == '3' && chCheckIsCircular=='C')
                //    comCls.LoadCircularOrNonCircularData(2, 'N', dgViewBidders, projId, cmbObj, null, dtViewBidders, 'N', chCheckShortList);
                //else if (chCheckShortList == '3' && chCheckIsCircular == 'O')
                //    comCls.LoadCircularOrNonCircularData(1, 'N', dgViewBidders, projId, null, null, dtViewBidders, 'N', chCheckShortList);                                
                //else
                //    comCls.LoadCircularOrNonCircularData(3, 'N', dgViewBidders, projId, null, null, dtViewBidders, 'N', chCheckShortList);                 
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Occurred while Re-Populating the Bidders Informations" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
    delegate void DelegateUpdateDataGridView();
   
}
