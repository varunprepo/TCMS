﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using MDI_ParenrForm;
using System.Data.SqlClient;
using TenderTrackingSystem.Contacts;
using TenderTrackingSystem;

namespace MDI_ParenrForm.Projects
{
    public partial class frmAddToShortList : Form
    {
        CommonClass commCls = null;
        int _ProjId = 0;
        int _bidDateID = 0;
        IList<string> userRightsColl = new List<string>();
        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();
        string _userName = string.Empty;
        string mtenderClosingDate = null;

        public frmAddToShortList(IList<string> userRightsCollPrjState,int prjId, string tndrNo, string tndrTitle,string chkCmpFilter,string user,string tenderClosingDate)
        {
            try
            {
                userRightsColl = userRightsCollPrjState;
                InitializeComponent();
                mtenderClosingDate = tenderClosingDate;
                _ProjId = prjId;
                _userName = user;
                commCls = new CommonClass(_userName);

                if (chkCmpFilter != "")
                {
                    string sqlQuery = @"SELECT COMPANY.co_id, COMPANY.co_name, COMPANY.block_listed, COMPANY_TYPE.co_type_id " +
                     " FROM COMPANY INNER JOIN COMPANY_TYPE ON COMPANY.co_type_id = COMPANY_TYPE.co_type_id " +
                     " WHERE (COMPANY.co_category_id<>4) and (COMPANY_TYPE.co_type_id IN (" + chkCmpFilter + ",4)) and COMPANY.co_name <>'' and (COMPANY.co_id <> 425)" +
                     " Order by Co_Name";
                    commCls.PopulateComboBox(cmbCompany, sqlQuery, "co_id", "co_name");

                    string sqlQueryEmp = @"SELECT Contacts.employee_id,Contacts.FirstName + ' ' + Contacts.LastName AS PersonName, COMPANY.co_name, COMPANY_TYPE.co_type_id " +
                    " FROM COMPANY INNER JOIN COMPANY_TYPE ON COMPANY.co_type_id = COMPANY_TYPE.co_type_id INNER JOIN " +
                    " Contacts ON COMPANY.co_id = Contacts.co_id WHERE (COMPANY_TYPE.co_type_id IN (" + chkCmpFilter + ",4)) AND Contacts.AuthorizedRep = 1 AND (COMPANY.co_category_id <> 4) " +
                    " AND (Contacts.employee_id <> 83) AND (Contacts.employee_id <> 122) ORDER BY PersonName";  //
                    commCls.PopulateComboBox(cmbAuthRepresentative, sqlQueryEmp, "employee_id", "PersonName");
                }
                
                txtTenderNo.Text = tndrNo;
                txtProjTitle.Text = tndrTitle;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while filling the Company or Authorized Representative list", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public frmAddToShortList(IList<string> userRightsCollPrjState, int bid_DateId, string tndrNo, string contractTitle, Boolean chkMode, string chkCmpFilter, string user)
        {
            userRightsColl = userRightsCollPrjState;
            InitializeComponent();
            _bidDateID = bid_DateId;
            txtTenderNo.Text = tndrNo;
            txtProjTitle.Text = contractTitle;

            _userName = user;
            commCls = new CommonClass(_userName);
            if (chkCmpFilter != "")
            {
                string sqlQuery = @"SELECT COMPANY.co_id, COMPANY.co_name, COMPANY.block_listed, COMPANY_TYPE.co_type_id " +
                 " FROM COMPANY INNER JOIN COMPANY_TYPE ON COMPANY.co_type_id = COMPANY_TYPE.co_type_id " +
                 " WHERE (COMPANY.co_category_id!=4) and (COMPANY_TYPE.co_type_id IN (" + chkCmpFilter + ",4)) and COMPANY.co_name <>'' and (COMPANY.co_id <> 425)" +
                 " Order by Co_Name";
                commCls.PopulateComboBox(cmbCompany, sqlQuery, "co_id", "co_name");

                string sqlQueryEmp = @"SELECT Contacts.employee_id,Contacts.FirstName + ' ' + Contacts.LastName AS PersonName, COMPANY.co_name, COMPANY_TYPE.co_type_id " +
                " FROM COMPANY INNER JOIN COMPANY_TYPE ON COMPANY.co_type_id = COMPANY_TYPE.co_type_id INNER JOIN " +
                " Contacts ON COMPANY.co_id = Contacts.co_id WHERE (COMPANY_TYPE.co_type_id IN (" + chkCmpFilter + ",4)) AND Contacts.AuthorizedRep = 1 AND (COMPANY.co_category_id <> 4) " +
                " AND (Contacts.employee_id <> 83) AND (Contacts.employee_id <> 122) ORDER BY PersonName";  //
                commCls.PopulateComboBox(cmbAuthRepresentative, sqlQueryEmp, "employee_id", "PersonName");
            }       
        }
        private void GetBidderInfo(int bidID)
        {
            string empname = string.Empty;
            int empID = 0;            
            
            string sqlQuery =  "SELECT TenderDatesInfo.date_id, TenderDatesInfo.proj_id, TenderDatesInfo.stage_id, " +
              " COMPANY.co_name, TenderDatesInfo.co_id, TenderDatesInfo.employee_id, " +
              " Contacts.FirstName + Contacts.LastName AS PersonName FROM TenderDatesInfo INNER JOIN COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id INNER JOIN " +
              " Contacts ON TenderDatesInfo.employee_id = Contacts.employee_id WHERE (TenderDatesInfo.date_id = " + bidID + ")";

            using (SqlConnection sqlCon = new SqlConnection(strCon))
            {
                sqlCon.Open();
                using (SqlCommand sqlComm = new SqlCommand(sqlQuery, sqlCon))
                {
                    using (SqlDataReader dr = sqlComm.ExecuteReader())
                    {
                        while (dr.Read())
                        {                   
                          cmbCompany.SelectedValue = Convert.ToInt16(dr[7].ToString());
                          cmbAuthRepresentative.SelectedValue = Convert.ToInt16(dr[8].ToString());

                          empID = Convert.ToInt16(dr[8].ToString());
                          empname = dr[9].ToString();
                        }
                    }
                }
            }            
        }
        private void cmbAuthorized_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (CheckBlockListCompany() == true)
            {
                MessageBox.Show("Selected Company " + cmbCompany.Text + " is currently blocklisted", "Block Listed Company Info", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                cmbCompany.SelectedIndex = -1;
                return;
            }
            else
            {
                FillCompanyData();
                FillEmpData();
            }
        }
        private void FillEmpData()
        {
            if (txtTenderNo.Text != "")
            {
                try
                {
                    txtCompAddress.Text = "";
                    txtFaxNo.Text = "";
                    txtCompTelNo.Text = "";
                    txtMobileNo.Text = "";
                    txtCompEmailAddress.Text = "";
                    txtCRExpDate.Text = "";
                    txtNationality.Text = "";
                    txtQatariShare.Text = "";
                    txtCRNumber.Text = "";

                    using (SqlConnection sqlConn = new SqlConnection(strCon))
                    {
                        using (SqlCommand cmd = new SqlCommand())
                        {
                            sqlConn.Open();

                            string sqlQuery = "SELECT COMPANY.co_address, COMPANY.co_fax, COMPANY.co_tel,Contacts.MobilePhone,COMPANY.co_email_address,COMPANY.cr_expiry_date,COMPANY.nationality,COMPANY.qatari_share,COMPANY.CRNo,COMPANY.co_city,COMPANY.co_state,COMPANY.co_country,COMPANY.co_zip " +
                            "FROM Contacts INNER JOIN COMPANY ON Contacts.co_id = COMPANY.co_id " +
                            " WHERE (Contacts.employee_id = " + cmbAuthRepresentative.SelectedValue + ")";

                            //string sqlQuery = "SELECT Contacts.employee_id, Contacts.FirstName, Contacts.LastName, Contacts.Company, Contacts.JobTitle, Contacts.MobilePhone, Contacts.FaxNumber, " +
                            //" Contacts.EmailAddress, Contacts.ShortName, Contacts.AuthorizedRep, COMPANY.co_name, Contacts.BusinessPhone, COMPANY.co_address, " +
                            //" COMPANY.cr_expiry_date, Contacts.co_id, COMPANY.co_id AS Expr1 FROM Contacts INNER JOIN COMPANY ON Contacts.co_id = COMPANY.co_id WHERE (COMPANY.co_id = " + cmbCompany.SelectedValue + ")";

                            cmd.Connection = sqlConn;
                            cmd.CommandText = sqlQuery;

                            using (SqlDataReader dr = cmd.ExecuteReader())
                            {
                                while (dr.Read())
                                {
                                    if (dr[0].ToString() != "")
                                        txtCompAddress.Text = dr[0].ToString() + " " + dr[9].ToString() + " " + dr[10].ToString() + " " + dr[11].ToString() + " " + dr[12].ToString();
                                    if (dr[1].ToString() != "")
                                        txtFaxNo.Text = dr[1].ToString();
                                    if (dr[2].ToString() != "")
                                        txtCompTelNo.Text = dr[2].ToString();
                                    if (dr[3].ToString() != "")
                                        txtMobileNo.Text = dr[3].ToString();
                                    if (dr[4].ToString() != "")
                                        txtCompEmailAddress.Text = dr[4].ToString();
                                    if (dr[5].ToString() != "")
                                        txtCRExpDate.Text = Convert.ToDateTime(dr[5]).ToString("dd/MMM/yyyy");
                                    if (dr[6].ToString() != "")
                                        txtNationality.Text = dr[6].ToString();
                                    if (dr[7].ToString() != "")
                                        txtQatariShare.Text = dr[7].ToString();
                                    if (dr[8].ToString() != "")
                                        txtCRNumber.Text = dr[8].ToString();
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while Updating the UPDATE DATES records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }
        CommonClass cmnCls = new CommonClass("");
        private void FillCompanyData()
        {
            if (cmbAuthRepresentative.Items.Count == 0)
            {
                string sqlQuery = "SELECT employee_id, FirstName + ' ' + LastName AS PersonName, ShortName, AuthorizedRep,co_id FROM Contacts WHERE employee_id =117";
                cmbAuthRepresentative.DataSource = null;
                commCls.PopulateComboBox(cmbAuthRepresentative, sqlQuery, "employee_id", "PersonName");
                cmbAuthRepresentative.SelectedIndex = 0;
            }
            else
            {
                string sqlQuery = "SELECT employee_id, FirstName + ' ' + LastName AS PersonName, ShortName, AuthorizedRep,co_id FROM Contacts WHERE (AuthorizedRep = 1) AND (co_id = " + cmbCompany.SelectedValue + ")";
                cmbAuthRepresentative.SelectedIndex = -1;
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    sqlConn.Open();
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        SqlDataReader dr = cmd.ExecuteReader();
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                cmbAuthRepresentative.Text = dr[1].ToString();
                            }
                        }
                        dr.Close();
                    }
                    sqlConn.Close();
                }

                if (cmbAuthRepresentative.Text == "")
                {
                    getAuthorizedEmpInfo();
                }
            }
        }

        private void getAuthorizedEmpInfo()
        {
            string sqlQueryNew = "SELECT employee_id, FirstName + ' ' + LastName AS PersonName, ShortName, AuthorizedRep,co_id FROM Contacts WHERE (AuthorizedRep = 1) AND (employee_id = 117) ";
            using (SqlConnection sqlConn = new SqlConnection(strCon))
            {
                sqlConn.Open();
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlConn;
                    cmd.CommandText = sqlQueryNew;
                    SqlDataReader drAuth = cmd.ExecuteReader();
                    if (drAuth.HasRows)
                    {
                        if (drAuth.Read())
                        {
                            cmbAuthRepresentative.Text = drAuth[1].ToString();
                        }
                    }
                    drAuth.Close();
                }
                sqlConn.Close();
            }
        }
        private Boolean CheckBlockListCompany()
        {
            Boolean blkCmp = false;
            string sqlQuery = "SELECT block_listed From COMPANY WHERE Co_id = '" + cmbCompany.SelectedValue + "'";
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    sqlConn.Open();
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        blkCmp = Convert.ToBoolean(cmd.ExecuteScalar());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while reading company blocklist, Try again.", ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            return blkCmp;
        }
        private void cmbCompany_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (CheckBlockListCompany() == true)
            {
                MessageBox.Show("Selected Company "  + cmbCompany.Text +  " is currently blocklisted", "Block Listed Company Info", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                cmbCompany.SelectedIndex = -1;
                return;
            }
            else
            {
                FillCompanyData();
                FillEmpData();
            }            
        }

        private void cmbAuthRepresentative_SelectionChangeCommitted(object sender, EventArgs e)
        {
            FillEmpData();

            string sqlQuery = "SELECT COMPANY.co_id, COMPANY.co_name, Contacts.employee_id " +
                                 " FROM COMPANY INNER JOIN Contacts ON COMPANY.co_id = Contacts.co_id " +
                                 " WHERE (Contacts.employee_id = " + cmbAuthRepresentative.SelectedValue + ")";
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    sqlConn.Open();
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                cmbCompany.Text = dr[1].ToString();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while reading company blocklist, Try again.", ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        
        private void btnAddNewCompany_Click(object sender, EventArgs e)
        {
            if (userRightsColl.Contains("25"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }
            frmAddCompanyInfo frmCmp = new frmAddCompanyInfo(userRightsColl, _userName);
            frmCmp.StartPosition = FormStartPosition.CenterScreen;
            frmCmp.ShowDialog();
        }

        private void btnAddAuthRep_Click(object sender, EventArgs e)
        {
            if (userRightsColl.Contains("26"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }
            TenderTrackingSystem.Contacts.frmContactPerson frmPerson = new TenderTrackingSystem.Contacts.frmContactPerson(userRightsColl, _userName,false);
            frmPerson.StartPosition = FormStartPosition.CenterScreen;
            frmPerson.ShowDialog();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {             
            if (cmbCompany.SelectedIndex == -1)
            {
                MessageBox.Show("Please Select Company info");
                cmbCompany.Focus();
                return;
            }
            if (cmbAuthRepresentative.SelectedIndex == -1)
            {
                MessageBox.Show("Please Select Authorized Representative info");
                cmbAuthRepresentative.Focus();
                return;
            }
           
            //int stgID = 2;             
            int bid_dateID = 0;         
            bid_dateID = commCls.GetMaxInfo("SELECT MAX(date_id) FROM TenderDatesInfo", 'Y');
            InsertBidderInfo(bid_dateID);                         
        }
        
        private void InsertBidderInfo(int maxbid_dateID)
        {
            string strTndrIssueDate = "01/01/1947";

 
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,employee_id,co_id,create_date,create_user,ts_tender_issue,Tender_Issued) VALUES(@dateId,@projId,@stageId,@empId,@coid,@createDate,@createUser,@tsTenderIssueDate,@tsTenderIssued)";
                        cmd.Parameters.AddWithValue("@dateId", maxbid_dateID);

                        cmd.Parameters.AddWithValue("@tsTenderIssueDate", strTndrIssueDate);
                        cmd.Parameters.AddWithValue("@tsTenderIssued",0);

                        cmd.Parameters.AddWithValue("@projId", _ProjId);
                        cmd.Parameters.AddWithValue("@stageId", 2);
                        cmd.Parameters.AddWithValue("@empId", Convert.ToInt16(cmbAuthRepresentative.SelectedValue));
                        cmd.Parameters.AddWithValue("@coid", Convert.ToInt16(cmbCompany.SelectedValue));                        
                        cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@createUser", _userName);                         
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();                        
                        MessageBox.Show("Company was added to the ShortList Succesfully");
                        this.Close();
                    }
                    sqlConn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Adding the company in short list", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        char lastChar = ' ';
       
        void comboBox1_GotFocus(object sender, EventArgs e)
        {
            // remove last char before select new item
            lastChar = (char)0;
        }     

        private void cmbAuthRepresentative_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            string strToFind;

            // if first char
            if (lastChar == 0)
                strToFind = ch.ToString();
            else
                strToFind = lastChar.ToString() + ch;

            // set first char
            lastChar = ch;

            // find first item that exactly like strToFind
            int idx = cmbAuthRepresentative.FindStringExact(strToFind);

            // if not found, find first item that start with strToFind
            if (idx == -1) idx = cmbAuthRepresentative.FindString(strToFind);

            if (idx == -1) return;

            cmbAuthRepresentative.SelectedIndex = idx;

            e.Handled = true;
        }

        private void cmbCompany_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            string strToFind;

            // if first char
            if (lastChar == 0)
                strToFind = ch.ToString();
            else
                strToFind = lastChar.ToString() + ch;

            // set first char
            lastChar = ch;

            // find first item that exactly like strToFind
            int idx = cmbCompany.FindStringExact(strToFind);

            // if not found, find first item that start with strToFind
            if (idx == -1) idx = cmbCompany.FindString(strToFind);

            if (idx == -1) return;

            cmbCompany.SelectedIndex = idx;

            e.Handled = true;
        }

        private void frmAddToShortList_Load(object sender, EventArgs e)
        {

        }

        
 
    }
}
