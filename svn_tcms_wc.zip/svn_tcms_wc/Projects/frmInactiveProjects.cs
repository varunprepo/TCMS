﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using TenderTrackingSystem;
using DataGridViewAutoFilter;
using System.Data.SqlClient;

namespace MDI_ParenrForm.Projects
{
    public partial class frmInactiveProjects : Form
    {
        static string staticUserName = null;
       

        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();
      
        protected SqlConnection sqlConn;
        protected SqlCommand sqlCom;

        protected SqlDataReader sqlReader;
        private System.Windows.Forms.Label label1;

        CreateCheckBox chkBox = null;
        CheckBox headerCheckBox = null;
        IList<string> userRightsColl = new List<string>();
        string _userName = string.Empty;
        bool _isHeadOfSection = false;
        public frmInactiveProjects(IList<string> userRightsCollInactive, string user, bool isHeadOfSection)
        {
            InitializeComponent();
            userRightsColl = getUserAccessList();
            _userName = user;
            _isHeadOfSection = isHeadOfSection;
        }
        private IList<string> getUserAccessList()
        {
            userRightsColl.Clear();
            SqlConnection sqlConn = new SqlConnection(strCon);

            string sqlQuery = "SELECT  UserAccessRights.AccessID,UserAccessRights.[AccessRights], UserPrivelege.HasPrivelege, UserPrivelege.user_profile_id, UserSecurityProfile.profile_name, USERS.user_id, " +
            " USERS.user_name FROM UserAccessRights INNER JOIN UserPrivelege ON UserAccessRights.AccessID = UserPrivelege.AccessID INNER JOIN " +
            " UserSecurityProfile ON UserPrivelege.user_profile_id = UserSecurityProfile.user_profile_id INNER JOIN " +
            " USERS ON UserSecurityProfile.user_profile_id = USERS.user_profile_id WHERE (UserPrivelege.HasPrivelege = 0) AND (USERS.user_name = '" + _userName + "') ORDER BY UserAccessRights.AccessID";

            try
            {
                sqlConn.Open();
                SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
                SqlDataReader sqlReader = sqlCom.ExecuteReader();
                while (sqlReader.Read())
                {
                    userRightsColl.Add(sqlReader[0].ToString());
                }
                sqlReader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error getting while reading data !" + ex.Message);
            }
            finally
            {
                sqlConn.Close();
            }
            return userRightsColl;
        }
        string filterQuery = string.Empty;
        private void frmInactiveProjects_Load(object sender, EventArgs e)
        {
            if (!userRightsColl.Contains("54"))
            {
                rePopulateDataGridView_Contact_Person_EntryData("");
            }
            else
            {
                if (!userRightsColl.Contains("55"))
                {
                    filterQuery = "'" + "GTC" + "'";
                }
                if (!userRightsColl.Contains("56"))
                {
                    if (filterQuery == "")
                        filterQuery = "'" + "STC" + "'";
                    else
                        filterQuery = filterQuery + "," + "'" + "STC" + "'";

                }
                if (!userRightsColl.Contains("57"))
                {
                    if (filterQuery == "")
                        filterQuery = "'" + "ITC" + "'";
                    else
                        filterQuery = filterQuery + "," + "'" + "ITC" + "'";
                }
                if (!userRightsColl.Contains("58"))
                {
                    if (filterQuery == "")
                        filterQuery = "'" + "MRPSC" + "'";
                    else
                        filterQuery = filterQuery + "," + "'" + "MRPSC" + "'";

                    // filterQuery = filterQuery + "," + "'" + "MRPCS" + "'";
                }
                if (!userRightsColl.Contains("59"))
                {
                    if (filterQuery == "")
                        filterQuery = "'" + "U&EWTC" + "'";
                    else
                        filterQuery = filterQuery + "," + "'" + "U&EWTC" + "'";
                }
                if (!userRightsColl.Contains("60"))
                {
                    if (filterQuery == "")
                        filterQuery = "'" + "WPC" + "'";
                    else
                        filterQuery = filterQuery + "," + "'" + "WPC" + "'";
                }
                if (filterQuery == "")
                    filterQuery = "'" + "NC" + "'";
                else
                    filterQuery = filterQuery + "," + "'" + "NC" + "'";

                //filterQueryMain = filterQuery;

                rePopulateDataGridView_Contact_Person_EntryData(filterQuery);
            }
        }
        private void rePopulateDataGridView_Contact_Person_EntryData(string committesList)
        {
            //InitializeComponent();

            //headerCheckBox = new CheckBox();
            //chkBox = new CreateCheckBox(dgView, headerCheckBox);
            //chkBox.AddHeaderCheckBox();

            if (dgViewInactive.ColumnCount == 0)
            {

                //this.dgvContactPerson.CellContentClick += new DataGridViewCellEventHandler(dgvContactPerson_CellContentClick);


                var col0 = new DataGridViewCheckBoxColumn();
                var col1 = new DataGridViewLinkColumn();    // ();  //DataGridViewLinkColumn
                var col2 = new DataGridViewAutoFilterTextBoxColumn();
                var col3 = new DataGridViewAutoFilterTextBoxColumn();
                var col4 = new DataGridViewAutoFilterTextBoxColumn();
                var col5 = new DataGridViewAutoFilterTextBoxColumn();
                var col6 = new DataGridViewAutoFilterTextBoxColumn();
                var col7 = new DataGridViewAutoFilterTextBoxColumn();
                var col8 = new DataGridViewLinkColumn();
                var col9 = new DataGridViewAutoFilterTextBoxColumn();
                var col10 = new DataGridViewTextBoxColumn();
                var col11 = new DataGridViewTextBoxColumn();

                dgViewInactive.Columns.AddRange(new DataGridViewColumn[] { col1, col2, col3, col4, col5, col6, col7, col8, col9, col10, col11 });

                dgViewInactive.AutoGenerateColumns = false;
                dgViewInactive.AllowUserToAddRows = false;

                //dgView.AutoResizeColumns();

                col0.Name = "chkBxSelect";
                col0.DataPropertyName = "Select";
                col0.HeaderText = "Select";
                col0.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;

                col1.DataPropertyName = "ContractNo";
                col1.HeaderText = "Contract No";
                col1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
                col1.LinkBehavior = LinkBehavior.NeverUnderline;

                col2.DataPropertyName = "ContractTitle";
                col2.HeaderText = "Contract Title";
                col2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
                col2.Width = 140;

                col3.DataPropertyName = "ContractStartDate";
                col3.HeaderText = "Contract StartDate";
                col3.Resizable = System.Windows.Forms.DataGridViewTriState.True;

                col4.DataPropertyName = "ContractEndDate";
                col4.HeaderText = "Contract FinishDate";
                col4.Resizable = System.Windows.Forms.DataGridViewTriState.True;

                col5.DataPropertyName = "Performencebond ExpiryDate";
                col5.HeaderText = "Bond Expiry";
                col5.Resizable = System.Windows.Forms.DataGridViewTriState.True;

                col6.DataPropertyName = "Vendor";
                col6.HeaderText = "Contractor /Vendor";
                col6.Resizable = System.Windows.Forms.DataGridViewTriState.True;

                col7.DataPropertyName = "Type";
                col7.HeaderText = "Type";
                col7.Resizable = System.Windows.Forms.DataGridViewTriState.True;
                col7.Width = 80;

                col8.DataPropertyName = "ProjectCode";
                col8.HeaderText = "Project Code";
                col8.Resizable = System.Windows.Forms.DataGridViewTriState.True;
                col8.Width = 130;
                col8.LinkBehavior = LinkBehavior.HoverUnderline;

                col9.DataPropertyName = "TypeOfContract";
                col9.HeaderText = "TypeOf Contract";
                col9.Resizable = System.Windows.Forms.DataGridViewTriState.True;

                col10.DataPropertyName = "BidID";
                col10.HeaderText = "BidID";
                col10.Resizable = System.Windows.Forms.DataGridViewTriState.True;

                col11.DataPropertyName = "ProjID";
                col11.HeaderText = "ProjID";
                col11.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            }
            
            BindingSource myBindingSource = null;

            try
            {
                DataTable finalDt = new DataTable("Company");
                finalDt.Columns.Add("Select");
                finalDt.Columns.Add("ContractNo");
                finalDt.Columns.Add("ContractTitle");
                finalDt.Columns.Add("ContractStartDate");
                finalDt.Columns.Add("ContractEndDate");

                finalDt.Columns.Add("BondExpiry");
                finalDt.Columns.Add("Vendor");
                finalDt.Columns.Add("Type");
                finalDt.Columns.Add("ProjectCode");
                finalDt.Columns.Add("TypeOfContract");

                finalDt.Columns.Add("BidID");
                finalDt.Columns.Add("ProjID");


                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();

                //string sqlQuery = "SELECT CONTRACTORS.bidder_id, CONTRACTORS.contract_status_id, [Contract Status].[Contract Status], PROJECTS.project_code, CONTRACTORS.proj_id, CONTRACTORS.contract_no, CONTRACTORS.[Contract Title], " + 
                //" CONVERT(varchar(11), CONTRACTORS.ContractStartDat, 101) AS StartDate,CONVERT(varchar(11), CONTRACTORS.ContractFinishDat, 101) AS EndDate, CONVERT(varchar(11),CONTRACTORS.[Performance Bond Expiry Date],101) as BondExpireDate, COMPANY.co_name, COMPANY_TYPE.co_type_name, [Contract Status].[Contract Status], [Contract Cost].[Original Contract Value], [Contract Cost].[Performance Bond], [Contract Cost].Rentention, [Contract Cost].[Down Payment], PROJECTS.contract_type_id, [Type of Contract].type_short_name, [Type of Contract].[Type of Contract], PROJECTS.committee_id, Committee.committee_short_name " + 
                //" FROM (Committee RIGHT JOIN ([Type of Contract] INNER JOIN PROJECTS ON [Type of Contract].contract_type_id = PROJECTS.contract_type_id) ON Committee.committee_id = PROJECTS.committee_id) INNER JOIN (((COMPANY_TYPE INNER JOIN COMPANY ON COMPANY_TYPE.[co_type_id] = COMPANY.[co_type_id]) INNER JOIN ([Contract Status] INNER JOIN CONTRACTORS ON [Contract Status].[contract_status_id] = CONTRACTORS.[contract_status_id]) ON COMPANY.[co_id] = CONTRACTORS.[co_id]) LEFT JOIN [Contract Cost] ON CONTRACTORS.[bidder_id] = [Contract Cost].[bidder_id]) ON PROJECTS.proj_id = CONTRACTORS.proj_id " +
                //" WHERE (((CONTRACTORS.contract_status_id)<>1))";
                                
                string sqlQuery = string.Empty;
                if (filterQuery !="")

                    sqlQuery= "SELECT CONTRACTORS.bidder_id, CONTRACTORS.contract_status_id, PROJECTS.project_code, CONTRACTORS.proj_id, CONTRACTORS.contract_no, " +
                      " CONTRACTORS.[ContractTitle], CONVERT(varchar(11), CONTRACTORS.StartDate, 101) AS StartDate, CONVERT(varchar(11), " +
                      " CONTRACTORS.FinishDate, 101) AS EndDate, CONVERT(varchar(11), CONTRACTORS.[PB_Expiry_Date], 101) AS BondExpireDate, " +
                      "COMPANY.co_name, COMPANY_TYPE.co_type_name, [ContractStatus].[ContractStatus], PROJECTS.contract_type_id, " +
                      "[ContractTypes].type_short_name, [ContractTypes].[TypeofContract], PROJECTS.committee_id, Committee.committee_short_name " +
                      " FROM  Committee RIGHT OUTER JOIN [ContractTypes] INNER JOIN " +
                      " PROJECTS ON [ContractTypes].contract_type_id = PROJECTS.contract_type_id ON Committee.committee_id = PROJECTS.committee_id INNER JOIN " +
                      " COMPANY_TYPE INNER JOIN COMPANY ON COMPANY_TYPE.co_type_id = COMPANY.co_type_id INNER JOIN [ContractStatus] INNER JOIN " +
                      " CONTRACTORS ON [ContractStatus].contract_status_id = CONTRACTORS.contract_status_id ON COMPANY.co_id = CONTRACTORS.co_id ON " +
                      " PROJECTS.proj_id = CONTRACTORS.proj_id WHERE  (CONTRACTORS.contract_status_id <> 1) AND (CONTRACTORS.contract_no IS NOT NULL) And ([Committee].committee_short_name in (" + committesList + ")) ORDER BY CONTRACTORS.bidder_id DESC";
                else
                     sqlQuery= "SELECT CONTRACTORS.bidder_id, CONTRACTORS.contract_status_id, PROJECTS.project_code, CONTRACTORS.proj_id, CONTRACTORS.contract_no, " +
                      " CONTRACTORS.[ContractTitle], CONVERT(varchar(11), CONTRACTORS.StartDate, 101) AS StartDate, CONVERT(varchar(11), " +
                      " CONTRACTORS.FinishDate, 101) AS EndDate, CONVERT(varchar(11), CONTRACTORS.[PB_Expiry_Date], 101) AS BondExpireDate, " +
                      "COMPANY.co_name, COMPANY_TYPE.co_type_name, [ContractStatus].[ContractStatus], PROJECTS.contract_type_id, " +
                      "[ContractTypes].type_short_name, [ContractTypes].[TypeofContract], PROJECTS.committee_id, Committee.committee_short_name " +
                      " FROM  Committee RIGHT OUTER JOIN [ContractTypes] INNER JOIN " +
                      " PROJECTS ON [ContractTypes].contract_type_id = PROJECTS.contract_type_id ON Committee.committee_id = PROJECTS.committee_id INNER JOIN " +
                      " COMPANY_TYPE INNER JOIN COMPANY ON COMPANY_TYPE.co_type_id = COMPANY.co_type_id INNER JOIN [ContractStatus] INNER JOIN " +
                      " CONTRACTORS ON [ContractStatus].contract_status_id = CONTRACTORS.contract_status_id ON COMPANY.co_id = CONTRACTORS.co_id ON " +
                      " PROJECTS.proj_id = CONTRACTORS.proj_id WHERE  (CONTRACTORS.contract_status_id <> 1) AND (CONTRACTORS.contract_no IS NOT NULL) ORDER BY CONTRACTORS.bidder_id DESC";
                

                finalDt.AcceptChanges();
                sqlCom = new SqlCommand(sqlQuery, sqlConn);
                sqlReader = sqlCom.ExecuteReader();

                while (sqlReader.Read())
                {
                    DataRow dr = finalDt.NewRow();
                    dr[1] = sqlReader[4];   //ContractNo
                    dr[2] = sqlReader[5];   //ContractTitle
                    dr[3] = sqlReader[6];   //ContractStartDate
                    dr[4] = sqlReader[7];   //ContractEndDate
                    dr[5] = sqlReader[8];   //BondExpiry
                    dr[6] = sqlReader[9];   //Vendor
                    dr[7] = sqlReader[10];   //Type
                    dr[8] = sqlReader[2];    //ProjectCode
                    dr[9] = sqlReader[14];    //TypeOfContract

                    dr[10] = sqlReader[0];    //BidID
                    dr[11] = sqlReader[3];    //PrjID

                    finalDt.Rows.Add(dr);
                    finalDt.AcceptChanges();
                }
                sqlReader.Close();

                myBindingSource = new BindingSource(finalDt, null);
                dgViewInactive.DataSource = myBindingSource;

                dtTemp = finalDt;

                //dgViewInactive.ColumnHeadersDefaultCellStyle.Font = new Font(dgViewInactive.Font, FontStyle.Bold);
                dgViewInactive.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;


                dgViewInactive.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
                dgViewInactive.RowsDefaultCellStyle.WrapMode = DataGridViewTriState.True;
                dgViewInactive.RowsDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                dgViewInactive.ReadOnly = true;

                dgViewInactive.Columns[9].Visible = false;
                dgViewInactive.Columns[10].Visible = false;
               // dgViewInactive.Columns[11].Visible = false;
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }

           // headerCheckBox.KeyUp += new KeyEventHandler(chkBox.HeaderCheckBox_KeyUp);
           // headerCheckBox.MouseClick += new MouseEventHandler(chkBox.HeaderCheckBox_MouseClick);
           // dgView.CellValueChanged += new DataGridViewCellEventHandler(chkBox.dgvSelectAll_CellValueChanged);
           // dgView.CurrentCellDirtyStateChanged += new EventHandler(chkBox.dgvSelectAll_CurrentCellDirtyStateChanged);
            //dgView.CellPainting += new DataGridViewCellPaintingEventHandler(chkBox.dgvSelectAll_CellPainting);

            //
            // label1
            // 
            this.label1 = new Label();
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Service Uri:";
        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void dgViewInactive_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                string mnstryCode = string.Empty;
                string prvsnNo = string.Empty;
                string tendrStatus = string.Empty;
                string budgetRefNo = string.Empty;
                try
                {
                    //   frmContractsEntry contractsEntry = new frmContractsEntry(0, dgView.Rows[e.RowIndex].Cells[1].Value.ToString(), dgView.Rows[e.RowIndex].Cells[2].Value.ToString(), dgView.Rows[e.RowIndex].Cells[3].Value.ToString(), staticUserName, dgView.Rows[e.RowIndex].Cells[4].Value.ToString(), mnstryCode, prvsnNo, budgetRefNo, dgView.Rows[e.RowIndex].Cells[6].Value.ToString());
                    frmContractsEntry contractsEntry = new frmContractsEntry(userRightsColl, Convert.ToInt16(dgViewInactive.Rows[e.RowIndex].Cells[9].Value), Convert.ToInt16(dgViewInactive.Rows[e.RowIndex].Cells[10].Value), null, _userName, _isHeadOfSection, null, null, null, null);
                    contractsEntry.StartPosition = FormStartPosition.CenterParent;
                    contractsEntry.ShowDialog();
                }
                catch (Exception ex)
                {
                }
            }
            if (e.ColumnIndex == 7)
            {
                try
                {
                    ProjectStages projStg = new ProjectStages(userRightsColl, "", Convert.ToInt16(dgViewInactive.Rows[e.RowIndex].Cells[10].Value), null, _userName,null,_isHeadOfSection);
                    // ProjectStages projStg = new ProjectStages(Convert.ToInt16(dgView.Rows[e.RowIndex].Cells[0].Value));                 
                    projStg.StartPosition = FormStartPosition.CenterParent;
                    projStg.ShowDialog();
                }
                catch (Exception ex)
                {

                }                
            }
        }
       

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            txtVendor.Text = "";
            txtCntrTitle.Text = "";
            txtCntrNo.Text = "";

            rePopulateDataGridView_Contact_Person_EntryData(filterQuery);
        }      

        private void txtCntrNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            filterCombo();
        }

        private void filterCombo()
        {
            string filterQuery = "";

            if (txtCntrNo.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "ContractNo like '%" + txtCntrNo.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "ContractNo like '%" + txtCntrNo.Text + "%'";
                }
            }
            if (txtCntrTitle.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "ContractTitle like '%" + txtCntrTitle.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "ContractTitle like '%" + txtCntrTitle.Text + "%'";
                }
            }
            if (txtVendor.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "Vendor like '%" + txtVendor.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "Vendor like '%" + txtVendor.Text + "%'";
                }
            }             
            if (filterQuery == "")
            {
                GridFill("");
            }
            else
            {
                GridFill(filterQuery);
            }
        }
        DataTable dtTemp = null;
        private void GridFill(string filterQuery)
        {
            BindingSource myBindingSource = null;
            int iCnt = dtTemp.Rows.Count;
            DataTable dtCmbTbl = null;
            if (dtTemp.Select(filterQuery).Length != 0)
            {
                dtCmbTbl = dtTemp.Select(filterQuery).CopyToDataTable();
                int jCnt = dtCmbTbl.Rows.Count;
                try
                {
                    myBindingSource = new BindingSource(dtCmbTbl, null);
                    dgViewInactive.DataSource = myBindingSource;

                    dtTemp = dtCmbTbl;

                    dgViewInactive.EnableHeadersVisualStyles = false;                 

                    //lblCnt.Text = dgViewInactive.Rows.Count.ToString();
                   
                }
                catch (Exception ex)
                {
                    string exMsg = ex.Message;
                }
                finally
                {
                }
            }
            else
            {
                DataTable nullTable = new DataTable();
                dtCmbTbl = null;
                myBindingSource = new BindingSource(nullTable, null);
                dgViewInactive.DataSource = myBindingSource;
            }

           // lblCnt.Text = dgViewInactive.Rows.Count.ToString();
        }
        private void txtCntrNo_KeyDown(object sender, KeyEventArgs e)
        {
            filterCombo();
        }
        private void txtCntrTitle_KeyDown(object sender, KeyEventArgs e)
        {
            filterCombo();
        }
        private void txtCntrTitle_KeyPress(object sender, KeyPressEventArgs e)
        {
            filterCombo();
        }
        private void txtVendor_KeyDown(object sender, KeyEventArgs e)
        {
            filterCombo();
        }
        private void txtVendor_KeyPress(object sender, KeyPressEventArgs e)
        {
            filterCombo();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
