﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace TenderTrackingSystem
{
    class DAL
    {
        // Status of Tender      //Type of Tender      // Type of Contract       // Status of Tender       

        SqlDataAdapter da;
        SqlCommand sqlCmd;
        SqlDataReader sqlDtReader;
           
        string strCon = ConfigurationManager.AppSettings["TCMSConnString"].ToString();       

        public DataTable GetDataFromDB(string dataTabName, string sqlQuery)
        {
            DataTable table = null;
            SqlConnection conn = null;             
            try
            {                 
                table = new DataTable(dataTabName);
                conn = new SqlConnection(strCon);
                conn.Open();                
                sqlCmd = new SqlCommand(@sqlQuery, conn);
                sqlCmd.CommandTimeout = 80;
                da = new SqlDataAdapter(sqlCmd);                 
                da.Fill(table);
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {                
                da.Dispose();
                conn.Close();
            }
            return table;
        }



        public string GetPRDate(string sqlQuery)
        {
            string strDateTime = null;
            try
            {                 
                SqlConnection conn = new SqlConnection(strCon);
                conn.Open();
                sqlCmd = new SqlCommand(@sqlQuery, conn);
                sqlDtReader = sqlCmd.ExecuteReader();
                sqlDtReader.Read();
                if (sqlDtReader[0] != DBNull.Value)
                    strDateTime = sqlDtReader.GetDateTime(0).ToString("dd-MMM-yyyy");
                else
                    strDateTime = "";
            }
            catch (Exception ex)
            {
                return null;
            }
            return strDateTime;
        }




        public void populateLstBox(string sqlQuery, ListBox lstBox)
        {
            DataTable dt = null;
            SqlConnection sqlConn = null;
            try
            {
                dt = GetDataFromDB("AlertCategory", sqlQuery);
                lstBox.DataSource = dt;
                lstBox.DisplayMember = "AlertCategory";
                lstBox.ValueMember = "alert_cat_id";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while populating the " + lstBox.Name + " box", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {
                if (sqlConn != null)
                    sqlConn.Close();
                if (sqlDtReader != null)
                    sqlDtReader.Close();
            }
        }
        public void populateCircularCmbBox(string sqlQuery, ComboBox lstBox)
        {             
            SqlConnection sqlConn = null;
            try
            {
                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                sqlCmd = new SqlCommand(sqlQuery, sqlConn);
                sqlDtReader = sqlCmd.ExecuteReader();

                if (sqlDtReader.HasRows)
                {
                    while (sqlDtReader.Read())
                    {
                        lstBox.Items.Add(sqlDtReader[0].ToString());
                    }
                }  
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while populating the " + lstBox.Name + " combo box.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (sqlConn != null)
                    sqlConn.Close();
                if (sqlDtReader != null)
                    sqlDtReader.Close();
            }
        }

        public void populateCmbBox(string sqlQuery, ComboBox lstBox,bool includeBlank)
        {
            DataTable dt = null;
            if (lstBox.Name == "cmbFiscalYear")
            {
                dt = GetDataFromDB("FiscalYear", sqlQuery);
                DataRow dr = dt.NewRow();
                dr[0] = dt.Rows.Count + 1;
                dr[1] = "";
                dt.Rows.Add(dr);
                lstBox.DataSource = dt;
                lstBox.DisplayMember = "FiscalYear";
                lstBox.ValueMember = "FYID";
                lstBox.SelectedValue = dt.Rows.Count;
            }
            else if (lstBox.Name == "cmbTenderYear")
            {
                dt = GetDataFromDB("TenderYear", sqlQuery);
                DataRow dr = dt.NewRow();
                dr[0] = dt.Rows.Count + 1;
                dr[1] = "";
                dt.Rows.Add(dr);
                lstBox.DataSource = dt;
                lstBox.DisplayMember = "FiscalYear";
                lstBox.ValueMember = "FYID";
                lstBox.SelectedValue = dt.Rows.Count;
            }
        }
        public void populateCmbBox(string sqlQuery, ComboBox lstBox)
        {
            if (lstBox.Items.Count == 0)
            {

                DataTable dt = null;
                SqlConnection sqlConn = null;
                try
                {
                    if (lstBox.Name == "cmbUserDepart")
                    {
                        dt = GetDataFromDB("UserDept", sqlQuery);
                        lstBox.DataSource = dt;
                        lstBox.DisplayMember = "department_short_name";
                        lstBox.ValueMember = "Department";
                    }
                    else if (lstBox.Name == "cmbTenderCommittee")
                    {
                        dt = GetDataFromDB("TenderCommittee", sqlQuery);
                        lstBox.DataSource = dt;
                        lstBox.DisplayMember = "committee_short_name";
                        lstBox.ValueMember = "committee_id";
                    }
                    else if (lstBox.Name == "cmbCommitteeNames")
                    {
                        dt = GetDataFromDB("TenderCommittee", sqlQuery);
                        lstBox.DataSource = dt;
                        lstBox.DisplayMember = "committee_name";
                        lstBox.ValueMember = "committee_id";
                    }    
                    else if (lstBox.Name == "lstboxAlertCategories")
                    {
                        dt = GetDataFromDB("EmailAlertCategory", sqlQuery);
                        lstBox.DataSource = dt;
                        lstBox.DisplayMember = "alert_cat_id";
                        lstBox.ValueMember = "AlertCategory";
                    }
                    else if (lstBox.Name == "cmbCircularNo")
                    {
                        dt = GetDataFromDB("CircularNo", sqlQuery);
                        lstBox.DataSource = dt;
                        lstBox.DisplayMember = "CircularNo";
                        lstBox.ValueMember = "CircularNo";
                    }
                    else if (lstBox.Name == "cmbMozanahID")
                    {
                        dt = GetDataFromDB("MozanahIDs", sqlQuery);
                        lstBox.DataSource = dt;
                        lstBox.DisplayMember = "moazanah_proj_id_new";
                        lstBox.ValueMember = "moazanah_proj_id_new";
                    }
                    else if (lstBox.Name == "cmbContractNo")
                    {
                        dt = GetDataFromDB("ContractNos", sqlQuery);
                        lstBox.DataSource = dt;
                        lstBox.DisplayMember = "contract_no";
                        lstBox.ValueMember = "contract_no";
                    }
                    else if (lstBox.Name == "cmbFiscalYear" || lstBox.Name == "cmbCreateYear" || lstBox.Name == "cmbModifiedYear")
                    {
                        dt = GetDataFromDB("FiscalYear", sqlQuery);
                        lstBox.DataSource = dt;
                        lstBox.DisplayMember = "FiscalYear";
                        lstBox.ValueMember = "FYID";
                    }                    
                    else if (lstBox.Name == "cmbCommittedYear")
                    {
                        dt = GetDataFromDB("CommittedYear", sqlQuery);
                        lstBox.DataSource = dt;
                        lstBox.DisplayMember = "commitmentYear";
                        lstBox.ValueMember = "cyID";
                    }
                    else if (lstBox.Name == "cmbAssignedQS")
                    {
                        dt = GetDataFromDB("cmbAssignedQS", sqlQuery);
                        lstBox.DataSource = dt;
                        lstBox.DisplayMember = "ptd_assign_qs";
                        lstBox.ValueMember = "ptd_assign_qs";
                    }
                    else if (lstBox.Name == "cmbAssignedQS")
                    {
                        dt = GetDataFromDB("cmbAssignedQS", sqlQuery);
                        lstBox.DataSource = dt;
                        lstBox.DisplayMember = "ptd_assign_qs";
                        lstBox.ValueMember = "ptd_assign_qs";
                    }
                    else if (lstBox.Name == "cmbTenderIssue")
                    {
                        dt = GetDataFromDB("cmbTenderIssue", sqlQuery);
                        lstBox.DataSource = dt;
                        lstBox.DisplayMember = "ts_issue_handling";
                        lstBox.ValueMember = "ts_issue_handling";
                    }
                    else if (lstBox.Name == "cmbContractProcess")
                    {
                        dt = GetDataFromDB("cmbContractProcess", sqlQuery);
                        lstBox.DataSource = dt;
                        lstBox.DisplayMember = "StaffInCharge";
                        lstBox.ValueMember = "StaffInCharge";
                    }  
                    else
                    {
                        dt = GetDataFromDB(lstBox.Name, sqlQuery);
                        lstBox.DataSource = dt;
                        lstBox.DisplayMember = dt.Columns[0].ColumnName;
                        //lstBox.ValueMember = dt.Columns[0].ColumnName;
// "commitmentYear";
                        //lstBox.ValueMember = "cyID";

                        //sqlConn = new SqlConnection(strCon);
                        //sqlConn.Open();
                        //sqlCmd = new SqlCommand(sqlQuery, sqlConn);
                        //sqlDtReader = sqlCmd.ExecuteReader();

                        //if (sqlDtReader.HasRows == true)
                        //{
                        //    while (sqlDtReader.Read())
                        //    {
                        //        lstBox.Items.Add(sqlDtReader[0].ToString());
                        //    }
                        //}
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while populating the " + lstBox.Name + " combo box, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                finally
                {
                    if (sqlConn != null)
                        sqlConn.Close();
                    if (sqlDtReader != null)
                        sqlDtReader.Close();
                }
            }
        }        
        public IList<string> FillCombo(string sqlQuery)
        {
            IList<string> itemColl = new List<string>();
            SqlConnection sqlConn = null;
            try
            {
                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                sqlCmd = new SqlCommand(sqlQuery, sqlConn);
                sqlDtReader = sqlCmd.ExecuteReader();

                if (sqlDtReader.HasRows == true)
                {
                    while (sqlDtReader.Read())
                    {
                        itemColl.Add(sqlDtReader[1].ToString());                       
                    }
                }
            }
            catch
            {
                MessageBox.Show("Error while populating , Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {
                sqlConn.Close();
                sqlDtReader.Close();
            }
            return itemColl;
        }
        public void populatePurposeCmbBox(string sqlQuery, ComboBox lstBox)
        {
            SqlConnection sqlConn = null;
            try
            {
                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                sqlCmd = new SqlCommand(sqlQuery, sqlConn);
                sqlDtReader = sqlCmd.ExecuteReader();

                if (sqlDtReader.HasRows == true)
                {
                    while (sqlDtReader.Read())
                    {
                        lstBox.Items.Add(new PurposeItemData(Convert.ToInt32(sqlDtReader[0]), sqlDtReader[1].ToString()));
                        //col4.Items.Add(new ItemData(Convert.ToInt32(sqlDtReader[0]), sqlDtReader[1].ToString()));
                        //dgvColBoxCol.
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while populating the Assigned combo box, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {
                sqlConn.Close();
                sqlDtReader.Close();
            }
        }
        public void populateAssignedQSCmbBox(string sqlQuery, ComboBox lstBox)
        {
            SqlConnection sqlConn = null;
            try
            {
                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                sqlCmd = new SqlCommand(sqlQuery, sqlConn);
                sqlDtReader = sqlCmd.ExecuteReader();
                
                if (sqlDtReader.HasRows == true)
                {
                    while (sqlDtReader.Read())
                    {
                        lstBox.Items.Add(new ItemData(Convert.ToInt32(sqlDtReader[0]), sqlDtReader[1].ToString()));
                        //col4.Items.Add(new ItemData(Convert.ToInt32(sqlDtReader[0]), sqlDtReader[1].ToString()));
                        //dgvColBoxCol.
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while populating the Assigned combo box, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {
                sqlDtReader.Close();
                sqlConn.Close();                
            }
        }
        public void populateSentDocCategoryCmbBox(string sqlQuery, ComboBox lstBox)
        {
            SqlConnection sqlConn = null;
            try
            {
                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                sqlCmd = new SqlCommand(sqlQuery, sqlConn);
                sqlDtReader = sqlCmd.ExecuteReader();


                if (sqlDtReader.HasRows == true)
                {
                    while (sqlDtReader.Read())
                    {
                        lstBox.Items.Add(new DocTypeItemData(Convert.ToInt32(sqlDtReader[0]), sqlDtReader[1].ToString()));
                        //col4.Items.Add(new ItemData(Convert.ToInt32(sqlDtReader[0]), sqlDtReader[1].ToString()));
                        //dgvColBoxCol.
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while populating the Assigned combo box, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {
                sqlConn.Close();
                sqlDtReader.Close();
            }
        }

        public int GetEmpId(Object cmbSelectedItem)
        {
            return ((ItemData)cmbSelectedItem).empID;
        }
        public int GetPurposeId(Object cmbSelectedItem)
        {
            return ((PurposeItemData)cmbSelectedItem).purposeID;
        }
        public string GetEmpName(Object cmbSelectedItem)
        {
            return ((ItemData)cmbSelectedItem).empName;
        }
        public int GetSentDocCategoryId(Object cmbSelectedItem)
        {
            return ((DocTypeItemData)cmbSelectedItem).docTypeID;
        }
        public string GetSentDocCategoryName(Object cmbSelectedItem)
        {
            return ((DocTypeItemData)cmbSelectedItem).docTypeName;
        }
        public DataTable GetAssignedQS(string dataTabName, string sqlQuery)
        {
            DataTable table = null;
            try
            {
                table = new DataTable(dataTabName);
                SqlConnection conn = new SqlConnection(strCon);
                conn.Open();
                da = new SqlDataAdapter(@sqlQuery, conn);
                da.Fill(table);
            }
            catch (Exception ex)
            {
                return null;
            }
            return table;
        }
        public DataTable GetPTDPurpose(string dataTabName, string sqlQuery)
        {
            DataTable table = null;
            try
            {
                table = new DataTable(dataTabName);
                SqlConnection conn = new SqlConnection(strCon);
                conn.Open();
                da = new SqlDataAdapter(@sqlQuery, conn);             
                da.Fill(table);
            }
            catch (Exception ex)
            {
                return null;
            }
            return table;
        }
        public DataTable GetData1()
        {
            DataTable table = null;
            try
            {
                table = new DataTable("Table1");
                SqlConnection conn = new SqlConnection(strCon);
                conn.Open();
                da = new SqlDataAdapter(@"SELECT * FROM Table1", conn);             
                da.Fill(table);                
            }
            catch (Exception ex)
            {
                return null;
            }
            return table;
        }
        public struct PurposeItemData
        {
            public int purposeID;
            public string purposeName;

            public PurposeItemData(int paramPurposeID, string paramPurposeName)
            {
                purposeID = paramPurposeID;
                purposeName = paramPurposeName;
            }

            public override string ToString()
            {
                return this.purposeName;
            }
        }
        public struct ItemData
        {
            public int empID;
            public string empName;

            public ItemData(int paramEmpID, string paramEmpName)
            {
                empID = paramEmpID;
                empName = paramEmpName;
            }

            public override string ToString()
            {
                return this.empName;
            }
        }
        public struct DocTypeItemData
        {
            public int docTypeID;
            public string docTypeName;

            public DocTypeItemData(int paramdocTypeID, string paramdocTypeName)
            {
                docTypeID = paramdocTypeID;
                docTypeName = paramdocTypeName;
            }

            public override string ToString()
            {
                return this.docTypeName;
            }
        }
        //public int circularNo = 0;
        public void PopulateComboBox(ComboBox cmbBox, string sqlQuery, string displayName, string valueMember)
        {
            DataTable table = new DataTable();         

            try
            {               
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn)) //@"select Affair_id,[PWA Affairs]as AffairName from AFFAIRS"
                        da.Fill(table);
                }
                cmbBox.DataSource = table;                               
                cmbBox.DisplayMember = valueMember;
                if (displayName != null)
                    cmbBox.ValueMember = displayName;                                
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void AllowNumaric(string txtData)
        {
            if (Microsoft.VisualBasic.Information.IsNumeric(txtData))
            {
                //Display error
            }
            else
            {
                //Carry on with the rest of program ie. Add Phone number to program.
            }
        }
        private void AllowNumaric2(string txtData)
        {
            if (!txtData.All(c => Char.IsNumber(c)))
            {
                //Display error
            }
            else
            {
                //Carry on with the rest of program ie. Add Phone number to program.
            }
        }
        private void AllowNumaric3(string txtData)
        {
            int num;
            bool isNum = int.TryParse(txtData.Trim(), out num);
            if (!isNum)
            {

            }
            else
            {

            }
        }
        private void DummyFunctions()
        {
           // MessageBox.Show("Data saved successfully.", "PostContract Data Entry", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


    } 
}
