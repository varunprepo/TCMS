﻿namespace MDI_ParenrForm
{
    partial class ProjectsWithSuccessfulBidders
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProjectsWithSuccessfulBidders));
            this.cmbUserDepart = new System.Windows.Forms.ComboBox();
            this.lblUserDept = new System.Windows.Forms.Label();
            this.cmbTenderCommittee = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.cmbTenderNo = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtPrjTitle = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbFiscalYear = new System.Windows.Forms.ComboBox();
            this.cmbTypeofContract = new System.Windows.Forms.ComboBox();
            this.cmbTypeOftender = new System.Windows.Forms.ComboBox();
            this.cmbTenderStatus = new System.Windows.Forms.ComboBox();
            this.cmbCurrentStage = new System.Windows.Forms.ComboBox();
            this.cmbPrjCode = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnExportToExcel = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmbContractNo = new System.Windows.Forms.ComboBox();
            this.lblContractNo = new System.Windows.Forms.Label();
            this.cmbMozanahID = new System.Windows.Forms.ComboBox();
            this.lblMozanahID = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnDeleteArchieve = new System.Windows.Forms.Button();
            this.btnEditArchieve = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.dgView = new System.Windows.Forms.DataGridView();
            this.btnAddProject = new System.Windows.Forms.Button();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbFirst = new System.Windows.Forms.ToolStripButton();
            this.tsbPrevious = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this.tsbNext = new System.Windows.Forms.ToolStripButton();
            this.tsbLast = new System.Windows.Forms.ToolStripButton();
            this.label14 = new System.Windows.Forms.Label();
            this.lblCnt = new System.Windows.Forms.Label();
            this.lblStaff = new System.Windows.Forms.Label();
            this.lblCp = new System.Windows.Forms.Label();
            this.cmbStaff = new System.Windows.Forms.ComboBox();
            this.lblTndr = new System.Windows.Forms.Label();
            this.cmbTndrHndl = new System.Windows.Forms.ComboBox();
            this.lblQS = new System.Windows.Forms.Label();
            this.cmbQs = new System.Windows.Forms.ComboBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgView)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmbUserDepart
            // 
            this.cmbUserDepart.FormattingEnabled = true;
            this.cmbUserDepart.Location = new System.Drawing.Point(1053, 46);
            this.cmbUserDepart.Name = "cmbUserDepart";
            this.cmbUserDepart.Size = new System.Drawing.Size(75, 23);
            this.cmbUserDepart.TabIndex = 16;
            this.cmbUserDepart.SelectedIndexChanged += new System.EventHandler(this.cmbUserDepart_SelectedIndexChanged);
            this.cmbUserDepart.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbUserDepart_KeyPress);
            // 
            // lblUserDept
            // 
            this.lblUserDept.AutoSize = true;
            this.lblUserDept.Location = new System.Drawing.Point(1053, 27);
            this.lblUserDept.Name = "lblUserDept";
            this.lblUserDept.Size = new System.Drawing.Size(75, 15);
            this.lblUserDept.TabIndex = 44;
            this.lblUserDept.Text = "Deptartment";
            // 
            // cmbTenderCommittee
            // 
            this.cmbTenderCommittee.FormattingEnabled = true;
            this.cmbTenderCommittee.Location = new System.Drawing.Point(772, 45);
            this.cmbTenderCommittee.Name = "cmbTenderCommittee";
            this.cmbTenderCommittee.Size = new System.Drawing.Size(77, 23);
            this.cmbTenderCommittee.TabIndex = 13;
            this.cmbTenderCommittee.SelectedIndexChanged += new System.EventHandler(this.cmbTenderCommittee_SelectedIndexChanged);
            this.cmbTenderCommittee.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbTenderCommittee_KeyPress);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label12.Location = new System.Drawing.Point(772, 27);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(60, 15);
            this.label12.TabIndex = 42;
            this.label12.Text = "Committe";
            // 
            // cmbTenderNo
            // 
            this.cmbTenderNo.FormattingEnabled = true;
            this.cmbTenderNo.Location = new System.Drawing.Point(275, 46);
            this.cmbTenderNo.Name = "cmbTenderNo";
            this.cmbTenderNo.Size = new System.Drawing.Size(155, 23);
            this.cmbTenderNo.TabIndex = 9;
            this.cmbTenderNo.SelectedIndexChanged += new System.EventHandler(this.cmbTenderNo_SelectedIndexChanged);
            this.cmbTenderNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbTenderNo_KeyPress);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label10.Location = new System.Drawing.Point(278, 28);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(62, 15);
            this.label10.TabIndex = 38;
            this.label10.Text = "TenderNo";
            // 
            // txtPrjTitle
            // 
            this.txtPrjTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrjTitle.Location = new System.Drawing.Point(162, 46);
            this.txtPrjTitle.Name = "txtPrjTitle";
            this.txtPrjTitle.Size = new System.Drawing.Size(109, 23);
            this.txtPrjTitle.TabIndex = 8;
            this.txtPrjTitle.TextChanged += new System.EventHandler(this.txtPrjTitle_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label9.Location = new System.Drawing.Point(166, 28);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(68, 15);
            this.label9.TabIndex = 36;
            this.label9.Text = "ProjectTitle";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label8.Location = new System.Drawing.Point(12, 29);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 15);
            this.label8.TabIndex = 35;
            this.label8.Text = "ProjectCode";
            // 
            // cmbFiscalYear
            // 
            this.cmbFiscalYear.FormattingEnabled = true;
            this.cmbFiscalYear.Location = new System.Drawing.Point(969, 46);
            this.cmbFiscalYear.Name = "cmbFiscalYear";
            this.cmbFiscalYear.Size = new System.Drawing.Size(78, 23);
            this.cmbFiscalYear.TabIndex = 15;
            this.cmbFiscalYear.SelectedIndexChanged += new System.EventHandler(this.cmbFiscalYear_SelectedIndexChanged);
            this.cmbFiscalYear.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbFiscalYear_KeyPress);
            // 
            // cmbTypeofContract
            // 
            this.cmbTypeofContract.FormattingEnabled = true;
            this.cmbTypeofContract.Location = new System.Drawing.Point(855, 45);
            this.cmbTypeofContract.Name = "cmbTypeofContract";
            this.cmbTypeofContract.Size = new System.Drawing.Size(108, 23);
            this.cmbTypeofContract.TabIndex = 14;
            this.cmbTypeofContract.SelectedIndexChanged += new System.EventHandler(this.cmbTypeofContract_SelectedIndexChanged);
            this.cmbTypeofContract.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbTypeofContract_KeyPress);
            // 
            // cmbTypeOftender
            // 
            this.cmbTypeOftender.FormattingEnabled = true;
            this.cmbTypeOftender.Location = new System.Drawing.Point(686, 45);
            this.cmbTypeOftender.Name = "cmbTypeOftender";
            this.cmbTypeOftender.Size = new System.Drawing.Size(80, 23);
            this.cmbTypeOftender.TabIndex = 12;
            this.cmbTypeOftender.SelectedIndexChanged += new System.EventHandler(this.cmbTypeOftender_SelectedIndexChanged);
            this.cmbTypeOftender.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbTypeOftender_KeyPress);
            // 
            // cmbTenderStatus
            // 
            this.cmbTenderStatus.FormattingEnabled = true;
            this.cmbTenderStatus.Location = new System.Drawing.Point(575, 46);
            this.cmbTenderStatus.Name = "cmbTenderStatus";
            this.cmbTenderStatus.Size = new System.Drawing.Size(109, 23);
            this.cmbTenderStatus.TabIndex = 11;
            this.cmbTenderStatus.SelectedIndexChanged += new System.EventHandler(this.cmbTenderStatus_SelectedIndexChanged);
            this.cmbTenderStatus.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbTenderStatus_KeyPress);
            // 
            // cmbCurrentStage
            // 
            this.cmbCurrentStage.FormattingEnabled = true;
            this.cmbCurrentStage.Location = new System.Drawing.Point(436, 46);
            this.cmbCurrentStage.Name = "cmbCurrentStage";
            this.cmbCurrentStage.Size = new System.Drawing.Size(133, 23);
            this.cmbCurrentStage.TabIndex = 10;
            this.cmbCurrentStage.SelectedIndexChanged += new System.EventHandler(this.cmbCurrentStage_SelectedIndexChanged);
            this.cmbCurrentStage.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbCurrentStage_KeyPress);
            // 
            // cmbPrjCode
            // 
            this.cmbPrjCode.FormattingEnabled = true;
            this.cmbPrjCode.Location = new System.Drawing.Point(9, 46);
            this.cmbPrjCode.Name = "cmbPrjCode";
            this.cmbPrjCode.Size = new System.Drawing.Size(150, 23);
            this.cmbPrjCode.TabIndex = 7;
            this.cmbPrjCode.SelectedIndexChanged += new System.EventHandler(this.cmbPrjCode_SelectedIndexChanged);
            this.cmbPrjCode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbPrjCode_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label7.Location = new System.Drawing.Point(439, 28);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 15);
            this.label7.TabIndex = 22;
            this.label7.Text = "Current Stage";
            // 
            // btnExportToExcel
            // 
            this.btnExportToExcel.Location = new System.Drawing.Point(1432, 42);
            this.btnExportToExcel.Name = "btnExportToExcel";
            this.btnExportToExcel.Size = new System.Drawing.Size(95, 23);
            this.btnExportToExcel.TabIndex = 4;
            this.btnExportToExcel.Text = "Export To Excel";
            this.btnExportToExcel.UseVisualStyleBackColor = true;
            this.btnExportToExcel.Click += new System.EventHandler(this.btnExportToExcel_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label5.Location = new System.Drawing.Point(857, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 15);
            this.label5.TabIndex = 26;
            this.label5.Text = "Contract Type";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.Location = new System.Drawing.Point(966, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 15);
            this.label6.TabIndex = 27;
            this.label6.Text = "Fiscal Year";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(684, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 15);
            this.label4.TabIndex = 25;
            this.label4.Text = "Tender Type";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(576, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 15);
            this.label3.TabIndex = 24;
            this.label3.Text = "Tender Status";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cmbContractNo);
            this.groupBox1.Controls.Add(this.lblContractNo);
            this.groupBox1.Controls.Add(this.cmbMozanahID);
            this.groupBox1.Controls.Add(this.lblMozanahID);
            this.groupBox1.Controls.Add(this.cmbUserDepart);
            this.groupBox1.Controls.Add(this.lblUserDept);
            this.groupBox1.Controls.Add(this.cmbTenderCommittee);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.cmbTenderNo);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txtPrjTitle);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.cmbFiscalYear);
            this.groupBox1.Controls.Add(this.cmbTypeofContract);
            this.groupBox1.Controls.Add(this.cmbTypeOftender);
            this.groupBox1.Controls.Add(this.cmbTenderStatus);
            this.groupBox1.Controls.Add(this.cmbCurrentStage);
            this.groupBox1.Controls.Add(this.cmbPrjCode);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(23, 74);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1386, 81);
            this.groupBox1.TabIndex = 73;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Search Project Details";
            // 
            // cmbContractNo
            // 
            this.cmbContractNo.FormattingEnabled = true;
            this.cmbContractNo.Location = new System.Drawing.Point(1131, 45);
            this.cmbContractNo.Name = "cmbContractNo";
            this.cmbContractNo.Size = new System.Drawing.Size(111, 23);
            this.cmbContractNo.TabIndex = 17;
            this.cmbContractNo.SelectedIndexChanged += new System.EventHandler(this.cmbContractNo_SelectedIndexChanged);
            this.cmbContractNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbContractNo_KeyPress);
            // 
            // lblContractNo
            // 
            this.lblContractNo.AutoSize = true;
            this.lblContractNo.Location = new System.Drawing.Point(1134, 27);
            this.lblContractNo.Name = "lblContractNo";
            this.lblContractNo.Size = new System.Drawing.Size(68, 15);
            this.lblContractNo.TabIndex = 60;
            this.lblContractNo.Text = "ContractNo";
            // 
            // cmbMozanahID
            // 
            this.cmbMozanahID.FormattingEnabled = true;
            this.cmbMozanahID.Location = new System.Drawing.Point(1248, 45);
            this.cmbMozanahID.Name = "cmbMozanahID";
            this.cmbMozanahID.Size = new System.Drawing.Size(131, 23);
            this.cmbMozanahID.TabIndex = 18;
            this.cmbMozanahID.SelectedIndexChanged += new System.EventHandler(this.cmbMozanahID_SelectedIndexChanged);
            this.cmbMozanahID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbMozanahID_KeyPress);
            // 
            // lblMozanahID
            // 
            this.lblMozanahID.AutoSize = true;
            this.lblMozanahID.Location = new System.Drawing.Point(1250, 27);
            this.lblMozanahID.Name = "lblMozanahID";
            this.lblMozanahID.Size = new System.Drawing.Size(71, 15);
            this.lblMozanahID.TabIndex = 58;
            this.lblMozanahID.Text = "MozanahID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(185, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 15);
            this.label2.TabIndex = 23;
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnClose.Image = global::MDI_ParenrForm.Properties.Resources.Actions_window_close_icon;
            this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.Location = new System.Drawing.Point(1613, 38);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(66, 30);
            this.btnClose.TabIndex = 6;
            this.btnClose.Text = "Close";
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnDeleteArchieve
            // 
            this.btnDeleteArchieve.BackColor = System.Drawing.Color.Maroon;
            this.btnDeleteArchieve.ForeColor = System.Drawing.Color.White;
            this.btnDeleteArchieve.Image = global::MDI_ParenrForm.Properties.Resources.Actions_window_close_icon;
            this.btnDeleteArchieve.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDeleteArchieve.Location = new System.Drawing.Point(298, 38);
            this.btnDeleteArchieve.Name = "btnDeleteArchieve";
            this.btnDeleteArchieve.Size = new System.Drawing.Size(69, 30);
            this.btnDeleteArchieve.TabIndex = 3;
            this.btnDeleteArchieve.Text = "Delete";
            this.btnDeleteArchieve.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDeleteArchieve.UseVisualStyleBackColor = false;
            this.btnDeleteArchieve.Visible = false;
            this.btnDeleteArchieve.Click += new System.EventHandler(this.btnDeleteArchieve_Click);
            // 
            // btnEditArchieve
            // 
            this.btnEditArchieve.BackColor = System.Drawing.Color.Maroon;
            this.btnEditArchieve.ForeColor = System.Drawing.Color.White;
            this.btnEditArchieve.Image = global::MDI_ParenrForm.Properties.Resources.Text_Edit_icon__1_;
            this.btnEditArchieve.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEditArchieve.Location = new System.Drawing.Point(150, 38);
            this.btnEditArchieve.Name = "btnEditArchieve";
            this.btnEditArchieve.Size = new System.Drawing.Size(149, 30);
            this.btnEditArchieve.TabIndex = 2;
            this.btnEditArchieve.Text = "View/ Edit Project Details";
            this.btnEditArchieve.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEditArchieve.UseVisualStyleBackColor = false;
            this.btnEditArchieve.Click += new System.EventHandler(this.btnEditArchieve_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.BackColor = System.Drawing.Color.White;
            this.btnRefresh.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefresh.ForeColor = System.Drawing.Color.Coral;
            this.btnRefresh.Image = global::MDI_ParenrForm.Properties.Resources.Button_Reload_icon;
            this.btnRefresh.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRefresh.Location = new System.Drawing.Point(1538, 38);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(75, 30);
            this.btnRefresh.TabIndex = 5;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = false;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // dgView
            // 
            this.dgView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dgView.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(236)))), ((int)(((byte)(236)))));
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.Color.HotPink;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle22;
            this.dgView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle23.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgView.DefaultCellStyle = dataGridViewCellStyle23;
            this.dgView.GridColor = System.Drawing.Color.Olive;
            this.dgView.Location = new System.Drawing.Point(24, 177);
            this.dgView.Name = "dgView";
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle24.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgView.RowHeadersDefaultCellStyle = dataGridViewCellStyle24;
            this.dgView.RowHeadersVisible = false;
            this.dgView.Size = new System.Drawing.Size(1738, 576);
            this.dgView.TabIndex = 39;
            this.dgView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgView_CellContentClick);
            this.dgView.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgView_ColumnHeaderMouseClick);
            // 
            // btnAddProject
            // 
            this.btnAddProject.BackColor = System.Drawing.Color.Maroon;
            this.btnAddProject.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAddProject.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddProject.ForeColor = System.Drawing.Color.White;
            this.btnAddProject.Image = global::MDI_ParenrForm.Properties.Resources.coin_add_icon;
            this.btnAddProject.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddProject.Location = new System.Drawing.Point(23, 38);
            this.btnAddProject.Name = "btnAddProject";
            this.btnAddProject.Size = new System.Drawing.Size(128, 30);
            this.btnAddProject.TabIndex = 1;
            this.btnAddProject.Text = "Add New Project";
            this.btnAddProject.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAddProject.UseVisualStyleBackColor = false;
            this.btnAddProject.Click += new System.EventHandler(this.btnAddProject_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbFirst,
            this.tsbPrevious,
            this.toolStripLabel2,
            this.toolStripLabel1,
            this.toolStripLabel3,
            this.tsbNext,
            this.tsbLast});
            this.toolStrip1.Location = new System.Drawing.Point(779, 756);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.toolStrip1.Size = new System.Drawing.Size(186, 25);
            this.toolStrip1.TabIndex = 81;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsbFirst
            // 
            this.tsbFirst.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbFirst.Image = ((System.Drawing.Image)(resources.GetObject("tsbFirst.Image")));
            this.tsbFirst.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbFirst.Name = "tsbFirst";
            this.tsbFirst.Size = new System.Drawing.Size(33, 22);
            this.tsbFirst.Text = "First";
            this.tsbFirst.Click += new System.EventHandler(this.tsbFirst_Click);
            // 
            // tsbPrevious
            // 
            this.tsbPrevious.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbPrevious.Image = ((System.Drawing.Image)(resources.GetObject("tsbPrevious.Image")));
            this.tsbPrevious.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPrevious.Name = "tsbPrevious";
            this.tsbPrevious.Size = new System.Drawing.Size(56, 22);
            this.tsbPrevious.Text = "Previous";
            this.tsbPrevious.Click += new System.EventHandler(this.tsbPrevious_Click);
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(0, 22);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(18, 22);
            this.toolStripLabel1.Text = "of";
            // 
            // toolStripLabel3
            // 
            this.toolStripLabel3.Name = "toolStripLabel3";
            this.toolStripLabel3.Size = new System.Drawing.Size(0, 22);
            // 
            // tsbNext
            // 
            this.tsbNext.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbNext.Image = ((System.Drawing.Image)(resources.GetObject("tsbNext.Image")));
            this.tsbNext.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbNext.Name = "tsbNext";
            this.tsbNext.Size = new System.Drawing.Size(35, 22);
            this.tsbNext.Text = "Next";
            this.tsbNext.Click += new System.EventHandler(this.tsbNext_Click);
            // 
            // tsbLast
            // 
            this.tsbLast.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbLast.Image = ((System.Drawing.Image)(resources.GetObject("tsbLast.Image")));
            this.tsbLast.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbLast.Name = "tsbLast";
            this.tsbLast.Size = new System.Drawing.Size(32, 22);
            this.tsbLast.Text = "Last";
            this.tsbLast.Click += new System.EventHandler(this.tsbLast_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label14.Location = new System.Drawing.Point(708, 42);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(112, 13);
            this.label14.TabIndex = 63;
            this.label14.Text = "Total Projects Count : ";
            // 
            // lblCnt
            // 
            this.lblCnt.AutoSize = true;
            this.lblCnt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblCnt.Location = new System.Drawing.Point(826, 42);
            this.lblCnt.Name = "lblCnt";
            this.lblCnt.Size = new System.Drawing.Size(41, 13);
            this.lblCnt.TabIndex = 62;
            this.lblCnt.Text = "label14";
            // 
            // lblStaff
            // 
            this.lblStaff.AutoSize = true;
            this.lblStaff.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStaff.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblStaff.Location = new System.Drawing.Point(1134, 9);
            this.lblStaff.Name = "lblStaff";
            this.lblStaff.Size = new System.Drawing.Size(210, 15);
            this.lblStaff.TabIndex = 88;
            this.lblStaff.Text = "Filter Projects By Assigned Staff";
            // 
            // lblCp
            // 
            this.lblCp.AutoSize = true;
            this.lblCp.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblCp.Location = new System.Drawing.Point(1290, 30);
            this.lblCp.Name = "lblCp";
            this.lblCp.Size = new System.Drawing.Size(93, 13);
            this.lblCp.TabIndex = 87;
            this.lblCp.Text = "Contracts Process";
            // 
            // cmbStaff
            // 
            this.cmbStaff.FormattingEnabled = true;
            this.cmbStaff.Location = new System.Drawing.Point(1293, 50);
            this.cmbStaff.Name = "cmbStaff";
            this.cmbStaff.Size = new System.Drawing.Size(106, 21);
            this.cmbStaff.TabIndex = 86;
            this.cmbStaff.SelectionChangeCommitted += new System.EventHandler(this.cmbStaff_SelectionChangeCommitted);
            this.cmbStaff.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbStaff_KeyPress);
            // 
            // lblTndr
            // 
            this.lblTndr.AutoSize = true;
            this.lblTndr.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblTndr.Location = new System.Drawing.Point(1183, 32);
            this.lblTndr.Name = "lblTndr";
            this.lblTndr.Size = new System.Drawing.Size(74, 13);
            this.lblTndr.TabIndex = 85;
            this.lblTndr.Text = "Tender Issues";
            // 
            // cmbTndrHndl
            // 
            this.cmbTndrHndl.FormattingEnabled = true;
            this.cmbTndrHndl.Location = new System.Drawing.Point(1183, 50);
            this.cmbTndrHndl.Name = "cmbTndrHndl";
            this.cmbTndrHndl.Size = new System.Drawing.Size(106, 21);
            this.cmbTndrHndl.TabIndex = 84;
            this.cmbTndrHndl.SelectionChangeCommitted += new System.EventHandler(this.cmbTndrHndl_SelectionChangeCommitted);
            this.cmbTndrHndl.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbTndrHndl_KeyPress);
            // 
            // lblQS
            // 
            this.lblQS.AutoSize = true;
            this.lblQS.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblQS.Location = new System.Drawing.Point(1072, 32);
            this.lblQS.Name = "lblQS";
            this.lblQS.Size = new System.Drawing.Size(68, 13);
            this.lblQS.TabIndex = 83;
            this.lblQS.Text = "Assigned QS";
            // 
            // cmbQs
            // 
            this.cmbQs.FormattingEnabled = true;
            this.cmbQs.Location = new System.Drawing.Point(1072, 50);
            this.cmbQs.Name = "cmbQs";
            this.cmbQs.Size = new System.Drawing.Size(106, 21);
            this.cmbQs.TabIndex = 82;
            this.cmbQs.SelectionChangeCommitted += new System.EventHandler(this.cmbQs_SelectionChangeCommitted);
            this.cmbQs.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbQs_KeyPress);
            // 
            // ProjectsWithSuccessfulBidders
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1774, 796);
            this.Controls.Add(this.lblStaff);
            this.Controls.Add(this.lblCp);
            this.Controls.Add(this.cmbStaff);
            this.Controls.Add(this.lblTndr);
            this.Controls.Add(this.cmbTndrHndl);
            this.Controls.Add(this.lblQS);
            this.Controls.Add(this.cmbQs);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.lblCnt);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.btnAddProject);
            this.Controls.Add(this.dgView);
            this.Controls.Add(this.btnExportToExcel);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnDeleteArchieve);
            this.Controls.Add(this.btnEditArchieve);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnRefresh);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ProjectsWithSuccessfulBidders";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Projects With Tender Number";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgView)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbUserDepart;
        private System.Windows.Forms.Label lblUserDept;
        private System.Windows.Forms.ComboBox cmbTenderCommittee;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cmbTenderNo;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtPrjTitle;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbFiscalYear;
        private System.Windows.Forms.ComboBox cmbTypeofContract;
        private System.Windows.Forms.ComboBox cmbTypeOftender;
        private System.Windows.Forms.ComboBox cmbTenderStatus;
        private System.Windows.Forms.ComboBox cmbCurrentStage;
        private System.Windows.Forms.ComboBox cmbPrjCode;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnExportToExcel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnDeleteArchieve;
        private System.Windows.Forms.Button btnEditArchieve;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.DataGridView dgView;
        private System.Windows.Forms.ComboBox cmbContractNo;
        private System.Windows.Forms.Label lblContractNo;
        private System.Windows.Forms.ComboBox cmbMozanahID;
        private System.Windows.Forms.Label lblMozanahID;
        private System.Windows.Forms.Button btnAddProject;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbFirst;
        private System.Windows.Forms.ToolStripButton tsbPrevious;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel3;
        private System.Windows.Forms.ToolStripButton tsbNext;
        private System.Windows.Forms.ToolStripButton tsbLast;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblCnt;
        private System.Windows.Forms.Label lblStaff;
        private System.Windows.Forms.Label lblCp;
        private System.Windows.Forms.ComboBox cmbStaff;
        private System.Windows.Forms.Label lblTndr;
        private System.Windows.Forms.ComboBox cmbTndrHndl;
        private System.Windows.Forms.Label lblQS;
        private System.Windows.Forms.ComboBox cmbQs;
    }
}