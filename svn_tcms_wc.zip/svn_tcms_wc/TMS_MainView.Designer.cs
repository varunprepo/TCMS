﻿using MDI_ParenrForm;
namespace MDI_ParenrForm
{
    partial class TMS_MainView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TMS_MainView));
            this.aFFAIRSBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblUserName = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnAdmin = new System.Windows.Forms.Button();
            this.btnReports = new System.Windows.Forms.Button();
            this.btnDashboard = new System.Windows.Forms.Button();
            this.btnProjects = new System.Windows.Forms.Button();
            this.btnContacts = new System.Windows.Forms.Button();
            this.btnDocuments = new System.Windows.Forms.Button();
            this.btnDeleteProject = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnAddProject = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnExportToExcel = new System.Windows.Forms.Button();
            this.cmbContractNo = new System.Windows.Forms.ComboBox();
            this.lblContractNo = new System.Windows.Forms.Label();
            this.cmbMozanahID = new System.Windows.Forms.ComboBox();
            this.lblMozanahID = new System.Windows.Forms.Label();
            this.lblDept = new System.Windows.Forms.Label();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.cmbUserDepart = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbFiscalYear = new System.Windows.Forms.ComboBox();
            this.cmbTenderCommittee = new System.Windows.Forms.ComboBox();
            this.cmbPrjCode = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbTypeofContract = new System.Windows.Forms.ComboBox();
            this.cmbTenderNo = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtPrjTitle = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cmbCurrentStage = new System.Windows.Forms.ComboBox();
            this.cmbTypeOftender = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbTenderStatus = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.lblCnt = new System.Windows.Forms.Label();
            this.dgView = new System.Windows.Forms.DataGridView();
            this.spliterForProjects = new System.Windows.Forms.SplitContainer();
            this.lblProfileName = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblStaff = new System.Windows.Forms.Label();
            this.lblCp = new System.Windows.Forms.Label();
            this.cmbStaff = new System.Windows.Forms.ComboBox();
            this.lblTndr = new System.Windows.Forms.Label();
            this.cmbTndrHndl = new System.Windows.Forms.ComboBox();
            this.lblQS = new System.Windows.Forms.Label();
            this.cmbQs = new System.Windows.Forms.ComboBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbFirst = new System.Windows.Forms.ToolStripButton();
            this.tsbPrevious = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this.tsbNext = new System.Windows.Forms.ToolStripButton();
            this.tsbLast = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.aFFAIRSBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spliterForProjects)).BeginInit();
            this.spliterForProjects.Panel1.SuspendLayout();
            this.spliterForProjects.Panel2.SuspendLayout();
            this.spliterForProjects.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // aFFAIRSBindingSource
            // 
            this.aFFAIRSBindingSource.DataMember = "AFFAIRS";
            // 
            // splitContainer1
            // 
            this.splitContainer1.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Top;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.Color.LightSlateGray;
            this.splitContainer1.Panel1.Controls.Add(this.panel1);
            this.splitContainer1.Panel1.Controls.Add(this.groupBox1);
            this.splitContainer1.Panel1.Controls.Add(this.btnAdmin);
            this.splitContainer1.Panel1.Controls.Add(this.btnReports);
            this.splitContainer1.Panel1.Controls.Add(this.btnDashboard);
            this.splitContainer1.Panel1.Controls.Add(this.btnProjects);
            this.splitContainer1.Panel1.Controls.Add(this.btnContacts);
            this.splitContainer1.Panel1.Controls.Add(this.btnDocuments);
            this.splitContainer1.Panel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.BackColor = System.Drawing.Color.Maroon;
            this.splitContainer1.Size = new System.Drawing.Size(1404, 87);
            this.splitContainer1.SplitterDistance = 44;
            this.splitContainer1.SplitterWidth = 1;
            this.splitContainer1.TabIndex = 25;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblUserName);
            this.panel1.Controls.Add(this.linkLabel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(1259, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(145, 44);
            this.panel1.TabIndex = 19;
            // 
            // lblUserName
            // 
            this.lblUserName.AutoSize = true;
            this.lblUserName.BackColor = System.Drawing.Color.LightSlateGray;
            this.lblUserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserName.ForeColor = System.Drawing.Color.White;
            this.lblUserName.Location = new System.Drawing.Point(0, 5);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(29, 13);
            this.lblUserName.TabIndex = 7;
            this.lblUserName.Text = "User";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.Location = new System.Drawing.Point(105, 7);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(42, 13);
            this.linkLabel1.TabIndex = 30;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "logout";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // groupBox1
            // 
            this.groupBox1.AutoSize = true;
            this.groupBox1.BackColor = System.Drawing.Color.LightSlateGray;
            this.groupBox1.Cursor = System.Windows.Forms.Cursors.Default;
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.LightSlateGray;
            this.groupBox1.Location = new System.Drawing.Point(1404, 0);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox1.Size = new System.Drawing.Size(0, 44);
            this.groupBox1.TabIndex = 31;
            this.groupBox1.TabStop = false;
            // 
            // btnAdmin
            // 
            this.btnAdmin.BackColor = System.Drawing.Color.LightSlateGray;
            this.btnAdmin.FlatAppearance.BorderColor = System.Drawing.Color.LightSlateGray;
            this.btnAdmin.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnAdmin.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SaddleBrown;
            this.btnAdmin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdmin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnAdmin.ForeColor = System.Drawing.Color.Black;
            this.btnAdmin.Location = new System.Drawing.Point(737, 0);
            this.btnAdmin.Name = "btnAdmin";
            this.btnAdmin.Size = new System.Drawing.Size(148, 46);
            this.btnAdmin.TabIndex = 6;
            this.btnAdmin.Text = "Admin";
            this.btnAdmin.UseVisualStyleBackColor = false;
            this.btnAdmin.Click += new System.EventHandler(this.btnAdmin_Click);
            // 
            // btnReports
            // 
            this.btnReports.BackColor = System.Drawing.Color.LightSlateGray;
            this.btnReports.FlatAppearance.BorderColor = System.Drawing.Color.LightSlateGray;
            this.btnReports.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnReports.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SaddleBrown;
            this.btnReports.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReports.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnReports.ForeColor = System.Drawing.Color.Black;
            this.btnReports.Location = new System.Drawing.Point(589, 0);
            this.btnReports.Name = "btnReports";
            this.btnReports.Size = new System.Drawing.Size(148, 46);
            this.btnReports.TabIndex = 5;
            this.btnReports.Text = "Reports";
            this.btnReports.UseVisualStyleBackColor = false;
            this.btnReports.Click += new System.EventHandler(this.btnReports_Click);
            // 
            // btnDashboard
            // 
            this.btnDashboard.BackColor = System.Drawing.Color.LightSlateGray;
            this.btnDashboard.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnDashboard.FlatAppearance.BorderColor = System.Drawing.Color.LightSlateGray;
            this.btnDashboard.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnDashboard.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SaddleBrown;
            this.btnDashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDashboard.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnDashboard.ForeColor = System.Drawing.Color.Black;
            this.btnDashboard.Location = new System.Drawing.Point(0, 0);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Size = new System.Drawing.Size(148, 44);
            this.btnDashboard.TabIndex = 1;
            this.btnDashboard.Text = "Dashboard";
            this.btnDashboard.UseVisualStyleBackColor = false;
            this.btnDashboard.Click += new System.EventHandler(this.btnDashboard_Click);
            // 
            // btnProjects
            // 
            this.btnProjects.BackColor = System.Drawing.Color.LightSlateGray;
            this.btnProjects.FlatAppearance.BorderColor = System.Drawing.Color.LightSlateGray;
            this.btnProjects.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SaddleBrown;
            this.btnProjects.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProjects.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnProjects.ForeColor = System.Drawing.Color.Black;
            this.btnProjects.Location = new System.Drawing.Point(145, 0);
            this.btnProjects.Name = "btnProjects";
            this.btnProjects.Size = new System.Drawing.Size(148, 46);
            this.btnProjects.TabIndex = 2;
            this.btnProjects.Text = "All Projects";
            this.btnProjects.UseVisualStyleBackColor = false;
            this.btnProjects.Click += new System.EventHandler(this.btnProjects_Click);
            // 
            // btnContacts
            // 
            this.btnContacts.BackColor = System.Drawing.Color.LightSlateGray;
            this.btnContacts.FlatAppearance.BorderColor = System.Drawing.Color.LightSlateGray;
            this.btnContacts.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnContacts.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SaddleBrown;
            this.btnContacts.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnContacts.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnContacts.ForeColor = System.Drawing.Color.Black;
            this.btnContacts.Location = new System.Drawing.Point(441, 0);
            this.btnContacts.Name = "btnContacts";
            this.btnContacts.Size = new System.Drawing.Size(148, 46);
            this.btnContacts.TabIndex = 4;
            this.btnContacts.Text = "Contacts";
            this.btnContacts.UseVisualStyleBackColor = false;
            this.btnContacts.Click += new System.EventHandler(this.btnContacts_Click);
            // 
            // btnDocuments
            // 
            this.btnDocuments.BackColor = System.Drawing.Color.LightSlateGray;
            this.btnDocuments.FlatAppearance.BorderColor = System.Drawing.Color.LightSlateGray;
            this.btnDocuments.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnDocuments.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SaddleBrown;
            this.btnDocuments.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDocuments.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnDocuments.ForeColor = System.Drawing.Color.Black;
            this.btnDocuments.Location = new System.Drawing.Point(293, 0);
            this.btnDocuments.Name = "btnDocuments";
            this.btnDocuments.Size = new System.Drawing.Size(148, 46);
            this.btnDocuments.TabIndex = 3;
            this.btnDocuments.Text = "Documents";
            this.btnDocuments.UseVisualStyleBackColor = false;
            this.btnDocuments.Click += new System.EventHandler(this.btnDocuments_Click);
            // 
            // btnDeleteProject
            // 
            this.btnDeleteProject.BackColor = System.Drawing.Color.Maroon;
            this.btnDeleteProject.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDeleteProject.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteProject.ForeColor = System.Drawing.Color.White;
            this.btnDeleteProject.Image = global::MDI_ParenrForm.Properties.Resources.Actions_window_close_icon;
            this.btnDeleteProject.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDeleteProject.Location = new System.Drawing.Point(319, 13);
            this.btnDeleteProject.Name = "btnDeleteProject";
            this.btnDeleteProject.Size = new System.Drawing.Size(85, 30);
            this.btnDeleteProject.TabIndex = 48;
            this.btnDeleteProject.Text = "Delete";
            this.btnDeleteProject.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDeleteProject.UseVisualStyleBackColor = false;
            this.btnDeleteProject.Click += new System.EventHandler(this.btnDeleteProject_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackColor = System.Drawing.Color.Maroon;
            this.btnEdit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.ForeColor = System.Drawing.Color.White;
            this.btnEdit.Image = global::MDI_ParenrForm.Properties.Resources.Text_Edit_icon__1_;
            this.btnEdit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEdit.Location = new System.Drawing.Point(140, 13);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(178, 30);
            this.btnEdit.TabIndex = 49;
            this.btnEdit.Text = "View/ Edit Project Details";
            this.btnEdit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEdit.UseVisualStyleBackColor = false;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnAddProject
            // 
            this.btnAddProject.BackColor = System.Drawing.Color.Maroon;
            this.btnAddProject.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAddProject.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddProject.ForeColor = System.Drawing.Color.White;
            this.btnAddProject.Image = global::MDI_ParenrForm.Properties.Resources.coin_add_icon;
            this.btnAddProject.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddProject.Location = new System.Drawing.Point(11, 13);
            this.btnAddProject.Name = "btnAddProject";
            this.btnAddProject.Size = new System.Drawing.Size(128, 30);
            this.btnAddProject.TabIndex = 47;
            this.btnAddProject.Text = "Add New Project";
            this.btnAddProject.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAddProject.UseVisualStyleBackColor = false;
            this.btnAddProject.Click += new System.EventHandler(this.button4_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnExportToExcel);
            this.groupBox2.Controls.Add(this.cmbContractNo);
            this.groupBox2.Controls.Add(this.lblContractNo);
            this.groupBox2.Controls.Add(this.cmbMozanahID);
            this.groupBox2.Controls.Add(this.lblMozanahID);
            this.groupBox2.Controls.Add(this.lblDept);
            this.groupBox2.Controls.Add(this.btnRefresh);
            this.groupBox2.Controls.Add(this.cmbUserDepart);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.cmbFiscalYear);
            this.groupBox2.Controls.Add(this.cmbTenderCommittee);
            this.groupBox2.Controls.Add(this.cmbPrjCode);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.cmbTypeofContract);
            this.groupBox2.Controls.Add(this.cmbTenderNo);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.txtPrjTitle);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.cmbCurrentStage);
            this.groupBox2.Controls.Add(this.cmbTypeOftender);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.cmbTenderStatus);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(0, 60);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1402, 91);
            this.groupBox2.TabIndex = 51;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Search Project Details";
            // 
            // btnExportToExcel
            // 
            this.btnExportToExcel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnExportToExcel.Location = new System.Drawing.Point(1474, 11);
            this.btnExportToExcel.Name = "btnExportToExcel";
            this.btnExportToExcel.Size = new System.Drawing.Size(106, 28);
            this.btnExportToExcel.TabIndex = 58;
            this.btnExportToExcel.Text = "Export To Excel";
            this.btnExportToExcel.UseVisualStyleBackColor = true;
            this.btnExportToExcel.Click += new System.EventHandler(this.btnExportToExcel_Click);
            // 
            // cmbContractNo
            // 
            this.cmbContractNo.FormattingEnabled = true;
            this.cmbContractNo.Location = new System.Drawing.Point(1024, 50);
            this.cmbContractNo.Name = "cmbContractNo";
            this.cmbContractNo.Size = new System.Drawing.Size(111, 23);
            this.cmbContractNo.TabIndex = 57;
            this.cmbContractNo.SelectionChangeCommitted += new System.EventHandler(this.cmbContractNo_SelectionChangeCommitted);
            this.cmbContractNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbContractNo_KeyPress);
            // 
            // lblContractNo
            // 
            this.lblContractNo.AutoSize = true;
            this.lblContractNo.Location = new System.Drawing.Point(1027, 32);
            this.lblContractNo.Name = "lblContractNo";
            this.lblContractNo.Size = new System.Drawing.Size(68, 15);
            this.lblContractNo.TabIndex = 56;
            this.lblContractNo.Text = "ContractNo";
            // 
            // cmbMozanahID
            // 
            this.cmbMozanahID.FormattingEnabled = true;
            this.cmbMozanahID.Location = new System.Drawing.Point(1311, 50);
            this.cmbMozanahID.Name = "cmbMozanahID";
            this.cmbMozanahID.Size = new System.Drawing.Size(174, 23);
            this.cmbMozanahID.TabIndex = 55;
            this.cmbMozanahID.Visible = false;
            this.cmbMozanahID.SelectionChangeCommitted += new System.EventHandler(this.cmbMozanahID_SelectionChangeCommitted);
            this.cmbMozanahID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbMozanahID_KeyPress);
            // 
            // lblMozanahID
            // 
            this.lblMozanahID.AutoSize = true;
            this.lblMozanahID.Location = new System.Drawing.Point(1310, 32);
            this.lblMozanahID.Name = "lblMozanahID";
            this.lblMozanahID.Size = new System.Drawing.Size(71, 15);
            this.lblMozanahID.TabIndex = 54;
            this.lblMozanahID.Text = "MozanahID";
            this.lblMozanahID.Visible = false;
            // 
            // lblDept
            // 
            this.lblDept.AutoSize = true;
            this.lblDept.Location = new System.Drawing.Point(1217, 32);
            this.lblDept.Name = "lblDept";
            this.lblDept.Size = new System.Drawing.Size(72, 15);
            this.lblDept.TabIndex = 53;
            this.lblDept.Text = "Department";
            // 
            // btnRefresh
            // 
            this.btnRefresh.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefresh.ForeColor = System.Drawing.Color.Coral;
            this.btnRefresh.Image = global::MDI_ParenrForm.Properties.Resources.Button_Reload_icon;
            this.btnRefresh.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRefresh.Location = new System.Drawing.Point(1496, 43);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(84, 30);
            this.btnRefresh.TabIndex = 50;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // cmbUserDepart
            // 
            this.cmbUserDepart.FormattingEnabled = true;
            this.cmbUserDepart.Location = new System.Drawing.Point(1220, 51);
            this.cmbUserDepart.Name = "cmbUserDepart";
            this.cmbUserDepart.Size = new System.Drawing.Size(80, 23);
            this.cmbUserDepart.TabIndex = 52;
            this.cmbUserDepart.SelectionChangeCommitted += new System.EventHandler(this.cmbUserDepart_SelectionChangeCommitted);
            this.cmbUserDepart.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbUserDepart_OnKeyPress);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label12.Location = new System.Drawing.Point(846, 18);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(67, 30);
            this.label12.TabIndex = 42;
            this.label12.Text = "Tender \r\nCommittee";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.Location = new System.Drawing.Point(1141, 34);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 15);
            this.label6.TabIndex = 27;
            this.label6.Text = "Fiscal Year";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label5.Location = new System.Drawing.Point(929, 18);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 30);
            this.label5.TabIndex = 26;
            this.label5.Text = "Type Of \r\nContract ";
            // 
            // cmbFiscalYear
            // 
            this.cmbFiscalYear.FormattingEnabled = true;
            this.cmbFiscalYear.Location = new System.Drawing.Point(1142, 51);
            this.cmbFiscalYear.Name = "cmbFiscalYear";
            this.cmbFiscalYear.Size = new System.Drawing.Size(69, 23);
            this.cmbFiscalYear.TabIndex = 34;
            this.cmbFiscalYear.SelectionChangeCommitted += new System.EventHandler(this.cmbFiscalYear_SelectionChangeCommitted);
            this.cmbFiscalYear.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbFiscalYear_OnKeyPress);
            // 
            // cmbTenderCommittee
            // 
            this.cmbTenderCommittee.FormattingEnabled = true;
            this.cmbTenderCommittee.Location = new System.Drawing.Point(845, 51);
            this.cmbTenderCommittee.Name = "cmbTenderCommittee";
            this.cmbTenderCommittee.Size = new System.Drawing.Size(78, 23);
            this.cmbTenderCommittee.TabIndex = 43;
            this.cmbTenderCommittee.SelectionChangeCommitted += new System.EventHandler(this.cmbtenderCommitte_SelectionChangeCommitted);
            this.cmbTenderCommittee.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbtenderCommitte_OnKeyPress);
            // 
            // cmbPrjCode
            // 
            this.cmbPrjCode.FormattingEnabled = true;
            this.cmbPrjCode.Location = new System.Drawing.Point(11, 51);
            this.cmbPrjCode.Name = "cmbPrjCode";
            this.cmbPrjCode.Size = new System.Drawing.Size(164, 23);
            this.cmbPrjCode.TabIndex = 29;
            this.cmbPrjCode.SelectionChangeCommitted += new System.EventHandler(this.cmbPrjCode_SelectionChangeCommitted);
            this.cmbPrjCode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbPrjCode_OnKeyPress);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label8.Location = new System.Drawing.Point(10, 33);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 15);
            this.label8.TabIndex = 35;
            this.label8.Text = "Project Code";
            // 
            // cmbTypeofContract
            // 
            this.cmbTypeofContract.FormattingEnabled = true;
            this.cmbTypeofContract.Location = new System.Drawing.Point(927, 51);
            this.cmbTypeofContract.Name = "cmbTypeofContract";
            this.cmbTypeofContract.Size = new System.Drawing.Size(91, 23);
            this.cmbTypeofContract.TabIndex = 33;
            this.cmbTypeofContract.SelectionChangeCommitted += new System.EventHandler(this.cmbTypeofContract_SelectionChangeCommitted);
            this.cmbTypeofContract.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbTypeofContract_OnKeyPress);
            // 
            // cmbTenderNo
            // 
            this.cmbTenderNo.FormattingEnabled = true;
            this.cmbTenderNo.Location = new System.Drawing.Point(364, 51);
            this.cmbTenderNo.Name = "cmbTenderNo";
            this.cmbTenderNo.Size = new System.Drawing.Size(162, 23);
            this.cmbTenderNo.TabIndex = 39;
            this.cmbTenderNo.SelectionChangeCommitted += new System.EventHandler(this.cmbTenderNo_SelectionChangeCommitted);
            this.cmbTenderNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbTenderNo_OnKeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(749, 35);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 15);
            this.label4.TabIndex = 25;
            this.label4.Text = "Type Of Tender ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(635, 33);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 15);
            this.label3.TabIndex = 24;
            this.label3.Text = "Tender Status";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label10.Location = new System.Drawing.Point(362, 33);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(68, 15);
            this.label10.TabIndex = 38;
            this.label10.Text = "Tender No.";
            // 
            // txtPrjTitle
            // 
            this.txtPrjTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrjTitle.Location = new System.Drawing.Point(177, 51);
            this.txtPrjTitle.Name = "txtPrjTitle";
            this.txtPrjTitle.Size = new System.Drawing.Size(185, 23);
            this.txtPrjTitle.TabIndex = 37;
            this.txtPrjTitle.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPrjTitle_KeyPress);
            this.txtPrjTitle.Leave += new System.EventHandler(this.txtPrjTitle_Leave);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label9.Location = new System.Drawing.Point(174, 33);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(71, 15);
            this.label9.TabIndex = 36;
            this.label9.Text = "Project Title";
            // 
            // cmbCurrentStage
            // 
            this.cmbCurrentStage.FormattingEnabled = true;
            this.cmbCurrentStage.Location = new System.Drawing.Point(529, 51);
            this.cmbCurrentStage.Name = "cmbCurrentStage";
            this.cmbCurrentStage.Size = new System.Drawing.Size(105, 23);
            this.cmbCurrentStage.TabIndex = 30;
            this.cmbCurrentStage.SelectionChangeCommitted += new System.EventHandler(this.cmbCurrentStage_SelectionChangeCommitted);
            this.cmbCurrentStage.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbCurrentStage_OnKeyPress);
            // 
            // cmbTypeOftender
            // 
            this.cmbTypeOftender.FormattingEnabled = true;
            this.cmbTypeOftender.Location = new System.Drawing.Point(752, 51);
            this.cmbTypeOftender.Name = "cmbTypeOftender";
            this.cmbTypeOftender.Size = new System.Drawing.Size(91, 23);
            this.cmbTypeOftender.TabIndex = 32;
            this.cmbTypeOftender.SelectionChangeCommitted += new System.EventHandler(this.cmbTypeOftender_SelectionChangeCommitted);
            this.cmbTypeOftender.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbTypeOftender_OnKeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label7.Location = new System.Drawing.Point(527, 34);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 15);
            this.label7.TabIndex = 22;
            this.label7.Text = "Current Stage";
            // 
            // cmbTenderStatus
            // 
            this.cmbTenderStatus.FormattingEnabled = true;
            this.cmbTenderStatus.Location = new System.Drawing.Point(636, 51);
            this.cmbTenderStatus.Name = "cmbTenderStatus";
            this.cmbTenderStatus.Size = new System.Drawing.Size(114, 23);
            this.cmbTenderStatus.TabIndex = 31;
            this.cmbTenderStatus.SelectionChangeCommitted += new System.EventHandler(this.cmbTenderStatus_SelectionChangeCommitted);
            this.cmbTenderStatus.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbTenderStatus_OnKeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(190, 299);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 23;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.lblCnt);
            this.panel2.Location = new System.Drawing.Point(491, 13);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(257, 32);
            this.panel2.TabIndex = 55;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label14.Location = new System.Drawing.Point(20, 8);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(112, 13);
            this.label14.TabIndex = 54;
            this.label14.Text = "Total Projects Count : ";
            // 
            // lblCnt
            // 
            this.lblCnt.AutoSize = true;
            this.lblCnt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblCnt.Location = new System.Drawing.Point(138, 8);
            this.lblCnt.Name = "lblCnt";
            this.lblCnt.Size = new System.Drawing.Size(41, 13);
            this.lblCnt.TabIndex = 53;
            this.lblCnt.Text = "label14";
            // 
            // dgView
            // 
            this.dgView.AllowUserToOrderColumns = true;
            this.dgView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dgView.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.Padding = new System.Windows.Forms.Padding(8);
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.HotPink;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.25F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Peru;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgView.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgView.GridColor = System.Drawing.Color.Olive;
            this.dgView.Location = new System.Drawing.Point(0, 28);
            this.dgView.Name = "dgView";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgView.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgView.RowHeadersVisible = false;
            this.dgView.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgView.Size = new System.Drawing.Size(1700, 700);
            this.dgView.TabIndex = 46;
            this.dgView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgView_CellContentClick);
            this.dgView.CellValidated += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgView_CellValidated);
            // 
            // spliterForProjects
            // 
            this.spliterForProjects.BackColor = System.Drawing.Color.LightCyan;
            this.spliterForProjects.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.spliterForProjects.Dock = System.Windows.Forms.DockStyle.Fill;
            this.spliterForProjects.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.spliterForProjects.IsSplitterFixed = true;
            this.spliterForProjects.Location = new System.Drawing.Point(0, 87);
            this.spliterForProjects.Name = "spliterForProjects";
            this.spliterForProjects.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // spliterForProjects.Panel1
            // 
            this.spliterForProjects.Panel1.Controls.Add(this.lblProfileName);
            this.spliterForProjects.Panel1.Controls.Add(this.label11);
            this.spliterForProjects.Panel1.Controls.Add(this.lblStaff);
            this.spliterForProjects.Panel1.Controls.Add(this.lblCp);
            this.spliterForProjects.Panel1.Controls.Add(this.cmbStaff);
            this.spliterForProjects.Panel1.Controls.Add(this.lblTndr);
            this.spliterForProjects.Panel1.Controls.Add(this.cmbTndrHndl);
            this.spliterForProjects.Panel1.Controls.Add(this.lblQS);
            this.spliterForProjects.Panel1.Controls.Add(this.cmbQs);
            this.spliterForProjects.Panel1.Controls.Add(this.btnAddProject);
            this.spliterForProjects.Panel1.Controls.Add(this.groupBox2);
            this.spliterForProjects.Panel1.Controls.Add(this.label2);
            this.spliterForProjects.Panel1.Controls.Add(this.btnDeleteProject);
            this.spliterForProjects.Panel1.Controls.Add(this.panel2);
            this.spliterForProjects.Panel1.Controls.Add(this.btnEdit);
            // 
            // spliterForProjects.Panel2
            // 
            this.spliterForProjects.Panel2.Controls.Add(this.toolStrip1);
            this.spliterForProjects.Panel2.Controls.Add(this.dgView);
            this.spliterForProjects.Size = new System.Drawing.Size(1404, 685);
            this.spliterForProjects.SplitterDistance = 153;
            this.spliterForProjects.SplitterWidth = 1;
            this.spliterForProjects.TabIndex = 29;
            // 
            // lblProfileName
            // 
            this.lblProfileName.AutoSize = true;
            this.lblProfileName.Dock = System.Windows.Forms.DockStyle.Right;
            this.lblProfileName.Location = new System.Drawing.Point(1391, 0);
            this.lblProfileName.Name = "lblProfileName";
            this.lblProfileName.Size = new System.Drawing.Size(11, 13);
            this.lblProfileName.TabIndex = 32;
            this.lblProfileName.Text = "*";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(630, 69);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(11, 13);
            this.label11.TabIndex = 63;
            this.label11.Text = "*";
            // 
            // lblStaff
            // 
            this.lblStaff.AutoSize = true;
            this.lblStaff.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStaff.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblStaff.Location = new System.Drawing.Point(897, -1);
            this.lblStaff.Name = "lblStaff";
            this.lblStaff.Size = new System.Drawing.Size(210, 15);
            this.lblStaff.TabIndex = 62;
            this.lblStaff.Text = "Filter Projects By Assigned Staff";
            this.lblStaff.Visible = false;
            // 
            // lblCp
            // 
            this.lblCp.AutoSize = true;
            this.lblCp.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblCp.Location = new System.Drawing.Point(1053, 20);
            this.lblCp.Name = "lblCp";
            this.lblCp.Size = new System.Drawing.Size(93, 13);
            this.lblCp.TabIndex = 61;
            this.lblCp.Text = "Contracts Process";
            this.lblCp.Visible = false;
            // 
            // cmbStaff
            // 
            this.cmbStaff.FormattingEnabled = true;
            this.cmbStaff.Location = new System.Drawing.Point(1056, 40);
            this.cmbStaff.Name = "cmbStaff";
            this.cmbStaff.Size = new System.Drawing.Size(106, 21);
            this.cmbStaff.TabIndex = 60;
            this.cmbStaff.Visible = false;
            this.cmbStaff.SelectionChangeCommitted += new System.EventHandler(this.cmbStaff_SelectionChangeCommitted);
            this.cmbStaff.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbStaff_KeyPress);
            // 
            // lblTndr
            // 
            this.lblTndr.AutoSize = true;
            this.lblTndr.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblTndr.Location = new System.Drawing.Point(946, 22);
            this.lblTndr.Name = "lblTndr";
            this.lblTndr.Size = new System.Drawing.Size(74, 13);
            this.lblTndr.TabIndex = 59;
            this.lblTndr.Text = "Tender Issues";
            this.lblTndr.Visible = false;
            // 
            // cmbTndrHndl
            // 
            this.cmbTndrHndl.FormattingEnabled = true;
            this.cmbTndrHndl.Location = new System.Drawing.Point(946, 40);
            this.cmbTndrHndl.Name = "cmbTndrHndl";
            this.cmbTndrHndl.Size = new System.Drawing.Size(106, 21);
            this.cmbTndrHndl.TabIndex = 58;
            this.cmbTndrHndl.Visible = false;
            this.cmbTndrHndl.SelectionChangeCommitted += new System.EventHandler(this.cmbTndrHndl_SelectionChangeCommitted);
            this.cmbTndrHndl.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbTndrHndl_KeyPress);
            // 
            // lblQS
            // 
            this.lblQS.AutoSize = true;
            this.lblQS.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblQS.Location = new System.Drawing.Point(835, 22);
            this.lblQS.Name = "lblQS";
            this.lblQS.Size = new System.Drawing.Size(68, 13);
            this.lblQS.TabIndex = 57;
            this.lblQS.Text = "Assigned QS";
            this.lblQS.Visible = false;
            // 
            // cmbQs
            // 
            this.cmbQs.FormattingEnabled = true;
            this.cmbQs.Location = new System.Drawing.Point(835, 40);
            this.cmbQs.Name = "cmbQs";
            this.cmbQs.Size = new System.Drawing.Size(106, 21);
            this.cmbQs.TabIndex = 56;
            this.cmbQs.Visible = false;
            this.cmbQs.SelectionChangeCommitted += new System.EventHandler(this.cmbQs_SelectionChangeCommitted);
            this.cmbQs.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbQs_KeyPress);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbFirst,
            this.tsbPrevious,
            this.toolStripLabel2,
            this.toolStripLabel1,
            this.toolStripLabel3,
            this.tsbNext,
            this.tsbLast});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1402, 25);
            this.toolStrip1.TabIndex = 47;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsbFirst
            // 
            this.tsbFirst.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbFirst.Image = ((System.Drawing.Image)(resources.GetObject("tsbFirst.Image")));
            this.tsbFirst.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbFirst.Name = "tsbFirst";
            this.tsbFirst.Size = new System.Drawing.Size(33, 22);
            this.tsbFirst.Text = "First";
            this.tsbFirst.Click += new System.EventHandler(this.tsbFirst_Click);
            // 
            // tsbPrevious
            // 
            this.tsbPrevious.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbPrevious.Image = ((System.Drawing.Image)(resources.GetObject("tsbPrevious.Image")));
            this.tsbPrevious.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPrevious.Name = "tsbPrevious";
            this.tsbPrevious.Size = new System.Drawing.Size(56, 22);
            this.tsbPrevious.Text = "Previous";
            this.tsbPrevious.Click += new System.EventHandler(this.tsbPrevious_Click);
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(0, 22);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(18, 22);
            this.toolStripLabel1.Text = "of";
            // 
            // toolStripLabel3
            // 
            this.toolStripLabel3.Name = "toolStripLabel3";
            this.toolStripLabel3.Size = new System.Drawing.Size(0, 22);
            // 
            // tsbNext
            // 
            this.tsbNext.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbNext.Image = ((System.Drawing.Image)(resources.GetObject("tsbNext.Image")));
            this.tsbNext.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbNext.Name = "tsbNext";
            this.tsbNext.Size = new System.Drawing.Size(36, 22);
            this.tsbNext.Text = "Next";
            this.tsbNext.Click += new System.EventHandler(this.tsbNext_Click);
            // 
            // tsbLast
            // 
            this.tsbLast.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbLast.Image = ((System.Drawing.Image)(resources.GetObject("tsbLast.Image")));
            this.tsbLast.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbLast.Name = "tsbLast";
            this.tsbLast.Size = new System.Drawing.Size(32, 22);
            this.tsbLast.Text = "Last";
            this.tsbLast.Click += new System.EventHandler(this.tsbLast_Click);
            // 
            // TMS_MainView
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(236)))), ((int)(((byte)(236)))));
            this.BackgroundImage = global::MDI_ParenrForm.Properties.Resources.BackColor;
            this.ClientSize = new System.Drawing.Size(1404, 772);
            this.Controls.Add(this.spliterForProjects);
            this.Controls.Add(this.splitContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "TMS_MainView";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tender  & Contract Management System *** V 2.5.7";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.TMS_MainView_FormClosed);
            this.Load += new System.EventHandler(this.MDIParent1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.aFFAIRSBindingSource)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgView)).EndInit();
            this.spliterForProjects.Panel1.ResumeLayout(false);
            this.spliterForProjects.Panel1.PerformLayout();
            this.spliterForProjects.Panel2.ResumeLayout(false);
            this.spliterForProjects.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spliterForProjects)).EndInit();
            this.spliterForProjects.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);

        }
        #endregion

      
        private System.Windows.Forms.BindingSource aFFAIRSBindingSource;

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button btnAdmin;
        private System.Windows.Forms.Button btnReports;
        private System.Windows.Forms.Button btnDashboard;
        private System.Windows.Forms.Button btnProjects;
        private System.Windows.Forms.Button btnContacts;
        private System.Windows.Forms.Button btnDocuments;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnDeleteProject;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnAddProject;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cmbTenderCommittee;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.ComboBox cmbTenderNo;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtPrjTitle;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbFiscalYear;
        private System.Windows.Forms.ComboBox cmbTypeofContract;
        private System.Windows.Forms.ComboBox cmbTypeOftender;
        private System.Windows.Forms.ComboBox cmbTenderStatus;
        private System.Windows.Forms.ComboBox cmbCurrentStage;
        private System.Windows.Forms.ComboBox cmbPrjCode;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblCnt;
        private System.Windows.Forms.DataGridView dgView;
        private System.Windows.Forms.SplitContainer spliterForProjects;
        private System.Windows.Forms.ComboBox cmbUserDepart;
        private System.Windows.Forms.Label lblDept;
        private System.Windows.Forms.ComboBox cmbQs;
        private System.Windows.Forms.Label lblQS;
        private System.Windows.Forms.Label lblTndr;
        private System.Windows.Forms.ComboBox cmbTndrHndl;
        private System.Windows.Forms.Label lblCp;
        private System.Windows.Forms.ComboBox cmbStaff;
        private System.Windows.Forms.Label lblStaff;
        private System.Windows.Forms.Label lblProfileName;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbFirst;
        private System.Windows.Forms.ToolStripButton tsbPrevious;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripButton tsbNext;
        private System.Windows.Forms.ToolStripButton tsbLast;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripLabel toolStripLabel3;
        private System.Windows.Forms.ComboBox cmbMozanahID;
        private System.Windows.Forms.Label lblMozanahID;
        private System.Windows.Forms.ComboBox cmbContractNo;
        private System.Windows.Forms.Label lblContractNo;
        private System.Windows.Forms.Button btnExportToExcel;
   

    }
}



