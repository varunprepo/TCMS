﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using MDI_ParenrForm;

namespace MDI_ParenrForm
{
    public partial class CustomDialog : Form
    {
        private string connStr = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();
        SqlConnection sqlConn = null;
        public CustomDialog()
        {
            InitializeComponent();
            sqlConn = new SqlConnection(connStr);
        }

        private void btnYes_Click(object sender, EventArgs e)
        {             
            try
            {
                sqlConn.Open();
                using (SqlCommand sqlCom = new SqlCommand("Delete from Projects where Proj_id =" + CommonClass.prjID + "", sqlConn))
                {
                    sqlCom.ExecuteNonQuery();                               
                }
                using (SqlCommand sqlCom = new SqlCommand("Delete from TenderDatesInfo where Proj_id =" + CommonClass.prjID + "", sqlConn))
                {
                    sqlCom.ExecuteNonQuery();            
                }
                using (SqlCommand sqlCom = new SqlCommand("Delete from ProjectCost where Proj_id =" + CommonClass.prjID + "", sqlConn))
                {
                    sqlCom.ExecuteNonQuery();
                }
                using (SqlCommand sqlCom = new SqlCommand("Delete from DOCUMENTS where Proj_id =" + CommonClass.prjID + "", sqlConn))
                {
                    sqlCom.ExecuteNonQuery();
                }
                using (SqlCommand sqlCom = new SqlCommand("Delete from CONTRACTORS where Proj_id =" + CommonClass.prjID + "", sqlConn))
                {
                    sqlCom.ExecuteNonQuery();
                }
                this.Close();
                MessageBox.Show("Record deleted Successfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception occurred while deleting the data.", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnNo_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
