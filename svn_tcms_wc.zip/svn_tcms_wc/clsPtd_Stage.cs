﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Windows.Forms;
using TenderTrackingSystem;

namespace MDI_ParenrForm
{
    class clsPtd_Stage        // Class defined for Tender Preparation Stage (Stage 1)
    {
        DAL dalObj = new DAL(); 
        string connStr = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();
        string _userName = string.Empty;
        public clsPtd_Stage(string user)
        {
            _userName = user;
        }
        public void CreateGridviewForPTD(DataGridView dgvPTD, int ptd_prjID)
        {
            //SqlConnection sqlConn = new SqlConnection(connStr);
            if (dgvPTD.ColumnCount != 0)
            {

                var col0 = new DataGridViewTextBoxColumn();
                var col1 = new DataGridViewTextBoxColumn();
                var col2 = new DataGridViewTextBoxColumn();        // DataGridViewAutoFilterTextBoxColumn();
                var col3 = new DataGridViewTextBoxColumn();
                var col4 = new DataGridViewTextBoxColumn();
                var col5 = new DataGridViewTextBoxColumn();
                var col6 = new DataGridViewTextBoxColumn();
                var col7 = new DataGridViewTextBoxColumn();
                var col8 = new DataGridViewTextBoxColumn();

                dgvPTD.Columns.AddRange(new DataGridViewColumn[] { col0, col1, col2, col3, col4, col5, col6, col7, col8 });
                dgvPTD.AutoGenerateColumns = false;
                dgvPTD.AllowUserToAddRows = false;
                dgvPTD.AutoResizeColumns();
                dgvPTD.AllowUserToOrderColumns = false;

                col0.DataPropertyName = "ReceivedOn";
                col0.HeaderText = "Received On";
                col0.Width = 120;

                col1.DataPropertyName = "Purpose";
                col1.HeaderText = "Purpose";
                col1.Width = 115;


                //col1.Items.Add("Preparation");
                //col1.Items.Add("Review");
                //col1.Items.Add("Re-Tender");

                col2.DataPropertyName = "AssignedQS";
                col2.HeaderText = "Assigned QS";
                col2.Width = 121;

                //col2.Items.Add("Fady");
                //col2.Items.Add("GH");
                //col2.Items.Add("Hafiz");

                col3.DataPropertyName = "Review";
                col3.HeaderText = "Sent to Dept. for Review/with comments";
                col3.Width = 126;

                col4.DataPropertyName = "QSWorkingStatus";
                col4.HeaderText = "QS Working Status";
                //col4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
                col4.Width = 110;

                //col4.Items.Add("On-Hold");
                //col4.Items.Add("On-going");
                //col4.Items.Add("Completed");

                col5.DataPropertyName = "TenderDocumentCurrentStatus";
                col5.HeaderText = "Tender Document Current Status";
                col5.Width = 116;

                //col5.Items.Add("Approved");
                //col5.Items.Add("Disapproved");


                col6.DataPropertyName = "ForwardedToEndUserDepartment";
                col6.HeaderText = "Forwarded to Department";
                col6.Width = 116;

                col7.DataPropertyName = "Remarks";
                col7.HeaderText = "Remarks";
                //col7.Width = 120;

                col8.DataPropertyName = "DateID";
                col8.HeaderText = "DateID";
                col8.Width = 0;
            }
            //if(dgvPTD.Rows.Count !=0)
            //    dgvPTD.Rows.Clear();
            DataTable dtProject = null;
            string[] projRows = new string[8];

            try
            {               
                //sqlConn.Open();
                dtProject = dalObj.GetDataFromDB("ProjectPTD", "SELECT REPLACE(CONVERT(nvarchar, ptd_receive_on, 106), ' ', '/') AS ReceivedOn, ptd_purpose As Purpose, " +
                "ptd_assign_qs As AssignedQS, REPLACE(CONVERT(nvarchar,ptd_sent_for_rev, 106), ' ', '/') As Review, ptd_qs_working_status As QSWorkingStatus, ptd_tendec_doc_cur_status As TenderDocumentCurrentStatus, " +
                "REPLACE(CONVERT(nvarchar,ptd_forwarded_to_dep, 106), ' ', '/') As ForwardedToEndUserDepartment, remarks As Remarks,date_id As DateID,proj_id, stage_id FROM TenderDatesInfo WHERE (stage_id = 1) AND (proj_id = " + ptd_prjID + " )");               

                if (dtProject.Rows.Count > 0)
                {
                    dtProject.DefaultView.Sort = "DateID";
                    BindingSource myBindingSource = new BindingSource(dtProject, null);
                    dgvPTD.DataSource = myBindingSource;
                    //dgvPTD.ColumnHeadersDefaultCellStyle.BackColor = Color.DimGray;                     

                    dgvPTD.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                    dgvPTD.Columns[8].Visible = false;
                    dgvPTD.Columns[9].Visible = false;
                    dgvPTD.Columns[10].Visible = false;
                }
                else
                {
                    dgvPTD.DataSource = null;
                }
              
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            
        }
        public void UpdateStageLevel(int stg2_prjID)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]= 2,[stage_id]= 2 Where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@projId", stg2_prjID);
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        public void UpdateFromTPtoTS(int prjID)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]= 1,[Stage_ID]= 1 Where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@projId", prjID);
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
