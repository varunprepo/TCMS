﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Windows.Forms;
using TenderTrackingSystem;

namespace MDI_ParenrForm
{
    class clsTE_Stage
    {
        DAL dalObj = new DAL();
        string connStr = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();
        string _userName = string.Empty;
        public clsTE_Stage(string user)
        {
            _userName = user;
        }
        public void UpdateTenderStatusForAward(int upd_projID)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]= 6 , [stage_id]= 3 Where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@projId", upd_projID);
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating project status, Try again.", ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        public void UpdateTenderStatusForFinancialData(int upd_PrjID)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]= 4 , [stage_id]= 3 Where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@projId", upd_PrjID);
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE TenderDatesInfo records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        public void UpdateTenderStatusForEvaluationData(int upd_PrjID)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]= 3 , [stage_id]= 3 Where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@projId", upd_PrjID);
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the project info, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        public void UpdateTenderStatusFor_Tech_and_EvaluationData(int upd_PrjID)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]= 5 , [stage_id]= 3 Where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@projId", upd_PrjID);
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the project info, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }




        public Boolean CheckProjectCostDataExist(int chk_prjID)
        {
            string strQuery1 = "";
            strQuery1 = "Select * From ProjectCost Where Proj_ID = " + chk_prjID + " and Stage_id = 4";
            try
            {
                using (SqlConnection sqlCn = new SqlConnection(connStr))
                {
                    sqlCn.Open();
                    using (SqlCommand sqlCmd = new SqlCommand(strQuery1, sqlCn))
                    {
                        using (SqlDataReader sqlread = sqlCmd.ExecuteReader())
                        {
                            if (sqlread.HasRows)
                            {
                                return true;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
            }
            return false;
        } 
        public void InsertTE_Budget_ProjectCostData(string txtAmont,int insert_prjID)
        {
            
            string insertQueryBdgt = "INSERT INTO ProjectCost(stage_id, proj_id, budgeted_cost,create_user,create_date) VALUES(@stgID,@PrjID,@budgeted_cost,@createUser,@createDate)";
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                sqlConn.Open();
                using (SqlCommand cmd = new SqlCommand(insertQueryBdgt, sqlConn))
                {

                    cmd.Parameters.AddWithValue("@stgID", 4);
                    cmd.Parameters.AddWithValue("@PrjID", insert_prjID);
                    if (txtAmont != "")
                    {
                        if (txtAmont.Contains("QAR"))
                        {
                            string budjetAmnt = txtAmont.Substring(3, txtAmont.Length - 3);
                            // txtMozBudjet.Text = txtMozBudjet.Text.Substring(0, txtMozBudjet.Text.Length);
                            cmd.Parameters.AddWithValue("@budgeted_cost", Convert.ToDouble(budjetAmnt));
                        }
                        else
                        {
                            string budjetAmnt = txtAmont;
                            cmd.Parameters.AddWithValue("@budgeted_cost", Convert.ToDouble(budjetAmnt));
                        }
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("@budgeted_cost", DBNull.Value);
                    }

                    cmd.Parameters.AddWithValue("@createUser", _userName);
                    cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                    int exUpdated = cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                }
            }
        }
        public void UpdateTE_BudgetAmount_ProjectCostData(string txtAmnt, int upd_PrjID)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"UPDATE PROJECTCOST SET budgeted_cost=@BdgtAmnt, update_user=@updateUser, update_date=@updateDate where proj_id=@prjID and Stage_ID= 4";
                        if(txtAmnt!="")
                            cmd.Parameters.AddWithValue("@BdgtAmnt", Convert.ToDouble(txtAmnt));
                        else
                            cmd.Parameters.AddWithValue("@BdgtAmnt", System.DBNull.Value);
                        cmd.Parameters.AddWithValue("@prjID", upd_PrjID);
                        cmd.Parameters.AddWithValue("@updateUser", _userName);
                        cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the Tender Bond Amount records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        public void InsertTE_Estimate_ProjectCostData(string txtAmont, int insert_PrjID)
        {
            string insertQueryBdgt = "INSERT INTO ProjectCost(stage_id, proj_id, estimated_cost,create_user,create_date) VALUES(@stgID,@PrjID,@estimated_cost,@createUser,@createDate)";
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                sqlConn.Open();
                using (SqlCommand cmd = new SqlCommand(insertQueryBdgt, sqlConn))
                {
                    cmd.Parameters.AddWithValue("@stgID", 4);
                    cmd.Parameters.AddWithValue("@PrjID", insert_PrjID);
                    if (txtAmont != "")
                    {
                        if (txtAmont.Contains("QAR"))
                        {
                            string budjetAmnt = txtAmont.Substring(3, txtAmont.Length - 3);                            
                            cmd.Parameters.AddWithValue("@estimated_cost", Convert.ToDouble(budjetAmnt));
                        }
                        else
                        {
                            string budjetAmnt = txtAmont;
                            cmd.Parameters.AddWithValue("@estimated_cost", Convert.ToDouble(budjetAmnt));
                        }
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("@estimated_cost", DBNull.Value);
                    }
                    cmd.Parameters.AddWithValue("@createUser", _userName);
                    cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                    int exUpdated = cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                }
            }
        }
        public void UpdateTE_Estimate_ProjectCostData(string txtAmont, int upd_PrjID)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;
                        
                        cmd.CommandText = @"UPDATE PROJECTCOST SET estimated_cost=@PC_EstimateAmnt,update_user=@updateUser,update_date=@updateDate where proj_id=@prjID and Stage_ID= 4";
                        
                        if(txtAmont!="")
                            cmd.Parameters.AddWithValue("@PC_EstimateAmnt", Convert.ToDouble(txtAmont));
                        else
                            cmd.Parameters.AddWithValue("@PC_EstimateAmnt", System.DBNull.Value);

                        cmd.Parameters.AddWithValue("@updateUser", _userName);                         
                        cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@prjID", upd_PrjID);
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the Tender Bond Amount records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }



    }
}
