﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace MDI_ParenrForm
{
    public class clsDatabase
    {        
        private string dbPath = null;
        private SqlConnection cConnection = null;         
        public clsDatabase(string databasePath)
        {
           dbPath = databasePath;
        }
        public void ConnectDB()
        {
            if (cConnection != null)
            {
                //Close the connection if already opened 
                if (cConnection.State == System.Data.ConnectionState.Open)
                {
                    cConnection.Close();
                }
            }
            
            cConnection = new SqlConnection();
            cConnection.ConnectionString = dbPath;
            cConnection.Open();
        }
        public void DisconnectDB()
        {
           cConnection.Close();
           cConnection.Dispose();
        }
        public int InsertNewRecord(string insertString)
        {
          SqlCommand insertCommand = new SqlCommand(insertString, cConnection);
           insertCommand.ExecuteNonQuery();
           SqlCommand identityCommand = new SqlCommand("Select @@IDENTITY", cConnection); 
            //insertCommand.Dispose(); 
            //identityCommand.Dispose(); 
            return (int)identityCommand.ExecuteScalar();
        }
        public void ClearmenuInfo()
        {
           SqlCommand delCommand = new SqlCommand("Delete * from Info", cConnection);
           delCommand.ExecuteNonQuery();
           delCommand.Dispose();
        }
        public void ExcuteNonQuery(string sqlString)
        {
           
           SqlCommand sqlCommand = new SqlCommand(sqlString, cConnection);
           sqlCommand.ExecuteNonQuery();
           sqlCommand.Dispose();
           
        }
        public string ExecuteReader(string sqlString)
        {
            string strCatOfTenderEligibility = null;
            StringBuilder strBuild = new StringBuilder();
            SqlCommand sqlCommand = new SqlCommand(sqlString, cConnection);
            SqlDataReader sqlReader = sqlCommand.ExecuteReader();
            if (sqlReader.HasRows == true)
            {
                sqlCommand.Dispose();
                if (sqlReader.Read())
                    strCatOfTenderEligibility = sqlReader["EligibleTenderTypes"].ToString();
                sqlReader.Close();
            }
            cConnection.Close();
            return strCatOfTenderEligibility;
        }
        public int ExecuteNonQuery(string sqlString)
        {
            int exeResult = 0;
            SqlCommand sqlCommand = new SqlCommand(sqlString, cConnection);
            exeResult = sqlCommand.ExecuteNonQuery();
            sqlCommand.Dispose();
            //cConnection.Close();
            return exeResult;
        }

        public int ExecuteNonQuery(string sqlString, SqlConnection sqlConn)
        {
            int exeResult = 0;
            sqlConn.Open();
            SqlCommand sqlCommand = new SqlCommand(sqlString, sqlConn);
            exeResult = sqlCommand.ExecuteNonQuery();
            sqlCommand.Dispose();
            sqlConn.Close();
            return exeResult;
        }

        // Added by Varun on 05 Feb 2014
        public bool ExecuteReader1(string sqlString)
        {
            SqlCommand sqlCommand = new SqlCommand(sqlString, cConnection);
            SqlDataReader sqlReader = sqlCommand.ExecuteReader();
            if (sqlReader.HasRows == true)
            {
                sqlCommand.Dispose();
                sqlReader.Close();
                return true;
            }
            else
            {
                sqlCommand.Dispose();
                sqlReader.Close();
                return false;
            }

        }        

        public bool ExecuteReader(string sqlString, SqlConnection sqlConn)
        {             
            SqlCommand sqlCommand = new SqlCommand(sqlString, sqlConn);
            SqlDataReader sqlReader = sqlCommand.ExecuteReader();
            if (sqlReader.HasRows == true)
            {
                sqlCommand.Dispose();
                sqlReader.Close();
                return true;
            }
            else
            {
                sqlCommand.Dispose();
                sqlReader.Close();
                return false;
            }           
             
        }
        public SqlDataReader ExecuteReader(string sqlString, SqlConnection sqlConn,char ch)
        {          
            SqlCommand sqlCommand = new SqlCommand(sqlString, sqlConn);
            SqlDataReader sqlReader = sqlCommand.ExecuteReader();          
            return sqlReader;
        }

        public SqlDataReader ExecuteReader1(string sqlString,char ch)
        {
            SqlDataReader sqlReader = null;
            SqlCommand sqlCommand = new SqlCommand(sqlString, cConnection);            
            sqlReader = sqlCommand.ExecuteReader();
            return sqlReader;
        }       

        public object ExcuteScalar(string SqlString)
        {
            SqlCommand sqlCommand = new SqlCommand(SqlString, cConnection);
            return sqlCommand.ExecuteScalar();
        }
        public void IncrementStatus()
        {
           SqlCommand sqlCommand = new SqlCommand();
           sqlCommand.CommandText =   "Update State set [State] = [State] + 1";
           sqlCommand.Connection = cConnection;
           sqlCommand.ExecuteScalar();
        }
        public void UpdateTable(SqlDataAdapter dAdapter, DataTable dtTable)  //SqlDataAdapter
        {
            try
            {
               IncrementStatus();
               dAdapter.Update(dtTable);
            }
            catch (Exception)
            {

            }
        }
    }
}
