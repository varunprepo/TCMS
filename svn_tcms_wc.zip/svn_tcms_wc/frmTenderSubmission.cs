﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using TenderTrackingSystem;
using Bytescout.BarCode;
using System.IO;
using Microsoft.Office.Interop.Excel;

namespace MDI_ParenrForm.Projects
{
    public partial class frmTenderSubmission : Form
    {
        protected SqlConnection sqlConn;
        private string strCon = ConfigurationManager.AppSettings["TCMSConnString"].ToString();
        CommonClass comCls = null;
        string mUserName = null;
        string mCommitteeName = null;
        string mSelectedWorkOrderInfo = null;
        int mProjId = 0;
        int mNoOfDaysForClosing = 0;
        
        bool mIsHeadOfSection = false;
        bool mIsWorkOrder = false;
        bool mIsTenderClosingDateStage2 = false;
        DateTime? mTenderClosingDate = null;
        IList<string> mUserRightsColl = null;
        System.Data.DataTable dtFinalTenderersInfo = null;

        public frmTenderSubmission(string committeeName, string tenderNo, string projTitle, int projId, string userName, string tenderClosingDate, IList<string> userRightsColl, string selectedWorkOrderInfo, string workOrderTitle, bool isHeadOfSection, bool isWorkOrder, bool isTenderClosingDateStage2)
        {
            InitializeComponent();
            mUserRightsColl = userRightsColl;
            mIsWorkOrder = isWorkOrder;
            mSelectedWorkOrderInfo = selectedWorkOrderInfo;
            comCls = new CommonClass(userName);
            if (isWorkOrder)
            {
                grpBoxTenderSubmission.Text = "Work Order Tender Submission";
                lblTenderSubmissionHeading1.Text = "Work Order Tender Submission for " + committeeName + " Committee";
                lblWorkOrderNoValue.Text = selectedWorkOrderInfo.Split(',')[0];
                lblWorkOrderTitleValue.Text = workOrderTitle;
                lblClosingDateValue.Text = selectedWorkOrderInfo.Split(',')[1].Split(' ')[0];
                if (lblClosingDateValue.Text != "")
                {
                    mTenderClosingDate = Convert.ToDateTime(lblClosingDateValue.Text);
                    mNoOfDaysForClosing = comCls.DateDiff(lblClosingDateValue.Text);
                }
                if (mNoOfDaysForClosing <= 0)
                {
                    if (mNoOfDaysForClosing == 0)
                    {
                        if (DateTime.Now.TimeOfDay.Hours >= 13)
                            lblTenderStatus.Text = "Work Order is Closed";
                        else
                            lblTenderStatus.Text = "Work Order is Open";
                    }
                    else
                        lblTenderStatus.Text = "Work Order is Closed";
                }
                else
                    lblTenderStatus.Text = "Work Order is Open";
            }
            else
            {
                if (!committeeName.Equals("PQ"))
                {
                    lblTenderSubmissionHeading1.Text = "Tender Voucher Submission  for " + committeeName + " Committee";
                    if (isTenderClosingDateStage2)
                    {
                        lblTenderSubmissionHeading2.Text = "Tender Submission Receipt System (Stage 2)";
                    }
                    else
                    {
                        lblTenderSubmissionHeading2.Text = "Tender Submission Receipt System";
                    }
                }
                else
                {
                    lblTenderSubmissionHeading1.Text = "Voucher Submission  for " + committeeName + " Committee";
                    if (isTenderClosingDateStage2)
                    {
                        lblTenderSubmissionHeading2.Text = "Submission Receipt System (Stage 2)";
                    }
                    else
                    {
                        lblTenderSubmissionHeading2.Text = "Submission Receipt System";
                    }
                }               
            }

            lblTenderNoValue.Text = tenderNo;
            lblProjTitleValue.Text = projTitle;
            if (tenderClosingDate != null)
            {
                lblWorkOrderNo.Text = "";
                lblWorkOrderNoValue.Text = "";
                lblWorkOrderTitle.Text = "";
                lblWorkOrderTitleValue.Text = "";
                mTenderClosingDate = Convert.ToDateTime(tenderClosingDate);
                lblClosingDateValue.Text = mTenderClosingDate.Value.ToString("dd/MMM/yyyy");
                mNoOfDaysForClosing = comCls.DateDiff(lblClosingDateValue.Text);
                if (mNoOfDaysForClosing <= 0)
                {
                    if (mNoOfDaysForClosing == 0)
                    {
                        if (!committeeName.Equals("PQ"))
                        {
                            if (DateTime.Now.TimeOfDay.Hours >= 13 && DateTime.Now.TimeOfDay.Minutes > 30)
                                lblTenderStatus.Text = "Tender Voucher Submission is Closed";
                            else
                                lblTenderStatus.Text = "Tender Voucher Submission is Open";
                        }
                        else
                        {
                            if (DateTime.Now.TimeOfDay.Hours >= 13 && DateTime.Now.TimeOfDay.Minutes > 30)
                                lblTenderStatus.Text = "Voucher Submission is Closed";
                            else
                                lblTenderStatus.Text = "Voucher Submission is Open";
                        }
                    }
                    else
                    {
                        if (!committeeName.Equals("PQ"))
                        {
                            lblTenderStatus.Text = "Tender Voucher Submission is Closed";
                        }
                        else
                        {
                            lblTenderStatus.Text = "Voucher Submission is Closed";
                        }
                    }
                }
                else
                {
                    if (!committeeName.Equals("PQ"))
                    {
                        lblTenderStatus.Text = "Tender Voucher Submission is Open";
                    }
                    else
                    {
                        lblTenderStatus.Text = "Voucher Submission is Open";
                    }
                }
            }

            mUserName = userName;
            mIsHeadOfSection = isHeadOfSection;
            mIsTenderClosingDateStage2 = isTenderClosingDateStage2;
            mProjId = projId;
            mCommitteeName = committeeName;

            dgvTendererInfo.RowTemplate.Height = 35;


            var col1 = new DataGridViewTextBoxColumn();
            col1.HeaderText = "Tenderer Name";
            col1.DataPropertyName = "TendererName";
            col1.Width = 240;
            col1.Resizable = System.Windows.Forms.DataGridViewTriState.True;

            var col13 = new DataGridViewTextBoxColumn();
            var col17 = new DataGridViewTextBoxColumn();

            var col14 = new DataGridViewTextBoxColumn();
            col14.HeaderText = "Delivered By";
            col14.DataPropertyName = "printDeliveredBy";
            col14.Width = 115;

            var col2 = new DataGridViewTextBoxColumn();
            col2.HeaderText = "No Of Envelopes";
            col2.DataPropertyName = "NoOfEnvelopes";
            col2.Width = 66;

            var col7 = new DataGridViewTextBoxColumn();
            col7.HeaderText = "Remarks";
            col7.DataPropertyName = "TenderSubmissionRemarks";
            col7.Width = 120;

            var col3 = new DataGridViewTextBoxColumn();
            col3.HeaderText = "Submission Status";
            col3.DataPropertyName = "Submission";
            col3.ReadOnly = true;
            col3.Width = 100;

            var col4 = new DataGridViewTextBoxColumn();
            col4.HeaderText = "Submitted Time";
            col4.DataPropertyName = "TenderSubmittedTime";
            col4.ReadOnly = true;
            col4.Width = 150;

            var col9 = new DataGridViewTextBoxColumn();
            col9.HeaderText = "Original Receipt Barcode Number (Re-Submission)";
            //col9.DataPropertyName = "TenderSubmissionReturnedSerialNumber";
            col9.Width = 110;

            var col5 = new DataGridViewLinkColumn();
            col5.HeaderText = "Issue Voucher";
            col5.DataPropertyName = "PrintVoucher";
            col5.Width = 110;
            col5.ReadOnly = true;
            col5.LinkBehavior = LinkBehavior.AlwaysUnderline;
           
            var col6 = new DataGridViewLinkColumn();
            col6.HeaderText = "Reset Submission Data";
            col6.DataPropertyName = "ResetSubmissionData";
            col6.Width = 110;
            col6.ReadOnly = true;
            col6.LinkBehavior = LinkBehavior.AlwaysUnderline;            

            //var col8 = new DataGridViewTextBoxColumn();
            //col8.HeaderText = "Bidder No.";
            //col8.DataPropertyName = "TenderSubmissionNo";

            var col10 = new DataGridViewTextBoxColumn();
            col10.HeaderText = "VersionNo";
            col10.DataPropertyName = "VersionNo";

            var col11 = new DataGridViewTextBoxColumn();
            var col12 = new DataGridViewTextBoxColumn();
            var col15 = new DataGridViewTextBoxColumn();
            if (!isWorkOrder)
            {
                col11.HeaderText = "DateId";
                col11.DataPropertyName = "Date_Id";

                col12.HeaderText = "EmpId";
                col12.DataPropertyName = "employee_id";

                col15.HeaderText = "CoId";
                col15.DataPropertyName = "co_id";
            }
            else
            {

                col13.HeaderText = "bidder_id";
                col13.DataPropertyName = "bidder_id";

                col17.HeaderText = "workOrderSubmissionID";
                col17.DataPropertyName = "workOrderSubmissionID";
            }


            if (!isWorkOrder)
            {
                if (mUserRightsColl.Count() == 0 || mIsHeadOfSection)
                {
                    dgvTendererInfo.Columns.AddRange(new DataGridViewColumn[] { col1, col14, col2, col7, col3, col4, col9, col5, col6, col10, col11, col12, col15 });
                }
                else
                {
                    dgvTendererInfo.Columns.AddRange(new DataGridViewColumn[] { col1, col14, col2, col7, col3, col4, col9, col5, col10, col11, col12, col15 });
                }
            }
            else
            {
                if (mUserRightsColl.Count() == 0 || mIsHeadOfSection)
                {
                    dgvTendererInfo.Columns.AddRange(new DataGridViewColumn[] { col1, col14, col2, col7, col3, col4, col9, col5, col6, col10, col13, col17 });
                }
                else
                {
                    dgvTendererInfo.Columns.AddRange(new DataGridViewColumn[] { col1, col14, col2, col7, col3, col4, col9, col5, col10, col13, col17 });
                }
            }

            dgvTendererInfo.AutoGenerateColumns = false;
            dgvTendererInfo.AllowUserToAddRows = false;
            dgvTendererInfo.AutoResizeColumns();
            dgvTendererInfo.AutoResizeRows();
            //dgvTendererInfo.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font(dgvTendererInfo.Font, FontStyle.Regular);             
            dgvTendererInfo.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dgvTendererInfo.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;

            dgvTendererInfo.EditingControlShowing += new DataGridViewEditingControlShowingEventHandler(dgvTenderNames_EditingNoOfEnvelopeColumn);
            dgvTendererInfo.EditingControlShowing += new DataGridViewEditingControlShowingEventHandler(dgvTenderNames_EditingRemarksColumn);
            //dgvTendererInfo.EditingControlShowing += new DataGridViewEditingControlShowingEventHandler(dgvTenderNames_EditingSubmissionReturnColumn);
            dgvTendererInfo.EditingControlShowing += new DataGridViewEditingControlShowingEventHandler(dgvTenderNames_EditingDeliveredByColumn);
            comCls.Populate(ref dgvTendererInfo, mUserRightsColl, strCon, mProjId, mSelectedWorkOrderInfo, mIsWorkOrder, mIsHeadOfSection, mNoOfDaysForClosing, isTenderClosingDateStage2);             
             
        }      

        static System.Windows.Forms.TextBox txtNoOfEnvelopes = null;
        void dgvTenderNames_EditingNoOfEnvelopeColumn(object sender, DataGridViewEditingControlShowingEventArgs e)
        {

            if (this.dgvTendererInfo.CurrentCell.ColumnIndex == 2)
            //the column you want to add event for, I take the first column for example
            {
                txtNoOfEnvelopes = e.Control as System.Windows.Forms.TextBox;
                if (txtNoOfEnvelopes != null)
                {
                    txtNoOfEnvelopes.KeyPress -= new KeyPressEventHandler(txtNoOfEnvelopes_KeyPress);
                    txtNoOfEnvelopes.KeyPress += new KeyPressEventHandler(txtNoOfEnvelopes_KeyPress);
                }
                clsDatabase clsObj = new clsDatabase(mUserName);
                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                SqlDataReader sqlDtReader = null;
                if (!mIsWorkOrder)
                {
                    if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                    {
                        if (dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[9].Value != DBNull.Value)
                            sqlDtReader = clsObj.ExecuteReader("select PrintStatus from TenderDatesInfo where date_id =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[9].Value, sqlConn, 'Y');
                    }
                    else
                    {
                        if (dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value != DBNull.Value)
                            sqlDtReader = clsObj.ExecuteReader("select PrintStatus from TenderDatesInfo where date_id =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value, sqlConn, 'Y');
                    }
                }
                else
                {
                    if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                    {
                        if (dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value.ToString() != "")
                            sqlDtReader = clsObj.ExecuteReader("select PrintStatus from WorkOrderSubmissions where workOrderSubmissionID =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value, sqlConn, 'Y');
                    }
                    else
                    {
                        if (dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[11].Value.ToString() != "")
                            sqlDtReader = clsObj.ExecuteReader("select PrintStatus from WorkOrderSubmissions where workOrderSubmissionID =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[11].Value, sqlConn, 'Y');
                    }
                }
                if (sqlDtReader != null)
                {
                    if (sqlDtReader.Read())
                    {
                        if (sqlDtReader["PrintStatus"] != DBNull.Value)
                        {
                            sqlDtReader.Close();
                            txtNoOfEnvelopes = e.Control as System.Windows.Forms.TextBox;
                            if (txtNoOfEnvelopes != null)
                            {
                                txtNoOfEnvelopes.Leave -= new EventHandler(txtNoOfEnvelopes_LeaveOrEnter);
                                txtNoOfEnvelopes.Leave += new EventHandler(txtNoOfEnvelopes_LeaveOrEnter);
                            }
                        }
                    }
                    sqlDtReader.Close();
                }
                sqlConn.Close();
            }
        }

        static System.Windows.Forms.TextBox txtRemarks = null;
        void dgvTenderNames_EditingRemarksColumn(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            if (this.dgvTendererInfo.CurrentCell.ColumnIndex == 3)
            {
                clsDatabase clsObj = new clsDatabase(mUserName);
                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                SqlDataReader sqlDtReader = null;
                if (!mIsWorkOrder)
                {
                    if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                    {
                        if (dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[9].Value != DBNull.Value)
                            sqlDtReader = clsObj.ExecuteReader("select PrintStatus from TenderDatesInfo where date_id =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[9].Value, sqlConn, 'Y');
                    }
                    else
                    {
                        if (dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value != DBNull.Value)
                            sqlDtReader = clsObj.ExecuteReader("select PrintStatus from TenderDatesInfo where date_id =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value, sqlConn, 'Y');
                    }
                }
                else
                {
                    if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                    {
                        if (dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value.ToString() != "")
                            sqlDtReader = clsObj.ExecuteReader("select PrintStatus from WorkOrderSubmissions where workOrderSubmissionID =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value, sqlConn, 'Y');
                    }
                    else
                    {
                        if (dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[11].Value.ToString() != "")
                            sqlDtReader = clsObj.ExecuteReader("select PrintStatus from WorkOrderSubmissions where workOrderSubmissionID =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[11].Value, sqlConn, 'Y');
                    }
                }
                if (sqlDtReader != null)
                {
                    if (sqlDtReader.Read())
                    {
                        if (sqlDtReader["PrintStatus"] != DBNull.Value)
                        {
                            sqlDtReader.Close();
                            txtRemarks = e.Control as System.Windows.Forms.TextBox;
                            if (txtRemarks != null)
                            {
                                txtRemarks.Leave -= new EventHandler(txtRemarks_LeaveOrEnter);
                                txtRemarks.Leave += new EventHandler(txtRemarks_LeaveOrEnter);
                            }
                        }
                    }
                    sqlDtReader.Close();
                }
                sqlConn.Close();
            }
        }

        //void dgvTenderNames_EditingSubmissionReturnColumn(object sender, DataGridViewEditingControlShowingEventArgs e)
        //{
        //    if (this.dgvTendererInfo.CurrentCell.ColumnIndex == 6)
        //    {
        //        txtSubmissionReturnReceiptNo = e.Control as System.Windows.Forms.TextBox;
        //        if (txtSubmissionReturnReceiptNo != null)
        //        {
        //            txtSubmissionReturnReceiptNo.Leave -= new EventHandler(txtSubmissionReturn_LeaveOrEnter);
        //            txtSubmissionReturnReceiptNo.Leave += new EventHandler(txtSubmissionReturn_LeaveOrEnter);
        //        }
        //    }
        //}

        static System.Windows.Forms.TextBox txtDeliveredBy = null;
        void dgvTenderNames_EditingDeliveredByColumn(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            if (this.dgvTendererInfo.CurrentCell.ColumnIndex == 1)
            {
                clsDatabase clsObj = new clsDatabase(mUserName);
                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                SqlDataReader sqlDtReader = null;
                if (!mIsWorkOrder)
                {
                    if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                    {
                        if (dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[9].Value != DBNull.Value)
                            sqlDtReader = clsObj.ExecuteReader("select PrintStatus from TenderDatesInfo where date_id =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[9].Value, sqlConn, 'Y');
                    }
                    else
                    {
                        if (dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value != DBNull.Value)
                            sqlDtReader = clsObj.ExecuteReader("select PrintStatus from TenderDatesInfo where date_id =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value, sqlConn, 'Y');
                    }   
                    
                }
                else
                {
                    if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                    {
                        if (dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value.ToString() != "")
                            sqlDtReader = clsObj.ExecuteReader("select PrintStatus from WorkOrderSubmissions where workOrderSubmissionID =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value, sqlConn, 'Y');
                    }
                    else
                    {
                        if (dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[11].Value.ToString() != "")
                            sqlDtReader = clsObj.ExecuteReader("select PrintStatus from WorkOrderSubmissions where workOrderSubmissionID =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[11].Value, sqlConn, 'Y');
                    }   
                    
                }
                if (sqlDtReader != null)
                {
                    if (sqlDtReader.Read())
                    {
                        if (sqlDtReader["PrintStatus"] != DBNull.Value)
                        {
                            sqlDtReader.Close();
                            txtDeliveredBy = e.Control as System.Windows.Forms.TextBox;
                            if (txtDeliveredBy != null)
                            {
                                txtDeliveredBy.Leave -= new EventHandler(txtDeliveredBy_LeaveOrEnter);
                                txtDeliveredBy.Leave += new EventHandler(txtDeliveredBy_LeaveOrEnter);
                            }
                        }
                    }
                    sqlDtReader.Close();
                }
                sqlConn.Close();
            }
        }

        //void txtSubmissionReturn_LeaveOrEnter(object sender, EventArgs e)
        //{
        //    if (restrictedPriv == 1 || (mUserRightsColl.Count != 0 && _isHeadOfSection == false))
        //    {
        //        MessageBox.Show("You have no privilege to edit the submission return value. Please Contact system administrator.");
        //        txtSubmissionReturnReceiptNo.Leave -= new EventHandler(txtSubmissionReturn_LeaveOrEnter);
        //        return;
        //    }            

        //    if (this.dgvTendererInfo.CurrentCell.ColumnIndex == 6)
        //    {
        //        try
        //        {
        //            if (txtSubmissionReturnReceiptNo != null)
        //            {                         

        //                dgvTendererInfo.BeginInvoke(new DelegateUpdateDataGridView(Populate));                         
        //            }
        //            else
        //            {
        //                MessageBox.Show("Error occurred while Updating the records", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //            }
        //        }
        //        catch (Exception ex)
        //        {
        //            MessageBox.Show("Error occurred while Updating the records", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //        }
        //    }
        //    txtSubmissionReturnReceiptNo.Leave -= new EventHandler(txtSubmissionReturn_LeaveOrEnter);
        //}


        void txtRemarks_LeaveOrEnter(object sender, EventArgs e)
        {
            //if (restrictedPriv == 1)
            //{
            //    MessageBox.Show("You have no privilege to edit the Remarks Column. Please Contact system administrator.");
            //    return;
            //}

            if (this.dgvTendererInfo.CurrentCell.ColumnIndex == 3)
            {
                try
                {
                    if (!mIsWorkOrder)
                    {
                        if (txtRemarks.Text != "")
                        {
                            using (SqlConnection sqlConn = new SqlConnection(strCon))
                            {
                                clsDatabase clsObj = new clsDatabase(mUserName);
                                if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                                {
                                    clsObj.ExecuteNonQuery("update TenderDatesInfo set TenderSubmissionRemarks='" + txtRemarks.Text + "' where date_id =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[9].Value, sqlConn);
                                }
                                else
                                {
                                    clsObj.ExecuteNonQuery("update TenderDatesInfo set TenderSubmissionRemarks='" + txtRemarks.Text + "' where date_id =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value, sqlConn);
                                }
                            }
                            txtRemarks.Leave -= new EventHandler(txtRemarks_LeaveOrEnter);
                        }
                        else
                        {
                            using (SqlConnection sqlConn = new SqlConnection(strCon))
                            {
                                clsDatabase clsObj = new clsDatabase(mUserName);
                                int executeResult = 0;
                                if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                                {
                                    executeResult = clsObj.ExecuteNonQuery("update TenderDatesInfo set TenderSubmissionRemarks=null where date_id =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[9].Value, sqlConn);
                                }
                                else
                                {
                                    executeResult = clsObj.ExecuteNonQuery("update TenderDatesInfo set TenderSubmissionRemarks=null where date_id =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value, sqlConn);
                                }
                            }
                            txtRemarks.Leave -= new EventHandler(txtRemarks_LeaveOrEnter);
                        }
                    }
                    else
                    {
                        if (txtRemarks.Text != "")
                        {
                            using (SqlConnection sqlConn = new SqlConnection(strCon))
                            {
                                clsDatabase clsObj = new clsDatabase(mUserName);
                                if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                                {
                                    clsObj.ExecuteNonQuery("update WorkOrderSubmissions set TenderSubmissionRemarks='" + txtRemarks.Text + "' where workOrderSubmissionID =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value, sqlConn);
                                }
                                else
                                {
                                    clsObj.ExecuteNonQuery("update WorkOrderSubmissions set TenderSubmissionRemarks='" + txtRemarks.Text + "' where workOrderSubmissionID =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[11].Value, sqlConn);
                                }
                            }
                            txtRemarks.Leave -= new EventHandler(txtRemarks_LeaveOrEnter);
                        }
                        else
                        {
                            using (SqlConnection sqlConn = new SqlConnection(strCon))
                            {
                                clsDatabase clsObj = new clsDatabase(mUserName);                                 
                                if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                                {
                                    clsObj.ExecuteNonQuery("update WorkOrderSubmissions set TenderSubmissionRemarks=null where workOrderSubmissionID =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value, sqlConn);
                                }
                                else
                                {
                                    clsObj.ExecuteNonQuery("update WorkOrderSubmissions set TenderSubmissionRemarks=null where workOrderSubmissionID =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[11].Value, sqlConn);
                                }                                 
                            }
                            txtRemarks.Leave -= new EventHandler(txtRemarks_LeaveOrEnter);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while Updating the records", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        delegate void DelegateUpdateDataGridView();

        void txtNoOfEnvelopes_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (this.dgvTendererInfo.CurrentCell.ColumnIndex == 2)
            {
                ValidateNumericAndDecimalInput(sender, e);
            }
        }

        private bool nonNumberEntered = false;

        //Added by Varun on 12th Aug 2015 Validation process for checking the numerics and decimals in the textboxes where only these inputs are expected 
        private void ValidateNumericAndDecimalInput(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != 8 && e.KeyChar != 13) //&& e.KeyChar.ToString().Contains('.').ToString().Length>=2
            {
                nonNumberEntered = true;
            }
            if (e.KeyChar == '.' && (sender as System.Windows.Forms.TextBox).Text.IndexOf('.') > -1)
            {
                nonNumberEntered = true;
                e.Handled = true;
            }

            if (nonNumberEntered == true)
            {
                MessageBox.Show("Please enter number only...");
                e.Handled = true;
            }

            nonNumberEntered = false;
        }

        void txtNoOfEnvelopes_LeaveOrEnter(object sender, EventArgs e)
        {
            //if (restrictedPriv == 1)
            //{
            //    MessageBox.Show("You have no privilege to edit the Envelops Column. Please Contact system administrator.");
            //    return;
            //}
            if (this.dgvTendererInfo.CurrentCell.ColumnIndex == 2)
            {
                try
                {

                    if (txtNoOfEnvelopes.Text != "")
                    {
                        //int noOfEnvelops = 0;
                        //noOfEnvelops = Convert.ToInt32(txtNoOfEnvelopes.Text);
                        //if (!(noOfEnvelops >= 1 && noOfEnvelops <= 5))
                        //{
                        //    MessageBox.Show("Please enter only integer values between (1 to 5) in Number Of Envelopes column", "Alert Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //    txtNoOfEnvelopes.Focus();
                        //    return;
                        //}
                        //if (noOfEnvelops >= 1 && noOfEnvelops <= 5)
                        //{                            
                        using (SqlConnection sqlConn = new SqlConnection(strCon))
                        {
                            clsDatabase clsObj = new clsDatabase(mUserName);
                            if (!mIsWorkOrder)
                            {
                                if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                                {
                                    if (dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[9].Value != DBNull.Value)
                                    clsObj.ExecuteNonQuery("update TenderDatesInfo set NoOfEnvelopes='" + txtNoOfEnvelopes.Text + "' where date_id =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[9].Value, sqlConn);
                                }
                                else
                                {
                                    if (dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value != DBNull.Value)
                                    clsObj.ExecuteNonQuery("update TenderDatesInfo set NoOfEnvelopes='" + txtNoOfEnvelopes.Text + "' where date_id =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value, sqlConn);
                                }                                
                            }
                            else
                            {
                                if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                                {
                                    if (dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value.ToString() != "")
                                        clsObj.ExecuteNonQuery("update WorkOrderSubmissions set NoOfEnvelopes='" + txtNoOfEnvelopes.Text + "' where workOrderSubmissionID =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value, sqlConn);
                                }
                                else
                                {
                                    if (dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[11].Value.ToString() != "")
                                        clsObj.ExecuteNonQuery("update WorkOrderSubmissions set NoOfEnvelopes='" + txtNoOfEnvelopes.Text + "' where workOrderSubmissionID =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[11].Value, sqlConn);
                                }                            
                            }
                        }
                        txtNoOfEnvelopes.Leave -= new EventHandler(txtNoOfEnvelopes_LeaveOrEnter);
                        //}
                    }
                    else
                    {
                        using (SqlConnection sqlConn = new SqlConnection(strCon))
                        {
                            clsDatabase clsObj = new clsDatabase(mUserName);
                            if (!mIsWorkOrder)
                            {
                                if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                                {
                                    if (dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[9].Value != DBNull.Value)
                                        clsObj.ExecuteNonQuery("update TenderDatesInfo set NoOfEnvelopes=NULL where date_id =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[9].Value, sqlConn);
                                }
                                else
                                {
                                    if (dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value != DBNull.Value)
                                        clsObj.ExecuteNonQuery("update TenderDatesInfo set NoOfEnvelopes=NULL where date_id =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value, sqlConn);
                                }   
                                
                            }
                            else
                            {
                                if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                                {
                                    if (dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value.ToString() != "")
                                        clsObj.ExecuteNonQuery("update WorkOrderSubmissions set NoOfEnvelopes=NULL where workOrderSubmissionID =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value, sqlConn);
                                }
                                else
                                {
                                    if (dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[11].Value.ToString() != "")
                                        clsObj.ExecuteNonQuery("update WorkOrderSubmissions set NoOfEnvelopes=NULL where workOrderSubmissionID =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[11].Value, sqlConn);
                                } 
                                
                            }
                        }
                        txtNoOfEnvelopes.Leave -= new EventHandler(txtNoOfEnvelopes_LeaveOrEnter);
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while Updating the records", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        void txtDeliveredBy_LeaveOrEnter(object sender, EventArgs e)
        {
            //if (restrictedPriv == 1)
            //{
            //    MessageBox.Show("You have no privilege to edit the DeliveredBy Column. Please Contact system administrator.");
            //    return;
            //}
            if (this.dgvTendererInfo.CurrentCell.ColumnIndex == 1)
            {
                try
                {
                    if (txtDeliveredBy.Text != "")
                    {
                        using (SqlConnection sqlConn = new SqlConnection(strCon))
                        {
                            clsDatabase clsObj = new clsDatabase(mUserName);
                            if (!mIsWorkOrder)
                            {
                                if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                                {
                                    if (dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[9].Value != DBNull.Value)
                                        clsObj.ExecuteNonQuery("update TenderDatesInfo set printDeliveredBy='" + txtDeliveredBy.Text + "' where date_id =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[9].Value, sqlConn);
                                }
                                else
                                {
                                    if (dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value != DBNull.Value)
                                        clsObj.ExecuteNonQuery("update TenderDatesInfo set printDeliveredBy='" + txtDeliveredBy.Text + "' where date_id =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value, sqlConn);
                                }   
                                
                            }
                            else
                            {
                                if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                                {
                                    if (dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value.ToString() != "")
                                        clsObj.ExecuteNonQuery("update WorkOrderSubmissions set printDeliveredBy='" + txtDeliveredBy.Text + "' where workOrderSubmissionID =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value, sqlConn);
                                }
                                else
                                {
                                    if (dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[11].Value.ToString() != "")
                                        clsObj.ExecuteNonQuery("update WorkOrderSubmissions set printDeliveredBy='" + txtDeliveredBy.Text + "' where workOrderSubmissionID =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[11].Value, sqlConn);
                                }                                   
                            }
                        }
                        txtDeliveredBy.Leave -= new EventHandler(txtDeliveredBy_LeaveOrEnter);
                    }
                    else
                    {
                        using (SqlConnection sqlConn = new SqlConnection(strCon))
                        {
                            clsDatabase clsObj = new clsDatabase(mUserName);
                            if (!mIsWorkOrder)
                            {
                                if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                                {
                                    if (dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[9].Value != DBNull.Value)
                                        clsObj.ExecuteNonQuery("update TenderDatesInfo set printDeliveredBy=null where date_id =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[9].Value, sqlConn);
                                }
                                else
                                {
                                    if (dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value != DBNull.Value)
                                        clsObj.ExecuteNonQuery("update TenderDatesInfo set printDeliveredBy=null where date_id =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value, sqlConn);
                                }   
                                
                            }
                            else
                            {
                                if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                                {
                                    if (dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value.ToString() != "")
                                        clsObj.ExecuteNonQuery("update WorkOrderSubmissions set printDeliveredBy=null where workOrderSubmissionID =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value, sqlConn);
                                }
                                else
                                {
                                    if (dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[11].Value.ToString() != "")
                                        clsObj.ExecuteNonQuery("update WorkOrderSubmissions set printDeliveredBy=null where workOrderSubmissionID =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[11].Value, sqlConn);
                                }   
                                
                            }
                        }
                        txtDeliveredBy.Leave -= new EventHandler(txtDeliveredBy_LeaveOrEnter);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while Updating the records", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }


        private void dgvTendererInfo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 7)
            {

                if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                {
                    if (!mIsWorkOrder)
                    {
                        if (mUserRightsColl.Contains("68"))
                        {
                            MessageBox.Show("You do not have permission to issue the voucher, Please contact the Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }
                    }
                    else
                    {
                        if (mUserRightsColl.Contains("74"))
                        {
                            MessageBox.Show("You do not have permission to Issue the Vouchers of Work Orders, Please contact the Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }
                    }
                    if (mNoOfDaysForClosing == 0)
                    {
                        if (DateTime.Now.TimeOfDay.Hours >= 13 && DateTime.Now.TimeOfDay.Minutes > 30)
                        {
                            MessageBox.Show("Issue Voucher time has exceeded 1:30 PM for the day, Please contact the Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }
                    }
                }

                if (mNoOfDaysForClosing < 0)
                {
                    MessageBox.Show("You can not Issue Voucher after Tender Submission closing Date expired", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                string[] companyInfo = null;
                if (!mIsWorkOrder)
                    companyInfo = new string[12];
                else
                    companyInfo = new string[14];

                string bidderId = null;
                string workOrderId = null;
                string noOfEnvelopes = null;
                string deliveredBy = null;
                string isPrinted = null;
                string nonWoRemarks = null;
                string woRemarks = null;
                string woNo = null;
                string woTitle = null;
                string workOrderSubID = null;
                noOfEnvelopes = dgvTendererInfo.Rows[e.RowIndex].Cells[2].Value.ToString();
                if (!mIsWorkOrder)
                {
                    nonWoRemarks = dgvTendererInfo.Rows[e.RowIndex].Cells[3].Value.ToString();
                    if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                    {
                        bidderId = dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[9].Value.ToString();
                    }
                    else
                    {
                        bidderId = dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value.ToString();
                    }
                }
                companyInfo[2] = noOfEnvelopes;       // # of Envelopes 
                deliveredBy = dgvTendererInfo.Rows[e.RowIndex].Cells[1].Value.ToString();

                if (deliveredBy == "")
                {
                    MessageBox.Show("Please enter Delivered By Name");
                    return;
                }

                if (noOfEnvelopes == "")
                {
                    MessageBox.Show("Please enter Number of Envelopes");
                    return;
                }

                isPrinted = dgvTendererInfo.Rows[e.RowIndex].Cells[4].Value.ToString();
                if (mIsWorkOrder)
                {
                    woRemarks = dgvTendererInfo.Rows[e.RowIndex].Cells[3].Value.ToString();
                    
                    //if (dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value != DBNull.Value)
                    if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                    {
                        bidderId = dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[9].Value.ToString();
                        workOrderSubID = dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value.ToString();
                    }
                    else
                    {
                        bidderId = dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value.ToString();
                        workOrderSubID = dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[11].Value.ToString();
                    }
                    workOrderId = mSelectedWorkOrderInfo.Split(',')[2];
                    woNo = lblWorkOrderNoValue.Text;       // WO Number
                    woTitle = lblWorkOrderTitleValue.Text;     // WO Title
                    companyInfo[10] = woNo;
                    companyInfo[11] = woTitle;
                }

                clsDatabase clsObj = null;
                clsObj = new clsDatabase(strCon);
                clsObj.ConnectDB();

                comCls = new CommonClass(mUserName);
                companyInfo[0] = mProjId.ToString();
                char[] delimiters = new char[] { '\r', '\n' };
                companyInfo[1] = dgvTendererInfo.Rows[e.RowIndex].Cells[0].Value.ToString().Split(delimiters)[0];       // Company Name                
                if (!mIsWorkOrder)
                {
                    companyInfo[3] = bidderId.ToString();        // DateID
                    if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                    {
                        companyInfo[10] = dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value.ToString();
                        companyInfo[11] = dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[11].Value.ToString();
                    }
                    else
                    {
                        companyInfo[10] = dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[11].Value.ToString();
                        companyInfo[11] = dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[12].Value.ToString();
                    }                    
                }
                else
                {
                    companyInfo[3] = workOrderId.ToString();        // workOrderId
                    companyInfo[12] = bidderId;        // bidderId
                    companyInfo[13] = workOrderSubID;
                }

                if (isPrinted != "")
                {
                    if (!mIsWorkOrder)
                    {
                        if (dgvTendererInfo.Rows[e.RowIndex].Cells[6].Value == null)
                        {
                            if (mNoOfDaysForClosing <= 0)
                            {
                                if (DateTime.Now.TimeOfDay.Hours >= 13 && DateTime.Now.TimeOfDay.Minutes > 30)
                                {
                                    MessageBox.Show("Tender Submission Voucher cannot be Issued after 1:30 PM", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    return;
                                }
                                else
                                {
                                    MessageBox.Show("Please enter the Barcode Serial Number of the Original Receipt Voucher if this is Re-Submission", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    return;
                                }
                            }
                            else
                            {
                                MessageBox.Show("Please enter the Barcode Serial Number of the Original Receipt Voucher if this is Re-Submission", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                return;
                            }

                        }
                        else
                        {
                            if (!clsObj.ExecuteReader1("select date_id from TenderDatesInfo where TenderSubmissionReturnedSerialNumber='" + dgvTendererInfo.Rows[e.RowIndex].Cells[6].Value.ToString().Trim() + "'" +
                                " and date_id=" + bidderId))
                            {
                                MessageBox.Show("Barcode Serial Number does not match with the original Receipt Voucher, Can not Issue the Voucher", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                return;
                            }
                            else
                                dgvTendererInfo.Rows[e.RowIndex].Cells[6].Value = "";
                        }
                    }
                    else
                    {
                        if (dgvTendererInfo.Rows[e.RowIndex].Cells[6].Value == null)
                        {
                            if (mNoOfDaysForClosing <= 0)
                            {
                                if (DateTime.Now.TimeOfDay.Hours >= 13 && DateTime.Now.TimeOfDay.Minutes > 30)
                                {
                                    MessageBox.Show("Work order Voucher cannot be Issued after 1:30 PM", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    return;
                                }
                                else
                                {
                                    MessageBox.Show("Please enter the Barcode Serial Number of the Original Receipt Voucher if this is Re-Submission", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    return;
                                }
                            }
                            else
                            {
                                MessageBox.Show("Please enter the Barcode Serial Number of the Original Receipt Voucher if this is Re-Submission", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                return;
                            }


                        }
                        else
                        {
                            if (!clsObj.ExecuteReader1("select workOrderID from WorkOrderSubmissions where tenderSubmissionSerialNumber='" + dgvTendererInfo.Rows[e.RowIndex].Cells[6].Value.ToString().Trim() + "'" +
                                    " and workOrderSubmissionID=" + workOrderSubID))
                            {
                                MessageBox.Show("Barcode Serial Number does not match with the original Receipt Voucher, Can not Issue the Voucher", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                return;
                            }
                            else
                                dgvTendererInfo.Rows[e.RowIndex].Cells[6].Value = "";
                        }
                    }
                }

                int versionNo = 0;

               
                if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                {
                    if (dgvTendererInfo.Rows[e.RowIndex].Cells[8].Value.ToString() == "") //VersionNo
                    {
                        versionNo = 1;
                    }
                    else
                    {
                        versionNo = Convert.ToInt16(dgvTendererInfo.Rows[e.RowIndex].Cells[8].Value);
                        versionNo = (++versionNo);
                    }
                }
                else
                {
                    if (dgvTendererInfo.Rows[e.RowIndex].Cells[9].Value.ToString() == "") //VersionNo
                    {
                        versionNo = 1;
                    }
                    else
                    {
                        versionNo = Convert.ToInt16(dgvTendererInfo.Rows[e.RowIndex].Cells[9].Value);
                        versionNo = (++versionNo);
                    }
                }      

                companyInfo[5] = "Issue Voucher";
                companyInfo[8] = mCommitteeName;
                companyInfo[9] = deliveredBy;

                companyInfo[4] = "OC";
                frmIssueVoucherConfirmationDialogBox frmObj = new
                frmIssueVoucherConfirmationDialogBox(strCon, lblTenderNoValue.Text, mCommitteeName, lblProjTitleValue.Text,Convert.ToInt32(noOfEnvelopes), companyInfo, versionNo.ToString(), mIsWorkOrder,
                isPrinted, ref clsObj, workOrderSubID, nonWoRemarks, woRemarks, bidderId, deliveredBy, workOrderId, ref dgvTendererInfo, mUserRightsColl, mProjId, mSelectedWorkOrderInfo, mIsHeadOfSection, mUserName, mNoOfDaysForClosing, mIsTenderClosingDateStage2);
                frmObj.StartPosition = FormStartPosition.CenterParent;
                frmObj.ShowDialog();                
                //dgvTendererInfo.BeginInvoke(new DelegateUpdateDataGridView(Populate));
            }
            else if (e.ColumnIndex == 8)
            {               
                if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                {

                    MessageBox.Show("You do not have permission to reset the voucher submission data, Please contact the Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                else
                {
                    clsDatabase clsObj = null;
                    clsObj = new clsDatabase(strCon);
                    clsObj.ConnectDB();
                    int updateResult = 0;
                    if (!mIsWorkOrder)
                    {
                        if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                        {
                            updateResult = clsObj.ExecuteNonQuery("UPDATE TenderDatesInfo set TenderSubmittedTime = Null,printDeliveredBy = Null, VersionNo=Null, PrintStatus=Null,NoOfEnvelopes=Null,TenderSubmissionRemarks=Null, " +
                            "TenderSubmissionReturnedSerialNumber = NULL WHERE date_id =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[9].Value.ToString());                             
                        }
                        else
                        {
                            updateResult = clsObj.ExecuteNonQuery("UPDATE TenderDatesInfo set TenderSubmittedTime = Null,printDeliveredBy = Null, VersionNo=Null, PrintStatus=Null,NoOfEnvelopes=Null,TenderSubmissionRemarks=Null, " +
                            "TenderSubmissionReturnedSerialNumber = NULL WHERE date_id =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value.ToString());                             
                        }
                        
                        if (updateResult == 1)
                        {
                            MessageBox.Show("Data updated successfully", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    else
                    {
                        if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                        {
                            updateResult = clsObj.ExecuteNonQuery("UPDATE WorkOrderSubmissions SET versionNo = NULL, tenderSubmissionSerialNumber = NULL, printDeliveredBy = NULL, tenderSubmittedTime = NULL, tenderSubmissionRemarks = NULL, " +
                            "printStatus = NULL, noOfEnvelopes = NULL WHERE workOrderSubmissionID =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[10].Value.ToString());
                        }
                        else
                        {
                            updateResult = clsObj.ExecuteNonQuery("UPDATE WorkOrderSubmissions SET versionNo = NULL, tenderSubmissionSerialNumber = NULL, printDeliveredBy = NULL, tenderSubmittedTime = NULL, tenderSubmissionRemarks = NULL, " +
                            "printStatus = NULL, noOfEnvelopes = NULL WHERE workOrderSubmissionID =" + dgvTendererInfo.Rows[dgvTendererInfo.CurrentCell.RowIndex].Cells[11].Value.ToString());
                        }
                        if (updateResult == 1)
                        {
                            MessageBox.Show("Data updated successfully", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    comCls.Populate(ref dgvTendererInfo, mUserRightsColl, strCon, mProjId, mSelectedWorkOrderInfo, mIsWorkOrder, mIsHeadOfSection, mNoOfDaysForClosing, mIsTenderClosingDateStage2);                                   
                }
                
            }
        }

        private void btnExcel_Click(object sender, EventArgs e)
        {
            try
            {
                dtFinalTenderersInfo = (System.Data.DataTable)dgvTendererInfo.DataSource;
                if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
                {
                    if (mIsWorkOrder)
                    {
                        if (mUserRightsColl.Contains("79"))
                        {
                            MessageBox.Show("You do not have permission to Export To Excel In Work Orders, Please contact the Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }
                    }
                    else
                    {
                        if (mUserRightsColl.Contains("81"))
                        {
                            MessageBox.Show("You do not have permission to Export To Excel In Tender Submission, Please contact the Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }
                    }
                }

                SaveFileDialog saveFileDialog1 = new SaveFileDialog();
                Microsoft.Office.Interop.Excel._Application app = null;
                Microsoft.Office.Interop.Excel._Workbook workbook = null;
                //if(!mIsWorkOrder)
                //{
                // commented by Varun on 08/Jun/15 saveFileDialog1.Filter = "Excel Path|*.xls|Excel Format|*.xlsx";

                saveFileDialog1.Filter = "Excel Path|*.xls|Excel Path|*.xlsx";
                saveFileDialog1.Title = "Save an Excel File";
                saveFileDialog1.ShowDialog();

                if (saveFileDialog1.FileName != "")
                {
                    // creating Excel Application
                    app = new Microsoft.Office.Interop.Excel.Application();

                    // creating new WorkBook within Excel application
                    workbook = app.Workbooks.Add(Type.Missing);

                    // creating new Excelsheet in workbook
                    Microsoft.Office.Interop.Excel._Worksheet worksheet = null;

                    // see the excel sheet behind the program
                    app.Visible = true;

                    // get the reference of first sheet. By default its name is Sheet1.
                    // store its reference to worksheet
                    worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Sheets["Sheet1"];
                    worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.ActiveSheet;

                    Microsoft.Office.Interop.Excel.Range formatRange = worksheet.UsedRange;
                    Microsoft.Office.Interop.Excel.Range formatA1CellRange = null;
                    Microsoft.Office.Interop.Excel.Range formatA1Cell = null;
                    Microsoft.Office.Interop.Excel.Range formatOtherCell = null;

                    formatA1CellRange = worksheet.get_Range("A1", "G1");
                    formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[1, 7];
                    formatA1CellRange.ColumnWidth = 150;
                    formatA1CellRange.Merge(true);
                    if (!mIsWorkOrder)
                        formatA1CellRange.FormulaR1C1 = "TENDER SUBMISSION REPORT FOR " + lblTenderNoValue.Text;
                    else
                        formatA1CellRange.FormulaR1C1 = "WORK ORDER TENDER SUBMISSION REPORT FOR " + lblTenderNoValue.Text;
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(196, 215, 155));
                    formatA1CellRange.Font.Size = 18;

                    formatA1CellRange = worksheet.get_Range("A2", "G2");
                    formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[2, 7];
                    formatA1CellRange.ColumnWidth = 150;
                    formatA1CellRange.Merge(true);
                    formatA1CellRange.FormulaR1C1 = "Tender Title :" + lblProjTitleValue.Text;
                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(242, 242, 242));
                    formatA1CellRange.Font.Size = 13;
                    formatA1CellRange.Font.Bold = true;

                    if (!mIsWorkOrder)
                    {
                        formatA1CellRange = worksheet.get_Range("A3", "G3");
                        formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, 7];
                        formatA1CellRange.ColumnWidth = 150;
                        formatA1CellRange.HorizontalAlignment = 3;
                        formatA1CellRange.VerticalAlignment = 3;
                        formatA1CellRange.Font.Name = "Calibri";
                        formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(242, 242, 242));
                        formatA1CellRange.Font.Size = 13;
                        formatA1CellRange.Font.Bold = true;

                        worksheet.Cells[3, 2] = "Closing Date:" + lblClosingDateValue.Text;
                        worksheet.Cells[3, 4] = "Nos. of Submision:" + dtFinalTenderersInfo.Select("Submission<>'' and Submission<>'Regret and Not Submitted'").Count();
                        worksheet.Cells[3, 6] = "Nos. of Non-Submission:" + dtFinalTenderersInfo.Select("Submission is null or Submission='Regret and Not Submitted'").Count();

                        System.Drawing.Color color = Color.FromArgb(255, 204, 0);
                        // storing header part in Excel
                        for (int i = 1; i <= 7; i++)
                        {
                            if (i == 1)
                            {
                                worksheet.Cells[4, 1] = "SNo.";
                                formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[4, 1];
                                formatA1Cell.Font.Name = "Calibri";
                                formatA1Cell.Font.Size = "12";
                                formatA1Cell.Font.Bold = true;
                                formatA1Cell.WrapText = true;
                                formatA1Cell.ColumnWidth = 5;
                                formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                                formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                            }
                            else if (i == 2)
                            {
                                worksheet.Cells[4, i] = dgvTendererInfo.Columns[i - 2].HeaderText;
                                formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[4, i];
                                formatA1Cell.Font.Name = "Calibri";
                                formatA1Cell.Font.Size = "12";
                                formatA1Cell.Font.Bold = true;
                                formatA1Cell.WrapText = true;
                                formatA1Cell.ColumnWidth = 50;
                                formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                                formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                            }
                            else if (i != 1 && i != 2)
                            {
                                worksheet.Cells[4, i] = dgvTendererInfo.Columns[i - 2].HeaderText;
                                formatOtherCell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[4, i];
                                formatOtherCell.Font.Name = "Calibri";
                                formatOtherCell.Font.Size = "12";
                                formatOtherCell.WrapText = true;
                                formatOtherCell.Font.Bold = true;
                                formatOtherCell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                                formatOtherCell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                                if (i == 3)
                                    formatOtherCell.ColumnWidth = 12;
                                if (i == 4)
                                    formatOtherCell.ColumnWidth = 15;
                                if (i == 5)
                                    formatOtherCell.ColumnWidth = 28;
                                if (i == 6)
                                    formatOtherCell.ColumnWidth = 14;
                                if (i == 7)
                                    formatOtherCell.ColumnWidth = 14;
                            }


                        }

                        // storing Each row and column value to excel sheet
                        for (int i = 0; i < dgvTendererInfo.Rows.Count; i++)
                        {

                            for (int asciiCode = 65; asciiCode <= 71; asciiCode++)
                            {
                                char alphaBet = (char)asciiCode;
                                worksheet.get_Range(alphaBet + (i + 5).ToString(), alphaBet + (i + 5).ToString()).Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeLeft].Weight = XlBorderWeight.xlThin;
                                worksheet.get_Range(alphaBet + (i + 5).ToString(), alphaBet + (i + 5).ToString()).Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeTop].Weight = XlBorderWeight.xlThin;
                                worksheet.get_Range(alphaBet + (i + 5).ToString(), alphaBet + (i + 5).ToString()).Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeRight].Weight = XlBorderWeight.xlThin;
                                worksheet.get_Range(alphaBet + (i + 5).ToString(), alphaBet + (i + 5).ToString()).Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeBottom].Weight = XlBorderWeight.xlThin;
                                worksheet.get_Range(alphaBet + (i + 5).ToString(), alphaBet + (i + 5).ToString()).RowHeight = 25;
                                if (asciiCode == 71)
                                    worksheet.get_Range(alphaBet + (i + 5).ToString(), alphaBet + (i + 5).ToString()).WrapText = true;
                            }

                            worksheet.Cells[i + 5, 1] = i + 1;
                            for (int j = 0; j < 6; j++) // Need to print only six columns
                            {
                                if (dgvTendererInfo.Rows[i].Cells[j].Value.ToString() != "" && j != 5 && j != 4)
                                    worksheet.Cells[i + 5, j + 2] = dgvTendererInfo.Rows[i].Cells[j].Value.ToString();
                                else if ((dgvTendererInfo.Rows[i].Cells[4].Value.ToString() == "" ||
                                    dgvTendererInfo.Rows[i].Cells[4].Value.ToString().Equals("Regret and Not Submitted")) && j == 4)
                                    worksheet.Cells[i + 5, j + 2] = "Not Submitted";
                                else if (dgvTendererInfo.Rows[i].Cells[5].Value.ToString() != "")
                                {
                                    worksheet.Cells[i + 5, j + 2] = dgvTendererInfo.Rows[i].Cells[j].Style.Format = "dd/MMM/yy hh:m:ss tt";
                                    worksheet.Cells[i + 5, j + 2] = dgvTendererInfo.Rows[i].Cells[j].Value.ToString();
                                }
                            }
                        }

                    }
                    else
                    {
                        formatA1CellRange = worksheet.get_Range("A3", "G3");
                        formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, 7];
                        formatA1CellRange.ColumnWidth = 150;
                        formatA1CellRange.HorizontalAlignment = 3;
                        formatA1CellRange.VerticalAlignment = 3;
                        formatA1CellRange.Font.Name = "Calibri";
                        formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(242, 242, 242));
                        formatA1CellRange.Font.Size = 13;
                        formatA1CellRange.Font.Bold = true;

                        worksheet.Cells[3, 2] = "Work Order No.:" + lblWorkOrderNoValue.Text;
                        //worksheet.Cells[3, 4] = "Nos. of Submision:" + dtFinalTenderersInfo.Select("Submission<>''").Count();
                        worksheet.Cells[3, 6] = "Work Order Title:" + lblWorkOrderTitleValue.Text;

                        formatA1CellRange = worksheet.get_Range("A4", "G4");
                        formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[4, 7];
                        formatA1CellRange.ColumnWidth = 150;
                        formatA1CellRange.HorizontalAlignment = 3;
                        formatA1CellRange.VerticalAlignment = 3;
                        formatA1CellRange.Font.Name = "Calibri";
                        formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(242, 242, 242));
                        formatA1CellRange.Font.Size = 13;
                        formatA1CellRange.Font.Bold = true;

                        worksheet.Cells[4, 2] = "Closing Date:" + lblClosingDateValue.Text;
                        worksheet.Cells[4, 4] = "Nos. of Submision:" + dtFinalTenderersInfo.Select("Submission<>'' and Submission<>'Regret and Not Submitted'").Count();
                        worksheet.Cells[4, 6] = "Nos. of Non-Submission:" + dtFinalTenderersInfo.Select("Submission is null or Submission='Regret and Not Submitted'").Count();

                        System.Drawing.Color color = Color.FromArgb(255, 204, 0);
                        // storing header part in Excel
                        for (int i = 1; i <= 7; i++)
                        {
                            if (i == 1)
                            {
                                worksheet.Cells[5, 1] = "SNo.";
                                formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[5, 1];
                                formatA1Cell.Font.Name = "Calibri";
                                formatA1Cell.Font.Size = "12";
                                formatA1Cell.Font.Bold = true;
                                formatA1Cell.WrapText = true;
                                formatA1Cell.ColumnWidth = 5;
                                formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                                formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                            }
                            else if (i == 2)
                            {
                                worksheet.Cells[5, 2] = dgvTendererInfo.Columns[i - 2].HeaderText;
                                formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[5, i];
                                formatA1Cell.Font.Name = "Calibri";
                                formatA1Cell.Font.Size = "12";
                                formatA1Cell.Font.Bold = true;
                                formatA1Cell.WrapText = true;
                                formatA1Cell.ColumnWidth = 50;
                                formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                                formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                            }
                            else if (i != 1 && i != 2)
                            {
                                worksheet.Cells[5, i] = dgvTendererInfo.Columns[i - 2].HeaderText;
                                formatOtherCell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[5, i];
                                formatOtherCell.Font.Name = "Calibri";
                                formatOtherCell.Font.Size = "12";
                                formatOtherCell.WrapText = true;
                                formatOtherCell.Font.Bold = true;
                                formatOtherCell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                                formatOtherCell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                                if (i == 3)
                                    formatOtherCell.ColumnWidth = 12;
                                if (i == 4)
                                    formatOtherCell.ColumnWidth = 15;
                                if (i == 5)
                                    formatOtherCell.ColumnWidth = 28;
                                if (i == 6)
                                    formatOtherCell.ColumnWidth = 14;
                                if (i == 7)
                                    formatOtherCell.ColumnWidth = 14;
                            }


                        }

                        // storing Each row and column value to excel sheet
                        for (int i = 0; i < dgvTendererInfo.Rows.Count; i++)
                        {

                            for (int asciiCode = 65; asciiCode <= 71; asciiCode++)
                            {
                                char alphaBet = (char)asciiCode;
                                worksheet.get_Range(alphaBet + (i + 6).ToString(), alphaBet + (i + 6).ToString()).Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeLeft].Weight = XlBorderWeight.xlThin;
                                worksheet.get_Range(alphaBet + (i + 6).ToString(), alphaBet + (i + 6).ToString()).Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeTop].Weight = XlBorderWeight.xlThin;
                                worksheet.get_Range(alphaBet + (i + 6).ToString(), alphaBet + (i + 6).ToString()).Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeRight].Weight = XlBorderWeight.xlThin;
                                worksheet.get_Range(alphaBet + (i + 6).ToString(), alphaBet + (i + 6).ToString()).Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeBottom].Weight = XlBorderWeight.xlThin;
                                worksheet.get_Range(alphaBet + (i + 6).ToString(), alphaBet + (i + 6).ToString()).RowHeight = 25;
                                if (asciiCode == 71)
                                    worksheet.get_Range(alphaBet + (i + 6).ToString(), alphaBet + (i + 6).ToString()).WrapText = true;
                            }

                            worksheet.Cells[i + 6, 1] = i + 1;
                            for (int j = 0; j < 6; j++) // Need to print only six columns
                            {
                                if (dgvTendererInfo.Rows[i].Cells[j].Value.ToString() != "" && j != 5 && j != 4)
                                    worksheet.Cells[i + 6, j + 2] = dgvTendererInfo.Rows[i].Cells[j].Value.ToString();
                                else if ((dgvTendererInfo.Rows[i].Cells[4].Value.ToString() == "" ||
                                    dgvTendererInfo.Rows[i].Cells[4].Value.ToString().Equals("Regret and Not Submitted")) && j == 4)
                                    worksheet.Cells[i + 6, j + 2] = "Not Submitted";
                                else if (dgvTendererInfo.Rows[i].Cells[5].Value.ToString() != "")
                                {
                                    worksheet.Cells[i + 6, j + 2] = dgvTendererInfo.Rows[i].Cells[j].Style.Format = "dd/MMM/yy hh:m:ss tt";
                                    worksheet.Cells[i + 6, j + 2] = dgvTendererInfo.Rows[i].Cells[j].Value.ToString();
                                }
                            }
                        }
                    }
                    // save the application
                    workbook.SaveAs(saveFileDialog1.FileName, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show("Error occurred while creating the excel file", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void btnExportToPDF_Click(object sender, EventArgs e)
        {

            dtFinalTenderersInfo = (System.Data.DataTable)dgvTendererInfo.DataSource;
            if (mIsWorkOrder)
            {
                if (mUserRightsColl.Contains("80"))
                {
                    MessageBox.Show("You do not have permission to Export To Pdf In Work Orders, Please contact the Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            else
            {
                if (mUserRightsColl.Contains("82"))
                {
                    MessageBox.Show("You do not have permission to Export To Pdf In Tender Submission, Please contact the Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }

            string[] workOrderInfo = null;
            if (!mIsWorkOrder)
            {
                workOrderInfo = null;
                comCls.ExportToPDF("WorkOrderSubmission", strCon, dtFinalTenderersInfo, lblTenderNoValue.Text, mCommitteeName, lblProjTitleValue.Text, lblClosingDateValue.Text, ref workOrderInfo, mIsWorkOrder, mIsTenderClosingDateStage2);
            }
            else
            {
                workOrderInfo = new string[2];
                workOrderInfo[0] = lblWorkOrderNoValue.Text;
                workOrderInfo[1] = lblWorkOrderTitleValue.Text;
                comCls.ExportToPDF("WorkOrderSubmission", strCon, dtFinalTenderersInfo, lblTenderNoValue.Text, mCommitteeName, lblProjTitleValue.Text, lblClosingDateValue.Text, ref workOrderInfo, mIsWorkOrder, mIsTenderClosingDateStage2);
            }
        }


        // To move the cursor on the right side cell not working
        //       bool notlastColumn = false;
        //        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)

        //{

        //if (e.ColumnIndex==7) //if last column
        //{

        //KeyEventArgs forKeyDown = new KeyEventArgs(Keys.Enter);
        //notlastColumn = false;
        //dataGridView1_KeyDown(dgvTendererInfo, forKeyDown);

        //}
        //else
        //{

        //SendKeys.Send("{up}");
        //SendKeys.Send("{right}");

        //}

        //}

        //private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        //{

        //if (e.KeyCode == Keys.Enter && notlastColumn) //if not last column move to next
        //{

        //SendKeys.Send("{up}");
        //SendKeys.Send("{right}");

        //}
        //else if (e.KeyCode == Keys.Enter)
        //{

        //SendKeys.Send("{home}");//go to first column
        //notlastColumn = true;

        //}

        //}












    }
}
