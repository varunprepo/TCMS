﻿namespace MDI_ParenrForm.Projects
{
    partial class frmWorkOrders
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnNewWorkOrder = new System.Windows.Forms.Button();
            this.dgvWorkOrders = new System.Windows.Forms.DataGridView();
            this.btnWOTenderSubmission = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvWorkOrders)).BeginInit();
            this.SuspendLayout();
            // 
            // btnNewWorkOrder
            // 
            this.btnNewWorkOrder.BackColor = System.Drawing.Color.Maroon;
            this.btnNewWorkOrder.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNewWorkOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewWorkOrder.ForeColor = System.Drawing.Color.White;
            this.btnNewWorkOrder.Location = new System.Drawing.Point(12, 12);
            this.btnNewWorkOrder.Name = "btnNewWorkOrder";
            this.btnNewWorkOrder.Size = new System.Drawing.Size(112, 26);
            this.btnNewWorkOrder.TabIndex = 231;
            this.btnNewWorkOrder.Text = "New Work Order";
            this.btnNewWorkOrder.UseVisualStyleBackColor = false;
            this.btnNewWorkOrder.Click += new System.EventHandler(this.btnNewWorkOrder_Click);
            // 
            // dgvWorkOrders
            // 
            this.dgvWorkOrders.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvWorkOrders.BackgroundColor = System.Drawing.Color.FloralWhite;
            this.dgvWorkOrders.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvWorkOrders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Peru;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvWorkOrders.DefaultCellStyle = dataGridViewCellStyle1;
            this.dgvWorkOrders.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvWorkOrders.Location = new System.Drawing.Point(12, 44);
            this.dgvWorkOrders.Name = "dgvWorkOrders";
            this.dgvWorkOrders.RowHeadersVisible = false;
            this.dgvWorkOrders.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvWorkOrders.Size = new System.Drawing.Size(769, 349);
            this.dgvWorkOrders.TabIndex = 232;
            this.dgvWorkOrders.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvWorkOrders_CellContentClick);
            // 
            // btnWOTenderSubmission
            // 
            this.btnWOTenderSubmission.BackColor = System.Drawing.Color.Maroon;
            this.btnWOTenderSubmission.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnWOTenderSubmission.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnWOTenderSubmission.ForeColor = System.Drawing.Color.White;
            this.btnWOTenderSubmission.Location = new System.Drawing.Point(12, 409);
            this.btnWOTenderSubmission.Name = "btnWOTenderSubmission";
            this.btnWOTenderSubmission.Size = new System.Drawing.Size(199, 24);
            this.btnWOTenderSubmission.TabIndex = 240;
            this.btnWOTenderSubmission.Text = "Work Order Tender Submission";
            this.btnWOTenderSubmission.UseVisualStyleBackColor = false;
            this.btnWOTenderSubmission.Click += new System.EventHandler(this.btnWOTenderSubmission_Click);
            // 
            // frmWorkOrders
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FloralWhite;
            this.ClientSize = new System.Drawing.Size(793, 445);
            this.Controls.Add(this.btnWOTenderSubmission);
            this.Controls.Add(this.dgvWorkOrders);
            this.Controls.Add(this.btnNewWorkOrder);
            this.Name = "frmWorkOrders";
            this.Text = "Work Orders";
            ((System.ComponentModel.ISupportInitialize)(this.dgvWorkOrders)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnNewWorkOrder;
        private System.Windows.Forms.DataGridView dgvWorkOrders;
        private System.Windows.Forms.Button btnWOTenderSubmission;
    }
}