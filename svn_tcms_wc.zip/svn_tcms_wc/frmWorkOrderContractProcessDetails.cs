﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Globalization;
using System.Text.RegularExpressions;

namespace MDI_ParenrForm.Projects
{
    public partial class frmWorkOrderContractProcessDetails : Form
    {
        string mWorkOrderID = null;         
        string mUserName = null;
        int mPrjID = 0;        
        DataGridView mDgv = null;         
        IList<string> mUserRightsColl = new List<string>();                
        string mProjectTitle = null;
        string mContractId = null;         
        bool mIsHeadOfSection = false;         
        CommonClass cmnCls = null;
        

        public frmWorkOrderContractProcessDetails(IList<string> userRightsColl, string userName, string[] workOrderInfo, int prjId, DataGridView dgv, bool isHeadOfSection, string projectTitle)
        {
            InitializeComponent();
            mUserRightsColl = userRightsColl;
            if (userRightsColl.Count == 0 || isHeadOfSection)
            {
                txtWOTitle.Enabled = true;
                txtWorkOrderNo.Enabled = true;
            }
            else
            {
                if (userRightsColl.Contains("101"))
                {
                    UnableDisableTenderingPhaseControls(false);
                }
                if (userRightsColl.Contains("102"))
                {
                    UnableDisableTenderEvalPhaseControls(false);
                }
                if (userRightsColl.Contains("103"))
                {
                    UnableDisableContractsProcessControls(false);
                }
            }
            mUserName = userName;
            mWorkOrderID = workOrderInfo[5];
            cmnCls = new CommonClass(userName);
            txtWorkOrderNo.Text = workOrderInfo[0];
            txtWOTitle.Text = workOrderInfo[1];
            mContractId = workOrderInfo[6].ToString();
            if (mContractId != "")
                btnUpdateAndCloseWO.Text = "Update";
            else
                btnUpdateAndCloseWO.Text = "Save";

            if (workOrderInfo[7].ToString() != "")
            {
                mskTxtWOClosingDate.Text = Convert.ToDateTime(workOrderInfo[7].ToString().Split(' ')[0]).ToString("dd/MMM/yyyy");
            }
            if (workOrderInfo[8].ToString() != "")
            {
                mskTxtTenderOpenDate.Text = Convert.ToDateTime(workOrderInfo[8].ToString().Split(' ')[0]).ToString("dd/MMM/yyyy");
            }
            if (workOrderInfo[9].ToString() != "")
            {
                mskTxtEvalReportDateSend.Text = Convert.ToDateTime(workOrderInfo[9].ToString().Split(' ')[0]).ToString("dd/MMM/yyyy");
            }
            txtTechnoFinTotWorkdays.Text = workOrderInfo[10].ToString();
            txtNoOfMeetings.Text = workOrderInfo[11].ToString();
            if (workOrderInfo[12].ToString() != "")
            {
                mskTxtEvalRepDateReceived.Text = Convert.ToDateTime(workOrderInfo[12].ToString().Split(' ')[0]).ToString("dd/MMM/yyyy");
            }
            if (workOrderInfo[13].ToString() != "")
            {
                mskTxtTenderAwardApprovalDate.Text = Convert.ToDateTime(workOrderInfo[13].ToString().Split(' ')[0]).ToString("dd/MMM/yyyy");
            }
            mPrjID = prjId;
            mDgv = dgv;
            mIsHeadOfSection = isHeadOfSection;
            mProjectTitle = projectTitle;
            SqlConnection sqlCn = null;
            try
            {                
                if (cmnCls.PopulateComboBox1(cmbCompany, "SELECT CONTRACTORS.bidder_id, COMPANY.co_id, COMPANY.co_name FROM CONTRACTORS INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id WHERE (CONTRACTORS.proj_id = " + prjId + ") AND (CONTRACTORS.stage_Id = 4) " +
                "ORDER BY COMPANY.co_name", null, null) == null)  //on CONTRACTORS.bidder_id=WorkOrderSubmissions.bidder_id                  
                {
                    MessageBox.Show("Error occurred while populating the Submitted Bidders", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }               

                if (mContractId != "")
                {
                    using (sqlCn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                    {
                        sqlCn.Open();                        

                        DataTable dtAwardedBidders = cmnCls.GetDataTable("Select COMPANY.co_id,COMPANY.CO_NAME,CONTRACTORS.cp_tender_award,CONTRACTORS.ContractAmount,cp_request_start_date,CONTRACTORS.cp_start_date_receive,CONTRACTORS.cp_notice_contractor_to_sign, " +
                        "CONTRACTORS.cp_due_date_pb,CONTRACTORS.cp_contractor_sign,CONTRACTORS.cp_sent_dep_sign,CONTRACTORS.cp_receive_dep_sent_prsd,CONTRACTORS.cp_sent_fd_commit,CONTRACTORS.cp_receive_fd_commit,CONTRACTORS.cp_distribution,CONTRACTORS.contract_no, " +
                        "CONTRACTORS.remarks,CONTRACTORS.cp_received_of_doc,CONTRACTORS.WOTenderEstimate FROM CONTRACTORS join COMPANY on CONTRACTORS.co_id=COMPANY.co_id where proj_id=" + prjId + " and bidder_id=" + mContractId + " AND (CONTRACTORS.stage_Id = 6) Order by COMPANY.CO_NAME", sqlCn);

                        string coID = dtAwardedBidders.Rows[0]["co_id"].ToString();
                        DataTable dtSubmittedCompanies = (DataTable)cmbCompany.DataSource;
                        DataRow[] drBiddersSubmitted = dtSubmittedCompanies.Select("Ids like '%," + coID + "%'");
                        int rowCounter = 0;
                        while (rowCounter < drBiddersSubmitted.Length)
                        {
                            drBiddersSubmitted[rowCounter].Delete();
                            rowCounter++;
                        }
                        dtSubmittedCompanies.AcceptChanges();                      


                        DataRow drNewSubmittedBidders = dtSubmittedCompanies.NewRow();
                        drNewSubmittedBidders[0] = dtAwardedBidders.Rows[0]["CO_NAME"].ToString();
                        drNewSubmittedBidders[1] = mContractId + "," + coID;
                        dtSubmittedCompanies.Rows.Add(drNewSubmittedBidders);
                        dtSubmittedCompanies.AcceptChanges();

                        cmbCompany.DataSource = dtSubmittedCompanies;
                        cmbCompany.DisplayMember = "CO_NAME";
                        cmbCompany.ValueMember = "Ids";
                        cmbCompany.SelectedValue = mContractId + "," + coID;

                        if (mUserRightsColl.Count != 0)
                            cmbCompany.Enabled = false;

                        if (dtAwardedBidders.Rows[0]["cp_tender_award"].ToString() != "")
                            mskTxtWOAwardDate.Text = Convert.ToDateTime(dtAwardedBidders.Rows[0]["cp_tender_award"]).ToString("dd/MMM/yyyy");

                        if (dtAwardedBidders.Rows[0]["ContractAmount"].ToString() != "")
                            txtWOAmount.Text = string.Format("{0:#,##0.00}", double.Parse(dtAwardedBidders.Rows[0]["ContractAmount"].ToString()));

                        if (dtAwardedBidders.Rows[0]["WOTenderEstimate"].ToString() != "")
                            txtWOTenderEstimate.Text = string.Format("{0:#,##0.00}", double.Parse(dtAwardedBidders.Rows[0]["WOTenderEstimate"].ToString()));

                        if (dtAwardedBidders.Rows[0]["cp_received_of_doc"].ToString() != "")
                            mskTxtRecOfAwardDoc.Text = Convert.ToDateTime(dtAwardedBidders.Rows[0]["cp_received_of_doc"]).ToString("dd/MMM/yyyy");

                        if (dtAwardedBidders.Rows[0]["cp_request_start_date"] != DBNull.Value)
                            mskTxtReqDeptStartDate.Text = Convert.ToDateTime(dtAwardedBidders.Rows[0]["cp_request_start_date"]).ToString("dd/MMM/yyyy");
                        if (dtAwardedBidders.Rows[0]["cp_start_date_receive"] != DBNull.Value)
                            mskTxtStartDateReceive.Text = Convert.ToDateTime(dtAwardedBidders.Rows[0]["cp_start_date_receive"]).ToString("dd/MMM/yyyy");
                        if (dtAwardedBidders.Rows[0]["cp_notice_contractor_to_sign"] != DBNull.Value)
                            mskTxtNoticeSendSignContract.Text = Convert.ToDateTime(dtAwardedBidders.Rows[0]["cp_notice_contractor_to_sign"]).ToString("dd/MMM/yyyy");
                        if (dtAwardedBidders.Rows[0]["cp_due_date_pb"] != DBNull.Value)
                            mskTxtDueDateOfSubPBSign.Text = Convert.ToDateTime(dtAwardedBidders.Rows[0]["cp_due_date_pb"]).ToString("dd/MMM/yyyy");
                        if (dtAwardedBidders.Rows[0]["cp_contractor_sign"] != DBNull.Value)
                            mskTxtDateOfSignContract.Text = Convert.ToDateTime(dtAwardedBidders.Rows[0]["cp_contractor_sign"]).ToString("dd/MMM/yyyy");
                        if (dtAwardedBidders.Rows[0]["cp_sent_dep_sign"] != DBNull.Value)
                            mskTxtSentDeptForSign.Text = Convert.ToDateTime(dtAwardedBidders.Rows[0]["cp_sent_dep_sign"]).ToString("dd/MMM/yyyy");
                        if (dtAwardedBidders.Rows[0]["cp_receive_dep_sent_prsd"] != DBNull.Value)
                            mskTxtRcvdDeptSentPRSDForSign.Text = Convert.ToDateTime(dtAwardedBidders.Rows[0]["cp_receive_dep_sent_prsd"]).ToString("dd/MMM/yyyy");
                        if (dtAwardedBidders.Rows[0]["cp_sent_fd_commit"] != DBNull.Value)
                            mskTxtSentFinanceDeptForCommittment.Text = Convert.ToDateTime(dtAwardedBidders.Rows[0]["cp_sent_fd_commit"]).ToString("dd/MMM/yyyy");
                        if (dtAwardedBidders.Rows[0]["cp_receive_fd_commit"] != DBNull.Value)
                            mskTxtRcvdFromFinanceDeptForCommittment.Text = Convert.ToDateTime(dtAwardedBidders.Rows[0]["cp_receive_fd_commit"]).ToString("dd/MMM/yyyy");
                        if (dtAwardedBidders.Rows[0]["cp_distribution"] != DBNull.Value)
                            mskTxtDistribution.Text = Convert.ToDateTime(dtAwardedBidders.Rows[0]["cp_distribution"]).ToString("dd/MMM/yyyy");
                        if (dtAwardedBidders.Rows[0]["contract_no"] != DBNull.Value)
                            txtContractNo.Text = dtAwardedBidders.Rows[0]["contract_no"].ToString();
                        if (dtAwardedBidders.Rows[0]["remarks"] != DBNull.Value)
                            textRemarks.Text = dtAwardedBidders.Rows[0]["remarks"].ToString();
                        sqlCn.Close();
                    }

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while populating the Submitted Bidders", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (sqlCn != null)
                    sqlCn.Close();
            }

        }

        private void UnableDisableTenderingPhaseControls(bool isEnabled)
        {
            txtWOTitle.Enabled = isEnabled;
            txtWorkOrderNo.Enabled = isEnabled;
            mskTxtWOClosingDate.Enabled = isEnabled;
            dtpWOClosingDate.Enabled = isEnabled;
        }

        private void UnableDisableTenderEvalPhaseControls(bool isEnabled)
        {
            mskTxtTenderOpenDate.Enabled = isEnabled;
            dtpTenderOpenDate.Enabled = isEnabled;
            mskTxtEvalReportDateSend.Enabled = isEnabled;
            dtpEvalReportDateSend.Enabled = isEnabled;
            txtTechnoFinTotWorkdays.Enabled = isEnabled;
            mskTxtEvalRepDateReceived.Enabled = isEnabled;
            dtpEvalRepDateReceived.Enabled = isEnabled;
            mskTxtTenderAwardApprovalDate.Enabled = isEnabled;
            dtpTenderAwardApprovalDate.Enabled = isEnabled;
            txtNoOfMeetings.Enabled = isEnabled;
            mskTxtWOAwardDate.Enabled = isEnabled;
            dtpWOAwardDate.Enabled = isEnabled;
            cmbCompany.Enabled = isEnabled;
            txtWOAmount.Enabled = isEnabled;
        }

        private void UnableDisableContractsProcessControls(bool isEnabled)
        {
            mskTxtRecOfAwardDoc.Enabled = isEnabled;
            dtpRecOfAwardDoc.Enabled = isEnabled;
            mskTxtReqDeptStartDate.Enabled = isEnabled;
            dtpReqDeptStartDate.Enabled = isEnabled;
            mskTxtStartDateReceive.Enabled = isEnabled;
            dtpStartDateReceive.Enabled = isEnabled;
            mskTxtNoticeSendSignContract.Enabled = isEnabled;
            dtpNoticeSendSignContract.Enabled = isEnabled;
            mskTxtDueDateOfSubPBSign.Enabled = isEnabled;
            dtpDueDateOfSubPBSign.Enabled = isEnabled;
            mskTxtDateOfSignContract.Enabled = isEnabled;
            dtpDateOfSignContract.Enabled = isEnabled;
            mskTxtSentDeptForSign.Enabled = isEnabled;
            dtpSentDeptForSign.Enabled = isEnabled;
            mskTxtRcvdDeptSentPRSDForSign.Enabled = isEnabled;
            dtpRcvdDeptSentPRSDForSign.Enabled = isEnabled;
            mskTxtSentFinanceDeptForCommittment.Enabled = isEnabled;
            dtpSentFinanceDeptForCommittment.Enabled = isEnabled;
            mskTxtRcvdFromFinanceDeptForCommittment.Enabled = isEnabled;
            dtpRcvdFromFinanceDeptForCommittment.Enabled = isEnabled;
            mskTxtDistribution.Enabled = isEnabled;
            dtpDistribution.Enabled = isEnabled;
            txtContractNo.Enabled = isEnabled;
            textRemarks.Enabled = isEnabled;
        }
        
        private void btnSaveAndCloseWO_Click(object sender, EventArgs e)
        {             
            if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
            {
                if (mUserRightsColl.Contains("77"))
                {
                    MessageBox.Show("You do not have permission to Edit Contractors Details In Work Orders, Please contact the head of section", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            
            if (mskTxtWOClosingDate.Text.Trim() == "")
            {
                MessageBox.Show("Work Order Closing Date cannot be left blank", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                mskTxtWOClosingDate.Focus();
                return;
            }
            if (txtTechnoFinTotWorkdays.Text != "")
            {
                if (Convert.ToInt32(txtTechnoFinTotWorkdays.Text) > 32767)
                {
                    MessageBox.Show("Techno Financial Total Workdays cannot be greater than 32767");
                    return;
                }
            }

            if (txtNoOfMeetings.Text != "")
            {

                if (Convert.ToInt32(txtNoOfMeetings.Text) > 32767)
                {
                    MessageBox.Show("No. Of Meetings cannot be greater than 32767");
                    return;
                }
            }

            if (cmbCompany.SelectedItem != null)
            {                
                if (mskTxtWOAwardDate.Text != "")
                {
                    if (Convert.ToDateTime(mskTxtWOAwardDate.Text).Date.CompareTo(Convert.ToDateTime(mskTxtWOClosingDate.Text).Date) < 0)
                    {
                        MessageBox.Show("Awarded date cannot be less than closing date, Please enter Awarded date greater than Closing Date", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        mskTxtWOAwardDate.Focus();
                        return;
                    }
                }
                 
            }
            else
                btnUpdateAndCloseWO.Text = "Update";

            CommonClass comCls = new CommonClass(mUserName);             
            string woStatus = null;
            int noOfDays = comCls.DateDiff(mskTxtWOClosingDate.Text);
            if (noOfDays <= 0)
            {
                if (noOfDays == 0)
                {
                    if (DateTime.Now.TimeOfDay.Hours >= 13)
                        woStatus = "Closed";
                    else
                        woStatus = "Open";
                }
                else
                    woStatus = "Closed";
            }
            else
                woStatus = "Open";

            SqlConnection sqlConn = null;
            SqlTransaction transaction = null;
            try
            {
                using (sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                {
                    if (sqlConn.State == ConnectionState.Closed)
                        sqlConn.Open();                    

                    string sqlQuery = null;                    
                    SqlCommand sqlCmd = null;                   

                    if (btnUpdateAndCloseWO.Text == "Update")
                    {                          
                        if (cmbCompany.SelectedItem != null)
                        {
                            sqlQuery = "update CONTRACTORS set contract_no=@contractNo,cp_request_start_date=@cpReqStartDate,cp_start_date_receive=@cpStartDateRec,cp_notice_contractor_to_sign=@cpNoticeContractorToSign," +
                            "cp_due_date_pb=@cpDueDatePb,cp_contractor_sign=@cpContractorSign,cp_sent_dep_sign=@cpSentDepSign,cp_receive_dep_sent_prsd=@cpRecDepSentPrsd,cp_sent_fd_commit=@cpSentFdCommit,cp_receive_fd_commit=@cpRecFdCommit," +
                            "cp_distribution=@cpDistribution,Remarks=@remarks,update_user_pc=@updateUserPC,update_date_pc=@updateDatePC,contractAmount=@workOrderAmount,cp_tender_award=@cpTenderAward,cp_received_of_doc=@cpReceivedOfDoc, " +
                            "WOTenderEstimate=@woTenderEstimate where bidder_id=@bidderId";

                            transaction = sqlConn.BeginTransaction();
                            sqlCmd = new SqlCommand(sqlQuery, sqlConn);
                            sqlCmd.Transaction = transaction;
                            
                            sqlCmd.Parameters.AddWithValue("@bidderId", mContractId);                           

                            if (mskTxtRecOfAwardDoc.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@cpReceivedOfDoc", Convert.ToDateTime(mskTxtRecOfAwardDoc.Text.Trim()));
                            else
                                sqlCmd.Parameters.AddWithValue("@cpReceivedOfDoc", DBNull.Value);
                            if (mskTxtReqDeptStartDate.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@cpReqStartDate", Convert.ToDateTime(mskTxtReqDeptStartDate.Text.Trim()));
                            else
                                sqlCmd.Parameters.AddWithValue("@cpReqStartDate", DBNull.Value);
                            if (mskTxtStartDateReceive.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@cpStartDateRec", Convert.ToDateTime(mskTxtStartDateReceive.Text.Trim()));
                            else
                                sqlCmd.Parameters.AddWithValue("@cpStartDateRec", DBNull.Value);
                            if (mskTxtNoticeSendSignContract.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@cpNoticeContractorToSign", Convert.ToDateTime(mskTxtNoticeSendSignContract.Text.Trim()));
                            else
                                sqlCmd.Parameters.AddWithValue("@cpNoticeContractorToSign", DBNull.Value);
                            if (mskTxtDueDateOfSubPBSign.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@cpDueDatePb", Convert.ToDateTime(mskTxtDueDateOfSubPBSign.Text.Trim()));
                            else
                                sqlCmd.Parameters.AddWithValue("@cpDueDatePb", DBNull.Value);
                            if (mskTxtDateOfSignContract.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@cpContractorSign", Convert.ToDateTime(mskTxtDateOfSignContract.Text.Trim()));
                            else
                                sqlCmd.Parameters.AddWithValue("@cpContractorSign", DBNull.Value);
                            if (mskTxtSentDeptForSign.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@cpSentDepSign", Convert.ToDateTime(mskTxtSentDeptForSign.Text.Trim()));
                            else
                                sqlCmd.Parameters.AddWithValue("@cpSentDepSign", DBNull.Value);
                            if (mskTxtRcvdDeptSentPRSDForSign.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@cpRecDepSentPrsd", Convert.ToDateTime(mskTxtRcvdDeptSentPRSDForSign.Text.Trim()));
                            else
                                sqlCmd.Parameters.AddWithValue("@cpRecDepSentPrsd", DBNull.Value);
                            if (mskTxtSentFinanceDeptForCommittment.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@cpSentFdCommit", Convert.ToDateTime(mskTxtSentFinanceDeptForCommittment.Text.Trim()));
                            else
                                sqlCmd.Parameters.AddWithValue("@cpSentFdCommit", DBNull.Value);
                            if (mskTxtRcvdFromFinanceDeptForCommittment.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@cpRecFdCommit", Convert.ToDateTime(mskTxtRcvdFromFinanceDeptForCommittment.Text.Trim()));
                            else
                                sqlCmd.Parameters.AddWithValue("@cpRecFdCommit", DBNull.Value);
                            if (mskTxtDistribution.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@cpDistribution", Convert.ToDateTime(mskTxtDistribution.Text.Trim()));
                            else
                                sqlCmd.Parameters.AddWithValue("@cpDistribution", DBNull.Value);
                            if (textRemarks.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@remarks", textRemarks.Text.Trim());
                            else
                                sqlCmd.Parameters.AddWithValue("@remarks", DBNull.Value);
                            if (txtContractNo.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@contractNo", txtContractNo.Text.Trim());
                            else
                                sqlCmd.Parameters.AddWithValue("@contractNo", DBNull.Value);

                            if (txtWOAmount.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@workOrderAmount", txtWOAmount.Text.Trim().Replace(",", ""));
                            else
                                sqlCmd.Parameters.AddWithValue("@workOrderAmount", DBNull.Value);
                            
                            if (txtWOTenderEstimate.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@woTenderEstimate", txtWOTenderEstimate.Text.Trim().Replace(",", ""));
                            else
                                sqlCmd.Parameters.AddWithValue("@woTenderEstimate", DBNull.Value);

                            
                            if (mskTxtWOAwardDate.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@cpTenderAward", Convert.ToDateTime(mskTxtWOAwardDate.Text.Trim()));
                            else
                                sqlCmd.Parameters.AddWithValue("@cpTenderAward", DBNull.Value);                            
                            
                            sqlCmd.Parameters.AddWithValue("@updateUserPC", mUserName);
                            sqlCmd.Parameters.AddWithValue("@updateDatePC", DateTime.Now);
                            sqlCmd.ExecuteNonQuery();
                            sqlCmd.Dispose();
                        }


                        if (mContractId != "")
                        {
                            if (mUserRightsColl.Count == 0 || mIsHeadOfSection)
                            {
                                sqlQuery = "update WorkOrders set bidder_Id=@bidderId,workOrderNo=@workOrderNo,workOrderTitle=@workOrderTitle,workOrderClosingDate=@workOrderClosingDate,workOrderStatus=@workOrderStatus,update_user=@updateUser,update_date=@updateDate," +
                                "tender_open_date=@tenderOpenDate,evaluation_report_datesend=@evalReportDatesend,techno_financial_totalworkdays=@technoFinancialTotWorkdays,evaluation_report_daterecvd=@evalReportDaterecvd,tender_award_approvaldate=@tenderAwardApprovaldate," +
                                "no_of_meetings=@noOfMeetings where workOrderId=@workOrderId";
                            }
                            else
                            {
                                sqlQuery = "update WorkOrders set bidder_Id=@bidderId,workOrderClosingDate=@workOrderClosingDate,workOrderStatus=@workOrderStatus,update_user=@updateUser,update_date=@updateDate,tender_open_date=@tenderOpenDate,evaluation_report_datesend=@evalReportDatesend," +
                                "techno_financial_totalworkdays=@technoFinancialTotWorkdays,evaluation_report_daterecvd=@evalReportDaterecvd,tender_award_approvaldate=@tenderAwardApprovaldate,no_of_meetings=@noOfMeetings where workOrderId=@workOrderId";
                            }
                        }
                        else
                        {
                            if (mUserRightsColl.Count == 0 || mIsHeadOfSection)
                            {
                                sqlQuery = "update WorkOrders set workOrderNo=@workOrderNo,workOrderTitle=@workOrderTitle,workOrderClosingDate=@workOrderClosingDate,workOrderStatus=@workOrderStatus,update_user=@updateUser,update_date=@updateDate,tender_open_date=@tenderOpenDate," +
                                "evaluation_report_datesend=@evalReportDatesend,techno_financial_totalworkdays=@technoFinancialTotWorkdays,evaluation_report_daterecvd=@evalReportDaterecvd,tender_award_approvaldate=@tenderAwardApprovaldate," +
                                "no_of_meetings=@noOfMeetings where workOrderId=@workOrderId";
                            }
                            else
                            {
                                sqlQuery = "update WorkOrders set workOrderClosingDate=@workOrderClosingDate,workOrderStatus=@workOrderStatus,update_user=@updateUser,update_date=@updateDate,tender_open_date=@tenderOpenDate,evaluation_report_datesend=@evalReportDatesend,techno_financial_totalworkdays=@technoFinancialTotWorkdays," +
                                "evaluation_report_daterecvd=@evalReportDaterecvd,tender_award_approvaldate=@tenderAwardApprovaldate,no_of_meetings=@noOfMeetings where workOrderId=@workOrderId";
                            }
                        }

                        sqlCmd = new SqlCommand(sqlQuery, sqlConn);
                        if (cmbCompany.SelectedItem != null)            
                            sqlCmd.Transaction = transaction;
                        sqlCmd.Parameters.AddWithValue("@workOrderId", mWorkOrderID);
                        sqlCmd.Parameters.AddWithValue("@workOrderClosingDate", Convert.ToDateTime(mskTxtWOClosingDate.Text));
                        sqlCmd.Parameters.AddWithValue("@workOrderStatus", woStatus);
                        if (mUserRightsColl.Count == 0 || mIsHeadOfSection)
                        {
                            sqlCmd.Parameters.AddWithValue("@workOrderNo", txtWorkOrderNo.Text.Replace("'", "").Trim());
                            sqlCmd.Parameters.AddWithValue("@workOrderTitle", txtWOTitle.Text.Replace("'", "").Trim());
                        }
                        if (mContractId != "")
                            sqlCmd.Parameters.AddWithValue("@bidderId", mContractId);
                        sqlCmd.Parameters.AddWithValue("@updateUser", mUserName);
                        sqlCmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                        if (mskTxtTenderOpenDate.Text.Trim() != "")
                            sqlCmd.Parameters.AddWithValue("@tenderOpenDate", Convert.ToDateTime(mskTxtTenderOpenDate.Text.Trim()));
                        else
                            sqlCmd.Parameters.AddWithValue("@tenderOpenDate", DBNull.Value);

                        if (mskTxtEvalReportDateSend.Text.Trim() != "")
                            sqlCmd.Parameters.AddWithValue("@evalReportDatesend", Convert.ToDateTime(mskTxtEvalReportDateSend.Text.Trim()));
                        else
                            sqlCmd.Parameters.AddWithValue("@evalReportDatesend", DBNull.Value);

                        if (txtTechnoFinTotWorkdays.Text.Trim() != "")
                            sqlCmd.Parameters.AddWithValue("@technoFinancialTotWorkdays", txtTechnoFinTotWorkdays.Text.Trim());
                        else
                            sqlCmd.Parameters.AddWithValue("@technoFinancialTotWorkdays", DBNull.Value);

                        if (mskTxtEvalRepDateReceived.Text.Trim() != "")
                            sqlCmd.Parameters.AddWithValue("@evalReportDaterecvd", mskTxtEvalRepDateReceived.Text.Trim());
                        else
                            sqlCmd.Parameters.AddWithValue("@evalReportDaterecvd", DBNull.Value);

                        if (mskTxtTenderAwardApprovalDate.Text.Trim() != "")
                            sqlCmd.Parameters.AddWithValue("@tenderAwardApprovaldate", mskTxtTenderAwardApprovalDate.Text.Trim());
                        else
                            sqlCmd.Parameters.AddWithValue("@tenderAwardApprovaldate", DBNull.Value);

                        if (txtNoOfMeetings.Text.Trim() != "")
                            sqlCmd.Parameters.AddWithValue("@noOfMeetings", txtNoOfMeetings.Text.Trim());
                        else
                            sqlCmd.Parameters.AddWithValue("@noOfMeetings", DBNull.Value);

                        sqlCmd.ExecuteNonQuery();
                        if (cmbCompany.SelectedItem != null)            
                            transaction.Commit();
                        sqlCmd.Dispose();
                        if (cmbCompany.SelectedItem != null)            
                            MessageBox.Show("Awarded Contractor details updated successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show(txtWorkOrderNo.Text+" Work Order details updated successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        int contractorId = 0;
                        if (cmbCompany.SelectedItem != null)
                        {
                            transaction = sqlConn.BeginTransaction();
                            clsCP_Stage clsCPStage = new clsCP_Stage(mUserName, mIsHeadOfSection);
                            contractorId = clsCPStage.maxValue("SELECT MAX(bidder_id)+1 FROM [CONTRACTORS]");
                             
                            sqlQuery = "insert into CONTRACTORS (ContractTitle,contract_status_id,contract_no,cp_request_start_date,cp_start_date_receive,cp_notice_contractor_to_sign,cp_due_date_pb,cp_contractor_sign,cp_sent_dep_sign,cp_receive_dep_sent_prsd,cp_sent_fd_commit,cp_receive_fd_commit," +
                            "cp_distribution,Remarks,create_date,create_user,contractAmount,cp_tender_award,bidder_id,co_id,proj_id,stage_Id,cp_received_of_doc,WOTenderEstimate) " +
                            "values (@contractTitle,@contractStatusId,@contractNo,@cpReqStartDate,@cpStartDateRec,@cpNoticeContractorToSign,@cpDueDatePb,@cpContractorSign,@cpSentDepSign,@cpRecDepSentPrsd,@cpSentFdCommit," +
                            "@cpRecFdCommit,@cpDistribution,@remarks,@createdate,@createUser,@workOrderAmount,@cpTenderAward,@contractorId,@co_id,@proj_id,@stageId,@cpReceivedOfDoc,@woTenderEstimate)";

                            sqlCmd = new SqlCommand(sqlQuery, sqlConn);
                            sqlCmd.Transaction = transaction;
                            
                            sqlCmd.Parameters.AddWithValue("@proj_id", mPrjID);
                            sqlCmd.Parameters.AddWithValue("@contractorId", contractorId);
                            sqlCmd.Parameters.AddWithValue("@contractTitle", txtWOTitle.Text.Trim());
                            sqlCmd.Parameters.AddWithValue("@contractStatusId", 1);
                            if (mskTxtRecOfAwardDoc.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@cpReceivedOfDoc", Convert.ToDateTime(mskTxtRecOfAwardDoc.Text.Trim()));
                            else
                                sqlCmd.Parameters.AddWithValue("@cpReceivedOfDoc", DBNull.Value);
                            if (txtContractNo.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@contractNo", txtContractNo.Text.Trim());
                            else
                                sqlCmd.Parameters.AddWithValue("@contractNo", DBNull.Value);
                            if (mskTxtReqDeptStartDate.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@cpReqStartDate", Convert.ToDateTime(mskTxtReqDeptStartDate.Text.Trim()));
                            else
                                sqlCmd.Parameters.AddWithValue("@cpReqStartDate", DBNull.Value);
                            if (mskTxtStartDateReceive.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@cpStartDateRec", Convert.ToDateTime(mskTxtStartDateReceive.Text.Trim()));
                            else
                                sqlCmd.Parameters.AddWithValue("@cpStartDateRec", DBNull.Value);
                            if (mskTxtNoticeSendSignContract.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@cpNoticeContractorToSign", Convert.ToDateTime(mskTxtNoticeSendSignContract.Text.Trim()));
                            else
                                sqlCmd.Parameters.AddWithValue("@cpNoticeContractorToSign", DBNull.Value);
                            if (mskTxtDueDateOfSubPBSign.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@cpDueDatePb", Convert.ToDateTime(mskTxtDueDateOfSubPBSign.Text.Trim()));
                            else
                                sqlCmd.Parameters.AddWithValue("@cpDueDatePb", DBNull.Value);
                            if (mskTxtDateOfSignContract.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@cpContractorSign", Convert.ToDateTime(mskTxtDateOfSignContract.Text.Trim()));
                            else
                                sqlCmd.Parameters.AddWithValue("@cpContractorSign", DBNull.Value);
                            if (mskTxtSentDeptForSign.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@cpSentDepSign", Convert.ToDateTime(mskTxtSentDeptForSign.Text.Trim()));
                            else
                                sqlCmd.Parameters.AddWithValue("@cpSentDepSign", DBNull.Value);
                            if (mskTxtRcvdDeptSentPRSDForSign.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@cpRecDepSentPrsd", Convert.ToDateTime(mskTxtRcvdDeptSentPRSDForSign.Text.Trim()));
                            else
                                sqlCmd.Parameters.AddWithValue("@cpRecDepSentPrsd", DBNull.Value);
                            if (mskTxtSentFinanceDeptForCommittment.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@cpSentFdCommit", Convert.ToDateTime(mskTxtSentFinanceDeptForCommittment.Text.Trim()));
                            else
                                sqlCmd.Parameters.AddWithValue("@cpSentFdCommit", DBNull.Value);
                            if (mskTxtRcvdFromFinanceDeptForCommittment.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@cpRecFdCommit", Convert.ToDateTime(mskTxtRcvdFromFinanceDeptForCommittment.Text.Trim()));
                            else
                                sqlCmd.Parameters.AddWithValue("@cpRecFdCommit", DBNull.Value);
                            if (mskTxtDistribution.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@cpDistribution", Convert.ToDateTime(mskTxtDistribution.Text.Trim()));
                            else
                                sqlCmd.Parameters.AddWithValue("@cpDistribution", DBNull.Value);
                            if (textRemarks.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@remarks", textRemarks.Text.Trim());
                            else
                                sqlCmd.Parameters.AddWithValue("@remarks", DBNull.Value);

                            if (txtWOAmount.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@workOrderAmount", txtWOAmount.Text.Trim().Replace(",", ""));
                            else
                                sqlCmd.Parameters.AddWithValue("@workOrderAmount", DBNull.Value);

                            if (mskTxtWOAwardDate.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@cpTenderAward", Convert.ToDateTime(mskTxtWOAwardDate.Text.Trim()));
                            else
                                sqlCmd.Parameters.AddWithValue("@cpTenderAward", DBNull.Value);

                            if (txtWOTenderEstimate.Text.Trim() != "")
                                sqlCmd.Parameters.AddWithValue("@woTenderEstimate", txtWOTenderEstimate.Text.Trim().Replace(",", ""));
                            else
                                sqlCmd.Parameters.AddWithValue("@woTenderEstimate", DBNull.Value);    
                                                        
                            sqlCmd.Parameters.AddWithValue("@createUser", mUserName);
                            sqlCmd.Parameters.AddWithValue("@createDate", DateTime.Now);
                            sqlCmd.Parameters.AddWithValue("@co_id", cmbCompany.SelectedValue.ToString().Split(',')[1]);
                            sqlCmd.Parameters.AddWithValue("@stageId", 6); //When WorkOrder is Awarded to a company
                            sqlCmd.ExecuteNonQuery();
                            sqlCmd.Dispose();
                        }

                        if (mUserRightsColl.Count == 0 || mIsHeadOfSection)
                        {
                            sqlQuery = "update WorkOrders set bidder_Id=@bidderId,workOrderNo=@workOrderNo,workOrderTitle=@workOrderTitle,workOrderClosingDate=@workOrderClosingDate,workOrderStatus=@workOrderStatus,update_user=@updateUser,update_date=@updateDate,tender_open_date=@tenderOpenDate,evaluation_report_datesend=@evalReportDatesend,techno_financial_totalworkdays=@technoFinancialTotWorkdays," +
                            "evaluation_report_daterecvd=@evalReportDaterecvd,tender_award_approvaldate=@tenderAwardApprovaldate,no_of_meetings=@noOfMeetings where workOrderId=@workOrderId";
                        }
                        else
                        {
                            sqlQuery = "update WorkOrders set bidder_Id=@bidderId,workOrderClosingDate=@workOrderClosingDate,workOrderStatus=@workOrderStatus,update_user=@updateUser,update_date=@updateDate,tender_open_date=@tenderOpenDate,evaluation_report_datesend=@evalReportDatesend,techno_financial_totalworkdays=@technoFinancialTotWorkdays," +
                            "evaluation_report_daterecvd=@evalReportDaterecvd,tender_award_approvaldate=@tenderAwardApprovaldate,no_of_meetings=@noOfMeetings where workOrderId=@workOrderId";
                        }
                        sqlCmd = new SqlCommand(sqlQuery, sqlConn);
                        if (cmbCompany.SelectedItem != null)            
                            sqlCmd.Transaction = transaction;
                        sqlCmd.Parameters.AddWithValue("@workOrderId", mWorkOrderID);
                        sqlCmd.Parameters.AddWithValue("@workOrderClosingDate", Convert.ToDateTime(mskTxtWOClosingDate.Text));
                        if(contractorId != 0)
                            sqlCmd.Parameters.AddWithValue("@bidderId", contractorId);                         
                        else
                            sqlCmd.Parameters.AddWithValue("@bidderId", DBNull.Value);
                        if (mUserRightsColl.Count == 0 || mIsHeadOfSection)
                        {
                            sqlCmd.Parameters.AddWithValue("@workOrderNo", txtWorkOrderNo.Text.Replace("'", "").Trim());
                            sqlCmd.Parameters.AddWithValue("@workOrderTitle", txtWOTitle.Text.Replace("'","").Trim());
                        }
                        sqlCmd.Parameters.AddWithValue("@workOrderStatus", woStatus);
                        sqlCmd.Parameters.AddWithValue("@updateUser", mUserName);
                        sqlCmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);

                        if (mskTxtTenderOpenDate.Text.Trim() != "")
                            sqlCmd.Parameters.AddWithValue("@tenderOpenDate", Convert.ToDateTime(mskTxtTenderOpenDate.Text.Trim()));
                        else
                            sqlCmd.Parameters.AddWithValue("@tenderOpenDate", DBNull.Value);

                        if (mskTxtEvalReportDateSend.Text.Trim() != "")
                            sqlCmd.Parameters.AddWithValue("@evalReportDatesend", Convert.ToDateTime(mskTxtEvalReportDateSend.Text.Trim()));
                        else
                            sqlCmd.Parameters.AddWithValue("@evalReportDatesend", DBNull.Value);

                        if (txtTechnoFinTotWorkdays.Text.Trim() != "")
                            sqlCmd.Parameters.AddWithValue("@technoFinancialTotWorkdays", txtTechnoFinTotWorkdays.Text.Trim());
                        else
                            sqlCmd.Parameters.AddWithValue("@technoFinancialTotWorkdays", DBNull.Value);

                        if (mskTxtEvalRepDateReceived.Text.Trim() != "")
                            sqlCmd.Parameters.AddWithValue("@evalReportDaterecvd", mskTxtEvalRepDateReceived.Text.Trim());
                        else
                            sqlCmd.Parameters.AddWithValue("@evalReportDaterecvd", DBNull.Value);

                        if (mskTxtTenderAwardApprovalDate.Text.Trim() != "")
                            sqlCmd.Parameters.AddWithValue("@tenderAwardApprovaldate", mskTxtTenderAwardApprovalDate.Text.Trim());
                        else
                            sqlCmd.Parameters.AddWithValue("@tenderAwardApprovaldate", DBNull.Value);

                        if (txtNoOfMeetings.Text.Trim() != "")
                            sqlCmd.Parameters.AddWithValue("@noOfMeetings", txtNoOfMeetings.Text.Trim());
                        else
                            sqlCmd.Parameters.AddWithValue("@noOfMeetings", DBNull.Value);

                        sqlCmd.ExecuteNonQuery();

                        if (cmbCompany.SelectedItem != null)
                            transaction.Commit();
                        sqlCmd.Dispose();
                        
                        MessageBox.Show("Awarded Contractor details inserted successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    cmnCls.CreateWorkOrderGridViewColumns(mDgv, mPrjID, 0);                                                           
                     
                }
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                MessageBox.Show("Exception occurred while inserting a new Work Order", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlConn.Close();
            }
        }

        // Added by Varun on 21 May 2014 for checking the duplicate ContractNo.
        public bool ValidateContractNo(string contractNo,string contractorID)
        {
            using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
            {
                sqlConn.Open();
                string sqlQuery = null;
                if (contractorID != "")
                    sqlQuery = "select contract_no from [CONTRACTORS] where contract_no = @cntrNo and bidder_id<>" + contractorID;
                else
                    sqlQuery = "select contract_no from [CONTRACTORS] where contract_no = @cntrNo";
                SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
                contractNo = contractNo.Replace(" ", "").Replace("-", "/");
                while (Regex.Match(contractNo, "/0").Success)
                    contractNo = contractNo.Replace("/0", "/");
                sqlCom.Parameters.AddWithValue("@cntrNo", contractNo.ToUpper());
                SqlDataReader sqlDtReader = sqlCom.ExecuteReader();
                if (sqlDtReader.HasRows)
                {
                    if (sqlDtReader.Read())
                    {
                        MessageBox.Show("Entered Contract Number already assigned to some other Contractor, Please enter a unique Contract Number", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return false;
                    }
                }
                else
                    txtContractNo.Text = contractNo.ToUpper();
                sqlDtReader.Close();
                sqlCom = null;
                sqlConn.Close();
            }
            return true;
        }

        private void dtpReqDeptStartDate_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                dtpReqDeptStartDate.CustomFormat = "dd/MMM/yyyy";
                if (mskTxtRecOfAwardDoc.Text.Trim() != "" && mskTxtReqDeptStartDate.Text.Trim() == "")
                {
                    dtpReqDeptStartDate.Value = Convert.ToDateTime(mskTxtRecOfAwardDoc.Text.ToString()).AddDays(1);                    
                }
                mskTxtReqDeptStartDate.Text = dtpReqDeptStartDate.Value.ToString("dd/MMM/yyyy");
                mskTxtReqDeptStartDate.Focus();
            }
            else
            {
                dtpStartDateReceive.Value = dtpReqDeptStartDate.Value.AddDays(1);                
            }            
        }

        private void txtContractNo_Leave(object sender, EventArgs e)
        {
            if (txtContractNo.Text.Trim() != "")
            {
                if (ValidateContractNo(txtContractNo.Text,mContractId) == false)
                    txtContractNo.Focus();
            }
        }

        private void dtpStartDateReceive_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                dtpStartDateReceive.CustomFormat = "dd/MMM/yyyy";
                if (mskTxtReqDeptStartDate.Text.Trim() != "" && mskTxtStartDateReceive.Text.Trim() == "")
                {
                    dtpStartDateReceive.Value = Convert.ToDateTime(mskTxtReqDeptStartDate.Text.ToString()).AddDays(1);
                 
                }
                mskTxtStartDateReceive.Text = dtpStartDateReceive.Value.ToString("dd/MMM/yyyy");
                mskTxtStartDateReceive.Focus();
            }
            else
            {
                dtpNoticeSendSignContract.Value = dtpStartDateReceive.Value.AddDays(1);
            }            
        }

        private void dtpNoticeSendSignContract_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                dtpNoticeSendSignContract.CustomFormat = "dd/MMM/yyyy";
                if (mskTxtStartDateReceive.Text.Trim() != "" && mskTxtNoticeSendSignContract.Text.Trim() == "")
                {
                    dtpNoticeSendSignContract.Value = Convert.ToDateTime(mskTxtStartDateReceive.Text.ToString()).AddDays(1);                    
                }
                mskTxtNoticeSendSignContract.Text = dtpNoticeSendSignContract.Value.ToString("dd/MMM/yyyy");
                mskTxtNoticeSendSignContract.Focus();
            }
            else
            {
                dtpDueDateOfSubPBSign.Value = dtpNoticeSendSignContract.Value.AddDays(1);
            }
            
        }

        private void dtpDueDateOfSubPBSign_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                dtpDueDateOfSubPBSign.CustomFormat = "dd/MMM/yyyy";
                if (mskTxtStartDateReceive.Text.Trim() != "" && mskTxtDueDateOfSubPBSign.Text.Trim() == "")
                {
                    dtpDueDateOfSubPBSign.Value = Convert.ToDateTime(mskTxtStartDateReceive.Text.ToString()).AddDays(1);                    
                }
                mskTxtDueDateOfSubPBSign.Text = dtpDueDateOfSubPBSign.Value.ToString("dd/MMM/yyyy");
                mskTxtDueDateOfSubPBSign.Focus();
            }
            else
            {
                dtpDateOfSignContract.Value = dtpDueDateOfSubPBSign.Value.AddDays(1);
            }
            
        }

        private void dtpDateOfSignContract_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                dtpDateOfSignContract.CustomFormat = "dd/MMM/yyyy";
                if (mskTxtDueDateOfSubPBSign.Text.Trim() != "" && mskTxtDateOfSignContract.Text.Trim() == "")
                {
                    dtpDateOfSignContract.Value = Convert.ToDateTime(mskTxtDueDateOfSubPBSign.Text.ToString()).AddDays(1);                    
                }
                mskTxtDateOfSignContract.Text = dtpDateOfSignContract.Value.ToString("dd/MMM/yyyy");
                mskTxtDateOfSignContract.Focus();
            }
            else
            {
                dtpSentDeptForSign.Value = dtpDateOfSignContract.Value.AddDays(1);
            }
            
        }

        private void dtpSentDeptForSign_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                dtpSentDeptForSign.CustomFormat = "dd/MMM/yyyy";
                if (mskTxtDateOfSignContract.Text.Trim() != "" && mskTxtSentDeptForSign.Text.Trim() == "")
                {
                    dtpSentDeptForSign.Value = Convert.ToDateTime(mskTxtDateOfSignContract.Text.ToString()).AddDays(1);                    
                }
                mskTxtSentDeptForSign.Text = dtpSentDeptForSign.Value.ToString("dd/MMM/yyyy");
                mskTxtSentDeptForSign.Focus();
            }
            else
            {
                dtpRcvdDeptSentPRSDForSign.Value = dtpSentDeptForSign.Value.AddDays(1);
            }
            
        }

        private void dtpRcvdDeptSentPRSDForSign_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                dtpRcvdDeptSentPRSDForSign.CustomFormat = "dd/MMM/yyyy";
                if (mskTxtSentDeptForSign.Text.Trim() != "" && mskTxtRcvdDeptSentPRSDForSign.Text.Trim() == "")
                {
                    dtpRcvdDeptSentPRSDForSign.Value = Convert.ToDateTime(mskTxtSentDeptForSign.Text.ToString()).AddDays(1);                    
                }
                mskTxtRcvdDeptSentPRSDForSign.Text = dtpRcvdDeptSentPRSDForSign.Value.ToString("dd/MMM/yyyy");
                mskTxtRcvdDeptSentPRSDForSign.Focus();
            }
            else
            {
                dtpSentFinanceDeptForCommittment.Value = dtpRcvdDeptSentPRSDForSign.Value.AddDays(1);
            }
            
        }

        private void dtpSentFinanceDeptForCommittment_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                dtpSentFinanceDeptForCommittment.CustomFormat = "dd/MMM/yyyy";
                if (mskTxtSentDeptForSign.Text.Trim() != "" && mskTxtSentFinanceDeptForCommittment.Text.Trim() == "")
                {
                    dtpSentFinanceDeptForCommittment.Value = Convert.ToDateTime(mskTxtSentDeptForSign.Text.ToString()).AddDays(1);                    
                }
                mskTxtSentFinanceDeptForCommittment.Text = dtpSentFinanceDeptForCommittment.Value.ToString("dd/MMM/yyyy");
                mskTxtSentFinanceDeptForCommittment.Focus();
            }
            else
            {
                dtpRcvdFromFinanceDeptForCommittment.Value = dtpSentFinanceDeptForCommittment.Value.AddDays(1);
            }
        }

        private void dtpRcvdFromFinanceDeptForCommittment_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                dtpRcvdFromFinanceDeptForCommittment.CustomFormat = "dd/MMM/yyyy";
                if (mskTxtSentFinanceDeptForCommittment.Text.Trim() != "" && mskTxtRcvdFromFinanceDeptForCommittment.Text.Trim() == "")
                {
                    dtpRcvdFromFinanceDeptForCommittment.Value = Convert.ToDateTime(mskTxtSentFinanceDeptForCommittment.Text.ToString()).AddDays(1);
                }
                mskTxtRcvdFromFinanceDeptForCommittment.Text = dtpRcvdFromFinanceDeptForCommittment.Value.ToString("dd/MMM/yyyy");
                mskTxtRcvdFromFinanceDeptForCommittment.Focus();                
            }
            else
            {
                dtpDistribution.Value = dtpRcvdFromFinanceDeptForCommittment.Value.AddDays(1);
            }
        }

        private void dtpDistribution_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                dtpDistribution.CustomFormat = "dd/MMM/yyyy";
                if (mskTxtRcvdFromFinanceDeptForCommittment.Text.Trim() != "" && mskTxtDistribution.Text.Trim() == "")
                {
                    dtpDistribution.Value = Convert.ToDateTime(mskTxtRcvdFromFinanceDeptForCommittment.Text.ToString()).AddDays(1);
                }
                mskTxtDistribution.Text = dtpDistribution.Value.ToString("dd/MMM/yyyy");
                mskTxtDistribution.Focus();
            }
            else
            {
                isProgrammaticEvent = false;
            }
        }

        private void btnCancelWO_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnDeleteWO_Click(object sender, EventArgs e)
        {
            if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
            {
                if (mUserRightsColl.Contains("83"))
                {
                    MessageBox.Show("Do not have access rights to delete Work Orders, Please contact Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }

            DialogResult dlgResult = DialogResult.Yes;
            dlgResult = MessageBox.Show(" Are you sure you want to DELETE the Work Order?", "Delete Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (dlgResult.ToString() == "Yes")
            {
                string sqlUpdate = "Delete from WorkOrders where workOrderID = @workOrderID";
                using (SqlConnection sqlCn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                {
                    sqlCn.Open();
                    using (SqlCommand sqlCmd = new SqlCommand(sqlUpdate, sqlCn))
                    {
                        sqlCmd.Parameters.AddWithValue("@workOrderID", mWorkOrderID);                         
                        
                        if(sqlCmd.ExecuteNonQuery()==0)
                            MessageBox.Show("Did not found Work order details. Work order details not deleted successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show("Work order details deleted successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    sqlCn.Close();                    
                    this.Close();
                    cmnCls.CreateWorkOrderGridViewColumns(mDgv, mPrjID,0);
                }   
         
            }
        }

        private void txtContractAmt_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }

        private bool nonNumberEntered = false;
        private void ValidateNumericAndDecimalInput(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != 8 && e.KeyChar != 13) //&& e.KeyChar.ToString().Contains('.').ToString().Length>=2
            {
                nonNumberEntered = true;
            }
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                nonNumberEntered = true;
                e.Handled = true;
            }

            if (nonNumberEntered == true)
            {
                MessageBox.Show("Please enter number only...");                 
                e.Handled = true;
            }           
            nonNumberEntered = false;
        }

        private void txtContractAmt_Leave(object sender, EventArgs e)
        {
            if(txtWOAmount.Text.Trim()!="")
                txtWOAmount.Text = string.Format("{0:#,##0.00}", double.Parse(txtWOAmount.Text));
        }

        public int DateDiff()
        {
            DateTime startdate;
            DateTime enddate;
            TimeSpan remaindate;

            startdate = DateTime.Parse(System.DateTime.Now.ToString()).Date;
            enddate = DateTime.Parse(mskTxtWOClosingDate.Text.ToString()).Date;

            remaindate = enddate - startdate;

            return Convert.ToInt16(remaindate.TotalDays);
        }         

        private void txtNoOfEnvelopes_KeyPress(object sender, KeyPressEventArgs e)
        {                        
                ValidateNumericAndDecimalInput(sender, e);                       
        }

        private void dtpWOClosingDate_ValueChanged(object sender, EventArgs e)
        {
            if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
            {
                if (mUserRightsColl.Contains("75"))
                {
                    MessageBox.Show("Do not have access rights to Work Order Closing Date, Please contact Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            dtpWOClosingDate.CustomFormat = "dd/MMM/yyyy";
            mskTxtWOClosingDate.Text = dtpWOClosingDate.Value.ToString("dd/MMM/yyyy");
            mskTxtWOClosingDate.Focus();
            isProgrammaticEvent = true;
            dtpTenderOpenDate.Value = Convert.ToDateTime(mskTxtWOClosingDate.Text.ToString()).AddDays(1);             
        }

        bool isProgrammaticEvent = false;

        public class LastDateTimePicker : DateTimePicker
        {
            protected override void OnValueChanged(EventArgs eventargs)
            {
                base.OnValueChanged(eventargs);

                LastValue = Value;
                IsProgrammaticChange = false;
            }

            public DateTime? LastValue { get; private set; }
            public bool IsProgrammaticChange { get; private set; }

            public new DateTime Value
            {
                get { return base.Value; }
                set
                {
                    IsProgrammaticChange = true;
                    base.Value = value;
                }
            }
        }

        private void cmbCompany_SelectionChangeCommitted(object sender, EventArgs e)
        {            
            try
            {
                if (cmbCompany.SelectedItem != null)
                {                   
                    if (mContractId == cmbCompany.SelectedValue.ToString().Split(',')[0])
                        btnUpdateAndCloseWO.Text = "Update";
                    else
                        btnUpdateAndCloseWO.Text = "Save";
                    PopulateContractProcessDetails(cmbCompany.SelectedValue.ToString().Split(',')[0]);
                    txtWOAmount.Focus();                 
                    
                }
                else
                {
                    MessageBox.Show("Awarded Bidder cannot be left blank, Please select an Awarded Bidder.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    cmbCompany.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while checking the assignment of the selected company with a Work Order", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }            
        }

        private void ResetWOContractProcessDetails()
        {
            mskTxtWOAwardDate.Text = "";
            txtWOAmount.Text = "";
            mskTxtReqDeptStartDate.Text = "";
            mskTxtStartDateReceive.Text = "";
          
            mskTxtNoticeSendSignContract.Text = "";
           
            mskTxtDueDateOfSubPBSign.Text = "";
            
            mskTxtDateOfSignContract.Text = "";
             
            mskTxtSentDeptForSign.Text = "";
             
            mskTxtRcvdDeptSentPRSDForSign.Text = "";
             
            mskTxtSentFinanceDeptForCommittment.Text = "";
             
            mskTxtRcvdFromFinanceDeptForCommittment.Text = "";
             
            mskTxtDistribution.Text = "";
             
            txtContractNo.Text = "";
             
            textRemarks.Text = "";
        }

        private void PopulateContractProcessDetails(string contractorID)
        {
            SqlConnection sqlConn = null;
            SqlDataReader sqlDtReader = null;

            try
            {
                using (sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                {
                    if (sqlConn.State == ConnectionState.Closed)
                        sqlConn.Open();

                    SqlCommand sqlCmd = new SqlCommand("select CONTRACTORS.cp_request_start_date,CONTRACTORS.cp_start_date_receive,CONTRACTORS.cp_notice_contractor_to_sign,CONTRACTORS.cp_due_date_pb,CONTRACTORS.cp_contractor_sign," +
                    "CONTRACTORS.cp_sent_dep_sign,CONTRACTORS.cp_receive_dep_sent_prsd,CONTRACTORS.cp_sent_fd_commit,CONTRACTORS.cp_receive_fd_commit,CONTRACTORS.cp_distribution,CONTRACTORS.contract_no,CONTRACTORS.remarks,CONTRACTORS.ContractAmount," +
                    "CONTRACTORS.cp_tender_award,CONTRACTORS.cp_received_of_doc from CONTRACTORS join WorkOrders on CONTRACTORS.bidder_Id=WorkOrders.bidder_Id where CONTRACTORS.bidder_id=" + contractorID + " and CONTRACTORS.stage_id=6", sqlConn);

                    sqlDtReader = sqlCmd.ExecuteReader();
                    if (sqlDtReader.Read())
                    {
                        if (sqlDtReader["cp_tender_award"].ToString() != "")
                            mskTxtWOAwardDate.Text = Convert.ToDateTime(sqlDtReader["cp_tender_award"]).ToString("dd/MMM/yyyy");
                        if (sqlDtReader["ContractAmount"].ToString() != "")
                            txtWOAmount.Text = string.Format("{0:#,##0.00}", double.Parse(sqlDtReader["ContractAmount"].ToString()));
                        if (sqlDtReader["cp_received_of_doc"].ToString() != "")
                            mskTxtRecOfAwardDoc.Text = Convert.ToDateTime(sqlDtReader["cp_received_of_doc"]).ToString("dd/MMM/yyyy");
                        if (sqlDtReader["cp_request_start_date"] != DBNull.Value)
                            mskTxtReqDeptStartDate.Text = Convert.ToDateTime(sqlDtReader["cp_request_start_date"]).ToString("dd/MMM/yyyy");
                        if (sqlDtReader["cp_start_date_receive"] != DBNull.Value)
                            mskTxtStartDateReceive.Text = Convert.ToDateTime(sqlDtReader["cp_start_date_receive"]).ToString("dd/MMM/yyyy");
                        if (sqlDtReader["cp_notice_contractor_to_sign"] != DBNull.Value)
                            mskTxtNoticeSendSignContract.Text = Convert.ToDateTime(sqlDtReader["cp_notice_contractor_to_sign"]).ToString("dd/MMM/yyyy");
                        if (sqlDtReader["cp_due_date_pb"] != DBNull.Value)
                            mskTxtDueDateOfSubPBSign.Text = Convert.ToDateTime(sqlDtReader["cp_due_date_pb"]).ToString("dd/MMM/yyyy");
                        if (sqlDtReader["cp_contractor_sign"] != DBNull.Value)
                            mskTxtDateOfSignContract.Text = Convert.ToDateTime(sqlDtReader["cp_contractor_sign"]).ToString("dd/MMM/yyyy");
                        if (sqlDtReader["cp_sent_dep_sign"] != DBNull.Value)
                            mskTxtSentDeptForSign.Text = Convert.ToDateTime(sqlDtReader["cp_sent_dep_sign"]).ToString("dd/MMM/yyyy");
                        if (sqlDtReader["cp_receive_dep_sent_prsd"] != DBNull.Value)
                            mskTxtRcvdDeptSentPRSDForSign.Text = Convert.ToDateTime(sqlDtReader["cp_receive_dep_sent_prsd"]).ToString("dd/MMM/yyyy");
                        if (sqlDtReader["cp_sent_fd_commit"] != DBNull.Value)
                            mskTxtSentFinanceDeptForCommittment.Text = Convert.ToDateTime(sqlDtReader["cp_sent_fd_commit"]).ToString("dd/MMM/yyyy");
                        if (sqlDtReader["cp_receive_fd_commit"] != DBNull.Value)
                            mskTxtRcvdFromFinanceDeptForCommittment.Text = Convert.ToDateTime(sqlDtReader["cp_receive_fd_commit"]).ToString("dd/MMM/yyyy");
                        if (sqlDtReader["cp_distribution"] != DBNull.Value)
                            mskTxtDistribution.Text = Convert.ToDateTime(sqlDtReader["cp_distribution"]).ToString("dd/MMM/yyyy");
                        if (sqlDtReader["contract_no"] != DBNull.Value)
                            txtContractNo.Text = sqlDtReader["contract_no"].ToString();
                        if (sqlDtReader["remarks"] != DBNull.Value)
                            textRemarks.Text = sqlDtReader["remarks"].ToString();
                    }
                    else
                        ResetWOContractProcessDetails();                                             
                     
                    sqlDtReader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception occurred while displaying the Work Order", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlConn.Close();
            }
        }
         
        private void dtpWOAwardDate_ValueChanged(object sender, EventArgs e)
        {
            if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
            {
                if (mUserRightsColl.Contains("78"))
                {
                    MessageBox.Show("You do not have permission to Edit Award Date of Work Orders, Please contact the head of section", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            if (!isProgrammaticEvent)
            {
                dtpWOAwardDate.CustomFormat = "dd/MMM/yyyy";
                if (mskTxtTenderAwardApprovalDate.Text.Trim() != "" && mskTxtWOAwardDate.Text.Trim() == "")
                {
                    dtpWOAwardDate.Value = Convert.ToDateTime(mskTxtTenderAwardApprovalDate.Text.ToString()).AddDays(1);
                }
                mskTxtWOAwardDate.Text = dtpWOAwardDate.Value.ToString("dd/MMM/yyyy");
                mskTxtWOAwardDate.Focus();
            }
            else
            {
                dtpRecOfAwardDoc.Value = dtpWOAwardDate.Value.AddDays(1);                            
            }
        }

        private void txtWorkOrderNo_Leave(object sender, EventArgs e)
        {
            try
            {
                string sqlQuery = "select workOrderID from WorkOrders where workOrderNo='" + txtWorkOrderNo.Text.Replace("'","") + "'";
                SqlCommand sqlCmd = null;
                SqlDataReader sqlDtReader = null;
                using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                {
                    sqlConn.Open();
                    sqlCmd = new SqlCommand(sqlQuery, sqlConn);
                    sqlDtReader = sqlCmd.ExecuteReader();
                    if (sqlDtReader.Read())
                    {
                        MessageBox.Show("Entered Work Order Number already exists, please enter a unique Work Order Number", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtWorkOrderNo.Focus();
                    }
                    sqlDtReader.Close();
                    sqlConn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while checking existing Work Order Numbers", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }             
        }

        private void dtpRecOfAwardDoc_ValueChanged(object sender, EventArgs e)
        {
            if (!isProgrammaticEvent)
            {
                dtpRecOfAwardDoc.CustomFormat = "dd/MMM/yyyy";
                if (mskTxtWOAwardDate.Text.Trim() != "" && mskTxtRecOfAwardDoc.Text.Trim() == "")
                {
                    dtpRecOfAwardDoc.Value = Convert.ToDateTime(mskTxtWOAwardDate.Text.ToString()).AddDays(1);
                }
                mskTxtRecOfAwardDoc.Text = dtpRecOfAwardDoc.Value.ToString("dd/MMM/yyyy");
                mskTxtRecOfAwardDoc.Focus();
            }
            else
            {
                dtpReqDeptStartDate.Value = dtpRecOfAwardDoc.Value.AddDays(1);             
            }
        } 

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();   
        }

        private void dtpTenderOpenDate_ValueChanged(object sender, EventArgs e)
        {             
            if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
            {
                if (mUserRightsColl.Contains("75"))
                {
                    MessageBox.Show("Do not have access rights to Edit Tender Open Date of Work Order, Please contact Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            if (!isProgrammaticEvent)
            {
                dtpTenderOpenDate.CustomFormat = "dd/MMM/yyyy";
                if (mskTxtWOClosingDate.Text.Trim() != "" && mskTxtTenderOpenDate.Text.Trim() == "")
                {
                    dtpTenderOpenDate.Value = Convert.ToDateTime(mskTxtWOClosingDate.Text.ToString()).AddDays(1);
                }
                mskTxtTenderOpenDate.Text = dtpTenderOpenDate.Value.ToString("dd/MMM/yyyy");
                mskTxtTenderOpenDate.Focus();
                //isProgrammaticEvent = true;
            }
            else
            {
                dtpEvalReportDateSend.Value = dtpTenderOpenDate.Value.AddDays(1);
            }
        }

        private void dtpEvalReportDateSend_ValueChanged(object sender, EventArgs e)
        {

            if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
            {
                if (mUserRightsColl.Contains("75"))
                {
                    MessageBox.Show("Do not have access rights to Evaluation Report Date Send of Work Order, Please contact Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            if (!isProgrammaticEvent)
            {
                dtpEvalReportDateSend.CustomFormat = "dd/MMM/yyyy";
                if (mskTxtTenderOpenDate.Text.Trim() != "" && mskTxtEvalReportDateSend.Text.Trim() == "")
                {
                    dtpEvalReportDateSend.Value = Convert.ToDateTime(mskTxtTenderOpenDate.Text.ToString()).AddDays(1);
                }
                mskTxtEvalReportDateSend.Text = dtpEvalReportDateSend.Value.ToString("dd/MMM/yyyy");
                mskTxtEvalReportDateSend.Focus();
                //isProgrammaticEvent = true;
            }
            else
            {
                dtpEvalRepDateReceived.Value = dtpEvalReportDateSend.Value.AddDays(1);
            }           
        }     

        private void txtTechnoFinTotWorkdays_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }

        private void txtNoOfMeetings_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateNumericAndDecimalInput(sender, e);
        }

        private void dtpEvalRepDateReceived_ValueChanged(object sender, EventArgs e)
        {

            if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
            {
                if (mUserRightsColl.Contains("75"))
                {
                    MessageBox.Show("Do not have access rights to Edit Evaluation Report Date Received of Work Order, Please contact Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            
            if (!isProgrammaticEvent)
            {
                dtpEvalRepDateReceived.CustomFormat = "dd/MMM/yyyy";
                if (mskTxtEvalReportDateSend.Text.Trim() != "" && mskTxtEvalRepDateReceived.Text.Trim() == "")
                {
                    dtpEvalRepDateReceived.Value = Convert.ToDateTime(mskTxtEvalReportDateSend.Text.ToString()).AddDays(1);
                }
                mskTxtEvalRepDateReceived.Text = dtpEvalRepDateReceived.Value.ToString("dd/MMM/yyyy");
                mskTxtEvalRepDateReceived.Focus();
                //isProgrammaticEvent = true;
            }
            else
            {
                dtpTenderAwardApprovalDate.Value = dtpTenderOpenDate.Value.AddDays(1);
            }    
        }

        private void dtpTenderAwardApprovalDate_ValueChanged(object sender, EventArgs e)
        {

            if (mUserRightsColl.Count != 0 && mIsHeadOfSection == false)
            {
                if (mUserRightsColl.Contains("75"))
                {
                    MessageBox.Show("Do not have access rights to Edit Tender Award Approval Date of Work Order, Please contact Administrator", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            if (!isProgrammaticEvent)
            {
                dtpTenderAwardApprovalDate.CustomFormat = "dd/MMM/yyyy";
                if (mskTxtEvalRepDateReceived.Text.Trim() != "" && mskTxtTenderAwardApprovalDate.Text.Trim() == "")
                {
                    dtpTenderAwardApprovalDate.Value = Convert.ToDateTime(mskTxtEvalRepDateReceived.Text.ToString()).AddDays(1);
                }
                mskTxtTenderAwardApprovalDate.Text = dtpTenderAwardApprovalDate.Value.ToString("dd/MMM/yyyy");
                mskTxtTenderAwardApprovalDate.Focus();
                //isProgrammaticEvent = true;
            }
            else
            {
                dtpWOAwardDate.Value = dtpTenderAwardApprovalDate.Value.AddDays(1);
            }        
        }       
    }
}
