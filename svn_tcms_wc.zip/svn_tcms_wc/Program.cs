﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using TenderTrackingSystem;
using MDI_ParenrForm.Admin;
using MDI_ParenrForm;
using MDI_ParenrForm.Reports;
using System.IO;
using System.Data.SqlClient;


namespace MDI_ParenrForm
{
    static class Program
    {
        // public static string dbPath = @"Data Source=\SQLEXPRESS;Initial Catalog=master;Integrated Security=True";
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.CreateSpecificCulture("en-US");
            System.Threading.Thread.CurrentThread.CurrentUICulture = System.Threading.Thread.CurrentThread.CurrentCulture;
            Application.EnableVisualStyles();
 

            // Application.Run(new TenderTrackingSystem.TenderTrackingSystem());

            // Application.Run(new frmLoginUser());

            //Application.Run(new TMS_MainView("ebsd_svadakapuram"));  //DefaultView.cs

            //  Application.Run(new TMS_MainView("Admin1"));  //DefaultView.cs

            // Application.Run(new dashBoardParent("ebsd_svadakapuram"));  //DefaultView.cs

            //Application.Run(new DefaultView("Admin"));

            //Application.Run(new frmUserLogin());

            try
            {
                // Added by Varun on 07/Jun/15
                //string[] files = System.IO.Directory.GetFiles(Path.GetTempFileName().Substring(0, Path.GetTempFileName().LastIndexOf('\\')).ToString(), "*Tender*.pdf");                 

                //foreach (string file in files)
                //{
                //    System.IO.File.Delete(file);
                //}

                //files = System.IO.Directory.GetFiles(Path.GetTempFileName().Substring(0, Path.GetTempFileName().LastIndexOf('\\')).ToString(), "*GTC*.pdf");

                //foreach (string file in files)
                //{
                //    System.IO.File.Delete(file);
                //}

                //files = System.IO.Directory.GetFiles(Path.GetTempFileName().Substring(0, Path.GetTempFileName().LastIndexOf('\\')).ToString(), "*ITC*.pdf");

                //foreach (string file in files)
                //{
                //    System.IO.File.Delete(file);
                //}

                //files = System.IO.Directory.GetFiles(Path.GetTempFileName().Substring(0, Path.GetTempFileName().LastIndexOf('\\')).ToString(), "*MRPSC*.pdf");

                //foreach (string file in files)
                //{
                //    System.IO.File.Delete(file);
                //}

                //files = System.IO.Directory.GetFiles(Path.GetTempFileName().Substring(0, Path.GetTempFileName().LastIndexOf('\\')).ToString(), "*STC*.pdf");

                //foreach (string file in files)
                //{
                //    System.IO.File.Delete(file);
                //}

                //files = System.IO.Directory.GetFiles(Path.GetTempFileName().Substring(0, Path.GetTempFileName().LastIndexOf('\\')).ToString(), "*WPC*.pdf");

                //foreach (string file in files)
                //{
                //    System.IO.File.Delete(file);
                //}

                //files = System.IO.Directory.GetFiles(Path.GetTempFileName().Substring(0, Path.GetTempFileName().LastIndexOf('\\')).ToString(), "*EUWC*.pdf");

                //foreach (string file in files)
                //{
                //    System.IO.File.Delete(file);
                //}

                //files = System.IO.Directory.GetFiles(Path.GetTempFileName().Substring(0, Path.GetTempFileName().LastIndexOf('\\')).ToString(), "*NC*.pdf");

                //foreach (string file in files)
                //{
                //    System.IO.File.Delete(file);
                //}
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception occurred while deleting the pdf files from " + Path.GetTempFileName().Substring(0, Path.GetTempFileName().LastIndexOf('\\')).ToString() + " location. Please close all TCMS related opened pdf files.",
                "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new frmSwitchUser()); //  Form1 frmSwitchUser
            Application.Run(new frmSwitchUser()); //  Form2, frmSwitchUser 

            //Application.Run(new Form1());

            //Application.Run(new dashBoardParent("Admin"));

            // Application.Run(new Form1());            

            //Application.Run(new WindowsFormsApplication1.Form1());
 
 
        }

       
    }
}
