﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Windows.Forms;
using TenderTrackingSystem;
using System.Drawing;

namespace MDI_ParenrForm
{
    class clsPostContract_Stage
    {
        string _userName = string.Empty;
        public clsPostContract_Stage(string user)
        {
            _userName = user;
        }
        string connStr = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();
        public void refreshPCContracts_Data(DataGridView dgvPC_Contracts, int pc_prjID)
        {
            BindingSource myBindingSource = null;
            SqlConnection sqlConn = null;
            try
            {
                DataTable finalDt = new DataTable("ContractorsInfo");
                finalDt.Columns.Add("Company");
                finalDt.Columns.Add("Type");
                finalDt.Columns.Add("ContractNo");
                finalDt.Columns.Add("ContractTitle");
                finalDt.Columns.Add("ContractStartDate");
                finalDt.Columns.Add("ContractEndDate");
                finalDt.Columns.Add("PerfomenseBondExpiryDate");
                finalDt.Columns.Add("ContractStatus");
                finalDt.Columns.Add("bidID");
                finalDt.Columns.Add("co_id");

                sqlConn = new SqlConnection(connStr);
                sqlConn.Open();

                  string sqlQuery = "SELECT CONTRACTORS.bidder_id, CONTRACTORS.proj_id, CONTRACTORS.contract_no, CONTRACTORS.[ContractTitle], CONTRACTORS.StartDate, " +
                  " CONTRACTORS.FinishDate, CONTRACTORS.[PB_Expiry_Date], COMPANY.co_name, COMPANY_TYPE.co_type_name, " +
                  " [ContractStatus].[ContractStatus],COMPANY.co_id FROM CONTRACTORS INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN " +
                  " COMPANY_TYPE ON COMPANY.co_type_id = COMPANY_TYPE.co_type_id INNER JOIN [ContractStatus] ON CONTRACTORS.contract_status_id = [ContractStatus].contract_status_id " +
                  " WHERE  (CONTRACTORS.proj_id = " + pc_prjID + " and CONTRACTORS.stage_Id=4 and CONTRACTORS.cp_tender_award IS NOT NULL) or (CONTRACTORS.proj_id = " + pc_prjID + " and CONTRACTORS.stage_Id=6 and CONTRACTORS.cp_tender_award IS NOT NULL)";
                
                finalDt.AcceptChanges();
                SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
                SqlDataReader sqlReader = sqlCom.ExecuteReader();
                while (sqlReader.Read())
                {
                    DataRow dr = finalDt.NewRow();
                    // dr[0] = sqlReader[0].ToString();

                    dr[0] = sqlReader[7].ToString();           // CmpName
                    dr[1] = sqlReader[8].ToString();           // Type

                    dr[2] = sqlReader[2].ToString();
                    dr[3] = sqlReader[3].ToString();

                    if (sqlReader[4].ToString() != "")
                    {
                        dr[4] = Convert.ToDateTime(sqlReader[4]).ToString("dd/MMM/yyyy");     // StartDate   
                    }
                    if (sqlReader[5].ToString() != "")
                    {
                        dr[5] = Convert.ToDateTime(sqlReader[5]).ToString("dd/MMM/yyyy");
                    }
                    if (sqlReader[6].ToString() != "")
                    {
                        dr[6] = Convert.ToDateTime(sqlReader[6]).ToString("dd/MMM/yyyy");
                    }

                    dr[7] = sqlReader[9].ToString();
                    dr[8] = Convert.ToInt16(sqlReader[0]).ToString();
                    dr[9] = sqlReader[10].ToString();

                    finalDt.Rows.Add(dr);
                    finalDt.AcceptChanges();
                }
                sqlReader.Close();
                myBindingSource = new BindingSource(finalDt, null);
                dgvPC_Contracts.DataSource = myBindingSource;
                dgvPC_Contracts.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                dgvPC_Contracts.Columns[5].DefaultCellStyle.Format = "dd/MMM/yyy";
                dgvPC_Contracts.Columns[8].Visible = false;
                dgvPC_Contracts.Columns[9].Visible = false;

            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }
        }
        public void FillPostContractInformation(DataGridView dgvPC_Contracts,int PC_prjID)
        {
            //modified my Varun on 30 Jan 14 based on req. from Sridher
            var col1 = new DataGridViewLinkColumn();
            var col2 = new DataGridViewTextBoxColumn();
            var col3 = new DataGridViewTextBoxColumn();
            var col4 = new DataGridViewTextBoxColumn();
            var col5 = new CalendarColumn();
            var col6 = new CalendarColumn();
            var col7 = new DataGridViewTextBoxColumn();
            var col8 = new DataGridViewTextBoxColumn();
            var col9 = new DataGridViewTextBoxColumn();
            var col10 = new DataGridViewTextBoxColumn();


            dgvPC_Contracts.Visible = true;
            dgvPC_Contracts.AutoGenerateColumns = false;
            dgvPC_Contracts.AllowUserToAddRows = false;
            dgvPC_Contracts.AutoResizeColumns();

            //dgvPC_Contracts.Columns.AddRange(new DataGridViewColumn[] { col1, col2, col3, col4, col5, col6, col7, col8, col9, col10 });
            col1.DataPropertyName = "Company";
            col1.HeaderText = "Choosen Contractor/Vendor";
            //col1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            col1.Width = 100;
            dgvPC_Contracts.Columns.Add(col1);

            col2.DataPropertyName = "Type";
            col2.HeaderText = "Type Of Company";
            //col2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            col2.Width = 80;
            dgvPC_Contracts.Columns.Add(col2);

            col3.DataPropertyName = "ContractNo";
            col3.HeaderText = "Contract No";
            col3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            col3.Width = 90;
            dgvPC_Contracts.Columns.Add(col3);

            col4.DataPropertyName = "ContractTitle";
            col4.HeaderText = "Contract Title";
            // col4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            col4.Width = 180;
            dgvPC_Contracts.Columns.Add(col4);
            //dgvContracts.Columns.Add(colCboxCategory3);
                        
            col5.DataPropertyName = "ContractStartDate";
            col5.HeaderText = "Contract Start Date";             
            col5.Width = 80;
            col5.DefaultCellStyle.Format = "dd/MMMM/yyyy";             
            dgvPC_Contracts.Columns.Add(col5);

            col6.DataPropertyName = "ContractEndDate";
            col6.HeaderText = "Contract Finish Date";
            col6.Width = 80;
            col6.DefaultCellStyle.Format = "dd/MMMM/yyyy";
            dgvPC_Contracts.Columns.Add(col6);

            col7.DataPropertyName = "PerformenseBondExpiryDate";
            col7.HeaderText = "Performance Bond ExpiryDate";
            col7.Width = 80;
            col7.DefaultCellStyle.Format = "dd/MMMM/yyyy";
            dgvPC_Contracts.Columns.Add(col7);

            col8.DataPropertyName = "ContractStatus";
            col8.HeaderText = "Contract Status";
            col8.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            dgvPC_Contracts.Columns.Add(col8);

            col9.DataPropertyName = "BidID";
            col9.HeaderText = "BidID";
            col9.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            dgvPC_Contracts.Columns.Add(col9);

            col10.DataPropertyName = "co_id";
            col10.HeaderText = "co_id";
            col10.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            dgvPC_Contracts.Columns.Add(col10);

            

            dgvPC_Contracts.ColumnHeadersDefaultCellStyle.BackColor = Color.Gainsboro;
            dgvPC_Contracts.ColumnHeadersDefaultCellStyle.ForeColor = Color.Chocolate;             
            dgvPC_Contracts.ColumnHeadersDefaultCellStyle.Font = new Font(dgvPC_Contracts.Font, FontStyle.Regular);
            dgvPC_Contracts.EnableHeadersVisualStyles = false;
            dgvPC_Contracts.DefaultCellStyle.WrapMode = DataGridViewTriState.True;

            refreshPCContracts_Data(dgvPC_Contracts, PC_prjID);
            //BindingSource myBindingSource = null;
            ////SqlConnection sqlConn = null;
            //try
            //{
            //    DataTable finalDt = null; // = new DataTable("ContractorsInfo");

            //    //finalDt.Columns.Add("Company");
            //    //finalDt.Columns.Add("Type");
            //    //finalDt.Columns.Add("ContractNo");
            //    //finalDt.Columns.Add("ContractTitle");
            //    //finalDt.Columns.Add("ContractStartDate");
            //    //finalDt.Columns.Add("ContractEndDate");
            //    //finalDt.Columns.Add("PerformenseBondExpiryDate");
            //    //finalDt.Columns.Add("ContractStatus");
            //    //finalDt.Columns.Add("BidID");
            //    //finalDt.Columns.Add("co_id");
                
            //    //sqlConn = new SqlConnection(connStr);
            //    //sqlConn.Open();
            //    DAL dalObj = new DAL();

            //    string sqlQuery = "SELECT COMPANY.co_name As Company, COMPANY_TYPE.co_type_name As Type,CONTRACTORS.contract_no As ContractNo, CONTRACTORS.[ContractTitle], Replace(Convert(nvarchar,CONTRACTORS.StartDate,106),' ','/') As ContractStartDate, " +
            //    " Replace(Convert(nvarchar,CONTRACTORS.FinishDate,106),' ','/') As ContractEndDate, Replace(Convert(nvarchar,CONTRACTORS.[PB_Expiry_Date],106),' ','/') As PerformenseBondExpiryDate " +
            //    " [ContractStatus].[ContractStatus],CONTRACTORS.bidder_id As BidID,COMPANY.co_id FROM CONTRACTORS INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN " +
            //    " COMPANY_TYPE ON COMPANY.co_type_id = COMPANY_TYPE.co_type_id INNER JOIN [ContractStatus] ON CONTRACTORS.contract_status_id = [ContractStatus].contract_status_id " +
            //    " WHERE (CONTRACTORS.stage_Id=4 or CONTRACTORS.stage_Id=6) and (CONTRACTORS.proj_id = " + PC_prjID + " and CONTRACTORS.cp_tender_award IS NOT NULL)";
            //    finalDt = dalObj.GetDataFromDB("ContractorsInfo", sqlQuery);
            //    //finalDt.AcceptChanges();
            //    //SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            //    //SqlDataReader sqlReader = sqlCom.ExecuteReader();
            //    //while (sqlReader.Read())
            //    //{
            //    //    DataRow dr = finalDt.NewRow();
            //    //    // dr[0] = sqlReader[0].ToString();

            //    //    dr[0] = sqlReader[7].ToString();           // CmpName
            //    //    dr[1] = sqlReader[8].ToString();           // Type

            //    //    dr[2] = sqlReader[2].ToString(); 
            //    //    dr[3] = sqlReader[3].ToString();

            //    //    if (sqlReader[4].ToString() != "")
            //    //    {
            //    //        dr[4] = Convert.ToDateTime(sqlReader[4]).ToString("dd/MMM/yyyy");     // StartDate   
            //    //    }
            //    //    if (sqlReader[5].ToString() != "")
            //    //    {
            //    //        dr[5] = Convert.ToDateTime(sqlReader[5]).ToString("dd/MMM/yyyy");
            //    //    }
            //    //    if (sqlReader[6].ToString() != "")
            //    //    {
            //    //        dr[6] = Convert.ToDateTime(sqlReader[6]).ToString("dd/MMM/yyyy");
            //    //    }

            //    //    dr[7] = sqlReader[9].ToString();
            //    //    dr[8] = Convert.ToInt16(sqlReader[0]).ToString();
            //    //    dr[9] = sqlReader[10].ToString();

            //    //    finalDt.Rows.Add(dr);
            //    //    finalDt.AcceptChanges();
            //    //}
            //    //sqlReader.Close();
            //    myBindingSource = new BindingSource(finalDt, null);
            //    dgvPC_Contracts.DataSource = myBindingSource;
            //    dgvPC_Contracts.Columns[5].DefaultCellStyle.Format = "dd/MMM/yyy";
            //    dgvPC_Contracts.Columns[8].Visible = false;
            //    dgvPC_Contracts.Columns[9].Visible = false;
            //}
            //catch (Exception ex)
            //{
            //    string exMsg = ex.Message;
            //}
            //finally
            //{
            //    //sqlConn.Close();
            //}
        }
        public void CreatePostContractGridColumns(DataGridView dgvPC)
        {
            DataSet ds = new DataSet();
            string strQuery = "";
            strQuery = "Select employee_id,ShortName From Contacts where shortname is not null order by shortname asc";
            try
            {
                using (SqlConnection sqlCn = new SqlConnection(connStr))
                {
                    sqlCn.Open();
                    using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                    {
                        SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                        sqlda.Fill(ds);

                        DataTable data = new DataTable();
                        data.Columns.Add(new DataColumn("Value", typeof(int)));
                        data.Columns.Add(new DataColumn("Description", typeof(string)));
                        for (int l = 0; l < ds.Tables[0].Rows.Count; l++)
                        {
                            data.Rows.Add(ds.Tables[0].Rows[l][0].ToString(), ds.Tables[0].Rows[l][1].ToString());
                        }

                        DataGridViewComboBoxColumn colCboxCategory = new DataGridViewComboBoxColumn();
                        colCboxCategory.HeaderText = "Staff Incharge";
                        colCboxCategory.Name = "colBoc";
                        colCboxCategory.DataSource = data;
                        colCboxCategory.ValueMember = "Value";
                        colCboxCategory.DisplayMember = "Description";
                        dgvPC.Columns.Add(colCboxCategory);

                        CalendarColumn colFromDate = new CalendarColumn();
                        colFromDate.HeaderText = "From Date";
                        colFromDate.Width = 50;
                        dgvPC.Columns.Add(colFromDate);

                        CalendarColumn colTodDate = new CalendarColumn();
                        colTodDate.HeaderText = "To Date";
                        colTodDate.Width = 50;
                        dgvPC.Columns.Add(colTodDate);

                        DataGridViewTextBoxColumn colCboxRemarks = new DataGridViewTextBoxColumn();
                        colCboxRemarks.HeaderText = "Remarks";
                        colCboxRemarks.Name = "colBoc";
                        dgvPC.Columns.Add(colCboxRemarks);
                       
                        dgvPC.ColumnHeadersDefaultCellStyle.BackColor = Color.Gainsboro;
                        dgvPC.ColumnHeadersDefaultCellStyle.ForeColor = Color.Chocolate;
                        dgvPC.ColumnHeadersDefaultCellStyle.Font = new Font(dgvPC.Font, FontStyle.Regular);
                        dgvPC.EnableHeadersVisualStyles = false;
                        dgvPC.DefaultCellStyle.WrapMode = DataGridViewTriState.True;

                    }
                }
            }
            catch (Exception ex)
            {

            }
        }
        public void FillPostContractsData(DataGridView dgvPC,int pc_PrjID)
        {
            DataSet ds1 = new DataSet();
            string strQuery1 = "";
            strQuery1 = "Select employee_id,FromDate,ToDate,remarks From TenderDatesInfo Where Proj_ID = " + pc_PrjID + " and Stage_ID= 6 and employee_id IS NOT NULL";
            try
            {
                using (SqlConnection sqlCn = new SqlConnection(connStr))
                {
                    sqlCn.Open();
                    using (SqlCommand sqlCmd = new SqlCommand(strQuery1, sqlCn))
                    {
                        SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                        sqlda.Fill(ds1);
                    }
                }
            }
            catch (Exception ex)
            {

            }


            dgvPC.AllowUserToAddRows = false;
            dgvPC.Columns[0].DataPropertyName = "employee_id";
            dgvPC.Columns[1].DataPropertyName = "FromDate";
            dgvPC.Columns[2].DataPropertyName = "ToDate";
            dgvPC.Columns[3].DataPropertyName = "remarks";

            //  dataGridView1.Columns[3].DataPropertyName = "bidder_id";
            if(ds1.Tables[0].Rows.Count!=0)
                dgvPC.DataSource = ds1.Tables[0];
            else
                dgvPC.DataSource = null;
            dgvPC.AllowUserToAddRows = true;

            

        }
    }
}
