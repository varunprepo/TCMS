﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Windows.Forms;
using TenderTrackingSystem;
using System.Drawing;
using MDI_ParenrForm;
using System.Text.RegularExpressions;

namespace MDI_ParenrForm
{
    class clsCP_Stage
    {
        DAL dalObj = new DAL();
      //  CommonClass cmnCls = new CommonClass("");
        string connStr = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();
        string _userName = string.Empty;
        bool mIsHeadOfSection = false;
        public clsCP_Stage(string user,bool isHeadOfSection)
        {
            _userName = user;
            mIsHeadOfSection = isHeadOfSection;
        }
        void dgvContracts_DataError(object sender, DataGridViewDataErrorEventArgs e)     //dgvContracts_DataError
        {
            e.Cancel = true;
        }            

        public void FillCP_ContractsData(DataGridView dgvContracts,int cp_prjID)
        {
            string strQuery = null;
            //strQuery = "select co_id,co_type_id,ContractAmount as award ,cp_contractor_sign,contract_no,bidder_id from CONTRACTORS WHERE (proj_id = " + Convert.ToInt16(lblProjID.Text) + ") AND (stage_id = 4) ";

            strQuery = "SELECT CONTRACTORS.co_id, CONTRACTORS.co_type_id, CONTRACTORS.ContractAmount AS award,CONTRACTORS.cp_contractor_sign, CONTRACTORS.contract_no, " +
            " CONTRACTORS.bidder_id, COMPANY.co_name FROM CONTRACTORS INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id " +
            " WHERE (CONTRACTORS.proj_id = " + cp_prjID + ") AND (CONTRACTORS.stage_id = 4)";

            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                    DataSet ds = new DataSet();

                    dgvContracts.AllowUserToAddRows = false;
                    sqlda.Fill(ds);

                    dgvContracts.Columns[0].DataPropertyName = "co_id";   // co_id
                    dgvContracts.Columns[1].DataPropertyName = "co_type_id";
                    dgvContracts.Columns[2].DataPropertyName = "award";
                    dgvContracts.Columns[3].DataPropertyName = "cp_contractor_sign";
                    dgvContracts.Columns[4].DataPropertyName = "contract_no";
                    dgvContracts.Columns[5].DataPropertyName = "bidder_id";
                    dgvContracts.DataSource = ds.Tables[0];
                    dgvContracts.AllowUserToAddRows = true;
                }
                sqlCn.Close();
            }
            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                    DataSet ds = new DataSet();
                    sqlda.Fill(ds);
                    dgvContracts.AllowUserToAddRows = false;
                    sqlda.Fill(ds);

                    dgvContracts.Columns[0].DataPropertyName = "co_id";   // co_id
                    dgvContracts.Columns[1].DataPropertyName = "co_type_id";
                    dgvContracts.Columns[2].DataPropertyName = "award";
                    dgvContracts.Columns[3].DataPropertyName = "cp_contractor_sign";
                    dgvContracts.Columns[4].DataPropertyName = "contract_no";
                    dgvContracts.Columns[5].DataPropertyName = "bidder_id";
                    dgvContracts.DataSource = ds.Tables[0];
                    dgvContracts.AllowUserToAddRows = true;
                }
                sqlCn.Close();
            }
            try
            {
                for (int i = 0; i < dgvContracts.Rows.Count; i++)
                {
                    if (i == (dgvContracts.Rows.Count - 1))
                    {
                        dgvContracts.Rows[i].Cells[3].Value = "";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void createCompanyColumn(DataGridView dgvCpDataEntry)
        {
            DataSet ds2 = new DataSet();
            string strQuery = "";

            //strQuery = "select employee_id,shortname as staff from Contacts where shortname is not null order by employee_id asc"; //   WHERE (b.proj_id = " + Convert.ToInt16(lblProjID.Text) + ") AND (b.stage_id = 4) ";

            strQuery = "select shortname as staff from Contacts where shortname <>'' order by employee_id asc"; //   WHERE (b.proj_id = " + Convert.ToInt16(lblProjID.Text) + ") AND (b.stage_id = 4) ";
            try
            {
                using (SqlConnection sqlCn = new SqlConnection(connStr))
                {
                    sqlCn.Open();
                    using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                    {
                        SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                        sqlda.Fill(ds2);

                        CalendarColumn colCboxCategory1 = new CalendarColumn();
                        colCboxCategory1.HeaderText = "Sent to Dept For Signature";
                        colCboxCategory1.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory1);

                        CalendarColumn colCboxCategory2 = new CalendarColumn();
                        colCboxCategory2.HeaderText = "Rcvd from Dept and Sent to PRSD Sign";
                        colCboxCategory2.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory2);

                        CalendarColumn colCboxCategory3 = new CalendarColumn();
                        colCboxCategory3.HeaderText = "Sent To Fin Dept for Commitment";
                        colCboxCategory3.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory3);

                        CalendarColumn colCboxCategory4 = new CalendarColumn();
                        colCboxCategory4.HeaderText = "Received From Finance Dept";
                        colCboxCategory4.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory4);

                        CalendarColumn colCboxCategory5 = new CalendarColumn();
                        colCboxCategory5.HeaderText = "Distribution";
                        colCboxCategory5.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory5);

                        DataGridViewTextBoxColumn colCboxCategory6 = new DataGridViewTextBoxColumn();
                        colCboxCategory6.Name = "abc";
                        colCboxCategory6.HeaderText = "Remarks";
                        colCboxCategory6.Width = 200;
                        dgvCpDataEntry.Columns.Add(colCboxCategory6);

                        var column = new DataGridViewComboBoxColumn();
                        DataTable data = new DataTable();

                        // data.Columns.Add(new DataColumn("Value", typeof(int)));
                        //data.Columns.Add(new DataColumn("Value", typeof(string)));
                        data.Columns.Add(new DataColumn("Description", typeof(string)));
                        for (int l = 0; l < ds2.Tables[0].Rows.Count; l++)
                        {
                            // data.Rows.Add(ds2.Tables[0].Rows[l][0].ToString(), ds2.Tables[0].Rows[l][1].ToString());

                            data.Rows.Add(ds2.Tables[0].Rows[l][0].ToString());
                        }

                        column.DataSource = data;
                        //column.ValueMember = "Value";
                        column.DisplayMember = "Description";
                        column.HeaderText = "Staff Incharge";
                        dgvCpDataEntry.Columns.Add(column);

                        DataGridViewTextBoxColumn colCboxCategory7 = new DataGridViewTextBoxColumn();
                        colCboxCategory7.Name = "ColID";
                        colCboxCategory7.Visible = false;
                        colCboxCategory7.HeaderText = "ID";
                        dgvCpDataEntry.Columns.Add(colCboxCategory7);


                        CalendarColumn colCboxCategory8 = new CalendarColumn();
                        colCboxCategory8.HeaderText = "Received_of_doc,";
                        colCboxCategory8.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory8);

                        CalendarColumn colCboxCategory9 = new CalendarColumn();
                        colCboxCategory9.HeaderText = "Request StartDate,";
                        colCboxCategory9.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory9);

                        CalendarColumn colCboxCategory10 = new CalendarColumn();
                        colCboxCategory10.HeaderText = "StartDate Receive";
                        colCboxCategory10.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory10);

                        CalendarColumn colCboxCategory11 = new CalendarColumn();
                        colCboxCategory11.HeaderText = "Notice Contractor to Sign";
                        colCboxCategory11.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory11);

                        CalendarColumn colCboxCategory12 = new CalendarColumn();
                        colCboxCategory12.HeaderText = "Due_date_pb";
                        colCboxCategory12.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory12);

                        dgvCpDataEntry.ColumnHeadersDefaultCellStyle.BackColor = Color.Gainsboro;
                        dgvCpDataEntry.ColumnHeadersDefaultCellStyle.ForeColor = Color.Chocolate;

                        dgvCpDataEntry.ColumnHeadersDefaultCellStyle.Font = new Font(dgvCpDataEntry.Font, FontStyle.Regular);
                        dgvCpDataEntry.EnableHeadersVisualStyles = false;
                    }
                    sqlCn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void CreateColumnsForCP_MultiplerecordsDara(DataGridView dgvCpDataEntry)
        {
           // CreateColumnsForCompanyGrid(dgvCpDataEntry, 0);

            DataSet ds2 = new DataSet();
            string strQuery = "";

            //strQuery = "select employee_id,shortname as staff from Contacts where shortname is not null order by employee_id asc"; //   WHERE (b.proj_id = " + Convert.ToInt16(lblProjID.Text) + ") AND (b.stage_id = 4) ";

            strQuery = "select shortname as staff from Contacts where shortname is not null order by employee_id asc"; //   WHERE (b.proj_id = " + Convert.ToInt16(lblProjID.Text) + ") AND (b.stage_id = 4) ";
            try
            {
                using (SqlConnection sqlCn = new SqlConnection(connStr))
                {
                    sqlCn.Open();
                    using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                    {
                        SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                        sqlda.Fill(ds2);

                        DataGridViewTextBoxColumn colCboxCategoryBid = new DataGridViewTextBoxColumn();
                        colCboxCategoryBid.Name = "CompanyName";
                        colCboxCategoryBid.HeaderText = "Bidder Name";
                        colCboxCategoryBid.Width = 200;
                        dgvCpDataEntry.Columns.Add(colCboxCategoryBid);         


                        CalendarColumn colCboxCategory1 = new CalendarColumn();
                        colCboxCategory1.HeaderText = "Sent to Dept For Signature";
                        colCboxCategory1.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory1);

                        CalendarColumn colCboxCategory2 = new CalendarColumn();
                        colCboxCategory2.HeaderText = "Rcvd from Dept and Sent to PRSD Sign";
                        colCboxCategory2.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory2);

                        CalendarColumn colCboxCategory3 = new CalendarColumn();
                        colCboxCategory3.HeaderText = "Sent To Fin Dept for Commitment";
                        colCboxCategory3.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory3);

                        CalendarColumn colCboxCategory4 = new CalendarColumn();
                        colCboxCategory4.HeaderText = "Received From Finance Dept";
                        colCboxCategory4.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory4);

                        CalendarColumn colCboxCategory5 = new CalendarColumn();
                        colCboxCategory5.HeaderText = "Distribution";
                        colCboxCategory5.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory5);

                        DataGridViewTextBoxColumn colCboxCategory6 = new DataGridViewTextBoxColumn();
                        colCboxCategory6.Name = "abc";
                        colCboxCategory6.HeaderText = "Remarks";
                        colCboxCategory6.Width = 200;
                        dgvCpDataEntry.Columns.Add(colCboxCategory6);

                        var column = new DataGridViewComboBoxColumn();
                        DataTable data = new DataTable();

                        // data.Columns.Add(new DataColumn("Value", typeof(int)));
                        //data.Columns.Add(new DataColumn("Value", typeof(string)));
                        data.Columns.Add(new DataColumn("Description", typeof(string)));
                        for (int l = 0; l < ds2.Tables[0].Rows.Count; l++)
                        {
                            // data.Rows.Add(ds2.Tables[0].Rows[l][0].ToString(), ds2.Tables[0].Rows[l][1].ToString());

                            data.Rows.Add(ds2.Tables[0].Rows[l][0].ToString());
                        }

                        column.DataSource = data;
                        //column.ValueMember = "Value";
                        column.DisplayMember = "Description";
                        column.HeaderText = "Staff Incharge";
                        dgvCpDataEntry.Columns.Add(column);

                        DataGridViewTextBoxColumn colCboxCategory7 = new DataGridViewTextBoxColumn();
                        colCboxCategory7.Name = "ColID";
                        colCboxCategory7.Visible = false;
                        colCboxCategory7.HeaderText = "ID";
                        dgvCpDataEntry.Columns.Add(colCboxCategory7);


                        CalendarColumn colCboxCategory8 = new CalendarColumn();
                        colCboxCategory8.HeaderText = "Received_of_doc,";
                        colCboxCategory8.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory8);

                        CalendarColumn colCboxCategory9 = new CalendarColumn();
                        colCboxCategory9.HeaderText = "Request StartDate,";
                        colCboxCategory9.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory9);

                        CalendarColumn colCboxCategory10 = new CalendarColumn();
                        colCboxCategory10.HeaderText = "StartDate Receive";
                        colCboxCategory10.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory10);

                        CalendarColumn colCboxCategory11 = new CalendarColumn();
                        colCboxCategory11.HeaderText = "Notice Contractor to Sign";
                        colCboxCategory11.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory11);

                        CalendarColumn colCboxCategory12 = new CalendarColumn();
                        colCboxCategory12.HeaderText = "Due_date_pb";
                        colCboxCategory12.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory12);

                        DataGridViewTextBoxColumn colCboxCategory13 = new DataGridViewTextBoxColumn();
                        colCboxCategory13.Name = "BidID";
                        colCboxCategory13.Visible = false;
                        colCboxCategory13.HeaderText = "BidID";
                        dgvCpDataEntry.Columns.Add(colCboxCategory13);

                        dgvCpDataEntry.ColumnHeadersDefaultCellStyle.BackColor = Color.Gainsboro;
                        dgvCpDataEntry.ColumnHeadersDefaultCellStyle.ForeColor = Color.Chocolate;

                        dgvCpDataEntry.ColumnHeadersDefaultCellStyle.Font = new Font(dgvCpDataEntry.Font, FontStyle.Regular);
                        dgvCpDataEntry.EnableHeadersVisualStyles = false;
                    }
                    sqlCn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void FillCP_MultiplerecordsDara(DataGridView dgvCpDataEntry,int cp_PrjID)
        {
            if (dgvCpDataEntry.ColumnCount == 0)
                CreateColumnsForCP_MultiplerecordsDara(dgvCpDataEntry);

            string strQuery = "";
            strQuery = "SELECT COMPANY.co_name,TenderDatesInfo.cp_sent_dep_sign, TenderDatesInfo.cp_receive_dep_sent_prsd, TenderDatesInfo.cp_sent_fd_commit, " +
                       " TenderDatesInfo.cp_receive_fd_commit, TenderDatesInfo.cp_distribution, TenderDatesInfo.remarks, TenderDatesInfo.StaffInCharge AS staff, " +
                       " TenderDatesInfo.date_id, TenderDatesInfo.cp_received_of_doc, TenderDatesInfo.cp_request_start_date, TenderDatesInfo.cp_start_date_receive, " +
                       " TenderDatesInfo.cp_notice_contractor_to_sign, TenderDatesInfo.cp_due_date_pb, TenderDatesInfo.Tndr_BidID, TenderDatesInfo.Tndr_BidName " +
                       " FROM  TenderDatesInfo INNER JOIN COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id INNER JOIN " +
                       " CONTRACTORS ON TenderDatesInfo.Tndr_BidID = CONTRACTORS.bidder_id and TenderDatesInfo.stage_Id = CONTRACTORS.stage_Id WHERE (TenderDatesInfo.proj_id = " + cp_PrjID + " AND TenderDatesInfo.stage_id = 4 and CONTRACTORS.cp_tender_award<>Null)";

            //strQuery = "select cp_sent_dep_sign,cp_receive_dep_sent_prsd,cp_sent_fd_commit,cp_receive_fd_commit,cp_distribution,remarks," +
            //    " [StaffInCharge] as staff,date_id,cp_received_of_doc,cp_request_start_date,cp_start_date_receive,cp_notice_contractor_to_sign, " +
            //" cp_due_date_pb,Tndr_BidID,Tndr_BidName from TenderDatesInfo WHERE (proj_id = " + cp_PrjID + ") AND (stage_id = 4)";

            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                    DataSet ds = new DataSet();
                    sqlda.Fill(ds);
                    dgvCpDataEntry.AllowUserToAddRows = false;

                    dgvCpDataEntry.Columns[0].DataPropertyName = "Tndr_Bidname";
                    dgvCpDataEntry.Columns[1].DataPropertyName = "cp_sent_dep_sign";
                    dgvCpDataEntry.Columns[2].DataPropertyName = "cp_receive_dep_sent_prsd";
                    dgvCpDataEntry.Columns[3].DataPropertyName = "cp_sent_fd_commit";
                    dgvCpDataEntry.Columns[4].DataPropertyName = "cp_receive_fd_commit";
                    dgvCpDataEntry.Columns[5].DataPropertyName = "cp_distribution";
                    dgvCpDataEntry.Columns[6].DataPropertyName = "remarks";
                    dgvCpDataEntry.Columns[7].DataPropertyName = "staff";
                    dgvCpDataEntry.Columns[8].DataPropertyName = "date_id";

                    dgvCpDataEntry.Columns[9].DataPropertyName = "cp_received_of_doc";
                    dgvCpDataEntry.Columns[10].DataPropertyName = "cp_request_start_date";
                    dgvCpDataEntry.Columns[11].DataPropertyName = "cp_start_date_receive";
                    dgvCpDataEntry.Columns[12].DataPropertyName = "cp_notice_contractor_to_sign";
                    dgvCpDataEntry.Columns[13].DataPropertyName = "cp_due_date_pb";
                    dgvCpDataEntry.Columns[14].DataPropertyName = "Tndr_BidID";
                    
                    dgvCpDataEntry.DataSource = ds.Tables[0];
                    dgvCpDataEntry.AllowUserToAddRows = true;
                }
                sqlCn.Close();
            }

            dgvCpDataEntry.Columns[7].Visible = false;

            //using (SqlConnection sqlCn = new SqlConnection(connStr))
            //{
            //    sqlCn.Open();
            //    using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
            //    {
            //        SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
            //        DataSet ds = new DataSet();
            //        sqlda.Fill(ds);

            //        dgvCpDataEntry.AllowUserToAddRows = false;

            //        dgvCpDataEntry.Columns[0].DataPropertyName = "Tndr_Bidname";
            //        dgvCpDataEntry.Columns[1].DataPropertyName = "cp_sent_dep_sign";
            //        dgvCpDataEntry.Columns[2].DataPropertyName = "cp_receive_dep_sent_prsd";
            //        dgvCpDataEntry.Columns[3].DataPropertyName = "cp_sent_fd_commit";
            //        dgvCpDataEntry.Columns[4].DataPropertyName = "cp_receive_fd_commit";
            //        dgvCpDataEntry.Columns[5].DataPropertyName = "cp_distribution";
            //        dgvCpDataEntry.Columns[6].DataPropertyName = "remarks";
            //        dgvCpDataEntry.Columns[7].DataPropertyName = "staff";
            //        dgvCpDataEntry.Columns[8].DataPropertyName = "date_id";

            //        dgvCpDataEntry.Columns[9].DataPropertyName = "cp_received_of_doc";
            //        dgvCpDataEntry.Columns[10].DataPropertyName = "cp_request_start_date";
            //        dgvCpDataEntry.Columns[11].DataPropertyName = "cp_start_date_receive";
            //        dgvCpDataEntry.Columns[12].DataPropertyName = "cp_notice_contractor_to_sign";
            //        dgvCpDataEntry.Columns[13].DataPropertyName = "cp_due_date_pb";
            //        dgvCpDataEntry.Columns[14].DataPropertyName = "Tndr_BidID";
                    
            //        dgvCpDataEntry.DataSource = ds.Tables[0];
            //        dgvCpDataEntry.AllowUserToAddRows = true;
            //    }
            //    sqlCn.Close();
            //}
            try
            {
                for (int i = 0; i < dgvCpDataEntry.Rows.Count; i++)
                {
                    if (i == (dgvCpDataEntry.Rows.Count - 1))
                    {
                        dgvCpDataEntry.Rows[i].Cells[1].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[2].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[3].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[4].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[5].Value = "";

                       // dgvCpDataEntry.Rows[i].Cells[5].Value = "";

                        dgvCpDataEntry.Rows[i].Cells[7].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[8].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[9].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[10].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[11].Value = "";

                        dgvCpDataEntry.Rows[i].Cells[12].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[13].Value = "";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public Int16 maxValue(string str)
        {
            object max;
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                SqlCommand cmd = new SqlCommand(str, sqlConn);
                sqlConn.Open();
                max = cmd.ExecuteScalar();
            }
            return Convert.ToInt16(max);
        }

        public void UpdateTenderStatus_CP(int cp_prjID)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]= 5,[stage_id]= 4 Where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@projId", cp_prjID);
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE DATES records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }   
        }
        public void UpdateTenderStatus_CP_StartDateRequested(int cp_prjID)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]= 12,[stage_id]= 4 Where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@projId", cp_prjID);
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE DATES records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        public void UpdateTenderStatus_CP_NOAIssued(int cp_prjID)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]= 13 , [stage_id]= 4 Where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@projId", cp_prjID);
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE DATES records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        public void UpdateTenderStatus_CP_Contract_Signed(int cp_prjID)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]= 14 , [stage_id]= 4 Where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@projId", cp_prjID);
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE DATES records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        public void UpdateTenderStatus_CP_Signature_Processing(int cp_prjID)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]= 15 , [stage_id]= 4 Where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@projId", cp_prjID);
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE DATES records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        public void CreateColumnsForCompanyGrid(DataGridView dgvCntrStage3, int cp_PrjiD)
        {
            string strQuery = "";
            //strQuery = "SELECT Co_id,co_name FROM COMPANY where co_shortname is not null";

            strQuery = "SELECT COMPANY.co_id,COMPANY.co_name, TenderDatesInfo.proj_id FROM TenderDatesInfo INNER JOIN " +
                      " COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id WHERE (TenderDatesInfo.proj_id = " + cp_PrjiD + " and TenderDatesInfo.Tender_Issued=1)";
            try
            {
                using (SqlConnection sqlCn = new SqlConnection(connStr))
                {
                    sqlCn.Open();
                    using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                    {
                        SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                        DataSet ds = new DataSet();
                        sqlda.Fill(ds);

                        DataTable data = new DataTable();
                        data.Columns.Add(new DataColumn("Value", typeof(int)));
                        data.Columns.Add(new DataColumn("Description", typeof(string)));
                        for (int l = 0; l < ds.Tables[0].Rows.Count; l++)
                        {
                            data.Rows.Add(ds.Tables[0].Rows[l][0].ToString(), ds.Tables[0].Rows[l][1].ToString());
                        }

                        DataGridViewComboBoxColumn colCboxCategory = new DataGridViewComboBoxColumn();
                        colCboxCategory.Name = "CmpName";
                        colCboxCategory.HeaderText = "Successfull Bidder*";
                        colCboxCategory.DataSource = data;
                        colCboxCategory.ValueMember = "Value";
                        colCboxCategory.DisplayMember = "Description";
                        colCboxCategory.Width = 700;
                        dgvCntrStage3.Columns.Add(colCboxCategory);
                      //  dgvCntrStage3.DataError += new DataGridViewDataErrorEventHandler(dgvCntrStage3_DataError);
                        //dgvCntrStage3.EnableHeadersVisualStyles = false;
                    }
                    sqlCn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void CreateColumnsForWOContracors(DataGridView dgvWOCntr, int prjID) //WO->Work Orders
        {

            // Second New Column
            // CreateColumnsForCompanyGrid(dgvCntrStage3, cp_PrjiD);
            //===========================================================================
             
            //strQuery = "SELECT Co_id,co_name FROM COMPANY where co_shortname is not null";

            string strQuery = "SELECT COMPANY.co_id,COMPANY.co_name, Contractors.proj_id FROM Contractors INNER JOIN " +
            " COMPANY ON Contractors.co_id = COMPANY.co_id WHERE (Contractors.proj_id = " + prjID + " and Contractors.stage_id=4 ) ";

            //CheckBox headerCheckBox = null;
            //headerCheckBox = new CheckBox();
            //chkBox = new CreateCheckBox(dgvCntrStage3, headerCheckBox);
            //chkBox.AddHeaderCheckBox();

            DataGridViewCheckBoxColumn col0 = new DataGridViewCheckBoxColumn();
            //col0.Name = "chkBxSelect1";
            col0.DataPropertyName = "Select";
            col0.Width = 30;
            //col0.HeaderText = "";                      
            dgvWOCntr.Columns.Add(col0);

            try
            {
                using (SqlConnection sqlCn = new SqlConnection(connStr))
                {
                    sqlCn.Open();
                    using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                    {
                        SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                        DataTable data = new DataTable();
                        DataSet ds = new DataSet();
                        sqlda.Fill(ds);

                        data.Columns.Add(new DataColumn("co_id", typeof(int)));
                        data.Columns.Add(new DataColumn("co_name", typeof(string)));
                        for (int l = 0; l < ds.Tables[0].Rows.Count; l++)
                        {
                            //if(!successFullBidder.ToString().Contains(ds.Tables[0].Rows[l][1].ToString()))
                            data.Rows.Add(ds.Tables[0].Rows[l][0].ToString(), ds.Tables[0].Rows[l][1].ToString());
                        }

                        DataGridViewComboBoxColumn colCboxCategory = new DataGridViewComboBoxColumn();
                        colCboxCategory.Width = 300;
                        colCboxCategory.Name = "CmpName";
                        colCboxCategory.HeaderText = "Successfull Bidder";
                        colCboxCategory.DataSource = data;
                        colCboxCategory.ValueMember = "co_id";
                        colCboxCategory.DisplayMember = "co_name";
                        //dgvWOCntr.EditingControlShowing += new DataGridViewEditingControlShowingEventHandler(dgvWOCntr_EditingControlShowing);
                        if (!mIsHeadOfSection)
                        {
                            colCboxCategory.ReadOnly = true;
                        }
                        dgvWOCntr.Columns.Add(colCboxCategory);
                        

                        //colCboxCategory.Frozen = true;
                        //dgvWOCntr.EditingControlShowing += new DataGridViewEditingControlShowingEventHandler(dgvWOCntr_EditingControlShowing);

                        //dgvCntrStage3.RowEnter += new DataGridViewCellEventHandler(dgvCntrStage3_RowEnter);
                        //  dgvCntrStage3.DataError += new DataGridViewDataErrorEventHandler(dgvCntrStage3_DataError);
                        dgvWOCntr.EnableHeadersVisualStyles = false;                        
                    }
                    sqlCn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            DataGridViewTextBoxColumn colCmpName = new DataGridViewTextBoxColumn();
            colCmpName.Name = "co_name";
            colCmpName.HeaderText = "co_name";
            dgvWOCntr.Columns.Add(colCmpName);

            DataGridViewTextBoxColumn colWoContractAmount = new DataGridViewTextBoxColumn();
            colWoContractAmount.Name = "woContractAmount";
            colWoContractAmount.HeaderText = "WO Contract Amount";
            colWoContractAmount.Width = 100;
            dgvWOCntr.Columns.Add(colWoContractAmount);            
            dgvWOCntr.CellEndEdit += new DataGridViewCellEventHandler(dgvWOCntrAmount_CellEndEdit);

            //CalendarColumn colWoAwardDate = new CalendarColumn();
            //colWoAwardDate.Name = "woAwardDate";
            //colWoAwardDate.HeaderText = "Date of Award";
            //colWoAwardDate.Width = 120;
            //dgvWOCntr.Columns.Add(colWoAwardDate);
            //dgvWOCntr.CellEndEdit += new DataGridViewCellEventHandler(dgvWOCntrAwardDate_CellEndEdit);            

            CalendarColumn colCpReceivedofDoc = new CalendarColumn();
            colCpReceivedofDoc.Name = "cp_received_of_doc";
            colCpReceivedofDoc.HeaderText = "WO Received Date";
            dgvWOCntr.Columns.Add(colCpReceivedofDoc);
            dgvWOCntr.CellEndEdit += new DataGridViewCellEventHandler(dgvWOCntrReceivedDocDate_CellEndEdit);            

            DataGridViewTextBoxColumn colWorkOrderID = new DataGridViewTextBoxColumn();
            colWorkOrderID.Name = "workOrderBidderID";
            colWorkOrderID.HeaderText = "workOrderBidderID";
            dgvWOCntr.Columns.Add(colWorkOrderID);

            //DataGridViewTextBoxColumn colWoContractAmount = new DataGridViewTextBoxColumn();
            //colWoContractAmount.Name = "woContractAmount";
            //colWoContractAmount.HeaderText = "woContractAmount";
            //dgvWOCntr.Columns.Add(colWoContractAmount);

            //DataGridViewTextBoxColumn colWoAwardDate = new DataGridViewTextBoxColumn();
            //colWoAwardDate.Name = "woAwardDate";
            //colWoAwardDate.HeaderText = "woAwardDate";
            //dgvWOCntr.Columns.Add(colWoAwardDate);

           

            DataGridViewTextBoxColumn colCpRequestStartDate = new DataGridViewTextBoxColumn();
            colCpRequestStartDate.Name = "cp_request_start_date";
            colCpRequestStartDate.HeaderText = "cp_request_start_date";
            dgvWOCntr.Columns.Add(colCpRequestStartDate);

            DataGridViewTextBoxColumn colCpStartDateReceive = new DataGridViewTextBoxColumn();
            colCpStartDateReceive.Name = "cp_start_date_receive";
            colCpStartDateReceive.HeaderText = "cp_start_date_receive";
            dgvWOCntr.Columns.Add(colCpStartDateReceive);

            DataGridViewTextBoxColumn colCpNoticeContractorToSign = new DataGridViewTextBoxColumn();
            colCpNoticeContractorToSign.Name = "cp_notice_contractor_to_sign";
            colCpNoticeContractorToSign.HeaderText = "cp_notice_contractor_to_sign";
            dgvWOCntr.Columns.Add(colCpNoticeContractorToSign);

            DataGridViewTextBoxColumn colCpDueDatePb = new DataGridViewTextBoxColumn();
            colCpDueDatePb.Name = "cp_due_date_pb";
            colCpDueDatePb.HeaderText = "cp_due_date_pb";
            dgvWOCntr.Columns.Add(colCpDueDatePb);

            DataGridViewTextBoxColumn colCpSentDepSign = new DataGridViewTextBoxColumn();
            colCpSentDepSign.Name = "cp_sent_dep_sign";
            colCpSentDepSign.HeaderText = "cp_sent_dep_sign";
            dgvWOCntr.Columns.Add(colCpSentDepSign);

            DataGridViewTextBoxColumn colCpReceiveDepSentPrsd = new DataGridViewTextBoxColumn();
            colCpReceiveDepSentPrsd.Name = "cp_receive_dep_sent_prsd";
            colCpReceiveDepSentPrsd.HeaderText = "cp_receive_dep_sent_prsd";
            dgvWOCntr.Columns.Add(colCpReceiveDepSentPrsd);

            DataGridViewTextBoxColumn colCpSentFdCommit = new DataGridViewTextBoxColumn();
            colCpSentFdCommit.Name = "cp_sent_fd_commit";
            colCpSentFdCommit.HeaderText = "cp_sent_fd_commit";
            dgvWOCntr.Columns.Add(colCpSentFdCommit);

            DataGridViewTextBoxColumn colCpReceiveFdCommit = new DataGridViewTextBoxColumn();
            colCpReceiveFdCommit.Name = "cp_receive_fd_commit";
            colCpReceiveFdCommit.HeaderText = "cp_receive_fd_commit";
            dgvWOCntr.Columns.Add(colCpReceiveFdCommit);

            DataGridViewTextBoxColumn colCpDistribution = new DataGridViewTextBoxColumn();
            colCpDistribution.Name = "cp_distribution";
            colCpDistribution.HeaderText = "cp_distribution";
            dgvWOCntr.Columns.Add(colCpDistribution);

            DataGridViewTextBoxColumn colRemarks = new DataGridViewTextBoxColumn();
            colRemarks.Name = "remarks";
            colRemarks.HeaderText = "remarks";
            dgvWOCntr.Columns.Add(colRemarks);

            DataGridViewTextBoxColumn colContractNo = new DataGridViewTextBoxColumn();
            colContractNo.Name = "contract_no";
            colContractNo.HeaderText = "contract_no";
            dgvWOCntr.Columns.Add(colContractNo);

            DataGridViewTextBoxColumn colContractorSign = new DataGridViewTextBoxColumn();
            colContractorSign.Name = "cp_contractor_sign";
            colContractorSign.HeaderText = "cp_contractor_sign";
            dgvWOCntr.Columns.Add(colContractorSign);

            //if (txtWOAmount.Text != "")
            //{
            //    cmd.Parameters.AddWithValue("@woContractAmount", double.Parse(txtWOAmount.Text));               
            //}
            //else
            //{
            //    cmd.Parameters.AddWithValue("@woContractAmount", DBNull.Value);  
            //}

            //if (mskTxtRecOfAwardDoc.Text != "")
            //{
            //    cmd.Parameters.AddWithValue("@cpReceivedofDoc", Convert.ToDateTime(mskTxtRecOfAwardDoc.Text).ToString("dd/MMM/yyyy"));                   
            //}
            //else
            //{
            //    cmd.Parameters.AddWithValue("@cpReceivedofDoc", DBNull.Value);  
            //}

            //if (mskTxtReqDeptStartDate.Text != "")
            //{
            //    cmd.Parameters.AddWithValue("@cpRequestStartDate", Convert.ToDateTime(mskTxtReqDeptStartDate.Text).ToString("dd/MMM/yyyy"));                   
            //}
            //else
            //{
            //    cmd.Parameters.AddWithValue("@cpRequestStartDate", DBNull.Value);  
            //}

            //if (mskTxtStartDateReceive.Text != "")
            //{
            //    cmd.Parameters.AddWithValue("@cpStartDateReceive", Convert.ToDateTime(mskTxtStartDateReceive.Text).ToString("dd/MMM/yyyy"));                   
            //}
            //else
            //{
            //    cmd.Parameters.AddWithValue("@cpStartDateReceive", DBNull.Value);  
            //}

            //if (mskTxtNoticeSendSignContract.Text != "")
            //{
            //    cmd.Parameters.AddWithValue("@cpNoticeContractorToSign", Convert.ToDateTime(mskTxtNoticeSendSignContract.Text).ToString("dd/MMM/yyyy"));
            //}
            //else
            //{
            //    cmd.Parameters.AddWithValue("@cpNoticeContractorToSign", DBNull.Value);  
            //}

            //if (mskTxtDueDateOfSubPBSign.Text != "")
            //{
            //    cmd.Parameters.AddWithValue("@cpDueDatePb", Convert.ToDateTime(mskTxtDueDateOfSubPBSign.Text).ToString("dd/MMM/yyyy"));
            //}
            //else
            //{
            //    cmd.Parameters.AddWithValue("@cpDueDatePb", DBNull.Value);  
            //}

            //if (mskTxtSentDeptForSign.Text != "")
            //{
            //    cmd.Parameters.AddWithValue("@cpSentDepSign", Convert.ToDateTime(mskTxtSentDeptForSign.Text).ToString("dd/MMM/yyyy"));
            //}
            //else
            //{
            //    cmd.Parameters.AddWithValue("@cpSentDepSign", DBNull.Value);  
            //}

            //if (mskTxtRcvdDeptSentPRSDForSign.Text != "")
            //{
            //    cmd.Parameters.AddWithValue("@cpReceiveDepSentPrsd", Convert.ToDateTime(mskTxtRcvdDeptSentPRSDForSign.Text).ToString("dd/MMM/yyyy"));
            //}
            //else
            //{
            //    cmd.Parameters.AddWithValue("@cpReceiveDepSentPrsd", DBNull.Value);  
            //}

            //if (mskTxtSentFinanceDeptForCommittment.Text != "")
            //{
            //    cmd.Parameters.AddWithValue("@cpSentFdCommit", Convert.ToDateTime(mskTxtSentFinanceDeptForCommittment.Text).ToString("dd/MMM/yyyy"));
            //}
            //else
            //{
            //    cmd.Parameters.AddWithValue("@cpSentFdCommit", DBNull.Value);  
            //}

            //if (mskTxtRcvdFromFinanceDeptForCommittment.Text != "")
            //{
            //    cmd.Parameters.AddWithValue("@cpReceiveFdCommit", Convert.ToDateTime(mskTxtRcvdFromFinanceDeptForCommittment.Text).ToString("dd/MMM/yyyy"));
            //}
            //else
            //{
            //    cmd.Parameters.AddWithValue("@cpReceiveFdCommit", DBNull.Value);  
            //}

            //if (mskTxtDistribution.Text != "")
            //{
            //    cmd.Parameters.AddWithValue("@cpDistribution", Convert.ToDateTime(mskTxtDistribution.Text).ToString("dd/MMM/yyyy"));
            //}
            //else
            //{
            //    cmd.Parameters.AddWithValue("@cpDistribution", DBNull.Value);  
            //}


            //if (textRemarks.Text != "")
            //{
            //    cmd.Parameters.AddWithValue("@remarks", textRemarks.Text.Replace("Char(13)", "\r").Replace("Char(10)", "\n"));
            //}
            //else
            //{
            //    cmd.Parameters.AddWithValue("@remarks", DBNull.Value);  
            //} 

            //if (txtContractNo.Text != "")
            //{
            //    cmd.Parameters.AddWithValue("@contractNo", txtContractNo.Text);
            //}
            //else
            //{
            //    cmd.Parameters.AddWithValue("@contractNo", DBNull.Value);  
            //}             

            //if (mskTxtDateOfSignContract.Text  != "")
            //{
            //    cmd.Parameters.AddWithValue("@cpContractorSign", mskTxtDateOfSignContract.Text);
            //}
            //else
            //{
            //    cmd.Parameters.AddWithValue("@cpContractorSign", DBNull.Value);  
            //}  

            //DataGridViewTextBoxColumn colCboxCategory4 = new DataGridViewTextBoxColumn();
            //colCboxCategory4.Name = "Tndr_Date";
            //colCboxCategory4.HeaderText = "Tndr_Date";
            //dgvCntrStage3.Columns.Add(colCboxCategory4);
            
            dgvWOCntr.DataError += new DataGridViewDataErrorEventHandler(dgvWOCntr_DataError);             
            //headerCheckBox.KeyUp += new KeyEventHandler(chkBox.HeaderCheckBox_KeyUp);
            //headerCheckBox.MouseClick += new MouseEventHandler(chkBox.HeaderCheckBox_MouseClick);
            //dgvCntrStage3.CurrentCellDirtyStateChanged += new EventHandler(chkBox.dgvSelectAll_CurrentCellDirtyStateChanged);
            //dgvCntrStage3.CellPainting += new DataGridViewCellPaintingEventHandler(chkBox.dgvSelectAll_CellPainting);

            dgvWOCntr.ColumnHeadersDefaultCellStyle.BackColor = Color.Gainsboro;
            dgvWOCntr.ColumnHeadersDefaultCellStyle.ForeColor = Color.Chocolate;
            dgvWOCntr.ColumnHeadersDefaultCellStyle.Font = new Font(dgvWOCntr.Font, FontStyle.Regular);
            dgvWOCntr.EnableHeadersVisualStyles = false;
            dgvWOCntr.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
             
            
            //dgvWOCntr.Columns[7].Visible = false;
        }       
         

        protected void dgvWOCntrAmount_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if(mIsHeadOfSection)
            {
                DataGridView dgvCntr3 = sender as DataGridView;
                if (e.ColumnIndex == 3)
                {                
                    try
                    {
                        using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                        {
                            using (SqlCommand cmd = new SqlCommand())
                            {
                                if (sqlConn.State == ConnectionState.Closed)
                                    sqlConn.Open();
                                cmd.Connection = sqlConn;                          
                                        
                                cmd.CommandText = @"Update [WorkOrderSuccessfulBidders] set update_date=@update_date,update_user=@update_user,woContractAmount=@woContractAmount where workOrderBidderID=@workOrderBidderID";
                                cmd.Parameters.AddWithValue("@update_date", DateTime.Now.ToString());
                                cmd.Parameters.AddWithValue("@update_user", _userName);                                      
                                if (dgvCntr3.Rows[e.RowIndex].Cells[3].Value.ToString() != "")
                                {
                                    cmd.Parameters.AddWithValue("@woContractAmount", dgvCntr3.Rows[e.RowIndex].Cells[3].Value.ToString().Replace(",", ""));
                                }
                                else
                                {
                                    cmd.Parameters.AddWithValue("@woContractAmount", DBNull.Value);
                                } 
                                cmd.Parameters.AddWithValue("@workOrderBidderID", dgvCntr3.Rows[e.RowIndex].Cells[5].Value.ToString().Replace(",", ""));
                                int updated = cmd.ExecuteNonQuery();
                                cmd.Parameters.Clear();
                                if (updated != 0)
                                {
                                    MessageBox.Show("Contract Amount data Updated successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                                else
                                {
                                    MessageBox.Show("Record not updated. Please click on Save button or click on Edit button to update the details of Successfull  bidder", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error occurred while Updating the Successful Bidder record."+ ex.Message,"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }    
                     
                }
            }
            
        }

        protected void dgvWOCntrReceivedDocDate_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if(mIsHeadOfSection)
            {
                DataGridView dgvCntr3 = sender as DataGridView;
                if (dgvCntr3.Rows[e.RowIndex].Cells[5].Value!=null)
                { 
                    if (e.ColumnIndex == 4)
                    {                
                        try
                        {
                            using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["TCMSConnString"].ToString()))
                            {
                                using (SqlCommand cmd = new SqlCommand())
                                {
                                    if (sqlConn.State == ConnectionState.Closed)
                                        sqlConn.Open();
                                    cmd.Connection = sqlConn;                          
                                        
                                    cmd.CommandText = @"Update [WorkOrderSuccessfulBidders] set update_date=@update_date,update_user=@update_user,woAwardDate=@woAwardDate where workOrderBidderID=@workOrderBidderID";
                                    cmd.Parameters.AddWithValue("@update_date", DateTime.Now.ToString());
                                    cmd.Parameters.AddWithValue("@update_user", _userName);                                      
                                    if (dgvCntr3.Rows[e.RowIndex].Cells[4].Value.ToString() != "")
                                    {
                                        cmd.Parameters.AddWithValue("@woAwardDate", Convert.ToDateTime(dgvCntr3.Rows[e.RowIndex].Cells[4].Value).ToString("dd/MMM/yyyy"));
                                    }
                                    else
                                    {
                                        cmd.Parameters.AddWithValue("@woAwardDate", DBNull.Value);
                                    } 
                                    cmd.Parameters.AddWithValue("@workOrderBidderID", dgvCntr3.Rows[e.RowIndex].Cells[5].Value.ToString().Replace(",", ""));
                                    int updated = cmd.ExecuteNonQuery();
                                    cmd.Parameters.Clear();
                                    if (updated != 0)
                                    {
                                        MessageBox.Show("Work Order Document Received Date information updated successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    }
                                    else
                                    {
                                        MessageBox.Show("Record not updated. Please click on Save button or click on Edit button to update the details of Successfull  bidder", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error occurred while Updating the Successful Bidder record."+ ex.Message,"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }   
                    }                     
                }
            }
        }

        //private void dgvWOCntr_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        //{
        //    if (mdgvWOCntr.CurrentCell.ColumnIndex == 1 && e.Control is ComboBox)
        //    {
        //        ComboBox comboBox = e.Control as ComboBox;
        //        comboBox.SelectedIndexChanged -= SecondColumnComboSelectionChanged;
        //        comboBox.SelectedIndexChanged += SecondColumnComboSelectionChanged;
        //    }
        //}

        //private void SecondColumnComboSelectionChanged(object sender, EventArgs e)
        //{             
        //    var currentcell = mdgvWOCntr.CurrentCellAddress;
        //    var sendingCB = sender as DataGridViewComboBoxEditingControl;
        //    DataGridViewComboBoxCell cel = (DataGridViewComboBoxCell)mdgvWOCntr.Rows[currentcell.Y].Cells[1];
        //    //ComboBox cbRow5Cell1 = (ComboBox)cbRow5Cell1a as ComboBox;
        //    DataGridViewComboBoxCell cbRow6Cell1 = mdgvWOCntr.Rows[currentcell.Y].Cells[1] as DataGridViewComboBoxCell;

        //    //DataGridViewComboBoxColumn cel1 = (DataGridViewComboBoxColumn)mdgvWOCntr.Rows[currentcell.Y].Cells[1];
        //    object val = ((DataGridViewComboBoxCell)mdgvWOCntr.Rows[currentcell.Y].Cells[1]).Value;
        //    DataGridView dgv = sendingCB.EditingControlDataGridView;
        //    dgv.CurrentRow.Cells[1].Value = sendingCB.EditingControlFormattedValue.ToString();
        //    cel.Value = sendingCB.EditingControlFormattedValue.ToString();
        //    //cbRow6Cell1.Items.Add(sendingCB.EditingControlFormattedValue.ToString());
        //    cbRow6Cell1.Value = sendingCB.EditingControlFormattedValue.ToString();
        //    StringBuilder strCoIDs = new StringBuilder();

        //    foreach (DataGridViewRow dr in mdgvWOCntr.Rows)
        //    {
        //        if (dr.Cells[1].Value != null)
        //        {
        //            if (dr.Cells[1].Value != DBNull.Value)
        //                strCoIDs.Append(dr.Cells[1].Value.ToString() + ",");
        //        }
        //    }
        //    string duplicateCoIds = FindDuplicateCoIds(strCoIDs.ToString());
        //    if (duplicateCoIds.ToString()!="")
        //    {
        //        MessageBox.Show("Cannot select already selected company", "Information ", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //    }
        //}
        void dgvWOCntr_DataError(object sender, DataGridViewDataErrorEventArgs e)      
        {
            e.Cancel = true;
        }     
        
        StringBuilder successFullBidder = new StringBuilder();
         
        public void CreateColumnsForCP_Contracors_TE(DataGridView dgvCntrStage3, int cp_PrjiD)
        {            
             
            // Second New Column
            // CreateColumnsForCompanyGrid(dgvCntrStage3, cp_PrjiD);
            //===========================================================================

            string strQuery = null;
            //strQuery = "SELECT Co_id,co_name FROM COMPANY where co_shortname is not null";

            strQuery = "SELECT COMPANY.co_id,COMPANY.co_name, TenderDatesInfo.proj_id FROM TenderDatesInfo INNER JOIN " +
            " COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id WHERE (TenderDatesInfo.proj_id = " + cp_PrjiD + " and TenderDatesInfo.Tender_Issued=1 ) ";
             
            //CheckBox headerCheckBox = null;
            //headerCheckBox = new CheckBox();
            //chkBox = new CreateCheckBox(dgvCntrStage3, headerCheckBox);
            //chkBox.AddHeaderCheckBox();

            DataGridViewCheckBoxColumn col0 = new DataGridViewCheckBoxColumn();
            //col0.Name = "chkBxSelect1";
            col0.DataPropertyName = "Select";
            col0.Width = 30;   
            //col0.HeaderText = "";                      
            dgvCntrStage3.Columns.Add(col0);                 

            try
            {
                using (SqlConnection sqlCn = new SqlConnection(connStr))
                {
                    sqlCn.Open();
                    using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                    {
                        SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                        DataTable data = new DataTable();
                        DataSet ds = new DataSet();
                        sqlda.Fill(ds);

                        data.Columns.Add(new DataColumn("co_id", typeof(int)));
                        data.Columns.Add(new DataColumn("co_name", typeof(string)));
                        for (int l = 0; l < ds.Tables[0].Rows.Count; l++)
                        {
                            //if(!successFullBidder.ToString().Contains(ds.Tables[0].Rows[l][1].ToString()))
                                data.Rows.Add(ds.Tables[0].Rows[l][0].ToString(), ds.Tables[0].Rows[l][1].ToString());                             
                        }

                        DataGridViewComboBoxColumn colCboxCategory = new DataGridViewComboBoxColumn();
                        colCboxCategory.Width = 300;
                        colCboxCategory.Name = "CmpName";
                        colCboxCategory.HeaderText = "Successfull Bidder";
                        colCboxCategory.DataSource = data;
                        colCboxCategory.ValueMember = "co_id";
                        colCboxCategory.DisplayMember = "co_name";                                                 
                        dgvCntrStage3.Columns.Add(colCboxCategory);                        
                        
                        //colCboxCategory.Frozen = true;
                        //dgvCntrStage3.EditingControlShowing += new DataGridViewEditingControlShowingEventHandler(dgvCntrStage3ColCboxCategory_EditingControlShowing);
                        
                        //dgvCntrStage3.RowEnter += new DataGridViewCellEventHandler(dgvCntrStage3_RowEnter);
                        //  dgvCntrStage3.DataError += new DataGridViewDataErrorEventHandler(dgvCntrStage3_DataError);
                        dgvCntrStage3.EnableHeadersVisualStyles = false;
                        //dgvCntrStage3Obj = dgvCntrStage3;
                    }
                    sqlCn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            //===========================================================================

            DataGridViewTextBoxColumn colCboxCmpType = new DataGridViewTextBoxColumn();
            colCboxCmpType.Name = "Type";
            colCboxCmpType.HeaderText = "Type";
            colCboxCmpType.Width = 50;
            dgvCntrStage3.Columns.Add(colCboxCmpType);            

            DataGridViewTextBoxColumn colCboxCategory2 = new DataGridViewTextBoxColumn();
            colCboxCategory2.Name = "Amount";
            colCboxCategory2.HeaderText = "Award Amount";
            colCboxCategory2.Width = 100;
            dgvCntrStage3.Columns.Add(colCboxCategory2);

            CalendarColumn colCboxCategory7 = new CalendarColumn();
            colCboxCategory7.Name = "TndrAward";
            colCboxCategory7.HeaderText = "Date of Letter of Award";
            //colCboxCategory7.DefaultCellStyle.Format = "";
            //colCboxCategory7.CellEndEdit += new EventHandler(dgvCntrStage3_CellEndEdit);

            colCboxCategory7.Width = 120;
            dgvCntrStage3.Columns.Add(colCboxCategory7);

            DataGridViewTextBoxColumn colCboxCategory5 = new DataGridViewTextBoxColumn();
            colCboxCategory5.Name = "Bidder_ID";
            colCboxCategory5.HeaderText = "Bidder_ID";             
            dgvCntrStage3.Columns.Add(colCboxCategory5);

            DataGridViewTextBoxColumn colCboxCategory6 = new DataGridViewTextBoxColumn();
            colCboxCategory6.Name = "ProjID";
            colCboxCategory6.HeaderText = "projID";             
            dgvCntrStage3.Columns.Add(colCboxCategory6);          


            //DataGridViewTextBoxColumn colCboxCategory4 = new DataGridViewTextBoxColumn();
            //colCboxCategory4.Name = "Tndr_Date";
            //colCboxCategory4.HeaderText = "Tndr_Date";
            //dgvCntrStage3.Columns.Add(colCboxCategory4);
            //dgvCntrStage3.CellEndEdit += new DataGridViewCellEventHandler(dgvCntrStage3_CellEndEdit);
            // dgvCntrStage3.DataError += new DataGridViewDataErrorEventHandler(dgvContracts_DataError);

            //headerCheckBox.KeyUp += new KeyEventHandler(chkBox.HeaderCheckBox_KeyUp);
            //headerCheckBox.MouseClick += new MouseEventHandler(chkBox.HeaderCheckBox_MouseClick);
            //dgvCntrStage3.CurrentCellDirtyStateChanged += new EventHandler(chkBox.dgvSelectAll_CurrentCellDirtyStateChanged);
            //dgvCntrStage3.CellPainting += new DataGridViewCellPaintingEventHandler(chkBox.dgvSelectAll_CellPainting);

            dgvCntrStage3.ColumnHeadersDefaultCellStyle.BackColor = Color.Gainsboro;
            dgvCntrStage3.ColumnHeadersDefaultCellStyle.ForeColor = Color.Chocolate;
            dgvCntrStage3.ColumnHeadersDefaultCellStyle.Font = new Font(dgvCntrStage3.Font, FontStyle.Regular);
            dgvCntrStage3.EnableHeadersVisualStyles = false;
            dgvCntrStage3.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            
            dgvCntrStage3.Columns[5].Visible = false;
            dgvCntrStage3.Columns[6].Visible = false;
        }

        

        protected void dgvCntrStage3_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            DataGridView dgvCntr3 = sender as DataGridView;
            if (e.ColumnIndex == 3)
            {
                if (dgvCntr3.Rows[e.RowIndex].Cells[3].Value.ToString() != "" && dgvCntr3.Rows[e.RowIndex].Cells[0].Value.ToString() != "")
                {
                    successFullBidder.Append(dgvCntr3.Rows[e.RowIndex].Cells[0].Value.ToString() + ",");                    
                }
            }
        }

        private string FindDuplicateCoIds(string coIds)
        {
            var dictionary = new Dictionary<string, bool>();
                         
            // Build up string into this StringBuilder.
            StringBuilder duplicateCoIds = new StringBuilder();
                         
            // Split the input and handle spaces and punctuation.
            string[] arrayCoIds = coIds.Split(new char[] {','},
                StringSplitOptions.RemoveEmptyEntries);
             
            // Loop over each coIds
            foreach (string coId in arrayCoIds)
            {        
                // If we haven't already encountered the word,
                // append it to the result.
                if (!dictionary.ContainsKey(coId))                
                    dictionary.Add(coId, true);          
                else
                    duplicateCoIds.Append(coId + ",");                     
            }             
            // Return the duplicate coIds
            return duplicateCoIds.ToString();
        }

        bool isInsertedOrUpdated = false;         
        //static short updatedLoopCounter = 0;
        public void CP_Contracts_Insert_UpdateData(DataGridView dgvCntr, SqlCommand cmd, int cp_PrjID, bool isHeadOfSection)
        {            
            StringBuilder strCoIDs = new StringBuilder();
            
            foreach (DataGridViewRow dr in dgvCntr.Rows)
            {
                if (dr.Cells[1].Value != null)
                    strCoIDs.Append(dr.Cells[1].Value.ToString() + ",");
            }
            string duplicateCoIds = FindDuplicateCoIds(strCoIDs.ToString());            
            double cntr_Amnt = 0; string tndr_Award_Date = string.Empty; string bidID = null; string co_Id = null;             

            foreach (DataGridViewRow dr in dgvCntr.Rows)
            {
                if (dr.Cells[1].Value != null)
                {
                    if (dr.Cells[1].Value.ToString() != "")
                    {
                        string strQuery = null;
                        string cmpName = null;                         
                        co_Id = dr.Cells[1].Value.ToString();   //co_id                     

                        strQuery = "SELECT COMPANY.co_name,CONTRACTORS.bidder_id FROM CONTRACTORS INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id " +
                        " WHERE CONTRACTORS.proj_id=" + cp_PrjID + " and CONTRACTORS.co_id =" + co_Id;
                         
                        cmd.CommandText = strQuery;
                        SqlDataReader sqlDtReader = cmd.ExecuteReader();
                        
                        
                        if (dr.Cells[3].Value.ToString() != "")                     // Cntr_Amnt
                            cntr_Amnt = Convert.ToDouble(dr.Cells[3].Value.ToString());

                        if (dr.Cells[4].Value.ToString() != "")              // Tndr_Award
                            tndr_Award_Date = Convert.ToString(dr.Cells[4].Value.ToString());
                        else
                            tndr_Award_Date = "";

                        if (sqlDtReader.HasRows)
                        {
                            sqlDtReader.Read();
                            if (sqlDtReader["bidder_id"] != null)              //Bid_ID
                            {
                                bidID = sqlDtReader["bidder_id"].ToString();
                            }                             
                           
                        }
                        else
                        {
                            if (isHeadOfSection)
                            {
                                sqlDtReader.Close();
                                insertBidderDetails(cmd, cp_PrjID, bidID, co_Id, cntr_Amnt, tndr_Award_Date);                                
                                isInsertedOrUpdated = true;

                            }
                            else
                            {
                                sqlDtReader.Close();
                                MessageBox.Show("Cannot insert the information of company, Do not have privilege to insert the data, Contact Head of Section", "Information ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }    
                        }

                        if (bidID != null)
                        {
                            cmpName = sqlDtReader["co_name"].ToString();                            
                            sqlDtReader.Close();
                            if (!duplicateCoIds.Contains(dr.Cells[1].Value.ToString()))
                            {                                
                                 if (isHeadOfSection)
                                 {
                                     updateBidderDetails(cmd, cp_PrjID, bidID, co_Id, cntr_Amnt, tndr_Award_Date);
                                     isInsertedOrUpdated = true;                                      
                                 }
                                 else
                                 {
                                     MessageBox.Show("Cannot edit the information of company which was already awarded this contract, Do not have privilege to edit or save the data, Contact Head of Section", "Information ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                     sqlDtReader.Close();
                                 }   
                                                                
                            }
                            else
                            {                                   
                                if (isHeadOfSection)
                                {                                     
                                    updateDetailsOfRepeatedBidder(cmd, cp_PrjID, bidID, co_Id, cntr_Amnt, tndr_Award_Date, null, cmpName);                                       
                                }
                                else
                                {
                                    MessageBox.Show("Cannot edit the information of company, Do not have privilege to edit or save the data, Contact Head of Section", "Information ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }                                     
                            }                               
                        }                                              
                    }
                }
            }
            if (isInsertedOrUpdated)
            {
                MessageBox.Show("Contracts data added/updated successfully");
                isInsertedOrUpdated = false;
            }
            
        }


        bool isWOBidderInsertedOrUpdated = false;
        //static short updatedLoopCounter = 0;
        public void WOInsertOrUpdateBidders(DataGridView dgvWOCntr, SqlCommand cmd, int prjID,string workerOrderID, bool isHeadOfSection)
        {
            StringBuilder strCoIDs = new StringBuilder();

            foreach (DataGridViewRow dr in dgvWOCntr.Rows)
            {
                if (dr.Cells[1].Value != null)
                {
                    if(dr.Cells[1].Value!=DBNull.Value)
                        strCoIDs.Append(dr.Cells[1].Value.ToString() + ",");
                }
            }
            string duplicateCoIds = FindDuplicateCoIds(strCoIDs.ToString());            

            foreach (DataGridViewRow dr in dgvWOCntr.Rows)
            {
                if (dr.Cells[1].Value != null) //&& dr.Cells[2].Value != null && dr.Cells[3].Value != null
                {
                    if (dr.Cells[1].Value != DBNull.Value) //&& dr.Cells[2].Value != DBNull.Value && dr.Cells[3].Value != DBNull.Value
                    {
                        if (dr.Cells[1].Value.ToString() != "")
                        {
                            //string strQuery = null;
                            string cmpName = null;
                            string workOrderBidderID = null;
                            double cntr_Amnt = 0; string tndr_Award_Date = null; string coID = null;
                            //co_Id = dr.Cells[1].Value.ToString();   //co_id                     

                            //strQuery = "SELECT COMPANY.co_name,CONTRACTORS.bidder_id FROM CONTRACTORS INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id " +
                            //" WHERE CONTRACTORS.proj_id=" + prjID + " and CONTRACTORS.co_id =" + co_Id;

                            //cmd.CommandText = strQuery;
                            //SqlDataReader sqlDtReader = cmd.ExecuteReader();


                            //if (dr.Cells[2].Value.ToString() != "")                     // Wo_Cntr_Amnt->Wo-Work Order
                            //    cntr_Amnt = Convert.ToDouble(dr.Cells[2].Value.ToString());

                            //if (dr.Cells[3].Value.ToString() != "")              // Wo_Tndr_Award->Wo-Work Order
                            //    tndr_Award_Date = Convert.ToString(dr.Cells[3].Value.ToString());
                            //else
                            //    tndr_Award_Date = "";

                            //if (sqlDtReader.HasRows)
                            //{
                            //    sqlDtReader.Read();
                            //    if (sqlDtReader["bidder_id"] != null)              //Bid_ID
                            //    {
                            //        bidID = sqlDtReader["bidder_id"].ToString();
                            //    }

                            //}
                            //else
                            //{
                            coID = dr.Cells[1].Value.ToString();
                            workOrderBidderID = dr.Cells[2].Value.ToString();
                            if (workOrderBidderID == "")
                            {
                                if (isHeadOfSection)
                                {
                                    //sqlDtReader.Close();

                                    insertWOBidderDetails(cmd, prjID, coID, cntr_Amnt, tndr_Award_Date, workerOrderID);
                                    isWOBidderInsertedOrUpdated = true;

                                }
                                else
                                {
                                    //sqlDtReader.Close();
                                    MessageBox.Show("Cannot insert the information of company, Do not have privilege to insert the data, Contact Head of Section", "Information ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                            }
                            else
                            {
                                cmpName = dr.Cells[1].Value.ToString();
                                if (!duplicateCoIds.Contains(dr.Cells[1].Value.ToString()))
                                {
                                    if (isHeadOfSection)
                                    {
                                        updateWOBidderDetails(cmd, coID, cntr_Amnt, tndr_Award_Date, workerOrderID, workOrderBidderID);
                                        isWOBidderInsertedOrUpdated = true;
                                    }
                                    else
                                    {
                                        MessageBox.Show("Cannot edit the information of company which was already awarded this contract, Do not have privilege to edit or save the data, Contact Head of Section", "Information ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    }

                                }
                                else
                                {
                                    if (isHeadOfSection)
                                    {
                                        updateWODetailsOfRepeatedBidder(cmd, coID, cntr_Amnt, tndr_Award_Date, cmpName, workerOrderID, workOrderBidderID);
                                    }
                                    else
                                    {
                                        MessageBox.Show("Cannot edit the information of company, Do not have privilege to edit or save the data, Contact Head of Section", "Information ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Cannot Save or Update the Awarded Bidder information because either of Awarded Bidder (Company Name) or Awarded Amount or Date of Award is empty.", "Information ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                
            }
            if (isWOBidderInsertedOrUpdated)
            {
                MessageBox.Show("Contracts data added/updated successfully");
                isWOBidderInsertedOrUpdated = false;
            }

        }

        private void updateDetailsOfRepeatedBidder(SqlCommand cmd, int cp_PrjID, string bidId, string co_Id, double cntr_Amnt, string tndr_Award_Date, SqlDataReader sqlDtReader,string compName)
        {
            DialogResult dlgResult = DialogResult.No;
            dlgResult = MessageBox.Show(compName + " was already awarded this contract, Click Yes if you want to update the information", "Update Confirmation ", MessageBoxButtons.YesNo);

            if (dlgResult.ToString() == "Yes")
            {
                updateBidderDetails(cmd, cp_PrjID, bidId, co_Id, cntr_Amnt, tndr_Award_Date);
                if (sqlDtReader != null)
                {
                    sqlDtReader.Close();
                }
                isInsertedOrUpdated = true;
            }
            else
            {
                if (sqlDtReader != null)
                {
                    sqlDtReader.Close();
                }
            }
        }

        private void updateWODetailsOfRepeatedBidder(SqlCommand cmd, string coId, double cntr_Amnt, string tndr_Award_Date, string compName, string workerOrderID, string workOrderBidderID)
        {
            DialogResult dlgResult = DialogResult.No;
            dlgResult = MessageBox.Show(compName + " was already awarded this contract, Click Yes if you want to update the information", "Update Confirmation ", MessageBoxButtons.YesNo);

            if (dlgResult.ToString() == "Yes")
            {
                updateWOBidderDetails(cmd, coId, cntr_Amnt, tndr_Award_Date, workerOrderID, workOrderBidderID);                
                isInsertedOrUpdated = true;
            }            
        }

        private int updateBidderDetails(SqlCommand cmd, int cp_PrjID, string bidID, string coID, double awardedAmount, string tndrAwardDate)
        {
            cmd.CommandText = @"Update [CONTRACTORS] set ContractAmount = @CntrAmount,update_date_eval =@update_date,update_user_eval =@update_user,co_id =@cmpID, cp_tender_award = @tndr_Award where bidder_id=@bidder_id and proj_id=@projId";
            cmd.Parameters.AddWithValue("@projId", cp_PrjID);
            // cmd.Parameters.AddWithValue("@stageId", stage_Id);
            cmd.Parameters.AddWithValue("@cmpID", coID);

            if (awardedAmount != 0)
                cmd.Parameters.AddWithValue("@CntrAmount", awardedAmount);
            else
                cmd.Parameters.AddWithValue("@CntrAmount", DBNull.Value);

            
            cmd.Parameters.AddWithValue("@bidder_id", bidID);            

            cmd.Parameters.AddWithValue("@cntrTypeID", 1);  //ContractAmount       CntrAmount

            if (tndrAwardDate != "")
                cmd.Parameters.AddWithValue("@tndr_Award", Convert.ToDateTime(tndrAwardDate));    //CntrAward
            else
                cmd.Parameters.AddWithValue("@tndr_Award", DBNull.Value);

            cmd.Parameters.AddWithValue("@update_date", DateTime.Now.ToString());
            cmd.Parameters.AddWithValue("@update_user", _userName);  //ContractAmount       CntrAmount

            int updated = cmd.ExecuteNonQuery();
            cmd.Parameters.Clear();
            return updated;
            
        }


        private int updateWOBidderDetails(SqlCommand cmd, string coID, double awardedAmount, string woAwardDate, string workOrderID,string workOrderBidderID)
        {
            //cmd.CommandText = @"Update [WorkOrderSuccessfulBidders] set woContractAmount = @woCntrAmount,update_date=@update_date,update_user =@update_user, woAwardDate = @woAwardDate " +
            //",co_id=@coId where workOrderID=@workOrderID and workOrderBidderID=@workOrderBidderID";
            cmd.CommandText = @"Update [WorkOrderSuccessfulBidders] set update_date=@update_date,update_user =@update_user, " +
            "co_id=@coId where workOrderBidderID=@workOrderBidderID";
            cmd.Parameters.AddWithValue("@coId", coID);
            // cmd.Parameters.AddWithValue("@stageId", stage_Id);             

            //if (awardedAmount != 0)
            //    cmd.Parameters.AddWithValue("@woCntrAmount", awardedAmount);
            //else
            //    cmd.Parameters.AddWithValue("@woCntrAmount", DBNull.Value);

            //cmd.Parameters.AddWithValue("@workOrderID", workOrderID);

            //cmd.Parameters.AddWithValue("@workOrderBidderID", workOrderBidderID);

            //if (woAwardDate != "")
            //    cmd.Parameters.AddWithValue("@woAwardDate", Convert.ToDateTime(woAwardDate));    //CntrAward
            //else
            //    cmd.Parameters.AddWithValue("@woAwardDate", DBNull.Value);

            cmd.Parameters.AddWithValue("@update_date", DateTime.Now.ToString());
            cmd.Parameters.AddWithValue("@update_user", _userName);  //ContractAmount       CntrAmount

            int updated = cmd.ExecuteNonQuery();
            cmd.Parameters.Clear();
            return updated;

        }

        private void insertBidderDetails(SqlCommand cmd, int cp_PrjID, string bidID, string coID, double awardedAmount, string tndrAwardDate)
        {
            cmd.CommandText = @"insert into CONTRACTORS (ContractAmount,update_date_eval,update_user_eval,co_id,cp_tender_award,bidder_id,proj_id) values(@CntrAmount,@update_date,@update_user,@cmpID,@tndr_Award,@bidder_id,@projId)";
            cmd.Parameters.AddWithValue("@projId", cp_PrjID);
            // cmd.Parameters.AddWithValue("@stageId", stage_Id);
            cmd.Parameters.AddWithValue("@cmpID", coID);

            if (awardedAmount != 0)
                cmd.Parameters.AddWithValue("@CntrAmount", awardedAmount);
            else
                cmd.Parameters.AddWithValue("@CntrAmount", DBNull.Value);

            cmd.Parameters.AddWithValue("@bidder_id", maxValue("SELECT MAX(bidder_id)+1 FROM [CONTRACTORS]"));
            cmd.Parameters.AddWithValue("@cntrTypeID", 1);  //ContractAmount       CntrAmount
            if (tndrAwardDate != "")
                cmd.Parameters.AddWithValue("@tndr_Award", Convert.ToDateTime(tndrAwardDate));    //CntrAward
            else
                cmd.Parameters.AddWithValue("@tndr_Award", DBNull.Value);

            cmd.Parameters.AddWithValue("@update_date", DateTime.Now.ToString());
            cmd.Parameters.AddWithValue("@update_user", _userName);  //ContractAmount       CntrAmount

            int inserted = cmd.ExecuteNonQuery();
            cmd.Parameters.Clear();

        }

        private void insertWOBidderDetails(SqlCommand cmd, int prjID, string coID, double awardedAmount, string tndrAwardDate, string workerOrderID)
        {
            //cmd.CommandText = @"insert into WorkOrderSuccessfulBidders(woContractAmount,create_user,create_date,woAwardDate,co_id,proj_id,workOrderID) values(@woAmount,@createUser,@createDate,@woAwardDate,@coId,@projId,@workOrderID)";
            cmd.CommandText = @"insert into WorkOrderSuccessfulBidders(create_user,create_date,co_id,proj_id,workOrderID) values(@createUser,@createDate,@coId,@projId,@workOrderID)";
            cmd.Parameters.AddWithValue("@projId", prjID);             
            //cmd.Parameters.AddWithValue("@cmpID", coID);

            //if (awardedAmount != 0)
            //    cmd.Parameters.AddWithValue("@woAmount", awardedAmount);
            //else
            //    cmd.Parameters.AddWithValue("@woAmount", DBNull.Value);

            cmd.Parameters.AddWithValue("@coId", coID); //maxValue("SELECT MAX(bidder_id)+1 FROM [CONTRACTORS]")
            cmd.Parameters.AddWithValue("@workOrderID", workerOrderID);             
            //if (tndrAwardDate != "")
            //    cmd.Parameters.AddWithValue("@woAwardDate", Convert.ToDateTime(tndrAwardDate));    //CntrAward
            //else
            //    cmd.Parameters.AddWithValue("@woAwardDate", DBNull.Value);

            cmd.Parameters.AddWithValue("@createDate", DateTime.Now.ToString());
            cmd.Parameters.AddWithValue("@createUser", _userName);  //ContractAmount       CntrAmount

            int inserted = cmd.ExecuteNonQuery();
            cmd.Parameters.Clear();

        }

        public void UpdateBidderID(int bidID,int DateiD)
        {
            string sqlUpdate = "Update TenderDatesInfo Set tndr_BidID = @bidID where Date_ID = @dateID";
            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(sqlUpdate, sqlCn))
                {
                    sqlCmd.Parameters.AddWithValue("@bidID", bidID);
                    sqlCmd.Parameters.AddWithValue("@dateID", DateiD);
                }
                sqlCn.Close();
            }
        }
        public void FillContractsData()
        {

        }
        private void Insert_Cp_Multirecords(int _bidderid,int _tndrPrjID,string _cmpID)
        {
            int _dateID = GetMaxDateID();
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                sqlConn.Open();               
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlConn;         //co_id      ==  cmpID
                    cmd.CommandText = @"INSERT INTO [TenderDatesInfo](Tndr_BidID,date_id,proj_id,stage_id,CreateDate,CreateUser,co_id) VALUES(@TndrDates_BidID,@dateId,@projId,@stageID,@CreateDate,@CreateUser,@cmpID)";

                    cmd.Parameters.AddWithValue("@TndrDates_BidID", _bidderid);
                    cmd.Parameters.AddWithValue("@dateId", _dateID);
                    cmd.Parameters.AddWithValue("@projId", _tndrPrjID);
                    cmd.Parameters.AddWithValue("@stageID", 4);
                   // cmd.Parameters.AddWithValue("@cmpID", "");     

                    cmd.Parameters.AddWithValue("@CreateDate", DateTime.Now.ToString());
                    cmd.Parameters.AddWithValue("@CreateUser", _userName);  //TndrBidName

                    cmd.Parameters.AddWithValue("@cmpID", _cmpID); 

                    int exUpdated = cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                }
            } 
        }

        public void FillWOBiddersGrid(DataGridView dgvWOCntrDetails, int prjID, string workOrderID)
        {    
            // strQuery = "select co_type_id,cp_contractor_sign,contract_no,bidder_id,ContractAmount from WorkOrderSuccessfulBidders WHERE (proj_id = " + Convert.ToInt16(lblProjID.Text) + ") AND (stage_id = 4) ";

            //tndr_DateID
            //strQuery = "SELECT WorkOrderSuccessfulBidders.co_id, COMPANY_TYPE.co_type_name, WorkOrderSuccessfulBidders.ContractAmount, " +
            //" WorkOrderSuccessfulBidders.cp_tender_award,WorkOrderSuccessfulBidders.bidder_id, WorkOrderSuccessfulBidders.proj_id FROM WorkOrderSuccessfulBidders INNER JOIN COMPANY ON WorkOrderSuccessfulBidders.co_id = COMPANY.co_id INNER JOIN COMPANY_TYPE ON COMPANY.co_type_id = COMPANY_TYPE.co_type_id " +
            //" WHERE (WorkOrderSuccessfulBidders.proj_id = " + prjID + ") AND (WorkOrderSuccessfulBidders.stage_id = 4)";

            //strQuery = "SELECT DISTINCT WorkOrderSuccessfulBidders.co_id,COMPANY.co_name, COMPANY_TYPE.co_type_name, WorkOrders.woContractAmount, WorkOrders.woAwardDate, WorkOrders.bidder_Id,WorkOrders.workOrderID " +
            //" FROM WorkOrders RIGHT OUTER JOIN WorkOrderSuccessfulBidders ON WorkOrderSuccessfulBidders.proj_id = WorkOrders.proj_id INNER JOIN COMPANY ON WorkOrderSuccessfulBidders.co_id = COMPANY.co_id INNER JOIN " +
            //"COMPANY_TYPE ON COMPANY.co_type_id = COMPANY_TYPE.co_type_id WHERE (WorkOrders.proj_id = " + prjID + ") AND (WorkOrders.workOrderID ="+ workOrderID+") ";

            string strQuery = "SELECT WorkOrderSuccessfulBidders.co_id,COMPANY.co_name,WorkOrderSuccessfulBidders.woContractAmount,WorkOrderSuccessfulBidders.cp_received_of_doc,WorkOrderSuccessfulBidders.workOrderBidderID,WorkOrderSuccessfulBidders.cp_request_start_date,WorkOrderSuccessfulBidders.cp_start_date_receive,WorkOrderSuccessfulBidders.cp_notice_contractor_to_sign," +
            "WorkOrderSuccessfulBidders.cp_due_date_pb,WorkOrderSuccessfulBidders.cp_sent_dep_sign,WorkOrderSuccessfulBidders.cp_receive_dep_sent_prsd,WorkOrderSuccessfulBidders.cp_sent_fd_commit,WorkOrderSuccessfulBidders.cp_receive_fd_commit,WorkOrderSuccessfulBidders.cp_distribution,WorkOrderSuccessfulBidders.remarks," +
                    "WorkOrderSuccessfulBidders.contract_no,WorkOrderSuccessfulBidders.cp_contractor_sign " + //, WorkOrderSuccessfulBidders.woContractAmount,COMPANY.co_name,
            " FROM COMPANY INNER JOIN COMPANY_TYPE ON COMPANY.co_type_id = COMPANY_TYPE.co_type_id INNER JOIN WorkOrderSuccessfulBidders ON COMPANY.co_id = WorkOrderSuccessfulBidders.co_id INNER JOIN " +
            " WorkOrders ON WorkOrders.workOrderID = WorkOrderSuccessfulBidders.workOrderID WHERE (WorkOrders.proj_id = " + prjID + " and WorkOrders.workOrderID=" + workOrderID + ")";
            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    sqlCmd.CommandTimeout = 80;
                    SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                    DataSet ds = new DataSet();
                    sqlda.Fill(ds);                    
                    dgvWOCntrDetails.Columns[0].Width = 20;
                    dgvWOCntrDetails.Columns[1].DataPropertyName = "co_id";
                    dgvWOCntrDetails.Columns[1].Width = 200;                     
                    //dgvWOCntrDetails.Columns[2].DataPropertyName = "woContractAmount";
                    //dgvWOCntrDetails.Columns[3].DataPropertyName = "woAwardDate";
                    dgvWOCntrDetails.Columns[2].DataPropertyName = "co_name";
                    dgvWOCntrDetails.Columns[3].DataPropertyName = "woContractAmount";
                    dgvWOCntrDetails.Columns[4].DataPropertyName = "cp_received_of_doc";
                    dgvWOCntrDetails.Columns[5].DataPropertyName = "workOrderBidderID";                                         
                    dgvWOCntrDetails.Columns[6].DataPropertyName = "cp_request_start_date";
                    dgvWOCntrDetails.Columns[7].DataPropertyName = "cp_start_date_receive";
                    dgvWOCntrDetails.Columns[8].DataPropertyName = "cp_notice_contractor_to_sign";
                    dgvWOCntrDetails.Columns[9].DataPropertyName = "cp_due_date_pb";
                    dgvWOCntrDetails.Columns[10].DataPropertyName = "cp_contractor_sign";                     
                    dgvWOCntrDetails.Columns[11].DataPropertyName = "cp_sent_dep_sign";
                    dgvWOCntrDetails.Columns[12].DataPropertyName = "cp_receive_dep_sent_prsd";
                    dgvWOCntrDetails.Columns[13].DataPropertyName = "cp_sent_fd_commit";
                    dgvWOCntrDetails.Columns[14].DataPropertyName = "cp_receive_fd_commit";
                    dgvWOCntrDetails.Columns[15].DataPropertyName = "cp_distribution";
                    dgvWOCntrDetails.Columns[16].DataPropertyName = "remarks";
                    dgvWOCntrDetails.Columns[17].DataPropertyName = "contract_no";
                    //dgvWOCntrDetails.Columns[18].DataPropertyName = "cp_contractor_sign";
                    

                    dgvWOCntrDetails.DataSource = ds.Tables[0];                    
                    dgvWOCntrDetails.Columns[2].Visible = false;
                    dgvWOCntrDetails.Columns[5].Visible = false;
                    dgvWOCntrDetails.Columns[6].Visible = false;
                    dgvWOCntrDetails.Columns[7].Visible = false;
                    dgvWOCntrDetails.Columns[8].Visible = false;
                    dgvWOCntrDetails.Columns[9].Visible = false;
                    dgvWOCntrDetails.Columns[10].Visible = false;
                    dgvWOCntrDetails.Columns[11].Visible = false;
                    dgvWOCntrDetails.Columns[12].Visible = false;
                    dgvWOCntrDetails.Columns[13].Visible = false;
                    dgvWOCntrDetails.Columns[14].Visible = false;
                    dgvWOCntrDetails.Columns[15].Visible = false;
                    dgvWOCntrDetails.Columns[16].Visible = false;
                    dgvWOCntrDetails.Columns[17].Visible = false;
                    //dgvWOCntrDetails.Columns[18].Visible = false;
                    //dgvWOCntrDetails.Columns[19].Visible = false;                     
                    if (mIsHeadOfSection)
                    {
                        dgvWOCntrDetails.AllowUserToAddRows = true;
                    }
                    else
                    {
                        dgvWOCntrDetails.AllowUserToAddRows = false;
                    }
                    //dgvCntr.RowsAdded += new DataGridViewRowsAddedEventHandler(dgvCntr_RowsAdded);                           
                    //dgvWOCntrDetails.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvCntr_CellFormatting);
                    //dgvWOCntrDetails.DataError += new DataGridViewDataErrorEventHandler(dgvContracts_DataError);
                }
                sqlCn.Close();
            }

            dgvWOCntrDetails.DefaultCellStyle.WrapMode = DataGridViewTriState.True;

        }
         
        int cpProjID = 0;
        public void FillContractsGrid_TE(DataGridView dgvCntr,int cp_prjiD,int statusID)
        {
            cpProjID = cp_prjiD;
            
            string strQuery = "";
            // strQuery = "select co_type_id,cp_contractor_sign,contract_no,bidder_id,ContractAmount from CONTRACTORS WHERE (proj_id = " + Convert.ToInt16(lblProjID.Text) + ") AND (stage_id = 4) ";


            //tndr_DateID
            strQuery = "SELECT CONTRACTORS.co_id, COMPANY_TYPE.co_type_name, CONTRACTORS.ContractAmount, " +
            " CONTRACTORS.cp_tender_award,CONTRACTORS.bidder_id, CONTRACTORS.proj_id FROM CONTRACTORS INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN COMPANY_TYPE ON COMPANY.co_type_id = COMPANY_TYPE.co_type_id " +
            " WHERE (CONTRACTORS.proj_id = " + cp_prjiD + ") AND (CONTRACTORS.stage_id = 4)";

            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    sqlCmd.CommandTimeout = 80;
                    SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                    DataSet ds = new DataSet();
                    sqlda.Fill(ds);
                  
                    if (statusID != 0)
                    {
                        if (ds.Tables[0].Rows.Count == 0)                        
                            Status_Award(statusID, cp_prjiD.ToString());                        
                    }
                    dgvCntr.Columns[0].Width = 20;
                    dgvCntr.Columns[1].DataPropertyName = "co_id";
                    dgvCntr.Columns[1].Width = 200;
                    dgvCntr.Columns[2].DataPropertyName = "co_type_name";
                    dgvCntr.Columns[2].Width = 50;
                    dgvCntr.Columns[3].DataPropertyName = "ContractAmount";                     
                    dgvCntr.Columns[4].DataPropertyName = "cp_tender_award";                     
                    dgvCntr.Columns[5].DataPropertyName = "bidder_id";
                    dgvCntr.Columns[6].DataPropertyName = "proj_id";                    
                    dgvCntr.DataSource = ds.Tables[0];
                    dgvCntr.AllowUserToAddRows = true;
                    //dgvCntr.RowsAdded += new DataGridViewRowsAddedEventHandler(dgvCntr_RowsAdded);      
              
                    dgvCntr.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvCntr_CellFormatting);
                    dgvCntr.DataError += new DataGridViewDataErrorEventHandler(dgvContracts_DataError);
                }
                sqlCn.Close();
            }             

            dgvCntr.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
             
        }

        public void Status_Award(int statusID,string projID)
        {
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    if (sqlConn.State == ConnectionState.Closed)
                        sqlConn.Open();
                    cmd.Connection = sqlConn;
                    cmd.CommandText = @"Update Projects set Tender_Status_id = @status,stage_id = @stgID where proj_id=@projId";
                    cmd.Parameters.AddWithValue("@projId", projID);
                    cmd.Parameters.AddWithValue("@status", statusID);
                    if(statusID==6)
                        cmd.Parameters.AddWithValue("@stgID",4);
                    else
                        cmd.Parameters.AddWithValue("@stgID", 3);

                    cmd.Parameters.AddWithValue("@update_date", DateTime.Now.ToString());
                    //cmd.Parameters.AddWithValue("@update_user", "");

                    int exUpdated = cmd.ExecuteNonQuery();

                    cmd.Parameters.Clear();
                }
            }
        }

        void dgvCntr_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            DataGridView dgvCntr3 = (DataGridView)sender;
            DataGridViewComboBoxCell dgvComboBox = (DataGridViewComboBoxCell)dgvCntr3.Rows[e.RowIndex].Cells[0];
            if (dgvComboBox.Value == null)
            {
                string strQuery = "";

                strQuery = "SELECT COMPANY.co_id,COMPANY.co_name, TenderDatesInfo.proj_id FROM TenderDatesInfo INNER JOIN COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id LEFT OUTER JOIN CONTRACTORS ON " +
                "TenderDatesInfo.proj_id = CONTRACTORS.proj_id WHERE (TenderDatesInfo.proj_id = " + cpProjID + " and TenderDatesInfo.Tender_Issued=1) AND (TenderDatesInfo.co_id <> CONTRACTORS.co_id)";

                using (SqlConnection sqlCn = new SqlConnection(connStr))
                {
                    sqlCn.Open();
                    using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                    {
                        SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                        DataTable data = new DataTable();
                        DataSet ds = new DataSet();
                        sqlda.Fill(ds);

                        data.Columns.Add(new DataColumn("Value", typeof(int)));
                        data.Columns.Add(new DataColumn("Description", typeof(string)));
                        for (int l = 0; l < ds.Tables[0].Rows.Count; l++)
                        {
                            //if(!successFullBidder.ToString().Contains(ds.Tables[0].Rows[l][1].ToString()))
                            data.Rows.Add(ds.Tables[0].Rows[l][0].ToString(), ds.Tables[0].Rows[l][1].ToString());
                        }

                        dgvComboBox.DataSource = data;
                        dgvComboBox.ValueMember = "Value";
                        dgvComboBox.DisplayMember = "Description";
                    }
                }
            }
        }
        

        // Added by Varun on 10/05/15 for formatting the CalendarColumn date to blank
        private void dgvCntr_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            DataGridView dgvCntr3 = sender as DataGridView;
            if (e.ColumnIndex == 4)
            {
                DateTime? nullable_dt = new DateTime?();
                if(dgvCntr3.Rows[e.RowIndex].Cells[0].Value==null)
                    dgvCntr3.Rows[e.RowIndex].Cells[4].Value = nullable_dt;
                //if ((val != null) && !object.ReferenceEquals(val, DBNull.Value))
                //{
                //    e.Value = string.Format("{0:#,##0.00}", double.Parse(dgvContracts.Rows[e.RowIndex].Cells[1].Value.ToString()));//#,##0
                //}
            }

            //if (e.ColumnIndex == 0)
            //{
            //   
            //}

            if (e.ColumnIndex == 3)
            {
                object val = dgvCntr3.Rows[e.RowIndex].Cells[3].Value;
                if ((val != null) && !object.ReferenceEquals(val, DBNull.Value))
                {
                    e.Value = string.Format("{0:#,##0.00}", double.Parse(dgvCntr3.Rows[e.RowIndex].Cells[3].Value.ToString()));//#,##0
                }
            }
                //if (dgvCntr3.Rows[e.RowIndex].Cells[0].Value.ToString() != "")
                //    ((DataGridViewComboBoxCell)(dgvCntr3.Rows[e.RowIndex].Cells[0])).e

                
                //if ((val != null) && !object.ReferenceEquals(val, DBNull.Value))
                //{
                //    e.Value = string.Format("{0:#,##0.00}", double.Parse(dgvContracts.Rows[e.RowIndex].Cells[1].Value.ToString()));//#,##0
                //}
            //}
        }

        public string FillEmployee_dgvComboValue(int cmpID)
        {
            string _cmpType = string.Empty;
            SqlConnection sqlConn = new SqlConnection(connStr);
            sqlConn.Open();
            string sqlQuery = "SELECT COMPANY_TYPE.co_type_name, COMPANY.co_id FROM COMPANY INNER JOIN COMPANY_TYPE ON COMPANY.co_type_id = COMPANY_TYPE.co_type_id WHERE (COMPANY.co_id = " + cmpID + ")";

            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                _cmpType = sqlReader[0].ToString();
            }
            sqlReader.Close();
            sqlConn.Close();
            return _cmpType;
        }
        public string FillComapany_dgvComboValue(int cmpID)
        {
            string _cmpType = string.Empty;
            SqlConnection sqlConn = new SqlConnection(connStr);
            sqlConn.Open();
            string sqlQuery = "SELECT COMPANY_TYPE.co_type_name, COMPANY.co_id FROM COMPANY INNER JOIN COMPANY_TYPE ON COMPANY.co_type_id = COMPANY_TYPE.co_type_id WHERE (COMPANY.co_id = " + cmpID + ")";

            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                _cmpType = sqlReader[0].ToString();
            }
            sqlReader.Close();
            sqlConn.Close();
            return _cmpType;
        }
        public int FillDateIDOfSelectedCompany_dgvComboValue(int PrjiD, int cmpID)
        {
            int _dateID = 0;
            SqlConnection sqlConn = new SqlConnection(connStr);
            sqlConn.Open();
            string sqlQuery = "SELECT date_id, proj_id, stage_id, co_id FROM TenderDatesInfo WHERE (proj_id = " + PrjiD + ") AND (co_id =  " + cmpID + ")";

            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                _dateID = Convert.ToInt32(sqlReader[0].ToString());
            }
            sqlReader.Close();
            sqlConn.Close();
            return _dateID;
        }
        public void CPMultipleRecords_Insert_Update(DataGridView dgvCpDataEntry,SqlConnection sqlConn,SqlCommand cmd,int prjid)   // CPMultipleRecords_Insert_Update
        {
            int x;
            x = 0;
            foreach (DataGridViewRow dr in dgvCpDataEntry.Rows)
            {
                x = x + 1;
                if (x < dgvCpDataEntry.Rows.Count)
                {
                    // string Value0 = Convert.ToString(dr.Cells[0].Value.ToString());
                    string Value0 = Convert.ToString(dr.Cells[0].Value.ToString());
                    string Value1 = Convert.ToString(dr.Cells[1].Value.ToString());
                    string Value2 = Convert.ToString(dr.Cells[2].Value.ToString());
                    string Value3 = Convert.ToString(dr.Cells[3].Value.ToString());
                    string Value4 = Convert.ToString(dr.Cells[4].Value.ToString());
                    string Value5 = Convert.ToString(dr.Cells[5].Value.ToString());
                    string Value6 = Convert.ToString(dr.Cells[6].Value.ToString());
                    string Value7 = Convert.ToString(dr.Cells[7].Value.ToString());

                    string Value8 = Convert.ToString(dr.Cells[8].Value.ToString());
                    string Value9 = Convert.ToString(dr.Cells[9].Value.ToString());
                    string Value10 = Convert.ToString(dr.Cells[10].Value.ToString());
                    string Value11 = Convert.ToString(dr.Cells[11].Value.ToString());
                    string Value12 = Convert.ToString(dr.Cells[12].Value.ToString());

                    // string Value8 = Convert.ToString(dr.Cells[8].Value.ToString());

                    if (Value7 == "" || Value7 == null)
                    {
                        Int16 cpdateId;
                        cpdateId = maxValue("SELECT MAX(DATE_ID)+1 FROM TenderDatesInfo");


                        cmd.Connection = sqlConn;

                        int stage_Id = 0;
                        stage_Id = 4;
                        // cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,cp_sent_dep_sign,cp_receive_dep_sent_prsd,cp_sent_fd_commit,cp_receive_fd_commit,cp_distribution,remarks,employee_id,CreateDate,CreateUser) VALUES(@dateId,@projId,@stageId,@cp_sent_dep_sign,@cp_receive_dep_sent_prsd,@cp_sent_fd_commit,@cp_receive_fd_commit,@cp_distribution,@remarks,@empID,@CreateDate,@CreateUser)";

                        // cp_received_of_doc,cp_request_start_date,cp_start_date_receive,cp_notice_contractor_to_sign,cp_due_date_pb

                        cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,cp_sent_dep_sign,cp_receive_dep_sent_prsd,cp_sent_fd_commit, " +
                        " cp_receive_fd_commit,cp_distribution,remarks,StaffInCharge,CreateDate,CreateUser,cp_received_of_doc, " +
                        " cp_request_start_date,cp_start_date_receive,cp_notice_contractor_to_sign,cp_due_date_pb) " +
                        " VALUES(@dateId,@projId,@stageId,@cp_sent_dep_sign, " +
                        " @cp_receive_dep_sent_prsd,@cp_sent_fd_commit,@cp_receive_fd_commit,@cp_distribution,@remarks,@Staff,@CreateDate,@CreateUser, " +
                        " @cpreceivedofdoc,@cprequeststartdate,@cpstartdatereceive,@cpnotice_contractortosign,@cpduedatepb)";

                        cmd.Parameters.AddWithValue("@projId", prjid);
                        cmd.Parameters.AddWithValue("@stageId", stage_Id);

                        if (Value0 != "")
                            cmd.Parameters.AddWithValue("@cp_sent_dep_sign", Value0);
                        else
                            cmd.Parameters.AddWithValue("@cp_sent_dep_sign", DBNull.Value);
                        if (Value1 != "")
                            cmd.Parameters.AddWithValue("@cp_receive_dep_sent_prsd", Value1);
                        else
                            cmd.Parameters.AddWithValue("@cp_receive_dep_sent_prsd", DBNull.Value);
                        if (Value2 != "")
                            cmd.Parameters.AddWithValue("@cp_sent_fd_commit", Value2);
                        else
                            cmd.Parameters.AddWithValue("@cp_sent_fd_commit", DBNull.Value);
                        if (Value3 != "")
                            cmd.Parameters.AddWithValue("@cp_receive_fd_commit", Value3);
                        else
                            cmd.Parameters.AddWithValue("@cp_receive_fd_commit", DBNull.Value);

                        if (Value4 != "")
                            cmd.Parameters.AddWithValue("@cp_distribution", Value4);
                        else
                            cmd.Parameters.AddWithValue("@cp_distribution", DBNull.Value);

                        cmd.Parameters.AddWithValue("@remarks", Value5);
                        cmd.Parameters.AddWithValue("@Staff", Value6);
                        //cmd.Parameters.AddWithValue("@empID", Value6);

                        cmd.Parameters.AddWithValue("@CreateDate", DateTime.Now.ToString());
                        cmd.Parameters.AddWithValue("@CreateUser", _userName);
                        cmd.Parameters.AddWithValue("@dateId", cpdateId);



                        if (Value8 != "")
                            cmd.Parameters.AddWithValue("@cpreceivedofdoc", Value8);
                        else
                            cmd.Parameters.AddWithValue("@cpreceivedofdoc", DBNull.Value);

                        if (Value9 != "")
                            cmd.Parameters.AddWithValue("@cprequeststartdate", Value9);
                        else
                            cmd.Parameters.AddWithValue("@cprequeststartdate", DBNull.Value);

                        if (Value10 != "")
                            cmd.Parameters.AddWithValue("@cpstartdatereceive", Value10);
                        else
                            cmd.Parameters.AddWithValue("@cpstartdatereceive", DBNull.Value);

                        if (Value11 != "")
                            cmd.Parameters.AddWithValue("@cpnotice_contractortosign", Value11);
                        else
                            cmd.Parameters.AddWithValue("@cpnotice_contractortosign", DBNull.Value);

                        if (Value12 != "")
                            cmd.Parameters.AddWithValue("@cpduedatepb", Value12);
                        else
                            cmd.Parameters.AddWithValue("@cpduedatepb", DBNull.Value);

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                    else
                    {

                        cmd.Connection = sqlConn;
                        int stage_Id = 0;
                        stage_Id = 4;
                        // cmd.CommandText = @"UPDATE TenderDatesInfo set cp_sent_dep_sign=@cp_sent_dep_sign,cp_receive_dep_sent_prsd=@cp_receive_dep_sent_prsd,cp_sent_fd_commit=@cp_sent_fd_commit,cp_receive_fd_commit=@cp_receive_fd_commit,cp_distribution=@cp_distribution,remarks=@remarks,[employee_id]=@empID, UpdateDate=@UpdateDate,updateuser=@updateuser where date_id=@dateId";

                        cmd.CommandText = @"UPDATE TenderDatesInfo set cp_sent_dep_sign=@cp_sent_dep_sign,cp_receive_dep_sent_prsd=@cp_receive_dep_sent_prsd, " +
                        " cp_sent_fd_commit=@cp_sent_fd_commit,cp_receive_fd_commit=@cp_receive_fd_commit,cp_distribution=@cp_distribution,remarks=@remarks, " +
                        " [StaffIncharge]=@Staff, UpdateDate=@UpdateDate,updateuser=@updateuser,cp_received_of_doc=@cpreceivedofdoc,cp_request_start_date=@cprequeststartdate, " +
                            " cp_start_date_receive=@cpstartdatereceive,cp_notice_contractor_to_sign=@cpnotice_contractortosign,cp_due_date_pb=@cpduedatepb where date_id=@dateId";
                        cmd.Parameters.AddWithValue("@projId",prjid);
                        cmd.Parameters.AddWithValue("@stageId", stage_Id);
                        if (Value0 != "")
                            cmd.Parameters.AddWithValue("@cp_sent_dep_sign", Value0);
                        else
                            cmd.Parameters.AddWithValue("@cp_sent_dep_sign", DBNull.Value);
                        if (Value1 != "")
                            cmd.Parameters.AddWithValue("@cp_receive_dep_sent_prsd", Value1);
                        else
                            cmd.Parameters.AddWithValue("@cp_receive_dep_sent_prsd", DBNull.Value);
                        if (Value2 != "")
                            cmd.Parameters.AddWithValue("@cp_sent_fd_commit", Value2);
                        else
                            cmd.Parameters.AddWithValue("@cp_sent_fd_commit", DBNull.Value);
                        if (Value3 != "")
                            cmd.Parameters.AddWithValue("@cp_receive_fd_commit", Value3);
                        else
                            cmd.Parameters.AddWithValue("@cp_receive_fd_commit", DBNull.Value);

                        if (Value4 != "")
                            cmd.Parameters.AddWithValue("@cp_distribution", Value4);
                        else
                            cmd.Parameters.AddWithValue("@cp_distribution", DBNull.Value);
                        cmd.Parameters.AddWithValue("@remarks", Value5);
                        //cmd.Parameters.AddWithValue("@empID", Value6);

                        cmd.Parameters.AddWithValue("@Staff", Value6);
                        cmd.Parameters.AddWithValue("@UpdateDate", DateTime.Now.ToString());
                        cmd.Parameters.AddWithValue("@updateuser", _userName);
                        cmd.Parameters.AddWithValue("@dateId", Value7);

                        if (Value8 != "")
                            cmd.Parameters.AddWithValue("@cpreceivedofdoc", Value8);
                        else
                            cmd.Parameters.AddWithValue("@cpreceivedofdoc", DBNull.Value);

                        if (Value9 != "")
                            cmd.Parameters.AddWithValue("@cprequeststartdate", Value9);
                        else
                            cmd.Parameters.AddWithValue("@cprequeststartdate", DBNull.Value);

                        if (Value10 != "")
                            cmd.Parameters.AddWithValue("@cpstartdatereceive", Value10);
                        else
                            cmd.Parameters.AddWithValue("@cpstartdatereceive", DBNull.Value);

                        if (Value11 != "")
                            cmd.Parameters.AddWithValue("@cpnotice_contractortosign", Value11);
                        else
                            cmd.Parameters.AddWithValue("@cpnotice_contractortosign", DBNull.Value);

                        if (Value12 != "")
                            cmd.Parameters.AddWithValue("@cpduedatepb", Value12);
                        else
                            cmd.Parameters.AddWithValue("@cpduedatepb", DBNull.Value);


                        int exUpdated = cmd.ExecuteNonQuery();

                        cmd.Parameters.Clear();
                    }
                }
            }
        }

        clsStaffUpdate clsStaff = new clsStaffUpdate();
        
        public void UpdateContractsData(DataGridView dgvcontr, SqlCommand cmd, SqlConnection sqlConn,int cntr_PrjID)
        {
            int x;
            x = 0;

            List<string> staffColl = new List<string>();
            string staffName = "";

            int projID_cntr = 0;

            string Value0 = string.Empty;    // bidID
            string Value1 = string.Empty;
            string Value2 = string.Empty;
            string Value3 = string.Empty;
            string Value4 = string.Empty;
            string Value5 = string.Empty;
            string Value6 = string.Empty;

            string strDateReq = string.Empty;
            string noaIssued = string.Empty;

            foreach (DataGridViewRow dr in dgvcontr.Rows)
            {
                if (x < dgvcontr.Rows.Count)
                {
                     Value0 = Convert.ToString(dr.Cells[3].Value.ToString());    // bidID
                     Value1 = Convert.ToString(dr.Cells[4].Value.ToString());
                     Value2 = Convert.ToString(dr.Cells[5].Value.ToString());
                     Value3 = Convert.ToString(dr.Cells[6].Value.ToString());
                     Value4 = Convert.ToString(dr.Cells[7].Value.ToString());
                     Value5 = Convert.ToString(dr.Cells[8].Value.ToString());
                     Value6 = Convert.ToString(dr.Cells[9].Value.ToString());

                    if (projID_cntr == 0)
                        projID_cntr = Convert.ToInt16(dr.Cells[10].Value.ToString());

                    if (dr.Cells[0].Value.ToString() == "")
                    {
                        continue;
                    }

                    if (Value6 != "" || Value6 != null)
                    {
                        cmd.Connection = sqlConn;

                        cmd.CommandText = @"Update [CONTRACTORS] set StaffInCharge = @Staff, " +
                         " cp_received_of_doc = @ReceivedOfDoc, " +
                         " cp_request_start_date = @reqDeptStartDate, " +
                         " cp_start_date_receive = @startDateReceive, " +
                         " cp_notice_contractor_to_sign = @noticeSentforSign, " +
                         " cp_due_date_pb = @cpDueDate_PB , " +
                         " update_date_cp=@UpdateDate,update_user_cp=@updateuser where bidder_id=@bidder_id";

                        cmd.Parameters.AddWithValue("@bidder_id", Value6);

                        if (Value0 != "")
                            cmd.Parameters.AddWithValue("@Staff", Value0);
                        else
                            cmd.Parameters.AddWithValue("@Staff", DBNull.Value);

                        if (Value0 != "")
                            staffName = Value0; // Line added for get staff valus for update in projects table

                        if (Value1 != "")
                            cmd.Parameters.AddWithValue("@ReceivedOfDoc", Convert.ToDateTime(Value1.Split(' ')[0] +" " +DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@ReceivedOfDoc", DBNull.Value);                       

                        if (Value2 != "")
                            cmd.Parameters.AddWithValue("@reqDeptStartDate", Convert.ToDateTime(Value2.Split(' ')[0] + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@reqDeptStartDate", DBNull.Value);

                        if (Value3 != "")
                            cmd.Parameters.AddWithValue("@startDateReceive", Convert.ToDateTime(Value3.Split(' ')[0] + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@startDateReceive", DBNull.Value);

                        if (Value4 != "")
                            cmd.Parameters.AddWithValue("@noticeSentforSign", Convert.ToDateTime(Value4.Split(' ')[0] + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@noticeSentforSign", DBNull.Value);                      

                        if (Value5 != "")
                            cmd.Parameters.AddWithValue("@cpDueDate_PB", Convert.ToDateTime(Value5.Split(' ')[0] + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@cpDueDate_PB", DBNull.Value);

                        cmd.Parameters.AddWithValue("@UpdateDate", DateTime.Now.ToString());
                        cmd.Parameters.AddWithValue("@updateuser", _userName);

                        int exUpdated = cmd.ExecuteNonQuery();

                        cmd.Parameters.Clear();
                    }
                }

                x = x + 1;
            }

            cmd.Parameters.Clear();
            //Added To update the last_Modified_Date
            cmd.CommandText = @"UPDATE PROJECTS set last_Modified_Date=@UpdateDate,Update_User = @UpdateUser where proj_id=@projId";
            cmd.Parameters.AddWithValue("@UpdateDate", System.DateTime.Now);
            cmd.Parameters.AddWithValue("@UpdateUser", _userName);
            cmd.Parameters.AddWithValue("@projId", cntr_PrjID);
            cmd.ExecuteNonQuery();
            cmd.Parameters.Clear();
            // if cp_request_start_date enter then update tender status as Start Date requested
            //if (strDateReq != "")
            //{
            //    UpdateTenderStatus_CP_StartDateRequested(cntr_PrjID);
            //}
            //// if cp_notice_contractor_to_sign enter then update tender status as NoA issued
            //if (noaIssued != "")
            //{
            //    UpdateTenderStatus_CP_NOAIssued(cntr_PrjID);
            //}
           

            if (staffName !="")
            {
                clsStaff.update_Staff(staffName, cntr_PrjID);
            }
        }
        public void UpdateContractsMultipleData(DataGridView dgvCpDataEntry,DataGridView dgvContracts, SqlCommand cmd, SqlConnection sqlConn, int cntr_PrjID,Label lblContractNoDisplay)
        {
            int x;
            x = 0;
             
            Int16 insertCheck = 0;

            string Value1=null;
            string Value2 = string.Empty;
            string Value3 = string.Empty;
            string Value4 = string.Empty;
            string Value5 = string.Empty;
            string Value6 = string.Empty;
            string Value7 = string.Empty;
            string Value8 = string.Empty;
            string Value9 = string.Empty;
            
            string cntrSigned = string.Empty;
            string sigProcessing = string.Empty;

            foreach (DataGridViewRow dr in dgvCpDataEntry.Rows)
            {
                
                if (x < dgvCpDataEntry.Rows.Count)
                {
                    //string Value0 = Convert.ToString(dr.Cells[0].Value.ToString());    // bidID
                     Value1 = Convert.ToString(dr.Cells[1].Value.ToString());
                     Value2 = Convert.ToString(dr.Cells[2].Value.ToString());
                     Value3 = Convert.ToString(dr.Cells[3].Value.ToString());
                     Value4 = Convert.ToString(dr.Cells[4].Value.ToString());
                     Value5 = Convert.ToString(dr.Cells[5].Value.ToString());
                     Value6 = Convert.ToString(dr.Cells[6].Value.ToString());
                     Value7 = Convert.ToString(dr.Cells[7].Value.ToString());
                     Value8 = Convert.ToString(dr.Cells[8].Value.ToString());
                     Value9 = Convert.ToString(dr.Cells[9].Value.ToString());

                     //if (projID_cntr == 0)
                     //    projID_cntr = Convert.ToInt16(dr.Cells[10].Value.ToString());


                    if (dr.Cells[0].Value.ToString() == "")
                    {
                        continue;
                    }

                    if (Value9 != "" || Value9 != null)
                    {
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"Update [CONTRACTORS] set cp_contractor_sign = @cntrSign, " +
                            " cp_sent_dep_sign =  @SentFor_deptSign, " +
                            " cp_receive_dep_sent_prsd = @Prsd, " +
                            " cp_sent_fd_commit = @SentToFinance, " +
                            " cp_receive_fd_commit = @RecFromFinance, " +
                            " cp_distribution = @Distribustion," +
                            " contract_no = @cntrNo," +
                            " remarks =@cntrRemarks, " +
                            " update_date_cp=@UpdateDate,update_user_cp=@updateuser,stage_Id=@stageId where bidder_id=@bidder_id";

                        cmd.Parameters.AddWithValue("@bidder_id", Value9);

                        if (Value1 != "")
                            cmd.Parameters.AddWithValue("@cntrSign", Convert.ToDateTime(Value1.Split(' ')[0] + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@cntrSign", DBNull.Value);

                        if (Value1 != "")
                            cntrSigned = Value1;

                        if (Value2 != "")
                            cmd.Parameters.AddWithValue("@SentFor_deptSign", Convert.ToDateTime(Value2.Split(' ')[0] + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@SentFor_deptSign", DBNull.Value);

                        if (Value3 != "")
                            cmd.Parameters.AddWithValue("@Prsd", Convert.ToDateTime(Value3.Split(' ')[0] + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@Prsd", DBNull.Value);                       

                        if (Value4 != "")
                            cmd.Parameters.AddWithValue("@SentToFinance", Convert.ToDateTime(Value4.Split(' ')[0] + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@SentToFinance", DBNull.Value);

                        if (Value5 != "")
                            cmd.Parameters.AddWithValue("@RecFromFinance", Convert.ToDateTime(Value5.Split(' ')[0] + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@RecFromFinance", DBNull.Value);

                        if (Value6 != "")
                            cmd.Parameters.AddWithValue("@Distribustion", Convert.ToDateTime(Value6.Split(' ')[0] + " " + DateTime.Now.ToLongTimeString()));
                        else
                            cmd.Parameters.AddWithValue("@Distribustion", DBNull.Value);

                        if (Value7.Trim().ToLower() != "framework")
                        {
                            Value7 = Value7.Replace(" ", "").Replace("-", "/");
                            while (Regex.Match(Value7, "/0").Success)
                                Value7 = Value7.Replace("/0", "/");

                            cmd.Parameters.AddWithValue("@cntrNo", Value7.ToUpper());
                            if (x == 0)
                            {                       
                                lblContractNoDisplay.Text = Value7.ToUpper();                                
                            }
                        }
                        else if (Value7.Trim().ToLower() == "framework")
                        {
                            cmd.Parameters.AddWithValue("@cntrNo", "Framework");                            
                        }
                        else if (Value7.Trim().ToLower().Contains("workorder"))
                        {
                            cmd.Parameters.AddWithValue("@cntrNo", "Workorder");                            
                        }
                         
                        cmd.Parameters.AddWithValue("@stageId", 4);
                        
                        cmd.Parameters.AddWithValue("@cntrRemarks", Value8);


                        cmd.Parameters.AddWithValue("@UpdateDate", DateTime.Now.ToString());
                        cmd.Parameters.AddWithValue("@updateuser", _userName);

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();

                        SetProjStageStatus(6, cntr_PrjID);

                        if (Value1 != "" && dgvContracts.RowCount != 0 && insertCheck==0)
                        {
                            cmd.Connection = sqlConn;
                            cmd.CommandText = @"UPDATE TenderDatesInfo SET [org_tender_to_expire]= @orgTenderToExpire,[org_tenderbond_to_expire]=@orgTenderbondToExpire  Where proj_id=@projId and stage_id=2";
                            cmd.Parameters.AddWithValue("@projId", cntr_PrjID);
                            cmd.Parameters.AddWithValue("@orgTenderToExpire", DBNull.Value);
                            cmd.Parameters.AddWithValue("@orgTenderbondToExpire", DBNull.Value); //DBNull.Value
                            exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                            insertCheck = 1;
                        }     

                    }
                }
                x = x + 1;
            }

            //Added To update the last_Modified_Date
            
            //// if cp_sent_dep_sign enter then update tender status as Contract Signed
            //if (cntrSigned != "")
            //{
            //    UpdateTenderStatus_CP_Contract_Signed(cntr_PrjID);
            //}
            //// if cp_receive_dep_sent_prsd enter then update tender status as Signature processing
            //if (sigProcessing != "")
            //{
            //    UpdateTenderStatus_CP_Signature_Processing(cntr_PrjID);
            //}

            MessageBox.Show("Data Updated Successfully.");
        }

        public void Status_Commit(int ststusID,string projID)
        {
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    if (sqlConn.State == ConnectionState.Closed)
                        sqlConn.Open();
                    cmd.Connection = sqlConn;
                    cmd.CommandText = @"Update Projects set Tender_Status_id = @status,stage_id = @stgID where proj_id=@projId";
                    cmd.Parameters.AddWithValue("@projId", projID);
                    cmd.Parameters.AddWithValue("@status", ststusID);

                    if (ststusID == 7)   // commit
                        cmd.Parameters.AddWithValue("@stgID", 6);
                    else
                        cmd.Parameters.AddWithValue("@stgID", 4);

                    //cmd.Parameters.AddWithValue("@update_date", DateTime.Now.ToString());
                    //cmd.Parameters.AddWithValue("@update_user", "");

                    int exUpdated = cmd.ExecuteNonQuery();

                    cmd.Parameters.Clear();
                }
            }
        }

        public void SetProjStageStatus(int stageID, int projID)
        {
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    if (sqlConn.State == ConnectionState.Closed)
                        sqlConn.Open();
                    cmd.Connection = sqlConn;
                    cmd.CommandText = @"Update Projects set stage_id = @stgID,last_Modified_Date=@UpdateDate,Update_User = @UpdateUser where proj_id=@projId";
                    cmd.Parameters.AddWithValue("@projId", projID);
                    cmd.Parameters.AddWithValue("@stgID", stageID);
                    cmd.Parameters.AddWithValue("@UpdateDate", DateTime.Now.ToString());
                    cmd.Parameters.AddWithValue("@UpdateUser", _userName);

                    int exUpdated = cmd.ExecuteNonQuery();

                    cmd.Parameters.Clear();
                }
            }
        }

        public int GetMaxDateID()
        {
            int maxDate = 0;
            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                String readData = "SELECT Max(DATE_ID)+1 FROM TenderDatesInfo";
                SqlCommand cmd = new SqlCommand(readData, sqlCn);
                maxDate = Convert.ToInt16(cmd.ExecuteScalar());
                sqlCn.Close();
            }
            return maxDate;
        }

        //Added By Varun         
        static DataGridViewComboBoxColumn colCboxCategory = null;
        public DataGridViewComboBoxColumn ColCmbBoxCategory
        {
            get { return colCboxCategory; }
            set { colCboxCategory = value; }
        }

        public void CreateStaff_ComboBoxForGrid(DataGridView dgvContracts)
        {
            string strQuery = "";
            strQuery = "SELECT employee_id,ShortName,LastName FROM CONTACTS where ShortName is not null order by ShortName";
            try
            {
                using (SqlConnection sqlCn = new SqlConnection(connStr))
                {
                    sqlCn.Open();
                    using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                    {
                        colCboxCategory = new DataGridViewComboBoxColumn();
                        colCboxCategory.Name = "Staff";
                        colCboxCategory.HeaderText = "Handling By*";
                        sqlCmd.CommandText = strQuery;
                        sqlCmd.Connection = sqlCn;
                        SqlDataReader sqlReader = sqlCmd.ExecuteReader();
                        if (sqlReader.HasRows)
                        {
                            while (sqlReader.Read())
                            {
                                colCboxCategory.Items.Add(sqlReader[1]);       // + " " + sqlReader[2]
                            }
                        }
                        sqlReader.Close();
                        sqlCmd.Dispose();
                        ColCmbBoxCategory = colCboxCategory;
                        colCboxCategory.Name = "Staff";
                        colCboxCategory.HeaderText = "Handling By*";
                        //colCboxCategory.ValueMember = "Value";
                        //colCboxCategory.DisplayMember = "Description";
                        colCboxCategory.Width = 180;
                        //Added By Varun
                        colCboxCategory.DisplayStyle = DataGridViewComboBoxDisplayStyle.DropDownButton;
                        dgvContracts.EnableHeadersVisualStyles = true;
                        colCboxCategory.DataPropertyName = "StaffInCharge";
                        dgvContracts.Columns.Add(colCboxCategory);
                        dgvContracts.DataError += new DataGridViewDataErrorEventHandler(dgvContracts_DataError);

                    }
                    sqlCn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void CreateStaff_ComboBoxForGrid_Old(DataGridView dgvContracts)
        {
            string strQuery = "";
            strQuery = "SELECT employee_id,ShortName,LastName FROM CONTACTS where ShortName is not null order by ShortName";
            try
            {
                using (SqlConnection sqlCn = new SqlConnection(connStr))
                {
                    sqlCn.Open();
                    using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                    {
                        SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                        DataSet ds = new DataSet();
                        sqlda.Fill(ds);

                        DataTable data = new DataTable();
                        //data.Columns.Add(new DataColumn("Value", typeof(int)));
                        //data.Columns.Add(new DataColumn("Description", typeof(string)));

                        data.Columns.Add(new DataColumn("Value", typeof(string)));
                        data.Columns.Add(new DataColumn("Description", typeof(string)));
                        for (int l = 0; l < ds.Tables[0].Rows.Count; l++)
                        {
                            data.Rows.Add(ds.Tables[0].Rows[l][1].ToString(), ds.Tables[0].Rows[l][1].ToString());
                        }

                        DataGridViewComboBoxColumn colCboxCategory = new DataGridViewComboBoxColumn();
                        colCboxCategory.Name = "Staff";
                        colCboxCategory.HeaderText = "Handling By*";
                        colCboxCategory.DataSource = data;
                        colCboxCategory.ValueMember = "Value";
                        colCboxCategory.DisplayMember = "Description";
                        colCboxCategory.Width = 180;


                        //Added By Varun
                        colCboxCategory.DisplayStyle = DataGridViewComboBoxDisplayStyle.DropDownButton;
                        dgvContracts.EnableHeadersVisualStyles = true;
                        colCboxCategory.DataPropertyName = "StaffInCharge";
                        dgvContracts.Columns.Add(colCboxCategory);
                        dgvContracts.DataError += new DataGridViewDataErrorEventHandler(dgvContracts_DataError);

                        // Commented By Varun

                        //colCboxCategory.DisplayStyle = DataGridViewComboBoxDisplayStyle.Nothing;
                        //dgvContracts.Columns.Add(colCboxCategory);
                        //dgvContracts.DataError += new DataGridViewDataErrorEventHandler(dgvContracts_DataError);
                        //dgvContracts.EnableHeadersVisualStyles = false;
                    }
                    sqlCn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void CreateColumnsForCP_Contractors(ref DataGridView dgvContracts, int cp_PrjiD)
        {
            DataGridViewTextBoxColumn colCboxCategory = new DataGridViewTextBoxColumn();
            colCboxCategory.Name = "CmpName";
            colCboxCategory.HeaderText = "Successfull Bidder*";
            colCboxCategory.Width = 180;
            colCboxCategory.ReadOnly = true;
            dgvContracts.Columns.Add(colCboxCategory);

            DataGridViewTextBoxColumn colCboxCategory2 = new DataGridViewTextBoxColumn();
            colCboxCategory2.Name = "Amount";
            colCboxCategory2.HeaderText = "Award Amount";
            colCboxCategory2.Width = 50;
            colCboxCategory2.ReadOnly = true;
            dgvContracts.Columns.Add(colCboxCategory2);

            CalendarColumn colCboxCategory3 = new CalendarColumn();
            colCboxCategory3.Name = "AwardLetter";
            colCboxCategory3.HeaderText = "Date of Letter of Award";
            colCboxCategory3.Width = 50;
            colCboxCategory3.ReadOnly = true;
            dgvContracts.Columns.Add(colCboxCategory3);

            CreateStaff_ComboBoxForGrid(dgvContracts);

            CalendarColumn colForRecAwrdDoc = new CalendarColumn();
            colForRecAwrdDoc.Name = "RecAwardDocument";
            colForRecAwrdDoc.HeaderText = "Received of Award Document";
            colForRecAwrdDoc.Width = 50;
            dgvContracts.Columns.Add(colForRecAwrdDoc);

            CalendarColumn colForReqDept = new CalendarColumn();
            colForReqDept.Name = "ReqDept";
            colForReqDept.HeaderText = "Request Dept to provide Start Date";
            colForReqDept.Width = 50;
            dgvContracts.Columns.Add(colForReqDept);

            CalendarColumn colForStartDateRec = new CalendarColumn();
            colForStartDateRec.Name = "strtDateRec";
            colForStartDateRec.HeaderText = "Start Date Received";
            colForStartDateRec.Width = 50;
            dgvContracts.Columns.Add(colForStartDateRec);

            CalendarColumn colForNoticeSent = new CalendarColumn();
            colForNoticeSent.Name = "NtcSent";
            colForNoticeSent.HeaderText = "Notice Sent to Tenderer to Sign";
            colForNoticeSent.Width = 50;
            dgvContracts.Columns.Add(colForNoticeSent);

            CalendarColumn colForDueDate = new CalendarColumn();
            colForDueDate.Name = "pBond";
            colForDueDate.HeaderText = "Due date of Submission of Bond and Sign";                 //Due date of Submission of p.Bond, etc.Signinig of Contract
            colForDueDate.Width = 50;
            dgvContracts.Columns.Add(colForDueDate);
            
            DataGridViewTextBoxColumn colCboxBidder = new DataGridViewTextBoxColumn();
            colCboxBidder.Name = "BidID";
            colCboxBidder.HeaderText = "BidderID";
            colCboxBidder.Width = 180;
            colCboxBidder.ReadOnly = true;
            dgvContracts.Columns.Add(colCboxBidder);
            
            //Newly added on NOv 21st 2013 by sreedhar
            DataGridViewTextBoxColumn colCboxProjID = new DataGridViewTextBoxColumn();
            colCboxProjID.Name = "ProjID";
            colCboxProjID.HeaderText = "ProjID";
            colCboxProjID.Width = 180;
            colCboxProjID.ReadOnly = true;
            dgvContracts.Columns.Add(colCboxProjID);

            dgvContracts.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            dgvContracts.DataError += new DataGridViewDataErrorEventHandler(dgvContracts_DataError);
            dgvContracts.RowTemplate.Height =35;
            dgvContracts.ColumnHeadersDefaultCellStyle.BackColor = Color.Gainsboro;
            dgvContracts.ColumnHeadersDefaultCellStyle.ForeColor = Color.Chocolate; 
            dgvContracts.ColumnHeadersDefaultCellStyle.Font = new Font(dgvContracts.Font, FontStyle.Regular);
            dgvContracts.EnableHeadersVisualStyles = false;
            dgvContracts.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            
        }
        // Modified By Varun on Nov 21st
        public void FillContractsGrid(ref DataGridView dgvCntr, int cp_prjiD)
        {
            string strQuery = "";
            string strStaffInCharge = "";
            if (dgvCntr.Rows.Count != 0)
            {
                dgvCntr.Rows.Clear();
                //int rowCounter = 0;
                //while (rowCounter < dgvCntr.Rows.Count)
                //{
                //    dgvCntr.Rows.RemoveAt(rowCounter);
                //    rowCounter++;
                //}
            }
            strQuery = "SELECT COMPANY.co_name, CONTRACTORS.ContractAmount, CONTRACTORS.cp_tender_award, CONTRACTORS.StaffInCharge, " +
            " CONTRACTORS.cp_received_of_doc, CONTRACTORS.cp_request_start_date, CONTRACTORS.cp_start_date_receive, " +
            " CONTRACTORS.cp_notice_contractor_to_sign, CONTRACTORS.cp_due_date_pb,CONTRACTORS.bidder_id,CONTRACTORS.proj_id FROM CONTRACTORS INNER JOIN " +
            " COMPANY ON CONTRACTORS.co_id = COMPANY.co_id WHERE (CONTRACTORS.proj_id = " + cp_prjiD + " and CONTRACTORS.stage_Id = 4 and CONTRACTORS.cp_tender_award is Not Null)";

            using (SqlConnection sqlCn = new SqlConnection(connStr))

            {
                sqlCn.Open();
                int rowCounter = 0;
                //Modified By Varun
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    SqlDataReader sqlReader = sqlCmd.ExecuteReader();
                    //if (sqlReader.HasRows)
                    //{
                        while (sqlReader.Read())
                        {
                            dgvCntr.Rows.Add();
                            dgvCntr.Rows[rowCounter].Cells[0].Value = sqlReader["co_name"];

                            dgvCntr.Rows[rowCounter].Cells[1].Value = sqlReader["ContractAmount"];
                            dgvCntr.Rows[rowCounter].Cells[2].Value = sqlReader["cp_tender_award"];

                            strStaffInCharge = sqlReader["StaffInCharge"].ToString();
                            dgvCntr.Rows[rowCounter].Cells[3].Value = strStaffInCharge;
                            DataGridViewComboBoxColumn dgvColBoxCol = null;
                            if (strStaffInCharge != "")
                            {
                                dgvColBoxCol = ColCmbBoxCategory;
                                if(!dgvColBoxCol.Items.Contains(strStaffInCharge))
                                    dgvColBoxCol.Items.Add(strStaffInCharge);                                
                            }

                            dgvCntr.Rows[rowCounter].Cells[4].Value = sqlReader["cp_received_of_doc"];
                            dgvCntr.Rows[rowCounter].Cells[5].Value = sqlReader["cp_request_start_date"];
                            dgvCntr.Rows[rowCounter].Cells[6].Value = sqlReader["cp_start_date_receive"];
                            dgvCntr.Rows[rowCounter].Cells[7].Value = sqlReader["cp_notice_contractor_to_sign"];
                            dgvCntr.Rows[rowCounter].Cells[8].Value = sqlReader["cp_due_date_pb"];
                            dgvCntr.Rows[rowCounter].Cells[9].Value = sqlReader["bidder_id"];
                            dgvCntr.Rows[rowCounter].Cells[10].Value = sqlReader["proj_id"];                           
                            rowCounter++;
                            if (dgvColBoxCol != null)
                            {
                                dgvColBoxCol.Selected = true;
                                dgvCntr.CommitEdit(DataGridViewDataErrorContexts.Commit);
                            }
                        }
                    //}
                    sqlReader.Close();

                    //dgvCntr.AllowUserToAddRows = true;
                    dgvCntr.DataError += new DataGridViewDataErrorEventHandler(dgvContracts_DataError);
                }
                sqlCn.Close();
            }
            dgvCntr.Columns[9].Visible = false;
            dgvCntr.Columns[10].Visible = false;

            //ClearDatesOf_dgvContracts(dgvCntr);
            dgvCntr.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
        }

        public void FillContractsGrid_Old(DataGridView dgvCntr, int cp_prjiD)
        {
            string strQuery = "";
            
            strQuery = "SELECT COMPANY.co_name, CONTRACTORS.ContractAmount, CONTRACTORS.cp_tender_award, CONTRACTORS.StaffInCharge, " +
                      " CONTRACTORS.cp_received_of_doc, CONTRACTORS.cp_request_start_date, CONTRACTORS.cp_start_date_receive, " +
                      " CONTRACTORS.cp_notice_contractor_to_sign, CONTRACTORS.cp_due_date_pb,CONTRACTORS.bidder_id,CONTRACTORS.proj_id FROM CONTRACTORS INNER JOIN " +
                      " COMPANY ON CONTRACTORS.co_id = COMPANY.co_id WHERE (CONTRACTORS.proj_id = " + cp_prjiD + ")";

            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                    DataSet ds = new DataSet();
                    sqlda.Fill(ds);
                    dgvCntr.AllowUserToAddRows = false;

                    dgvCntr.Columns[0].DataPropertyName = "co_name";
                    dgvCntr.Columns[1].DataPropertyName = "ContractAmount";
                    dgvCntr.Columns[2].DataPropertyName = "cp_tender_award";

                   

                    dgvCntr.Columns[3].DataPropertyName = "StaffInCharge";

                    dgvCntr.Columns[4].DataPropertyName = "cp_received_of_doc";
                    dgvCntr.Columns[5].DataPropertyName = "cp_request_start_date";
                    dgvCntr.Columns[6].DataPropertyName = "cp_start_date_receive";
                    dgvCntr.Columns[7].DataPropertyName = "cp_notice_contractor_to_sign";
                    dgvCntr.Columns[8].DataPropertyName = "cp_due_date_pb";
                    dgvCntr.Columns[9].DataPropertyName = "bidder_id";
                    dgvCntr.Columns[10].DataPropertyName ="proj_id";

                    dgvCntr.DataSource = ds.Tables[0];

                    dgvCntr.AllowUserToAddRows = true;


                    dgvCntr.DataError += new DataGridViewDataErrorEventHandler(dgvContracts_DataError);
                }
                sqlCn.Close();
            }
            dgvCntr.Columns[9].Visible = false;
            dgvCntr.Columns[10].Visible = false;

            ClearDatesOf_dgvContracts(dgvCntr);

            dgvCntr.DefaultCellStyle.WrapMode = DataGridViewTriState.True; 
        }
        private void ClearDatesOf_dgvContracts(DataGridView dgvContracts)
        {
            try
            {
                for (int i = 0; i < dgvContracts.Rows.Count; i++)
                {
                    if (i == (dgvContracts.Rows.Count - 1))
                    {
                        //dgvContracts.Rows[i].Cells[1].Value = "";
                        dgvContracts.Rows[i].Cells[2].Value = "";
                        //dgvContracts.Rows[i].Cells[3].Value = "";
                        dgvContracts.Rows[i].Cells[4].Value = "";
                        dgvContracts.Rows[i].Cells[5].Value = "";
                        dgvContracts.Rows[i].Cells[6].Value = "";
                        dgvContracts.Rows[i].Cells[7].Value = "";
                        dgvContracts.Rows[i].Cells[8].Value = "";


                       
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void ClearDatesOf_dgvCpDataEntry(DataGridView dgvCpDataEntry)
        {
            try
            {
                for (int i = 0; i < dgvCpDataEntry.Rows.Count; i++)
                {
                    if (i == (dgvCpDataEntry.Rows.Count - 1))
                    {
                        dgvCpDataEntry.Rows[i].Cells[1].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[2].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[3].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[4].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[5].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[6].Value = "";
                        //dgvCpDataEntry.Rows[i].Cells[8].Value = "";             
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void CreateColumnsForCP_ContractorsMultiple(DataGridView dgvCpDataEntry, int cp_PrjiD)
        {
            DataGridViewTextBoxColumn colCboxCategory = new DataGridViewTextBoxColumn();
            colCboxCategory.Name = "CmpName";
            colCboxCategory.HeaderText = "Successfull Bidder*";
            colCboxCategory.Width = 180;
            colCboxCategory.ReadOnly = true;
            dgvCpDataEntry.Columns.Add(colCboxCategory);

            CalendarColumn colCboxCategory2 = new CalendarColumn();
            colCboxCategory2.Name = "AwardLetter";
            colCboxCategory2.HeaderText = "Date of Sign Contract";          
            colCboxCategory2.Width = 50;
            dgvCpDataEntry.Columns.Add(colCboxCategory2);

            CalendarColumn colCboxCategory3 = new CalendarColumn();
            colCboxCategory3.Name = "SignatureFromDept";
            colCboxCategory3.HeaderText = "Sent to dept for Signature";
            colCboxCategory3.Width = 50;
            dgvCpDataEntry.Columns.Add(colCboxCategory3);

            //CreateStaff_ComboBoxForGrid(dgvCpMulti);

            CalendarColumn colForRecAwrdDoc = new CalendarColumn();
            colForRecAwrdDoc.Name = "RecAwardDocument";
            colForRecAwrdDoc.HeaderText = "Received from Dept for PRSD Sign";         //Received from Dept. and Sent to PRSD. for Sign
            colForRecAwrdDoc.Width = 50;
            dgvCpDataEntry.Columns.Add(colForRecAwrdDoc);

            CalendarColumn colForReqDept = new CalendarColumn();
            colForReqDept.Name = "ReqDept";
            colForReqDept.HeaderText = "Sent to Finance Dept for Committment";
            colForReqDept.Width = 50;
            dgvCpDataEntry.Columns.Add(colForReqDept);

            CalendarColumn colForStartDateRec = new CalendarColumn();
            colForStartDateRec.Name = "strtDateRec";
            colForStartDateRec.HeaderText = "Received From Finance Dept";
            colForStartDateRec.Width = 50;
            dgvCpDataEntry.Columns.Add(colForStartDateRec);

            CalendarColumn colForNoticeSent = new CalendarColumn();
            colForNoticeSent.Name = "NtcSent";
            colForNoticeSent.HeaderText = "Distribution";
            colForNoticeSent.Width = 50;
            dgvCpDataEntry.Columns.Add(colForNoticeSent);

            DataGridViewTextBoxColumn colCboxCntrNo = new DataGridViewTextBoxColumn();
            colCboxCntrNo.Name = "CntrNo";
            colCboxCntrNo.HeaderText = "Contract No";
            colCboxCntrNo.Width = 180;           
            dgvCpDataEntry.Columns.Add(colCboxCntrNo);

            DataGridViewTextBoxColumn colCboxRemarks = new DataGridViewTextBoxColumn();
            colCboxRemarks.Name = "Remarks";
            colCboxRemarks.HeaderText = "Remarks";
            colCboxRemarks.Width = 180;
            dgvCpDataEntry.Columns.Add(colCboxRemarks);

            DataGridViewTextBoxColumn colCboxBidder = new DataGridViewTextBoxColumn();
            colCboxBidder.Name = "BidID";
            colCboxBidder.HeaderText = "BidderID";
            colCboxBidder.Width = 180;
            colCboxBidder.ReadOnly = true;
            dgvCpDataEntry.Columns.Add(colCboxBidder);

         //   dgvCpMulti.DataError += new DataGridViewDataErrorEventHandler(dgvCpMulti_DataError);

            dgvCpDataEntry.ColumnHeadersDefaultCellStyle.BackColor = Color.Gainsboro;
            dgvCpDataEntry.ColumnHeadersDefaultCellStyle.ForeColor = Color.Chocolate;
            dgvCpDataEntry.ColumnHeadersDefaultCellStyle.Font = new Font(dgvCpDataEntry.Font, FontStyle.Regular);        
            dgvCpDataEntry.EnableHeadersVisualStyles = false;
            dgvCpDataEntry.RowTemplate.Height = 35;
            dgvCpDataEntry.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dgvCpDataEntry.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
        }
        public void FillContractsGrid_Multiple(DataGridView dgvCpMulti, int cp_prjiD)
        {
            string strQuery = "";
            strQuery = "SELECT COMPANY.co_name, CONTRACTORS.cp_contractor_sign, CONTRACTORS.cp_sent_dep_sign, CONTRACTORS.cp_receive_dep_sent_prsd, " +
                      " CONTRACTORS.cp_sent_fd_commit, CONTRACTORS.cp_receive_fd_commit, CONTRACTORS.cp_distribution, CONTRACTORS.contract_no, " +
                      " CONTRACTORS.Remarks, CONTRACTORS.bidder_id FROM CONTRACTORS INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id " +
                      " WHERE (CONTRACTORS.proj_id = " + cp_prjiD + " and CONTRACTORS.stage_Id=4 and CONTRACTORS.cp_tender_award is not NULL)";

            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                    DataSet ds = new DataSet();
                    sqlda.Fill(ds);
                    DataTable dtContractors = ds.Tables[0];
                    dgvCpMulti.AllowUserToAddRows = false;
                    dgvCpMulti.Columns[0].DataPropertyName = "co_name";
                    dgvCpMulti.Columns[1].DataPropertyName = "cp_contractor_sign";
                    dgvCpMulti.Columns[2].DataPropertyName = "cp_sent_dep_sign";
                    dgvCpMulti.Columns[3].DataPropertyName = "cp_receive_dep_sent_prsd";
                    dgvCpMulti.Columns[4].DataPropertyName = "cp_sent_fd_commit";
                    dgvCpMulti.Columns[5].DataPropertyName = "cp_receive_fd_commit";
                    dgvCpMulti.Columns[6].DataPropertyName = "cp_distribution";
                    dgvCpMulti.Columns[7].DataPropertyName = "contract_no";
                    dgvCpMulti.Columns[8].DataPropertyName = "Remarks";
                    dgvCpMulti.Columns[9].DataPropertyName = "bidder_id";
                    dgvCpMulti.DataSource = ds.Tables[0];

                    int rowCounter = 0;
                    while (rowCounter < dtContractors.Rows.Count)
                    {                         
                        dgvCpMulti.Columns[8].ToolTipText = dtContractors.Rows[rowCounter][8].ToString(); // No. 8 is equalent to Remarks Column
                        rowCounter++;
                    }
                     
                    
                    //dgvCpMulti.AllowUserToAddRows = true;
                    //dgvCpMulti.DataError += new DataGridViewDataErrorEventHandler(dgvContracts_DataError);
                }
                sqlCn.Close();
            }
            //dgvCntr.Columns[5].Visible = false;
            dgvCpMulti.Columns[9].Visible = false;
           
            
            //ClearDatesOf_dgvCpDataEntry(dgvCpMulti);
        }

    }
}
