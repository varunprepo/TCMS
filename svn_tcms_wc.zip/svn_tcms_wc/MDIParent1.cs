﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

using DataGridViewAutoFilter;
using MDI_ParenrForm.Contacts;
using TenderTrackingSystem;
using WindowsFormsApplication1;

namespace MDI_ParenrForm
{
    public partial class MDIParent1 : Form
    {
        public MDIParent1(string userName)
        {
            InitializeComponent();
        }
        private void ShowNewForm(object sender, EventArgs e)
        {
            //Form childForm = new Form();
            //childForm.MdiParent = this;
            //childForm.Text = "Window " + childFormNumber++;
            //childForm.Show();
        }
        private void OpenFile(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = openFileDialog.FileName;
            }
        }
        private void SaveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            saveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = saveFileDialog.FileName;
            }
        }
        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void CascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        private void TileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }

        private void TileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void ArrangeIconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.ArrangeIcons);
        }

        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }      
        private void nameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmContactsDefault frmDef_Contacts = new frmContactsDefault();
            frmDef_Contacts.StartPosition = FormStartPosition.CenterScreen;
            frmDef_Contacts.ShowDialog();
        }
        private void companyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Contacts.frmCompanyContacts frmDef_Contacts = new frmCompanyContacts();
            frmDef_Contacts.StartPosition = FormStartPosition.CenterScreen;
            frmDef_Contacts.ShowDialog();
        }
        private void commitedProjectsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Projects.frmOngoingContracts OnGoingProjects = new MDI_ParenrForm.Projects.frmOngoingContracts();
            OnGoingProjects.StartPosition = FormStartPosition.CenterParent;
            OnGoingProjects.ShowDialog();

        }
        private void projectsOnTenderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DefaultView frmDefault = new DefaultView("Varun");
            ScaleDown(frmDefault);
            frmDefault.StartPosition = FormStartPosition.CenterScreen;
            frmDefault.Show();

            //DefaultView frmDefault = new DefaultView("Varun");
            //ScaleDown(frmDefault);
            //frmDefault.StartPosition = FormStartPosition.CenterScreen;
            //frmDefault.Show();

        }
        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            WindowsFormsApplication1.Form1 frmDefault = new WindowsFormsApplication1.Form1();
            frmDefault.StartPosition = FormStartPosition.CenterScreen;
            frmDefault.Show();
        }
        private void MDIParent1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dBTestDataSet.AFFAIRS' table. You can move, or remove it, as needed.
            this.aFFAIRSTableAdapter.Fill(this.dBTestDataSet.AFFAIRS);

            FillButtonsInfo();
        }
        private void committedProjectsClosedOthersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Projects.frmInactiveProjects contractorInfo = new MDI_ParenrForm.Projects.frmInactiveProjects();
            contractorInfo.StartPosition = FormStartPosition.CenterParent;
            contractorInfo.ShowDialog();
        }
        private void communicationsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Documents.frmCommunicationsOrg docCommunications = new MDI_ParenrForm.Documents.frmCommunicationsOrg();
            docCommunications.StartPosition = FormStartPosition.CenterParent;
            docCommunications.ShowDialog();
        }
        private void usersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Admin.frmUsers usersList = new MDI_ParenrForm.Admin.frmUsers();
            usersList.StartPosition = FormStartPosition.CenterParent;
            usersList.ShowDialog();
        }       
        public static void ScaleDown(System.Windows.Forms.Form frm) 
        { 
          int scrWidth = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width; 
          int scrHeight = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height; 
          if (scrWidth < frm.Width) 
          { 
                foreach (System.Windows.Forms.Control cntrl in frm.Controls) 
                { 
                    cntrl.Width = ((cntrl.Width) * (scrWidth)) / (frm.Width); 
                    cntrl.Left = ((cntrl.Left) * (scrWidth)) / (frm.Width); 
                } 
          }
         if (scrHeight < frm.Height) 
         { 
            foreach (System.Windows.Forms.Control cntrl in frm.Controls) 
            { 
                cntrl.Height = ((cntrl.Height) * (scrHeight)) / (frm.Height); 
                cntrl.Top = ((cntrl.Top) * (scrHeight)) / (frm.Height); 
            } 
         } 
       }    

       List<string> AllProjects = new List<string>();
       List<string> Admin = new List<string>();
       List<string> Documents = new List<string>();
       List<string> Reports = new List<string>();
       List<string> Contacts = new List<string>();
       Button btn;

       private void FillButtonsInfo()
       {
           AllProjects.Add("PWA Projects");
           AllProjects.Add("Ongoing Contracts");
           AllProjects.Add("Inactive Contracts");

           Contacts.Add("Company");
           Contacts.Add("Contacts");

           Documents.Add("Communication");
           Documents.Add("Word Document");
           Documents.Add("Forms");

           Admin.Add("Users");
           Admin.Add("Security Profiles");
           Admin.Add("Security Codes");

           Reports.Add("Tender Reports");
           Reports.Add("Statistic");
       }


       private void CreateDynamicButtons(List<string> moduleData)
       {
           int j = 0;
           for (int i = 0; i <= moduleData.Count - 1; i++)      //115, 32 //144,1
           {
               j = j + 130;
               btn = new Button();
               btn.Location = new Point(3 + j, 1);  // 337, 56
               btn.Size = new Size(125, 32);
               btn.Text = moduleData[i];
               btn.Font = new Font(btn.Font, FontStyle.Bold);
               btn.BackColor = Color.Gray;
               btn.ForeColor = Color.Black;

               btn.Click += new EventHandler(btn_Click);
               splitContainer1.Panel2.Controls.Add(btn);
           } 
       }
       private void btn_Click(object sender, EventArgs e)
       {
           Button btnDummy = sender as Button;
           btnDummy.ForeColor = Color.Tomato;

           foreach (Control item in splitContainer1.Panel2.Controls)
           {
               Button chkBtn = item as Button;
               if (chkBtn.Text.Trim() != btnDummy.Text.Trim())
               {
                   chkBtn.ForeColor = Color.Black;
                   chkBtn.BackColor = Color.Gray;
               }
           }
           if (btnDummy.Text == "PWA Projects")
           {
               // Projects.DefaultProjects defaultPrj = new MDI_ParenrForm.Projects.DefaultProjects("Varun");

               DefaultView defaultPrj = new DefaultView("Varun");
               defaultPrj.StartPosition = FormStartPosition.CenterParent;
               defaultPrj.ShowDialog();
           }
           if (btnDummy.Text == "Ongoing Contracts")
           {
               Projects.frmOngoingContracts OnGoingProjects = new MDI_ParenrForm.Projects.frmOngoingContracts();
               OnGoingProjects.StartPosition = FormStartPosition.CenterParent;
               OnGoingProjects.ShowDialog();
           }
           if (btnDummy.Text == "Inactive Contracts")
           {
               Projects.frmInactiveProjects contractorInfo = new MDI_ParenrForm.Projects.frmInactiveProjects();
               contractorInfo.StartPosition = FormStartPosition.CenterParent;
               contractorInfo.ShowDialog();
           }
           if (btnDummy.Text == "Company")
           {
               Contacts.frmCompanyContacts frmDef_Contacts = new frmCompanyContacts();
               frmDef_Contacts.StartPosition = FormStartPosition.CenterScreen;
               frmDef_Contacts.ShowDialog();
           }
           if (btnDummy.Text == "Contacts")
           {
               frmContactsDefault frmDef_Contacts = new frmContactsDefault();
               frmDef_Contacts.StartPosition = FormStartPosition.CenterScreen;
               frmDef_Contacts.ShowDialog();
           }
           if (btnDummy.Text == "Inactive Contracts")
           {
               Projects.frmInactiveProjects contractorInfo = new MDI_ParenrForm.Projects.frmInactiveProjects();
               contractorInfo.StartPosition = FormStartPosition.CenterParent;
               contractorInfo.ShowDialog();
           }
           if (btnDummy.Text == "Communication")
           {
               Documents.frmCommunications frmComm = new Documents.frmCommunications();
               frmComm.StartPosition = FormStartPosition.CenterParent;
               frmComm.ShowDialog();
           }
       }    

       private void btnDashboard_Click(object sender, EventArgs e)
       {
           splitContainer1.Panel2.Controls.Clear();

           btnDashboard.BackColor = Color.Green;
           btnDashboard.ForeColor = Color.YellowGreen;

           btnProjects.ForeColor = Color.Gray;
           btnDocuments.ForeColor = Color.Gray;
           btnContacts.ForeColor = Color.Gray;
           btnReports.ForeColor = Color.Gray;
           btnAdmin.ForeColor = Color.Gray;

           btnProjects.BackColor = Color.LightGray;      //LightGray
           btnDocuments.BackColor = Color.LightGray;
           btnContacts.BackColor = Color.LightGray;
           btnReports.BackColor = Color.LightGray;
           btnAdmin.BackColor = Color.LightGray;

           WindowsFormsApplication1.Form1 frmDefault = new WindowsFormsApplication1.Form1();
           frmDefault.StartPosition = FormStartPosition.CenterScreen;
           frmDefault.Show();
       }
       private void btnProjects_Click(object sender, EventArgs e)
       {
           splitContainer1.Panel2.Controls.Clear();

           btnProjects.BackColor = Color.Green;
           btnProjects.ForeColor = Color.YellowGreen;

           btnDashboard.ForeColor = Color.Gray;      //LightGray            
           btnDocuments.ForeColor = Color.Gray;
           btnContacts.ForeColor = Color.Gray;
           btnReports.ForeColor = Color.Gray;
           btnAdmin.ForeColor = Color.Gray;

           btnDashboard.BackColor = Color.LightGray;      //LightGray
           btnDocuments.BackColor = Color.LightGray;
           btnContacts.BackColor = Color.LightGray;
           btnReports.BackColor = Color.LightGray;
           btnAdmin.BackColor = Color.LightGray;

           CreateDynamicButtons(AllProjects);
       }
       private void btnDocuments_Click(object sender, EventArgs e)
       {
           splitContainer1.Panel2.Controls.Clear();
         
           btnDocuments.BackColor = Color.Green;
           btnDocuments.ForeColor = Color.YellowGreen;

           btnDashboard.ForeColor = Color.Gray;
           btnProjects.ForeColor = Color.Gray;
           btnContacts.ForeColor = Color.Gray;
           btnReports.ForeColor = Color.Gray;
           btnAdmin.ForeColor = Color.Gray;

           btnDashboard.BackColor = Color.LightGray;      //LightGray
           btnProjects.BackColor = Color.LightGray;
           btnContacts.BackColor = Color.LightGray;
           btnReports.BackColor = Color.LightGray;
           btnAdmin.BackColor = Color.LightGray;

           CreateDynamicButtons(Documents);
       }
       private void btnContacts_Click(object sender, EventArgs e)
       {
           splitContainer1.Panel2.Controls.Clear();
         

           btnContacts.BackColor = Color.Green;
           btnContacts.ForeColor = Color.YellowGreen;

           btnDashboard.ForeColor = Color.Gray;
           btnDocuments.ForeColor = Color.Gray;
           btnProjects.ForeColor = Color.Gray;
           btnReports.ForeColor = Color.Gray;
           btnAdmin.ForeColor = Color.Gray;

           btnDashboard.BackColor = Color.LightGray;      //LightGray
           btnProjects.BackColor = Color.LightGray;
           btnDocuments.BackColor = Color.LightGray;
           btnReports.BackColor = Color.LightGray;
           btnAdmin.BackColor = Color.LightGray;

           CreateDynamicButtons(Contacts);
       }
       private void btnReports_Click(object sender, EventArgs e)
       {
           splitContainer1.Panel2.Controls.Clear();

           btnReports.BackColor = Color.Green;
           btnReports.ForeColor = Color.YellowGreen;

           btnDashboard.ForeColor = Color.Gray;
           btnDocuments.ForeColor = Color.Gray;
           btnContacts.ForeColor = Color.Gray;
           btnProjects.ForeColor = Color.Gray;
           btnAdmin.ForeColor = Color.Gray;

           btnDashboard.BackColor = Color.LightGray;      //LightGray
           btnProjects.BackColor = Color.LightGray;
           btnDocuments.BackColor = Color.LightGray;
           btnContacts.BackColor = Color.LightGray;
           btnAdmin.BackColor = Color.LightGray;

           CreateDynamicButtons(Reports);
       }
       private void btnAdmin_Click(object sender, EventArgs e)
       {
           splitContainer1.Panel2.Controls.Clear();


           btnAdmin.BackColor = Color.Green;
           btnAdmin.ForeColor = Color.YellowGreen;

           btnDashboard.ForeColor = Color.Gray;
           btnDocuments.ForeColor = Color.Gray;
           btnContacts.ForeColor = Color.Gray;
           btnReports.ForeColor = Color.Gray;
           btnProjects.ForeColor = Color.Gray;

           btnDashboard.BackColor = Color.LightGray;      //LightGray
           btnProjects.BackColor = Color.LightGray;
           btnDocuments.BackColor = Color.LightGray;
           btnContacts.BackColor = Color.LightGray;
           btnReports.BackColor = Color.LightGray;

           CreateDynamicButtons(Admin);
       }          
    }
}
