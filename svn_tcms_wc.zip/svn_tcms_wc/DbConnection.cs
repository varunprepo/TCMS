﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;


namespace MDI_ParenrForm
{   
    class DbConnection
    {
        public static string connStr = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();


        public static void db_Update_Delete_Query(string strQuery)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connStr))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(strQuery, connection);
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception)
            {
                strQuery = strQuery.Replace("'", "''");
                using (SqlConnection connection = new SqlConnection(connStr))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand("Insert into tblSqlErrors values ('" + strQuery + "')", connection);
                    command.ExecuteNonQuery();
                }
            }
        }
    }
}
