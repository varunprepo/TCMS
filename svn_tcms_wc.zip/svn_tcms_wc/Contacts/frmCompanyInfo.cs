﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using DataGridViewAutoFilter;
using System.Configuration;
using System.Data.SqlClient;
using TenderTrackingSystem.Contacts;
using TenderTrackingSystem;
using System.Globalization;

namespace MDI_ParenrForm.Contacts
{
    public partial class frmCompanyContacts : Form
    {
        int mintTotalRecords = 0;
        int mintPageSize = 0;
        int mintPageCount = 0;
        int mintCurrentPage = 1;

        static string staticUserName = null;
        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();

        // Protected Connection.
        protected SqlConnection sqlConn;
        protected SqlCommand sqlCom;

        protected SqlDataReader sqlReader;
        private System.Windows.Forms.Label label1;
        //decimal bdgtEstimated = 0;
        CreateCheckBox chkBox = null;
        CheckBox headerCheckBox = null;
        BindingSource myBindingSource = null;
        DataTable dtTemp = null;
        CommonClass comCls = null;
        IList<string> userRightsColl = new List<string>();
        string _userName = string.Empty;

        public frmCompanyContacts(IList<string> userRightsCollCompany,string user)
        {
            InitializeComponent();
            userRightsColl = userRightsCollCompany;
            _userName = user;
        }

        private void frmCompanyContacts_Load(object sender, EventArgs e)
        {
            try
            {
                rePopulateDataGridView_Contact_EntryData("Admin");            
                DAL dalObj = new DAL();
                dalObj.populateCmbBox("Select co_type_name From COMPANY_TYPE Order by co_type_id", cmbType);
                cmbType.SelectedIndex = -1;

                dalObj.populateCmbBox("select co_category_name from COMPANY_CAT Order by co_category_id ", cmbCategory);
                cmbCategory.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while populating the companies list");
            }
            //comCls = new CommonClass(_userName);
        }
        private void rePopulateDataGridView_Contact_EntryData(string userName)
        {
            headerCheckBox = new CheckBox();
            chkBox = new CreateCheckBox(dgView, headerCheckBox);
            chkBox.AddHeaderCheckBox();

            if (dgView.Rows.Count > 0)
                return;
            staticUserName = userName;

            var col0 = new DataGridViewCheckBoxColumn();
            var col1 = new DataGridViewAutoFilterTextBoxColumn(); // DataGridViewLinkColumn; 
            var col2 = new DataGridViewAutoFilterTextBoxColumn();
            var col3 = new DataGridViewAutoFilterTextBoxColumn();
            var col4 = new DataGridViewAutoFilterTextBoxColumn();
            var col5 = new DataGridViewLinkColumn();
            var col6 = new DataGridViewLinkColumn();
            var col7 = new DataGridViewAutoFilterTextBoxColumn();
            col7.DefaultCellStyle.Format = "dd-MMM-yyyy";             
            var col8 = new DataGridViewAutoFilterTextBoxColumn();            
            dgView.Columns.AddRange(new DataGridViewColumn[] { col0, col1, col2, col3, col4, col5, col6, col7, col8 });
            //dgView.Columns[8].sty
            dgView.AutoGenerateColumns = false;
            dgView.AllowUserToAddRows = false;
            //dgvContacts.AutoResizeColumns();            

            col0.Name = "chkBxSelect";
            col0.DataPropertyName = "Select";
            col0.HeaderText = "";
            col0.Width = 45;

            col1.DataPropertyName = "CompanyName";
            col1.HeaderText = "Company Name";
            col1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            col1.Width = 250;

            col2.DataPropertyName = "Company ShortName";
            col2.HeaderText = "Company ShortName";
            col2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            col2.Width = 80;

            col3.DataPropertyName = "Nationality";
            col3.HeaderText = "Nationality";
            col3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            col3.Width = 80;

            col4.DataPropertyName = "Telephone No.";
            col4.HeaderText = "Telephone No.";
            col4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            col4.Width = 110;

            col5.DataPropertyName = "Email Address";
            col5.HeaderText = "Email Address";
            col5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            col5.Width = 160;

            col6.DataPropertyName = "Web Page";
            col6.HeaderText = "Web Page";
            col6.Resizable = System.Windows.Forms.DataGridViewTriState.True;

            col7.DataPropertyName = "CommercialRegExpiryDate";
            col7.HeaderText = "CommercialRegExpiryDate";
            col7.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            
            col8.DataPropertyName = "Company ID";
            col8.HeaderText = "Company ID";
            col8.Resizable = System.Windows.Forms.DataGridViewTriState.True;

            BindingSource myBindingSource = null;
            DataTable finalDt = new DataTable("Company");
            finalDt.Columns.Add("Select");
            finalDt.Columns.Add("CompanyName");
            finalDt.Columns.Add("Company ShortName");
            finalDt.Columns.Add("Nationality");
            finalDt.Columns.Add("Telephone No.");
            finalDt.Columns.Add("Email Address");
            finalDt.Columns.Add("Web Page");
            finalDt.Columns.Add("CommercialRegExpiryDate",typeof (DateTime));
            finalDt.Columns.Add("Company ID");
            finalDt.Columns.Add("Category");
            finalDt.Columns.Add("CompanyType");

            sqlConn = new SqlConnection(strCon);
            sqlConn.Open();
            //string sqlQuery = "SELECT COMPANY.Co_Name, co_shortname, COMPANY.Co_Address, COMPANY_CAT.Co_Category_Name, COMPANY_TYPE.Co_Type_Name,COMPANY.Co_ID FROM COMPANY INNER JOIN COMPANY_CAT ON COMPANY.Co_Category_Id = COMPANY_CAT.Co_Category_Id INNER JOIN COMPANY_TYPE ON COMPANY.Co_Type_Id = COMPANY_TYPE.Co_Type_Id Where COMPANY.Co_ID <> 1 AND COMPANY.Co_ID <> 425 Order by co_name";
            DAL dalObj = new DAL();

            //DataTable dtCompany = dalObj.GetDataFromDB("Company", "SELECT replace(co_name,',','|') as co_name, replace(co_shortname,',','|') as co_shortname, replace(nationality,',','|') as nationality, replace(co_tel,',','|') as co_tel, "+
            //"replace(co_email_address,',','|') as co_email_address, replace(WebPage,',','|') as WebPage, replace(Replace(CONVERT(nvarchar,cr_expiry_date,106),' ','-'),',','|') as CommercialRegExpiryDate,co_id,co_category_id,co_type_id FROM COMPANY Where (co_id <> 1) AND (co_id <> 425)");

            //DataTable dtCmpCat = dalObj.GetDataFromDB("CompanyCat", "SELECT co_category_id,co_category_name FROM COMPANY_CAT");

            //DataTable dtCmpType = dalObj.GetDataFromDB("COMPANYTYPE", "SELECT co_type_id,co_type_name FROM COMPANY_TYPE");


            //IEnumerable<object> iEnum = null;
            //iEnum = (from cmp in dtCompany.AsEnumerable()
            //         join cmpCat in dtCmpCat.AsEnumerable() on cmp.Field<int?>("co_category_id") equals cmpCat.Field<int?>("co_category_id")
            //         join cmpType in dtCmpType.AsEnumerable() on cmp.Field<int?>("co_type_id") equals cmpType.Field<int?>("co_type_id")
            //         select new
            //         {
            //             CoName = cmp.Field<string>("co_name"),
            //             ShortName = cmp.Field<string>("co_shortname"),
            //             Nationality = cmp.Field<string>("nationality"),
            //             CoTel = cmp.Field<string>("co_tel"),
            //             CoEmailAddress = cmp.Field<string>("co_email_address"),
            //             WebPage = cmp.Field<string>("WebPage"),
            //             CommercialRegExpiryDate = cmp.Field<string>("CommercialRegExpiryDate"),
            //             CoId = cmp.Field<int>("co_id"),
            //             CoCategoryName = cmpCat.Field<string>("co_category_name"),
            //             CoTypeName = cmpType.Field<string>("co_type_Name")
            //         }).OrderByDescending(item => item.CoName).ToList();


            string sqlQuery = "SELECT  COMPANY.co_name, COMPANY.co_shortname, COMPANY.nationality, COMPANY.co_tel, COMPANY.co_email_address, " +
            " COMPANY.WebPage, Replace(CONVERT(nvarchar,cr_expiry_date,106),' ','/') as CommercialRegExpiryDate, COMPANY.co_id,COMPANY_CAT.Co_Category_Name, COMPANY_TYPE.Co_Type_Name FROM   COMPANY INNER JOIN  COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id INNER JOIN " +
            " COMPANY_TYPE ON COMPANY.co_type_id = COMPANY_TYPE.co_type_id WHERE (COMPANY.co_id <> 1) AND (COMPANY.co_id <> 425) ORDER BY COMPANY.co_name";

            try
            {
                DataTable dtCompany = dalObj.GetDataFromDB("Company", sqlQuery);
                foreach (DataRow drRow in dtCompany.Rows)
                {
                    DataRow dr = finalDt.NewRow();
                    dr[1] = drRow[0]; //co_name
                    dr[2] = drRow[1]; //co_shortname
                    dr[3] = drRow[2]; //nationality
                    dr[4] = drRow[3]; //co_tel
                    dr[5] = drRow[4]; //co_email_address
                    dr[6] = drRow[5]; //webpage
                    if (drRow[6].ToString().Trim() != "")
                    {
                        dr[7] = drRow[6];
                    }
                    else
                    {
                        dr[7] = System.DBNull.Value;
                    }
                    dr[8] = drRow[7];
                    dr[9] = drRow[8];
                    dr[10] = drRow[9];


                    //dr[1] = drCmp.ToString().Split(',')[0].Split('=')[1].Trim().Replace('|',',');    //co_name
                    //dr[2] = drCmp.ToString().Split(',')[1].Split('=')[1].Trim().Replace('|', ',');  //co_shortname
                    //dr[3] = drCmp.ToString().Split(',')[2].Split('=')[1].Trim().Replace('|', ',');      //nationality
                    //dr[4] = drCmp.ToString().Split(',')[3].Split('=')[1].Trim().Replace('|', ',');         //co_tel
                    //dr[5] = drCmp.ToString().Split(',')[4].Split('=')[1].Trim().Replace('|', ',');        //co_email_address
                    //dr[6] = drCmp.ToString().Split(',')[5].Split('=')[1].Trim().Replace('|', ',');     //webpage
                    //if (drCmp.ToString().Split(',')[6].Split('=')[1].Trim() != "")
                    //{
                    //    dr[7] = drCmp.ToString().Split(',')[6].Split('=')[1].Trim().Replace('|', ',');     //CommercialRegExpiryDate
                    //}
                    //else
                    //{
                    //    //dr[7] = new DateTime?();
                    //    dr[7] = System.DBNull.Value; // new DateTime?();
                    //}
                    //dr[8] = drCmp.ToString().Split(',')[7].Split('=')[1].Trim();     //Co_ID 
                    //dr[9] = drCmp.ToString().Split(',')[8].Split('=')[1].Trim();     //Co_Category_Name
                    //dr[10] = drCmp.ToString().Split(',')[9].Split('=')[1].Trim().Replace("}", "");     //Co_Type_Name 


                    //dr[1] = strProj;    //ProjectId
                    //dr[1] = drCmp.ToString().Split(',')[0].Split('=')[1].Trim() + " " + drCmp.ToString().Split(',')[1].Split('=')[1].Trim();  //FirstName
                    //dr[2] = drCmp.ToString().Split(',')[2].Split('=')[1].Trim();  //ProjectCode
                    //dr[3] = drCmp.ToString().Split(',')[3].Split('=')[1].Trim();  //ProjTitle                   

                    //dr[4] = drCmp.ToString().Split(',')[4].Split('=')[1].Trim();  //TenderNo
                    //dr[5] = drCmp.ToString().Split(',')[5].Split('=')[1].Trim();  //CurrentStage

                    //dr[6] = drCmp.ToString().Split(',')[6].Split('=')[1].Trim();  //TenderStatus
                    //dr[7] = drCmp.ToString().Split(',')[7].Split('=')[1].Trim();  //TypeOfTender

                    //dr[8] = drCmp.ToString().Split(',')[8].Split('=')[1].Trim();  //TenderCommittee
                    //dr[9] = drCmp.ToString().Split(',')[9].Split('=')[1].Trim();  //TypeofContract

                    //if ((!profile_Name.Equals("EBSD Staff") && userRightsColl.Contains("104")) && userRightsColl.Count != 0)
                    //{
                    //    //dr[10] = drProj[14];  //ContractNo 
                    //    dr[10] = drContact.ToString().Split(',')[9].Split('=')[1].Trim();  //FiscalYear
                    //    dr[11] = drContact.ToString().Split(',')[10].Split('=')[1].Trim();  //UserDepartment 
                    //    dr[12] = drContact.ToString().Split(',')[11].Split('=')[1].Trim();  //Qs 
                    //    dr[13] = drContact.ToString().Split(',')[12].Split('=')[1].Trim();  //Handl
                    //    dr[14] = drContact.ToString().Split(',')[13].Split('=')[1].Trim();  //Staff 
                    //    dr[15] = rowId;
                    //}
                    //else if (profile_Name.Equals("EBSD Staff"))
                    //{
                    //    dr[10] = drContact.ToString().Split(',')[14].Split('=')[1].Trim();  //ContractNo 
                    //    dr[11] = drContact.ToString().Split(',')[9].Split('=')[1].Trim();  //FiscalYear 
                    //    dr[12] = drContact.ToString().Split(',')[10].Split('=')[1].Trim();  //UserDepartment
                    //    dr[13] = drContact.ToString().Split(',')[11].Split('=')[1].Trim();  //Qs 
                    //    dr[14] = drContact.ToString().Split(',')[12].Split('=')[1].Trim();  //Handl
                    //    dr[15] = drContact.ToString().Split(',')[13].Split('=')[1].Trim();  //Staff 
                    //    //dr[16] = drProj[15];  //ProjCreateDate                           
                    //    //dr[17] = drProj[16];  //ProjUpdateDate                           
                    //    dr[16] = drContact.ToString().Split(',')[15].Split('=')[1].Trim();  //MozanahID                           
                    //    dr[17] = rowId;
                    //}
                    //else if ((!profile_Name.Equals("EBSD Staff") && !userRightsColl.Contains("104")) || userRightsColl.Count == 0)
                    //{
                    //    //string contractNo = drProj[14].ToString();
                    //    dr[10] = drContact.ToString().Split(',')[14].Split('=')[1].Trim(); //ContractNoWorkOrderNo

                    //    //if (contractNo.Contains("C") || contractNo.Contains("P"))
                    //    //{
                    //    //    contractNo = contractNo.Split('-')[0];
                    //    //    if(contractNo!="")
                    //    //    {
                    //    //        dr[11] = FindSuccessfulBidders(dalObj, drProj, contractNo);
                    //    //    }                            
                    //    //}

                    //    dr[11] = drContact.ToString().Split(',')[9].Split('=')[1].Trim();  //FiscalYear
                    //    dr[12] = drContact.ToString().Split(',')[10].Split('=')[1].Trim();  //UserDepartment 
                    //    dr[13] = drContact.ToString().Split(',')[11].Split('=')[1].Trim();  //Qs 
                    //    dr[14] = drContact.ToString().Split(',')[12].Split('=')[1].Trim();  //Handl
                    //    dr[15] = drContact.ToString().Split(',')[13].Split('=')[1].Trim();  //Staff 
                    //    dr[16] = rowId;

                    //    //dr[11] = drProj[9];  //FiscalYear
                    //    //dr[12] = drProj[10];  //UserDepartment 
                    //    //dr[13] = drProj[11];  //Qs 
                    //    //dr[14] = drProj[12];  //Handl
                    //    //dr[15] = drProj[13];  //Staff 
                    //    //dr[16] = rowId;                            

                    //}

                    //rowId++;
                    finalDt.Rows.Add(dr);
                    finalDt.AcceptChanges();
                }
            }
            catch (Exception ex)
            {
                string strEx = ex.ToString();                     
            }
               
            //finalDt.AcceptChanges();

            //sqlCom = new SqlCommand(sqlQuery, sqlConn);
            //sqlReader = sqlCom.ExecuteReader();

            //while (sqlReader.Read())
            //{
            //    DataRow dr = finalDt.NewRow();

            //    dr[1] = sqlReader[0];    //co_name
            //    dr[2] = sqlReader[1];  //co_shortname
            //    dr[3] = sqlReader[2];      //nationality
            //    dr[4] = sqlReader[3];         //co_tel
            //    dr[5] = sqlReader[4];        //co_email_address
            //    dr[6] = sqlReader[5];     //webpage
            //    dr[7] = sqlReader[6];     //Co_ID 

            //    dr[8] = sqlReader[7];     //Co_Category_Name
            //    dr[9] = sqlReader[8];     //Co_Type_Name 


            //    finalDt.Rows.Add(dr);
            //    finalDt.AcceptChanges();
            //}
            //sqlReader.Close();

            myBindingSource = new BindingSource(finalDt, null);
            dtTemp = finalDt;
            dgView.Columns[8].Visible = false;  
            dgView.DataSource = myBindingSource;     
            sqlConn.Close();
            lblCnt.Text = "Record Count:" + dgView.Rows.Count.ToString();

            headerCheckBox.KeyUp += new KeyEventHandler(chkBox.HeaderCheckBox_KeyUp);
            headerCheckBox.MouseClick += new MouseEventHandler(chkBox.HeaderCheckBox_MouseClick);
            dgView.CellContentClick += new DataGridViewCellEventHandler(chkBox.dgvSelectAll_CellContentClick);
            dgView.CurrentCellDirtyStateChanged += new EventHandler(chkBox.dgvSelectAll_CurrentCellDirtyStateChanged);
            dgView.CellPainting += new DataGridViewCellPaintingEventHandler(chkBox.dgvSelectAll_CellPainting);

        }

        //private void rePopulateDataGridView_Contact_EntryData(string userName)
        //{
        //    headerCheckBox = new CheckBox();
        //    chkBox = new CreateCheckBox(dgView, headerCheckBox);
        //    chkBox.AddHeaderCheckBox();

        //    if (dgView.Rows.Count > 0)
        //        return;
        //    staticUserName = userName;

        //    var col0 = new DataGridViewCheckBoxColumn();
        //    var col1 = new DataGridViewAutoFilterTextBoxColumn(); // DataGridViewLinkColumn; 
        //    var col2 = new DataGridViewAutoFilterTextBoxColumn();
        //    var col3 = new DataGridViewAutoFilterTextBoxColumn();
        //    var col4 = new DataGridViewAutoFilterTextBoxColumn();
        //    var col5 = new DataGridViewAutoFilterTextBoxColumn();
        //    var col6 = new DataGridViewAutoFilterTextBoxColumn();


        //    dgView.Columns.AddRange(new DataGridViewColumn[] { col0, col1, col2, col3, col4, col5, col6 });
        //    dgView.AutoGenerateColumns = false;
        //    dgView.AllowUserToAddRows = false;
        //    //dgvContacts.AutoResizeColumns();            

        //    col0.Name = "chkBxSelect";
        //    col0.DataPropertyName = "Select";
        //    col0.HeaderText = "";
        //    col0.Width = 45;

        //    col1.DataPropertyName = "CompanyName";
        //    col1.HeaderText = "Company Name";
        //    col1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
        //    col1.Width = 180;

        //    col2.DataPropertyName = "Company ShortName";
        //    col2.HeaderText = "Company ShortName";
        //    col2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
        //    col2.Width = 80;

        //    col3.DataPropertyName = "Address";
        //    col3.HeaderText = "Address";
        //    col3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
        //    col3.Width = 180;

        //    col4.DataPropertyName = "Category";
        //    col4.HeaderText = "Category";
        //    col4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
        //    col4.Width = 110;

        //    col5.DataPropertyName = "CompanyType";
        //    col5.HeaderText = "Company Type";
        //    col5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
        //    col5.Width = 110;

        //    col6.DataPropertyName = "Company ID";
        //    col6.HeaderText = "Company ID";
        //    col6.Resizable = System.Windows.Forms.DataGridViewTriState.True;

        //    BindingSource myBindingSource = null;
        //    try
        //    {
        //        DataTable finalDt = new DataTable("Company");
        //        finalDt.Columns.Add("Select");
        //        finalDt.Columns.Add("CompanyName");
        //        finalDt.Columns.Add("Company ShortName");
        //        finalDt.Columns.Add("Address");
        //        finalDt.Columns.Add("Category");
        //        finalDt.Columns.Add("CompanyType");
        //        finalDt.Columns.Add("Company ID");

        //        sqlConn = new SqlConnection(strCon);
        //        sqlConn.Open();
        //        string sqlQuery = "SELECT COMPANY.Co_Name, co_shortname, COMPANY.Co_Address, COMPANY_CAT.Co_Category_Name, COMPANY_TYPE.Co_Type_Name,COMPANY.Co_ID FROM COMPANY INNER JOIN COMPANY_CAT ON COMPANY.Co_Category_Id = COMPANY_CAT.Co_Category_Id INNER JOIN COMPANY_TYPE ON COMPANY.Co_Type_Id = COMPANY_TYPE.Co_Type_Id Where COMPANY.Co_ID <> 1 AND COMPANY.Co_ID <> 425 Order by co_name";
        //        finalDt.AcceptChanges();

        //        sqlCom = new SqlCommand(sqlQuery, sqlConn);
        //        sqlReader = sqlCom.ExecuteReader();

        //        while (sqlReader.Read())
        //        {
        //            DataRow dr = finalDt.NewRow();

        //            dr[1] = sqlReader[0];
        //            dr[2] = sqlReader[1];
        //            dr[3] = sqlReader[2];
        //            dr[4] = sqlReader[3];
        //            dr[5] = sqlReader[4];
        //            dr[6] = sqlReader[5];
        //            finalDt.Rows.Add(dr);
        //            finalDt.AcceptChanges();
        //        }
        //        sqlReader.Close();

        //        dtTemp = finalDt;

        //        myBindingSource = new BindingSource(finalDt, null);
        //        dgView.DataSource = myBindingSource;

        //        dgView.Columns[6].Visible = false;
        //    }
        //    catch (Exception ex)
        //    {
        //        string exMsg = ex.Message;
        //    }
        //    finally
        //    {
        //        sqlConn.Close();
        //    }

        //    headerCheckBox.KeyUp += new KeyEventHandler(chkBox.HeaderCheckBox_KeyUp);
        //    headerCheckBox.MouseClick += new MouseEventHandler(chkBox.HeaderCheckBox_MouseClick);
        //    dgView.CellValueChanged += new DataGridViewCellEventHandler(chkBox.dgvSelectAll_CellValueChanged);
        //    dgView.CurrentCellDirtyStateChanged += new EventHandler(chkBox.dgvSelectAll_CurrentCellDirtyStateChanged);
        //    dgView.CellPainting += new DataGridViewCellPaintingEventHandler(chkBox.dgvSelectAll_CellPainting);
        //}

        private void button4_Click(object sender, EventArgs e)
        {
            if (userRightsColl.Contains("25"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            TenderTrackingSystem.Contacts.frmAddCompanyInfo frmPerson = new frmAddCompanyInfo(userRightsColl,0,_userName,false);
            frmPerson.StartPosition = FormStartPosition.CenterScreen;
            frmPerson.ShowDialog();

            //loadCompanyInfo();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (userRightsColl.Contains("27"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            List<int> lstObj = new List<int>();
            int compID = 0;

            int iCnt = 0;
            for (int iCounter = 0; iCounter < dgView.RowCount; iCounter++)
            {
                DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgView.Rows[iCounter].Cells[0];

                if (chkactive.Value != null)
                {
                    if (chkactive.Value.ToString().ToLower() == "true")
                        iCnt = iCnt + 1;
                }
            }
             

             DialogResult dlgResult = DialogResult.Yes;
             dlgResult = MessageBox.Show(" Are you sure want to make Company InActive?", "InActive Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

        if (dlgResult.ToString() == "Yes")
        {
            

            for (int iCounter = 0; iCounter < dgView.RowCount; iCounter++)
            {
                DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgView.Rows[iCounter].Cells[0];
                if (chkactive.Value != null)
                {
                    if (chkactive.Value.ToString().ToLower() == "true")
                    {
                        compID = Convert.ToInt16(dgView.Rows[iCounter].Cells[8].Value); 
                        try
                        {
                            sqlConn.Open();
                            sqlCom = new SqlCommand("update Company set isActive=0 where Co_Id= " + compID + "", sqlConn);
                            sqlCom.ExecuteNonQuery();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Cannot make the company inActive", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        finally
                        {
                            sqlConn.Close();
                        }
                        lstObj.Add(iCounter);
                    }
                }
            }
            short sClear = 0;
            if (dgView.Rows.Count == lstObj.Count)
            {
                dgView.Rows.RemoveAt(lstObj[0]);
                sClear = 1;
            }
            if (sClear != 1)
            {
                for (int iCounter = 0; iCounter < lstObj.Count; iCounter++)
                {
                    if (iCounter == 0)
                        dgView.Rows.RemoveAt(lstObj[iCounter]);
                    if (iCounter != 0)
                        dgView.Rows.RemoveAt(lstObj[iCounter] - 1);
                }
            }
            if (lstObj.Count == 0)
                MessageBox.Show("Please Click the Check Box From Company List", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //else
            //    loadCompanyInfo();
        }
      }

        private void button1_Click(object sender, EventArgs e)
        {
            if (userRightsColl.Contains("25"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            List<int> lstObj = new List<int>();
            int  compId = 0;

            int iCnt = 0;
            for (int iCounter = 0; iCounter < dgView.RowCount; iCounter++)
            {
                DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgView.Rows[iCounter].Cells[0];

                if (chkactive.Value != null)
                {
                    if (chkactive.Value.ToString().ToLower() == "true")
                    iCnt = iCnt + 1;
                }
            }

            if (iCnt > 1)
            {
                MessageBox.Show("Please Select Only One Record For Edit");

                return;
            }
            for (int iCounter = 0; iCounter < dgView.RowCount; iCounter++)
            {
                DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgView.Rows[iCounter].Cells[0];

                if (chkactive.Value != null)
                {
                    if (chkactive.Value.ToString().ToLower() == "true")
                    {
                        compId = Convert.ToInt16(dgView.Rows[iCounter].Cells[8].Value);   // 6 ToolBar 7 changed
                        try
                        {
                            TenderTrackingSystem.Contacts.frmAddCompanyInfo frmPerson = new TenderTrackingSystem.Contacts.frmAddCompanyInfo(userRightsColl, compId, _userName,false);
                            frmPerson.StartPosition = FormStartPosition.CenterScreen;
                            frmPerson.ShowDialog();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error occurred while opening the Company Information", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        finally
                        {
                            sqlConn.Close();
                        }
                        lstObj.Add(iCounter);
                    }
                }
            }

            if (lstObj.Count == 0)
                MessageBox.Show("Please select a record from GridView", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
           // else
               // loadCompanyInfo();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            loadCompanyInfo();
        }
        private void loadCompanyInfo()
        {
            BindingSource myBindingSource = null;
            try
            {
                DataTable finalDt = new DataTable("Company");
                finalDt.Columns.Add("Select");
                finalDt.Columns.Add("Company Name");
                finalDt.Columns.Add("Company ShortName");
                finalDt.Columns.Add("Address");
                finalDt.Columns.Add("Category");
                finalDt.Columns.Add("Company Type");
                finalDt.Columns.Add("CommercialRegExpiryDate",typeof(DateTime));
                finalDt.Columns.Add("Company ID");

                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                string sqlQuery = "SELECT COMPANY.Co_Name, co_shortname,COMPANY.Co_Address, COMPANY_CAT.Co_Category_Name, COMPANY_TYPE.Co_Type_Name,Replace(CONVERT(nvarchar,COMPANY.cr_expiry_date,106,' ','/') As CommercialRegExpiryDate,COMPANY.Co_ID FROM COMPANY INNER JOIN COMPANY_CAT ON COMPANY.Co_Category_Id = COMPANY_CAT.Co_Category_Id INNER JOIN COMPANY_TYPE ON COMPANY.Co_Type_Id = COMPANY_TYPE.Co_Type_Id Where COMPANY.Co_ID <> 1 AND COMPANY.Co_ID <> 425 Order by co_name";
                finalDt.AcceptChanges();

                sqlCom = new SqlCommand(sqlQuery, sqlConn);
                sqlReader = sqlCom.ExecuteReader();

                while (sqlReader.Read())
                {
                    DataRow dr = finalDt.NewRow();

                    dr[1] = sqlReader[0];
                    dr[2] = sqlReader[1];
                    dr[3] = sqlReader[2];
                    dr[4] = sqlReader[3];
                    dr[5] = sqlReader[4];
                    dr[6] = sqlReader[5];
                    dr[7] = sqlReader[6];

                    finalDt.Rows.Add(dr);
                    finalDt.AcceptChanges();

                }
                sqlReader.Close();

                myBindingSource = new BindingSource(finalDt, null);
                dgView.DataSource = myBindingSource;
                dgView.Columns[7].Visible = false;
                lblCnt.Text = "Record Count:" + dgView.Rows.Count.ToString();
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dgView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            int colIndex = e.ColumnIndex;
            int rowIndex = e.RowIndex;
            if (colIndex == 5)
            {
                CommonClass comCls = new CommonClass(_userName);
                comCls.CreateOutlookEmail(dgView.Rows[rowIndex].Cells[5].Value.ToString(), null,"My Subject");
            }
        }

        private void btnRefreshCmp_Click(object sender, EventArgs e)
        {
            txtCmpFilter.Text = "";
            cmbType.SelectedIndex = -1;
            cmbCategory.SelectedIndex = -1;
            txtFromExpiryDate.Text = "";
            txtToExpiryDate.Text = "";


            BindingSource myBindingSource = null;
            try
            {
                DataTable finalDt = new DataTable("Company");
                finalDt.Columns.Add("Select");
                finalDt.Columns.Add("CompanyName");
                finalDt.Columns.Add("Company ShortName");
                finalDt.Columns.Add("Nationality");
                finalDt.Columns.Add("Telephone No.");
                finalDt.Columns.Add("Email Address");
                finalDt.Columns.Add("Web Page");
                finalDt.Columns.Add("CommercialRegExpiryDate", typeof (DateTime));
                finalDt.Columns.Add("Company ID");

                finalDt.Columns.Add("Category");
                finalDt.Columns.Add("CompanyType");

                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                //string sqlQuery = "SELECT COMPANY.Co_Name, co_shortname, COMPANY.Co_Address, COMPANY_CAT.Co_Category_Name, COMPANY_TYPE.Co_Type_Name,COMPANY.Co_ID FROM COMPANY INNER JOIN COMPANY_CAT ON COMPANY.Co_Category_Id = COMPANY_CAT.Co_Category_Id INNER JOIN COMPANY_TYPE ON COMPANY.Co_Type_Id = COMPANY_TYPE.Co_Type_Id Where COMPANY.Co_ID <> 1 AND COMPANY.Co_ID <> 425 Order by co_name";

                string sqlQuery = "SELECT COMPANY.co_name, COMPANY.co_shortname, COMPANY.nationality, COMPANY.co_tel, COMPANY.co_email_address, " +
                     " COMPANY.WebPage,Replace(CONVERT(nvarchar,COMPANY.cr_expiry_date,106),' ','/') As CommercialRegExpiryDate,COMPANY.co_id,COMPANY_CAT.Co_Category_Name, COMPANY_TYPE.Co_Type_Name FROM   COMPANY INNER JOIN  COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id INNER JOIN " +
                       " COMPANY_TYPE ON COMPANY.co_type_id = COMPANY_TYPE.co_type_id WHERE (COMPANY.co_id <> 1) AND (COMPANY.co_id <> 425) ORDER BY COMPANY.co_name";
                finalDt.AcceptChanges();

                DAL dalObj = new DAL();
                DataTable dtCompany = dalObj.GetDataFromDB("Company", sqlQuery);

                foreach (DataRow drRow in dtCompany.Rows)
                {
                    DataRow dr = finalDt.NewRow();
                    dr[1] = drRow[0]; //co_name
                    dr[2] = drRow[1]; //co_shortname
                    dr[3] = drRow[2]; //nationality
                    dr[4] = drRow[3]; //co_tel
                    dr[5] = drRow[4]; //co_email_address
                    dr[6] = drRow[5]; //webpage
                    if (drRow[6].ToString().Trim() != "")
                    {
                        dr[7] = drRow[6]; //).ToString("dd/MMM/yyyy").Split(' ')[0]; //CommercialRegExpiryDate
                    }
                    else
                    {
                        dr[7] = System.DBNull.Value;
                    }
                    dr[8] = drRow[7]; //Co_ID 
                    dr[9] = drRow[8]; //Co_Category_Name
                    dr[10] = drRow[9]; //Co_Type_Name


                    //dr[1] = drCmp.ToString().Split(',')[0].Split('=')[1].Trim().Replace('|',',');    //co_name
                    //dr[2] = drCmp.ToString().Split(',')[1].Split('=')[1].Trim().Replace('|', ',');  //co_shortname
                    //dr[3] = drCmp.ToString().Split(',')[2].Split('=')[1].Trim().Replace('|', ',');      //nationality
                    //dr[4] = drCmp.ToString().Split(',')[3].Split('=')[1].Trim().Replace('|', ',');         //co_tel
                    //dr[5] = drCmp.ToString().Split(',')[4].Split('=')[1].Trim().Replace('|', ',');        //co_email_address
                    //dr[6] = drCmp.ToString().Split(',')[5].Split('=')[1].Trim().Replace('|', ',');     //webpage
                    //if (drCmp.ToString().Split(',')[6].Split('=')[1].Trim() != "")
                    //{
                    //    dr[7] = drCmp.ToString().Split(',')[6].Split('=')[1].Trim().Replace('|', ',');     //CommercialRegExpiryDate
                    //}
                    //else
                    //{
                    //    //dr[7] = new DateTime?();
                    //    dr[7] = System.DBNull.Value; // new DateTime?();
                    //}
                    //dr[8] = drCmp.ToString().Split(',')[7].Split('=')[1].Trim();     //Co_ID 
                    //dr[9] = drCmp.ToString().Split(',')[8].Split('=')[1].Trim();     //Co_Category_Name
                    //dr[10] = drCmp.ToString().Split(',')[9].Split('=')[1].Trim().Replace("}", "");     //Co_Type_Name 


                    //dr[1] = strProj;    //ProjectId
                    //dr[1] = drCmp.ToString().Split(',')[0].Split('=')[1].Trim() + " " + drCmp.ToString().Split(',')[1].Split('=')[1].Trim();  //FirstName
                    //dr[2] = drCmp.ToString().Split(',')[2].Split('=')[1].Trim();  //ProjectCode
                    //dr[3] = drCmp.ToString().Split(',')[3].Split('=')[1].Trim();  //ProjTitle                   

                    //dr[4] = drCmp.ToString().Split(',')[4].Split('=')[1].Trim();  //TenderNo
                    //dr[5] = drCmp.ToString().Split(',')[5].Split('=')[1].Trim();  //CurrentStage

                    //dr[6] = drCmp.ToString().Split(',')[6].Split('=')[1].Trim();  //TenderStatus
                    //dr[7] = drCmp.ToString().Split(',')[7].Split('=')[1].Trim();  //TypeOfTender

                    //dr[8] = drCmp.ToString().Split(',')[8].Split('=')[1].Trim();  //TenderCommittee
                    //dr[9] = drCmp.ToString().Split(',')[9].Split('=')[1].Trim();  //TypeofContract

                    //if ((!profile_Name.Equals("EBSD Staff") && userRightsColl.Contains("104")) && userRightsColl.Count != 0)
                    //{
                    //    //dr[10] = drProj[14];  //ContractNo 
                    //    dr[10] = drContact.ToString().Split(',')[9].Split('=')[1].Trim();  //FiscalYear
                    //    dr[11] = drContact.ToString().Split(',')[10].Split('=')[1].Trim();  //UserDepartment 
                    //    dr[12] = drContact.ToString().Split(',')[11].Split('=')[1].Trim();  //Qs 
                    //    dr[13] = drContact.ToString().Split(',')[12].Split('=')[1].Trim();  //Handl
                    //    dr[14] = drContact.ToString().Split(',')[13].Split('=')[1].Trim();  //Staff 
                    //    dr[15] = rowId;
                    //}
                    //else if (profile_Name.Equals("EBSD Staff"))
                    //{
                    //    dr[10] = drContact.ToString().Split(',')[14].Split('=')[1].Trim();  //ContractNo 
                    //    dr[11] = drContact.ToString().Split(',')[9].Split('=')[1].Trim();  //FiscalYear 
                    //    dr[12] = drContact.ToString().Split(',')[10].Split('=')[1].Trim();  //UserDepartment
                    //    dr[13] = drContact.ToString().Split(',')[11].Split('=')[1].Trim();  //Qs 
                    //    dr[14] = drContact.ToString().Split(',')[12].Split('=')[1].Trim();  //Handl
                    //    dr[15] = drContact.ToString().Split(',')[13].Split('=')[1].Trim();  //Staff 
                    //    //dr[16] = drProj[15];  //ProjCreateDate                           
                    //    //dr[17] = drProj[16];  //ProjUpdateDate                           
                    //    dr[16] = drContact.ToString().Split(',')[15].Split('=')[1].Trim();  //MozanahID                           
                    //    dr[17] = rowId;
                    //}
                    //else if ((!profile_Name.Equals("EBSD Staff") && !userRightsColl.Contains("104")) || userRightsColl.Count == 0)
                    //{
                    //    //string contractNo = drProj[14].ToString();
                    //    dr[10] = drContact.ToString().Split(',')[14].Split('=')[1].Trim(); //ContractNoWorkOrderNo

                    //    //if (contractNo.Contains("C") || contractNo.Contains("P"))
                    //    //{
                    //    //    contractNo = contractNo.Split('-')[0];
                    //    //    if(contractNo!="")
                    //    //    {
                    //    //        dr[11] = FindSuccessfulBidders(dalObj, drProj, contractNo);
                    //    //    }                            
                    //    //}

                    //    dr[11] = drContact.ToString().Split(',')[9].Split('=')[1].Trim();  //FiscalYear
                    //    dr[12] = drContact.ToString().Split(',')[10].Split('=')[1].Trim();  //UserDepartment 
                    //    dr[13] = drContact.ToString().Split(',')[11].Split('=')[1].Trim();  //Qs 
                    //    dr[14] = drContact.ToString().Split(',')[12].Split('=')[1].Trim();  //Handl
                    //    dr[15] = drContact.ToString().Split(',')[13].Split('=')[1].Trim();  //Staff 
                    //    dr[16] = rowId;

                    //    //dr[11] = drProj[9];  //FiscalYear
                    //    //dr[12] = drProj[10];  //UserDepartment 
                    //    //dr[13] = drProj[11];  //Qs 
                    //    //dr[14] = drProj[12];  //Handl
                    //    //dr[15] = drProj[13];  //Staff 
                    //    //dr[16] = rowId;                            

                    //}

                    //rowId++;
                    finalDt.Rows.Add(dr);
                    finalDt.AcceptChanges();
                }                 

                myBindingSource = new BindingSource(finalDt, null);

                dtTemp = finalDt;

                dgView.Columns[8].Visible = false;


                dgView.DataSource = myBindingSource;


            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }       
        }     
        DataTable dtTempForCombo = null;
        private void GridFillForCompany(string filterQuery)
        {
            dtTempForCombo = dtTemp;
            int iCnt = dtTempForCombo.Rows.Count;
            DataTable dtCmbTbl = null;

            if (dtTempForCombo.Select(filterQuery).Length != 0)
            {
                dtCmbTbl = dtTempForCombo.Select(filterQuery).CopyToDataTable();
                int jCnt = dtCmbTbl.Rows.Count;
                try
                {
                    myBindingSource = new BindingSource(dtCmbTbl, null);
                    dgView.DataSource = myBindingSource;
                    dtTempForCombo = dtCmbTbl;

                    //dgView.ColumnHeadersDefaultCellStyle.BackColor = Color.Olive;
                    //dgView.ColumnHeadersDefaultCellStyle.ForeColor = Color.Blue;
                    //dgView.ColumnHeadersDefaultCellStyle.Font = new Font(dgView.Font, FontStyle.Bold);

                    dgView.EnableHeadersVisualStyles = false;
                    dgView.Columns[8].Visible = false;
                    lblCnt.Text = "Record Count:" + dgView.Rows.Count.ToString();
                }
                catch (Exception ex)
                {
                    string exMsg = ex.Message;
                }
                finally
                {
                }
            }
            else
            {
                DataTable nullTable = new DataTable();
                dtCmbTbl = null;
                myBindingSource = new BindingSource(nullTable, null);
                dgView.DataSource = myBindingSource;
            }
        }

        private void txtCmpFilter_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                if (sender is TextBox)
                {
                    filterCombo();
                }
            }
        }

        private void txtCmpFilter_KeyPress(object sender, KeyPressEventArgs e)
        {
            filterCombo();
        }

        private void cmbType_SelectionChangeCommitted(object sender, EventArgs e)
        {
            filterCombo();
        }

        private void cmbCategory_SelectionChangeCommitted(object sender, EventArgs e)
        {
            filterCombo();
        }
        public void filterCombo()
        {
            try
            {
                string filterQuery = string.Empty;

                if (txtCmpFilter.Text != "")
                {
                    if (filterQuery == "")
                    {
                        filterQuery = "CompanyName like '%" + txtCmpFilter.Text + "%'";
                    }
                    else
                    {
                        filterQuery = filterQuery + " and " + "CompanyName like '%" + txtCmpFilter.Text + "%'";
                    }
                }

                if (cmbType.SelectedIndex != -1)
                {
                    if (filterQuery == "")
                    {
                        filterQuery = "CompanyType = '" + ((DataRowView)cmbType.SelectedItem).Row.ItemArray[0].ToString() + "'";
                    }
                    else
                    {
                        filterQuery = filterQuery + " and " + "CompanyType = '" + ((DataRowView)cmbType.SelectedItem).Row.ItemArray[0].ToString() + "'";
                    }
                }
                else if (cmbType.Text != "")
                {
                    if (filterQuery == "")
                    {
                        filterQuery = "CompanyType like '%" + cmbType.Text + "%'";
                    }
                    else
                    {
                        filterQuery = filterQuery + " and " + "CompanyType like '" + cmbType.Text + "'";
                    }
                }

                if (cmbCategory.SelectedIndex != -1)
                {
                    if (filterQuery == "")
                    {
                        filterQuery = "Category = '" + ((DataRowView)cmbCategory.SelectedItem).Row.ItemArray[0].ToString() + "'";
                    }
                    else
                    {
                        filterQuery = filterQuery + " and " + "Category = '" + ((DataRowView)cmbCategory.SelectedItem).Row.ItemArray[0].ToString() + "'";
                    }
                }
                else if (cmbCategory.Text != "")
                {
                    if (filterQuery == "")
                    {
                        filterQuery = "Category like '%" + cmbCategory.Text + "%'";
                    }
                    else
                    {
                        filterQuery = filterQuery + " and " + "Category like '" + cmbCategory.Text + "'";
                    }
                }
                else if (txtFromExpiryDate.Text != "" && txtToExpiryDate.Text != "")
                {
                    if (filterQuery == "")
                    {
                        filterQuery = "CommercialRegExpiryDate >= '" + txtFromExpiryDate.Text + "' and CommercialRegExpiryDate <='" + txtToExpiryDate.Text + "'";
                    }
                    else
                    {
                        filterQuery = filterQuery + " and " + "CommercialRegExpiryDate >= '" + txtFromExpiryDate.Text + "' and CommercialRegExpiryDate <='" + txtToExpiryDate.Text + "'";
                    }
                }
                 
                if (filterQuery == "")
                {
                    GridFillForCompany("");
                }
                else
                {
                    GridFillForCompany(filterQuery);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred ",ex.Message);                
            }
           
        }

        private void btnExportToExcel_Click(object sender, EventArgs e)
        {
            comCls = new CommonClass(_userName);
            string _fileName = comCls.SelectTextFile("@C:");
            comCls.export_datagridview_to_excel(dgView, _fileName,'C');
        }

        private void dgView_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //int colIndex = e.ColumnIndex;
            int rowIndex = e.RowIndex;

            if (userRightsColl.Contains("25"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            List<int> lstObj = new List<int>();
            int compId = 0;

            DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgView.Rows[rowIndex].Cells[0];

                compId = Convert.ToInt16(dgView.Rows[rowIndex].Cells[8].Value);   // 6 ToolBar 7 changed
                   
                try
                {
                    TenderTrackingSystem.Contacts.frmAddCompanyInfo frmPerson = new TenderTrackingSystem.Contacts.frmAddCompanyInfo(userRightsColl, compId, _userName,false);
                    frmPerson.StartPosition = FormStartPosition.CenterScreen;
                    frmPerson.ShowDialog();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while deleting the Project Code", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                finally
                {
                    sqlConn.Close();
                }
        }         

        private void dtpFromExpiryDate_ValueChanged(object sender, EventArgs e)
        {
            txtFromExpiryDate.Text = Convert.ToDateTime(dtpFromExpiryDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd-MMM-yyyy");        
        }

        private void dtpToExpiryDate_ValueChanged(object sender, EventArgs e)
        {            
            txtToExpiryDate.Text = Convert.ToDateTime(dtpToExpiryDate.Value.ToString("dd/MMM/yyyy", CultureInfo.InvariantCulture)).ToString("dd-MMM-yyyy");
            filterCombo();
        }

        private void dgView_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if(e.ColumnIndex == 7)
            {
                if(e.Value.ToString() != "")
                {
                    if (Convert.ToDateTime(dgView.Rows[e.RowIndex].Cells[7].Value.ToString().Split(' ')[0]).CompareTo(Convert.ToDateTime(DateTime.Now.ToString().Split(' ')[0])) == -1)
                    {
                        e.CellStyle.ForeColor = Color.Red;
                    }
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (userRightsColl.Contains("27"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            List<int> lstObj = new List<int>();
            int compID = 0;

            int iCnt = 0;
            for (int iCounter = 0; iCounter < dgView.RowCount; iCounter++)
            {
                DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgView.Rows[iCounter].Cells[0];

                if (chkactive.Value != null)
                {
                    if (chkactive.Value.ToString().ToLower() == "true")
                        iCnt = iCnt + 1;
                }
            }


            DialogResult dlgResult = DialogResult.Yes;
            dlgResult = MessageBox.Show(" Are you sure want to make Company Active?", "Active Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (dlgResult.ToString() == "Yes")
            {


                for (int iCounter = 0; iCounter < dgView.RowCount; iCounter++)
                {
                    DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgView.Rows[iCounter].Cells[0];
                    if (chkactive.Value != null)
                    {
                        if (chkactive.Value.ToString().ToLower() == "true")
                        {
                            compID = Convert.ToInt16(dgView.Rows[iCounter].Cells[8].Value);
                            try
                            {
                                sqlConn.Open();
                                sqlCom = new SqlCommand("update Company set isActive=1 where Co_Id= " + compID + "", sqlConn);
                                sqlCom.ExecuteNonQuery();
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Cannot make the company Active", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            finally
                            {
                                sqlConn.Close();
                            }
                            lstObj.Add(iCounter);
                        }
                    }
                }
                short sClear = 0;
                if (dgView.Rows.Count == lstObj.Count)
                {
                    dgView.Rows.RemoveAt(lstObj[0]);
                    sClear = 1;
                }
                if (sClear != 1)
                {
                    for (int iCounter = 0; iCounter < lstObj.Count; iCounter++)
                    {
                        if (iCounter == 0)
                            dgView.Rows.RemoveAt(lstObj[iCounter]);
                        if (iCounter != 0)
                            dgView.Rows.RemoveAt(lstObj[iCounter] - 1);
                    }
                }
                if (lstObj.Count == 0)
                    MessageBox.Show("Please Click the Check Box From Company List", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //else
                //    loadCompanyInfo();
            }
        }       
    }
}
