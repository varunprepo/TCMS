﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using MDI_ParenrForm;
using System.Text.RegularExpressions;
using System.Globalization;
using System.IO;
using System.Diagnostics;

namespace TenderTrackingSystem.Contacts
{
    public partial class frmAddCompanyInfo : Form
    {
        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();        
        protected SqlConnection sqlConn;        
        protected SqlCommand sqlCom;
        protected SqlDataReader sqlReader;
        CommonClass cmnClass = new CommonClass("");
        int _cmpID = 0;
        string _userName = string.Empty;
        bool _isHeadOfSection = false;

        // for Edit Company Information
        public frmAddCompanyInfo(IList<string> userRightsColl, int CmpID, string user, bool isHeadOfSection)
        {
            InitializeComponent();
            _cmpID = CmpID;
            _userName = user;
            _isHeadOfSection = isHeadOfSection;
            if (CmpID != 0)
            {
                btnSave.Text = "Update";                
                btnClick.Visible = true;
                txtOtherShare2.Visible = true;
                lblShare.Visible = true;
                cmbCntryNames.Visible = true;
                lblOtherShare.Visible = true;
                txtOtherShare.Visible = true;
                get_CompanyShare_Info(_cmpID);
            }
        }
        // For Add New Company Information
        public frmAddCompanyInfo(IList<string> userRightsColl, string user)
        {
            InitializeComponent();
            _userName = user;           
        }
        private void get_CompanyShare_Info(int cmpID)
        {
            string sqlQuery = "Select countryName,countryShare from CompanyShare where co_id = " + cmpID + "";

            using (SqlConnection sqlConn = new SqlConnection(strCon))
            {
                using (SqlCommand cmd = new SqlCommand(sqlQuery, sqlConn))
                {
                    sqlConn.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.HasRows)
                    {
                        dr.Read();
                        txtOtherShare.Text = txtOtherShare.Text + dr[0].ToString() + "-" + dr[1].ToString(); // +;                    
                        cmbCntryNames.Text = dr[0].ToString();
                        txtOtherShare2.Text = dr[1].ToString();
                    }
                    dr.Close();
                }
            }
        }
        private bool ValidateControls()
        {
            Boolean chkCntrls = true;
            
            //if (txtCmpAddress.Text ==  string.Empty)
            //{
            //    chkCntrls = false;
            //    MessageBox.Show("Please Enter Company Address");
            //    txtCmpAddress.Focus();
            //    return chkCntrls;
            //}
            if (txtCmpName.Text == "" || txtCmpName.Text == " ")
            {
                chkCntrls = false;
                MessageBox.Show("Please Enter Company Name");
                txtCmpName.Focus();
                return chkCntrls;                
            }
            //if (txtCmpShortName.Text == "")
            //{
            //    chkCntrls = false;
            //    MessageBox.Show("Please Enter Short Name");
            //    txtCmpShortName.Focus();
            //    return chkCntrls;
            //}             
            if (cmbCategiry.SelectedIndex == -1)
            {
                chkCntrls =  false;
                MessageBox.Show("Please Select Company Category");                
                return chkCntrls;
            }
            if (cmbCmpType.SelectedIndex == -1)
            {
                chkCntrls = false;
                MessageBox.Show("Please Select Company Type");
                return chkCntrls;
            }
            //if (dtpExpireDate.Text == " ")
            //{
            //    chkCntrls = false;
            //    MessageBox.Show("Please Select Rigistration Expiration Date");
            //    return chkCntrls;
            //}
            return chkCntrls;
        }
        string cmersialDate = string.Empty;
        private void button2_Click(object sender, EventArgs e)
        {
            Boolean chkCntl = ValidateControls();
            if (chkCntl == false)
                return;

            if (chkCompanyExist() == false)
            {
                MessageBox.Show("Company Name already existed,Please enter new company Name.");
                txtCmpName.Focus();
                return;
            }

            //if (mskExpireDate.MaskFull == false)
            //{
            //    cmersialDate = null;
            //}
            //else
            //{
            //    cmersialDate = Convert.ToDateTime(mskExpireDate.Text).ToString("dd/MM/yyyy");
            //   // string dateTime = Convert.ToDateTime(cmersialDate).ToString("dd/MM/yyyy");

            //    DateTime dt = DateTime.Parse(cmersialDate);

            //    cmersialDate = dt.ToString();
            //}

            if (dtpCRDate.Text == "" || dtpCRDate.Text == " ")
            {
                cmersialDate = null;
            }
            else
            {
                cmersialDate = Convert.ToDateTime(dtpCRDate.Text).ToString("dd/MMM/yyyy");
                // string dateTime = Convert.ToDateTime(cmersialDate).ToString("dd/MM/yyyy");

                //DateTime dt = DateTime.Parse(cmersialDate);

               // cmersialDate = dt.ToString();

               // DateTime date = DateTime.ParseExact(dtpCRDate.Text, "dd/MMM/yyyy", CultureInfo.InvariantCulture);
            }


           // mskExpireDate.ValidatingType = typeof(DateTime);

            if (chkCmpMode == false)
            {            
   
                //sqlReader.Dispose();

                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                sqlCom = new SqlCommand("select max(Co_Id) from COMPANY", sqlConn);
                sqlReader = sqlCom.ExecuteReader();
                sqlReader.Read();
                int cmp_ID = Convert.ToInt32(sqlReader[0]) + 1;  //Autometically Increamented in Database
                sqlReader.Close();
                sqlConn.Close();

                int chkVal = 0;
                if (chkBlockList.Checked == true)
                {
                    chkVal = 1;
                }
                try
                {
                    sqlConn.Open();
                                        
                    foreach (ListViewItem item in lstCRCopies.Items)
                    {
                        using (SqlCommand command = new SqlCommand())
                        {
                            command.CommandText = @"INSERT INTO CRAttachment(crAttFileName, crAttFile,co_id,create_date,create_user) VALUES (@crAttFileName, @crAttFile,@co_id,@createDate,@createUser)";
                            command.Connection = sqlConn;
                            command.Parameters.AddWithValue("@crAttFileName", item.Text);
                            command.Parameters.AddWithValue("@crAttFile", item.Tag);
                            command.Parameters.AddWithValue("@co_id", cmp_ID);
                            command.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                            command.Parameters.AddWithValue("@createUser", _userName);
                            command.ExecuteNonQuery();
                            command.Dispose();
                        }
                    }                     


                    string strQuery = "Insert into COMPANY(Co_Id,co_name,co_category_id,co_type_id,co_address,block_listed, " +
                         " co_tel,co_fax,co_email_address,nationality,cr_expiry_date,qatari_share,co_comments,co_shortname," +
                         " CRNo,create_date,create_user,WebPage,co_city,co_state,co_country,co_zip)" +
                         " values (@cmpId,@cmpName,@cmpCategID,@cmpTypeId,@cmpAddress,@blockListed,@cmpTel,@cmpFax, " +
                         " @cmpEmail,@Nationality,@crDate,@qatariShare,@cmpComments,@cmpShortname,@crNo,@createDate,@createUser,@WebPage,@co_city, " +
                         " @co_state,@co_country,@co_zip)";

                    sqlCom = new SqlCommand(strQuery,sqlConn);

                   // sqlCom = new SqlCommand("Insert into COMPANY(Co_Id,co_name,co_category_id,co_type_id,co_address,block_listed, " +
                   // " co_tel,co_fax,co_email_address,nationality,cr_expiry_date,qatari_share,co_comments,co_shortname," +
                   // " CRNo,create_date,create_user,WebPage,co_city,co_state,co_country,co_zip) values (" +
                   //"" + cmp_ID + ", '" + txtCmpName.Text + "'," + cmbCategiry.SelectedValue + "," + cmbCmpType.SelectedValue + ",'" + txtCmpAddress.Text + "'," + chkVal + ",'" + txtTelephone.Text + "','" + txtFaxNo.Text + "', " +
                   //" '" + txtEmail.Text + "','" + txtNationality.Text + "','" + cmersialDate + "','" + txtQuality.Text + "','" + txtComments.Text + "','" + txtCmpShortName.Text + "','" + txtCrno.Text + "','" + System.DateTime.Now + "','" + _userName + "','" +
                   //"" + _txtWebPage.Text + "','" + _txtCity.Text + "','" + _txtState.Text + "','" + _txtCountry.Text + "','" + _txtZip.Text + "')", sqlConn);  //dTime.ToString("dd/MMM/yyyy");                       
                    

                    sqlCom.Parameters.AddWithValue("@cmpId", cmp_ID);
                    sqlCom.Parameters.AddWithValue("@cmpName", txtCmpName.Text.Replace("\r","").Replace("\n",""));

                    sqlCom.Parameters.AddWithValue("@cmpCategID", cmbCategiry.SelectedValue);
                    sqlCom.Parameters.AddWithValue("@cmpTypeId", cmbCmpType.SelectedValue);
                    sqlCom.Parameters.AddWithValue("@cmpAddress", txtCmpAddress.Text);
                    sqlCom.Parameters.AddWithValue("@blockListed", chkVal);

                    sqlCom.Parameters.AddWithValue("@cmpTel", txtTelephone.Text);
                    sqlCom.Parameters.AddWithValue("@cmpFax", txtFaxNo.Text);
                    sqlCom.Parameters.AddWithValue("@cmpEmail", txtEmail.Text.ToString().Replace(";","; "));
                    sqlCom.Parameters.AddWithValue("@Nationality", txtNationality.Text);

                    if (cmersialDate != null)
                       sqlCom.Parameters.AddWithValue("@crDate", cmersialDate);
                    else
                        sqlCom.Parameters.AddWithValue("@crDate", System.DBNull.Value);


                    sqlCom.Parameters.AddWithValue("@qatariShare", txtQuality.Text);

                    sqlCom.Parameters.AddWithValue("@cmpComments", txtComments.Text);
                    sqlCom.Parameters.AddWithValue("@cmpShortname", txtCmpShortName.Text);

                    sqlCom.Parameters.AddWithValue("@crNo", txtCrno.Text);

                    sqlCom.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                    sqlCom.Parameters.AddWithValue("@createUser", _userName);

                    sqlCom.Parameters.AddWithValue("@WebPage", _txtWebPage.Text);
                    sqlCom.Parameters.AddWithValue("@co_city", _txtCity.Text);

                    sqlCom.Parameters.AddWithValue("@co_state", _txtState.Text);
                    sqlCom.Parameters.AddWithValue("@co_country", _txtCountry.Text);
                    sqlCom.Parameters.AddWithValue("@co_zip", _txtZip.Text);

                    sqlCom.ExecuteNonQuery();
                    sqlConn.Close();

                    MessageBox.Show("New Company Info Added Successfully");
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error While Enter Company Info" + ex.Message);
                }
            }
            else
            {
                int chkValUpd = 0;
                  if (chkBlockList.Checked == true)
                    chkValUpd = 1;
              
                try
                {
                    sqlConn = new SqlConnection(strCon);
                    sqlConn.Open();
                    
                    sqlCom = new SqlCommand("Update Company Set Co_Name = @cmpName ,Co_Category_Id =@cmpCategID, " +
                    " Co_Type_Id = @cmpTypeId,Co_Address =@cmpAddress,Block_Listed = @blockListed,co_tel =@cmpTel,co_fax =@cmpFax,co_email_address =@cmpEmail," +
                    " nationality = @Nationality,cr_expiry_date = @crDate,qatari_share = @qatariShare,co_comments = @cmpComments, co_shortname = @cmpShortname,CRNo = @crNo" +
                    ", update_date = @updateDate,update_user = @updateUser,WebPage= @WebPage,co_city= @co_city,co_state= @co_state,co_country= @co_country,co_zip= @co_zip Where Co_Id = @cmpId", sqlConn);
                    

                    sqlCom.Parameters.AddWithValue("@cmpId", _cmpID);
                    sqlCom.Parameters.AddWithValue("@cmpName", txtCmpName.Text);

                    sqlCom.Parameters.AddWithValue("@cmpCategID", cmbCategiry.SelectedValue);
                    sqlCom.Parameters.AddWithValue("@cmpTypeId", cmbCmpType.SelectedValue);
                    sqlCom.Parameters.AddWithValue("@cmpAddress", txtCmpAddress.Text);
                    sqlCom.Parameters.AddWithValue("@blockListed", chkValUpd);

                    sqlCom.Parameters.AddWithValue("@cmpTel", txtTelephone.Text);
                    sqlCom.Parameters.AddWithValue("@cmpFax", txtFaxNo.Text);
                    sqlCom.Parameters.AddWithValue("@cmpEmail", txtEmail.Text);
                    sqlCom.Parameters.AddWithValue("@Nationality", txtNationality.Text);

                    if (cmersialDate != null)
                        sqlCom.Parameters.AddWithValue("@crDate", cmersialDate);
                    else
                        sqlCom.Parameters.AddWithValue("@crDate", System.DBNull.Value);

                    sqlCom.Parameters.AddWithValue("@qatariShare", txtQuality.Text);
                    sqlCom.Parameters.AddWithValue("@cmpComments", txtComments.Text);
                    sqlCom.Parameters.AddWithValue("@cmpShortname", txtCmpShortName.Text);

                    sqlCom.Parameters.AddWithValue("@crNo", txtCrno.Text);

                    sqlCom.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                    sqlCom.Parameters.AddWithValue("@updateUser", _userName);

                    sqlCom.Parameters.AddWithValue("@WebPage", _txtWebPage.Text);
                    sqlCom.Parameters.AddWithValue("@co_city", _txtCity.Text);

                    sqlCom.Parameters.AddWithValue("@co_state", _txtState.Text);
                    sqlCom.Parameters.AddWithValue("@co_country", _txtCountry.Text);
                    sqlCom.Parameters.AddWithValue("@co_zip", _txtZip.Text);                    
                    sqlCom.ExecuteNonQuery();
                    sqlCom.Parameters.Clear();

                    if (cmbCntryNames.Text != "" && txtOtherShare2.Text != "")
                    {
                        sqlCom = new SqlCommand("Update CompanyShare Set countryName=@countryName ,countryShare=@countryShare " +
                        " Where Co_Id = @cmpId", sqlConn);
                        sqlCom.Parameters.AddWithValue("@countryName", cmbCntryNames.Text);
                        sqlCom.Parameters.AddWithValue("@countryShare", txtOtherShare2.Text);
                        sqlCom.Parameters.AddWithValue("@cmpId", _cmpID);
                        sqlCom.ExecuteNonQuery();
                        sqlCom.Parameters.Clear();
                    }
                   

                    foreach (ListViewItem item in lstCRCopies.Items)
                    {
                        using (SqlCommand command = new SqlCommand())
                        {
                            command.CommandText = @"select co_id from CRAttachment where co_id=" + _cmpID + " and crAttFileName='" + item.Text + "'";
                            command.Connection = sqlConn;
                            SqlDataReader sqlDtReader = command.ExecuteReader();
                            if (!sqlDtReader.HasRows)
                            {
                                sqlDtReader.Close();
                                command.CommandText = @"INSERT INTO CRAttachment(crAttFileName, crAttFile,co_id,create_date,create_user) VALUES (@crAttFileName, @crAttFile,@co_id,@createDate,@createUser)";
                                command.Connection = sqlConn;
                                command.Parameters.AddWithValue("@crAttFileName", item.Text);
                                command.Parameters.AddWithValue("@crAttFile", item.Tag);
                                command.Parameters.AddWithValue("@co_id", _cmpID);
                                command.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                                command.Parameters.AddWithValue("@createUser", _userName);
                                command.ExecuteNonQuery();
                                command.Dispose();
                            }  
                            else
                            {
                                sqlDtReader.Close();
                            }
                        }
                    }
                    sqlConn.Close();
                    MessageBox.Show("Rocords Updated Successfully!");
                    this.Close();
                }
                catch (Exception ex)
                {
                    sqlConn.Close();
                    MessageBox.Show("Exception occurred while performing operation on the company data");
                }
            }
        }
       

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtNationality.Text = "";
            txtQuality.Text = "";
            txtFaxNo.Text = "";
            txtTelephone.Text = "";
            txtEmail.Text = "";
            txtComments.Text = "";            
            txtCmpName.Text = "";
            txtCmpAddress.Text = "";

            cmbCmpType.SelectedIndex = -1;
            cmbCategiry.SelectedIndex = -1;
            this.Close();
        }
        Boolean chkCmpMode = false;
        private void frmContactInfo_Load_1(object sender, EventArgs e)
        {

            //mskExpireDate.Mask = "00/00/0000";
            //mskExpireDate.ValidatingType = typeof(System.DateTime);
            //mskExpireDate.TypeValidationCompleted += new TypeValidationEventHandler(mskExpireDate_TypeValidationCompleted);
            //mskExpireDate.KeyDown += new KeyEventHandler(mskExpireDate_KeyDown);

            //toolTip1.IsBalloon = true;

            cmnClass.PopulateComboBox(cmbCategiry,"Select Co_Category_Id,Co_Category_Name from COMPANY_CAT","Co_Category_Id","Co_Category_Name");
            cmnClass.PopulateComboBox(cmbCmpType, "select Co_Type_Id,Co_Type_Name from COMPANY_Type where Co_Type_Id<>4", "Co_Type_Id", "Co_Type_Name");

            if (_cmpID != 0)
            {
                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();

                string sqlQuery = "SELECT COMPANY.co_name, COMPANY.co_category_id, COMPANY.co_type_id, COMPANY.co_address, COMPANY.block_listed, COMPANY.co_tel, COMPANY.co_fax, " +
                         " COMPANY.co_email_address, COMPANY.nationality, COMPANY.cr_expiry_date, COMPANY.qatari_share,COMPANY_CAT.co_category_name,COMPANY_TYPE.co_type_name,COMPANY.co_comments,COMPANY.co_shortname,COMPANY.CRNo,WebPage,co_city,co_state,co_country,co_zip" +
                         " FROM COMPANY INNER JOIN " +
                         " COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id INNER JOIN COMPANY_TYPE ON COMPANY.co_type_id = COMPANY_TYPE.co_type_id Where Co_Id = '" + _cmpID + "'";
                
                sqlCom = new SqlCommand(sqlQuery, sqlConn);                
                SqlDataReader sqlReader = sqlCom.ExecuteReader();
                if (sqlReader.HasRows)
                {
                    chkCmpMode = true;
                    while (sqlReader.Read())
                    {
                        txtCmpName.Text = sqlReader[0].ToString().Replace("\r","").Replace("\n","");
                        cmbCategiry.Text = sqlReader[11].ToString();
                        cmbCmpType.Text = sqlReader[12].ToString();
                        txtCmpAddress.Text = sqlReader[3].ToString();

                        if (sqlReader[4].ToString() == "True")
                        {
                            chkBlockList.Checked = true;
                        }
                        else
                        {
                            chkBlockList.Checked = false;
                        }
                        txtTelephone.Text = sqlReader[5].ToString();
                        txtFaxNo.Text = sqlReader[6].ToString();
                        txtEmail.Text = sqlReader[7].ToString();
                        txtNationality.Text = sqlReader[8].ToString();

                        txtQuality.Text = sqlReader[10].ToString();
                       // dtpExpireDate.Text = sqlReader[9].ToString();
                        if (sqlReader[9].ToString() != "")
                        {
                            //mskExpireDate.Text = Convert.ToDateTime(sqlReader[9]).ToString("dd/MM/yyyy");

                            dtpCRDate.Text = Convert.ToDateTime(sqlReader[9]).ToString("dd/MMM/yyyy");

                            // DateTime date = DateTime.ParseExact(sqlReader[9], "dd/MMM/yyyy", CultureInfo.InvariantCulture);

                        }
  
                        txtComments.Text = sqlReader[13].ToString();
                        txtCmpShortName.Text = sqlReader[14].ToString();
                        txtCrno.Text = sqlReader[15].ToString();
                        _txtWebPage.Text = sqlReader[16].ToString();
                        _txtCity.Text = sqlReader[17].ToString();
                        _txtState.Text = sqlReader[18].ToString();
                        _txtCountry.Text = sqlReader[19].ToString();
                        _txtZip.Text = sqlReader[20].ToString();
                    }
                }
                sqlReader.Close();                 

                try
                {
                    //sqlConn.Open();
                    sqlQuery = "SELECT crAttFile,crAttFileName,crAttID FROM CRAttachment WHERE (co_id = " + _cmpID + ")";

                    SqlCommand sqlCommand = new SqlCommand(sqlQuery, sqlConn);
                    sqlReader = sqlCommand.ExecuteReader();
                    if (sqlReader.HasRows)
                    {                         
                        while (sqlReader.Read())
                        {
                            //docID = Convert.ToInt16(sqlReader[2].ToString());

                            ListViewItem lstItem = new ListViewItem();
                            lstItem.Text = sqlReader[1].ToString();
                            if (sqlReader[0] != DBNull.Value)
                                lstItem.Tag = (byte[])sqlReader[0];
                            lstItem.ImageIndex = Convert.ToInt32(sqlReader[2].ToString());
                            lstCRCopies.Items.Add(lstItem);                            
                        }
                    }
                    sqlReader.Close();
                    sqlCommand.Dispose();
                    //attFile = getImage(ref attFileName); 
                }
                catch (Exception ex)
                {
                    string exMsg = ex.Message;
                }
                finally
                {
                    sqlConn.Close();
                }                
            }
        }
        private bool nonNumberEntered = false;

        private void txtQuality_KeyDown(object sender, KeyEventArgs e)
        {
            nonNumberEntered = false;           
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            {
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    if ((e.KeyCode != Keys.Back) & (e.KeyCode != Keys.Enter))
                    {
                        nonNumberEntered = true;
                    }
                }
            }
        }
        private void txtQuality_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (nonNumberEntered == true)
            {
                MessageBox.Show("Please enter number only...");
                e.Handled = true;
            }
        }

        private void dtpExpireDate_ValueChanged(object sender, EventArgs e)
        {
        //    dtpExpireDate.CustomFormat = "dd/MMM/yyyy";
        //    dtpExpireDate.Text = dtpExpireDate.Value.ToString("dd/MMM/yyyy");
        }

        private void dtpExpireDate_KeyDown(object sender, KeyEventArgs e)
        {
            //if (e.KeyData == Keys.Delete)
            //{
            //    if (sender is DateTimePicker)
            //    {
            //        dtpExpireDate.CustomFormat = " ";
            //    }
            //}
        }
        private void txtNationality_KeyPress(object sender, KeyPressEventArgs e)
        {
            //if (Regex.IsMatch(txtNationality.Text, @"^[A-Z][A-Za-z]*$"))
            //{
            //    MessageBox.Show("Only use alphabates");
            //} 
        }

        private void txtCmpName_Leave(object sender, EventArgs e)
        {
           // if (_cmpID == 0)  // for edit mode
            if (txtCmpName.Text != "")            
                chkCompanyExist();
                       
        }
        private Boolean chkCompanyExist()
        {
            SqlConnection sqlConn = new SqlConnection(strCon);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("Select count(co_name),co_id from COMPANY where co_name='" + txtCmpName.Text.Trim() + "' GROUP BY co_name, co_id", sqlConn);
             
            int cmpID = 0; int iCnt = 0;

            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            if (sqlReader.HasRows == true)
            {                
                while (sqlReader.Read())
                {
                   //cmpCnt =  Convert.ToInt16(sqlReader[0]);
                   iCnt = iCnt + 1;
                   cmpID = Convert.ToInt16(sqlReader[1]);
                }
               

                if (iCnt == 1 && _cmpID != 0 && cmpID != _cmpID)
                {
                    MessageBox.Show("Entered Company Name is already in the system. Duplicate Company Name is not allowed.");
                    txtCmpName.Focus();
                    return false;
                }
                if (iCnt == 1 && _cmpID == 0)
                {
                    MessageBox.Show("Entered Company Name is already in the system. Duplicate Company Name is not allowed.");
                    txtCmpName.Focus();
                    return false;
                }
            }
            sqlReader.Close();
            return true;
        }
        private Boolean chk_ShortNameExist()
        {
            SqlConnection sqlConn = new SqlConnection(strCon);
            sqlConn.Open();
            SqlCommand sqlCom = new SqlCommand("select count(co_shortname),co_id from COMPANY Where co_shortname = '" + txtCmpShortName.Text + "' GROUP BY co_shortname, co_id", sqlConn);

            int cmpCnt = 0;
            int cmpID = 0; int iCnt = 0;

            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            if (sqlReader.HasRows == true)
            {
                while (sqlReader.Read())
                {
                    //cmpCnt =  Convert.ToInt16(sqlReader[0]);
                    iCnt = iCnt + 1;
                    cmpID = Convert.ToInt16(sqlReader[1]);
                }
               

                if (iCnt == 1 && _cmpID != 0 && cmpID != _cmpID)
                {
                    MessageBox.Show("Entered Short Name is already in the system. Duplicate Short Name is not allowed.");
                    txtCmpShortName.Focus();
                    return false;
                }
                if (iCnt == 1 && _cmpID == 0)
                {
                    MessageBox.Show("Entered Short Name is already in the system. Duplicate Short Name is not allowed.");
                    txtCmpShortName.Focus();
                    return false;
                }
            }
            sqlReader.Close(); 
            return true;
        }

        private void txtCmpShortName_Leave(object sender, EventArgs e)
        {
            // Commented By Varun
            //if (txtCmpShortName.Text != "")
            //{
            //    chk_ShortNameExist();
            //}           
        }

        private void txtEmail_Leave(object sender, EventArgs e)
        {
            if (txtEmail.Text != "")
            {
                if (EmailIsValid(txtEmail.Text) == false)
                {
                    MessageBox.Show("Please enter proper email address");
                    txtEmail.Focus();
                    return;
                }
            }
        }

        Regex ValidEmailRegex = CreateValidEmailRegex();
        private static Regex CreateValidEmailRegex()
        {
            string validEmailPattern = @"^(?!\.)(""([^""\r\\]|\\[""\r\\])*""|"
                + @"([-a-z0-9!#$%&'*+/=?^_`{|}~]|(?<!\.)\.)*)(?<!\.)"
                + @"@[a-z0-9][\w\.-]*[a-z0-9]\.[a-z][a-z\.]*[a-z]$";

            return new Regex(validEmailPattern, RegexOptions.IgnoreCase);
        }

        private bool EmailIsValid(string emailAddress)
        {
            bool isValid = ValidEmailRegex.IsMatch(emailAddress);
            return isValid;
        }
        

        private void txtQuality_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCmpName_Validating(object sender, CancelEventArgs e)
        {
            TextBox textbox = sender as TextBox;
            e.Cancel = string.IsNullOrEmpty(textbox.Text);               //.IsNullOrWhiteSpace(textbox.Text);
            //errorProvider1.SetError(textbox, "String cannot be empty");

            if (!Regex.IsMatch(textbox.Text, @"[a-zA-Z]"))
            {
                MessageBox.Show(textbox, "Please Enter Company Name");
                txtCmpName.Focus();
                return;
            }
        }


              

        private void mskExpireDate_KeyDown(object sender, KeyEventArgs e)
        {
            toolTip1.Hide(mskExpireDate);
        }
        
        public static bool IsDateTime(string txtDate)
        {
            DateTime tempDate;

            return DateTime.TryParse(txtDate, out tempDate) ? true : false;
        }        

        private void mskExpireDate_TypeValidationCompleted(object sender, TypeValidationEventArgs e)
        {
            MaskedTextBox mshText = null;
            if (sender is System.Windows.Forms.MaskedTextBox)            
                 mshText = sender as MaskedTextBox;

            if ((mskExpireDate.Text != "  /  /") && (mskExpireDate.Text != "  -  -"))
            {
                string stringValue = mshText.Text;
                Boolean chkDate = false;

                chkDate = IsDateTime(stringValue);

                if (stringValue.Length == 10)
                {
                    if (chkDate == false)
                    {
                        MessageBox.Show("Invalid Date,Please enter in dd/MM/yyyy Format");
                        mskExpireDate.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Date,Please enter full date");
                    mskExpireDate.Focus();
                }
            }           
        }





        private void chkDate()
        {
            //if (!e.IsValidInput)
            //{
            //    if ((mskExpireDate.Text != "  /  /") && (mskExpireDate.Text != "  -  -"))
            //    {
            //        toolTip1.ToolTipTitle = "Invalid Date";
            //        toolTip1.Show("The data you supplied must be a valid date in the format mm/dd/yyyy.", mskExpireDate, 0, -20, 5000);
            //        MessageBox.Show("Invalid Date");

            //        mskExpireDate.Focus();
            //    }
            //}
            //else
            //{
            //    //Now that the type has passed basic type validation, enforce more specific type rules.
            //    DateTime userDate = (DateTime)e.ReturnValue;
            //    cmersialDate = userDate.ToString();
            //    //if (userDate < DateTime.Now)
            //    //{
            //    //    toolTip1.ToolTipTitle = "Invalid Date";
            //    //    toolTip1.Show("The date in this field must be greater than today's date.", mskExpireDate, 0, -20, 5000);
            //    //    e.Cancel = true;
            //    //}
            //}
        }

        private void dtpCRDate_ValueChanged(object sender, EventArgs e)
        {
            dtpCRDate.CustomFormat = "dd/MMM/yyyy";
            dtpCRDate.Text = dtpCRDate.Value.ToString("dd/MMM/yyyy");
        }             


        private void dtpCRDate_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Delete)
            {
                if (sender is DateTimePicker)
                {
                    dtpCRDate.CustomFormat = " ";
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //int cmpShareID = getCompanyShareInfo();
            // int cmpID = 0;            
            string sqlQuery = "INSERT INTO CompanyShare(CO_ID,COUNTRYNAME,COUNTRYSHARE) VALUES(" + _cmpID + " ,'" + cmbCntryNames.SelectedItem + "', " + txtOtherShare2.Text + ")";             
            SqlConnection sqlConn = new SqlConnection(strCon);
            try
            {
                sqlConn.Open();
                SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
                sqlCom.ExecuteNonQuery();                
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlConn.Close();
            }
        }

        private int getCompanyShareInfo()
        {
            string strQuery = "Select max(CntrID) from CompanyShare";
            int strMaxNo = 0;
            SqlConnection sqlConn = new SqlConnection(strCon);
            try
            {
                sqlConn.Open();
                SqlCommand sqlCom = new SqlCommand(strQuery, sqlConn);
                SqlDataReader dr = sqlCom.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();                    
                    strMaxNo = Convert.ToInt32(dr[0]);                    
                }                
                dr.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlConn.Close();
            }
            return strMaxNo;
        }

        
        string attFileName = string.Empty;         
        private void addMultipleFiles(ref string _fileName)
        {
            System.IO.FileStream fileStream = null;
            System.IO.BinaryReader binaryReader = null;             
            byte[] buffer = null;
            lstCRCopies.Items.Clear();
            //lstRDPUploadedFiles.Items.Clear();
            try
            {
                OpenFileDialog op1 = new OpenFileDialog();
                op1.Multiselect = true;
                op1.ShowDialog();
                long totBytes = 0;


                if (op1.FileNames.Count() != 0)
                {                    
                    SqlCommand sqlCommand = new SqlCommand();
                    sqlCommand.Connection = sqlConn;
                    foreach (string s in op1.FileNames)
                    {                        
                        string[] strColl = s.Split('\\');
                        string fileName = strColl[strColl.Length - 1];
                        fileStream = new System.IO.FileStream(s, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                        binaryReader = new System.IO.BinaryReader(fileStream);
                        totBytes = new System.IO.FileInfo(s).Length;
                        buffer = binaryReader.ReadBytes((Int32)totBytes);
                        string specialChars = "`~!@#$%^&*(){}:<>?|[];";
                        foreach (char fChar in specialChars)
                        {
                            fileName = fileName.Replace(fChar.ToString(), "");
                        }
                        ListViewItem lstItem = new ListViewItem();
                        lstItem.Text = fileName;
                        lstItem.Tag = buffer;
                        lstCRCopies.View = View.LargeIcon;                         
                        lstCRCopies.Items.Add(lstItem);
                    }
                    fileStream.Close();
                    fileStream.Dispose();
                    binaryReader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error While Uploading the images, try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }      

       

        private void lstCRCopies_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            foreach (ListViewItem item in lstCRCopies.Items)
            {
                if (item.Text.Equals(lstCRCopies.SelectedItems[0].Text))
                {
                    string sName = item.Text;
                    byte[] _image = (byte[])item.Tag;

                    byte[] byteArray = _image;
                    MemoryStream mstream = new MemoryStream();
                    mstream.Write(byteArray, 0, byteArray.Length);

                    mstream.Seek(0, SeekOrigin.Begin);
                    //Modified By Varun on 29th Jan 2014 for opening the file with a specific ext. and to preserve the real name of the file
                    string ext = sName.Substring(sName.ToString().LastIndexOf('.'));
                    StringBuilder strBuild = new StringBuilder();
                    var tempFilePath = Path.ChangeExtension(Path.GetTempFileName(), ext);
                    strBuild.Append(tempFilePath.Substring(0, tempFilePath.LastIndexOf('\\')).ToString());
                    strBuild.Append("\\" + lstCRCopies.SelectedItems[0].Text);
                    if (File.Exists(strBuild.ToString()))
                        File.Delete(strBuild.ToString());
                    File.WriteAllBytes(strBuild.ToString(), byteArray);


                    Process.Start(strBuild.ToString());

                    mstream.Close();
                    return;
                }
            }        
        }

        private void btnCRFileUpload_Click(object sender, EventArgs e)
        {
            addMultipleFiles(ref attFileName);
        }

        private void btnCRRemoveAttachment_Click(object sender, EventArgs e)
        {
            if (lstCRCopies.Items.Count > 0 && lstCRCopies.SelectedIndices.Count == 0)
                MessageBox.Show("No Item is selected, Please select an Item", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
            {
                DialogResult dlgResult = DialogResult.Yes;
                dlgResult = MessageBox.Show("Are you sure you want to DELETE this Document?", "Delete Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (dlgResult.ToString() == "Yes")
                {
                   
                    sqlConn.Open();
                    foreach (ListViewItem item in lstCRCopies.SelectedItems)
                    {
                        using (SqlCommand command = new SqlCommand())
                        {                            
                            command.CommandText = @"DELETE FROM CRAttachment WHERE co_id = @coID and crAttFileName=@crAttFileName";
                            command.Connection = sqlConn;
                            command.Parameters.AddWithValue("@coID", _cmpID);
                            command.Parameters.AddWithValue("@crAttFileName", item.Text);                                                   
                            int ex = command.ExecuteNonQuery();
                            command.Dispose();
                            lstCRCopies.Items.Remove(item);
                        }
                    }
                    sqlConn.Close();
                }
            } 
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                string delSql = "delete from COMPANY where co_id=@coID"; // +_cmpID;
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    sqlConn.Open();
                    using (SqlCommand command = new SqlCommand())
                    {
                        command.CommandText = delSql;
                        command.Connection = sqlConn;
                        command.Parameters.AddWithValue("@coID", _cmpID);
                        //command.Parameters.AddWithValue("@crAttFileName", item.Text);       
                        int ex = command.ExecuteNonQuery();
                        command.Dispose();
                        MessageBox.Show("Company deleted successful", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //lstCRCopies.Items.Remove(item);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Occurred while deleting the company name.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);                 
            }

            
            
        }

    }
}
