﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using DataGridViewAutoFilter;
using System.Configuration;
using System.Data.SqlClient;
using TenderTrackingSystem.Contacts;
using TenderTrackingSystem;

namespace MDI_ParenrForm
{
    public partial class frmContactsDefault : Form
    {
        //int mintTotalRecords = 0;
        //int mintPageSize = 0;
        //int mintPageCount = 0;
        //int mintCurrentPage = 1;

        static string staticUserName = null;

        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();

        // Protected Connection.
        protected SqlConnection sqlConn;
        protected SqlCommand sqlCom;

        protected SqlDataReader sqlReader;
        private System.Windows.Forms.Label label1;
        //decimal bdgtEstimated = 0;
        CreateCheckBox chkBox = null;
        CheckBox headerCheckBox = null;
        BindingSource myBindingSource = null;
        DataTable dtTemp = null;
        string _userName = string.Empty;

        IList<string> userRightsColl = new List<string>();
        public frmContactsDefault(IList<string> userRightsCollContacts, string user)
        {
            InitializeComponent();
            userRightsColl = userRightsCollContacts;
            _userName = user;
        }

        private void frmContactsDefault_Load(object sender, EventArgs e)
        {
            rePopulateDataGridView_Contact_Person_EntryData("Admin");

            //DAL dalObj = new DAL();

            //dalObj.populateCmbBox("Select co_type_name From COMPANY_TYPE Order by co_type_id", cmbCmpType);
            //cmbCmpType.SelectedIndex = -1;
           
        }
        private void rePopulateDataGridView_Contact_Person_EntryData(string userName)
        {
            //InitializeComponent();

            headerCheckBox = new CheckBox();
            chkBox = new CreateCheckBox(dgView, headerCheckBox);
            chkBox.AddHeaderCheckBox();

            if (dgView.Rows.Count > 0)
                return;

            //this.dgvContactPerson.CellContentClick += new DataGridViewCellEventHandler(dgvContactPerson_CellContentClick);
            staticUserName = userName;

            var col0 = new DataGridViewCheckBoxColumn();
            var col1 = new DataGridViewAutoFilterTextBoxColumn();  // DataGridViewLinkColumn();
            var col2 = new DataGridViewAutoFilterTextBoxColumn();
            var col3 = new DataGridViewAutoFilterTextBoxColumn();
            var col4 = new DataGridViewAutoFilterTextBoxColumn();
            var col5 = new DataGridViewAutoFilterTextBoxColumn();
            var col6 = new DataGridViewLinkColumn();
            var col7 = new DataGridViewAutoFilterTextBoxColumn();
            var col8 = new DataGridViewAutoFilterTextBoxColumn();
            var col9 = new DataGridViewAutoFilterTextBoxColumn();

            dgView.Columns.AddRange(new DataGridViewColumn[] { col0, col1, col2, col3, col4, col5, col6, col7, col8, col9 });

            //dgView.Columns.AddRange(new DataGridViewColumn[] { col0, col1, col2, col3, col4, col5, col6, col9 });

            dgView.AutoGenerateColumns = false;
            dgView.AllowUserToAddRows = false;
                       
            //dgView.AutoResizeColumns();

            col0.Name = "chkBxSelect";
            col0.DataPropertyName = "Select";
            col0.HeaderText = "";
            col0.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            col0.Width = 45;

            col1.DataPropertyName = "PersonName";
            col1.HeaderText = "Person Name";
            col1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            
            col2.DataPropertyName = "Intial";
            col2.HeaderText = "Intial";
            col2.Resizable = System.Windows.Forms.DataGridViewTriState.True;

            col3.DataPropertyName = "Position";
            col3.HeaderText = "Position";
            col3.Resizable = System.Windows.Forms.DataGridViewTriState.True;

            col4.DataPropertyName = "Telephone No";
            col4.HeaderText = "Telephone No";
            col4.Resizable = System.Windows.Forms.DataGridViewTriState.True;

            col5.DataPropertyName = "MobileNo";
            col5.HeaderText = "MobileNo";
            col5.Resizable = System.Windows.Forms.DataGridViewTriState.True;

            col6.DataPropertyName = "Email";
            col6.HeaderText = "Email";
            col6.Resizable = System.Windows.Forms.DataGridViewTriState.True;            

            col7.DataPropertyName = "CompanyName";
            col7.HeaderText = "CompanyName/ Department";
            col7.Resizable = System.Windows.Forms.DataGridViewTriState.True;

            col8.DataPropertyName = "Company Category";
            col8.HeaderText = "Company Category";
            col8.Resizable = System.Windows.Forms.DataGridViewTriState.True;

            col9.DataPropertyName = "EmpID";
            col9.HeaderText = "EmpID";
            col9.Resizable = System.Windows.Forms.DataGridViewTriState.True;

            BindingSource myBindingSource = null;
            try
            {
                DataTable finalDt = new DataTable("Company");
                finalDt.Columns.Add("Select");
                finalDt.Columns.Add("PersonName");
                finalDt.Columns.Add("Intial");
                finalDt.Columns.Add("Position");
                finalDt.Columns.Add("Telephone No");

                finalDt.Columns.Add("MobileNo");
                finalDt.Columns.Add("Email");
                finalDt.Columns.Add("CompanyName");
                finalDt.Columns.Add("Company Category");
                finalDt.Columns.Add("EmpID");

                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                                
                DAL dalObj = new DAL();
                DataTable dtContacts = dalObj.GetDataFromDB("Contacts", "SELECT FirstName, LastName, ShortName, replace(JobTitle,',','|') as JobTitle, replace(MobilePhone,',','|') as MobilePhone, replace(EmailAddress,',','|') as EmailAddress," +
                "replace(BusinessPhone,',','|') as BusinessPhone,employee_id,co_id FROM Contacts Where employee_id <> 117 AND employee_id <> 83 AND employee_id <> 122 ");

                DataTable dtCompany = dalObj.GetDataFromDB("Company", "SELECT COMPANY.co_id,COMPANY.co_name,COMPANY.employee_id,co_category_id FROM COMPANY");

                DataTable dtCmpCat = dalObj.GetDataFromDB("CompanyCat", "SELECT co_category_id,co_category_name FROM COMPANY_CAT ");


                IEnumerable<object> iEnum = null;
                iEnum = (from conts in dtContacts.AsEnumerable()
                              join cmp in dtCompany.AsEnumerable() on conts.Field<int?>("co_id") equals cmp.Field<int>("co_id")
                              join cmpCat in dtCmpCat.AsEnumerable() on cmp.Field<int?>("co_category_id") equals cmpCat.Field<int>("co_category_id")                              
                              select new
                              {
                                  FirstName = conts.Field<string>("FirstName"),
                                  LastName = conts.Field<string>("LastName"),
                                  ShortName = conts.Field<string>("ShortName"),
                                  JobTitle = conts.Field<string>("JobTitle"),
                                  BusinessPhone = conts.Field<string>("BusinessPhone"),
                                  MobilePhone = conts.Field<string>("MobilePhone"),
                                  EmailAddress = conts.Field<string>("EmailAddress"),
                                  CoName = cmp.Field<string>("co_name"),
                                  CoCategoryName = cmpCat.Field<string>("co_category_name"),
                                  EmployeeId = conts.Field<int>("employee_id")
                              }).OrderByDescending(item => item.FirstName).ToList();

                //Order by Contacts.FirstName

                //INNER JOIN Contacts ON COMPANY.co_id = Contacts.co_id INNER JOIN " +
                //     ON COMPANY.co_category_id = COMPANY_CAT.co_category_id
                //COMPANY.co_name, COMPANY_CAT.co_category_name from COMPANY
                //SELECT from COMPANY_CAT

                foreach (object drContact in iEnum)
                {
                    DataRow dr = finalDt.NewRow();

                    try
                    {

                        //dr[1] = strProj;    //ProjectId
                        dr[1] = drContact.ToString().Split(',')[0].Split('=')[1].Trim() + " " + drContact.ToString().Split(',')[1].Split('=')[1].Trim();  //FirstName
                        dr[2] = drContact.ToString().Split(',')[2].Split('=')[1].Trim();  //ProjectCode
                        dr[3] = drContact.ToString().Split(',')[3].Split('=')[1].Trim().Replace('|', ',');  //ProjTitle                   

                        dr[4] = drContact.ToString().Split(',')[4].Split('=')[1].Trim().Replace('|', ',');  //BusinessPhone
                        dr[5] = drContact.ToString().Split(',')[5].Split('=')[1].Trim().Replace('|', ',');  //MobilePhone

                        dr[6] = drContact.ToString().Split(',')[6].Split('=')[1].Trim().Replace('|', ',');  //EmailAddress
                        dr[7] = drContact.ToString().Split(',')[7].Split('=')[1].Trim().Replace('|', ',');  //co_name

                        dr[8] = drContact.ToString().Split(',')[8].Split('=')[1].Trim();  //co_category_name
                        dr[9] = drContact.ToString().Split(',')[9].Split('=')[1].Trim();  //employee_id

                        //if ((!profile_Name.Equals("EBSD Staff") && userRightsColl.Contains("104")) && userRightsColl.Count != 0)
                        //{
                        //    //dr[10] = drProj[14];  //ContractNo 
                        //    dr[10] = drContact.ToString().Split(',')[9].Split('=')[1].Trim();  //FiscalYear
                        //    dr[11] = drContact.ToString().Split(',')[10].Split('=')[1].Trim();  //UserDepartment 
                        //    dr[12] = drContact.ToString().Split(',')[11].Split('=')[1].Trim();  //Qs 
                        //    dr[13] = drContact.ToString().Split(',')[12].Split('=')[1].Trim();  //Handl
                        //    dr[14] = drContact.ToString().Split(',')[13].Split('=')[1].Trim();  //Staff 
                        //    dr[15] = rowId;
                        //}
                        //else if (profile_Name.Equals("EBSD Staff"))
                        //{
                        //    dr[10] = drContact.ToString().Split(',')[14].Split('=')[1].Trim();  //ContractNo 
                        //    dr[11] = drContact.ToString().Split(',')[9].Split('=')[1].Trim();  //FiscalYear 
                        //    dr[12] = drContact.ToString().Split(',')[10].Split('=')[1].Trim();  //UserDepartment
                        //    dr[13] = drContact.ToString().Split(',')[11].Split('=')[1].Trim();  //Qs 
                        //    dr[14] = drContact.ToString().Split(',')[12].Split('=')[1].Trim();  //Handl
                        //    dr[15] = drContact.ToString().Split(',')[13].Split('=')[1].Trim();  //Staff 
                        //    //dr[16] = drProj[15];  //ProjCreateDate                           
                        //    //dr[17] = drProj[16];  //ProjUpdateDate                           
                        //    dr[16] = drContact.ToString().Split(',')[15].Split('=')[1].Trim();  //MozanahID                           
                        //    dr[17] = rowId;
                        //}
                        //else if ((!profile_Name.Equals("EBSD Staff") && !userRightsColl.Contains("104")) || userRightsColl.Count == 0)
                        //{
                        //    //string contractNo = drProj[14].ToString();
                        //    dr[10] = drContact.ToString().Split(',')[14].Split('=')[1].Trim(); //ContractNoWorkOrderNo

                        //    //if (contractNo.Contains("C") || contractNo.Contains("P"))
                        //    //{
                        //    //    contractNo = contractNo.Split('-')[0];
                        //    //    if(contractNo!="")
                        //    //    {
                        //    //        dr[11] = FindSuccessfulBidders(dalObj, drProj, contractNo);
                        //    //    }                            
                        //    //}

                        //    dr[11] = drContact.ToString().Split(',')[9].Split('=')[1].Trim();  //FiscalYear
                        //    dr[12] = drContact.ToString().Split(',')[10].Split('=')[1].Trim();  //UserDepartment 
                        //    dr[13] = drContact.ToString().Split(',')[11].Split('=')[1].Trim();  //Qs 
                        //    dr[14] = drContact.ToString().Split(',')[12].Split('=')[1].Trim();  //Handl
                        //    dr[15] = drContact.ToString().Split(',')[13].Split('=')[1].Trim();  //Staff 
                        //    dr[16] = rowId;

                        //    //dr[11] = drProj[9];  //FiscalYear
                        //    //dr[12] = drProj[10];  //UserDepartment 
                        //    //dr[13] = drProj[11];  //Qs 
                        //    //dr[14] = drProj[12];  //Handl
                        //    //dr[15] = drProj[13];  //Staff 
                        //    //dr[16] = rowId;                            

                        //}
                    }
                    catch (Exception ex)
                    {
                        string str = null;
                    }
                    //rowId++;
                    finalDt.Rows.Add(dr);
                    finalDt.AcceptChanges();
                }

               
                //finalDt.AcceptChanges();
                //sqlCom = new SqlCommand(sqlQuery, sqlConn);
                //sqlReader = sqlCom.ExecuteReader();

                //while (sqlReader.Read())
                //{
                //    DataRow dr = finalDt.NewRow();
                //    dr[1] = sqlReader["FirstName"] + " " + sqlReader["LastName"];   //Employee_Name
                //    dr[2] = sqlReader["ShortName"];   //Emp_Intial
                //    dr[3] = sqlReader["JobTitle"];   //Position
                //    dr[4] = sqlReader["BusinessPhone"];   //Emp_Telephone_No
                //    dr[5] = sqlReader["MobilePhone"];   //    MobileNo Emp_Fax_No 
                //    dr[6] = sqlReader["EmailAddress"];   //Email_Address
                //    dr[7] = sqlReader["co_name"];   //Co_Name
                //    dr[8] = sqlReader["co_category_name"];    //co_category_name
                //    dr[9] = sqlReader["employee_id"];    //Employee_No
                //    finalDt.Rows.Add(dr);
                //    finalDt.AcceptChanges();
                //}
                //sqlReader.Close();

                myBindingSource = new BindingSource(finalDt, null);
                dtTemp = finalDt;

                dgView.DataSource = myBindingSource;
                dgView.Columns[9].Visible = false;
                dgView.Columns[2].Visible = false;
                dgView.Columns[8].Visible = false;
                lblCnt.Text = "Record Count:" + dgView.Rows.Count.ToString();
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }

            headerCheckBox.KeyUp += new KeyEventHandler(chkBox.HeaderCheckBox_KeyUp);
            headerCheckBox.MouseClick += new MouseEventHandler(chkBox.HeaderCheckBox_MouseClick);
            dgView.CellContentClick += new DataGridViewCellEventHandler(chkBox.dgvSelectAll_CellContentClick);             
            dgView.CurrentCellDirtyStateChanged += new EventHandler(chkBox.dgvSelectAll_CurrentCellDirtyStateChanged);
            dgView.CellPainting += new DataGridViewCellPaintingEventHandler(chkBox.dgvSelectAll_CellPainting);

           
            //
            // label1
            // 
            this.label1 = new Label();
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Service Uri:";            
        }
        private void button4_Click(object sender, EventArgs e)
        {
            if (userRightsColl.Contains("26"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }
            TenderTrackingSystem.Contacts.frmContactPerson frmPerson = new frmContactPerson(userRightsColl, _userName,false);
            frmPerson.StartPosition = FormStartPosition.CenterScreen;
            frmPerson.ShowDialog();

            //loadContactInfo();
            //frmPerson.ShowDialog(this);
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (userRightsColl.Contains("27"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            List<int> lstObj = new List<int>();
            int empId = 0;

            int iCnt = 0;
            for (int iCounter = 0; iCounter < dgView.RowCount; iCounter++)
            {
                DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgView.Rows[iCounter].Cells[0];

                if (chkactive.Value != null)
                {
                    if (chkactive.Value.ToString().ToLower() == "true")
                        iCnt = iCnt + 1;
                }
            }
          
            for (int iCounter = 0; iCounter < dgView.RowCount; iCounter++)
            {
                DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgView.Rows[iCounter].Cells[0];
                if (chkactive.Value != null)
                {
                    if (chkactive.Value.ToString().ToLower() == "true")
                    {
                        empId = Convert.ToInt16(dgView.Rows[iCounter].Cells[9].Value);

                        try
                        {
                            sqlConn.Open();
                            sqlCom = new SqlCommand("delete from CONTACTS where EMPLOYEE_ID = " + empId + "", sqlConn);
                            sqlCom.ExecuteNonQuery();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error while deleting the Employee ", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        finally
                        {
                            sqlConn.Close();
                        }
                        lstObj.Add(iCounter);
                    }
                }
            }
            short sClear = 0;
            if (dgView.Rows.Count == lstObj.Count)
            {
                dgView.Rows.RemoveAt(lstObj[0]);
                sClear = 1;
            }
            if (sClear != 1)
            {
                for (int iCounter = 0; iCounter < lstObj.Count; iCounter++)
                {
                    if (iCounter == 0)
                        dgView.Rows.RemoveAt(lstObj[iCounter]);
                    if (iCounter != 0)
                        dgView.Rows.RemoveAt(lstObj[iCounter] - 1);
                }
            }
            if (lstObj.Count == 0)
                MessageBox.Show("Please select a record from GridView", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //else
            //    loadContactInfo();
        }
        private void getEmployeeInfo(int empID)
        {
            //string strEmp = "Select * from Controctors where ";
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (userRightsColl.Contains("26"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }
            List<int> lstObj = new List<int>();
            int empId = 0;

            int iCnt = 0;
            for (int iCounter = 0; iCounter < dgView.RowCount; iCounter++)
            {
                DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgView.Rows[iCounter].Cells[0];
                if (chkactive.Value != null)
                {
                    if (chkactive.Value.ToString().ToLower() == "true")
                        iCnt = iCnt + 1;
                }
            }
            if (iCnt > 1)
            {
                MessageBox.Show("Please Select Only One Record For Edit");
                return;
            }
            for (int iCounter = 0; iCounter < dgView.RowCount; iCounter++)
            {
                DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgView.Rows[iCounter].Cells[0];

                if (chkactive.Value != null)
                {
                    if (chkactive.Value.ToString().ToLower() == "true")
                    {
                        empId = Convert.ToInt16(dgView.Rows[iCounter].Cells[9].Value.ToString().Replace('}',' ').Trim());
                        try
                        {
                            TenderTrackingSystem.Contacts.frmContactPerson frm = new TenderTrackingSystem.Contacts.frmContactPerson(userRightsColl, empId,_userName,false);
                            frm.StartPosition = FormStartPosition.CenterScreen;
                            frm.ShowDialog(this);                            
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error while Editing the Contact Details", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        finally
                        {
                            sqlConn.Close();
                        }
                        lstObj.Add(iCounter);
                    }
                }
            }
            if (lstObj.Count == 0)
                MessageBox.Show("Please select a record from GridView", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //else
            //    loadContactInfo();
           
        }
        int scrollVal;
        private void btnLast_Click(object sender, EventArgs e)
        {
           scrollVal = scrollVal - 5;
            if (scrollVal <= 0)
            {
                scrollVal = 0;
            }
            //finalDt.Clear();
            //pagingAdapter.Fill(finalDt, scrollVal, 5, "authors_table");
            
        }

        private void dgView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {          
            dgView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            int colIndex = e.ColumnIndex;
            int rowIndex = e.RowIndex;
            if (colIndex == 6)
            {
                CommonClass comCls = new CommonClass(_userName);

                comCls.CreateOutlookEmail(dgView.Rows[rowIndex].Cells[6].Value.ToString(), null,"My Subject");
            }
        }
        private void btnRefreshCmp_Click(object sender, EventArgs e)
        {
            txtContactFilter.Text = "";
            txtJobTitle.Text = "";
            loadContactInfo();
        }
        private void loadContactInfo()
        {
            BindingSource myBindingSource = null;
            try
            {
                DataTable finalDt = new DataTable("Company");
                finalDt.Columns.Add("Select");
                finalDt.Columns.Add("PersonName");
                finalDt.Columns.Add("Intial");
                finalDt.Columns.Add("Position");
                finalDt.Columns.Add("Telephone No");

                finalDt.Columns.Add("MobileNo");
                finalDt.Columns.Add("Email");
                finalDt.Columns.Add("Company Name");
                finalDt.Columns.Add("Company Category");
                finalDt.Columns.Add("EmpID");

                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();

                string sqlQuery = "SELECT Contacts.LastName, Contacts.ShortName, Contacts.JobTitle, Contacts.MobilePhone, Contacts.MobilePhone, Contacts.EmailAddress, " +
                       " COMPANY.co_name, COMPANY_CAT.co_category_name, Contacts.employee_id, Contacts.BusinessPhone,Contacts.FirstName FROM COMPANY INNER JOIN Contacts ON COMPANY.co_id = Contacts.co_id INNER JOIN " +
                       " COMPANY_CAT ON COMPANY.co_category_id = COMPANY_CAT.co_category_id Where Contacts.employee_id <> 117 AND Contacts.employee_id <> 83 and Contacts.employee_id <> 122 Order by Contacts.FirstName ";

                finalDt.AcceptChanges();
                sqlCom = new SqlCommand(sqlQuery, sqlConn);
                sqlReader = sqlCom.ExecuteReader();

                while (sqlReader.Read())
                {
                    DataRow dr = finalDt.NewRow();
                    dr[1] = sqlReader[10] + " " + sqlReader[0];   //Employee_Name
                    dr[2] = sqlReader[1];   //Emp_Intial
                    dr[3] = sqlReader[2];   //Position
                    dr[4] = sqlReader[9];   //Emp_Telephone_No
                    dr[5] = sqlReader[4];   //MobileNo
                    dr[6] = sqlReader[5];   //Email_Address
                    dr[7] = sqlReader[6];   //Co_Name
                    dr[8] = sqlReader[7];    //co_category_name
                    dr[9] = sqlReader[8];    //Employee_No
                    finalDt.Rows.Add(dr);
                    finalDt.AcceptChanges();
                }

                sqlReader.Close();
                myBindingSource = new BindingSource(finalDt, null);
                dtTemp = finalDt;

                dgView.DataSource = myBindingSource;
                dgView.Columns[9].Visible = false;
                dgView.Columns[2].Visible = false;
                dgView.Columns[8].Visible = false;
                lblCnt.Text = dgView.Rows.Count.ToString();
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }        
        }
        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtContactFilter_KeyDown(object sender, KeyEventArgs e)
        {
            filterCombo();
        }

        private void txtContactFilter_KeyPress(object sender, KeyPressEventArgs e)
        {
            filterCombo();
        }

        private void txtJobTitle_KeyPress(object sender, KeyPressEventArgs e)
        {
            filterCombo();
        }

        private void txtJobTitle_KeyUp(object sender, KeyEventArgs e)
        {
            filterCombo();
        }

        private void cmbCmpType_SelectionChangeCommitted(object sender, EventArgs e)
        {
            filterCombo();
        }

        public void filterCombo()
        {
            string filterQuery = string.Empty;
            
            if (txtContactFilter.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "PersonName like '%" + txtContactFilter.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "PersonName like '%" + txtContactFilter.Text + "%'";
                }
            }
            if (txtJobTitle.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "Position like '%" + txtJobTitle.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "Position like '%" + txtJobTitle.Text + "%'";
                }
            }

            if (txtCompanyName.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "CompanyName like '%" + txtCompanyName.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "CompanyName like '%" + txtCompanyName.Text + "%'";
                }
            }

            //if (cmbCmpType.SelectedIndex != -1)
            //{
            //    if (filterQuery == "")
            //    {
            //        filterQuery = "CompanyType = '" + cmbCmpType.SelectedItem.ToString() + "'";
            //    }
            //    else
            //    {
            //        filterQuery = filterQuery + " and " + "CompanyType = '" + cmbCmpType.SelectedItem.ToString() + "'";
            //    }
            //}
            //else if (cmbCmpType.Text != "")
            //{
            //    if (filterQuery == "")
            //    {
            //        filterQuery = "CompanyType like '%" + cmbCmpType.Text + "%'";
            //    }
            //    else
            //    {
            //        filterQuery = filterQuery + " and " + "CompanyType like '" + cmbCmpType.Text + "'";
            //    }
            //}           

            if (filterQuery == "")
            {
                GridFillForContacts("");
            }
            else
            {
                GridFillForContacts(filterQuery);
            }
        }

        DataTable dtTempForCombo = null;
        private void GridFillForContacts(string filterQuery)
        {
            dtTempForCombo = dtTemp;
            int iCnt = dtTempForCombo.Rows.Count;
            DataTable dtCmbTbl = null;
            if (dtTempForCombo.Select(filterQuery).Length != 0)
            {
                dtCmbTbl = dtTempForCombo.Select(filterQuery).CopyToDataTable();
                int jCnt = dtCmbTbl.Rows.Count;
                try
                {
                    myBindingSource = new BindingSource(dtCmbTbl, null);
                    dgView.DataSource = myBindingSource;
                    dtTempForCombo = dtCmbTbl;

                    //dgView.ColumnHeadersDefaultCellStyle.BackColor = Color.Olive;
                    //dgView.ColumnHeadersDefaultCellStyle.ForeColor = Color.Blue;
                    //dgView.ColumnHeadersDefaultCellStyle.Font = new Font(dgView.Font, FontStyle.Bold);

                    dgView.EnableHeadersVisualStyles = false;

                    dgView.Columns[9].Visible = false;
                    dgView.Columns[2].Visible = false;
                    dgView.Columns[8].Visible = false;

                    lblCnt.Text = dgView.Rows.Count.ToString();
                }
                catch (Exception ex)
                {
                    string exMsg = ex.Message;
                }
                finally
                {
                }
            }
            else
            {
                DataTable nullTable = new DataTable();
                dtCmbTbl = null;
                myBindingSource = new BindingSource(nullTable, null);
                dgView.DataSource = myBindingSource;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtCompanyName_KeyDown(object sender, KeyEventArgs e)
        {
            filterCombo();
        }

        private void txtCompanyName_KeyPress(object sender, KeyPressEventArgs e)
        {
            filterCombo();
        }

        private void btnExportToExcel_Click(object sender, EventArgs e)
        {
            CommonClass comCls = new CommonClass(_userName);
            string _fileName = comCls.SelectTextFile("@C:");
            comCls.export_datagridview_to_excel(dgView, _fileName, 'C');
        }
         
    }
}
