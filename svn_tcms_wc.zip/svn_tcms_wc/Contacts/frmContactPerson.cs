﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using MDI_ParenrForm;
using System.Text.RegularExpressions;

namespace TenderTrackingSystem.Contacts
{
    public partial class frmContactPerson : Form
    { 
        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();
        protected SqlConnection sqlConn;
        protected SqlCommand sqlCom;
        protected SqlDataReader sqlReader;

        CommonClass cmnCls = new CommonClass("");

        IList<string> userRightsColl = new List<string>();
        int _empID = 0;
        string _userName = string.Empty;
        bool _isHeadOfSection = false;

        public frmContactPerson(IList<string> userRightsCollContacts, int empID, string user,bool isHeadOfSection) // Edit Window
        {
            InitializeComponent();
            userRightsColl = userRightsCollContacts;
            _empID = empID;
            _userName = user;
            _isHeadOfSection = isHeadOfSection;
            cmnCls.PopulateComboBox(cmbUserDept, "Select department_id,Department from Department order by Department", "department_id", "Department");
            FillEmployeeUpdateWindow(_empID);
            btnSave.Text = "Update";
        }
        public frmContactPerson(IList<string> userRightsCollContacts, string user,bool isHeadOfSection)    // New Entry
        {
            InitializeComponent();
            userRightsColl = userRightsCollContacts;
            _userName = user;
            _isHeadOfSection = isHeadOfSection;            
        }
        private void frmContactPerson_Load(object sender, EventArgs e)
        {
            if (cmbCmpType.Items.Count == 0)
                cmnCls.PopulateComboBox(cmbCmpType, "Select Co_Id,Co_Name from Company order by Co_Name", "Co_Id", "Co_Name");

            // Added by Varun on 22/Jun/15
            if (cmbUserDept.Items.Count == 0)
                cmnCls.PopulateComboBox(cmbUserDept, "Select department_id,Department from Department order by Department", "department_id", "Department");
        }
        private bool ValidateControls()
        {
            Boolean chkCntrls = true;
            if (txtFirstName.Text == string.Empty)
            {
                chkCntrls = false;
                MessageBox.Show("Please Enter Employee Name");
                return chkCntrls;
            }
            //if (txtIntial.Text == string.Empty)
            //{
            //    chkCntrls = false;
            //    MessageBox.Show("Please Enter Employee Intial");
            //    return chkCntrls; ;
            //}
            if (cmbCmpType.SelectedIndex == -1)
            {
                chkCntrls = false;
                MessageBox.Show("Please select Company Type");
                return chkCntrls;
            }
           
            return chkCntrls;
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            Boolean chkCntl = ValidateControls();
            

            if (chkCntl == false)
                return;
            if (_empID == 0)
            {
                if (chk_ContactExist_New(false) == false)
                    return;
                InsertContactPersonInfo();
            }
            else
            {
                if (chk_ContactExist_New(true) == false)
                    return;
                //if (!CheckForDuplicateContactPerson())
                //    return;
                UpdateContactPersonInfo(_empID);
            }
        }
        private Boolean chk_ContactExist()
        {
            SqlConnection sqlConn = new SqlConnection(strCon);
            sqlConn.Open();

            string sqlQuery = "SELECT  COUNT(Contacts.employee_id) AS empCnt,Contacts.FirstName, Contacts.LastName, COMPANY.co_name,Contacts.employee_id FROM  Contacts INNER JOIN " +
           "  COMPANY ON Contacts.co_id = COMPANY.co_id" +
            " WHERE (Contacts.FirstName = '" + txtFirstName.Text + "') AND (Contacts.LastName ='" + txtLastName.Text + "') AND (COMPANY.co_name = '" + cmbCmpType.Text.Trim() + "') " + 
            " GROUP BY Contacts.employee_id, Contacts.FirstName, Contacts.LastName, COMPANY.co_name";
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            
            int empID = 0; int iCnt = 0;

            sqlReader = sqlCom.ExecuteReader();
            if (sqlReader.HasRows == true)
            {
                while (sqlReader.Read())
                {
                    //cmpCnt =  Convert.ToInt16(sqlReader[0]);
                    iCnt = iCnt + 1;
                    empID = Convert.ToInt16(sqlReader[4]);
                }
                sqlReader.Close();

                if (iCnt == 1 && _empID != 0 && empID != _empID)
                {
                    MessageBox.Show("Entered Contact Person is already recorded. Please check the name and Company.");
                    txtFirstName.Focus();
                    return false;
                }
                if (iCnt == 1 && _empID == 0)
                {
                    MessageBox.Show("Entered Contact Person is already recorded. Please check the name and Company.");
                    txtFirstName.Focus();
                    return false;
                }
            }
            
            return true;
        }

       

        private void InsertContactPersonInfo()
        {            
            SqlConnection sqlCon = new SqlConnection(strCon);
            sqlCon.Open();
            SqlCommand sqlCom = new SqlCommand("select max(employee_id) from Contacts", sqlCon);
            sqlReader = sqlCom.ExecuteReader();
            sqlReader.Read();
            int emp_ID = Convert.ToInt32(sqlReader[0]) + 1;
            sqlReader.Close();
            sqlCon.Close();

            int chkVal = 0;
            if (chkAuthor.Checked == true)
                chkVal = 1;

            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        cmd.CommandText = @"INSERT INTO CONTACTS(co_id,employee_id,FirstName,LastName,Company, " +
                            " AuthorizedRep,ShortName,JobTitle,MobilePhone,BusinessPhone,FaxNumber,EmailAddress,create_date,create_user,department_id) VALUES(@cmpId,@empId,@empFirstName,@empLastName,@cmpName,@authRep,@shortName,@Position,"+
                        "@empMobile,@businessNo,@empFax,@email_address,@createDate,@createUser,@department_id)";

                        cmd.Parameters.AddWithValue("@empId", emp_ID);
                        cmd.Parameters.AddWithValue("@cmpId", cmbCmpType.SelectedValue);
                        cmd.Parameters.AddWithValue("@empFirstName", txtFirstName.Text);
                        cmd.Parameters.AddWithValue("@empLastName", txtLastName.Text);
                        cmd.Parameters.AddWithValue("@cmpName", cmbCmpType.Text);
                        cmd.Parameters.AddWithValue("@authRep", chkVal);
                        
                        if (txtIntial.Text =="")
                            cmd.Parameters.AddWithValue("@shortName", System.DBNull.Value);
                        else
                        cmd.Parameters.AddWithValue("@shortName", txtIntial.Text);

                        cmd.Parameters.AddWithValue("@Position", txtPosition.Text);
                        cmd.Parameters.AddWithValue("@businessNo", txtTelephone.Text);
                        cmd.Parameters.AddWithValue("@empFax", txtFaxNo.Text);
                        cmd.Parameters.AddWithValue("@empMobile", txtMobile.Text);
                        cmd.Parameters.AddWithValue("@email_address", txtEmail.Text);

                        cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@createUser", _userName);
                        if(cmbUserDept.SelectedValue != "21")
                            cmd.Parameters.AddWithValue("@department_id", cmbUserDept.SelectedValue);
                        else
                            cmd.Parameters.AddWithValue("@department_id", DBNull.Value);
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        MessageBox.Show("Employee Details Added Succesfully");
                        this.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE DATES records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        //Added By Varun
        private bool CheckForDuplicateContactPerson()
        {
            bool isCheck = true;
            SqlConnection sqlCon = new SqlConnection(strCon);
            sqlCon.Open();

            string sqlQuery = "SELECT Contacts.FirstName, Contacts.LastName, COMPANY.co_name FROM  Contacts INNER JOIN " +
            "  COMPANY ON Contacts.co_id = COMPANY.co_id" +
             " WHERE (Contacts.FirstName = '" + txtFirstName.Text + "') AND (Contacts.LastName ='" + txtLastName.Text + "') AND (COMPANY.co_name = '" + cmbCmpType.Text.Trim() + "')";
            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlCon);
            sqlReader = sqlCom.ExecuteReader();
            if (sqlReader.HasRows)
            {
                MessageBox.Show("Entered Contact Person is already recorded. Please check the name and Company");
                txtLastName.Focus();
                isCheck = false;
            }
            sqlReader.Close();
            sqlCon.Close();
            return isCheck;
        }

        private bool CheckForDuplicateContactPerson_New()
        {
            string txtFullName = string.Empty;

            txtFullName = txtFirstName.Text.Trim() + " " + txtLastName.Text.Trim();

            SqlConnection sqlCon = new SqlConnection(strCon);
            sqlCon.Open();

            string sqlQuery = "SELECT Contacts.FirstName, Contacts.LastName, COMPANY.co_name FROM  Contacts INNER JOIN " +
            "  COMPANY ON Contacts.co_id = COMPANY.co_id" +
             " WHERE (COMPANY.co_id = " + cmbCmpType.SelectedValue + ")";

            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlCon);
            sqlReader = sqlCom.ExecuteReader();
            if (sqlReader.HasRows)
            {
                string userFullName = string.Empty;
                while (sqlReader.Read())
                {
                    userFullName = sqlReader[0].ToString() + " " + sqlReader[1].ToString();
                    if (userFullName.Equals(txtFullName.Trim()))
                    {
                        MessageBox.Show("Entered Contact Person is already recorded. Please check the name and Company");
                        txtFirstName.Focus();                        
                        return false;
                    }
                }                
            }
            sqlReader.Close();
            sqlCon.Close();
            return true;
        }
        private Boolean chk_ContactExist_New(bool isUpdate)
        {
            string txtFullName = string.Empty;

            txtFullName = txtFirstName.Text.Trim() + " " + txtLastName.Text.Trim();

            SqlConnection sqlConn = new SqlConnection(strCon);
            sqlConn.Open();

            string sqlQuery = "SELECT  COUNT(Contacts.employee_id) AS empCnt,Contacts.FirstName, Contacts.LastName, COMPANY.co_name,Contacts.employee_id FROM  Contacts INNER JOIN " +
           "  COMPANY ON Contacts.co_id = COMPANY.co_id" +
            " WHERE (COMPANY.co_id = " + cmbCmpType.SelectedValue + ") " +
            " GROUP BY Contacts.employee_id, Contacts.FirstName, Contacts.LastName, COMPANY.co_name";

            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
   
            int empID = 0; int iCnt = 0;

            sqlReader = sqlCom.ExecuteReader();
            if (sqlReader.HasRows == true)
            {
                string userFullName = string.Empty;
                while (sqlReader.Read())
                {
                    userFullName = sqlReader[1].ToString() + " " + sqlReader[2].ToString();
                    empID = Convert.ToInt16(sqlReader[4]);
                    if (userFullName.Equals(txtFullName.Trim()))
                    {
                        iCnt = iCnt + 1;
                        if (isUpdate)
                        {
                            if (_empID != 0 && empID != _empID)
                            {
                                MessageBox.Show("Entered Contact Person is already recorded. Please check the name and Company.");
                                txtFirstName.Focus();
                                return false;
                            }
                        }
                    }
                    
                }
                sqlReader.Close();

                if (isUpdate==false)
                {
                    if (iCnt == 1 && _empID == 0)
                    {
                        MessageBox.Show("Entered Contact Person is already recorded. Please check the name and Company.");
                        txtFirstName.Focus();
                        return false;
                    }
                }
            }
            return true;
        }
        private void UpdateContactPersonInfo(int _employeeID)
        {            
            int chkVal = 0;
            if (chkAuthor.Checked == true)
                chkVal = 1;

            try
            {               
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        cmd.CommandText = @"UPDATE CONTACTS SET co_id = @cmpId, FirstName = @empFirstName,LastName = @empLastName,Company = @cmpName, " +
                        " AuthorizedRep = @authRep,ShortName = @shortName,JobTitle = @Position,MobilePhone = @empMobile, BusinessPhone = @businessNo,FaxNumber = @empFax,EmailAddress = @email_address,update_date = @updateDate, "+
                        "department_id=@department_id,update_user =  @updateUser Where employee_id = @empId";

                        cmd.Parameters.AddWithValue("@empId", _employeeID);
                        cmd.Parameters.AddWithValue("@cmpId", cmbCmpType.SelectedValue);
                        cmd.Parameters.AddWithValue("@empFirstName", txtFirstName.Text);
                        cmd.Parameters.AddWithValue("@empLastName", txtLastName.Text);
                        cmd.Parameters.AddWithValue("@cmpName", cmbCmpType.Text);
                        cmd.Parameters.AddWithValue("@authRep", chkVal);

                        if (txtIntial.Text == "")
                            cmd.Parameters.AddWithValue("@shortName", System.DBNull.Value);       
                        else
                            cmd.Parameters.AddWithValue("@shortName", txtIntial.Text);

                        cmd.Parameters.AddWithValue("@Position", txtPosition.Text);
                        cmd.Parameters.AddWithValue("@businessNo", txtTelephone.Text);
                        cmd.Parameters.AddWithValue("@empFax", txtFaxNo.Text);
                        cmd.Parameters.AddWithValue("@empMobile", txtMobile.Text);
                        cmd.Parameters.AddWithValue("@email_address", txtEmail.Text);

                        cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@updateUser", _userName);
                        if(cmbUserDept.SelectedValue==null)
                        {
                            cmd.Parameters.AddWithValue("@department_id", DBNull.Value);
                        }
                        else
                        {
                            if (cmbUserDept.SelectedValue.ToString() != "21") //21==Not Applicable                                                   
                            {
                                cmd.Parameters.AddWithValue("@department_id", cmbUserDept.SelectedValue);
                            }
                            else
                            {
                                cmd.Parameters.AddWithValue("@department_id", DBNull.Value);
                            }
                        }
                        
                            
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        MessageBox.Show("Employee Details Updated Succesfully");
                        this.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void FillEmployeeUpdateWindow(int _employeeID)
        {
            sqlConn = new SqlConnection(strCon);
            cmnCls.PopulateComboBox(cmbCmpType, "Select Co_Id,Co_Name from COMPANY order by COMPANY.co_name", "Co_Id", "Co_Name");

            sqlConn.Open();

            string sqlQuery = "SELECT Contacts.employee_id, Contacts.FirstName, Contacts.LastName, Contacts.Company, Contacts.JobTitle, Contacts.MobilePhone,Contacts.FaxNumber, " +
            " Contacts.EmailAddress, Contacts.ShortName, Contacts.AuthorizedRep, COMPANY.co_name,Contacts.BusinessPhone,Department.department_id FROM Contacts INNER JOIN COMPANY ON Contacts.co_id = COMPANY.co_id " +
            " left outer JOIN Department ON Department.department_id = Contacts.department_id where (Contacts.employee_id = " + _employeeID + ")  order by COMPANY.co_name";

            sqlCom = new SqlCommand(sqlQuery, sqlConn);
            sqlReader = sqlCom.ExecuteReader();

            while (sqlReader.Read())
            {
                txtFirstName.Text = sqlReader[1].ToString();
                txtLastName.Text = sqlReader[2].ToString();
                txtIntial.Text = sqlReader[8].ToString();
                txtPosition.Text = sqlReader[4].ToString();
                txtEmail.Text = sqlReader[7].ToString();
                txtFaxNo.Text = sqlReader[6].ToString();
                txtMobile .Text = sqlReader[5].ToString();
                cmbCmpType.Text = sqlReader[10].ToString();
                txtTelephone.Text = sqlReader[11].ToString();  
 
                if (sqlReader[9].ToString() == "True")
                    chkAuthor.Checked = true;
                else
                    chkAuthor.Checked = false;

                if (sqlReader[12].ToString() != "")
                {
                    cmbUserDept.SelectedValue = sqlReader[12].ToString();
                }
                else
                    cmbUserDept.SelectedValue = "21";
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtFirstName.Text = string.Empty;
            txtIntial.Text = string.Empty;
            txtPosition.Text = string.Empty;

            txtTelephone.Text = string.Empty;
            txtFaxNo.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtMobile.Text = string.Empty;

            chkAuthor.Checked = false;
            cmbCmpType.SelectedIndex = -1;
            this.Close();
        }
        // Commented by Varun
        //private void txtEmail_Leave(object sender, EventArgs e)
        //{           
            //if (txtEmail.Text != "")
            //{
            //    if (EmailIsValid(txtEmail.Text) == false)
            //    {
            //        MessageBox.Show("Please enter proper email address");
            //        txtEmail.Focus();
            //        return;
            //    }
            //}
        //}       
        Regex ValidEmailRegex = CreateValidEmailRegex();
        private static Regex CreateValidEmailRegex()
        {
            string validEmailPattern = @"^(?!\.)(""([^""\r\\]|\\[""\r\\])*""|"
                + @"([-a-z0-9!#$%&'*+/=?^_`{|}~]|(?<!\.)\.)*)(?<!\.)"
                + @"@[a-z0-9][\w\.-]*[a-z0-9]\.[a-z][a-z\.]*[a-z]$";

            return new Regex(validEmailPattern, RegexOptions.IgnoreCase);
        }
        private bool EmailIsValid(string emailAddress)
        {
            bool isValid = ValidEmailRegex.IsMatch(emailAddress);
            return isValid;
        }
        public static bool IsItNumber(string inputvalue)
        {
            Regex isnumber = new Regex("[^0-9][^-]");
            return !isnumber.IsMatch(inputvalue);
        }
        private void txtTelephone_Leave(object sender, EventArgs e)
        {
            if(txtTelephone.Text != "")
            {
                if (PhoneIsValid(txtTelephone.Text) == false)
                {
                    MessageBox.Show("Please enter proper phone no");
                    txtTelephone.Focus();
                    return;
                } 
            }
        }
        Regex ValidPhoneRegex = CreateValidPhoneRegex();
        private static Regex CreateValidPhoneRegex()
        {
            string validPhonePattern = @"^(?!([^-]*-){5})(\+\d+)?\s*(\(\d+\))?[- \d]+$|^$ ^.*$";
            return new Regex(validPhonePattern, RegexOptions.IgnoreCase);
        }
        private bool PhoneIsValid(string PhoneNo)
        {
            bool isValid = ValidPhoneRegex.IsMatch(PhoneNo);
            return isValid;
        }

        private void txtMobile_Leave(object sender, EventArgs e)
        {

        }

        private void txtFaxNo_Leave(object sender, EventArgs e)
        {

        }
        private bool nonNumberEntered = false;
        private bool textContainsUnallowedCharacter(string T, char[] UnallowedCharacters)
        {
            for (int i = 0; i < UnallowedCharacters.Length; i++)
            {
                if (T.Contains(UnallowedCharacters[i]))
                {
                }
                else
                {
                    return true;
                }
            }
            return false;
        }
        

        private void cmbCmpType_SelectionChangeCommitted(object sender, EventArgs e)
        {
            //CheckForDuplicateContactPerson();
        }
        
    }
}
