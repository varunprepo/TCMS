﻿namespace MDI_ParenrForm.Admin
{
    partial class frmSecurityProfile1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btndelete = new System.Windows.Forms.Button();
            this.btnupdateSecurityprevilege = new System.Windows.Forms.Button();
            this.btnSecProfileAdd = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnAccessRightsSave = new System.Windows.Forms.Button();
            this.listView2 = new System.Windows.Forms.ListView();
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SNO = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.button3 = new System.Windows.Forms.Button();
            this.dgSecurityProfile = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgSecurityProfile)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dgSecurityProfile);
            this.groupBox1.Controls.Add(this.btndelete);
            this.groupBox1.Controls.Add(this.btnupdateSecurityprevilege);
            this.groupBox1.Controls.Add(this.btnSecProfileAdd);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(4, 29);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(310, 463);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Security Profile";
            // 
            // btndelete
            // 
            this.btndelete.BackColor = System.Drawing.Color.Maroon;
            this.btndelete.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btndelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndelete.ForeColor = System.Drawing.Color.White;
            this.btndelete.Location = new System.Drawing.Point(131, 431);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(60, 26);
            this.btndelete.TabIndex = 3;
            this.btndelete.Text = "Delete";
            this.btndelete.UseVisualStyleBackColor = false;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // btnupdateSecurityprevilege
            // 
            this.btnupdateSecurityprevilege.BackColor = System.Drawing.Color.Maroon;
            this.btnupdateSecurityprevilege.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnupdateSecurityprevilege.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdateSecurityprevilege.ForeColor = System.Drawing.Color.White;
            this.btnupdateSecurityprevilege.Location = new System.Drawing.Point(70, 431);
            this.btnupdateSecurityprevilege.Name = "btnupdateSecurityprevilege";
            this.btnupdateSecurityprevilege.Size = new System.Drawing.Size(60, 26);
            this.btnupdateSecurityprevilege.TabIndex = 2;
            this.btnupdateSecurityprevilege.Text = "Update";
            this.btnupdateSecurityprevilege.UseVisualStyleBackColor = false;
            this.btnupdateSecurityprevilege.Click += new System.EventHandler(this.btnupdateSecurityprevilege_Click);
            // 
            // btnSecProfileAdd
            // 
            this.btnSecProfileAdd.BackColor = System.Drawing.Color.Maroon;
            this.btnSecProfileAdd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSecProfileAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSecProfileAdd.ForeColor = System.Drawing.Color.White;
            this.btnSecProfileAdd.Location = new System.Drawing.Point(9, 431);
            this.btnSecProfileAdd.Name = "btnSecProfileAdd";
            this.btnSecProfileAdd.Size = new System.Drawing.Size(60, 26);
            this.btnSecProfileAdd.TabIndex = 1;
            this.btnSecProfileAdd.Text = "Add";
            this.btnSecProfileAdd.UseVisualStyleBackColor = false;
            this.btnSecProfileAdd.Click += new System.EventHandler(this.btnSecProfileAdd_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(236)))), ((int)(((byte)(236)))));
            this.groupBox2.Controls.Add(this.btnAccessRightsSave);
            this.groupBox2.Controls.Add(this.listView2);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(328, 29);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(680, 463);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Access Rights ";
            // 
            // btnAccessRightsSave
            // 
            this.btnAccessRightsSave.BackColor = System.Drawing.Color.Maroon;
            this.btnAccessRightsSave.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAccessRightsSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAccessRightsSave.ForeColor = System.Drawing.Color.White;
            this.btnAccessRightsSave.Location = new System.Drawing.Point(6, 431);
            this.btnAccessRightsSave.Name = "btnAccessRightsSave";
            this.btnAccessRightsSave.Size = new System.Drawing.Size(60, 26);
            this.btnAccessRightsSave.TabIndex = 3;
            this.btnAccessRightsSave.Text = "Save";
            this.btnAccessRightsSave.UseVisualStyleBackColor = false;
            this.btnAccessRightsSave.Click += new System.EventHandler(this.btnAccessRightsSave_Click);
            // 
            // listView2
            // 
            this.listView2.BackColor = System.Drawing.SystemColors.Window;
            this.listView2.CheckBoxes = true;
            this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader3,
            this.columnHeader4,
            this.SNO});
            this.listView2.Location = new System.Drawing.Point(6, 25);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(668, 390);
            this.listView2.TabIndex = 0;
            this.listView2.UseCompatibleStateImageBehavior = false;
            // 
            // columnHeader3
            // 
            this.columnHeader3.DisplayIndex = 1;
            this.columnHeader3.Text = "Has Privilege";
            this.columnHeader3.Width = 110;
            // 
            // columnHeader4
            // 
            this.columnHeader4.DisplayIndex = 2;
            this.columnHeader4.Text = "AccessRights";
            this.columnHeader4.Width = 800;
            // 
            // SNO
            // 
            this.SNO.DisplayIndex = 0;
            this.SNO.Text = "Sr. No";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button3.ForeColor = System.Drawing.Color.Red;
            this.button3.Image = global::MDI_ParenrForm.Properties.Resources.Actions_window_close_icon;
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(943, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(65, 31);
            this.button3.TabIndex = 31;
            this.button3.Text = "Close";
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // dgSecurityProfile
            // 
            this.dgSecurityProfile.AllowUserToAddRows = false;
            this.dgSecurityProfile.AllowUserToDeleteRows = false;
            this.dgSecurityProfile.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgSecurityProfile.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgSecurityProfile.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgSecurityProfile.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgSecurityProfile.Location = new System.Drawing.Point(8, 25);
            this.dgSecurityProfile.MultiSelect = false;
            this.dgSecurityProfile.Name = "dgSecurityProfile";
            this.dgSecurityProfile.ReadOnly = true;
            this.dgSecurityProfile.RowHeadersVisible = false;
            this.dgSecurityProfile.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgSecurityProfile.Size = new System.Drawing.Size(296, 390);
            this.dgSecurityProfile.TabIndex = 4;
            this.dgSecurityProfile.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgSecurityProfile_CellClick);
            // 
            // frmSecurityProfile1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(236)))), ((int)(((byte)(236)))));
            this.ClientSize = new System.Drawing.Size(1020, 504);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmSecurityProfile1";
            this.Text = "User Security Access Rights and Previlege Setting window";
            this.Load += new System.EventHandler(this.frmSecurityProfile1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgSecurityProfile)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button btnupdateSecurityprevilege;
        private System.Windows.Forms.Button btnSecProfileAdd;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnAccessRightsSave;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ColumnHeader SNO;
        private System.Windows.Forms.DataGridView dgSecurityProfile;

    }
}