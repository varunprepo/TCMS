﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace MDI_ParenrForm.Admin
{
    public partial class frmDialog : Form
    {

        protected SqlConnection sqlConn;
        protected SqlCommand sqlCom;

        protected SqlDataReader sqlReader;

        SqlCommand sqlCmd = null;
        SqlCommand sqlCmdinsert = null;
        SqlDataReader sqlDtRead = null;
        string profileidinform1="1";
        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();
        public frmDialog()
        {
            InitializeComponent();
        }
        public frmDialog(string strTextBox, string paramUpdate, string selectedprofileid)
        {
          InitializeComponent(); 
          txtdialogwindow.Text=strTextBox;
          btnsubmitdialog.Text = paramUpdate;
          profileidinform1=selectedprofileid;
        }
        private void InsertAccessRights(string profileid)
        {
            sqlConn = new SqlConnection(strCon);
            sqlConn.Open();
            string datevalue = string.Empty;
            datevalue = String.Format("{0:yyyy/MM/dd}", DateTime.Now);

            string sqlQuerycount = "SELECT count(AccessID) FROM UserPrivelege where user_profile_id=1";
            Int32 Accessidscount = 0;
            sqlCmd = new SqlCommand(sqlQuerycount, sqlConn);
            Accessidscount = (Int32)sqlCmd.ExecuteScalar();

            for (int idx = 1; idx <= Accessidscount; idx++) // loop AccessRights Listview
            {
                string sqlQueryinsert = "insert into UserPrivelege (user_profile_id,AccessID,HasPrivelege,create_date) values(" + profileid + "," + idx + "," + 0 + ",'" + datevalue + "')";

                sqlCom = new SqlCommand(sqlQueryinsert, sqlConn);
                sqlCom.ExecuteNonQuery();
            }
        }
        private void btnsubmitdialog_Click(object sender, EventArgs e)
        {
            if (btnsubmitdialog.Text.Equals("Submit")) // if Add 
            {
                string datevalue = string.Empty;
                datevalue = String.Format("{0:yyyy/MM/dd}", DateTime.Now);
                if (txtdialogwindow.Text != "")
                {
                    string NewSecurityprofilename = (txtdialogwindow.Text).Trim().ToUpper();
                    sqlConn = new SqlConnection(strCon);
                    sqlConn.Open();

                    string sqlQuery = "SELECT user_profile_id,upper(profile_name) " +
                    " FROM UserSecurityProfile where profile_name = '" + NewSecurityprofilename + "'";   //check record exists

                    sqlCom = new SqlCommand(sqlQuery, sqlConn);
                    sqlReader = sqlCom.ExecuteReader();
                     
                    if (sqlReader.HasRows)      //if rec exists
                    {
                        MessageBox.Show("Record Already Exists", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        sqlReader.Close();
                    }
                    else                  //if not then insert
                    {
                        sqlReader.Close();
                        string sqlQuerymax = "SELECT max(user_profile_id) FROM UserSecurityProfile";
                        Int32 maxid = 0;
                        sqlCmd = new SqlCommand(sqlQuerymax, sqlConn);
                        maxid = (Int32)sqlCmd.ExecuteScalar();          //get max id
                        maxid = maxid + 1;
                        string sqlQueryinsert = "insert into UserSecurityProfile (user_profile_id,profile_name,[Default],[create_date]) values(" + maxid + ",'" + NewSecurityprofilename + "'," + 0 + ",'" + datevalue + "')";

                        sqlCom = new SqlCommand(sqlQueryinsert, sqlConn);
                        int result1 = sqlCom.ExecuteNonQuery();

                        MessageBox.Show("Data Inserted Sucessfully", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        InsertAccessRights(maxid.ToString()); //insert Accessid and AccessRightsID to userPrivilege table with False option

                        this.Close();

                    }
                }
            }
            else if (btnsubmitdialog.Text.Equals("Update"))        // if Update
            {
                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                string sqlQueryupdate = "update UserSecurityProfile set profile_name='" + txtdialogwindow.Text + "'" + " where user_profile_id =" + profileidinform1;

                sqlCom = new SqlCommand(sqlQueryupdate, sqlConn);
                int result1 = sqlCom.ExecuteNonQuery();

                MessageBox.Show("Data Updated Sucessfully", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();

            }                
        }
        private void frmDialog_Load(object sender, EventArgs e)
        {

        }            
    }
}
