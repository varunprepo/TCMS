﻿namespace MDI_ParenrForm.Admin
{
    partial class frmDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtdialogwindow = new System.Windows.Forms.TextBox();
            this.btnsubmitdialog = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtdialogwindow
            // 
            this.txtdialogwindow.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdialogwindow.Location = new System.Drawing.Point(54, 76);
            this.txtdialogwindow.Multiline = true;
            this.txtdialogwindow.Name = "txtdialogwindow";
            this.txtdialogwindow.Size = new System.Drawing.Size(335, 53);
            this.txtdialogwindow.TabIndex = 0;
            // 
            // btnsubmitdialog
            // 
            this.btnsubmitdialog.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsubmitdialog.Location = new System.Drawing.Point(128, 162);
            this.btnsubmitdialog.Name = "btnsubmitdialog";
            this.btnsubmitdialog.Size = new System.Drawing.Size(170, 38);
            this.btnsubmitdialog.TabIndex = 1;
            this.btnsubmitdialog.Text = "Submit";
            this.btnsubmitdialog.UseVisualStyleBackColor = true;
            this.btnsubmitdialog.Click += new System.EventHandler(this.btnsubmitdialog_Click);
            // 
            // frmDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(416, 290);
            this.Controls.Add(this.btnsubmitdialog);
            this.Controls.Add(this.txtdialogwindow);
            this.Name = "frmDialog";
            this.Text = "Add Edit Window";
            this.Load += new System.EventHandler(this.frmDialog_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtdialogwindow;
        private System.Windows.Forms.Button btnsubmitdialog;
    }
}