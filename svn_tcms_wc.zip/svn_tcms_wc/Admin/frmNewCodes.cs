﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using TenderTrackingSystem;

namespace MDI_ParenrForm.Admin
{

    public partial class frmNewCodes : Form
    {
        protected SqlConnection sqlConn;
        protected SqlCommand sqlCom;
        protected SqlDataReader sqlReader;
        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();


        public frmNewCodes()
        {
            InitializeComponent();
        }
        private void frmNewCodes_Load(object sender, EventArgs e)
        {
            getTenderTypes();
        }
        private void getTenderTypes()
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        string sqlQuery = "SELECT Ministry_id,[MinistryCode] as [MinistryCode],[MinistryName] as [Ministry Name] FROM [MinistryCodes] order by [MinistryCode]";  //tender_type_name
                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        DataSet ds = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        da.Fill(ds);
                        dgvMinistryCodes.DataSource = ds.Tables[0];
                    }
                }
                dgvMinistryCodes.Columns[0].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Reading TenderType records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (lblMinistryCode.Text != "")
            {
                try
                {
                    using (SqlConnection sqlConn = new SqlConnection(strCon))
                    {
                        using (SqlCommand cmd = new SqlCommand())
                        {
                            sqlConn.Open();
                            cmd.CommandText = @"Update [MinistryCodes] Set [MinistryCode] = @minstryCode,[MinistryName] = @ministryName Where ministry_ID = @MinID";
                            cmd.Connection = sqlConn;
                            cmd.Parameters.AddWithValue("@minstryCode", txtMinCode.Text);
                            cmd.Parameters.AddWithValue("@ministryName", txtMinName.Text);
                            cmd.Parameters.AddWithValue("@MinID", lblMinistryCode.Text);
                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while Insert Tender Types records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                try
                {
                    using (SqlConnection sqlConn = new SqlConnection(strCon))
                    {
                        using (SqlCommand cmd = new SqlCommand())
                        {
                            sqlConn.Open();
                            cmd.CommandText = @"INSERT INTO [MinistryCodes]([MinistryCode],[MinistryName]) VALUES(@minstryCode,@ministryName)";
                            cmd.Connection = sqlConn;
                            cmd.Parameters.AddWithValue("@minstryCode", txtMinName.Text);
                            cmd.Parameters.AddWithValue("@ministryName", txtMinName.Text);        
                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while Ministry records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            getTenderTypes();
        }

        private void dgvMinistryCodes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = e.RowIndex;
            int clmnIndex = e.ColumnIndex;

            lblMinistryCode.Text = dgvMinistryCodes[0, rowIndex].Value.ToString();
            txtMinCode.Text = dgvMinistryCodes[1, rowIndex].Value.ToString();
            txtMinName.Text = dgvMinistryCodes[2, rowIndex].Value.ToString();
        }
        private void getBudgetReferenceTypes()
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        string sqlQuery = "SELECT BudgetRef_id,[BudgetRefNumber] as [BudgetRefCode],[BudgetRefTitle] as [BudgetRefName] FROM [BudgetReferenceCodes] order by [BudgetRefNumber]";  //tender_type_name
                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        DataSet ds = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        da.Fill(ds);
                        dgvBudget.DataSource = ds.Tables[0];
                    }
                }
                dgvBudget.Columns[0].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Reading Budget Reference Codes records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void tabControl1_MouseClick(object sender, MouseEventArgs e)
        {
            getBudgetReferenceTypes();
        }
        private void btnBudget_Click(object sender, EventArgs e)
        {
            if (lblbudget.Text != "")
            {
                try
                {
                    using (SqlConnection sqlConn = new SqlConnection(strCon))
                    {
                        using (SqlCommand cmd = new SqlCommand())
                        {
                            sqlConn.Open();
                            cmd.CommandText = @"Update [BudgetReferenceCodes] Set [BudgetRefNumber] = @budgetRefCode,[BudgetRefTitle] = @budgetRefName Where BudgetRef_id = @BudID";
                            cmd.Connection = sqlConn;
                            cmd.Parameters.AddWithValue("@budgetRefCode", txtBudgetCode.Text);
                            cmd.Parameters.AddWithValue("@budgetRefName", txtBudgetName.Text);
                            cmd.Parameters.AddWithValue("@BudID", lblbudget.Text);
                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while Insert Tender Types records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                try
                {
                    using (SqlConnection sqlConn = new SqlConnection(strCon))
                    {
                        using (SqlCommand cmd = new SqlCommand())
                        {
                            sqlConn.Open();
                            cmd.CommandText = @"INSERT INTO [BudgetReferenceCodes]([BudgetRefNumber],[BudgetRefTitle]) VALUES(@budgetRefCode,@budgetRefName)";
                            cmd.Connection = sqlConn;
                            cmd.Parameters.AddWithValue("@budgetRefCode", txtBudgetCode.Text);
                            cmd.Parameters.AddWithValue("@budgetRefName", txtBudgetName.Text);
                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while Ministry records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            getBudgetReferenceTypes();
        }
        private void dgvBudget_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = e.RowIndex;
            int clmnIndex = e.ColumnIndex;

            lblbudget.Text = dgvBudget[0, rowIndex].Value.ToString();
            txtBudgetCode.Text = dgvBudget[1, rowIndex].Value.ToString();
            txtBudgetName.Text = dgvBudget[2, rowIndex].Value.ToString();
        }
        private void btnClr_Click(object sender, EventArgs e)
        {
            lblMinistryCode.Text = "";
            txtMinCode.Text = "";
            txtMinName.Text = "";
        }
        private void button1_Click(object sender, EventArgs e)
        {
            lblbudget.Text = "";
            txtBudgetCode.Text = "";
            txtBudgetName.Text = "";
        }
    }
}
