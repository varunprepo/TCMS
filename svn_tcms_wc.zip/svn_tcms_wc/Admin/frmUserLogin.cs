﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using MDI_ParenrForm;
using System.IO;

namespace MDI_ParenrForm.Admin
{
    partial class frmUserLogin : Form
    {
        string connStr = null;
        string strExcep = null;
        SqlConnection sqlConn = null;
        SqlCommand sqlCmd = null;
        SqlDataReader sqlDtRead = null;

        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();

        public frmUserLogin()
        {
            InitializeComponent();
           // this.Text = String.Format("About {0} {0}", AssemblyTitle);
           // this.labelProductName.Text = AssemblyProduct;
            //this.labelVersion.Text = String.Format("Version {0} {0}", AssemblyVersion);
            //this.labelCopyright.Text = AssemblyCopyright;
            //this.labelCompanyName.Text = AssemblyCompany;
            //this.textBoxDescription.Text = AssemblyDescription;
        }
        #region Assembly Attribute Accessors

        public string AssemblyTitle
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyTitleAttribute), false);
                if (attributes.Length > 0)
                {
                    AssemblyTitleAttribute titleAttribute = (AssemblyTitleAttribute)attributes[0];
                    if (titleAttribute.Title != "")
                    {
                        return titleAttribute.Title;
                    }
                }
                return System.IO.Path.GetFileNameWithoutExtension(Assembly.GetExecutingAssembly().CodeBase);
            }
        }

        public string AssemblyVersion
        {
            get
            {
                return Assembly.GetExecutingAssembly().GetName().Version.ToString();
            }
        }

        public string AssemblyDescription
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyDescriptionAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyDescriptionAttribute)attributes[0]).Description;
            }
        }

        public string AssemblyProduct
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyProductAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyProductAttribute)attributes[0]).Product;
            }
        }

        public string AssemblyCopyright
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyCopyrightAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyCopyrightAttribute)attributes[0]).Copyright;
            }
        }

        public string AssemblyCompany
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyCompanyAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyCompanyAttribute)attributes[0]).Company;
            }
        }
        #endregion
        
        private void UserLogin()
        {
            if (txtUserName.Text == "")
            {
                MessageBox.Show("Please enter User Name");
                txtUserName.Focus();
                return;
            }
            else if (txtPwd.Text == "")
            {
                MessageBox.Show("Please enter Password");
                txtPwd.Focus();
                return;
            }
            else
            {
                try
                {
                    sqlConn = new SqlConnection(strCon);
                    sqlConn.Open();

                    string sqlQuery = "SELECT user_name, password,isheadOfSection  FROM USERS WHERE user_name = '" + txtUserName.Text + "' and password ='" + txtPwd.Text + "'"; // Modified by Varun on 11/Jun/15
                    sqlCmd = new SqlCommand(sqlQuery, sqlConn);
                    sqlDtRead = sqlCmd.ExecuteReader();
                    if (sqlDtRead.HasRows)
                    {
                        sqlDtRead.Read();
                        bool isheadOfSection = false;
                        if(sqlDtRead["isheadOfSection"].ToString()=="True")
                            isheadOfSection = true;
                        sqlDtRead.Close();
                        dashBoardParent mainForm = new dashBoardParent(txtUserName.Text, isheadOfSection);
                        mainForm.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("User Name or Password was incorrect");
                    }
                }
                catch (Exception ex)
                {
                    strExcep = ex.ToString();

                    MessageBox.Show(ex.Message);
                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            UserLogin();

            Users_LogIn_System(txtUserName.Text);
        }
        private void linkChangePwd_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }
        private void button1_Leave(object sender, EventArgs e)
        {
          
        }
        private void button1_Enter(object sender, EventArgs e)
        {
            UserLogin();            
        }
        private void frmUserLogin_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Application.Exit();
        }
        private void frmUserLogin_FormClosed(object sender, FormClosedEventArgs e)
        {
            //frmSwitchUser frmSwitch = new frmSwitchUser();
            //frmSwitch.StartPosition = FormStartPosition.CenterScreen;
            //frmSwitch.ShowDialog();
            Application.Exit();
        }
        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();

            frmSwitchUser frmSwitch = new frmSwitchUser();
            frmSwitch.StartPosition = FormStartPosition.CenterScreen;
            frmSwitch.ShowDialog();            
        }
        private void txtPwd_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Return)
            {
                UserLogin();
            }          

        }

        private void Users_LogIn_System(string _userName)
        {
            try
            {
                SqlConnection sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                string strUpdate = "Update Users SET LogOn = 1 Where user_name = '" + _userName + "'";
                SqlCommand sqlCmd = new SqlCommand(strUpdate, sqlConn);
                sqlCmd.ExecuteNonQuery();
                sqlConn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Users_LogOut_System(string _userName)
        {
            try
            {
                SqlConnection sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                string strUpdate = "Update Users SET LogOn = 0 Where user_name = '" + _userName + "'";
                SqlCommand sqlCmd = new SqlCommand(strUpdate, sqlConn);
                sqlCmd.ExecuteNonQuery();
                sqlConn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
