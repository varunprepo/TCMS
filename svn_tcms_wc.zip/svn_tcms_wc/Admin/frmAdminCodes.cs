﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using TenderTrackingSystem;

namespace MDI_ParenrForm.Admin
{
    public partial class frmAdminCodes : Form
    {
        protected SqlConnection sqlConn;
        protected SqlCommand sqlCom;
        protected SqlDataReader sqlReader;
        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();

        public frmAdminCodes()
        {
            InitializeComponent();
        }
        private void frmAdminCodes_Load(object sender, EventArgs e)
        {
            getTenderTypes();
            getTenderStatus();
        }
        private void getTenderTypes()
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        string sqlQuery = "SELECT tender_type_id,tender_type_name as [TenderType Names],tender_type_short_name as [Short Name] FROM [TenderTypes] order by tender_type_id";  //tender_type_name
                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        DataSet ds = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        da.Fill(ds);
                        dgvTenderTypes.DataSource = ds.Tables[0];
                    }
                }
                dgvTenderTypes.Columns[0].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Reading TenderType records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void getTenderStatus()
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        string sqlQuery = "SELECT Tender_Status_id,Status_Name as [TenderStatus Names],TenderStatusShortName as [Short Name] FROM [TenderStatus] order by Tender_Status_id";  //tender_type_name
                        cmd.Connection = sqlConn;
                        cmd.CommandText = sqlQuery;
                        DataSet ds = new DataSet();
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        da.Fill(ds);
                        dgvTenderStatus.DataSource = ds.Tables[0];
                    }
                }
                dgvTenderTypes.Columns[0].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Reading Tender Status records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtTndrTypeName.Text == "")
            {
                MessageBox.Show("Please enter Tender Type Names");
                return;
            }            
            if (lblTndrTypeID.Text != "")
            {
                try
                {
                    using (SqlConnection sqlConn = new SqlConnection(strCon))
                    {
                        using (SqlCommand cmd = new SqlCommand())
                        {
                            sqlConn.Open();
                            cmd.CommandText = @"Update [TenderTypes] Set tender_type_name = @tenderType,tender_type_short_name = @Shortname Where tender_type_id = @tndrTypeID";
                            cmd.Connection = sqlConn;
                            cmd.Parameters.AddWithValue("@tenderType", txtTndrTypeName.Text);
                            cmd.Parameters.AddWithValue("@Shortname", TenderShortName.Text);
                            cmd.Parameters.AddWithValue("@tndrTypeID", lblTndrTypeID.Text);
                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while Insert Tender Types records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                try
                {
                    using (SqlConnection sqlConn = new SqlConnection(strCon))
                    {
                        using (SqlCommand cmd = new SqlCommand())
                        {
                            sqlConn.Open();
                            cmd.CommandText = @"INSERT INTO [TenderTypes](tender_type_name,tender_type_short_name) VALUES(@tenderType,@Shortname)";
                            cmd.Connection = sqlConn;
                            cmd.Parameters.AddWithValue("@tenderType", txtTndrTypeName.Text);
                            cmd.Parameters.AddWithValue("@Shortname", TenderShortName.Text);
                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while Insert Tender Types records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            getTenderTypes();
        }
        private void dgvTenderTypes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //int rowIndex = e.RowIndex;
            //int clmnIndex = e.ColumnIndex;
            //txtTndrTypeName.Text = dgvTenderTypes[0, rowIndex].Value.ToString();
            //TenderShortName.Text = dgvTenderTypes[1, rowIndex].Value.ToString();
        }
        private void dgvTenderTypes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = e.RowIndex;
            int clmnIndex = e.ColumnIndex;

            lblTndrTypeID.Text = dgvTenderTypes[0, rowIndex].Value.ToString();
            txtTndrTypeName.Text = dgvTenderTypes[1, rowIndex].Value.ToString();
            TenderShortName.Text = dgvTenderTypes[2, rowIndex].Value.ToString();
        }
        private void btnTndrStatClear_Click(object sender, EventArgs e)
        {
            lblTnderStatusName.Text = "";
            txtTndrStatusName.Text = "";
            txtTndrStatusShortName.Text = "";
        }
        private void btnTndrTypeClear_Click(object sender, EventArgs e)
        {
            lblTndrTypeID.Text = "";
            txtTndrTypeName.Text = "";
            TenderShortName.Text = "";
        }
        private void btnStatusName_Click(object sender, EventArgs e)
        {
            if (txtTndrStatusName.Text == "")
            {
                MessageBox.Show("Please enter Tender Type Names");
                return;
            }
            if (lblTndrStatusID.Text != "")
            {
                try
                {
                    using (SqlConnection sqlConn = new SqlConnection(strCon))
                    {
                        using (SqlCommand cmd = new SqlCommand())
                        {
                            sqlConn.Open();
                            cmd.CommandText = @"Update [TenderStatus] Set Status_Name = @statusName,TenderStatusShortName = @Shortname Where Tender_Status_id = @tndrStatusID";
                            cmd.Connection = sqlConn;
                            cmd.Parameters.AddWithValue("@statusName", txtTndrStatusName.Text);
                            cmd.Parameters.AddWithValue("@Shortname", txtTndrStatusShortName.Text);
                            cmd.Parameters.AddWithValue("@tndrStatusID", lblTndrStatusID.Text);
                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while Insert Tender Status records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                try
                {
                    using (SqlConnection sqlConn = new SqlConnection(strCon))
                    {
                        using (SqlCommand cmd = new SqlCommand())
                        {
                            sqlConn.Open();
                            cmd.CommandText = @"INSERT INTO [TenderStatus](Status_Name,TenderStatusShortName) VALUES(@statusName,@Shortname)";
                            cmd.Connection = sqlConn;
                            cmd.Parameters.AddWithValue("@statusName", txtTndrStatusName.Text);
                            cmd.Parameters.AddWithValue("@Shortname", txtTndrStatusShortName.Text);
                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while Insert Tender Types records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            getTenderStatus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult dlgResult = DialogResult.Yes;
            dlgResult = MessageBox.Show("Do you want to Update Document Stauts", "Invalid Entry", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (dlgResult.ToString().Equals("Yes"))
            {
                AutomaticUpdateDocumentStatus();
            }
        }
        private void AutomaticUpdateDocumentStatus()
        {
            //  if Document issue date + days to act less than current date : make document status as For Follow Up

            string sqlQuery = "SELECT doc_issue_date + days_to_act AS DocDate, doc_status_id, doc_id, CURRENT_TIMESTAMP AS Todaydate " +
            " FROM DOCUMENTS Where doc_status_id = 1 ORDER BY doc_status_id";

            DataSet dsDocStat = new DataSet();
            using (SqlConnection sqlConn = new SqlConnection(strCon))
            {
                sqlConn.Open();
                using (SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn))
                {
                    SqlDataAdapter daDocStatus = new SqlDataAdapter(sqlCom);
                    daDocStatus.Fill(dsDocStat);
                }
                sqlConn.Close();
            }

            for (int i = 0; i < dsDocStat.Tables[0].Rows.Count; i++)
            {
                DateTime docDate = Convert.ToDateTime(dsDocStat.Tables[0].Rows[i][0]);
                if (docDate < System.DateTime.Now)
                {
                    int docID = Convert.ToInt16(dsDocStat.Tables[0].Rows[i][2]);

                    string sqlQueryUpd = "UPDATE DOCUMENTS SET doc_status_id = 2 WHERE doc_id = " + docID + "";

                    using (SqlConnection sqlConn = new SqlConnection(strCon))
                    {
                        sqlConn.Open();
                        using (SqlCommand sqlCom = new SqlCommand(sqlQueryUpd, sqlConn))
                        {
                            sqlCom.ExecuteNonQuery();
                        }
                        sqlConn.Close();
                    }
                }
            }
        }
        private void dgvTenderStatus_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = e.RowIndex;
            int clmnIndex = e.ColumnIndex;

            lblTndrStatusID.Text = dgvTenderStatus[0, rowIndex].Value.ToString();
            txtTndrStatusName.Text = dgvTenderStatus[1, rowIndex].Value.ToString();
            txtTndrStatusShortName.Text = dgvTenderStatus[2, rowIndex].Value.ToString();
        }
        private void dgvTenderStatus_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            

        }
    }
}
