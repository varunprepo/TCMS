﻿namespace MDI_ParenrForm.Admin
{
    partial class frmEmailAlerts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbTenderCommittee = new System.Windows.Forms.ComboBox();
            this.lblSelectedCategory = new System.Windows.Forms.Label();
            this.panelSelectedAlertCategory = new System.Windows.Forms.Panel();
            this.panelAlertCategory = new System.Windows.Forms.Panel();
            this.lstboxAlertCategories = new System.Windows.Forms.ListBox();
            this.panelAlertCategoryHeading = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.lstUsers = new System.Windows.Forms.ListBox();
            this.btnDeleteUserDetail = new System.Windows.Forms.Button();
            this.btnAddUserDetail = new System.Windows.Forms.Button();
            this.dgvCommitteeEmployees = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panelSelectedAlertCategory.SuspendLayout();
            this.panelAlertCategory.SuspendLayout();
            this.panelAlertCategoryHeading.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCommitteeEmployees)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Alert Category";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(428, 105);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(157, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Assigned Committee Per Project";
            // 
            // cmbTenderCommittee
            // 
            this.cmbTenderCommittee.FormattingEnabled = true;
            this.cmbTenderCommittee.Location = new System.Drawing.Point(600, 102);
            this.cmbTenderCommittee.Name = "cmbTenderCommittee";
            this.cmbTenderCommittee.Size = new System.Drawing.Size(90, 21);
            this.cmbTenderCommittee.TabIndex = 4;             
            this.cmbTenderCommittee.SelectedIndexChanged += new System.EventHandler(this.cmbTenderCommittee_SelectedIndexChanged);
            // 
            // lblSelectedCategory
            // 
            this.lblSelectedCategory.AutoSize = true;
            this.lblSelectedCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectedCategory.Location = new System.Drawing.Point(3, 10);
            this.lblSelectedCategory.Name = "lblSelectedCategory";
            this.lblSelectedCategory.Size = new System.Drawing.Size(41, 13);
            this.lblSelectedCategory.TabIndex = 2;
            this.lblSelectedCategory.Text = "label1";
            // 
            // panelSelectedAlertCategory
            // 
            this.panelSelectedAlertCategory.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelSelectedAlertCategory.Controls.Add(this.lblSelectedCategory);
            this.panelSelectedAlertCategory.Location = new System.Drawing.Point(431, 49);
            this.panelSelectedAlertCategory.Name = "panelSelectedAlertCategory";
            this.panelSelectedAlertCategory.Size = new System.Drawing.Size(259, 34);
            this.panelSelectedAlertCategory.TabIndex = 5;
            // 
            // panelAlertCategory
            // 
            this.panelAlertCategory.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelAlertCategory.Controls.Add(this.lstboxAlertCategories);
            this.panelAlertCategory.Controls.Add(this.panelAlertCategoryHeading);
            this.panelAlertCategory.Controls.Add(this.cmbTenderCommittee);
            this.panelAlertCategory.Controls.Add(this.panelSelectedAlertCategory);
            this.panelAlertCategory.Controls.Add(this.label3);
            this.panelAlertCategory.Location = new System.Drawing.Point(30, 29);
            this.panelAlertCategory.Name = "panelAlertCategory";
            this.panelAlertCategory.Size = new System.Drawing.Size(827, 175);
            this.panelAlertCategory.TabIndex = 6;
            // 
            // lstboxAlertCategories
            // 
            this.lstboxAlertCategories.FormattingEnabled = true;
            this.lstboxAlertCategories.Location = new System.Drawing.Point(13, 49);
            this.lstboxAlertCategories.Name = "lstboxAlertCategories";
            this.lstboxAlertCategories.Size = new System.Drawing.Size(283, 82);
            this.lstboxAlertCategories.TabIndex = 6;
            this.lstboxAlertCategories.SelectedIndexChanged += new System.EventHandler(this.lstBoxAlertCategories_SelectedIndexChanged);
            // 
            // panelAlertCategoryHeading
            // 
            this.panelAlertCategoryHeading.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelAlertCategoryHeading.Controls.Add(this.label1);
            this.panelAlertCategoryHeading.Location = new System.Drawing.Point(13, 24);
            this.panelAlertCategoryHeading.Name = "panelAlertCategoryHeading";
            this.panelAlertCategoryHeading.Size = new System.Drawing.Size(283, 25);
            this.panelAlertCategoryHeading.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.lstUsers);
            this.panel1.Controls.Add(this.btnDeleteUserDetail);
            this.panel1.Controls.Add(this.btnAddUserDetail);
            this.panel1.Controls.Add(this.dgvCommitteeEmployees);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(32, 229);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(824, 314);
            this.panel1.TabIndex = 7;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.label4);
            this.panel3.Location = new System.Drawing.Point(508, 14);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(302, 35);
            this.panel3.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(4, 4);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(116, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "List of All Users";
            // 
            // lstUsers
            // 
            this.lstUsers.FormattingEnabled = true;
            this.lstUsers.Location = new System.Drawing.Point(508, 56);
            this.lstUsers.Name = "lstUsers";
            this.lstUsers.Size = new System.Drawing.Size(303, 238);
            this.lstUsers.TabIndex = 4;
            this.lstUsers.SelectedIndexChanged += new System.EventHandler(this.lstUsers_SelectedIndexChanged);
            // 
            // btnDeleteUserDetail
            // 
            this.btnDeleteUserDetail.Location = new System.Drawing.Point(398, 144);
            this.btnDeleteUserDetail.Name = "btnDeleteUserDetail";
            this.btnDeleteUserDetail.Size = new System.Drawing.Size(62, 40);
            this.btnDeleteUserDetail.TabIndex = 3;
            this.btnDeleteUserDetail.Text = "DELETE";
            this.btnDeleteUserDetail.UseVisualStyleBackColor = true;
            this.btnDeleteUserDetail.Click += new System.EventHandler(this.btnDeleteUserDetail_Click);
            // 
            // btnAddUserDetail
            // 
            this.btnAddUserDetail.Location = new System.Drawing.Point(398, 99);
            this.btnAddUserDetail.Name = "btnAddUserDetail";
            this.btnAddUserDetail.Size = new System.Drawing.Size(63, 39);
            this.btnAddUserDetail.TabIndex = 2;
            this.btnAddUserDetail.Text = "ADD";
            this.btnAddUserDetail.UseVisualStyleBackColor = true;
            this.btnAddUserDetail.Click += new System.EventHandler(this.btnAddUserDetail_Click);
            // 
            // dgvCommitteeEmployees
            // 
            this.dgvCommitteeEmployees.AllowUserToAddRows = false;
            this.dgvCommitteeEmployees.AllowUserToDeleteRows = false;
            this.dgvCommitteeEmployees.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCommitteeEmployees.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedHeaders;
            this.dgvCommitteeEmployees.BackgroundColor = System.Drawing.Color.White;
            this.dgvCommitteeEmployees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCommitteeEmployees.Location = new System.Drawing.Point(11, 80);
            this.dgvCommitteeEmployees.MultiSelect = false;
            this.dgvCommitteeEmployees.Name = "dgvCommitteeEmployees";
            this.dgvCommitteeEmployees.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCommitteeEmployees.Size = new System.Drawing.Size(362, 150);
            this.dgvCommitteeEmployees.TabIndex = 1;
            this.dgvCommitteeEmployees.Visible = false;
            this.dgvCommitteeEmployees.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCommitteeEmployees_CellClick);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Control;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(11, 14);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(362, 59);
            this.panel2.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(-1, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(358, 36);
            this.label2.TabIndex = 0;
            this.label2.Text = "label2";
            // 
            // frmEmailAlerts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(890, 584);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelAlertCategory);
            this.Name = "frmEmailAlerts";
            this.Text = "Email Alerts";
            this.panelSelectedAlertCategory.ResumeLayout(false);
            this.panelSelectedAlertCategory.PerformLayout();
            this.panelAlertCategory.ResumeLayout(false);
            this.panelAlertCategory.PerformLayout();
            this.panelAlertCategoryHeading.ResumeLayout(false);
            this.panelAlertCategoryHeading.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCommitteeEmployees)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbTenderCommittee;
        private System.Windows.Forms.Panel panelSelectedAlertCategory;
        private System.Windows.Forms.Label lblSelectedCategory;
        private System.Windows.Forms.Panel panelAlertCategory;
        private System.Windows.Forms.Panel panelAlertCategoryHeading;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dgvCommitteeEmployees;
        private System.Windows.Forms.Button btnDeleteUserDetail;
        private System.Windows.Forms.Button btnAddUserDetail;
        private System.Windows.Forms.ListBox lstUsers;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox lstboxAlertCategories;
    }
}