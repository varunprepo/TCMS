﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using MDI_ParenrForm;

namespace MDI_ParenrForm.Admin
{
    public partial class frmSwitchUser : Form
    {              
        string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();

        public frmSwitchUser()
        {
            InitializeComponent();
        }
        string systemUser = string.Empty;
        private void btnLogin_Click(object sender, EventArgs e)
        {
            Boolean chkUserID = false;
            //MessageBox.Show("User Name " + systemUser);
            chkUserID = ChkUser(systemUser);
            if (chkUserID == false)
            {
                MessageBox.Show("You are not authorized to Log on.");
                btnSwitchUser.Focus();
                return;
            }
            else
            {
                dashBoardParent mainForm = new dashBoardParent(lblUser.Text,isHeadOfSection);
                mainForm.StartPosition = FormStartPosition.CenterScreen;
                mainForm.Show();
                this.Hide();
            }
            Users_LogIn_System(systemUser);         // Check for who logon into the Application.
        }

        bool isHeadOfSection = false;
        private Boolean ChkUser(string systemUser)
        {
            Boolean ckhUser_ID = true;
            try
            {
                
                SqlConnection sqlConn = new SqlConnection(strCon);
                sqlConn.Open();

                string sqlQuery = "SELECT user_name,isheadOfSection FROM USERS WHERE user_name = '" + lblUser.Text + "'";
                SqlCommand sqlCmd = new SqlCommand(sqlQuery, sqlConn);
                SqlDataReader sqlDtRead = sqlCmd.ExecuteReader();
                if (sqlDtRead.Read())
                {
                    isHeadOfSection = (bool)sqlDtRead["isheadOfSection"];
                    ckhUser_ID = true;                    
                }
                else
                {
                    ckhUser_ID = false;
                }
                sqlDtRead.Close();
            }
            catch (Exception ex)
            {  
                MessageBox.Show("Please communicate with TCMS Administrator to resolve the Problem");
            }
            return ckhUser_ID;
        }

        private void frmSwitchUser_Load(object sender, EventArgs e)
        {
            systemUser = Environment.UserName;

            lblUser.Text = systemUser;
        }

        private void btnSwitchUser_Click(object sender, EventArgs e)
        {
            Users_LogIn_System(lblUser.Text);
            frmUserLogin frmLogin = new frmUserLogin();
            frmLogin.StartPosition = FormStartPosition.CenterScreen;
            frmLogin.Show();

            this.Hide();       
        }
        public bool isValidUser = false;
        private string username = null; 
        private string passWord = null;

        private void btnSwitchUser_Enter(object sender, EventArgs e)
        {
           // frmUserLogin frmLogin = new frmUserLogin();
           // frmLogin.StartPosition = FormStartPosition.CenterScreen;
           // frmLogin.Show();

           //// this.Close();
        }

        private void frmSwitchUser_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
        //clsDatabase cDatabase = new clsDatabase(Program.dbPath);  // Sree
        //public clsUser(string UserName,string Password)
        //{
        //     username = UserName;
        //     passWord = Password;

        //        if (ValidateUser())
        //        isValidUser = true;
        //        else
        //        isValidUser =   false;
        //}

        //private bool ValidateUser()
        //{
        //   cDatabase.ConnectDB();
        //   DataTable dtusers = cDatabase.FillInfo("Select * from ADCS_Users", new OleDbDataAdapter()); DataTable dtRoles = cDatabase.FillInfo("Select * from ADCS_UserRoles", new OleDbDataAdapter()); DataRow[] dRows = dtusers.Select("Username = '" + username +"'"); if (dRows.Length != 1) return false; DataRow cRow = dRows[0]; string userName = (string)cRow["UserName"]; string enPassword = (string)cRow["Password"]; clsEncriptor cEncripter = new clsEncriptor(); string dePassword = cEncripter.DecryptString(enPassword); if (dePassword == passWord) return true; return false;
        //}
        //public bool UpdateNewPassWord(string cUserName, string NewEncriptedPassword)
        //{
        //    string sqlString = "Update ADCS_Users set [Password] = \"" + NewEncriptedPassword + "\" Where [Username] = '" + cUserName + "'";
        //    cDatabase.ExcuteNonQuery(sqlString);
        //    return true;
        //}
        //public int GetAccessLevel(string UserName)
        //{
        //  string sqlString = "Select [Role] From ADCS_Users where [Username] = '" + UserName + "'"; object AccLevel = cDatabase.ExcuteScalar(sqlString); int outInt = 1; int.TryParse(AccLevel.ToString(), out outInt); return outInt;
        //}              


        private void Users_LogIn_System(string _userName)
        {
            try
            {
                SqlConnection sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                string strUpdate = "Update Users SET LOgon = 1 where user_name = '" + _userName + "'";
                SqlCommand sqlCmd = new SqlCommand(strUpdate, sqlConn);
                sqlCmd.ExecuteNonQuery();
                sqlConn.Close();                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Users_LogOut_System(string _userName)
        {
            try
            {
                SqlConnection sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                string strUpdate = "Update Users SET LogOn = 0 Where user_name = '" + _userName + "'";
                SqlCommand sqlCmd = new SqlCommand(strUpdate, sqlConn);
                sqlCmd.ExecuteNonQuery();
                sqlConn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        
        
        


        // =============================================================================

        
      
    }
}
