﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using Excel = Microsoft.Office.Interop.Excel;
using TenderTrackingSystem;


namespace MDI_ParenrForm.Admin
{
    public partial class frmUsers : Form
    {
        protected SqlConnection sqlConn;
        protected SqlCommand sqlCom;

        protected SqlDataReader sqlReader;

        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();
        string _userName = string.Empty;
        public frmUsers(IList<string> userRightsColl,string user)
        {
            InitializeComponent();
            _userName = user;
        }
        CreateCheckBox chkBox = null;
        CheckBox headerCheckBox = null;
        BindingSource myBindingSource = null;
        DataTable dtTemp = null;

        private void frmUsers_Load(object sender, EventArgs e)
        {
            var col0 = new DataGridViewCheckBoxColumn();
            var col1 = new DataGridViewTextBoxColumn();
            var col2 = new DataGridViewTextBoxColumn();
            var col3 = new DataGridViewTextBoxColumn();
            var col4 = new DataGridViewTextBoxColumn();
            var col5 = new DataGridViewCheckBoxColumn();
            var col6 = new DataGridViewCheckBoxColumn();

            //headerCheckBox = new CheckBox();
           // chkBox = new CreateCheckBox(dgView, headerCheckBox);
            //chkBox.AddHeaderCheckBox();

            dgViewUsers.Columns.AddRange(new DataGridViewColumn[] {col0, col1, col2, col3, col4, col5, col6});
            dgViewUsers.AutoGenerateColumns = false;
            dgViewUsers.AllowUserToAddRows = false;

            //dgView.AutoResizeColumns();

            col0.Name = "chkBxSelect";
            col0.DataPropertyName = "Select";
            col0.HeaderText = "Select";
            //col0.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            col0.Width = 40;

            col1.DataPropertyName = "UserName";
            col1.HeaderText = "User Name";
            col1.Resizable = System.Windows.Forms.DataGridViewTriState.True;

            col2.DataPropertyName = "SecurityProfile";
            col2.HeaderText = "Security Profile";
            col2.Resizable = System.Windows.Forms.DataGridViewTriState.True;

            col3.DataPropertyName = "EmailAddress";
            col3.HeaderText = "Email Address";
            col3.Resizable = System.Windows.Forms.DataGridViewTriState.True;

            col4.DataPropertyName = "ActualName";
            col4.HeaderText = "Actual Name";
            col4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            col4.Width = 300;

            col5.DataPropertyName = "Logon";
            col5.HeaderText = "Logon";
            col5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            col5.ReadOnly = true;

            col6.DataPropertyName = "user_id";
            col6.HeaderText = "user_id";
            col6.Resizable = System.Windows.Forms.DataGridViewTriState.True;

            //DataGridViewRow row = this.dgView.RowTemplate;
            //row.DefaultCellStyle.BackColor = Color.Bisque;
            //row.Height = 30;
            //row.MinimumHeight = 15;

            BindingSource myBindingSource = null;
            try
            {
                DataTable finalDt = new DataTable("Company");
                finalDt.Columns.Add("Select");
                finalDt.Columns.Add("UserName");
                finalDt.Columns.Add("SecurityProfile");
                finalDt.Columns.Add("EmailAddress");
                finalDt.Columns.Add("ActualName");
                finalDt.Columns.Add("Logon");
                finalDt.Columns.Add("user_id");
        

                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                string sqlQuery = "SELECT USERS.user_name, UserSecurityProfile.profile_name, USERS.email_address, USERS.actual_name," +
                " USERS.[LogOn], USERS.user_id FROM USERS INNER JOIN UserSecurityProfile ON USERS.user_profile_id = UserSecurityProfile.user_profile_id " +
                " Where USERS.user_id <> 1 ORDER By USERS.USER_ID DESC";
                finalDt.AcceptChanges();
                sqlCom = new SqlCommand(sqlQuery, sqlConn);
                sqlReader = sqlCom.ExecuteReader();

                while (sqlReader.Read())
                {
                    DataRow dr = finalDt.NewRow();
                    dr[1] = sqlReader[0];   
                    dr[2] = sqlReader[1];   
                    dr[3] = sqlReader[2];   
                    dr[4] = sqlReader[3];

                    dr[5] = Convert.ToBoolean(sqlReader[4]);
                    dr[6] = sqlReader[5]; 
                   
                    finalDt.Rows.Add(dr);
                    finalDt.AcceptChanges();
                }
                sqlReader.Close();
                myBindingSource = new BindingSource(finalDt, null);

                //dgView.RowsDefaultCellStyle.BackColor = Color.Bisque;
                //dgView.AlternatingRowsDefaultCellStyle.BackColor = Color.Beige;
                //dgView.CellBorderStyle = DataGridViewCellBorderStyle.None;

                //dgView.DefaultCellStyle.SelectionBackColor = Color.Green;
                //dgView.DefaultCellStyle.SelectionForeColor = Color.Yellow;

                //dgView.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                //dgView.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopLeft;

                //dgView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                //dgView.AllowUserToResizeColumns = false;

                //headerCheckBox.MouseClick += new MouseEventHandler(chkBox.HeaderCheckBox_MouseClick);
                //dgView.CellValueChanged += new DataGridViewCellEventHandler(chkBox.dgvSelectAll_CellValueChanged);
                //dgView.CurrentCellDirtyStateChanged += new EventHandler(chkBox.dgvSelectAll_CurrentCellDirtyStateChanged);
                //dgView.CellPainting += new DataGridViewCellPaintingEventHandler(chkBox.dgvSelectAll_CellPainting);      

                dgViewUsers.DataSource = myBindingSource;
               // dgViewUsers.Columns[5].Visible = false;
                dgViewUsers.Columns[6].Visible = false;
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }    
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Excel.Application xlApp;
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;

            Int16 i, j;

            xlApp = new Excel.ApplicationClass();
            xlWorkBook = xlApp.Workbooks.Add(misValue);

            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            for (i = 0; i <= dgViewUsers.RowCount - 2; i++)
            {
                for (j = 0; j <= dgViewUsers.ColumnCount - 1; j++)
                {
                    xlWorkSheet.Cells[i + 1, j + 1] = dgViewUsers[j, i].Value.ToString();
                }
            }

            xlWorkBook.SaveAs(@"c:\dataGridInfo.xls", Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();

            releaseObject(xlWorkSheet);
            releaseObject(xlWorkBook);
            releaseObject(xlApp);

            System.Diagnostics.Process.Start(@"c:\csharp.net-informations.xls");
        }
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            MDI_ParenrForm.Admin.frmAddUsers frmAddUser = new MDI_ParenrForm.Admin.frmAddUsers(0, _userName);
            frmAddUser.StartPosition = FormStartPosition.CenterParent;
            frmAddUser.ShowDialog();
            LoadUsersInfo();
        }
        int userID = 0;
        private void btnDelete_Click(object sender, EventArgs e)
        {
             DialogResult dlgResult = DialogResult.Yes;
             dlgResult = MessageBox.Show(" Are you sure you want to DELETE this User?", "Delete Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

             if (dlgResult.ToString() == "Yes")
             {
                 List<int> lstObj = new List<int>();
                 int iCnt = 0;
                 for (int iCounter = 0; iCounter < dgViewUsers.RowCount; iCounter++)
                 {
                     DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgViewUsers.Rows[iCounter].Cells[0];
                     if (chkactive.Value != null)
                     {
                         if (chkactive.Value.ToString().ToLower() == "true")
                             iCnt = iCnt + 1;
                     }
                 }
                 if (iCnt > 1)
                 {
                     MessageBox.Show("Please Select Only One Record For Edit");

                     return;
                 }
                 for (int iCounter = 0; iCounter < dgViewUsers.RowCount; iCounter++)
                 {
                     DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgViewUsers.Rows[iCounter].Cells[0];
                     if (chkactive.Value != null)
                     {
                         if (chkactive.Value.ToString().ToLower() == "true")
                         {
                             userID = Convert.ToInt16(dgViewUsers.Rows[iCounter].Cells[6].Value);
                             try
                             {
                                 sqlConn.Open();
                                 sqlCom = new SqlCommand("delete from USERS where User_Id= " + userID + "", sqlConn);
                                 sqlCom.ExecuteNonQuery();
                             }
                             catch (Exception ex)
                             {
                                 MessageBox.Show("Error while deleting the Users", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                             }
                             finally
                             {
                                 sqlConn.Close();
                             }
                             lstObj.Add(iCounter);

                         }
                     }
                 }
                 short sClear = 0;
                 if (dgViewUsers.Rows.Count == lstObj.Count)
                 {
                     dgViewUsers.Rows.RemoveAt(lstObj[0]);
                     sClear = 1;
                 }
                 if (sClear != 1)
                 {
                     for (int iCounter = 0; iCounter < lstObj.Count; iCounter++)
                     {
                         if (iCounter == 0)
                             dgViewUsers.Rows.RemoveAt(lstObj[iCounter]);
                         if (iCounter != 0)
                             dgViewUsers.Rows.RemoveAt(lstObj[iCounter] - 1);
                     }
                 }
                 if (lstObj.Count == 0)
                     MessageBox.Show("Please select a record from GridView", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                 else
                     LoadUsersInfo();
             }       
        }
        private void LoadUsersInfo()
        {
            try
            {
                DataTable finalDt = new DataTable("Users");
                finalDt.Columns.Add("Select");
                finalDt.Columns.Add("UserName");
                finalDt.Columns.Add("SecurityProfile");
                finalDt.Columns.Add("EmailAddress");
                finalDt.Columns.Add("ActualName");
                finalDt.Columns.Add("Logon");
                finalDt.Columns.Add("user_id");


                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                string sqlQuery = "SELECT USERS.user_name, UserSecurityProfile.profile_name, USERS.email_address, USERS.actual_name, USERS.[LogOn], USERS.user_id FROM USERS INNER JOIN UserSecurityProfile ON USERS.user_profile_id = UserSecurityProfile.user_profile_id Where USERS.user_id <> 1 ORDER By USERS.USER_ID DESC";
                finalDt.AcceptChanges();
                sqlCom = new SqlCommand(sqlQuery, sqlConn);
                sqlReader = sqlCom.ExecuteReader();

                while (sqlReader.Read())
                {
                    DataRow dr = finalDt.NewRow();
                    dr[1] = sqlReader[0];
                    dr[2] = sqlReader[1];
                    dr[3] = sqlReader[2];
                    dr[4] = sqlReader[3];

                    dr[5] = sqlReader[4];
                    dr[6] = sqlReader[5];

                    finalDt.Rows.Add(dr);
                    finalDt.AcceptChanges();
                }
                sqlReader.Close();
                BindingSource myBindingSource = new BindingSource(finalDt, null);
              
                dgViewUsers.DataSource = myBindingSource;
                dgViewUsers.Columns[6].Visible = false;
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }  
        }
        private void btnEdit_Click(object sender, EventArgs e)
        {
            List<int> lstObj = new List<int>();
            int compId = 0;


            int iCnt = 0;
            for (int iCounter = 0; iCounter < dgViewUsers.RowCount; iCounter++)
            {
                DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgViewUsers.Rows[iCounter].Cells[0];

                if (chkactive.Value != null)
                {
                    if (chkactive.Value.ToString().ToLower() == "true")
                        iCnt = iCnt + 1;
                }
            }
            if (iCnt > 1)
            {
                MessageBox.Show("Please Select Only One Record For Edit");
                return;
            }
            for (int iCounter = 0; iCounter < dgViewUsers.RowCount; iCounter++)
            {
                DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgViewUsers.Rows[iCounter].Cells[0];
                if (chkactive.Value != null)
                {
                    if (chkactive.Value.ToString().ToLower() == "true")
                    {
                        compId = Convert.ToInt16(dgViewUsers.Rows[iCounter].Cells[6].Value);
                        try
                        {
                            MDI_ParenrForm.Admin.frmAddUsers frmAddUser = new MDI_ParenrForm.Admin.frmAddUsers(compId,_userName);
                            frmAddUser.StartPosition = FormStartPosition.CenterParent;
                            frmAddUser.ShowDialog();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error while editing the Users Code", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        finally
                        {
                            sqlConn.Close();
                        }
                        lstObj.Add(iCounter);
                    }
                }
            }
            if (lstObj.Count == 0)
                MessageBox.Show("Please select a record from GridView", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                LoadUsersInfo();
        }
        private void button3_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
        private void dgView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dgViewUsers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }
    }
}
