﻿namespace MDI_ParenrForm.Admin
{
    partial class frmAdminCodes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dgvTenderStatus = new System.Windows.Forms.DataGridView();
            this.txtTndrStatusName = new System.Windows.Forms.TextBox();
            this.txtTndrStatusShortName = new System.Windows.Forms.TextBox();
            this.btnStatusName = new System.Windows.Forms.Button();
            this.lblTnderStatusName = new System.Windows.Forms.Label();
            this.lblTndrStatusShortName = new System.Windows.Forms.Label();
            this.btnTndrStatClear = new System.Windows.Forms.Button();
            this.lblTndrStatusID = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dgvTenderTypes = new System.Windows.Forms.DataGridView();
            this.txtTndrTypeName = new System.Windows.Forms.TextBox();
            this.TenderShortName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblTndrTypeID = new System.Windows.Forms.Label();
            this.btnTndrTypeClear = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTenderStatus)).BeginInit();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTenderTypes)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.lblTndrStatusID);
            this.tabPage2.Controls.Add(this.btnTndrStatClear);
            this.tabPage2.Controls.Add(this.lblTndrStatusShortName);
            this.tabPage2.Controls.Add(this.lblTnderStatusName);
            this.tabPage2.Controls.Add(this.btnStatusName);
            this.tabPage2.Controls.Add(this.txtTndrStatusShortName);
            this.tabPage2.Controls.Add(this.txtTndrStatusName);
            this.tabPage2.Controls.Add(this.dgvTenderStatus);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(676, 495);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "TenderStatus";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dgvTenderStatus
            // 
            this.dgvTenderStatus.AllowUserToOrderColumns = true;
            this.dgvTenderStatus.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTenderStatus.BackgroundColor = System.Drawing.Color.LightSteelBlue;
            this.dgvTenderStatus.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTenderStatus.Location = new System.Drawing.Point(17, 146);
            this.dgvTenderStatus.Name = "dgvTenderStatus";
            this.dgvTenderStatus.ReadOnly = true;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTenderStatus.RowHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvTenderStatus.Size = new System.Drawing.Size(637, 332);
            this.dgvTenderStatus.TabIndex = 1;
            this.dgvTenderStatus.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTenderStatus_CellClick);
            this.dgvTenderStatus.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTenderStatus_CellContentClick);
            // 
            // txtTndrStatusName
            // 
            this.txtTndrStatusName.Location = new System.Drawing.Point(190, 33);
            this.txtTndrStatusName.Name = "txtTndrStatusName";
            this.txtTndrStatusName.Size = new System.Drawing.Size(288, 20);
            this.txtTndrStatusName.TabIndex = 2;
            // 
            // txtTndrStatusShortName
            // 
            this.txtTndrStatusShortName.Location = new System.Drawing.Point(190, 66);
            this.txtTndrStatusShortName.Name = "txtTndrStatusShortName";
            this.txtTndrStatusShortName.Size = new System.Drawing.Size(288, 20);
            this.txtTndrStatusShortName.TabIndex = 3;
            // 
            // btnStatusName
            // 
            this.btnStatusName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStatusName.Location = new System.Drawing.Point(190, 101);
            this.btnStatusName.Name = "btnStatusName";
            this.btnStatusName.Size = new System.Drawing.Size(63, 23);
            this.btnStatusName.TabIndex = 6;
            this.btnStatusName.Text = "Save";
            this.btnStatusName.UseVisualStyleBackColor = true;
            this.btnStatusName.Click += new System.EventHandler(this.btnStatusName_Click);
            // 
            // lblTnderStatusName
            // 
            this.lblTnderStatusName.AutoSize = true;
            this.lblTnderStatusName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTnderStatusName.Location = new System.Drawing.Point(49, 37);
            this.lblTnderStatusName.Name = "lblTnderStatusName";
            this.lblTnderStatusName.Size = new System.Drawing.Size(119, 13);
            this.lblTnderStatusName.TabIndex = 7;
            this.lblTnderStatusName.Text = "TenderStatus Name";
            // 
            // lblTndrStatusShortName
            // 
            this.lblTndrStatusShortName.AutoSize = true;
            this.lblTndrStatusShortName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTndrStatusShortName.Location = new System.Drawing.Point(58, 69);
            this.lblTndrStatusShortName.Name = "lblTndrStatusShortName";
            this.lblTndrStatusShortName.Size = new System.Drawing.Size(109, 13);
            this.lblTndrStatusShortName.TabIndex = 8;
            this.lblTndrStatusShortName.Text = "Status ShortName";
            // 
            // btnTndrStatClear
            // 
            this.btnTndrStatClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTndrStatClear.Location = new System.Drawing.Point(253, 101);
            this.btnTndrStatClear.Name = "btnTndrStatClear";
            this.btnTndrStatClear.Size = new System.Drawing.Size(63, 23);
            this.btnTndrStatClear.TabIndex = 9;
            this.btnTndrStatClear.Text = "Clear";
            this.btnTndrStatClear.UseVisualStyleBackColor = true;
            this.btnTndrStatClear.Click += new System.EventHandler(this.btnTndrStatClear_Click);
            // 
            // lblTndrStatusID
            // 
            this.lblTndrStatusID.AutoSize = true;
            this.lblTndrStatusID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTndrStatusID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lblTndrStatusID.Location = new System.Drawing.Point(484, 35);
            this.lblTndrStatusID.Name = "lblTndrStatusID";
            this.lblTndrStatusID.Size = new System.Drawing.Size(2, 15);
            this.lblTndrStatusID.TabIndex = 10;
            this.lblTndrStatusID.Visible = false;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnTndrTypeClear);
            this.tabPage1.Controls.Add(this.lblTndrTypeID);
            this.tabPage1.Controls.Add(this.btnSave);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.TenderShortName);
            this.tabPage1.Controls.Add(this.txtTndrTypeName);
            this.tabPage1.Controls.Add(this.dgvTenderTypes);
            this.tabPage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(676, 495);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "TenderTypes";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dgvTenderTypes
            // 
            this.dgvTenderTypes.AllowUserToOrderColumns = true;
            this.dgvTenderTypes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTenderTypes.BackgroundColor = System.Drawing.Color.LightSteelBlue;
            this.dgvTenderTypes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTenderTypes.Location = new System.Drawing.Point(16, 148);
            this.dgvTenderTypes.Name = "dgvTenderTypes";
            this.dgvTenderTypes.ReadOnly = true;
            this.dgvTenderTypes.Size = new System.Drawing.Size(637, 322);
            this.dgvTenderTypes.TabIndex = 0;
            this.dgvTenderTypes.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTenderTypes_CellClick);
            this.dgvTenderTypes.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTenderTypes_CellContentClick);
            // 
            // txtTndrTypeName
            // 
            this.txtTndrTypeName.Location = new System.Drawing.Point(190, 31);
            this.txtTndrTypeName.Name = "txtTndrTypeName";
            this.txtTndrTypeName.Size = new System.Drawing.Size(288, 20);
            this.txtTndrTypeName.TabIndex = 1;
            // 
            // TenderShortName
            // 
            this.TenderShortName.Location = new System.Drawing.Point(190, 65);
            this.TenderShortName.Name = "TenderShortName";
            this.TenderShortName.Size = new System.Drawing.Size(288, 20);
            this.TenderShortName.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Tender Type ShortName";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(64, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "TenderTypeName";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(190, 100);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(63, 23);
            this.btnSave.TabIndex = 5;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lblTndrTypeID
            // 
            this.lblTndrTypeID.AutoSize = true;
            this.lblTndrTypeID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTndrTypeID.ForeColor = System.Drawing.Color.Coral;
            this.lblTndrTypeID.Location = new System.Drawing.Point(484, 33);
            this.lblTndrTypeID.Name = "lblTndrTypeID";
            this.lblTndrTypeID.Size = new System.Drawing.Size(2, 15);
            this.lblTndrTypeID.TabIndex = 6;
            this.lblTndrTypeID.Visible = false;
            // 
            // btnTndrTypeClear
            // 
            this.btnTndrTypeClear.Location = new System.Drawing.Point(253, 100);
            this.btnTndrTypeClear.Name = "btnTndrTypeClear";
            this.btnTndrTypeClear.Size = new System.Drawing.Size(63, 23);
            this.btnTndrTypeClear.TabIndex = 7;
            this.btnTndrTypeClear.Text = "Clear";
            this.btnTndrTypeClear.UseVisualStyleBackColor = true;
            this.btnTndrTypeClear.Click += new System.EventHandler(this.btnTndrTypeClear_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(684, 521);
            this.tabControl1.TabIndex = 0;
            // 
            // frmAdminCodes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(706, 547);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmAdminCodes";
            this.Text = "Admin Codes";
            this.Load += new System.EventHandler(this.frmAdminCodes_Load);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTenderStatus)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTenderTypes)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label lblTndrStatusID;
        private System.Windows.Forms.Button btnTndrStatClear;
        private System.Windows.Forms.Label lblTndrStatusShortName;
        private System.Windows.Forms.Label lblTnderStatusName;
        private System.Windows.Forms.Button btnStatusName;
        private System.Windows.Forms.TextBox txtTndrStatusShortName;
        private System.Windows.Forms.TextBox txtTndrStatusName;
        private System.Windows.Forms.DataGridView dgvTenderStatus;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button btnTndrTypeClear;
        private System.Windows.Forms.Label lblTndrTypeID;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TenderShortName;
        private System.Windows.Forms.TextBox txtTndrTypeName;
        private System.Windows.Forms.DataGridView dgvTenderTypes;
        private System.Windows.Forms.TabControl tabControl1;

    }
}