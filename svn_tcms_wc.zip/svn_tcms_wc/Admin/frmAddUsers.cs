﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace MDI_ParenrForm.Admin
{
    public partial class frmAddUsers : Form
    {
        protected int _userID = 0;
        string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();        
        protected SqlConnection sqlConn;
        protected SqlCommand sqlCom;
        protected SqlDataReader sqlReader;

        clsDatabase clsDb = new clsDatabase("");
        string _userName = string.Empty;
        public frmAddUsers(int userID,string user)
        {
            InitializeComponent();
            _userID = userID;
            _userName = user;
            PopulateComboBox(cmbUserProfile, "SELECT User_Profile_id,Profile_Name FROM UserSecurityProfile Order By User_Profile_id", "User_Profile_id", "Profile_Name");            
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            string date_str = System.DateTime.Now.Date.ToString();

            if (txtuserName.Text == "")
            {
                MessageBox.Show("Please Enter UserName");
                txtuserName.Focus();
                return;
            }
            else if (txtPassword.Text == "")
            {
                MessageBox.Show("Please enter Password");
                txtPassword.Focus();
                return;
            }
            else if (txtEmail.Text == "")
            {
                MessageBox.Show("Please Enter Email Address");
                txtEmail.Focus();
                return;
            }
            else if (txtActualname.Text == "")
            {
                MessageBox.Show("Please Enter Actual Name");
                txtActualname.Focus();
                return;
            }
            else if (cmbUserProfile.SelectedIndex == -1)
            {
                MessageBox.Show("Please Select User Profile");
                cmbUserProfile.Focus();
                return;
            }
            else if (chkBoxDeptManager.Checked)
            {
                if (cmbEmployeeName.SelectedIndex == -1)
                {
                    MessageBox.Show("Please Select an Employee Name which must be directly associated with the User Name");
                    cmbEmployeeName.Focus();
                    return;
                }               
            }
            
            if (_userID == 0)
                AddUsersInfo();
            else
                UpdateUsers();
        }
        private void AddUsersInfo()
        {            

            int maxuserID = MaxUserID();
            try
            {
                SqlConnection sqlCon = new SqlConnection(strCon);
                sqlCon.Open();

                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = "Insert into USERS(user_id,user_profile_id,user_name,email_address,password,actual_name, " +
                " create_user,create_date,LogOn,isheadOfSection,isDeptManager,employee_id) values (@userId,@profileID,@userName,@email,@pawrd,@actualName,@createUser,@createDate,@logOn,@isheadOfSection,@isDeptManager,@employee_id)";

                cmd.Connection = sqlCon;                
                cmd.Parameters.AddWithValue("@userId", maxuserID);
                cmd.Parameters.AddWithValue("@profileID", cmbUserProfile.SelectedValue);
                cmd.Parameters.AddWithValue("@userName", txtuserName.Text);

                cmd.Parameters.AddWithValue("@email", txtEmail.Text);
                cmd.Parameters.AddWithValue("@pawrd", txtPassword.Text);
                cmd.Parameters.AddWithValue("@actualName", txtActualname.Text);
                cmd.Parameters.AddWithValue("@createUser", _userName);
                cmd.Parameters.AddWithValue("@createDate",System.DateTime.Now);
                cmd.Parameters.AddWithValue("@logOn", 0);
                if (chkBoxHeadOfSection.Checked)
                    cmd.Parameters.AddWithValue("@isheadOfSection", 1);               
                else
                    cmd.Parameters.AddWithValue("@isheadOfSection", 0);
                if (chkBoxDeptManager.Checked)
                    cmd.Parameters.AddWithValue("@isDeptManager", 1);
                else
                    cmd.Parameters.AddWithValue("@isDeptManager", 0);

                if (chkBoxDeptManager.Checked)
                {
                    if (cmbEmployeeName.SelectedIndex != -1)
                    {
                        cmd.Parameters.AddWithValue("@employee_id", cmbEmployeeName.SelectedValue);
                    }                   
                }
                else
                    cmd.Parameters.AddWithValue("@employee_id", DBNull.Value);

                cmd.ExecuteNonQuery();
                sqlCon.Close();
                MessageBox.Show("Users Details Added Successfully");
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error While Insert Users Info" + ex.Message);
            } 
        }
        private void UpdateUsers()
        {
            SqlConnection sqlConn = new SqlConnection(strCon);
            try
            {
                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();                

                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = "Update USERS Set user_profile_id = @profileID,user_name = @userName,password = @pawrd, email_address = @email, actual_name =@actualName,update_user = @updateUser" +
                ",update_date = @updateDate,isheadOfSection=@isheadOfSection,isDeptManager=@isDeptManager,employee_id=@employee_id Where user_id = @userId";

                cmd.Connection = sqlConn;
                cmd.Parameters.AddWithValue("@userId", _userID);
                cmd.Parameters.AddWithValue("@profileID", cmbUserProfile.SelectedValue);
                cmd.Parameters.AddWithValue("@userName", txtuserName.Text);

                cmd.Parameters.AddWithValue("@email", txtEmail.Text);
                cmd.Parameters.AddWithValue("@pawrd", txtPassword.Text);
                cmd.Parameters.AddWithValue("@actualName", txtActualname.Text);
                cmd.Parameters.AddWithValue("@updateUser", _userName);
                cmd.Parameters.AddWithValue("@updateDate", System.DateTime.Now.Date);
                if (chkBoxHeadOfSection.Checked)
                    cmd.Parameters.AddWithValue("@isheadOfSection", 1);
                else
                    cmd.Parameters.AddWithValue("@isheadOfSection", 0);
                if (chkBoxDeptManager.Checked)
                    cmd.Parameters.AddWithValue("@isDeptManager", 1);
                else
                    cmd.Parameters.AddWithValue("@isDeptManager", 0);
                if (cmbEmployeeName.SelectedIndex !=-1)
                    cmd.Parameters.AddWithValue("@employee_id", cmbEmployeeName.SelectedValue);
                else
                    cmd.Parameters.AddWithValue("@employee_id", DBNull.Value);
                cmd.ExecuteNonQuery();
                sqlConn.Close();
                MessageBox.Show("User Details Updated SuccessFully");
                this.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private int MaxUserID()
        {
            int UserID = 0;
            try
            {
                SqlConnection sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                sqlCom = new SqlCommand("select max(user_id) from USERS", sqlConn);
                sqlReader = sqlCom.ExecuteReader();
                sqlReader.Read();
                UserID = Convert.ToInt32(sqlReader[0]) + 1;
                sqlReader.Close();
                sqlConn.Close();
            }
            catch (Exception ex)
            {
                throw;
            }
            return UserID;            
        }
        public void PopulateComboBox(ComboBox cmbBox, string sqlQuery, string valueMember, string displayName)
        {
            DataTable table = new DataTable();
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(sqlQuery, sqlConn))
                        da.Fill(table);
                }
                //cmbBox.Items.Add("Select");
                cmbBox.DataSource = table;
                cmbBox.DisplayMember = displayName;
                cmbBox.ValueMember = valueMember;
                cmbBox.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void frmAddUsers_Load(object sender, EventArgs e)
        {
            if (_userID != 0)
            {
                FillUserUpdateData();
            }
        }
        private void FillUserUpdateData()
        {
            sqlConn = new SqlConnection(strCon);
            sqlConn.Open();
            string sqlQuery = "SELECT USERS.user_name, UserSecurityProfile.profile_name, USERS.email_address, USERS.actual_name, USERS.[LogOn], USERS.user_id,USERS.password,USERS.isheadOfSection,USERS.isDeptManager,USERS.employee_id " +
            "FROM USERS INNER JOIN UserSecurityProfile ON USERS.user_profile_id = UserSecurityProfile.user_profile_id Where USERS.user_id = " + _userID + "";

            sqlCom = new SqlCommand(sqlQuery, sqlConn);
            sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                txtuserName.Text = sqlReader[0].ToString();
                txtPassword.Text = sqlReader[6].ToString();
                txtEmail.Text = sqlReader[2].ToString();
                txtActualname.Text = sqlReader[3].ToString();
                cmbUserProfile.Text = sqlReader[1].ToString();
                if (sqlReader[7].ToString() == "True")
                    chkBoxHeadOfSection.Checked = true;
                else
                    chkBoxHeadOfSection.Checked = false;
                if (sqlReader[8].ToString() == "True")
                {
                    chkBoxDeptManager.Checked = true;                    
                }
                else
                {
                    chkBoxDeptManager.Checked = false;
                    lblEmpName.Visible = false;
                    cmbEmployeeName.Visible = false;
                    lblEmpNameAsterisk.Visible = false;
                }
                if (sqlReader["employee_id"].ToString() != "")
                    cmbEmployeeName.SelectedValue = sqlReader["employee_id"].ToString();
                 
            }
            sqlReader.Close();
            sqlConn.Close();
        }
        private void fillUserData()
        {
            try
            {
                SqlConnection sqlConn = new SqlConnection(strCon);
                string sqlQuery = "SELECT USERS.user_name, UserSecurityProfile.profile_name, USERS.email_address, USERS.actual_name, USERS.[LogOn], USERS.user_id " +
                " FROM  USERS INNER JOIN UserSecurityProfile ON USERS.user_profile_id = UserSecurityProfile.user_profile_id WHERE (USERS.user_id = 17) ORDER BY USERS.user_id DESC";

                sqlCom = new SqlCommand(sqlQuery, sqlConn);              
                sqlConn.Open();


                sqlCom.ExecuteNonQuery();
                sqlConn.Close();
                MessageBox.Show("Users Info Added Successfully");
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error While Insert Users Info" + ex.Message);
            } 
        }
        Regex ValidEmailRegex = CreateValidEmailRegex();
        private static Regex CreateValidEmailRegex()
        {
            string validEmailPattern = @"^(?!\.)(""([^""\r\\]|\\[""\r\\])*""|"
                + @"([-a-z0-9!#$%&'*+/=?^_`{|}~]|(?<!\.)\.)*)(?<!\.)"
                + @"@[a-z0-9][\w\.-]*[a-z0-9]\.[a-z][a-z\.]*[a-z]$";

            return new Regex(validEmailPattern, RegexOptions.IgnoreCase);
        }
        private bool EmailIsValid(string emailAddress)
        {
            bool isValid = ValidEmailRegex.IsMatch(emailAddress);
            return isValid;
        }

        private void txtEmail_Leave(object sender, EventArgs e)
        {
            if (txtEmail.Text != "")
            {
                if (EmailIsValid(txtEmail.Text) == false)
                {
                    MessageBox.Show("Please enter proper email address");
                    txtEmail.Focus();
                    return;
                }
            }
        }

        private void chkBoxDeptManager_CheckedChanged(object sender, EventArgs e)
        {
            if (chkBoxDeptManager.Checked)
            {
                lblEmpName.Visible = true;
                cmbEmployeeName.Visible = true;
                lblEmpNameAsterisk.Visible = true;
                PopulateComboBox(cmbEmployeeName, "SELECT LTRIM(RTRIM(Contacts.FirstName)) + ' ' + LTRIM(RTRIM(Contacts.LastName)) as EmpName,Contacts.employee_id FROM Contacts join COMPANY on Contacts.co_id=" +
                "COMPANY.co_id WHERE (COMPANY.co_name LIKE '%PWA%') AND (COMPANY.co_name <> 'PWA')", "employee_id", "EmpName");
            }
            else
            {
                lblEmpName.Visible = false;
                cmbEmployeeName.Visible = false;
                lblEmpNameAsterisk.Visible = false;
            }
        }         

    }
}
