﻿namespace MDI_ParenrForm.Admin
{
    partial class frmNewCodes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.lblMinistryCode = new System.Windows.Forms.Label();
            this.btnClr = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMinCode = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMinName = new System.Windows.Forms.TextBox();
            this.dgvMinistryCodes = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lblbudget = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.lblTndrStatusShortName = new System.Windows.Forms.Label();
            this.lblTnderStatusName = new System.Windows.Forms.Label();
            this.btnBudget = new System.Windows.Forms.Button();
            this.txtBudgetName = new System.Windows.Forms.TextBox();
            this.txtBudgetCode = new System.Windows.Forms.TextBox();
            this.dgvBudget = new System.Windows.Forms.DataGridView();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMinistryCodes)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBudget)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(684, 538);
            this.tabControl1.TabIndex = 1;
            this.tabControl1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tabControl1_MouseClick);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lblMinistryCode);
            this.tabPage1.Controls.Add(this.btnClr);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.txtMinCode);
            this.tabPage1.Controls.Add(this.btnSave);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.txtMinName);
            this.tabPage1.Controls.Add(this.dgvMinistryCodes);
            this.tabPage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(676, 512);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "MinistryCodes";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // lblMinistryCode
            // 
            this.lblMinistryCode.AutoSize = true;
            this.lblMinistryCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblMinistryCode.ForeColor = System.Drawing.Color.Coral;
            this.lblMinistryCode.Location = new System.Drawing.Point(469, 34);
            this.lblMinistryCode.Name = "lblMinistryCode";
            this.lblMinistryCode.Size = new System.Drawing.Size(2, 15);
            this.lblMinistryCode.TabIndex = 11;
            this.lblMinistryCode.Visible = false;
            // 
            // btnClr
            // 
            this.btnClr.Location = new System.Drawing.Point(216, 111);
            this.btnClr.Name = "btnClr";
            this.btnClr.Size = new System.Drawing.Size(63, 23);
            this.btnClr.TabIndex = 10;
            this.btnClr.Text = "Clear";
            this.btnClr.UseVisualStyleBackColor = true;
            this.btnClr.Click += new System.EventHandler(this.btnClr_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(50, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Ministry Code";
            // 
            // txtMinCode
            // 
            this.txtMinCode.Location = new System.Drawing.Point(153, 31);
            this.txtMinCode.Name = "txtMinCode";
            this.txtMinCode.Size = new System.Drawing.Size(288, 20);
            this.txtMinCode.TabIndex = 7;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(153, 111);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(63, 23);
            this.btnSave.TabIndex = 5;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(47, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Ministry Name";
            // 
            // txtMinName
            // 
            this.txtMinName.Location = new System.Drawing.Point(153, 63);
            this.txtMinName.Multiline = true;
            this.txtMinName.Name = "txtMinName";
            this.txtMinName.Size = new System.Drawing.Size(288, 38);
            this.txtMinName.TabIndex = 1;
            // 
            // dgvMinistryCodes
            // 
            this.dgvMinistryCodes.AllowUserToOrderColumns = true;
            this.dgvMinistryCodes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvMinistryCodes.BackgroundColor = System.Drawing.Color.LightSteelBlue;
            this.dgvMinistryCodes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMinistryCodes.Location = new System.Drawing.Point(21, 154);
            this.dgvMinistryCodes.Name = "dgvMinistryCodes";
            this.dgvMinistryCodes.ReadOnly = true;
            this.dgvMinistryCodes.Size = new System.Drawing.Size(637, 337);
            this.dgvMinistryCodes.TabIndex = 0;
            this.dgvMinistryCodes.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvMinistryCodes_CellClick);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.lblbudget);
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Controls.Add(this.lblTndrStatusShortName);
            this.tabPage2.Controls.Add(this.lblTnderStatusName);
            this.tabPage2.Controls.Add(this.btnBudget);
            this.tabPage2.Controls.Add(this.txtBudgetName);
            this.tabPage2.Controls.Add(this.txtBudgetCode);
            this.tabPage2.Controls.Add(this.dgvBudget);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(676, 512);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Budget Reference Codes";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // lblbudget
            // 
            this.lblbudget.AutoSize = true;
            this.lblbudget.Location = new System.Drawing.Point(484, 25);
            this.lblbudget.Name = "lblbudget";
            this.lblbudget.Size = new System.Drawing.Size(0, 13);
            this.lblbudget.TabIndex = 10;
            this.lblbudget.Visible = false;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(253, 100);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(63, 23);
            this.button1.TabIndex = 9;
            this.button1.Text = "Clear";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblTndrStatusShortName
            // 
            this.lblTndrStatusShortName.AutoSize = true;
            this.lblTndrStatusShortName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTndrStatusShortName.Location = new System.Drawing.Point(58, 56);
            this.lblTndrStatusShortName.Name = "lblTndrStatusShortName";
            this.lblTndrStatusShortName.Size = new System.Drawing.Size(102, 13);
            this.lblTndrStatusShortName.TabIndex = 8;
            this.lblTndrStatusShortName.Text = "Reference Name";
            // 
            // lblTnderStatusName
            // 
            this.lblTnderStatusName.AutoSize = true;
            this.lblTnderStatusName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTnderStatusName.Location = new System.Drawing.Point(14, 25);
            this.lblTnderStatusName.Name = "lblTnderStatusName";
            this.lblTnderStatusName.Size = new System.Drawing.Size(143, 13);
            this.lblTnderStatusName.TabIndex = 7;
            this.lblTnderStatusName.Text = "Budget Reference Code";
            // 
            // btnBudget
            // 
            this.btnBudget.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBudget.Location = new System.Drawing.Point(190, 100);
            this.btnBudget.Name = "btnBudget";
            this.btnBudget.Size = new System.Drawing.Size(63, 23);
            this.btnBudget.TabIndex = 6;
            this.btnBudget.Text = "Save";
            this.btnBudget.UseVisualStyleBackColor = true;
            this.btnBudget.Click += new System.EventHandler(this.btnBudget_Click);
            // 
            // txtBudgetName
            // 
            this.txtBudgetName.Location = new System.Drawing.Point(190, 53);
            this.txtBudgetName.Multiline = true;
            this.txtBudgetName.Name = "txtBudgetName";
            this.txtBudgetName.Size = new System.Drawing.Size(288, 35);
            this.txtBudgetName.TabIndex = 3;
            // 
            // txtBudgetCode
            // 
            this.txtBudgetCode.Location = new System.Drawing.Point(190, 22);
            this.txtBudgetCode.Name = "txtBudgetCode";
            this.txtBudgetCode.Size = new System.Drawing.Size(288, 20);
            this.txtBudgetCode.TabIndex = 2;
            // 
            // dgvBudget
            // 
            this.dgvBudget.AllowUserToOrderColumns = true;
            this.dgvBudget.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvBudget.BackgroundColor = System.Drawing.Color.LightSteelBlue;
            this.dgvBudget.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBudget.Location = new System.Drawing.Point(17, 138);
            this.dgvBudget.Name = "dgvBudget";
            this.dgvBudget.ReadOnly = true;
            this.dgvBudget.Size = new System.Drawing.Size(638, 354);
            this.dgvBudget.TabIndex = 1;
            this.dgvBudget.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvBudget_CellClick);
            // 
            // frmNewCodes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(713, 562);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmNewCodes";
            this.Text = "Ministry/BudgetReference Codes";
            this.Load += new System.EventHandler(this.frmNewCodes_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMinistryCodes)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBudget)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMinName;
        private System.Windows.Forms.DataGridView dgvMinistryCodes;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label lblTndrStatusShortName;
        private System.Windows.Forms.Label lblTnderStatusName;
        private System.Windows.Forms.Button btnBudget;
        private System.Windows.Forms.TextBox txtBudgetName;
        private System.Windows.Forms.TextBox txtBudgetCode;
        private System.Windows.Forms.DataGridView dgvBudget;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMinCode;
        private System.Windows.Forms.Button btnClr;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblbudget;
        private System.Windows.Forms.Label lblMinistryCode;
    }
}