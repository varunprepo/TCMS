﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using TenderTrackingSystem;

namespace MDI_ParenrForm.Admin
{
    public partial class frmEmailAlerts : Form
    {
        private string strCon = ConfigurationManager.AppSettings["TCMSConnString"].ToString();         
        SqlConnection sqlConn = null;
        SqlCommand sqlCmd = null;
        SqlDataReader sqlDtRead = null;
        DataTable dtCommitteeUsers = null;
        public frmEmailAlerts()
        {
            InitializeComponent();
            try
            {
                DAL dalObj = new DAL();
                dalObj.populateLstBox("select alert_cat_id,AlertCategory from EmailAlertCategory", lstboxAlertCategories);

                lstboxAlertCategories.SelectedItem = 0;
                lstboxAlertCategories.Focus();                

                dalObj.populateCmbBox("select committee_short_name,committee_id from Committee", cmbTenderCommittee);                
                cmbTenderCommittee.SelectedIndex = 0;
                cmbTenderCommittee.Focus();
                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                sqlCmd = new SqlCommand("select actual_name,user_id,email_address,user_name from USERS where (actual_name <> ' ') order by actual_name", sqlConn);
                sqlDtRead = sqlCmd.ExecuteReader();
                if (sqlDtRead.HasRows == true)
                {
                    while (sqlDtRead.Read())
                        lstUsers.Items.Add(new KeyValueData(sqlDtRead[0].ToString(), sqlDtRead[1].ToString() + "," + sqlDtRead[2].ToString() + "," + sqlDtRead[3].ToString()));                         
                    
                }
                sqlDtRead.Close();
                sqlCmd.Dispose();

                dgvCommitteeEmployees.EnableHeadersVisualStyles = false;
                dtCommitteeUsers = new DataTable("UserDetails");
                dtCommitteeUsers.Columns.Add("TenderCommittee");
                dtCommitteeUsers.Columns.Add("Name");
                dtCommitteeUsers.Columns.Add("EmailAddress");
                dtCommitteeUsers.Columns.Add("UserID");
                dtCommitteeUsers.AcceptChanges();                 
                LoadDataInGridView();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while connecting to the database","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            finally
            {
                sqlConn.Close();
                sqlDtRead.Dispose();
            }
        }

        Int16 selectedUserID = 0;
        private void LoadDataInGridView()
        {
            if (dgvCommitteeEmployees != null)
                dgvCommitteeEmployees.DataSource = null;
            if (dtCommitteeUsers != null)
            {
                if (dtCommitteeUsers.Rows.Count > 0)
                    dtCommitteeUsers.Rows.Clear();

                DAL dalObj = new DAL();
                DataTable dtUserIds = dalObj.GetDataFromDB("UserIds", "select user_id from EmailAlertRecipients where alert_cat_id =" + lstboxAlertCategories.SelectedValue + " and committee_id = " + commId);      //Convert.ToInt16(strItemData.Split(',')[0])                                                    
                DataTable dtEmailIds = null;
                Int16 iUserCounter = 0;

                while (iUserCounter < dtUserIds.Rows.Count)
                {
                    dtEmailIds = dalObj.GetDataFromDB("EmailIds", "select actual_name,email_address from USERS where user_id=" + Convert.ToInt16(dtUserIds.Rows[iUserCounter][0]));
                    if (dtEmailIds.Rows.Count != 0)
                    {
                        DataRow dtRow = dtCommitteeUsers.NewRow();
                        dtRow[0] = commShortName;
                        dtRow[1] = dtEmailIds.Rows[0][0];
                        dtRow[2] = dtEmailIds.Rows[0][1];
                        dtRow[3] = dtUserIds.Rows[iUserCounter][0];
                        dtCommitteeUsers.Rows.Add(dtRow);
                        dtCommitteeUsers.AcceptChanges();
                    }
                    iUserCounter++;
                }               
                dgvCommitteeEmployees.DataSource = dtCommitteeUsers;
                dgvCommitteeEmployees.Visible = true;
                dgvCommitteeEmployees.Columns[3].Visible = false;               
            }
        }

        class KeyValueData
        {

            public KeyValueData(string Text, string ItemData)
            {
                text = Text;
                itemData = ItemData;
            }

            public string ItemData
            {
                get
                {
                    return itemData;
                }
                set
                {
                    itemData = value;
                }
            }

            public override string ToString()
            {
                return text;
            }

            private string text;
            private string itemData;
        }


        private void lstBoxAlertCategories_SelectedIndexChanged(object sender, EventArgs e)
        {             
            foreach (var item in lstboxAlertCategories.SelectedItems)
            {
                DataRowView dtView = (DataRowView)item;               
                if(cmbTenderCommittee.SelectedItem!=null)
                    label2.Text = "User that will receive email alert in " + lstboxAlertCategories.Text + " for " + ((DataRowView)cmbTenderCommittee.SelectedItem).Row.ItemArray[0].ToString() + " Projects";
                lblSelectedCategory.Text = dtView.Row.ItemArray[1].ToString();
                LoadDataInGridView();
            }
        }
        private void lstBoxAlertCategories_SelectedValueChanged(object sender, EventArgs e)
        {
            
            lblSelectedCategory.Text = lstboxAlertCategories.GetItemText(lstboxAlertCategories.SelectedIndex).ToString();                         
        }
                 
        string commShortName = "";
        Int16 commId = 0;
        private void cmbTenderCommittee_SelectedIndexChanged(object sender, EventArgs e)
        {
            dgvCommitteeEmployees.DataSource = null;
            //KeyValueData keyVal = (KeyValueData)cmbTenderCommittee.SelectedItem;
            //string strVal = keyVal.ItemData;
            DataRowView dtView = (DataRowView)cmbTenderCommittee.SelectedItem;
            commShortName = dtView.Row.ItemArray[0].ToString();
            commId = Convert.ToInt16(dtView.Row.ItemArray[1]);

            //if (strVal == "")
            //    label2.Text = "User that will receive email alert in New Tender Number Assignment for WPC Projects";
            //else
            label2.Text = "User that will receive email alert in " + lstboxAlertCategories.Text+ " for " + commShortName + " Projects";

            LoadDataInGridView();
        }

        static Int16 userId = 0;
        static string userName = "";
        static string emailAddress = "";
        static string userActualName = "";
        private void lstUsers_SelectedIndexChanged(object sender, EventArgs e)
        {
            KeyValueData keyVal = (KeyValueData)lstUsers.SelectedItem;
            userId = Convert.ToInt16(keyVal.ItemData.Split(',')[0]);
            userName = keyVal.ItemData.Split(',')[2];
            emailAddress = keyVal.ItemData.Split(',')[1];
            userActualName = lstUsers.SelectedItem.ToString();
        }
        private void btnAddUserDetail_Click(object sender, EventArgs e)
        {
            if (userActualName == "")
            {
                MessageBox.Show("Select a user from the List of All Users");
                return;
            }

            try
            {
                SqlDataReader sqlDtReader = null;
                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                sqlCmd = new SqlCommand("select alert_cat_id from EmailAlertRecipients where alert_cat_id=" + lstboxAlertCategories.SelectedValue + " and user_id=" + userId + " and committee_id=" + commId, sqlConn);
                sqlDtReader = sqlCmd.ExecuteReader();
                if (sqlDtReader.HasRows == true)
                {
                    MessageBox.Show("User already exists in " + commShortName + " committee can not add duplicate user", "Selection for Deletion", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Occurred while adding the user" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlConn.Close();
                sqlCmd.Dispose();
            }
            int totalRowCount = dgvCommitteeEmployees.RowCount;
            if (totalRowCount > 0)
            {
                //BindingSource bindSource = (BindingSource)dgvCommitteeEmployees.DataSource;
                dtCommitteeUsers = (DataTable)dgvCommitteeEmployees.DataSource;                                  
                DisplayAndInsertNewRecords();
            }
            else
                DisplayAndInsertNewRecords();
            
        }
        private void DisplayAndInsertNewRecords()
        {            
            DataRow dtRow = dtCommitteeUsers.NewRow();
            dtRow[0] = commShortName;
            dtRow[1] = userActualName;
            dtRow[2] = emailAddress;
            dtRow[3] = userId;
            dtCommitteeUsers.Rows.Add(dtRow);
            dtCommitteeUsers.AcceptChanges();
           
            dgvCommitteeEmployees.DataSource = null;
            dgvCommitteeEmployees.DataSource = dtCommitteeUsers;
            dgvCommitteeEmployees.Visible = true;
            dgvCommitteeEmployees.Columns[3].Visible = false;

            try
            {
                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                sqlCmd = new SqlCommand("insert into EmailAlertRecipients (alert_cat_id,user_id,committee_id,create_date,create_user) values(" + lstboxAlertCategories.SelectedValue + "," + userId + "," + commId + ",'" + System.DateTime.Now.ToString().Split(' ')[0] + "','" + userName + "')", sqlConn);
                int exeResult = sqlCmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Occurred while adding the user"+ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlConn.Close();
                sqlCmd.Dispose();
            }
        }
        private void btnDeleteUserDetail_Click(object sender, EventArgs e)
        {
            if (selectedUserID == 0)
                MessageBox.Show("Please select a row for deleting the user from the email alert list", "Selection for Deletion", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
            {
                try
                {
                    sqlConn = new SqlConnection(strCon);
                    sqlConn.Open();
                    sqlCmd = new SqlCommand("delete from EmailAlertRecipients where user_id=" + selectedUserID + " and committee_id=" + commId + " and alert_cat_id=" + lstboxAlertCategories.SelectedValue, sqlConn);
                    int exeResult = sqlCmd.ExecuteNonQuery();
                    LoadDataInGridView();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while deleting the user" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                finally
                {
                    sqlConn.Close();
                    sqlCmd.Dispose();
                }
            }
        }
        public class ListItem
        {
            public int iLstItemValue;
            public string strLstItem;
            public ListItem(int iValue,string text)
            {
                iLstItemValue = iValue;
                strLstItem = text;
            }
            public override string ToString()
            {
                return strLstItem;
            }
        }
        private void dgvCommitteeEmployees_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
                selectedUserID = Convert.ToInt16(dgvCommitteeEmployees.Rows[e.RowIndex].Cells[3].Value);
        }
      
    }
}
