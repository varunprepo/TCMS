﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using TenderTrackingSystem;

namespace MDI_ParenrForm.Admin
{
    public partial class frmSecurityProfile1 : Form
    {
        protected SqlConnection sqlConn;
        protected SqlCommand sqlCom;

        protected SqlDataReader sqlReader;

        SqlCommand sqlCmd = null;

        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();
        public frmSecurityProfile1(IList<string> userRightsColl)
        {
            InitializeComponent();
        }
        private void frmSecurityProfile1_Load(object sender, EventArgs e)
        {
            //loadData();
            loadData2();
        }
        private void listView1_DrawColumnHeader(object sender, DrawListViewColumnHeaderEventArgs e)
        {
            // Fill header background with solid yello color.
            e.Graphics.FillRectangle(Brushes.Yellow, e.Bounds);
            // Let ListView draw everything else.
            e.DrawText();
        }

        

        //private void loadData(string AccessName)
        //{
        //    try
        //    {

        //        //listView1.View = View.Details;
        //        //listView1.LabelEdit = true;
        //        //listView1.AllowColumnReorder = true;
        //        //listView1.FullRowSelect = true;
        //        //listView1.GridLines = true;
        //        //listView1.CheckBoxes = true;

        //        // listView1.Columns.Add("Has privilege", 130, HorizontalAlignment.Left);
        //        // listView1.Columns.Add("AccessRights", 270, HorizontalAlignment.Left);


        //        sqlConn = new SqlConnection(strCon);
        //        sqlConn.Open();
        //        string sqlQuery = "SELECT UserAccessRights.AccessID, UserAccessRights.[AccessRights], UserPrivelege.HasPrivelege, UserSecurityProfile.profile_name " +
        //        " FROM UserPrivelege INNER JOIN UserAccessRights ON UserPrivelege.AccessID = UserAccessRights.AccessID INNER JOIN UserSecurityProfile ON UserPrivelege.user_profile_id = UserSecurityProfile.user_profile_id " +
        //        " WHERE (UserSecurityProfile.profile_name = 'Administrator')";

        //        sqlCom = new SqlCommand(sqlQuery, sqlConn);
        //        sqlReader = sqlCom.ExecuteReader();
        //        int iCnt = 0;
        //        while (sqlReader.Read())
        //        {
        //            iCnt = iCnt + 1;
        //            ListViewItem lvi = new ListViewItem();
        //            lvi.SubItems.Add(sqlReader[1].ToString());

        //            if (Convert.ToBoolean(sqlReader[2]) == true)
        //            {
        //                lvi.Checked = true;
        //                //lvi.SubItems.Add(sqlReader[2].ToString());
        //            }
        //            else
        //            {
        //                lvi.Checked = false;
        //                //lvi.SubItems.Add(sqlReader[2].ToString());                       
        //            }
        //            listView2.Items.Add(lvi);
        //        }
        //        sqlReader.Close();
        //    }
        //    catch (Exception ex)
        //    {
        //        string exMsg = ex.Message;
        //    }
        //    finally
        //    {
        //        sqlConn.Close();
        //    }
        //}
        private void ShowAccessRightonProfileId(string profileid)
        {
            try
            {

                //listView1.View = View.Details;
                //listView1.LabelEdit = true;
                //listView1.AllowColumnReorder = true;
                //listView1.FullRowSelect = true;
                //listView1.GridLines = true;
                //listView1.CheckBoxes = true;
                 
                // listView1.Columns.Add("Has privilege", 130, HorizontalAlignment.Left);
                // listView1.Columns.Add("AccessRights", 270, HorizontalAlignment.Left);


                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                string sqlQuery = "SELECT UserAccessRights.AccessID, UserAccessRights.[AccessRights], UserPrivelege.HasPrivelege, UserSecurityProfile.profile_name " +
                " FROM UserPrivelege INNER JOIN UserAccessRights ON UserPrivelege.AccessID = UserAccessRights.AccessID INNER JOIN UserSecurityProfile ON UserPrivelege.user_profile_id = UserSecurityProfile.user_profile_id " +
                " WHERE UserSecurityProfile.user_profile_id = " + profileid + "order by  UserPrivelege.AccessID";

                sqlCom = new SqlCommand(sqlQuery, sqlConn);
                sqlReader = sqlCom.ExecuteReader();
                listView2.Items.Clear();
                int iCnt = 0;
                while (sqlReader.Read())
                {
                    iCnt = iCnt + 1;
                    ListViewItem lvi = new ListViewItem();
                    lvi.SubItems.Add(sqlReader[1].ToString());
                    lvi.SubItems.Add(sqlReader[0].ToString());

                    if (Convert.ToBoolean(sqlReader[2]) == true)
                    {
                        lvi.Checked = true;
                        //lvi.SubItems.Add(sqlReader[2].ToString());
                    }
                    else
                    {
                        lvi.Checked = false;
                        //lvi.SubItems.Add(sqlReader[2].ToString());                       
                    }
                    listView2.Items.Add(lvi);
                }
                sqlReader.Close();
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                sqlConn.Close();
            }
        }
        private void loadData2()
        {
            try
            {

                listView2.View = View.Details;
                listView2.LabelEdit = true;
                listView2.AllowColumnReorder = true;
                listView2.FullRowSelect = true;
                listView2.GridLines = true;
                listView2.CheckBoxes = true;

                // listView1.Columns.Add("Has privilege", 130, HorizontalAlignment.Left);
                // listView1.Columns.Add("AccessRights", 270, HorizontalAlignment.Left);


                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                DataTable dtSecurityProfile = new DataTable();
                string sqlQuery = "SELECT user_profile_id,profile_name " +
                " FROM UserSecurityProfile order by user_profile_id  ";       //WHERE (user_profile_id <> 1)

                SqlDataAdapter sqlDtAdapt = new SqlDataAdapter(sqlQuery, sqlConn);
                sqlDtAdapt.Fill(dtSecurityProfile); 
                 
                if (dtSecurityProfile.Rows.Count != 0)
                {
                    //BindingSource myBindingSource = new BindingSource(dtSecurityProfile, null);
                    dgSecurityProfile.DataSource = dtSecurityProfile; // myBindingSource;
                    dgSecurityProfile.Columns[0].Visible = false;
                    dgSecurityProfile.ColumnHeadersVisible = false;
                }
                else
                    dgSecurityProfile.DataSource = null;
            }
            catch (Exception ex)
            {
                string exMsg = ex.Message;
            }
            finally
            {
                dgSecurityProfile.CurrentCell = dgSecurityProfile.Rows[0].Cells[1];
                ShowAccessRightonProfileId("1");                
                sqlConn.Close();
            }
        }

        private void listView2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        //private void listView1_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        //{
        //    string namn = e.Item.Name;
        //}

        //private void listView1_SelectedIndexChanged(object sender, EventArgs e) // On Secuity profiles selection 
        //{
        //    int index = 0;
        //    if (listView1.FocusedItem != null)
        //    {
        //        if (listView1.FocusedItem.Selected) // Check for Whether focused listView item is Selected                             
        //        {
        //            index = Convert.ToInt16(this.listView1.Items[listView1.FocusedItem.Index].SubItems[2].Text);
        //            listView2.Items.Clear();
        //            ShowAccessRightonProfileId(index);
        //        }
        //    }
        //    else
        //    {
        //        ShowAccessRightonProfileId(1); //By Default during loading the form for the first time user_profile_id = 1
        //    }
        //}

        private void btnAccessRightsSave_Click(object sender, EventArgs e)
        {
            sqlCmd = null;
            sqlConn = new SqlConnection(strCon);

            try
            {
                sqlConn.Open();                 
                 
                string selectedprofileid = dgSecurityProfile.Rows[dgSecurityProfile.CurrentRow.Index].Cells[0].Value.ToString(); //Selected user item from User Security profile ListView1 
                
                for (int m = 0; m < listView2.Items.Count; m++) // loop AccessRights Listview
                {
                    int actAccessID = m + 1; //AccessID starts from 1 in UserPrivilege Table so it gets added 1 here
                    sqlCmd = new SqlCommand("update UserPrivelege set HasPrivelege ='" + listView2.Items[m].Checked + "' WHERE user_profile_id = " + selectedprofileid + " and AccessID=" + actAccessID, sqlConn);
                    sqlCmd.ExecuteNonQuery();

                }
                MessageBox.Show("Security Profile Updated Sucessfully", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Occurred while saving Security Profile", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlConn.Close();
            }
        }

        private void btnSecProfileAdd_Click(object sender, EventArgs e)
        {
            frmDialog f = new frmDialog();
            f.StartPosition = FormStartPosition.CenterParent;
            f.ShowDialog(this);
            //listView1.Items.Clear();  //Refresh to display the new added item
            loadData2();
        }

        private void btnupdateSecurityprevilege_Click(object sender, EventArgs e)
        {             
            string selectedprofilename = string.Empty;
            string paramUpdate = "Update";
            string selectedprofileid = dgSecurityProfile.Rows[dgSecurityProfile.CurrentRow.Index].Cells[0].Value.ToString(); //Selected user item from User Security profile ListView1 

            sqlConn = new SqlConnection(strCon);
            sqlConn.Open();
            string sqlQuery = "SELECT profile_name " +
            " FROM UserSecurityProfile where user_profile_id =" + selectedprofileid;
            sqlCom = new SqlCommand(sqlQuery, sqlConn);
            sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                selectedprofilename = sqlReader.GetString(0);
            }

            frmDialog f = new frmDialog(selectedprofilename, paramUpdate, selectedprofileid);
            f.StartPosition = FormStartPosition.CenterParent;
            f.ShowDialog(this);
            sqlReader.Close();
            //listView1.Items.Clear();  //Refresh to display the new added item
            loadData2();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            DialogResult dlgResult = DialogResult.No;
            dlgResult = MessageBox.Show(" Are you sure want to delete this Security Profile.", "Security Profile", MessageBoxButtons.YesNo);

            if (dlgResult.ToString() == "Yes")
            {
                string selectedprofileid = dgSecurityProfile.Rows[dgSecurityProfile.CurrentRow.Index].Cells[0].Value.ToString(); //Selected user item from User Security profile ListView1 

                try
                {
                    sqlConn = new SqlConnection(strCon);
                    sqlConn.Open();
                    string sqlQuery = "SELECT user_id from USERS where user_profile_id = " + selectedprofileid;

                    sqlCom = new SqlCommand(sqlQuery, sqlConn);
                    sqlReader = sqlCom.ExecuteReader();                     
                    if (sqlReader.HasRows)
                    {                         
                      MessageBox.Show("The Security Profile was assigned to a user. It cannot be deleted.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);
                      return;
                    }
                    else
                    {
                        sqlReader.Close();
                        sqlQuery = "delete from UserSecurityProfile where user_profile_id = " + selectedprofileid;
                        sqlCom = new SqlCommand(sqlQuery, sqlConn);
                        sqlCom.ExecuteNonQuery();
                    }
                    sqlReader.Close();
                    MessageBox.Show("Security Profile has been Deleted Sucessfully, Please close the window and reopen it to see the changes", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Error Occurred while deleting Security Profile", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    sqlConn.Close();
                }

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgSecurityProfile_CellClick(object sender, DataGridViewCellEventArgs e)
        {            
            ShowAccessRightonProfileId(dgSecurityProfile.Rows[e.RowIndex].Cells[0].Value.ToString()); //By Default during loading the form for the first time user_profile_id = 1
        }


        ////ListViewItem.ListViewSubItem SelectedLSI;
        ////private void listView1_MouseUp(object sender, MouseEventArgs e)
        ////{
        ////    ListViewHitTestInfo i = listView1.HitTest(e.X, e.Y);
        ////    SelectedLSI = i.SubItem;
        ////    if (SelectedLSI == null)
        ////        return;

        ////    int border = 0;
        ////    switch (listView1.BorderStyle)
        ////    {
        ////        case BorderStyle.FixedSingle:
        ////            border = 1;
        ////            break;
        ////        case BorderStyle.Fixed3D:
        ////            border = 2;
        ////            break;
        ////    }

        ////    int CellWidth = SelectedLSI.Bounds.Width;
        ////    int CellHeight = SelectedLSI.Bounds.Height;
        ////    int CellLeft = border + listView1.Left + i.SubItem.Bounds.Left;
        ////    int CellTop = listView1.Top + i.SubItem.Bounds.Top;
        ////    // First Column
        ////    if (i.SubItem == i.Item.SubItems[0])
        ////        CellWidth = listView1.Columns[0].Width;

        ////    TxtEdit.Location = new Point(CellLeft, CellTop);
        ////    TxtEdit.Size = new Size(CellWidth, CellHeight);
        ////    TxtEdit.Visible = true;
        ////    TxtEdit.BringToFront();
        ////    TxtEdit.Text = i.SubItem.Text;
        ////    TxtEdit.Select();
        ////    TxtEdit.SelectAll();
        ////}
        ////private void listView1_MouseDown(object sender, MouseEventArgs e)
        ////{
        ////    HideTextEditor();
        ////}
        ////private void listView1_Scroll(object sender, EventArgs e)
        ////{
        ////    HideTextEditor();
        ////}
        ////private void TxtEdit_Leave(object sender, EventArgs e)
        ////{
        ////    HideTextEditor();
        ////}
        ////private void TxtEdit_KeyUp(object sender, KeyEventArgs e)
        ////{
        ////    if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Return)
        ////        HideTextEditor();
        ////}
        ////private void HideTextEditor()
        ////{
        ////    TxtEdit.Visible = false;
        ////    if (SelectedLSI != null)
        ////        SelectedLSI.Text = TxtEdit.Text;
        ////    SelectedLSI = null;
        ////    TxtEdit.Text = "";
        ////}

        ////public class TestListView : System.Windows.Forms.ListView
        ////{
        ////    private const int WM_HSCROLL = 0x114;
        ////    private const int WM_VSCROLL = 0x115;
        ////    public event EventHandler Scroll;

        ////    protected void OnScroll()
        ////    {

        ////        if (this.Scroll != null)
        ////            this.Scroll(this, EventArgs.Empty);

        ////    }

        ////    protected override void WndProc(ref System.Windows.Forms.Message m)
        ////    {
        ////        base.WndProc(ref m);
        ////        if (m.Msg == WM_HSCROLL || m.Msg == WM_VSCROLL)
        ////            this.OnScroll();
        ////    }
        ////}


    }
}
