﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TenderTrackingSystem;

namespace MDI_ParenrForm
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DAL dal = new DAL();
            DataTable dt = dal.GetDataFromDB("CONTRACTORS", "SELECT WorkOrders.workOrderID,CONTRACTORS.co_id,CONTRACTORS.proj_id,CONTRACTORS.ContractAmount, CONTRACTORS.cp_tender_award,CONTRACTORS.create_date,CONTRACTORS.create_user,CONTRACTORS.cp_received_of_doc,CONTRACTORS.cp_request_start_date," +
                "CONTRACTORS.cp_start_date_receive,CONTRACTORS.cp_notice_contractor_to_sign,CONTRACTORS.cp_due_date_pb,CONTRACTORS.cp_sent_dep_sign,CONTRACTORS.cp_receive_dep_sent_prsd,CONTRACTORS.cp_sent_fd_commit,CONTRACTORS.cp_receive_fd_commit, CONTRACTORS.cp_distribution,CONTRACTORS.cp_contractor_sign, " +
                         "CONTRACTORS.contract_no,CONTRACTORS.remarks,"+
                         "CONTRACTORS.update_date_pc, CONTRACTORS.update_user_pc FROM CONTRACTORS INNER JOIN WorkOrders ON CONTRACTORS.bidder_id = WorkOrders.bidder_Id " +
                         "WHERE (CONTRACTORS.stage_Id = 6)");

            //DataTable dt = dal.GetDataFromDB("CONTRACTORS", "SELECT DISTINCT CONTRACTORS.co_id,WorkOrderSubmissions.bidder_id,WorkOrderSubmissions.workOrderSubmissionID FROM WorkOrderSubmissions INNER JOIN " +
            //"CONTRACTORS ON WorkOrderSubmissions.bidder_id = CONTRACTORS.bidder_id");

            short sCounter = 0;
            using (SqlConnection sqlConn = new SqlConnection(ConfigurationSettings.AppSettings["TCMSConnString"].ToString())) //"Data Source=EBSD-VPUCHNANDA\\SQLEXPRESS08;Initial Catalog=TCMSNew;User ID=sa;Password=Sa08@123"
            {
                sqlConn.Open();
                //int dateId = comCls.GetMaxInfo("select MAX(date_id) from TenderDatesInfo",'Y');
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlConn;
                    while (sCounter < dt.Rows.Count)
                    {

                        //int empId = comCls.ExecuteReaderQuery("SELECT employee_id FROM Contacts WHERE (co_id =" + dt.Rows[sCounter][1] + ")", sqlConn);



                        //if (sCounter == 0)
                        //object startDate =null;
                        //if (dt.Rows[sCounter][6].ToString() != "")
                        //    startDate = Convert.ToDateTimedt.Rows[sCounter][6].ToString();
                        //else
                        //    startDate = DBNull.Value;
                        //string woContractAmt = null;

                        //cmd.CommandText = @"update WorkOrderSubmissions set co_Id=@coId where workOrderSubmissionID=" + dt.Rows[sCounter][2];
                        //cmd.Parameters.AddWithValue("@coId", dt.Rows[sCounter][0].ToString());
                        cmd.Parameters.Clear();
                        cmd.CommandText = @"update WorkOrders set woAwardDate=@woAwardDate where workOrderID=@workOrderID";
                        cmd.Parameters.AddWithValue("@workOrderID", dt.Rows[sCounter][0]);
                        cmd.Parameters.AddWithValue("@woAwardDate", dt.Rows[sCounter][4]);
                        int exInserted = cmd.ExecuteNonQuery();

//                        cmd.CommandText = @"select workOrderBidderID from WorkOrderSuccessfulBidders where workOrderID=@workOrderID";
//                        cmd.Parameters.AddWithValue("@workOrderID", dt.Rows[sCounter][0]);
//                        SqlDataReader sqlDtReader = cmd.ExecuteReader();
//                        if (!sqlDtReader.HasRows)
//                        {
//                            sqlDtReader.Close();
//                            cmd.Parameters.Clear();
//                            cmd.CommandText = @"insert into WorkOrderSuccessfulBidders (co_id,proj_id,woContractAmount,woAwardDate,create_user,create_date,workOrderID,cp_received_of_doc,
//                            cp_request_start_date,cp_start_date_receive,cp_notice_contractor_to_sign,cp_due_date_pb,cp_sent_dep_sign,cp_receive_dep_sent_prsd,cp_sent_fd_commit,cp_receive_fd_commit,cp_distribution,cp_contractor_sign,
//                            contract_no,remarks,update_date,update_user) values(@coId,@projId,@woContractAmount,@woAwardDate,@createUser,@createDate,@workOrderID,@cp_received_of_doc," +
//                            "@cp_request_start_date,@cp_start_date_receive,@cp_notice_contractor_to_sign,@cp_due_date_pb,@cp_sent_dep_sign,@cp_receive_dep_sent_prsd,@cp_sent_fd_commit,@cp_receive_fd_commit,@cp_distribution,@cp_contractor_sign," +
//                            "@contract_no,@remarks,@updateDate,@updateUser)";
//                            if (dt.Rows[sCounter][1].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@coId", dt.Rows[sCounter][1].ToString());
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@coId", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][2].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@projId", dt.Rows[sCounter][2].ToString());
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@projId", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][3].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@woContractAmount", dt.Rows[sCounter][3].ToString());
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@woContractAmount", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][4].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@woAwardDate", Convert.ToDateTime(dt.Rows[sCounter][4]).ToString("dd/MMM/yyyy HH:mm:ss"));
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@woAwardDate", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][5].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@createDate", Convert.ToDateTime(dt.Rows[sCounter][5]).ToString("dd/MMM/yyyy HH:mm:ss"));
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@createDate", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][6].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@createUser", dt.Rows[sCounter][6].ToString());
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@createUser", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][0].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@workOrderID", dt.Rows[sCounter][0].ToString());
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@workOrderID", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][7].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@cp_received_of_doc", Convert.ToDateTime(dt.Rows[sCounter][7]).ToString("dd/MMM/yyyy HH:mm:ss"));
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@cp_received_of_doc", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][8].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@cp_request_start_date", Convert.ToDateTime(dt.Rows[sCounter][8]).ToString("dd/MMM/yyyy HH:mm:ss"));
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@cp_request_start_date", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][9].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@cp_start_date_receive", Convert.ToDateTime(dt.Rows[sCounter][9]).ToString("dd/MMM/yyyy HH:mm:ss"));
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@cp_start_date_receive", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][10].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@cp_notice_contractor_to_sign", Convert.ToDateTime(dt.Rows[sCounter][10]).ToString("dd/MMM/yyyy HH:mm:ss"));
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@cp_notice_contractor_to_sign", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][11].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@cp_due_date_pb", Convert.ToDateTime(dt.Rows[sCounter][11]).ToString("dd/MMM/yyyy HH:mm:ss"));
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@cp_due_date_pb", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][12].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@cp_sent_dep_sign", Convert.ToDateTime(dt.Rows[sCounter][12]).ToString("dd/MMM/yyyy HH:mm:ss"));
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@cp_sent_dep_sign", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][13].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@cp_receive_dep_sent_prsd", Convert.ToDateTime(dt.Rows[sCounter][13]).ToString("dd/MMM/yyyy HH:mm:ss"));
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@cp_receive_dep_sent_prsd", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][14].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@cp_sent_fd_commit", Convert.ToDateTime(dt.Rows[sCounter][14]).ToString("dd/MMM/yyyy HH:mm:ss"));
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@cp_sent_fd_commit", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][15].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@cp_receive_fd_commit", Convert.ToDateTime(dt.Rows[sCounter][15]).ToString("dd/MMM/yyyy HH:mm:ss"));
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@cp_receive_fd_commit", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][16].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@cp_distribution", Convert.ToDateTime(dt.Rows[sCounter][16]).ToString("dd/MMM/yyyy HH:mm:ss"));
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@cp_distribution", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][17].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@cp_contractor_sign", Convert.ToDateTime(dt.Rows[sCounter][17]).ToString("dd/MMM/yyyy HH:mm:ss"));
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@cp_contractor_sign", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][18].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@contract_no", dt.Rows[sCounter][18].ToString());
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@contract_no", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][19].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@remarks", dt.Rows[sCounter][19].ToString());
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@remarks", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][20].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@updateDate", Convert.ToDateTime(dt.Rows[sCounter][20]).ToString("dd/MMM/yyyy HH:mm:ss"));
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@updateDate", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][21].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@updateUser", dt.Rows[sCounter][21].ToString());
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@updateUser", DBNull.Value);
//                            }
                            
//                            int exInserted = cmd.ExecuteNonQuery();
                            
//                        }
//                        else
//                        {
//                            sqlDtReader.Close();
//                            cmd.Parameters.Clear();
//                            cmd.CommandText = @"update WorkOrderSuccessfulBidders set co_id=@coId,proj_id=@projId,woContractAmount=@woContractAmount,woAwardDate=@woAwardDate,create_user=@createUser,create_date=@createDate,cp_received_of_doc=@cp_received_of_doc, 
//                            cp_request_start_date=@cp_request_start_date,cp_start_date_receive=@cp_start_date_receive,cp_notice_contractor_to_sign=@cp_notice_contractor_to_sign,cp_due_date_pb=@cp_due_date_pb,cp_sent_dep_sign=@cp_sent_dep_sign,cp_receive_dep_sent_prsd=@cp_receive_dep_sent_prsd,
//                            cp_sent_fd_commit=@cp_sent_fd_commit,cp_receive_fd_commit=@cp_receive_fd_commit,cp_distribution=@cp_distribution,cp_contractor_sign=@cp_contractor_sign,contract_no=@contract_no,remarks=@remarks,update_date=@updateDate," +
//                            "update_user=@updateUser where workOrderID=@workOrderID"; // +dt.Rows[sCounter][0];

////                            cmd.CommandText = @"insert into WorkOrderSuccessfulBidders (,,,,,,workOrderID,cp_received_of_doc,
////                            cp_request_start_date,cp_start_date_receive,cp_notice_contractor_to_sign,cp_due_date_pb,cp_sent_dep_sign,cp_receive_dep_sent_prsd,cp_sent_fd_commit,cp_receive_fd_commit,cp_distribution,cp_contractor_sign,
////                            contract_no,remarks,update_date,update_user) values(,,,@woAwardDate,,,@workOrderID,@cp_received_of_doc," +
////                            "@cp_request_start_date,@cp_start_date_receive,@cp_notice_contractor_to_sign,@cp_due_date_pb,@cp_sent_dep_sign,@cp_receive_dep_sent_prsd,@cp_sent_fd_commit,@cp_receive_fd_commit,@cp_distribution,@cp_contractor_sign," +
////                            "@contract_no,@remarks,@updateDate,@updateUser)";
//                            if (dt.Rows[sCounter][1].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@coId", dt.Rows[sCounter][1].ToString());
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@coId", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][2].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@projId", dt.Rows[sCounter][2].ToString());
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@projId", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][3].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@woContractAmount", dt.Rows[sCounter][3].ToString());
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@woContractAmount", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][4].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@woAwardDate", Convert.ToDateTime(dt.Rows[sCounter][4]).ToString("dd/MMM/yyyy HH:mm:ss"));
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@woAwardDate", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][5].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@createDate", Convert.ToDateTime(dt.Rows[sCounter][5]).ToString("dd/MMM/yyyy HH:mm:ss"));
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@createDate", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][6].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@createUser", dt.Rows[sCounter][6].ToString());
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@createUser", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][0].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@workOrderID", dt.Rows[sCounter][0].ToString());
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@workOrderID", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][7].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@cp_received_of_doc", Convert.ToDateTime(dt.Rows[sCounter][7]).ToString("dd/MMM/yyyy HH:mm:ss"));
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@cp_received_of_doc", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][8].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@cp_request_start_date", Convert.ToDateTime(dt.Rows[sCounter][8]).ToString("dd/MMM/yyyy HH:mm:ss"));
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@cp_request_start_date", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][9].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@cp_start_date_receive", Convert.ToDateTime(dt.Rows[sCounter][9]).ToString("dd/MMM/yyyy HH:mm:ss"));
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@cp_start_date_receive", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][10].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@cp_notice_contractor_to_sign", Convert.ToDateTime(dt.Rows[sCounter][10]).ToString("dd/MMM/yyyy HH:mm:ss"));
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@cp_notice_contractor_to_sign", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][11].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@cp_due_date_pb", Convert.ToDateTime(dt.Rows[sCounter][11]).ToString("dd/MMM/yyyy HH:mm:ss"));
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@cp_due_date_pb", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][12].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@cp_sent_dep_sign", Convert.ToDateTime(dt.Rows[sCounter][12]).ToString("dd/MMM/yyyy HH:mm:ss"));
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@cp_sent_dep_sign", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][13].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@cp_receive_dep_sent_prsd", Convert.ToDateTime(dt.Rows[sCounter][13]).ToString("dd/MMM/yyyy HH:mm:ss"));
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@cp_receive_dep_sent_prsd", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][14].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@cp_sent_fd_commit", Convert.ToDateTime(dt.Rows[sCounter][14]).ToString("dd/MMM/yyyy HH:mm:ss"));
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@cp_sent_fd_commit", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][15].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@cp_receive_fd_commit", Convert.ToDateTime(dt.Rows[sCounter][15]).ToString("dd/MMM/yyyy HH:mm:ss"));
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@cp_receive_fd_commit", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][16].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@cp_distribution", Convert.ToDateTime(dt.Rows[sCounter][16]).ToString("dd/MMM/yyyy HH:mm:ss"));
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@cp_distribution", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][17].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@cp_contractor_sign", Convert.ToDateTime(dt.Rows[sCounter][17]).ToString("dd/MMM/yyyy HH:mm:ss"));
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@cp_contractor_sign", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][18].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@contract_no", dt.Rows[sCounter][18].ToString());
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@contract_no", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][19].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@remarks", dt.Rows[sCounter][19].ToString());
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@remarks", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][20].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@updateDate", Convert.ToDateTime(dt.Rows[sCounter][20]).ToString("dd/MMM/yyyy HH:mm:ss"));
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@updateDate", DBNull.Value);
//                            }
//                            if (dt.Rows[sCounter][21].ToString() != "")
//                            {
//                                cmd.Parameters.AddWithValue("@updateUser", dt.Rows[sCounter][21].ToString());
//                            }
//                            else
//                            {
//                                cmd.Parameters.AddWithValue("@updateUser", DBNull.Value);
//                            }

//                            int exInserted = cmd.ExecuteNonQuery();

                            
//                        }
                      
                        sCounter++;




                    }
                }
                sqlConn.Close();
            }
        }
    }
}
