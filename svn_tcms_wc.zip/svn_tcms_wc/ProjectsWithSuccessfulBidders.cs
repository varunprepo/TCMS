﻿using MDI_ParenrForm.Projects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TenderTrackingSystem;

namespace MDI_ParenrForm
{
    public partial class ProjectsWithSuccessfulBidders : Form
    {
        IList<string> _userRightsColl = null;
        private string connStr = ConfigurationManager.AppSettings["TCMSConnString"].ToString();
        SqlConnection sqlConn = null;
        string _userName = null;
        //bool _isHeadOfSection = false; // Added by Varun on 11/Jun/15         
        string _profileName = null;
        string whereClause = null;
        string whereClauseForFilter = null;
        CommonClass comCls = null;
        string mAffairShortName = null;
        string mCommitteeShortName = null;
        DataTable dtTemp = null;
        Int16 id1 = 1;
        Int16 id2 = 25;
        private string NavClicked = "";
        int CurrentPage = 1;
        bool _isHeadOfSection = false;

        public ProjectsWithSuccessfulBidders(IList<string> userRightsColl, bool isHeadOfSection, string committeeShortName, string affairShortName, string userName, string whereClause, string profileName)
        {
            InitializeComponent();
            _userName = userName;
            _profileName = profileName;
            mAffairShortName = affairShortName;
            mCommitteeShortName = committeeShortName;
            _isHeadOfSection = isHeadOfSection;
            _userRightsColl = userRightsColl;
            comCls = new CommonClass(userName);
            sqlConn = new SqlConnection();
            //rdoBtnSearchDate.Checked = true;
            //grpDateSearchBox.Enabled = true;
            //grpYearSearchBox.Enabled = false;
            //rdoBtnSearchYear.Checked = false;
            //rdoBtnLastModSearchDate.Checked = true;
            //grpLastDateSearchBox.Enabled = true;
            //rdoBtnLastModSearchYear.Checked = false;
            //grpLastYearSearchBox.Enabled = false;
            whereClause = SetWhereClause(userRightsColl);
            FillCombo(whereClause);
            DAL dal = new DAL();
            //dal.populateCmbBox("Select FYID,[FiscalYear] From [FiscalYear] Order by FYID DESC", cmbCreateYear);  //Fiscal_Year
            //cmbCreateYear.SelectedIndex = -1;
            //dal.populateCmbBox("Select FYID,[FiscalYear] From [FiscalYear] Order by FYID DESC", cmbModifiedYear);  //Fiscal_Year
            //cmbModifiedYear.SelectedIndex = -1;
            FillAllProjectsInformation(' ');
        }
        

        private string SetWhereClause(IList<string> userRightsColl)
        {
            string whereClause = "";
            if (userRightsColl.Count !=0)
            {
                whereClause = comCls.CheckAccessRightsForTenderNoYear(userRightsColl);
                if (whereClause != "")
                {
                    whereClause = whereClause.Substring(4);
                }
                else
                {
                    whereClause = "";
                }   

                //if (!userRightsColl.Contains("104"))
                //{
                    
                //    //whereClause = comCls.CheckAccessRightsForTenderNoYear(userRightsColl);
                //    //DataTable dtProjIds = comCls.GetDataTable("SELECT PROJECTS.proj_id FROM PROJECTS INNER JOIN TenderDatesInfo ON TenderDatesInfo.proj_id = PROJECTS.proj_id WHERE (TenderDatesInfo.stage_id = 2) " +
                //    //"AND (TenderDatesInfo.ts_tender_issue IS NULL) AND (ISNULL(CAST(TenderDatesInfo.ts_modified_closing AS Date), " +
                //    //"CAST(TenderDatesInfo.ts_closing_s1 AS Date)) >= CAST('" + DateTime.Now.Date.ToString().Split(' ')[0] + "' As Date)) AND (PROJECTS.isDeleted=0) and PROJECTS.Tender_Status_id<>10", sqlConn);

                //    whereClause = (comCls.CheckAccessRightsForTenderNoYear(userRightsColl) + " AND p.proj_id not IN (SELECT PROJECTS.proj_id FROM PROJECTS INNER JOIN TenderDatesInfo ON TenderDatesInfo.proj_id = PROJECTS.proj_id WHERE (TenderDatesInfo.stage_id = 2) " +
                //    "AND (TenderDatesInfo.ts_tender_issue IS NULL) AND (ISNULL(CAST(TenderDatesInfo.ts_modified_closing AS Date), " +
                //    "CAST(TenderDatesInfo.ts_closing_s1 AS Date)) >= CAST('" + DateTime.Now.Date.ToString().Split(' ')[0] + "' As Date)) AND (PROJECTS.isDeleted=0) and PROJECTS.Tender_Status_id<>10)").Substring(4);

                //    //if (dtProjIds.Rows.Count != 0)
                //    //{
                //    //    whereClause = whereClause + " AND p.proj_id not IN (" + string.Join(",", dtProjIds.AsEnumerable().Select(x => x.Field<string>("proj_id").ToArray())) + ")".Substring(4);
                //    //}
                //    //else
                //    //{
                //    //    whereClause = whereClause.Substring(4);
                //    //}
                    
                //}
                //else
                //{
                //    whereClause = comCls.CheckAccessRightsForTenderNoYear(userRightsColl);
                //    if (whereClause != "")
                //    {
                //        whereClause = whereClause.Substring(4);
                //    }                     
                //}
            }
            else
            {
                whereClause = "";
            }
            return whereClause;
        }

        private enum NavButton
        {
            First = 1,
            Next = 2,
            Previous = 3,
            Last = 4,
        }

        char cFilter = ' ';
        public char Filtered
        {
            get { return cFilter; }
            set { cFilter = value; }
        }

        static BindingSource myBindingSource = null;
        DataTable dtTempForCombo = null;

        
        private void filterCombo()
        {
            string filterQuery = "";

            if (cmbPrjCode.SelectedIndex != -1)
            {
                string projectCode = ((DataRowView)cmbPrjCode.SelectedItem).Row.ItemArray[0].ToString();
                if (filterQuery == "")
                {
                    filterQuery = "ProjectCode = '" + projectCode + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "ProjectCode = '" + projectCode + "'";
                }
            }
            else if (cmbPrjCode.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "ProjectCode like '%" + cmbPrjCode.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "ProjectCode like '%" + cmbPrjCode.Text + "%'";
                }
            }


            if (txtPrjTitle.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "ProjectTitle like '%" + txtPrjTitle.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "ProjectTitle like '%" + txtPrjTitle.Text + "%'";
                }
            }


            if (cmbTenderNo.SelectedIndex != -1)
            {
                string tenderNo = ((DataRowView)cmbTenderNo.SelectedItem).Row.ItemArray[0].ToString();
                if (filterQuery == "")
                {
                    if (cmbTenderNo.SelectedItem.ToString() == "")
                    {
                        filterQuery = "TenderNo = ''";
                    }
                    else
                    {
                        filterQuery = "TenderNo = '" + tenderNo + "'";
                    }
                }
                else
                {
                    if (tenderNo == "")
                    {
                        filterQuery = filterQuery + " and TenderNo = ''";
                    }
                    else
                    {
                        filterQuery = filterQuery + " and " + "TenderNo = '" + tenderNo + "'";
                    }

                }
            }
            else if (cmbTenderNo.Text != "")
            {
                string tenderNo = ((DataRowView)cmbTenderNo.SelectedItem).Row.ItemArray[0].ToString();
                if (filterQuery == "")
                {
                    filterQuery = "TenderNo like '%" + tenderNo + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "TenderNo like '%" + tenderNo + "%'";
                }
            }

            if (cmbFiscalYear.SelectedIndex != -1)
            {
                string fiscalYear = ((DataRowView)cmbFiscalYear.SelectedItem).Row.ItemArray[1].ToString();
                if (filterQuery == "")
                {
                    filterQuery = "FiscalYear = '" + fiscalYear + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "FiscalYear = '" + fiscalYear + "'";
                }
            }
            else if (cmbFiscalYear.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "FiscalYear like '%" + cmbFiscalYear.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "FiscalYear like '%" + cmbFiscalYear.Text + "%'";
                }
            }


            if (cmbTypeofContract.SelectedIndex != -1)
            {
                string typeofContract = ((DataRowView)cmbTypeofContract.SelectedItem).Row.ItemArray[0].ToString();
                if (filterQuery == "")
                {
                    filterQuery = "TypeofContract = '" + typeofContract + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "TypeofContract = '" + typeofContract + "'";
                }
            }
            else if (cmbTypeofContract.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "TypeofContract like '%" + cmbTypeofContract.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "TypeofContract like '%" + cmbTypeofContract.Text + "%'";
                }
            }

            if (cmbTenderCommittee.SelectedIndex != -1)
            {
                string tndrCommShort = ((DataRowView)cmbTenderCommittee.SelectedItem).Row.ItemArray[0].ToString();
                if (filterQuery == "")
                {
                    filterQuery = "TenderCommittee = '" + tndrCommShort + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "TenderCommittee = '" + tndrCommShort + "'";
                }

            }
            else if (cmbTenderCommittee.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "TenderCommittee like '%" + cmbTenderCommittee.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "TenderCommittee like '%" + cmbTenderCommittee.Text + "%'";
                }
            }
            if (cmbTypeOftender.SelectedIndex != -1)
            {
                string typeOftender = ((DataRowView)cmbTypeOftender.SelectedItem).Row.ItemArray[0].ToString();
                if (filterQuery == "")
                {
                    filterQuery = "TypeOfTender = '" + typeOftender + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "TypeOfTender = '" + typeOftender + "'";
                }
            }
            else if (cmbTypeOftender.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "TypeOfTender like '%" + cmbTypeOftender.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "TypeOfTender like '%" + cmbTypeOftender.Text + "%'";
                }
            }
            if (cmbTenderStatus.SelectedIndex != -1)
            {
                string tenderStatus = ((DataRowView)cmbTenderStatus.SelectedItem).Row.ItemArray[0].ToString();
                if (filterQuery == "")
                {
                    filterQuery = "TenderStatus = '" + tenderStatus + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "TenderStatus = '" + tenderStatus + "'";
                }
            }
            else if (cmbTenderStatus.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "TenderStatus like '%" + cmbTenderStatus.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "TenderStatus like '%" + cmbTenderStatus.Text + "%'";
                }
            }
            //DataRowView cmbCurrentStageView = (DataRowView)cmbCurrentStage.SelectedItem;
            if (cmbCurrentStage.SelectedIndex != -1)
            {
                string currentStage = ((DataRowView)cmbCurrentStage.SelectedItem).Row.ItemArray[0].ToString();
                if (cmbCurrentStage.SelectedItem.Equals("Contracts Process"))
                {
                    if (filterQuery == "")
                    {
                        filterQuery = "CurrentStage = '" + currentStage + "' and TenderStatus<>'Cancelled' and TenderStatus<>'Committed'";
                    }
                    else
                    {
                        filterQuery = filterQuery + " and " + "CurrentStage = '" + currentStage + "' and TenderStatus<>'Cancelled' and TenderStatus<>'Committed'";
                    }
                }
                else
                {
                    if (filterQuery == "")
                    {
                        filterQuery = "CurrentStage = '" + currentStage + "' and TenderStatus<>'Cancelled'";
                    }
                    else
                    {
                        filterQuery = filterQuery + " and " + "CurrentStage = '" + currentStage + "' and TenderStatus<>'Cancelled'";
                    }
                }
            }
            else if (cmbCurrentStage.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "CurrentStage like '%" + cmbCurrentStage.Text + "%' and TenderStatus<>'Cancelled'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "CurrentStage like '%" + cmbCurrentStage.Text + "%' and TenderStatus<>'Cancelled'";
                }
            }

            if (cmbUserDepart.SelectedIndex != -1)
            {
                string userDepart = ((DataRowView)cmbUserDepart.SelectedItem).Row.ItemArray[1].ToString();
                if (filterQuery == "")
                {
                    filterQuery = "UserDepartment = '" + userDepart + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "UserDepartment = '" + userDepart + "'";
                }
            }
            else if (cmbUserDepart.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "UserDepartment like '%" + cmbUserDepart.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "UserDepartment like '%" + cmbUserDepart.Text + "%'";
                }
            }


            // Newely Added on Nov 20th 2013 for AiisheNed Qs 
            if (cmbQs.SelectedIndex != -1)
            {
                string qs = ((DataRowView)cmbQs.SelectedItem).Row.ItemArray[0].ToString();
                if (filterQuery == "")
                {
                    filterQuery = "Qs = '" + qs + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "Qs = '" + qs + "'";
                }
            }
            else if (cmbQs.Text != "")
            {

                if (filterQuery == "")
                {
                    filterQuery = "Qs like '%" + cmbQs.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "Qs like '%" + cmbQs.Text + "%'";
                }
            }


            if (cmbTndrHndl.SelectedIndex != -1)
            {
                string tndrHndl = ((DataRowView)cmbTndrHndl.SelectedItem).Row.ItemArray[0].ToString();
                if (filterQuery == "")
                {
                    filterQuery = "TndrHndl = '" + tndrHndl + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "TndrHndl = '" + tndrHndl + "'";
                }
            }
            else if (cmbTndrHndl.Text != "")
            {

                if (filterQuery == "")
                {
                    filterQuery = "TndrHndl like '%" + cmbTndrHndl.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "TndrHndl like '%" + cmbTndrHndl.Text + "%'";
                }
            }

            if (cmbStaff.SelectedIndex != -1)
            {
                string staff = ((DataRowView)cmbStaff.SelectedItem).Row.ItemArray[0].ToString();
                if (filterQuery == "")
                {
                    filterQuery = "Staff = '" + staff + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "Staff = '" + staff + "'";
                }
            }
            else if (cmbStaff.Text != "")
            {

                if (filterQuery == "")
                {
                    filterQuery = "Staff like '%" + cmbStaff.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "Staff like '%" + cmbStaff.Text + "%'";
                }
            }
            if (cmbMozanahID.SelectedIndex != -1)
            {
                string mozanahID = ((DataRowView)cmbMozanahID.SelectedItem).Row.ItemArray[0].ToString();
                if (filterQuery == "")
                {
                    filterQuery = "MozanahID = '" + mozanahID + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "MozanahID = '" + mozanahID + "'";
                }
            }
            else if (cmbMozanahID.Text != "")
            {

                if (filterQuery == "")
                {
                    filterQuery = "MozanahID like '%" + cmbMozanahID.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "MozanahID like '%" + cmbMozanahID.Text + "%'";
                }
            }

            if (cmbContractNo.SelectedIndex != -1)
            {
                string contractNo = ((DataRowView)cmbContractNo.SelectedItem).Row.ItemArray[0].ToString();
                if (filterQuery == "")
                {
                    filterQuery = "[ContractNoWorkOrderNo] like '%" + contractNo + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "[ContractNoWorkOrderNo] like '%" + contractNo + "%'";
                }

            }
            else if (cmbContractNo.Text != "")
            {
                if (filterQuery == "")
                {
                    if (cmbContractNo.SelectedValue != null)
                    {
                        filterQuery = "[ContractNoWorkOrderNo] ='" + cmbContractNo.SelectedValue + "'";
                    }
                    else
                    {
                        filterQuery = "[ContractNoWorkOrderNo] like '%" + cmbContractNo.Text + "%'";
                    }
                }
                else
                {
                    if (cmbContractNo.SelectedValue != null)
                    {
                        filterQuery = filterQuery + " and " + "[ContractNoWorkOrderNo] = '" + cmbContractNo.SelectedValue + "'";
                    }
                    else
                    {
                        filterQuery = filterQuery + " and " + "[ContractNoWorkOrderNo] like '%" + cmbContractNo.Text + "%'";
                    }
                }

            }   

            if (filterQuery == "")
            {
                GridFill("");
            }
            else
            {
                GridFill(filterQuery);
            }
        }

        //private string SqlQuery()
        //{
        //    string sqlQuery = ;
        //    return sqlQuery;
        //}
        
        static DataTable dtUniqueProjects = new DataTable();
        private void FillAllProjectsInformation(char chkInfo)
        {
            Cursor = Cursors.WaitCursor;

            if (chkInfo == 'R')
            {
                txtPrjTitle.Text = "";
                cmbPrjCode.Text = "";
                cmbTenderNo.Text = "";
                cmbPrjCode.SelectedIndex = -1;
                cmbTenderNo.SelectedIndex = -1;
                cmbCurrentStage.SelectedIndex = -1;
                cmbTenderStatus.SelectedIndex = -1;
                cmbTypeOftender.SelectedIndex = -1;
                cmbTenderCommittee.SelectedIndex = -1;
                cmbTypeofContract.SelectedIndex = -1;
                cmbContractNo.SelectedIndex = -1;
                cmbContractNo.Text = "";
                cmbFiscalYear.SelectedIndex = -1;
                cmbUserDepart.SelectedIndex = -1;
                dtTempForCombo = null;                 
            }

            if (dgView.ColumnCount == 0)
            {
                var col0 = new DataGridViewCheckBoxColumn();
                var col1 = new DataGridViewTextBoxColumn();
                var col2 = new DataGridViewLinkColumn();
                var col3 = new DataGridViewTextBoxColumn();
                var col4 = new DataGridViewTextBoxColumn();
                var col5 = new DataGridViewTextBoxColumn();
                var col6 = new DataGridViewTextBoxColumn();
                var col7 = new DataGridViewTextBoxColumn();
                var col8 = new DataGridViewTextBoxColumn();
                var col9 = new DataGridViewTextBoxColumn();
                var col10 = new DataGridViewTextBoxColumn();
                var col11 = new DataGridViewTextBoxColumn();
                var col12 = new DataGridViewTextBoxColumn();               
                var col15 = new DataGridViewTextBoxColumn();
                var col16 = new DataGridViewTextBoxColumn();               
                var col18 = new DataGridViewTextBoxColumn();
                 
                           
                dgView.Columns.AddRange(new DataGridViewColumn[] { col0, col1, col2, col3, col4, col5, col6, col7, col8, col9, col10, col18, col11, col12, col15,col16 });

                dgView.AutoGenerateColumns = false;
                dgView.AllowUserToAddRows = false;
                dgView.AutoResizeColumns();

                col0.DataPropertyName = "";
                col0.Width = 1;

                col1.DataPropertyName = "Proj_Id";
                col1.HeaderText = "ProjectId";
                col1.Width = 1;

                col2.DataPropertyName = "ProjectCode";
                col2.HeaderText = "Project Code";
                col2.Width = 12;
                col2.LinkBehavior = LinkBehavior.NeverUnderline;

                col3.DataPropertyName = "ProjectTitle";
                col3.HeaderText = "ProjectTitle";
                col3.Width = 20;

                col4.DataPropertyName = "TenderNo";
                col4.HeaderText = "TenderNo";
                col4.Width = 10;

                col5.DataPropertyName = "CurrentStage";
                col5.HeaderText = "Current Stage";
                col5.Width = 7;

                col6.DataPropertyName = "TenderStatus";
                col6.HeaderText = "Tender Status";
                col6.Width = 5;

                col7.DataPropertyName = "TypeOfTender";
                col7.HeaderText = "Tender Type";
                col7.Width = 5;

                col8.DataPropertyName = "TenderCommittee";
                col8.HeaderText = "Tender Committee";
                col8.Width = 3;

                col9.DataPropertyName = "TypeofContract";
                col9.HeaderText = "Contract Type";
                col9.Width = 5;

                col10.DataPropertyName = "ContractNoWorkOrderNo";
                col10.HeaderText = "ContractNoWorkOrderNo";
                col10.Width = 11;

                col18.DataPropertyName = "SuccessfulBidder";
                col18.HeaderText = "Successful Bidder";
                col18.Width = 10;

                col11.DataPropertyName = "FiscalYear";
                col11.HeaderText = "Fiscal Year";
                col11.Width = 5;

                col12.DataPropertyName = "Department";
                col12.HeaderText = "User Department";
                col12.Width = 10;

                col15.DataPropertyName = "MozanahID";
                col15.HeaderText = "Mozanah ID";
                col15.Width = 13;

                col16.DataPropertyName = "ID";
                col16.HeaderText = "ID";
                col16.Width = 1;

                //col17.DataPropertyName = "FYID";
                //col17.HeaderText = "FYID";
                //col17.Width = 1;              
            }
            else
            {
                dgView.DataSource = null;
                dgView.Refresh();
            }

            foreach (DataGridViewColumn c in dgView.Columns)
            {
                c.DefaultCellStyle.Font = new Font("Calibri (Body)", 11F, GraphicsUnit.Pixel);
            }

            //DataTable dtProject = null;
            string[] projRows = new string[8];

            try
            {
                
                DAL dalObj = new DAL(); //Dharan
                if (dtTempForCombo == null)
                {
                    StringBuilder sqlBuildQuery = new StringBuilder();
                    if (whereClauseForFilter != null)
                    {
                        whereClause = whereClauseForFilter;
                    }

                    //IEnumerable<object> iEnum = null;


                    //DataTable dtAffairs = null;
                    DataTable dtSuccessfulBidders = null;                     
                    //DataTable dtStages = dalObj.GetDataFromDB("STAGES", "SELECT stage_id,Stage_Name from STAGES");
                    //DataTable dtDepartment1 = dalObj.GetDataFromDB("Department", "SELECT department_id,Department,newDepID from Department2");
                    //DataTable dtDepartment2 = dalObj.GetDataFromDB("Department1", "SELECT department_id,Department,newDepID from Department2");
                    //DataTable dtTenderTypes = dalObj.GetDataFromDB("TenderTypes", "SELECT tender_type_id,tender_type_name from TenderTypes");
                    //DataTable dtTenderStatus = dalObj.GetDataFromDB("TenderStatus", "SELECT Tender_Status_id,Status_Name from TenderStatus");
                    //DataTable dtCommittee = null;
                    //DataTable dtFiscalYear = dalObj.GetDataFromDB("FiscalYear", "SELECT FYID,FiscalYear from FiscalYear");
                    //DataTable dtContractTypes = dalObj.GetDataFromDB("ContractTypes", "SELECT contract_type_id,TypeofContract from ContractTypes");
                    //DataTable dtCompany = dalObj.GetDataFromDB("Company", "SELECT co_id,co_name from Company");
                    //DataTable dtTenderDatesInfo = dalObj.GetDataFromDB("TenderDatesInfo", "SELECT proj_id,co_id,co_name from TenderDatesInfo");

                    if (whereClause != null && whereClause!="")
                    {
                        dtSuccessfulBidders = dalObj.GetDataFromDB("SuccessfulBidders", "SELECT '',p.proj_id,p.project_code As ProjectCode,replace(p.project_newname_en,',','|') as ProjectTitle,p.tender_no As TenderNo, " +
                        "STAGES.Stage_Name As CurrentStage, TenderStatus.Status_Name As TenderStatus, TenderTypes.tender_type_name As TypeOfTender,Committee.committee_short_name As TenderCommittee, ContractTypes.TypeofContract, FiscalYear.FiscalYear, dp2.Department," +
                        "COALESCE (ctr.contract_no,'')+'|'+COALESCE(wosb.contract_no,'') + '-' + COALESCE (wo.workOrderNo, '') AS ContractNoWorkOrderNo,COMPANY.co_name as SuccessfulBidder, p.moazanah_proj_id_new As MozanahID, p.ptd_assign_qs As QS," +
                        "p.ts_issue_handling As TndrHndl, p.StaffInCharge As Staff,p.dummyfield,ROW_NUMBER() OVER(ORDER BY p.dummyfield Desc) AS ID FROM COMPANY inner JOIN CONTRACTORS As ctr ON COMPANY.co_id = ctr.co_id right outer JOIN PROJECTS p on ctr.proj_id = p.proj_id left outer JOIN WorkOrders AS wo ON " +
                        "wo.bidder_Id = ctr.bidder_id left outer join WorkOrderSuccessfulBidders as wosb on wosb.proj_id=p.proj_id JOIN AFFAIRS2 ON AFFAIRS2.Affair_id = p.Affair_id INNER JOIN Department2 dp2 ON p.department_id = dp2.department_id JOIN " +
                        "STAGES ON STAGES.stage_id = p.stage_id INNER JOIN TenderTypes ON TenderTypes.tender_type_id = p.tender_type_id JOIN ContractTypes ON ContractTypes.contract_type_id = p.contract_type_id JOIN FiscalYear ON FiscalYear.FYID = p.FYID Join " +
                        "Committee ON Committee.committee_id = p.committee_id JOIN TenderStatus ON TenderStatus.Tender_Status_id = p.Tender_Status_id WHERE (p.Tender_Status_id <> 10) AND (p.Tender_Status_id <> 9) AND (p.Tender_Status_id <> 17) AND (p.isDeleted = 0) and p.stage_id in (4,6) and (p.isDeleted=0) and (ctr.contract_no not like '%Framework%' and " +
                        "ctr.contract_no not like '%Workorder%') and (ctr.contract_no<>NULL or ctr.contract_no<>' ') and " + whereClause + " order by p.dummyfield Desc");                         
                    }
                    else
                    {
                        dtSuccessfulBidders = dalObj.GetDataFromDB("SuccessfulBidders", "SELECT '',p.proj_id,p.project_code As ProjectCode,replace(p.project_newname_en,',','|') as ProjectTitle,p.tender_no As TenderNo, " +
                        "STAGES.Stage_Name As CurrentStage, TenderStatus.Status_Name As TenderStatus, TenderTypes.tender_type_name As TypeOfTender,Committee.committee_short_name As TenderCommittee, ContractTypes.TypeofContract, FiscalYear.FiscalYear, dp2.Department," +
                        "COALESCE (ctr.contract_no, '') +'|'+COALESCE(wosb.contract_no,'') + '-' + COALESCE (wo.workOrderNo, '') AS ContractNoWorkOrderNo,COMPANY.co_name as SuccessfulBidder, p.moazanah_proj_id_new As MozanahID, p.ptd_assign_qs As QS," +
                        "p.ts_issue_handling As TndrHndl, p.StaffInCharge As Staff,p.dummyfield,ROW_NUMBER() OVER(ORDER BY p.dummyfield Desc) AS ID FROM COMPANY inner JOIN CONTRACTORS As ctr ON COMPANY.co_id = ctr.co_id right outer JOIN PROJECTS p on ctr.proj_id = p.proj_id left outer JOIN WorkOrders AS wo ON " +
                        "wo.bidder_Id = ctr.bidder_id left outer join WorkOrderSuccessfulBidders as wosb on wosb.proj_id=p.proj_id JOIN AFFAIRS2 ON AFFAIRS2.Affair_id = p.Affair_id INNER JOIN Department2 dp2 ON p.department_id = dp2.department_id JOIN " +
                        "STAGES ON STAGES.stage_id = p.stage_id INNER JOIN TenderTypes ON TenderTypes.tender_type_id = p.tender_type_id JOIN ContractTypes ON ContractTypes.contract_type_id = p.contract_type_id JOIN FiscalYear ON FiscalYear.FYID = p.FYID Join " +
                        "Committee ON Committee.committee_id = p.committee_id JOIN TenderStatus ON TenderStatus.Tender_Status_id = p.Tender_Status_id " +
                        "WHERE (p.Tender_Status_id <> 17) AND (p.isDeleted = 0) and p.stage_id in (4,6) and (p.isDeleted=0) and (ctr.contract_no not like '%Framework%' and " +
                        "ctr.contract_no not like '%Workorder%') and (ctr.contract_no<>NULL or ctr.contract_no<>' ') order by p.dummyfield Desc");                         
                    }

                    //if (!mCommitteeShortName.Contains("All") && mAffairShortName.Contains("All"))
                    //{
                    //    dtCommittee = dalObj.GetDataFromDB("Committee", "SELECT committee_id,committee_short_name from Committee WHERE committee_short_name in (" + mCommitteeShortName + ")");
                    //    dtAffairs = dalObj.GetDataFromDB("AFFAIRS", "SELECT Affair_id from AFFAIRS2");
                    //}
                    //else if (!mCommitteeShortName.Contains("All") && (!mAffairShortName.Contains("All") && mAffairShortName != ""))
                    //{
                    //    dtCommittee = dalObj.GetDataFromDB("Committee", "SELECT committee_id,committee_short_name from Committee where committee_short_name in (" + mCommitteeShortName + ")");
                    //    dtAffairs = dalObj.GetDataFromDB("AFFAIRS", "SELECT Affair_id from AFFAIRS2 where Affairs_Short_name in (" + mAffairShortName + ")");                         
                    //}
                    //else if (mCommitteeShortName.Contains("All") && (!mAffairShortName.Contains("All") && mAffairShortName != ""))
                    //{
                    //    dtCommittee = dalObj.GetDataFromDB("Committee", "SELECT committee_id,committee_short_name from Committee");
                    //    dtAffairs = dalObj.GetDataFromDB("AFFAIRS", "SELECT Affair_id from AFFAIRS2 where Affairs_Short_name in (" + mAffairShortName + ")");
                    //}
                    //else if (mCommitteeShortName.Contains("All") && (!mAffairShortName.Contains("All") && mAffairShortName != ""))
                    //{
                    //    dtCommittee = dalObj.GetDataFromDB("Committee", "SELECT committee_id,committee_short_name from Committee");
                    //    dtAffairs = dalObj.GetDataFromDB("AFFAIRS", "SELECT Affair_id from AFFAIRS2 where Affairs_Short_name in (" + mAffairShortName + ")");
                    //}
                    //else if (!mCommitteeShortName.Contains("All") && mAffairShortName == "")
                    //{
                    //    if (mCommitteeShortName != "")
                    //    {
                    //        dtCommittee = dalObj.GetDataFromDB("Committee", "SELECT committee_id,committee_short_name from Committee where ommittee_short_name in (" + mCommitteeShortName + ")");
                    //    }
                    //    else
                    //    {
                    //        dtCommittee = dalObj.GetDataFromDB("Committee", "SELECT committee_id,committee_short_name from Committee");
                    //    }
                    //    dtAffairs = dalObj.GetDataFromDB("AFFAIRS", "SELECT Affair_id from AFFAIRS2");
                    //}
                    //else
                    //{
                    //    dtCommittee = dalObj.GetDataFromDB("Committee", "SELECT committee_id,committee_short_name from Committee");
                    //    dtAffairs = dalObj.GetDataFromDB("AFFAIRS", "SELECT Affair_id from AFFAIRS2");
                    //}
                   
                    //iEnum = (from sufb in dtSuccessfulBidders.AsEnumerable()
                    //         join aff in dtAffairs.AsEnumerable() on sufb.Field<int>("Affair_id") equals aff.Field<int>("Affair_id")
                    //         join dpt in dtDepartment1.AsEnumerable() on sufb.Field<int>("department_id") equals dpt.Field<int>("department_id")
                    //         join dpt1 in dtDepartment2.AsEnumerable() on dpt.Field<Int16>("newDepID") equals dpt1.Field<int>("department_id")
                    //         join stg in dtStages.AsEnumerable() on sufb.Field<int>("stage_id") equals stg.Field<int>("stage_id")
                    //         join tt in dtTenderTypes.AsEnumerable() on sufb.Field<int>("tender_type_id") equals tt.Field<int>("tender_type_id")
                    //         join ct in dtContractTypes.AsEnumerable() on sufb.Field<int>("contract_type_id") equals ct.Field<int>("contract_type_id")
                    //         join fy in dtFiscalYear.AsEnumerable() on sufb.Field<int>("FYID") equals fy.Field<int>("FYID")
                    //         join cmt in dtCommittee.AsEnumerable() on sufb.Field<int>("committee_id") equals cmt.Field<int>("committee_id")
                    //         join ts in dtTenderStatus.AsEnumerable() on sufb.Field<int>("Tender_Status_id") equals ts.Field<int>("Tender_Status_id")                              
                    //         select new
                    //         {
                    //             ProjectId = sufb.Field<int>("proj_id"),
                    //             ProjectCode = sufb.Field<string>("project_code"),
                    //             ProjectTitle = sufb.Field<string>("project_newname"),
                    //             TenderNo = sufb.Field<string>("tender_no"),
                    //             CurrentStage = stg.Field<string>("Stage_Name"),
                    //             TenderStatus = ts.Field<string>("Status_Name"),
                    //             TypeOfTender = tt.Field<string>("tender_type_name"),
                    //             TenderCommittee = cmt.Field<string>("committee_short_name"),
                    //             TypeofContract = ct.Field<string>("TypeofContract"),
                    //             ContractNoWorkOrderNo = sufb.Field<string>("ContractNoWorkOrderNo"),
                    //             SuccessfulBidder = sufb.Field<string>("SuccessfulBidder"),
                    //             FiscalYear = fy.Field<string>("FiscalYear"),
                    //             UserDepartment = dpt1.Field<string>("Department"),
                    //             Qs = sufb.Field<string>("Qs"),
                    //             TndrHndl = sufb.Field<string>("TndrHndl"),
                    //             Staff = sufb.Field<string>("Staff"),                                                       
                    //             MozanahID = sufb.Field<string>("MozanahID"),                                 
                    //             dummyfield = sufb.Field<DateTime?>("dummyfield")                                  
                    //         }).OrderByDescending(item => item.dummyfield).ToList(); // AsEnumerable();//.ToList(); colName = p.Field<DateTime?>(colName)
                     
                    //DataTable finalDt = new DataTable("Project");
                    //finalDt.Columns.Add("Select");

                    //finalDt.Columns.Add("ProjectId");
                    //finalDt.Columns.Add("ProjectCode");
                    //finalDt.Columns.Add("ProjectTitle");

                    //finalDt.Columns.Add("TenderNo");
                    //finalDt.Columns.Add("CurrentStage");

                    //finalDt.Columns.Add("TenderStatus");
                    //finalDt.Columns.Add("TypeOfTender");

                    //finalDt.Columns.Add("TenderCommittee");
                    //finalDt.Columns.Add("TypeofContract");
                    //finalDt.Columns.Add("ContractNoWorkOrderNo");
                    //finalDt.Columns.Add("SuccessfulBidder");
                    //finalDt.Columns.Add("FiscalYear");
                    //finalDt.Columns.Add("UserDepartment");
                    //finalDt.Columns.Add("Qs");
                    //finalDt.Columns.Add("TndrHndl");
                    //finalDt.Columns.Add("Staff");
                    //finalDt.Columns.Add("MozanahID");
                    //finalDt.Columns.Add("ID", typeof(Int16));                

                    //finalDt.AcceptChanges();

                    //short rowId = 1;
                    //foreach (object drProj in iEnum)
                    //{
                    //    DataRow dr = finalDt.NewRow();

                    //    try
                    //    {
                             
                    //        dr[1] = drProj.ToString().Split(',')[0].Split('=')[1].Trim();  //ProjectId
                    //        dr[2] = drProj.ToString().Split(',')[1].Split('=')[1].Trim();  //ProjectCode
                    //        dr[3] = drProj.ToString().Split(',')[2].Split('=')[1].Trim().Replace('|',',');  //ProjTitle                   

                    //        dr[4] = drProj.ToString().Split(',')[3].Split('=')[1].Trim();  //TenderNo
                    //        dr[5] = drProj.ToString().Split(',')[4].Split('=')[1].Trim();  //CurrentStage

                    //        dr[6] = drProj.ToString().Split(',')[5].Split('=')[1].Trim();  //TenderStatus
                    //        dr[7] = drProj.ToString().Split(',')[6].Split('=')[1].Trim();  //TypeOfTender

                    //        dr[8] = drProj.ToString().Split(',')[7].Split('=')[1].Trim();  //TenderCommittee
                    //        dr[9] = drProj.ToString().Split(',')[8].Split('=')[1].Trim();  //TypeofContract
                    //        dr[10] = drProj.ToString().Split(',')[9].Split('=')[1].Replace("|",",").Trim();  //ContractNoWorkOrderNo
                    //        dr[11] = drProj.ToString().Split(',')[10].Split('=')[1].Trim(); //SuccessfulBidder
                             
                    //        dr[12] = drProj.ToString().Split(',')[11].Split('=')[1].Trim();  //FiscalYear
                    //        dr[13] = drProj.ToString().Split(',')[12].Split('=')[1].Trim();  //UserDepartment 
                    //        dr[14] = drProj.ToString().Split(',')[13].Split('=')[1].Trim();  //Qs 
                    //        dr[15] = drProj.ToString().Split(',')[14].Split('=')[1].Trim();  //TndrHndl 
                    //        dr[16] = drProj.ToString().Split(',')[15].Split('=')[1].Trim();  //Staff
                    //        dr[17] = drProj.ToString().Split(',')[16].Split('=')[1].Trim();  //MozanahID
                    //        dr[18] = rowId;                            

                    //    }
                    //    catch (Exception ex)
                    //    {
                    //        string str = null;
                    //    }
                    //    rowId++;
                    //    finalDt.Rows.Add(dr);
                    //    finalDt.AcceptChanges();
                    //}             


                    dtTemp = dtSuccessfulBidders;
                     
                        dtUniqueProjects = new DataTable();
                        foreach (DataColumn item in dtSuccessfulBidders.Columns)
                        {
                            dtUniqueProjects.Columns.Add(item.ColumnName, item.DataType);
                        }


                    foreach (DataRow dr in dtSuccessfulBidders.Rows)
                    {
                        if (dtUniqueProjects.Select("Proj_Id='" + dr[1].ToString() + "'").Count() == 0)
                        {
                            dtUniqueProjects.Rows.Add(dr.ItemArray);
                        }
                    }
                    int rowCounter = 1;
                    foreach (DataRow dr in dtUniqueProjects.Rows)
                        dr["ID"] = rowCounter++;
                    //dtCmbTbl = finalDt;
                    id1 = 1;
                    if (dtUniqueProjects.Rows.Count != 0)
                    {
                        if (dtUniqueProjects.Rows.Count >= 23)
                        {
                            id2 = 22;
                        }
                        else
                        {
                            id2 = Convert.ToInt16(dtUniqueProjects.Rows[dtTemp.Rows.Count - 1]["ID"]);
                        }

                        toolStripLabel2.Text = id1.ToString();
                        toolStripLabel3.Text = id2.ToString();
                        dgView.DataSource = dtUniqueProjects.Select("ID>=" + id1 + " and ID <= " + id2).CopyToDataTable();
                    }
                    else
                    {
                        dgView.DataSource = null;
                    }
                }               

                dgView.Columns[1].Visible = false;
                //dgView.Columns[13].Visible = false;
                dgView.Columns[15].Visible = false;
                //dgView.Columns[16].Visible = false;
                //dgView.Columns[16].Visible = false;
                
                Cursor = Cursors.Default;
                dgView.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
                dgView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgView.ColumnHeadersDefaultCellStyle.Font = new Font(dgView.Font, FontStyle.Bold);
                dgView.EnableHeadersVisualStyles = false;
                dgView.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                lblCnt.Text = dtUniqueProjects.Rows.Count.ToString(); //Select("proj_id").Distinct().Count();                 

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Occurred", "Error", MessageBoxButtons.OK,MessageBoxIcon.Error);                
            }           

        }

        private void FillCombo(string whereClause)
        {
            DAL dalObj = new DAL();
            if (whereClause != null)
            {
                if (whereClause != "")
                {
                    dalObj.populateCmbBox("Select p.Project_Code From Projects p where " + whereClause + " Order by p.Project_Code", cmbPrjCode);
                    dalObj.populateCmbBox("select tender_no from Projects p INNER JOIN TenderStatus ON TenderStatus.Tender_Status_id = p.Tender_Status_id " +
                    "INNER JOIN Department2 ON Department2.department_id = p.department_id WHERE (tender_no IS NOT NULL) and [TenderStatus].Tender_Status_id not in(17) " +
                    " and (p.isDeleted=0) and " + whereClause + "  Order by tender_no ", cmbTenderNo);

                    dalObj.populateCmbBox("Select ctrs.contract_no from CONTRACTORS ctrs full outer join PROJECTS p on p.proj_id=ctrs.proj_id " +
                    "INNER JOIN Department2 ON Department2.department_id = p.department_id INNER JOIN TenderStatus ON TenderStatus.Tender_Status_id = p.Tender_Status_id where ctrs.contract_no<>'' and "
                    + whereClause + " and [TenderStatus].Tender_Status_id not in(17) and (p.isDeleted=0) order by ctrs.contract_no", cmbContractNo);
                    cmbContractNo.SelectedIndex = -1;

                    dalObj.populateCmbBox("Select moazanah_proj_id_new From PROJECTS p full outer join CONTRACTORS ctrs on p.proj_id=ctrs.proj_id " +
                    "INNER JOIN Department2 ON Department2.department_id = p.department_id INNER JOIN TenderStatus ON TenderStatus.Tender_Status_id = p.Tender_Status_id where moazanah_proj_id_new<>'' and " +
                    whereClause + " and [TenderStatus].Tender_Status_id not in(17) and (p.isDeleted=0) order by moazanah_proj_id_new", cmbMozanahID);
                    cmbMozanahID.SelectedIndex = -1;            
                }
                else
                {
                    dalObj.populateCmbBox("Select Project_Code From Projects p INNER JOIN TenderStatus ON TenderStatus.Tender_Status_id = p.Tender_Status_id " +
                    "INNER JOIN Department2 ON Department2.department_id = p.department_id WHERE [TenderStatus].Tender_Status_id not in(17) and (p.isDeleted=0) Order by p.Project_Code", cmbPrjCode);

                    dalObj.populateCmbBox("select tender_no from Projects p INNER JOIN TenderStatus ON TenderStatus.Tender_Status_id = p.Tender_Status_id " +
                    "INNER JOIN Department2 ON Department2.department_id = p.department_id WHERE (tender_no IS NOT NULL) and [TenderStatus].Tender_Status_id not in(17) " +
                    " and (p.isDeleted=0) Order by tender_no ", cmbTenderNo);

                    dalObj.populateCmbBox("Select ctrs.contract_no from CONTRACTORS ctrs full outer join PROJECTS p on p.proj_id=ctrs.proj_id " +
                    "INNER JOIN Department2 ON Department2.department_id = p.department_id INNER JOIN TenderStatus ON TenderStatus.Tender_Status_id = p.Tender_Status_id where ctrs.contract_no<>'' " +
                    "and [TenderStatus].Tender_Status_id not in(17) and (p.isDeleted=0) order by ctrs.contract_no", cmbContractNo);
                    cmbContractNo.SelectedIndex = -1;

                    dalObj.populateCmbBox("Select moazanah_proj_id_new From PROJECTS p full outer join CONTRACTORS ctrs on p.proj_id=ctrs.proj_id " +
                    "INNER JOIN Department2 ON Department2.department_id = p.department_id INNER JOIN TenderStatus ON TenderStatus.Tender_Status_id = p.Tender_Status_id where moazanah_proj_id_new<>'' " +
                    "and [TenderStatus].Tender_Status_id not in(17) and (p.isDeleted=0) order by moazanah_proj_id_new", cmbMozanahID);
                    cmbMozanahID.SelectedIndex = -1;            
                }
            }
            else
            {
                dalObj.populateCmbBox("Select Project_Code From Projects p INNER JOIN TenderStatus ON TenderStatus.Tender_Status_id = p.Tender_Status_id " +
                "INNER JOIN Department2 ON Department2.department_id = p.department_id WHERE [TenderStatus].Tender_Status_id not in(17) and (p.isDeleted=0) Order by p.Project_Code", cmbPrjCode);

                dalObj.populateCmbBox("select tender_no from Projects p INNER JOIN TenderStatus ON TenderStatus.Tender_Status_id = p.Tender_Status_id " +
                "INNER JOIN Department2 ON Department2.department_id = p.department_id WHERE (tender_no IS NOT NULL) and [TenderStatus].Tender_Status_id not in(17) " +
                " and (p.isDeleted=0) Order by tender_no ", cmbTenderNo);

                dalObj.populateCmbBox("Select ctrs.contract_no from CONTRACTORS ctrs full outer join PROJECTS p on p.proj_id=ctrs.proj_id " +
                "INNER JOIN Department2 ON Department2.department_id = p.department_id INNER JOIN TenderStatus ON TenderStatus.Tender_Status_id = p.Tender_Status_id where ctrs.contract_no<>'' " +
                "and [TenderStatus].Tender_Status_id not in(17) and (p.isDeleted=0) order by ctrs.contract_no", cmbContractNo);
                cmbContractNo.SelectedIndex = -1;

                dalObj.populateCmbBox("Select moazanah_proj_id_new From PROJECTS p full outer join CONTRACTORS ctrs on p.proj_id=ctrs.proj_id " +
                "INNER JOIN Department2 ON Department2.department_id = p.department_id INNER JOIN TenderStatus ON TenderStatus.Tender_Status_id = p.Tender_Status_id where moazanah_proj_id_new<>'' " +
                "and [TenderStatus].Tender_Status_id not in(17) and (p.isDeleted=0) order by moazanah_proj_id_new", cmbMozanahID);
                cmbMozanahID.SelectedIndex = -1;  
            }
            cmbPrjCode.SelectedIndex = -1;

            
            cmbTenderNo.SelectedIndex = -1;

            dalObj.populateCmbBox("select Stage_Name from STAGES", cmbCurrentStage);
            cmbCurrentStage.SelectedIndex = -1;

            dalObj.populateCmbBox("Select [Status_Name],[TenderStatusShortName] From [TenderStatus] WHERE Tender_Status_id not in (17) Order by Tender_Status_id ", cmbTenderStatus);
            cmbTenderStatus.SelectedIndex = -1;

            dalObj.populateCmbBox("Select tender_type_name From [TenderTypes] Order by tender_type_name", cmbTypeOftender);
            cmbTypeOftender.SelectedIndex = -1;

            dalObj.populateCmbBox("select committee_short_name,committee_id from [Committee]", cmbTenderCommittee);
            cmbTenderCommittee.SelectedIndex = -1;

            dalObj.populateCmbBox("select [TypeofContract] from [ContractTypes]", cmbTypeofContract);
            cmbTypeofContract.SelectedIndex = -1;

            dalObj.populateCmbBox("Select FYID,[FiscalYear] From [FiscalYear] Order by FYID DESC", cmbFiscalYear);  //Fiscal_Year
            cmbFiscalYear.SelectedIndex = -1;

            dalObj.populateCmbBox("Select department_short_name,Department From Department2 where isActive=1 and department_id not in (46,47,48)", cmbUserDepart);
            cmbUserDepart.SelectedIndex = -1;
            
           

            dalObj.populateCmbBox("Select ShortName From Contacts where ShortName is not NULL order by ShortName", cmbQs);
            cmbQs.SelectedIndex = -1;

            dalObj.populateCmbBox("Select ShortName From Contacts where ShortName is not NULL order by ShortName", cmbTndrHndl);
            cmbTndrHndl.SelectedIndex = -1;

            dalObj.populateCmbBox("Select ShortName From Contacts where ShortName is not NULL order by ShortName", cmbStaff);
            cmbStaff.SelectedIndex = -1;
            
        }

        bool isRefresh = false;
        bool isNewItemSelected = false;
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            //Added by Varun on 10 Feb 2014 for displaying the projects related to user access rights only
            isRefresh = true;
            whereClauseForFilter = null;             
            whereClause = SetWhereClause(_userRightsColl);
            FillAllProjectsInformation('R');
        }

        DataTable dtCmbTbl = null;
        private void GridFill(string filterQuery)
        {

            dtTempForCombo = dtTemp;             
            if (dtTempForCombo.Rows.Count != 0)
            {
                if (dtTempForCombo.Select(filterQuery).Length != 0)
                {
                    dtCmbTbl = dtTempForCombo.Select(filterQuery).CopyToDataTable();
                    
                    if (colName != null)
                    {
                        dtCmbTbl.DefaultView.Sort = colName;
                        dtCmbTbl = dtCmbTbl.DefaultView.ToTable();
                    }
                    if (dtUniqueProjects != null)
                    {
                        dtUniqueProjects.Rows.Clear();
                    }
                    else
                    {
                        dtUniqueProjects = new DataTable();
                        foreach (DataColumn item in dtCmbTbl.Columns)
                        {
                            dtUniqueProjects.Columns.Add(item.ColumnName, item.DataType);
                        }
                    }
                    foreach (DataRow dr in dtCmbTbl.Rows)
                    {
                        if (dtUniqueProjects.Select("Proj_Id='" + dr[1].ToString() + "'").Count() == 0)
                        {
                            dtUniqueProjects.Rows.Add(dr.ItemArray);
                        }
                    }
                    try
                    {
                        //dtCmbTbl = dtCmbTbl.DefaultView.ToTable(true, "ProjectId");
                        int rowCounter = 1;
                        foreach (DataRow dr in dtUniqueProjects.Rows)
                            dr["ID"] = rowCounter++;
                        
                        id1 = 1;
                        if (dtUniqueProjects.Rows.Count >= 23)
                            id2 = 22;
                        else
                            id2 = Convert.ToInt16(dtUniqueProjects.Rows[dtUniqueProjects.Rows.Count - 1]["ID"]);

                        toolStripLabel2.Text = id1.ToString();
                        toolStripLabel3.Text = id2.ToString();
                        //dtCmbTbl.Select("ID>=" + id1 + " and ID <= " + id2).CopyToDataTable().DefaultView.Sort = colName;
                        myBindingSource = new BindingSource(dtUniqueProjects.Select("ID>=" + id1 + " and ID <= " + id2).CopyToDataTable(), null);
                        dgView.DataSource = myBindingSource;

                        dgView.EnableHeadersVisualStyles = false;
                        dgView.Columns[1].Visible = false;

                        if (filterQuery != "")
                        {
                            Filtered = 'Y';
                            isRefresh = false;
                        }
                        else
                        {
                            Filtered = ' ';
                            isRefresh = true;
                        }
                    }
                    catch (Exception ex)
                    {
                        string exMsg = ex.Message;
                    }
                    finally
                    {
                    }

                    //if (isContractorExists)
                    lblCnt.Text = dtUniqueProjects.Rows.Count.ToString(); //dtCmbTbl.Rows.Count.ToString();
                }
                else
                {
                    SetGridViewToNoRecords();
                }
            }
            else
            {
                SetGridViewToNoRecords();
            }
        }


        private void SetGridViewToNoRecords()
        {
            dtUniqueProjects = null;
            dtCmbTbl = null;
            myBindingSource = new BindingSource(null, null);
            dgView.DataSource = myBindingSource;
            id1 = 0;
            id2 = 0;
            toolStripLabel2.Text = id1.ToString();
            toolStripLabel3.Text = id2.ToString();
            lblCnt.Text = "0";
        }

        // This method will determine the correct
        // Page Boundaries for the RecordID's to filter by
        private void DeterminePageBoundaries()
        {
            if (dgView.RowCount != 0)
            {         

                //Added By Varun on 24/02/14 for creating pagination functionality
                //We now need to determine the LowerBoundary
                //and UpperBoundary in order to correctly...
                //...determine the Correct RecordID's
                //to use in the bindingSource1.Filter property.        
                                
                //This is the maximum rows to display on a page.
                //So we want paging to be implemented at 100 rows a page 

                //If the rows per page are less than
                //the total row count do the following:   
                
                int totalRowCount = 0;
                totalRowCount = dtUniqueProjects.Rows.Count;

                //This is the maximum rows to display on a page.
                //So we want paging to be implemented at 100 rows a page                          
                int pageRows = 23;
                int pages = 0;

                //If the rows per page are less than
                //the total row count do the following:
                if (pageRows < totalRowCount)
                {
                    //If the Modulus returns > 0 then there should be another page.
                    if ((totalRowCount % pageRows) > 0)
                    {
                        pages = ((totalRowCount / pageRows) + 1);
                    }
                    else
                    {
                        //There is nothing left after the Modulus,
                        //so the pageRows divide exactly...
                        //...into TotalRowCount leaving no rest,
                        //thus no extra page needs to be added.
                        pages = totalRowCount / pageRows;
                    }
                }
                else
                {
                    //If the rows per page are more than the total
                    //row count, we will obviously only ever have 1 page
                    pages = 1;
                }

                //Added By Varun on 24/02/14 for creating pagination functionality
                //We now need to determine the LowerBoundary
                //and UpperBoundary in order to correctly...
                //...determine the Correct RecordID's
                //to use in the bindingSource1.Filter property.
                int LowerBoundary = 0;
                int UpperBoundary = 0;

                //We now need to know what button was clicked,
                //if any (First, Last, Next, Previous)
                switch (NavClicked)
                {
                    case "First":
                        //First clicked, the Current Page will always be 1
                        CurrentPage = 1;
                        //The LowerBoundary will thus be ((50 * 1) - (50 - 1)) = 1
                        LowerBoundary = ((pageRows * CurrentPage) - (pageRows - 1));

                        //If the rows per page are less than
                        //the total row count do the following:
                        if (pageRows < totalRowCount)
                        {
                            UpperBoundary = (pageRows * CurrentPage);
                        }
                        else
                        {
                            //If the rows per page are more than
                            //the total row count do the following:
                            //There is only one page, so get
                            //the total row count as an UpperBoundary
                            UpperBoundary = totalRowCount;
                        }

                        //Now using these boundaries, get the
                        //appropriate RecordID's (min & max)...
                        //...for this specific page.
                        //Remember, .NET is 0 based, so subtract 1 from both boundaries
                        id1 = Convert.ToInt16(dtUniqueProjects.Rows[LowerBoundary - 1]["ID"]);
                        id2 = Convert.ToInt16(dtUniqueProjects.Rows[UpperBoundary - 1]["ID"]);

                        break;

                    case "Last":
                        //Last clicked, the CurrentPage will always be = to the variable pages
                        CurrentPage = pages;
                        LowerBoundary = ((pageRows * CurrentPage) - (pageRows - 1));
                        //The UpperBoundary will always be the sum total of all the rows
                        UpperBoundary = totalRowCount;

                        //Now using these boundaries, get the appropriate
                        //RecordID's (min & max)...
                        //...for this specific page.
                        //Remember, .NET is 0 based, so subtract 1 from both boundaries
                        id1 = Convert.ToInt16(dtUniqueProjects.Rows[LowerBoundary - 1]["ID"]);
                        id2 = Convert.ToInt16(dtUniqueProjects.Rows[UpperBoundary - 1]["ID"]);

                        break;

                    case "Next":
                        //Next clicked
                        if (CurrentPage != pages)
                        {
                            //If we arent on the last page already, add another page
                            CurrentPage += 1;
                        }

                        LowerBoundary = ((pageRows * CurrentPage) - (pageRows - 1));

                        if (CurrentPage == pages)
                        {
                            //If we are on the last page, the UpperBougndary
                            //will always be the sum total of all the rows
                            UpperBoundary = totalRowCount;
                        }
                        else
                        {
                            //Else if we have a pageRow of 50 and we are
                            //on page 3, the UpperBoundary = 150
                            UpperBoundary = (pageRows * CurrentPage);
                        }

                        if (UpperBoundary > dtUniqueProjects.Rows.Count)
                        {
                            UpperBoundary = dtUniqueProjects.Rows.Count;
                            LowerBoundary = UpperBoundary - 23;
                        }
                        //Now using these boundaries, get the appropriate
                        //RecordID's (min & max)...
                        //...for this specific page.
                        //Remember, .NET is 0 based, so subtract 1 from both boundaries

                        id1 = Convert.ToInt16(dtUniqueProjects.Rows[LowerBoundary - 1]["ID"]);
                        id2 = Convert.ToInt16(dtUniqueProjects.Rows[UpperBoundary - 1]["ID"]);

                        break;

                    case "Previous":
                        //Previous clicked
                        if (CurrentPage != 1)
                        {
                            //If we aren't on the first page already,
                            //subtract 1 from the CurrentPage
                            CurrentPage -= 1;
                        }
                        //Get the LowerBoundary
                        LowerBoundary = ((pageRows * CurrentPage) - (pageRows - 1));

                        if (pageRows < totalRowCount)
                        {
                            UpperBoundary = (pageRows * CurrentPage);
                        }
                        else
                        {
                            UpperBoundary = totalRowCount;
                        }

                        if (UpperBoundary > dtUniqueProjects.Rows.Count)
                        {
                            UpperBoundary = dtUniqueProjects.Rows.Count;
                            LowerBoundary = UpperBoundary - 23;
                        }
                        //Now using these boundaries,
                        //get the appropriate RecordID's (min & max)...
                        //...for this specific page.
                        //Remember, .NET is 0 based, so subtract 1 from both boundaries
                        id1 = Convert.ToInt16(dtUniqueProjects.Rows[LowerBoundary - 1]["ID"]);
                        id2 = Convert.ToInt16(dtUniqueProjects.Rows[UpperBoundary - 1]["ID"]);

                        break;

                    default:
                        //No button was clicked.
                        LowerBoundary = ((pageRows * CurrentPage) - (pageRows - 1));

                        //If the rows per page are less than
                        //the total row count do the following:
                        if (pageRows < totalRowCount)
                        {
                            UpperBoundary = (pageRows * CurrentPage);
                        }
                        else
                        {
                            //If the rows per page are more than
                            //the total row count do the following:
                            //Therefore there is only one page,
                            //so get the total row count as an UpperBoundary
                            UpperBoundary = totalRowCount;
                        }

                        //Now using these boundaries, get the
                        //appropriate RecordID's (min & max)...
                        //...for this specific page.
                        //Remember, .NET is 0 based, so subtract 1 from both boundaries
                        id1 = Convert.ToInt16(dtUniqueProjects.Rows[LowerBoundary - 1]["ID"]);
                        id2 = Convert.ToInt16(dtUniqueProjects.Rows[UpperBoundary - 1]["ID"]);

                        break;
                }
            }


        }

        //Added By Varun on 24/02/14 for creating pagination functionality
        // Filter DataGrid based on changing ID values
        private void FilterDataGrid()
        {
            try
            {
                if (dgView.RowCount != 0)
                {
                    Cursor = Cursors.WaitCursor;
                    if (id1 == 1 && dtUniqueProjects != null && isRefresh == false)
                    {
                        if (dtUniqueProjects.Rows.Count >= 23)
                            id2 = 22;
                        else
                            id2 = Convert.ToInt16(dtUniqueProjects.Rows[dtUniqueProjects.Rows.Count - 1]["ID"]);
                    }
                    //else if (id1 == 1 && dtTemp != null)
                    //{
                    //    if (dtTemp.Rows.Count >= 23)
                    //        id2 = 22;
                    //    else
                    //        id2 = Convert.ToInt16(dtTemp.Rows[dtTemp.Rows.Count - 1]["ID"]);
                    //}
                    toolStripLabel2.Text = id1.ToString();
                    toolStripLabel3.Text = id2.ToString();
                    if (dtCmbTbl != null && isRefresh == false)
                        dgView.DataSource = new BindingSource(dtUniqueProjects.Select("ID>=" + id1 + " and ID <= " + id2).CopyToDataTable(), null);
                    else
                        dgView.DataSource = new BindingSource(dtUniqueProjects.Select("ID>=" + id1 + " and ID <= " + id2).CopyToDataTable(), null);
                }
                else
                {
                    dtUniqueProjects = null;
                    dtCmbTbl = null;
                    myBindingSource = new BindingSource(null, null);
                    dgView.DataSource = myBindingSource;
                    id1 = 0;
                    id2 = 0;
                    toolStripLabel2.Text = id1.ToString();
                    toolStripLabel3.Text = id2.ToString();
                    lblCnt.Text = "0";            
                }
                //totalProjectsCount = dgView.RowCount;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        //Added By Varun on 24/02/14 for creating pagination functionality
        private void tsbFirst_Click(object sender, EventArgs e)
        {
            try
            {
                if (id1 != 0)
                {
                    NavClicked = NavButton.First.ToString();
                    DeterminePageBoundaries();
                    FilterDataGrid();
                }
                else
                {
                    MessageBox.Show("No records found to traverse");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Occurred", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                  
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        //Added By Varun on 24/02/14 for creating pagination functionality
        private void tsbPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                if (id1 != 0)
                {
                    NavClicked = NavButton.Previous.ToString();
                    DeterminePageBoundaries();
                    FilterDataGrid();
                }
                else
                {
                    MessageBox.Show("No records found to traverse");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Occurred", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                  
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        //Added By Varun on 24/02/14 for creating pagination functionality
        private void tsbNext_Click(object sender, EventArgs e)
        {
            try
            {
                if (id1 != 0)
                {
                    NavClicked = NavButton.Next.ToString();
                    DeterminePageBoundaries();
                    FilterDataGrid();
                }
                else
                {
                    MessageBox.Show("No records found to traverse");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Occurred", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                  
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        //Added By Varun on 24/02/14 for creating pagination functionality
        private void tsbLast_Click(object sender, EventArgs e)
        {
            try
            {
                if (id1 != 0)
                {
                    NavClicked = NavButton.Last.ToString();
                    DeterminePageBoundaries();
                    FilterDataGrid();
                }
                else
                {
                    MessageBox.Show("No records found to traverse");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Occurred", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                  
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        private void cmbPrjCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dtTemp != null)
            {
                isNewItemSelected = true;
                filterCombo();
            }
        }

        private void cmbPrjCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (dtTemp != null)
            {
                if (e.KeyChar == 13)
                {
                    isNewItemSelected = true;
                    filterCombo();
                }
            }
        }

        private void cmbTenderNo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dtTemp != null)
            {
                isNewItemSelected = true;
                filterCombo();
            }
        }

        private void cmbTenderNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (dtTemp != null)
            {
                if (e.KeyChar == 13)
                {
                    isNewItemSelected = true;
                    filterCombo();
                }
            }
        }

        private void cmbCurrentStage_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dtTemp != null)
            {
                isNewItemSelected = true;
                filterCombo();
            }
        }

        private void cmbCurrentStage_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (dtTemp != null)
            {
                if (e.KeyChar == 13)
                {
                    isNewItemSelected = true;
                    filterCombo();
                }
            }
        }

        private void cmbTenderStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dtTemp != null)
            {
                isNewItemSelected = true;
                filterCombo();
            }
        }

        private void cmbTenderStatus_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (dtTemp != null)
            {
                if (e.KeyChar == 13)
                {
                    isNewItemSelected = true;
                    filterCombo();
                }
            }
        }

        private void cmbTypeOftender_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dtTemp != null)
            {
                isNewItemSelected = true;
                filterCombo();
            }
        }

        private void cmbTypeOftender_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (dtTemp != null)
            {
                if (e.KeyChar == 13)
                {
                    isNewItemSelected = true;
                    filterCombo();
                }
            }
        }

        private void cmbTenderCommittee_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dtTemp != null)
            {
                isNewItemSelected = true;
                filterCombo();
            }
        }

        private void cmbTenderCommittee_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (dtTemp != null)
            {
                if (e.KeyChar == 13)
                {
                    isNewItemSelected = true;
                    filterCombo();
                }
            }
        }

        private void cmbTypeofContract_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dtTemp != null)
            {
                isNewItemSelected = true;
                filterCombo();
            }
        }

        private void cmbTypeofContract_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (dtTemp != null)
            {
                if (e.KeyChar == 13)
                {
                    isNewItemSelected = true;
                    filterCombo();
                }
            }
        }

        private void cmbFiscalYear_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dtTemp != null)
            {
                isNewItemSelected = true;
                filterCombo();
            }
        }

        private void cmbFiscalYear_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (dtTemp != null)
            {
                if (e.KeyChar == 13)
                {
                    isNewItemSelected = true;
                    filterCombo();
                }
            }
        }

        private void cmbUserDepart_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dtTemp != null)
            {
                isNewItemSelected = true;
                filterCombo();
            }
        }

        //"#" + myDate + "# >= StartDate AND EndDate <= #" + myDate + "#"
                        //dtCmbTbl = dtCmbTbl.AsEnumerable().Where(c => c.Field<CreateDate> "CreateDate>='01-Jul-2013' and CreateDate<='04-Dec-2013'").CopyToDataTable();
                        //try
                        //{
                        //    filterCombo(whereClause);
                        //    //dtCmbTbl = dtCmbTbl.Select(whereClause).CopyToDataTable();
                        //    dtCmbTbl.DefaultView.Sort = colName;
                        //    dtProject = dtCmbTbl;
                        //}
                        //catch (Exception)
                        //{
                        //    MessageBox.Show("No records found", "Information", MessageBoxButtons.OK);
                        //    dtProject = new DataTable();
                        //}       



        private void cmbUserDepart_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (dtTemp != null)
            {
                if (e.KeyChar == 13)
                {
                    isNewItemSelected = true;
                    filterCombo();
                }
            }
        }

        private void cmbContractNo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dtTemp != null)
            {
                isNewItemSelected = true;
                filterCombo();
            }
        }

        private void cmbContractNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (dtTemp != null)
            {
                if (e.KeyChar == 13)
                {
                    isNewItemSelected = true;
                    filterCombo();
                }
            }
        }

        private void cmbMozanahID_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dtTemp != null)
            {
                isNewItemSelected = true;
                filterCombo();
            }
        }

        private void cmbMozanahID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                isNewItemSelected = true;
                filterCombo();
            }
        }

        private void btnAddProject_Click(object sender, EventArgs e)
        {
            if (_userRightsColl.Contains("1"))   //Add New Project
            {
                MessageBox.Show("You have no privilege to add project,Contact administrator");
                return;
            }
            MDI_ParenrForm.Projects.frmProjectInfo prjInfo = new MDI_ParenrForm.Projects.frmProjectInfo(_userRightsColl, _userName, _isHeadOfSection);
            prjInfo.StartPosition = FormStartPosition.CenterScreen;
            prjInfo.ShowDialog();
            FillAllProjectsInformation('R');
        }

        private void btnEditArchieve_Click(object sender, EventArgs e)
        {
            if (_userRightsColl.Contains("3"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            int iCnt = 0;
            for (int iCounter = 0; iCounter < dgView.RowCount; iCounter++)
            {
                DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgView.Rows[iCounter].Cells[0];

                if (chkactive.Value != null)
                {
                    if (chkactive.Value.ToString().ToLower() == "true")
                        iCnt = iCnt + 1;
                }
            }
            if (iCnt > 1)
            {
                MessageBox.Show("Please Select Only One Record For Edit");
                return;
            }


            int ProjectID = 0;
            string prjCode = string.Empty;

            for (int iCounter = 0; iCounter < dgView.RowCount; iCounter++)
            {
                DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgView.Rows[iCounter].Cells[0];
                if (chkactive.Value != null)
                {
                    if (chkactive.Value.ToString().ToLower() == "true")
                    {
                        ProjectID = Convert.ToInt16(dgView.Rows[iCounter].Cells[1].Value);
                    }
                }
            }
            if (ProjectID == 0)
            {
                MessageBox.Show("Please click the checkbox to select the project you want to View/Edit.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                // frmProjectEdit frmEditProject = new frmProjectEdit(ProjectID, prjCode, affairsName, deptName, prjTitleEn, prjTitleArb, tndrCommitte, typeOfTender, fiscalYear, typeOfCntr);
                frmProjectEdit frmEditProject = new frmProjectEdit(_userRightsColl, ProjectID, prjCode, _userName);
                frmEditProject.StartPosition = FormStartPosition.CenterParent;
                frmEditProject.ShowDialog();
            }
        }

        private void btnDeleteArchieve_Click(object sender, EventArgs e)
        {
            int prjID = 0;
            try
            {
                if (_userRightsColl.Contains("2"))
                {
                    MessageBox.Show("You have no privilege, Contact administrator");
                    return;
                }


                int iCnt = 0;
                for (int iCounter = 0; iCounter < dgView.RowCount; iCounter++)
                {
                    DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgView.Rows[iCounter].Cells[0];

                    if (chkactive.Value != null)
                    {
                        if (chkactive.Value.ToString().ToLower() == "true")
                            iCnt = iCnt + 1;
                    }
                }

                if (iCnt > 1)
                {
                    MessageBox.Show("Please Select Only One Record For Delete");
                    return;
                }

                List<int> lstObj = new List<int>();

                sqlConn = new SqlConnection(connStr);
                sqlConn.Open();
                for (int iCounter = 0; iCounter < dgView.RowCount; iCounter++)
                {
                    DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgView.Rows[iCounter].Cells[0];
                    if (chkactive.Value != null)
                    {
                        if (chkactive.Value.ToString().ToLower() == "true")
                        {
                            prjID = Convert.ToInt16(dgView.Rows[iCounter].Cells[1].Value);
                            try
                            {
                                DialogResult dlgResult = DialogResult.Yes;
                                dlgResult = MessageBox.Show(" Are you sure you want to move the Project to Deleted Projects?", "Delete Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                                if (dlgResult.ToString() == "Yes")
                                {
                                    try
                                    {
                                        using (SqlCommand sqlCom = new SqlCommand("update Projects set isDeleted=1 where Proj_id =" + prjID, sqlConn))
                                        {
                                            sqlCom.ExecuteNonQuery();
                                        }
                                        MessageBox.Show("Record Successfully moved to Deleted Projects");
                                    }
                                    catch (Exception ex)
                                    {
                                        MessageBox.Show("Error occurred while updating the value of isDeleted column of Project table.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    }
                                    // moved by Varun
                                    lstObj.Add(iCounter);

                                }
                                else
                                {
                                    return;
                                }

                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("You have no privilege to delete this project,Contact administrator", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                sqlConn.Close();
                                return;
                            }
                            finally
                            {
                                sqlConn.Close();
                            }
                        }
                    }
                }
                short sClear = 0;
                if (dgView.Rows.Count == lstObj.Count)
                {
                    dgView.Rows.RemoveAt(lstObj[0]);
                    sClear = 1;
                }
                if (sClear != 1)
                {
                    for (int iCounter = 0; iCounter < lstObj.Count; iCounter++)
                    {
                        if (iCounter == 0)
                            dgView.Rows.RemoveAt(lstObj[iCounter]);
                        if (iCounter != 0)
                            dgView.Rows.RemoveAt(lstObj[iCounter] - 1);
                    }
                }

                if (lstObj.Count == 0)
                    MessageBox.Show("Please click the checkbox to select the project you want to Delete.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while connecting to database", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnExportToExcel_Click(object sender, EventArgs e)
        {
            try
            {
                if (_userRightsColl.Contains("92"))   
                {
                    MessageBox.Show("You have no privilege to export project details into excel sheet. Please Contact system administrator.");
                    return;
                }


                SaveFileDialog saveFileDialog1 = new SaveFileDialog();
                Microsoft.Office.Interop.Excel._Application app = null;
                Microsoft.Office.Interop.Excel._Workbook workbook = null;
                //if(!mIsWorkOrder)
                //{
                // commented by Varun on 08/Jun/15 saveFileDialog1.Filter = "Excel Path|*.xls|Excel Format|*.xlsx";

                saveFileDialog1.Filter = "Excel Path|*.xls|Excel Path|*.xlsx";
                saveFileDialog1.Title = "Save an Excel File";
                saveFileDialog1.ShowDialog();

                if (saveFileDialog1.FileName != "")
                {
                    // creating Excel Application
                    app = new Microsoft.Office.Interop.Excel.Application();

                    // creating new WorkBook within Excel application
                    workbook = app.Workbooks.Add(Type.Missing);

                    // creating new Excelsheet in workbook
                    Microsoft.Office.Interop.Excel._Worksheet worksheet = null;

                    // see the excel sheet behind the program
                    app.Visible = true;

                    // get the reference of first sheet. By default its name is Sheet1.
                    // store its reference to worksheet
                    worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Sheets["Sheet1"];
                    worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.ActiveSheet;

                    Microsoft.Office.Interop.Excel.Range formatRange = worksheet.UsedRange;
                    Microsoft.Office.Interop.Excel.Range formatA1CellRange = null;
                    Microsoft.Office.Interop.Excel.Range formatA1Cell = null;

                    DataTable dtExportToExcel = null;
                    if (dtUniqueProjects != null)
                    {
                        dtExportToExcel = dtUniqueProjects;
                    }
                    else
                    {
                        dtExportToExcel = dtTemp;
                    }

                    int columnCount = dtExportToExcel.Columns.Count;
                    //if (columnCount == 17)
                    //{
                    //    formatA1CellRange = worksheet.get_Range("A1", "O1");
                    //    formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[1, 15];
                    //}
                    //else
                    //{
                        formatA1CellRange = worksheet.get_Range("A1", "O1");
                        formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[1, 15];
                    //}

                    formatA1CellRange.ColumnWidth = 150;
                    formatA1CellRange.Merge(true);

                    //if (dtCmbTbl != null)
                    //{
                    //    formatA1CellRange.FormulaR1C1 = "PROJECT REPORT(" + dtExportToExcel.Rows[0]["TenderStatus"].ToString() + ")";
                    //}
                    //else
                    //{
                        formatA1CellRange.FormulaR1C1 = "PROJECTS REPORT";
                    //}

                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(196, 215, 155));
                    formatA1CellRange.Font.Size = 18;

                    System.Drawing.Color color = Color.FromArgb(255, 204, 0);

                    // storing header part in Excel
                    for (int i = 1; i <= 15; i++)
                    {
                        if (i == 1)
                        {
                            worksheet.Cells[3, 1] = "SNo.";
                            formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, i];
                            formatA1Cell.Font.Name = "Calibri";
                            formatA1Cell.Font.Size = "12";
                            formatA1Cell.Font.Bold = true;
                            formatA1Cell.WrapText = true;
                            formatA1Cell.ColumnWidth = 5;
                            formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                            formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                        }
                        else if (i == 2)
                        {
                            worksheet.Cells[3, 2] = dtExportToExcel.Columns[i].ColumnName; // Project Code == Columns[2]
                            formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, i];
                            formatA1Cell.Font.Name = "Calibri";
                            formatA1Cell.Font.Size = "12";
                            formatA1Cell.Font.Bold = true;
                            formatA1Cell.WrapText = true;
                            formatA1Cell.ColumnWidth = 20;
                            formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                            formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                        }
                        else if (i == 3)
                        {
                            worksheet.Cells[3, 3] = dtExportToExcel.Columns[i].ColumnName; // Project Title == Columns[3]
                            formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, i];
                            formatA1Cell.Font.Name = "Calibri";
                            formatA1Cell.Font.Size = "12";
                            formatA1Cell.Font.Bold = true;
                            formatA1Cell.WrapText = true;
                            formatA1Cell.ColumnWidth = 40;
                            formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                            formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                        }
                        else if (i == 4)
                        {
                            worksheet.Cells[3, 4] = dtExportToExcel.Columns[i].ColumnName; // Tender No. == Columns[4]
                            formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, i];
                            formatA1Cell.Font.Name = "Calibri";
                            formatA1Cell.Font.Size = "12";
                            formatA1Cell.Font.Bold = true;
                            formatA1Cell.WrapText = true;
                            formatA1Cell.ColumnWidth = 20;
                            formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                            formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                        }

                        else if (i == 5)
                        {
                            worksheet.Cells[3, 5] = dtExportToExcel.Columns[i].ColumnName; // Tender Committee == Columns[5]
                            formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, i];
                            formatA1Cell.Font.Name = "Calibri";
                            formatA1Cell.Font.Size = "12";
                            formatA1Cell.Font.Bold = true;
                            formatA1Cell.WrapText = true;
                            formatA1Cell.ColumnWidth = 20;
                            formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                            formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                        }
                        else if (i == 6)
                        {
                            worksheet.Cells[3, 6] = dtExportToExcel.Columns[i].ColumnName; // Department Name == Columns[11]
                            formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, i];
                            formatA1Cell.Font.Name = "Calibri";
                            formatA1Cell.Font.Size = "12";
                            formatA1Cell.Font.Bold = true;
                            formatA1Cell.WrapText = true;
                            formatA1Cell.ColumnWidth = 40;
                            formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                            formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                        }
                        else if (i == 7)
                        {
                            worksheet.Cells[3, 7] = dtExportToExcel.Columns[i].ColumnName;
                            formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, i];
                            formatA1Cell.Font.Name = "Calibri";
                            formatA1Cell.Font.Size = "12";
                            formatA1Cell.Font.Bold = true;
                            formatA1Cell.WrapText = true;
                            formatA1Cell.ColumnWidth = 20;
                            formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                            formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                        }
                        else if (i == 8)
                        {
                            worksheet.Cells[3, 8] = dtExportToExcel.Columns[i].ColumnName;
                            formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, i];
                            formatA1Cell.Font.Name = "Calibri";
                            formatA1Cell.Font.Size = "12";
                            formatA1Cell.Font.Bold = true;
                            formatA1Cell.WrapText = true;
                            formatA1Cell.ColumnWidth = 20;
                            formatA1Cell.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
                            formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                            //formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                            formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                        }
                        else if (i == 9)
                        {
                            worksheet.Cells[3, 9] = dtExportToExcel.Columns[i].ColumnName;
                            formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, i];
                            formatA1Cell.Font.Name = "Calibri";
                            formatA1Cell.Font.Size = "12";
                            formatA1Cell.Font.Bold = true;
                            formatA1Cell.WrapText = true;
                            formatA1Cell.ColumnWidth = 20;
                            formatA1Cell.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
                            formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                            //formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                            formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                        }
                        else if (i == 10)
                        {
                            worksheet.Cells[3, 10] = dtExportToExcel.Columns[i].ColumnName;
                            formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, i];
                            formatA1Cell.Font.Name = "Calibri";
                            formatA1Cell.Font.Size = "12";
                            formatA1Cell.Font.Bold = true;
                            formatA1Cell.WrapText = true;
                            formatA1Cell.ColumnWidth = 20;
                            formatA1Cell.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
                            formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                            //formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                            formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                        }

                        else if (i == 11)
                        {
                            worksheet.Cells[3, 11] = dtExportToExcel.Columns[i].ColumnName; // Fiscal Year == Columns[10]
                            formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, i];
                            formatA1Cell.Font.Name = "Calibri";
                            formatA1Cell.Font.Size = "12";
                            formatA1Cell.Font.Bold = true;
                            formatA1Cell.WrapText = true;
                            formatA1Cell.ColumnWidth = 20;
                            formatA1Cell.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
                            formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                            //formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                            formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                        }


                        //if (columnCount == 17)
                        //{
                            if (i == 12)
                            {
                                worksheet.Cells[3, 12] = dtExportToExcel.Columns[i].ColumnName; // Fiscal Year == Columns[10]
                                formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, i];
                                formatA1Cell.Font.Name = "Calibri";
                                formatA1Cell.Font.Size = "12";
                                formatA1Cell.Font.Bold = true;
                                formatA1Cell.WrapText = true;
                                formatA1Cell.ColumnWidth = 20;
                                formatA1Cell.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
                                formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                                //formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                                formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                            }

                            if (i == 13)
                            {
                                worksheet.Cells[3, 13] = dtExportToExcel.Columns[i].ColumnName; // Fiscal Year == Columns[10]
                                formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, i];
                                formatA1Cell.Font.Name = "Calibri";
                                formatA1Cell.Font.Size = "12";
                                formatA1Cell.Font.Bold = true;
                                formatA1Cell.WrapText = true;
                                formatA1Cell.ColumnWidth = 20;
                                formatA1Cell.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
                                formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                                //formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                                formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                            }

                            if (i == 14)
                            {
                                worksheet.Cells[3, 14] = dtExportToExcel.Columns[i].ColumnName; // Fiscal Year == Columns[10]
                                formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, i];
                                formatA1Cell.Font.Name = "Calibri";
                                formatA1Cell.Font.Size = "12";
                                formatA1Cell.Font.Bold = true;
                                formatA1Cell.WrapText = true;
                                formatA1Cell.ColumnWidth = 20;
                                formatA1Cell.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
                                formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                                //formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                                formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                            }

                            if (i == 15)
                            {
                                worksheet.Cells[3, 15] = dtExportToExcel.Columns[i].ColumnName; // Fiscal Year == Columns[10]
                                formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, i];
                                formatA1Cell.Font.Name = "Calibri";
                                formatA1Cell.Font.Size = "12";
                                formatA1Cell.Font.Bold = true;
                                formatA1Cell.WrapText = true;
                                formatA1Cell.ColumnWidth = 20;
                                formatA1Cell.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
                                formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                                //formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                                formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                            }
                        //}

                    }

                    int maxAsciiCode = 79;
                    //if (columnCount == 17)
                    //{
                    //    maxAsciiCode = 79;
                    //}
                    //else
                    //{
                    //    maxAsciiCode = 76;
                    //}

                    // storing Each row and column value to excel sheet
                    for (int i = 0; i < dtExportToExcel.Rows.Count; i++)
                    {

                        for (int asciiCode = 65; asciiCode <= maxAsciiCode; asciiCode++)
                        {
                            char alphaBet = (char)asciiCode;
                            worksheet.get_Range(alphaBet + (i + 5).ToString(), alphaBet + (i + 5).ToString()).Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeLeft].Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;                             
                            worksheet.get_Range(alphaBet + (i + 5).ToString(), alphaBet + (i + 5).ToString()).Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeTop].Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
                            worksheet.get_Range(alphaBet + (i + 5).ToString(), alphaBet + (i + 5).ToString()).RowHeight = 45;
                            worksheet.get_Range(alphaBet + (i + 5).ToString(), alphaBet + (i + 5).ToString()).Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeRight].Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
                            worksheet.get_Range(alphaBet + (i + 5).ToString(), alphaBet + (i + 5).ToString()).Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeBottom].Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;                                                          
                        }

                        worksheet.Cells[i + 5, 1] = i + 1;

                        worksheet.Cells[i + 5, 2] = dtExportToExcel.Rows[i][2].ToString();
 
                        worksheet.Cells[i + 5, 3] = dtExportToExcel.Rows[i][3].ToString();

                        worksheet.Cells[i + 5, 4] = dtExportToExcel.Rows[i][4].ToString();

                        worksheet.Cells[i + 5, 5] = dtExportToExcel.Rows[i][5].ToString();

                        worksheet.Cells[i + 5, 6] = dtExportToExcel.Rows[i][6].ToString();

                        worksheet.Cells[i + 5, 7] = dtExportToExcel.Rows[i][7].ToString();

                        worksheet.Cells[i + 5, 8] = dtExportToExcel.Rows[i][8].ToString();

                        worksheet.Cells[i + 5, 9] = dtExportToExcel.Rows[i][9].ToString();

                        worksheet.Cells[i + 5, 10] = dtExportToExcel.Rows[i][10].ToString();

                        worksheet.Cells[i + 5, 11] = dtExportToExcel.Rows[i][11].ToString();

                        worksheet.Cells[i + 5, 12] = dtExportToExcel.Rows[i][12].ToString();

                        worksheet.Cells[i + 5, 13] = dtExportToExcel.Rows[i][13].ToString();

                        worksheet.Cells[i + 5, 14] = dtExportToExcel.Rows[i][14].ToString();

                        worksheet.Cells[i + 5, 15] = dtExportToExcel.Rows[i][15].ToString();                         

                        //if (columnCount == 17)
                        //{
                        //    worksheet.Cells[i + 5, 12] = dtExportToExcel.Rows[i][12].ToString();
                        //}

                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while creating the excel file", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 2)
            {
                string mnstryCode = string.Empty;
                try
                {
                    ProjectStages projStg = new ProjectStages(_userRightsColl, "", Convert.ToInt16(dgView.Rows[e.RowIndex].Cells[1].Value), dgView.Rows[e.RowIndex].Cells[8].Value.ToString(), _userName, null, _isHeadOfSection);
                    projStg.StartPosition = FormStartPosition.CenterParent;
                    projStg.ShowDialog();
                    UpdateTimeInDummyField(projStg.ProjectId);

                    //if(projStg.ProjTransferedToComm=='Y' || Filtered ==' ')                     

                    //if (!userRightsColl.Contains("54"))
                    //{
                    if (projStg.ProjTransferedToComm == 'Y' || projStg.ProjReTendered == 'Y')
                    {
                        FillAllProjectsInformation('R');
                    }

                    //    //else if (Filtered!='Y')
                    //    //    FillAllProjectsInformation_CommitteWise(' ', filterQueryMain, Filtered);
                    //}

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }       
        }       

        private void UpdateTimeInDummyField(int ProjIDTime)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        cmd.CommandText = @"UPDATE PROJECTS SET dummyfield = @fieldForTime where proj_id=@prjID";
                        cmd.Parameters.AddWithValue("@fieldForTime", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@prjID", ProjIDTime);

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the TimeSpan, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        static int countMouseClicks = 0;
        static int colIdx = 0;
        static int prevColIdx = 0;
        static string colName = null;
        private void dgView_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                countMouseClicks += 1;
                colIdx = e.ColumnIndex;
                if (countMouseClicks >= 3)
                {
                    if (prevColIdx != colIdx)
                    {
                        countMouseClicks = 0;
                    }
                }
                //if ((countMouseClicks % 2) == 0)
                //{
                    prevColIdx = colIdx;
                //}

                if (colIdx == 2)
                {
                    if ((countMouseClicks % 2) == 0 && prevColIdx == colIdx)
                    {
                        colName = "ProjectCode";
                    }
                    else if ((countMouseClicks % 2) != 0 && prevColIdx != colIdx)
                    {
                        colName = "ProjectCode DESC";
                    }
                    else if ((countMouseClicks % 2) != 0 && prevColIdx == colIdx)
                    {
                        colName = "ProjectCode DESC";
                    }
                }
                else if (colIdx == 3)
                {
                    if ((countMouseClicks % 2) == 0 && prevColIdx == colIdx)
                    {
                        colName = "ProjectTitle ASC";
                    }
                    else if ((countMouseClicks % 2) != 0 && prevColIdx != colIdx)
                    {
                        colName = "ProjectTitle DESC";
                    }
                    else if ((countMouseClicks % 2) != 0 && prevColIdx == colIdx)
                    {
                        colName = "ProjectTitle DESC";
                    }
                }
                else if (colIdx == 4)
                {
                    if ((countMouseClicks % 2) == 0 && prevColIdx == colIdx)
                    {
                        colName = "TenderNo ASC";
                    }
                    else if ((countMouseClicks % 2) != 0 && prevColIdx != colIdx)
                    {
                        colName = "TenderNo DESC";
                    }
                    else if ((countMouseClicks % 2) != 0 && prevColIdx == colIdx)
                    {
                        colName = "TenderNo DESC";
                    }
                }
                else if (colIdx == 5)
                {
                    if ((countMouseClicks % 2) == 0 && prevColIdx == colIdx)
                    {
                        colName = "CurrentStage ASC";
                    }
                    else if ((countMouseClicks % 2) != 0 && prevColIdx != colIdx)
                    {
                        colName = "CurrentStage DESC";
                    }
                    else if ((countMouseClicks % 2) != 0 && prevColIdx == colIdx)
                    {
                        colName = "CurrentStage DESC";
                    }
                }
                else if (colIdx == 6)
                {
                    if ((countMouseClicks % 2) == 0 && prevColIdx == colIdx)
                    {
                        colName = "TenderStatus ASC";
                    }
                    else if ((countMouseClicks % 2) != 0 && prevColIdx != colIdx)
                    {
                        colName = "TenderStatus DESC";
                    }
                    else if ((countMouseClicks % 2) != 0 && prevColIdx == colIdx)
                    {
                        colName = "TenderStatus DESC";
                    }
                }
                else if (colIdx == 7)
                {
                    if ((countMouseClicks % 2) == 0 && prevColIdx == colIdx)
                    {
                        colName = "TypeOfTender ASC";
                    }
                    else if ((countMouseClicks % 2) != 0 && prevColIdx != colIdx)
                    {
                        colName = "TypeOfTender DESC";
                    }
                    else if ((countMouseClicks % 2) != 0 && prevColIdx == colIdx)
                    {
                        colName = "TypeOfTender DESC";
                    }
                }
                else if (colIdx == 8)
                {
                    if ((countMouseClicks % 2) == 0 && prevColIdx == colIdx)
                    {
                        colName = "TenderCommittee ASC";
                    }
                    else if ((countMouseClicks % 2) != 0 && prevColIdx != colIdx)
                    {
                        colName = "TenderCommittee DESC";
                    }
                    else if ((countMouseClicks % 2) != 0 && prevColIdx == colIdx)
                    {
                        colName = "TenderCommittee DESC";
                    }
                }
                else if (colIdx == 9)
                {
                    if ((countMouseClicks % 2) == 0 && prevColIdx == colIdx)
                    {
                        colName = "TypeofContract ASC";
                    }
                    else if ((countMouseClicks % 2) != 0 && prevColIdx != colIdx)
                    {
                        colName = "TypeofContract DESC";
                    }
                    else if ((countMouseClicks % 2) != 0 && prevColIdx == colIdx)
                    {
                        colName = "TypeofContract DESC";
                    }
                }
                else if (colIdx == 10)
                {
                    if ((countMouseClicks % 2) == 0 && prevColIdx == colIdx)
                    {
                        colName = "ContractNo ASC";
                    }
                    else if ((countMouseClicks % 2) != 0 && prevColIdx != colIdx)
                    {
                        colName = "ContractNo DESC";
                    }
                    else if ((countMouseClicks % 2) != 0 && prevColIdx == colIdx)
                    {
                        colName = "ContractNo DESC";
                    }
                }
                else if (colIdx == 11)
                {
                    if ((countMouseClicks % 2) == 0 && prevColIdx == colIdx)
                    {
                        colName = "FiscalYear ASC";
                    }
                    else if ((countMouseClicks % 2) != 0 && prevColIdx != colIdx)
                    {
                        colName = "FiscalYear DESC";
                    }
                    else if ((countMouseClicks % 2) != 0 && prevColIdx == colIdx)
                    {
                        colName = "FiscalYear DESC";
                    }
                }
                else if (colIdx == 12)
                {
                    if ((countMouseClicks % 2) == 0 && prevColIdx == colIdx)
                    {
                        colName = "UserDepartment ASC";
                    }
                    else if ((countMouseClicks % 2) != 0 && prevColIdx != colIdx)
                    {
                        colName = "UserDepartment DESC";
                    }
                    else if ((countMouseClicks % 2) != 0 && prevColIdx == colIdx)
                    {
                        colName = "UserDepartment DESC";
                    }
                }                 
                else if (colIdx == 13)
                {
                    if ((countMouseClicks % 2) == 0 && prevColIdx == colIdx)
                    {
                        colName = "CreateDate ASC";
                    }
                    else if ((countMouseClicks % 2) != 0 && prevColIdx != colIdx)
                    {
                        colName = "CreateDate DESC";
                    }
                    else if ((countMouseClicks % 2) != 0 && prevColIdx == colIdx)
                    {
                        colName = "CreateDate DESC";
                    }
                }
                else if (colIdx == 14)
                {
                    if ((countMouseClicks % 2) == 0 && prevColIdx == colIdx)
                    {
                        colName = "LastModifiedDate ASC";
                    }
                    else if ((countMouseClicks % 2) != 0 && prevColIdx != colIdx)
                    {
                        colName = "LastModifiedDate DESC";
                    }
                    else if ((countMouseClicks % 2) != 0 && prevColIdx == colIdx)
                    {
                        colName = "LastModifiedDate DESC";
                    }
                }
                else if (colIdx == 15)
                {
                    if ((countMouseClicks % 2) == 0 && prevColIdx == colIdx)
                    {
                        colName = "MozanahID ASC";
                    }
                    else if ((countMouseClicks % 2) != 0 && prevColIdx != colIdx)
                    {
                        colName = "MozanahID DESC";
                    }
                    else if ((countMouseClicks % 2) != 0 && prevColIdx == colIdx)
                    {
                        colName = "MozanahID DESC";
                    }
                }

                if (colIdx != 0)
                {
                    if (whereClauseForFilter == null)
                    {
                        if (dtCmbTbl != null)
                        {
                            FillAllProjectsInformation(' ');
                        }
                        else
                        {
                            FillAllProjectsInformation('R');
                        }
                    }
                    else
                    {
                        FillAllProjectsInformation(' ');
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while displaying data" + ex.Message);
            }                        
            
        }     

        private void txtPrjTitle_TextChanged(object sender, EventArgs e)
        {
            if (dtTemp != null)
            {                 
                isNewItemSelected = true;
                filterCombo();                
            }
        }

        private void cmbQs_SelectionChangeCommitted(object sender, EventArgs e)
        {            
            filterCombo();        
        }

        private void cmbQs_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                filterCombo();
            }
        }

        private void cmbTndrHndl_SelectionChangeCommitted(object sender, EventArgs e)
        {
            filterCombo();
        }

        private void cmbTndrHndl_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                filterCombo();
            }
        }

        private void cmbStaff_SelectionChangeCommitted(object sender, EventArgs e)
        {
            filterCombo();
        }

        private void cmbStaff_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                filterCombo();
            }
        } 
    }
}
