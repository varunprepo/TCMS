﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using MDI_ParenrForm.Admin;
using MDI_ParenrForm.Reports;
using MDI_ParenrForm;
using MDI_ParenrForm.Documents;
using TenderTrackingSystem;
using System.Reflection;
//using System.Windows.Forms.DataVisualization.Charting;

namespace MDI_ParenrForm
{
    public partial class dashBoardParent : Form
    {
        private int childFormNumber = 0;
        IList<string> userRightsColl = new List<string>();
        private string strCon = ConfigurationManager.AppSettings["TCMSConnString"].ToString();
        SqlConnection cn = new SqlConnection();

        public static string _userName = string.Empty;
        public static string _userID = string.Empty;
        string _profileName = string.Empty;
        bool _isHeadOfSection = false; // Added by Varun on 11/Jun/15

        public dashBoardParent(string userName, bool isHeadOfSection)
        {             
            InitializeComponent();
            if (userName!="")
            _userName = userName;
            userRightsColl = getUserAccessList(ref _profileName);
            lblUserName.Text = userName;
            _isHeadOfSection = isHeadOfSection;
        }
        private IList<string> getUserAccessList(ref string profileName)
        {
            userRightsColl.Clear();
            SqlConnection sqlConn = new SqlConnection(strCon);

            string sqlQuery = "SELECT distinct UserAccessRights.AccessID,UserAccessRights.[AccessRights], UserPrivelege.HasPrivelege, UserPrivelege.user_profile_id, UserSecurityProfile.profile_name, USERS.user_id, " +
            " USERS.user_name FROM UserAccessRights INNER JOIN UserPrivelege ON UserAccessRights.AccessID = UserPrivelege.AccessID INNER JOIN " +
            " UserSecurityProfile ON UserPrivelege.user_profile_id = UserSecurityProfile.user_profile_id INNER JOIN " +
            " USERS ON UserSecurityProfile.user_profile_id = USERS.user_profile_id WHERE (UserPrivelege.HasPrivelege = 0) AND (USERS.user_name = '" + _userName + "') ORDER BY UserAccessRights.AccessID";

            try
            {
                sqlConn.Open();
                SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
                SqlDataReader sqlReader = sqlCom.ExecuteReader();
                while (sqlReader.Read())
                {
                    userRightsColl.Add(sqlReader[0].ToString());
                    _profileName = sqlReader[4].ToString();
                }
                sqlReader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error getting while reading data !" + ex.Message);
            }
            {
                sqlConn.Close();
            }
            return userRightsColl;
        }
        private void ShowNewForm(object sender, EventArgs e)
        {
            Form childForm = new Form();
            childForm.MdiParent = this;
            childForm.Text = "Window " + childFormNumber++;
            childForm.Show();
        }
        private void OpenFile(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = openFileDialog.FileName;
            }
        }
        private void SaveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            saveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = saveFileDialog.FileName;
            }
        }
        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void CutToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }
        private void CopyToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }
        private void PasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
        } 
        private void CascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }
        private void TileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }
        private void TileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }
        private void ArrangeIconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.ArrangeIcons);
        }
        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }
        private void toolStripLabel1_Click(object sender, EventArgs e)
        {

        }
        private void btnProjects_Click(object sender, EventArgs e)
        {
            //MDI_ParenrForm.TMS_MainView mainView = new MDI_ParenrForm.TMS_MainView(_userName, btnProjects);
            MDI_ParenrForm.TMS_MainView mainView = new MDI_ParenrForm.TMS_MainView(_userName, btnProjects, _isHeadOfSection);
            mainView.Show();
            this.Hide();
        }
        private void dashBoardParent_Load(object sender, EventArgs e)
        {
            if (_profileName.Equals("Contracts Services Section") || _profileName.Equals("Administrator") || _profileName.Equals("VIEW ALL") || _isHeadOfSection)   //Add New Project
            {
                chartTenderDocsUnderPreparation.Visible = true;
            }           
            else
            {
                chartTenderDocsUnderPreparation.Visible = false;
            }          
 
            //textBox1.Text = "QR";
            //textBox1.SelectionStart = textBox1.Text.Length;

            if (!strCon.Contains("PWA_TCMS_DBT"))
            {
                label4.Text = "Test Database";
            }
            else
            {
                label4.Visible = false;
            }

            AutomaticUpdateDocumentStatus();         

            LoadChartData();

            if (lblUserName.Text == "")
                lblUserName.Text = _userName;
        }
        private void lnkAddProject_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (userRightsColl.Contains("1"))   //Add New Project
            {
                MessageBox.Show("You have no privilege to add project,Contact administrator");
                return;
            }

            MDI_ParenrForm.Projects.frmProjectInfo frmProj = new MDI_ParenrForm.Projects.frmProjectInfo(userRightsColl, _userName, _isHeadOfSection);
            frmProj.StartPosition = FormStartPosition.CenterParent;
            frmProj.ShowDialog();
        }
        private void lnkCompany_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (userRightsColl.Contains("25"))   //Add New Company
            {
                MessageBox.Show("You have no privilege to add project,Contact administrator");
                return;
            }

            TenderTrackingSystem.Contacts.frmAddCompanyInfo frmCmp = new TenderTrackingSystem.Contacts.frmAddCompanyInfo(userRightsColl, 0, _userName, _isHeadOfSection);
            frmCmp.StartPosition = FormStartPosition.CenterParent;
            frmCmp.ShowDialog();
        }
        private void lnkContacts_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (userRightsColl.Contains("26"))   //Add New Company
            {
                MessageBox.Show("You have no privilege to add project,Contact administrator");
                return;
            }
            TenderTrackingSystem.Contacts.frmContactPerson frmPerson = new TenderTrackingSystem.Contacts.frmContactPerson(userRightsColl, _userName, _isHeadOfSection);
            frmPerson.StartPosition = FormStartPosition.CenterParent;
            frmPerson.ShowDialog();
        }
        private void lnkViewProjects_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (userRightsColl.Contains("3"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }
            foreach (Control aControl in this.Controls)
            {
                if (aControl is Panel)
                {
                    if (aControl.Name.Equals("panelForDashboard"))
                    {
                        aControl.Visible = false;
                    }
                }
            }
            this.Close();
            //TMS_MainView frmPrjView = new TMS_MainView(_userName);
            TMS_MainView frmPrjView = new TMS_MainView(_userName, _isHeadOfSection);
            frmPrjView.SetBtnName("All Projects");
            frmPrjView.StartPosition = FormStartPosition.CenterParent;
            frmPrjView.ShowDialog();
        }
        private void lnkOngoingProjects_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (userRightsColl.Contains("13"))   //View On-going Contracts
            {
                MessageBox.Show("You have no privilege to add project,Contact administrator");
                return;
            }
            foreach (Control aControl in this.Controls)
            {
                if (aControl is Panel)
                {
                    if (aControl.Name.Equals("panelForDashboard"))
                    {
                        aControl.Visible = false;
                    }
                }
            }
            MDI_ParenrForm.Projects.frmOngoingContracts frmOngoingPrj = new MDI_ParenrForm.Projects.frmOngoingContracts(userRightsColl, _userName, _isHeadOfSection,null);
            frmOngoingPrj.StartPosition = FormStartPosition.CenterParent;
            frmOngoingPrj.ShowDialog();
        }
        private void lnkInactive_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (userRightsColl.Contains("14"))   //View Inactive Contracts
            {
                MessageBox.Show("You have no privilege to add project,Contact administrator");
                return;
            }
            foreach (Control aControl in this.Controls)
            {
                if (aControl is Panel)
                {
                    if (aControl.Name.Equals("panelForDashboard"))
                    {
                        aControl.Visible = false;
                    }
                }
            }

            MDI_ParenrForm.Projects.frmInactiveProjects frmInactivePrj = new MDI_ParenrForm.Projects.frmInactiveProjects(userRightsColl, _userName, _isHeadOfSection);
            frmInactivePrj.StartPosition = FormStartPosition.CenterParent;
            frmInactivePrj.ShowDialog();
        }

        DataSet ds = null;
        private void LoadChartData()
        {
            cn.ConnectionString = strCon;
            cn.Open();
            SqlDataAdapter sqlDataAdapter = null;           

            if (!userRightsColl.Contains("84"))
            {
                sqlDataAdapter = new SqlDataAdapter("SELECT FYID,FiscalYear FROM [FiscalYear]", cn);
                ds = new DataSet();
                sqlDataAdapter.Fill(ds);
                cmbFinancialYears.Items.Clear();
                cmbFinancialYears.DataSource = ds.Tables[0];
                cmbFinancialYears.DisplayMember = "FiscalYear";
                cmbFinancialYears.ValueMember = "FYID";
                cmbFinancialYears.SelectedIndex = -1;
                cmbFinancialYears.SelectedValue = 13; // Added by Varun on 22Nov2015
                ds.Tables.Clear();
                ChartFor_ApprovedTenderDocuments();
                ChartFor_TenderDocsUnderPreparation();
            }
            else
            {
                lblFinancialYear.Visible = false;
                cmbFinancialYears.Visible = false;
                btnRefreshTenderDocsApproved.Visible = false;
                label1.Visible = false;
                ChartPrepDocsApproved.Visible = false;
                chartTenderDocsUnderPreparation.Visible = false;
            }
            if (!userRightsColl.Contains("85"))
            {
                sqlDataAdapter = new SqlDataAdapter("SELECT committee_id,committee_name FROM [committee]", cn);
                ds = new DataSet();
                sqlDataAdapter.Fill(ds);
                cmbCommitteNames.Items.Clear();
                cmbCommitteNames.DataSource = ds.Tables[0];
                cmbCommitteNames.DisplayMember = "committee_name";
                cmbCommitteNames.ValueMember = "committee_id";
                cmbCommitteNames.SelectedIndex = -1;
                ds.Tables.Clear();                
                ChartFor_TotalProjectsPerTenderStatus();
            }
            else
            {
                label2.Visible = false;
                cmbCommitteNames.Visible = false;
                btnRefreshTotalProjectsPerTenderStatus.Visible = false;
                ChartProjects.Visible = false;
            }

            if (!userRightsColl.Contains("86"))
            {
                // Added by Varun on 22Nov2015
                sqlDataAdapter = new SqlDataAdapter("SELECT committee_id,committee_name FROM [committee]", cn);
                ds = new DataSet();
                sqlDataAdapter.Fill(ds);
                cmbCmteNamesForNumberOfTenders.Items.Clear();
                cmbCmteNamesForNumberOfTenders.DataSource = ds.Tables[0];
                cmbCmteNamesForNumberOfTenders.DisplayMember = "committee_name";
                cmbCmteNamesForNumberOfTenders.ValueMember = "committee_id";
                cmbCmteNamesForNumberOfTenders.SelectedIndex = -1;
                ds.Tables.Clear();

                // Added by Varun on 22Nov2015
                sqlDataAdapter = new SqlDataAdapter("SELECT FYID,FiscalYear FROM [FiscalYear]", cn);
                ds = new DataSet();
                sqlDataAdapter.Fill(ds);
                cmbFYForNumberOfTenders.Items.Clear();
                cmbFYForNumberOfTenders.DataSource = ds.Tables[0];
                cmbFYForNumberOfTenders.DisplayMember = "FiscalYear";
                cmbFYForNumberOfTenders.ValueMember = "FYID";
                cmbFYForNumberOfTenders.SelectedIndex = -1;
                cmbFYForNumberOfTenders.SelectedValue = 13;
                ds.Tables.Clear();

                sqlDataAdapter = new SqlDataAdapter("SELECT committee_id,committee_name FROM [committee]", cn);
                ds = new DataSet();
                sqlDataAdapter.Fill(ds);
                cmbCmteNamesForTotalContractAmounts.Items.Clear();
                cmbCmteNamesForTotalContractAmounts.DataSource = ds.Tables[0];
                cmbCmteNamesForTotalContractAmounts.DisplayMember = "committee_name";
                cmbCmteNamesForTotalContractAmounts.ValueMember = "committee_id";
                cmbCmteNamesForTotalContractAmounts.SelectedIndex = -1;
                ds.Tables.Clear();

                 // Added by Varun on 31Jan2015
                sqlDataAdapter = new SqlDataAdapter("SELECT FYID,FiscalYear FROM [FiscalYear]", cn);
                ds = new DataSet();
                sqlDataAdapter.Fill(ds);
                cmbFYTotValTenderAwardsPerCommt.Items.Clear();
                cmbFYTotValTenderAwardsPerCommt.DataSource = ds.Tables[0];
                cmbFYTotValTenderAwardsPerCommt.DisplayMember = "FiscalYear";
                cmbFYTotValTenderAwardsPerCommt.ValueMember = "FYID";
                //cmbFYTotProjPerTenderStatus.SelectedIndex = -1;
                cmbFYTotValTenderAwardsPerCommt.SelectedValue = ConfigurationManager.AppSettings["CurrentFY"].ToString();
                ds.Tables.Clear();                
                DataRowView dtFYView = (DataRowView)cmbFYTotValTenderAwardsPerCommt.SelectedItem;                
                CommitteeWiseTenderCount(null, null);
                TotalAmountOfContractsPerCommittee(null,dtFYView.Row.ItemArray[1].ToString());
            }
            else
            {                
                label5.Visible = false;
                cmbCmteNamesForNumberOfTenders.Visible = false;
                label6.Visible = false;
                cmbFYForNumberOfTenders.Visible = false;
                btnRefreshNumberOfTenderEachYear.Visible = false;
                chartTendersPerYearPerCommittee.Visible = false;
                label7.Visible = false;
                cmbCmteNamesForTotalContractAmounts.Visible = false;                 
                chartTotalAmountOfContractsPerCommittee.Visible = false;
                cmbFYTotValTenderAwardsPerCommt.Visible = false;
                btnRefreshTotValTenderAwardsPerCommt.Visible = false;
                lblFYTotValTenderAwardsPerCommt.Visible = false;
            }
            cn.Close();
        }


        private void ChartFor_ApprovedTenderDocuments()
        {
            try
            {
                string strQuery = "SELECT COUNT(TenderDatesInfo.ptd_tendec_doc_cur_status) AS ApprovedCount, dp2.department_short_name FROM TenderDatesInfo INNER JOIN PROJECTS ON TenderDatesInfo.proj_id = PROJECTS.proj_id INNER JOIN FiscalYear ON PROJECTS.FYID = FiscalYear.FYID INNER JOIN " +
                "Department2 AS dp1 ON PROJECTS.department_id = dp1.department_id INNER JOIN Department2 AS dp2 ON dp1.newDepID = dp2.department_id WHERE (TenderDatesInfo.ptd_tendec_doc_cur_status = N'Approved') AND (TenderDatesInfo.stage_id = 1) AND (FiscalYear.FYID=13) GROUP BY TenderDatesInfo.ptd_tendec_doc_cur_status, dp2.department_short_name"; // FYID=13 is 2014-2015

                SqlDataAdapter da1 = new SqlDataAdapter(strQuery, cn);
                da1.Fill(ds);
                ChartPrepDocsApproved.DataSource = ds.Tables[0].DefaultView;
                ChartPrepDocsApproved.Series["PrepDocsApproved"].XValueMember = "department_short_name";
                ChartPrepDocsApproved.Series["PrepDocsApproved"].YValueMembers = "ApprovedCount";
                ds.Tables.Clear();
                ChartPrepDocsApproved.Width = 1550;
                ChartPrepDocsApproved.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
                ChartPrepDocsApproved.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
                ChartPrepDocsApproved.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
                ChartPrepDocsApproved.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

                ChartPrepDocsApproved.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
                ChartPrepDocsApproved.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;
                ChartPrepDocsApproved.ChartAreas[0].AxisX.Interval = 1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while displaying the Number Of Tender Documents Approved Each Year Chart", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ChartFor_TotalProjectsPerTenderStatus()
        {
            try
            {
                string strQuery2 = "SELECT COUNT(PROJECTS.proj_id) AS PrjCnt,[TenderStatus].[Status_Name] AS Status, [TenderStatus].Tender_Status_id " +
                " FROM PROJECTS INNER JOIN [TenderStatus] ON PROJECTS.Tender_Status_id = [TenderStatus].Tender_Status_id WHERE (PROJECTS.isDeleted = 0) GROUP BY [TenderStatus].[Status_Name], [TenderStatus].Tender_Status_id " +
                " HAVING ([TenderStatus].[Tender_Status_id] <> 8) and ([TenderStatus].[Tender_Status_id] <> 9) AND ([TenderStatus].[Tender_Status_id] <> 10) AND ([TenderStatus].[Tender_Status_id] <> 11) ORDER BY [TenderStatus].Tender_Status_id ASC ";
                SqlDataAdapter da2 = new SqlDataAdapter(strQuery2, cn);
                da2.Fill(ds);
                ChartProjects.Width = 1100;
                ChartProjects.DataSource = ds.Tables[0].DefaultView;
                ChartProjects.Series["Tender Status"].XValueMember = "Status";
                ChartProjects.Series["Tender Status"].YValueMembers = "PrjCnt";
                ds.Tables.Clear();

                ChartProjects.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
                ChartProjects.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
                ChartProjects.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
                ChartProjects.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

                ChartProjects.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
                ChartProjects.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;
                ChartProjects.ChartAreas[0].AxisX.Interval = 1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while displaying the Total Projects Per Tender Status Chart", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void ChartFor_TenderDocsUnderPreparation()
        {
            try
            {
                DataSet dsTndr = new DataSet();

                string sqlQuery = "SELECT COUNT(dp2.department_short_name) AS ProjectCount, TenderDatesInfo.ptd_assign_qs FROM TenderDatesInfo INNER JOIN PROJECTS ON TenderDatesInfo.proj_id = PROJECTS.proj_id INNER JOIN " +
                "Department2 AS dp1 ON PROJECTS.department_id = dp1.department_id INNER JOIN Department2 AS dp2 ON dp1.newDepID = dp2.department_id WHERE (TenderDatesInfo.ptd_qs_working_status = 'On-going') AND (TenderDatesInfo.stage_id = 1) AND (PROJECTS.isDeleted = 0 OR PROJECTS.isDeleted IS NULL) " +
                "GROUP BY TenderDatesInfo.ptd_assign_qs";

                SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, cn);
                daTndr.Fill(dsTndr);
                if (dsTndr.Tables[0].Rows.Count>0)
                {
                    chartTenderDocsUnderPreparation.Visible = true;
                }
                chartTenderDocsUnderPreparation.DataSource = dsTndr.Tables[0].DefaultView;
                chartTenderDocsUnderPreparation.Series["Ongoing Tenders"].XValueMember = "ptd_assign_qs";
                chartTenderDocsUnderPreparation.Series["Ongoing Tenders"].YValueMembers = "ProjectCount";
                dsTndr.Tables.Clear();
                chartTenderDocsUnderPreparation.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
                chartTenderDocsUnderPreparation.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
                chartTenderDocsUnderPreparation.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
                chartTenderDocsUnderPreparation.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

                chartTenderDocsUnderPreparation.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
                chartTenderDocsUnderPreparation.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;
                chartTenderDocsUnderPreparation.ChartAreas[0].AxisX.Interval = 1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while displaying the Tender Documents Under Preparation Chart", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void TotalAmountOfContractsPerCommittee(string cmtIDSelectedValue, string fiscalYear)
        {
            try
            {
                DataSet dsTndr = new DataSet();

                string sqlQuery = null;
                if(fiscalYear.Contains("-"))
                {
                    fiscalYear = fiscalYear.Split('-')[0].ToString();
                }
                
                if (cmtIDSelectedValue == null)
                {
                    //if (fiscalYear == "15")
                    //{
                    
                    sqlQuery = "SELECT Format(SUM(CONTRACTORS.ContractAmount) / 1000000.00, 'N') AS TotalContractAmount, '" + fiscalYear + "' AS FiscalYear FROM CONTRACTORS INNER JOIN PROJECTS ON CONTRACTORS.proj_id = PROJECTS.proj_id INNER JOIN " +
                    "Committee ON PROJECTS.committee_id = Committee.committee_id WHERE (CONTRACTORS.cp_tender_award IS NOT NULL) AND (CONTRACTORS.ContractAmount IS NOT NULL) AND (CONTRACTORS.ContractAmount <> 0) AND (Committee.committee_id IN " +
                    "(SELECT Committee.committee_id AS Expr1 FROM Committee AS Committee_1)) AND YEAR(CONTRACTORS.cp_tender_award) = '"+fiscalYear+"'";
                    //}
                    //else
                    //{
                    //    sqlQuery = "SELECT Format(SUM(CONTRACTORS.ContractAmount)/1000000.00, 'N') AS TotalContractAmount, PROJECTS.project_code FROM CONTRACTORS INNER JOIN PROJECTS ON CONTRACTORS.proj_id = PROJECTS.proj_id INNER JOIN " +
                    //    "FiscalYear ON PROJECTS.FYID = FiscalYear.FYID INNER JOIN Committee ON PROJECTS.committee_id = Committee.committee_id WHERE (CONTRACTORS.cp_tender_award IS NOT NULL) AND (CONTRACTORS.ContractAmount IS NOT NULL) AND (CONTRACTORS.ContractAmount <> 0) " +
                    //    "and (Committee.committee_id IN (SELECT Committee.committee_id AS Expr1 FROM Committee AS Committee_1)) AND (FiscalYear.FYID =" + fiscalYear + ") GROUP BY PROJECTS.project_code";
                    //}
                }
                else if (cmtIDSelectedValue != null)
                {
                    sqlQuery = "SELECT Format(SUM(CONTRACTORS.ContractAmount)/1000000.00, 'N') AS TotalContractAmount, '" + fiscalYear + "' AS FiscalYear FROM CONTRACTORS INNER JOIN PROJECTS ON CONTRACTORS.proj_id = PROJECTS.proj_id INNER JOIN " +
                    "Committee ON PROJECTS.committee_id = Committee.committee_id WHERE (CONTRACTORS.cp_tender_award IS NOT NULL) AND (CONTRACTORS.ContractAmount IS NOT NULL) AND (CONTRACTORS.ContractAmount <> 0) " +
                    "and (Committee.committee_id=" + cmtIDSelectedValue + ") AND YEAR(CONTRACTORS.cp_tender_award) = '"+fiscalYear+"'";
                }

                SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, cn);
                daTndr.Fill(dsTndr);
                chartTotalAmountOfContractsPerCommittee.Width = 1100;
                chartTotalAmountOfContractsPerCommittee.DataSource = dsTndr.Tables[0].DefaultView;
                chartTotalAmountOfContractsPerCommittee.Series["Total ContractAmount"].XValueMember = "FiscalYear";
                chartTotalAmountOfContractsPerCommittee.Series["Total ContractAmount"].YValueMembers = "TotalContractAmount";
                dsTndr.Tables.Clear();

                chartTotalAmountOfContractsPerCommittee.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
                chartTotalAmountOfContractsPerCommittee.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
                chartTotalAmountOfContractsPerCommittee.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
                chartTotalAmountOfContractsPerCommittee.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

                chartTotalAmountOfContractsPerCommittee.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
                chartTotalAmountOfContractsPerCommittee.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;

                chartTotalAmountOfContractsPerCommittee.ChartAreas[0].AxisX.Interval = 1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while displaying the Total Amount Of Contracts Per Committee Chart", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CommitteeWiseTenderCount(string cmtIDSelectedValue, string fySelectedValue)
        {            
            try
            {
                string strQuery = null;
                if(cmtIDSelectedValue==null && fySelectedValue==null)
                    strQuery = "SELECT COUNT(PROJECTS.proj_id) AS TenderCounts, Committee.committee_short_name FROM PROJECTS INNER JOIN Committee ON PROJECTS.committee_id = Committee.committee_id INNER JOIN FiscalYear ON PROJECTS.FYID = FiscalYear.FYID WHERE (PROJECTS.tender_no <> '') AND (PROJECTS.tender_no IS NOT NULL) " +
                    "and (Committee.committee_id IN (SELECT committee_id FROM Committee AS Committee_1)) AND (FiscalYear.FYID=13) GROUP BY PROJECTS.committee_id, Committee.committee_short_name"; // FYID=13 is 2014-2015             
                else if (cmtIDSelectedValue != null && fySelectedValue != null)
                    strQuery = "SELECT COUNT(PROJECTS.proj_id) AS TenderCounts, Committee.committee_short_name FROM PROJECTS INNER JOIN Committee ON PROJECTS.committee_id = Committee.committee_id INNER JOIN FiscalYear ON PROJECTS.FYID = FiscalYear.FYID WHERE (PROJECTS.tender_no <> '') AND (PROJECTS.tender_no IS NOT NULL) " +
                    "and (Committee.committee_id=" + cmtIDSelectedValue + ") AND (FiscalYear.FYID = " + fySelectedValue + ") GROUP BY PROJECTS.committee_id, Committee.committee_short_name";
                else if (cmtIDSelectedValue == null && fySelectedValue != null)
                    strQuery = "SELECT COUNT(PROJECTS.proj_id) AS TenderCounts, Committee.committee_short_name FROM PROJECTS INNER JOIN Committee ON PROJECTS.committee_id = Committee.committee_id INNER JOIN FiscalYear ON PROJECTS.FYID = FiscalYear.FYID WHERE (PROJECTS.tender_no <> '') AND (PROJECTS.tender_no IS NOT NULL) " +
                    "and (Committee.committee_id IN (SELECT committee_id FROM Committee AS Committee_1)) AND (FiscalYear.FYID = " + fySelectedValue + ") GROUP BY PROJECTS.committee_id, Committee.committee_short_name";
                else if (cmtIDSelectedValue != null && fySelectedValue == null)
                    strQuery = "SELECT COUNT(PROJECTS.proj_id) AS TenderCounts, Committee.committee_short_name FROM PROJECTS INNER JOIN Committee ON PROJECTS.committee_id = Committee.committee_id INNER JOIN FiscalYear ON PROJECTS.FYID = FiscalYear.FYID WHERE (PROJECTS.tender_no <> '') AND (PROJECTS.tender_no IS NOT NULL) " +
                    "and (Committee.committee_id=" + cmtIDSelectedValue + ") AND (FiscalYear.FYID IN (SELECT FYID AS Expr1 FROM FiscalYear AS FiscalYear_1)) GROUP BY PROJECTS.committee_id, Committee.committee_short_name";

                SqlDataAdapter da2 = new SqlDataAdapter(strQuery, cn);
                DataSet ds = new DataSet();
                da2.Fill(ds);             
                chartTendersPerYearPerCommittee.DataSource = ds.Tables[0].DefaultView;              
                chartTendersPerYearPerCommittee.Width = 800;
                chartTendersPerYearPerCommittee.Series["Tender Count"].XValueMember = "committee_short_name";
                chartTendersPerYearPerCommittee.Series["Tender Count"].YValueMembers = "TenderCounts";
                ds.Tables.Clear();
                chartTendersPerYearPerCommittee.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
                chartTendersPerYearPerCommittee.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
                chartTendersPerYearPerCommittee.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
                chartTendersPerYearPerCommittee.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

                chartTendersPerYearPerCommittee.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
                chartTendersPerYearPerCommittee.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;
                chartTendersPerYearPerCommittee.ChartAreas[0].AxisX.Interval = 1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while displaying the CommitteeWise TenderCount Chart", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void cmbTenderTypes_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
        private void btnTndrTypes_Click(object sender, EventArgs e)
        {
            cn.ConnectionString = strCon;
            cn.Open();            

            string strQuery = "SELECT  [DocumentStatus].doc_status_name, COUNT(DOCUMENTS.doc_status_id) AS DocCnt, [DocumentCategory].doc_category_id FROM DOCUMENTS INNER JOIN " +
            " [DocumentStatus] ON DOCUMENTS.doc_status_id = [DocumentStatus].doc_status_id INNER JOIN [DocumentCategory] ON DOCUMENTS.doc_category_id = [DocumentCategory].doc_category_id " +
            " GROUP BY [DocumentStatus].doc_status_name, [DocumentCategory].doc_category_id HAVING ([DocumentStatus].doc_status_name <> N'Closed') AND ([DocumentCategory].doc_category_id = 1)";

            SqlDataAdapter da1 = new SqlDataAdapter(strQuery, cn);
            DataSet ds = new DataSet();
            da1.Fill(ds);
            cn.Close();
            ChartPrepDocsApproved.DataSource = ds.Tables[0].DefaultView;
            ChartPrepDocsApproved.Series["Sent Documents"].XValueMember = "doc_status_name";
            ChartPrepDocsApproved.Series["Sent Documents"].YValueMembers = "DocCnt";
            ChartPrepDocsApproved.DataBind();
            ChartPrepDocsApproved.Visible = true;
            cmbFinancialYears.SelectedIndex = -1;
        }
        private void btnCommitte_Click(object sender, EventArgs e)
        {
            ChartFor_TotalProjectsPerTenderStatus();
        }
        static void MainDash()
        {
            //LoginForm fLogin = new LoginForm();
            //if (fLogin.ShowDialog() == DialogResult.OK)
            //{
            //    Application.Run(new MainForm());
            //}
            //else
            //{
            //    Application.Exit();
            //}
        }
        CommonClass cmnCls = new CommonClass("");
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmSwitchUser frmSwitch = new frmSwitchUser();
            frmSwitch.StartPosition = FormStartPosition.CenterScreen;
            frmSwitch.Show();

            cmnCls.Users_LogOut_System(lblUserName.Text);

            this.Hide();
        }
        private void lnkMouseOverStyle(LinkLabel lblName)
        {
            lblName.BackColor = Color.Yellow;
            // lblName.ForeColor = Color.Maroon;

            lblName.LinkColor = Color.Maroon;
            lblName.Font = new Font(lblName.Font, FontStyle.Bold);
        }
        private void lnkMouseLeaveStyle(LinkLabel lblName)
        {
            lblName.BackColor = Color.White;
            // lblName.ForeColor = Color.White;
            lblName.LinkColor = Color.Blue;
            lblName.Font = new Font(lblName.Font, FontStyle.Regular);
        }
        private void lnkAddProject_MouseHover(object sender, EventArgs e)
        {
            lnkMouseOverStyle(lnkAddProject);
        }
        private void lnkAddProject_MouseLeave(object sender, EventArgs e)
        {
            lnkMouseLeaveStyle(lnkAddProject);
        }
        private void lnkCompany_MouseHover(object sender, EventArgs e)
        {
            lnkMouseOverStyle(lnkCompany);
        }
        private void lnkCompany_MouseLeave(object sender, EventArgs e)
        {
            lnkMouseLeaveStyle(lnkCompany);
        }
        private void lnkContacts_MouseHover(object sender, EventArgs e)
        {
            lnkMouseOverStyle(lnkContacts);
        }
        private void lnkContacts_MouseLeave(object sender, EventArgs e)
        {
            lnkMouseLeaveStyle(lnkContacts);
        }
        private void lnkViewProjects_MouseHover(object sender, EventArgs e)
        {
            lnkMouseOverStyle(lnkViewProjects);
        }
        private void lnkViewProjects_MouseLeave(object sender, EventArgs e)
        {
            lnkMouseLeaveStyle(lnkViewProjects);
        }
        private void lnkOngoingProjects_MouseHover(object sender, EventArgs e)
        {
            lnkMouseOverStyle(lnkOngoingProjects);
        }
        private void lnkOngoingProjects_MouseLeave(object sender, EventArgs e)
        {
            lnkMouseLeaveStyle(lnkOngoingProjects);
        }
        private void lnkInactive_MouseHover(object sender, EventArgs e)
        {
            lnkMouseOverStyle(lnkInactive);
        }
        private void lnkInactive_MouseLeave(object sender, EventArgs e)
        {
            lnkMouseLeaveStyle(lnkInactive);
        }

        private void cmbCommitteNames_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }
        private void btnDocuments_Click(object sender, EventArgs e)
        {
            if (userRightsColl.Contains("18"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            this.Close();

            MDI_ParenrForm.TMS_MainView mainView = new MDI_ParenrForm.TMS_MainView(_userName, btnDocuments, _isHeadOfSection);
            mainView.Show(); 
        }
        List<string> AllProjects = new List<string>();
        List<string> Admin = new List<string>();
        List<string> Documents = new List<string>();
        List<string> Reports = new List<string>();
        List<string> Contacts = new List<string>();
        Button btn;

        private void CreateDynamicButtons(List<string> moduleData, string btnName)
        {
            int j = 0;
            for (int i = 0; i <= moduleData.Count - 1; i++)
            {
                if (btnName == "Contacts")
                {
                    j = j + 145;
                    btn = new Button();
                    btn.Location = new Point(295 + j, 1);         //478,9
                    btn.Size = new Size(148, 46);
                    btn.Text = moduleData[i];
                    btn.Font = new Font(btn.Font, FontStyle.Bold);

                    btn.FlatStyle = FlatStyle.Flat;
                    btn.FlatAppearance.BorderColor = Color.Maroon;
                    btn.FlatAppearance.MouseOverBackColor = Color.Maroon;

                    // btn.BackColor = Color.LightSlateGray;
                    btn.ForeColor = Color.DarkGray;

                    btn.Click += new EventHandler(btn_Click);
                    splitContainer1.Panel2.Controls.Add(btn);
                }
                else if (btnName == "Reports")
                {
                    j = j + 145;
                    btn = new Button();
                    btn.Location = new Point(444 + j, 1);         //478,9
                    btn.Size = new Size(148, 46);
                    btn.Text = moduleData[i];
                    btn.Font = new Font(btn.Font, FontStyle.Bold);

                    btn.FlatStyle = FlatStyle.Flat;
                    btn.FlatAppearance.BorderColor = Color.Maroon;
                    btn.FlatAppearance.MouseOverBackColor = Color.Maroon;

                    //  btn.BackColor = Color.LightSlateGray;
                    btn.ForeColor = Color.DarkGray;

                    btn.Click += new EventHandler(btn_Click);
                    splitContainer1.Panel2.Controls.Add(btn);
                }
                else if (btnName == "Admin")
                {
                    j = j + 147;
                    btn = new Button();
                    btn.Location = new Point(444 + j, 1);         //478,9
                    btn.Size = new Size(148, 46);
                    btn.Text = moduleData[i];
                    btn.Font = new Font(btn.Font, FontStyle.Bold);

                    btn.FlatStyle = FlatStyle.Flat;
                    btn.FlatAppearance.BorderColor = Color.Maroon;
                    btn.FlatAppearance.MouseOverBackColor = Color.Maroon;

                    //btn.BackColor = Color.LightSlateGray;
                    btn.ForeColor = Color.DarkGray;

                    btn.Click += new EventHandler(btn_Click);
                    splitContainer1.Panel2.Controls.Add(btn);
                }
                else
                {
                    j = j + 145;
                    btn = new Button();
                    btn.Location = new Point(1 + j, 1);         //478,9
                    btn.Size = new Size(148, 46);
                    btn.Text = moduleData[i];
                    btn.Font = new Font(btn.Font, FontStyle.Bold);

                    btn.FlatStyle = FlatStyle.Flat;
                    btn.FlatAppearance.BorderColor = Color.Maroon;
                    btn.FlatAppearance.MouseOverBackColor = Color.Maroon;     //SaddleBrown

                    // btn.BackColor = Color.LightSlateGray;
                    btn.ForeColor = Color.DarkGray;

                    btn.Click += new EventHandler(btn_Click);
                    splitContainer1.Panel2.Controls.Add(btn);
                }
            }
        }
        private void btn_Click(object sender, EventArgs e)
        {
            Button btnDummy = sender as Button;
            //btnDummy.ForeColor = Color.Tomato;

            // btnDummy.BackColor = Color.SaddleBrown;
            btnDummy.ForeColor = Color.WhiteSmoke;

            foreach (Control item in splitContainer1.Panel2.Controls)
            {
                Button chkBtn = item as Button;
                if (chkBtn.Text.Trim() != btnDummy.Text.Trim())
                {
                    chkBtn.ForeColor = Color.DarkGray;
                    chkBtn.BackColor = Color.Maroon;
                }
            }
            if (btnDummy.Text == "PWA Projects")
            {
                // Projects.DefaultProjects defaultPrj = new MDI_ParenrForm.Projects.DefaultProjects("Admin");

                if (userRightsColl.Contains("3"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }

                TenderTrackingSystem.DefaultView defaultPrj = new TenderTrackingSystem.DefaultView(userRightsColl, "Admin",_isHeadOfSection,null);
                defaultPrj.StartPosition = FormStartPosition.CenterParent;
                defaultPrj.ShowDialog();
            }
            if (btnDummy.Text == "Ongoing Contracts")
            {
                if (userRightsColl.Contains("13"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }
                MDI_ParenrForm.Projects.frmOngoingContracts OnGoingProjects = new MDI_ParenrForm.Projects.frmOngoingContracts(userRightsColl, _userName, _isHeadOfSection,null);
                OnGoingProjects.StartPosition = FormStartPosition.CenterParent;
                OnGoingProjects.ShowDialog();
            }
            if (btnDummy.Text == "Inactive Contracts")
            {
                if (userRightsColl.Contains("14"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }
                MDI_ParenrForm.Projects.frmInactiveProjects contractorInfo = new MDI_ParenrForm.Projects.frmInactiveProjects(userRightsColl, _userName, _isHeadOfSection);
                contractorInfo.StartPosition = FormStartPosition.CenterParent;
                contractorInfo.ShowDialog();
            }
            if (btnDummy.Text == "Company")
            {
                if (userRightsColl.Contains("13"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }
                MDI_ParenrForm.Contacts.frmCompanyContacts frmDef_Contacts = new MDI_ParenrForm.Contacts.frmCompanyContacts(userRightsColl, _userName);
                frmDef_Contacts.StartPosition = FormStartPosition.CenterScreen;
                frmDef_Contacts.ShowDialog();
            }
            if (btnDummy.Text == "Contacts")
            {
                if (userRightsColl.Contains("24"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }
                MDI_ParenrForm.frmContactsDefault frmDef_Contacts = new MDI_ParenrForm.frmContactsDefault(userRightsColl, _userName);
                frmDef_Contacts.StartPosition = FormStartPosition.CenterScreen;
                frmDef_Contacts.ShowDialog();
            }
            if (btnDummy.Text == "Communication")
            {
                if (userRightsColl.Contains("18"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }

                MDI_ParenrForm.Documents.frmCommunications frmComm = new MDI_ParenrForm.Documents.frmCommunications(userRightsColl, _userName);
                frmComm.StartPosition = FormStartPosition.CenterScreen;
                frmComm.ShowDialog();
            }
            if (btnDummy.Text == "Users")
            {
                if (userRightsColl.Contains("34"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }

                MDI_ParenrForm.Admin.frmUsers frmUserInfo = new MDI_ParenrForm.Admin.frmUsers(userRightsColl, _userName);
                frmUserInfo.StartPosition = FormStartPosition.CenterParent;
                frmUserInfo.ShowDialog();
            }
            if (btnDummy.Text == "Security Profiles")
            {
                if (userRightsColl.Contains("34"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }
                //frmSecurityProfile frmSecurityProfile = new frmSecurityProfile();
                //frmSecurityProfile.StartPosition = FormStartPosition.CenterParent;
                //frmSecurityProfile.ShowDialog();

                MDI_ParenrForm.Admin.frmSecurityProfile1 frmSecurityProfile = new MDI_ParenrForm.Admin.frmSecurityProfile1(userRightsColl);
                frmSecurityProfile.StartPosition = FormStartPosition.CenterParent;
                frmSecurityProfile.ShowDialog();
            }
        }
        private void btnContacts_Click(object sender, EventArgs e)
        {
            if (userRightsColl.Contains("24"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            this.Close();
            MDI_ParenrForm.TMS_MainView mainView = new MDI_ParenrForm.TMS_MainView(_userName, btnContacts, _isHeadOfSection);
            mainView.Show();
        }
        private void btnReports_Click(object sender, EventArgs e)
        {
            if (userRightsColl.Contains("28"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            this.Close();

            MDI_ParenrForm.TMS_MainView mainView = new MDI_ParenrForm.TMS_MainView(_userName, btnReports, _isHeadOfSection);
            mainView.Show();
        }
        private void btnAdmin_Click(object sender, EventArgs e)
        {
            if (userRightsColl.Contains("34"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            this.Close();

            MDI_ParenrForm.TMS_MainView mainView = new MDI_ParenrForm.TMS_MainView(_userName, btnAdmin, _isHeadOfSection);
            mainView.Show();
        }
        private void btnDashboard_Click(object sender, EventArgs e)
        {
             if (panelForDashboard.Visible == false)
                panelForDashboard.Visible = true;

            if (lblUserName.Text =="")
             lblUserName.Text = _userName;
        }

        private void chart1_DoubleClick(object sender, EventArgs e)
        {
            MessageBox.Show("This is Alert for TenderBond Expiry Projects");
        }

        // Commented By Varun on 22/11/2015
        //private void chart1_Click(object sender, EventArgs e)
        //{
        //    if (!userRightsColl.Contains("23"))
        //    {
        //        frmTenderExpiry frmTenderExpiry = new frmTenderExpiry(lblUserName.Text,_isHeadOfSection);
        //        frmTenderExpiry.StartPosition = FormStartPosition.CenterParent;
        //        frmTenderExpiry.ShowDialog();
        //    }
        //    else
        //    {
        //        MessageBox.Show("You don't have priviliges to view Expired Tender information,Please contact Administrator");
        //    }
        //}
        private void ChartReceived_DoubleClick(object sender, EventArgs e)
        {
            if (!userRightsColl.Contains("18"))
            {
                frmCommunications frmTenderExpiry = new frmCommunications(userRightsColl, lblUserName.Text, "dashBoardParent", _isHeadOfSection);
                frmTenderExpiry.StartPosition = FormStartPosition.CenterParent;
                frmTenderExpiry.ShowDialog();
            }
            else
            {
                MessageBox.Show("You don't have priviliges to view Documents information,Please contact Administrator");
            }
        }
        private void AutomaticUpdateDocumentStatus()
        {
            //  if Document issue date + days to act less than current date : make document status as For Follow Up
            //Modified by Varun doc_issue_date IS NOT NULL from doc_issue_date IS NULL         

            string sqlQuery = "SELECT doc_issue_date + days_to_act AS DocDate, doc_status_id, doc_id, CURRENT_TIMESTAMP AS Todaydate " +
            " FROM DOCUMENTS Where doc_status_id = 1 AND (doc_issue_date IS NOT NULL) and (doc_id is NULL) ORDER BY doc_status_id";

            DataSet dsDocStat = new DataSet();
            using (SqlConnection sqlConn = new SqlConnection(strCon))
            {
                sqlConn.Open();
                using (SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn))
                {
                    SqlDataAdapter daDocStatus = new SqlDataAdapter(sqlCom);
                    daDocStatus.Fill(dsDocStat);
                }
                sqlConn.Close();
            }

            for (int i = 0; i < dsDocStat.Tables[0].Rows.Count; i++)
            {
                DateTime docDate = Convert.ToDateTime(dsDocStat.Tables[0].Rows[i][0]);
                if (docDate < System.DateTime.Now)
                {
                    int docID = Convert.ToInt16(dsDocStat.Tables[0].Rows[i][2]);

                    string sqlQueryUpd = "UPDATE DOCUMENTS SET doc_status_id = 2 WHERE doc_id = " + docID + "";

                    using (SqlConnection sqlConn = new SqlConnection(strCon))
                    {
                        sqlConn.Open();
                        using (SqlCommand sqlCom = new SqlCommand(sqlQueryUpd, sqlConn))
                        {
                            sqlCom.ExecuteNonQuery();
                        }
                        sqlConn.Close();
                    }
                }
            }
        }
         
        private void dashBoardParent_FormClosing(object sender, FormClosingEventArgs e)
        {          
            //Added by Varun on 03 Feb 2014
            CommonClass cmnCls = new CommonClass(lblUserName.Text);
            cmnCls.Users_LogOut_System(lblUserName.Text);
            
            //}           
        }
        
        private void FillApprovedDocumentsChart()
        {
            if (cmbFinancialYears.SelectedIndex >= 0)
            {
                if (cn.State == ConnectionState.Closed)
                {
                    cn.ConnectionString = strCon;
                    cn.Open();
                }

                DataRowView dtFYView = (DataRowView)cmbFinancialYears.SelectedItem;
                string strQuery = "SELECT COUNT(TenderDatesInfo.ptd_tendec_doc_cur_status) AS ApprovedCount, dp2.department_short_name FROM TenderDatesInfo INNER JOIN PROJECTS ON TenderDatesInfo.proj_id = PROJECTS.proj_id INNER JOIN FiscalYear ON PROJECTS.FYID = FiscalYear.FYID INNER JOIN " +
                "Department2 AS dp1 ON PROJECTS.department_id = dp1.department_id INNER JOIN Department2 AS dp2 ON dp1.newDepID = dp2.department_id WHERE (TenderDatesInfo.ptd_tendec_doc_cur_status = N'Approved') AND (TenderDatesInfo.stage_id = 1) AND (FiscalYear.FYID = " + dtFYView.Row.ItemArray[0].ToString() + ") GROUP BY TenderDatesInfo.ptd_tendec_doc_cur_status, dp2.department_short_name";

                SqlDataAdapter da1 = new SqlDataAdapter(strQuery, cn);
                DataSet ds = new DataSet();
                da1.Fill(ds);
                cn.Close();
                ChartPrepDocsApproved.DataSource = ds.Tables[0].DefaultView;
                ChartPrepDocsApproved.Series["PrepDocsApproved"].XValueMember = "department_short_name";
                ChartPrepDocsApproved.Series["PrepDocsApproved"].YValueMembers = "ApprovedCount";
                ds.Tables.Clear();
                ChartPrepDocsApproved.DataBind();
                ChartPrepDocsApproved.Visible = true;
                ChartPrepDocsApproved.ChartAreas[0].AxisX.LabelStyle.Angle = 30;                            
            }
        }
        private void cmbCommitteNames_SelectionChangeCommitted(object sender, EventArgs e)
        {
            ShowProjectsTenderStatusPerCommittee();
        }
        private void ShowProjectsTenderStatusPerCommittee()
        {
            if (cmbCommitteNames.SelectedIndex >= 0)
            {
                if (cn.State == ConnectionState.Closed)
                {
                    cn.ConnectionString = strCon;
                    cn.Open();
                }
                DataRowView dtCommitteIDView = (DataRowView)cmbCommitteNames.SelectedItem;             
                string strQueryPrj = "SELECT COUNT(PROJECTS.proj_id) AS PrjCnt, [TenderStatus].[Status_Name] AS Status, [TenderStatus].Tender_Status_id, Committee.committee_id FROM PROJECTS INNER JOIN [TenderStatus] ON PROJECTS.Tender_Status_id = [TenderStatus].Tender_Status_id INNER JOIN Committee ON PROJECTS.committee_id = Committee.committee_id " +
                "WHERE (PROJECTS.isDeleted = 0) GROUP BY [TenderStatus].[Status_Name], [TenderStatus].Tender_Status_id, Committee.committee_id HAVING ([TenderStatus].[Tender_Status_id] <> 8) and ([TenderStatus].[Tender_Status_id] <> 9) AND ([TenderStatus].[Tender_Status_id] <> 10) AND ([TenderStatus].[Tender_Status_id] <> 11) AND (Committee.committee_id = " + dtCommitteIDView.Row.ItemArray[0].ToString() + ") ORDER BY [TenderStatus].Tender_Status_id ";

                SqlDataAdapter daPrj = new SqlDataAdapter(strQueryPrj, cn);
                DataSet dsPrj = new DataSet();
                daPrj.Fill(dsPrj);
                cn.Close();
                ChartProjects.DataSource = dsPrj.Tables[0].DefaultView;
                ChartProjects.Series["Tender Status"].XValueMember = "Status";
                ChartProjects.Series["Tender Status"].YValueMembers = "PrjCnt";
                ChartProjects.DataBind();
                ChartProjects.Visible = true;

                ChartProjects.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
            }
        }

        private void cmbTenderTypes_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            
        }
               

        private void splitContainer3_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dashBoardParent_Leave(object sender, EventArgs e)
        {

        }
              

        private void chartIssuedTender_Click(object sender, EventArgs e)
        {
            if (!userRightsColl.Contains("37"))                // _profileName == "" means Administrator rights
            {
                Dashboard.frmTenderIssued tndrIssued = new Dashboard.frmTenderIssued();
                tndrIssued.StartPosition = FormStartPosition.CenterScreen;
                tndrIssued.ShowDialog();
            }
            else
            {
                MessageBox.Show("You don't have priviliges to view On-going Tender information,Please contact Administrator");
            }
        }

        

        private void cmbCmteNamesForNumberOfTenders_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void cmbFYForNumberOfTenders_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }       

        private void FillCommitteeWiseTenderCountChart()
        {
            if (cmbCmteNamesForNumberOfTenders.SelectedIndex >= 0 && cmbFYForNumberOfTenders.SelectedIndex == -1)
            {
                DataRowView dtView = (DataRowView)cmbCmteNamesForNumberOfTenders.SelectedItem;
                CommitteeWiseTenderCount(dtView.Row.ItemArray[0].ToString(), null);
            }
            else if (cmbCmteNamesForNumberOfTenders.SelectedIndex == -1 && cmbFYForNumberOfTenders.SelectedIndex >= 0)
            {
                DataRowView dtView = (DataRowView)cmbFYForNumberOfTenders.SelectedItem;
                CommitteeWiseTenderCount(null, dtView.Row.ItemArray[0].ToString());
            }
            else if (cmbCmteNamesForNumberOfTenders.SelectedIndex == -1 && cmbFYForNumberOfTenders.SelectedIndex == -1)
            {
                CommitteeWiseTenderCount(null, null);
            }
            else if (cmbCmteNamesForNumberOfTenders.SelectedIndex >= 0 && cmbFYForNumberOfTenders.SelectedIndex >= 0)
            {
                DataRowView dtViewSelectedCmteName = (DataRowView)cmbCmteNamesForNumberOfTenders.SelectedItem;
                DataRowView dtViewSelectedFY = (DataRowView)cmbFYForNumberOfTenders.SelectedItem;
                CommitteeWiseTenderCount(dtViewSelectedCmteName.Row.ItemArray[0].ToString(), dtViewSelectedFY.Row.ItemArray[0].ToString());
            }
        }

        private void FillTotalContractAmountChart()
        {
            if (cmbCmteNamesForTotalContractAmounts.SelectedIndex >= 0)
            {
                DataRowView dtView = (DataRowView)cmbCmteNamesForTotalContractAmounts.SelectedItem;
                DataRowView dtFYView = (DataRowView)cmbFYTotValTenderAwardsPerCommt.SelectedItem;
                TotalAmountOfContractsPerCommittee(dtView.Row.ItemArray[0].ToString(), dtFYView.Row.ItemArray[1].ToString());
            }
            else if (cmbCmteNamesForTotalContractAmounts.SelectedIndex == -1)
            {
                DataRowView dtFYView = (DataRowView)cmbFYTotValTenderAwardsPerCommt.SelectedItem;
                TotalAmountOfContractsPerCommittee(null, dtFYView.Row.ItemArray[1].ToString());
            }
           
        }

        private void cmbFinancialYears_SelectionChangeCommitted(object sender, EventArgs e)
        {
            FillApprovedDocumentsChart();
        }

        private void cmbCmteNamesForNumberOfTenders_SelectionChangeCommitted(object sender, EventArgs e)
        {
            FillCommitteeWiseTenderCountChart();
        }

        private void cmbFYForNumberOfTenders_SelectionChangeCommitted(object sender, EventArgs e)
        {
            FillCommitteeWiseTenderCountChart();
        }

        private void cmbFYForTotalContractAmounts_SelectionChangeCommitted(object sender, EventArgs e)
        {
            FillTotalContractAmountChart();
        }

        private void cmbCmteNamesForTotalContractAmounts_SelectionChangeCommitted(object sender, EventArgs e)
        {
            FillTotalContractAmountChart();
        }

        // Added by Varun on 23Nov2015
        private void btnRefreshTenderDocsApproved_Click(object sender, EventArgs e)
        {
            cmbFinancialYears.SelectedValue = 13;
            ChartFor_ApprovedTenderDocuments();            
        }
       
        

        // Added by Varun on 23Nov2015
        private void btnRefreshNumberOfTenderEachYear_Click(object sender, EventArgs e)
        {
            cmbFYForNumberOfTenders.SelectedValue = 13;
            cmbCmteNamesForNumberOfTenders.SelectedIndex = -1;
            CommitteeWiseTenderCount(null, null);
        }

       

        private void btnRefreshTotalProjectsPerTenderStatus_Click(object sender, EventArgs e)
        {
            cmbCommitteNames.SelectedIndex = -1;
            ChartFor_TotalProjectsPerTenderStatus();
        }

        private void chartTenderDocsUnderPreparation_Click(object sender, EventArgs e)
        {
            if (!userRightsColl.Contains("37"))                // _profileName Null means here Administrator rights
            {
                OngoingTenders frmTenderExpiry = new OngoingTenders(null, _userName, _isHeadOfSection);
                frmTenderExpiry.StartPosition = FormStartPosition.CenterParent;
                frmTenderExpiry.ShowDialog();
            }
            else
            {
                MessageBox.Show("You don't have priviliges to view Tender Documents Under Preparation information, Please contact Administrator");
            }
        }

        private void chartTenderDocsUnderPreparation_DoubleClick(object sender, EventArgs e)
        {
            if (!userRightsColl.Contains("37"))                // _profileName Null means here Administrator rights
            {
                OngoingTenders frmTenderExpiry = new OngoingTenders(null, _userName, _isHeadOfSection);
                frmTenderExpiry.StartPosition = FormStartPosition.CenterParent;
                frmTenderExpiry.ShowDialog();
            }
            else
            {
                MessageBox.Show("You don't have priviliges to view Tender Documents Under Preparation information, Please contact Administrator");
            }
        }

        private void linkShowMoreCharts_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (!userRightsColl.Contains("37"))                // _profileName == "" means Administrator rights
            {
                Dashboard.frmTCMCharts frmTCMCharts = new Dashboard.frmTCMCharts(userRightsColl);
                frmTCMCharts.StartPosition = FormStartPosition.CenterScreen;
                frmTCMCharts.ShowDialog();
            }
            else
            {
                MessageBox.Show("You don't have priviliges to view more charts, Please contact Administrator");
            }
        }

        private void btnRefreshTotValTenderAwardsPerCommt_Click(object sender, EventArgs e)
        {
            cmbCmteNamesForTotalContractAmounts.SelectedIndex = -1;            
            cmbFYTotValTenderAwardsPerCommt.SelectedValue = ConfigurationManager.AppSettings["CurrentFY"].ToString();
            DataRowView dtFYView = (DataRowView)cmbFYTotValTenderAwardsPerCommt.SelectedItem;
            TotalAmountOfContractsPerCommittee(null, dtFYView.Row.ItemArray[1].ToString());
        }

        private void cmbFYTotValTenderAwardsPerCommt_SelectedIndexChanged(object sender, EventArgs e)
        {
            FillTotalContractAmountChart();
        }

        private void dashBoardParent_Paint(object sender, PaintEventArgs e)
        {
            //Assembly asm = Assembly.GetExecutingAssembly();
            //Bitmap backgroundImage = new Bitmap(asm.GetManifestResourceStream("F:\\WalidFiles\\TCMS\\svn_tcms_wc\\Resources\\AsghalNewLogoCopy.jpg"));

            //e.Graphics.DrawImage(backgroundImage, this.ClientRectangle,
            //    new Rectangle(0, 0, backgroundImage.Width, backgroundImage.Height),
            //    GraphicsUnit.Pixel);
        }

           

        
    }
}

