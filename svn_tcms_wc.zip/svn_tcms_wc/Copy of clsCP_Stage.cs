﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Windows.Forms;
using TenderTrackingSystem;
using System.Drawing;
using MDI_ParenrForm;

namespace MDI_ParenrForm
{
    class clsCP_Stage
    {
        DAL dalObj = new DAL();
      //  CommonClass cmnCls = new CommonClass("");
        string connStr = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();
        string _userName = string.Empty;
        public clsCP_Stage(string user)
        {
            _userName = user;
        }
        void dgvContracts_DataError(object sender, DataGridViewDataErrorEventArgs e)     //dgvContracts_DataError
        {
            e.Cancel = true;
        }        
        public void FillCP_ContractsData(DataGridView dgvContracts,int cp_prjID)
        {
            string strQuery = "";
            //strQuery = "select co_id,co_type_id,ContractAmount as award ,cp_contractor_sign,contract_no,bidder_id from CONTRACTORS WHERE (proj_id = " + Convert.ToInt16(lblProjID.Text) + ") AND (stage_id = 4) ";

            strQuery = "SELECT CONTRACTORS.co_id, CONTRACTORS.co_type_id, CONTRACTORS.ContractAmount AS award,CONTRACTORS.cp_contractor_sign, CONTRACTORS.contract_no, " +
            " CONTRACTORS.bidder_id, COMPANY.co_name FROM CONTRACTORS INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id " +
            " WHERE (CONTRACTORS.proj_id = " + cp_prjID + ") AND (CONTRACTORS.stage_id = 4)";

            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                    DataSet ds = new DataSet();

                    dgvContracts.AllowUserToAddRows = false;
                    sqlda.Fill(ds);

                    dgvContracts.Columns[0].DataPropertyName = "co_id";   // co_id
                    dgvContracts.Columns[1].DataPropertyName = "co_type_id";
                    dgvContracts.Columns[2].DataPropertyName = "award";
                    dgvContracts.Columns[3].DataPropertyName = "cp_contractor_sign";
                    dgvContracts.Columns[4].DataPropertyName = "contract_no";
                    dgvContracts.Columns[5].DataPropertyName = "bidder_id";
                    dgvContracts.DataSource = ds.Tables[0];
                    dgvContracts.AllowUserToAddRows = true;
                }
                sqlCn.Close();
            }
            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                    DataSet ds = new DataSet();
                    sqlda.Fill(ds);
                    dgvContracts.AllowUserToAddRows = false;
                    sqlda.Fill(ds);

                    dgvContracts.Columns[0].DataPropertyName = "co_id";   // co_id
                    dgvContracts.Columns[1].DataPropertyName = "co_type_id";
                    dgvContracts.Columns[2].DataPropertyName = "award";
                    dgvContracts.Columns[3].DataPropertyName = "cp_contractor_sign";
                    dgvContracts.Columns[4].DataPropertyName = "contract_no";
                    dgvContracts.Columns[5].DataPropertyName = "bidder_id";
                    dgvContracts.DataSource = ds.Tables[0];
                    dgvContracts.AllowUserToAddRows = true;
                }
                sqlCn.Close();
            }
            try
            {
                for (int i = 0; i < dgvContracts.Rows.Count; i++)
                {
                    if (i == (dgvContracts.Rows.Count - 1))
                    {
                        dgvContracts.Rows[i].Cells[3].Value = "";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void createCompanyColumn(DataGridView dgvCpDataEntry)
        {
            DataSet ds2 = new DataSet();
            string strQuery = "";

            //strQuery = "select employee_id,shortname as staff from Contacts where shortname is not null order by employee_id asc"; //   WHERE (b.proj_id = " + Convert.ToInt16(lblProjID.Text) + ") AND (b.stage_id = 4) ";

            strQuery = "select shortname as staff from Contacts where shortname <>'' order by employee_id asc"; //   WHERE (b.proj_id = " + Convert.ToInt16(lblProjID.Text) + ") AND (b.stage_id = 4) ";
            try
            {
                using (SqlConnection sqlCn = new SqlConnection(connStr))
                {
                    sqlCn.Open();
                    using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                    {
                        SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                        sqlda.Fill(ds2);

                        CalendarColumn colCboxCategory1 = new CalendarColumn();
                        colCboxCategory1.HeaderText = "Sent to Dept For Signature";
                        colCboxCategory1.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory1);

                        CalendarColumn colCboxCategory2 = new CalendarColumn();
                        colCboxCategory2.HeaderText = "Rcvd from Dept and Sent to PRSD Sign";
                        colCboxCategory2.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory2);

                        CalendarColumn colCboxCategory3 = new CalendarColumn();
                        colCboxCategory3.HeaderText = "Sent To Fin Dept for Commitment";
                        colCboxCategory3.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory3);

                        CalendarColumn colCboxCategory4 = new CalendarColumn();
                        colCboxCategory4.HeaderText = "Received From Finance Dept";
                        colCboxCategory4.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory4);

                        CalendarColumn colCboxCategory5 = new CalendarColumn();
                        colCboxCategory5.HeaderText = "Distribution";
                        colCboxCategory5.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory5);

                        DataGridViewTextBoxColumn colCboxCategory6 = new DataGridViewTextBoxColumn();
                        colCboxCategory6.Name = "abc";
                        colCboxCategory6.HeaderText = "Remarks";
                        colCboxCategory6.Width = 200;
                        dgvCpDataEntry.Columns.Add(colCboxCategory6);

                        var column = new DataGridViewComboBoxColumn();
                        DataTable data = new DataTable();

                        // data.Columns.Add(new DataColumn("Value", typeof(int)));
                        //data.Columns.Add(new DataColumn("Value", typeof(string)));
                        data.Columns.Add(new DataColumn("Description", typeof(string)));
                        for (int l = 0; l < ds2.Tables[0].Rows.Count; l++)
                        {
                            // data.Rows.Add(ds2.Tables[0].Rows[l][0].ToString(), ds2.Tables[0].Rows[l][1].ToString());

                            data.Rows.Add(ds2.Tables[0].Rows[l][0].ToString());
                        }

                        column.DataSource = data;
                        //column.ValueMember = "Value";
                        column.DisplayMember = "Description";
                        column.HeaderText = "Staff Incharge";
                        dgvCpDataEntry.Columns.Add(column);

                        DataGridViewTextBoxColumn colCboxCategory7 = new DataGridViewTextBoxColumn();
                        colCboxCategory7.Name = "ColID";
                        colCboxCategory7.Visible = false;
                        colCboxCategory7.HeaderText = "ID";
                        dgvCpDataEntry.Columns.Add(colCboxCategory7);


                        CalendarColumn colCboxCategory8 = new CalendarColumn();
                        colCboxCategory8.HeaderText = "Received_of_doc,";
                        colCboxCategory8.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory8);

                        CalendarColumn colCboxCategory9 = new CalendarColumn();
                        colCboxCategory9.HeaderText = "Request StartDate,";
                        colCboxCategory9.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory9);

                        CalendarColumn colCboxCategory10 = new CalendarColumn();
                        colCboxCategory10.HeaderText = "StartDate Receive";
                        colCboxCategory10.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory10);

                        CalendarColumn colCboxCategory11 = new CalendarColumn();
                        colCboxCategory11.HeaderText = "Notice Contractor to Sign";
                        colCboxCategory11.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory11);

                        CalendarColumn colCboxCategory12 = new CalendarColumn();
                        colCboxCategory12.HeaderText = "Due_date_pb";
                        colCboxCategory12.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory12);

                        dgvCpDataEntry.ColumnHeadersDefaultCellStyle.BackColor = Color.Gainsboro;
                        dgvCpDataEntry.ColumnHeadersDefaultCellStyle.ForeColor = Color.Chocolate;
                        dgvCpDataEntry.ColumnHeadersDefaultCellStyle.Font = new Font(dgvCpDataEntry.Font, FontStyle.Regular);
                        dgvCpDataEntry.EnableHeadersVisualStyles = false;
                    }
                    sqlCn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void CreateColumnsForCP_MultiplerecordsDara(DataGridView dgvCpDataEntry)
        {
           // CreateColumnsForCompanyGrid(dgvCpDataEntry, 0);

            DataSet ds2 = new DataSet();
            string strQuery = "";

            //strQuery = "select employee_id,shortname as staff from Contacts where shortname is not null order by employee_id asc"; //   WHERE (b.proj_id = " + Convert.ToInt16(lblProjID.Text) + ") AND (b.stage_id = 4) ";

            strQuery = "select shortname as staff from Contacts where shortname is not null order by employee_id asc"; //   WHERE (b.proj_id = " + Convert.ToInt16(lblProjID.Text) + ") AND (b.stage_id = 4) ";
            try
            {
                using (SqlConnection sqlCn = new SqlConnection(connStr))
                {
                    sqlCn.Open();
                    using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                    {
                        SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                        sqlda.Fill(ds2);

                        DataGridViewTextBoxColumn colCboxCategoryBid = new DataGridViewTextBoxColumn();
                        colCboxCategoryBid.Name = "CompanyName";
                        colCboxCategoryBid.HeaderText = "Bidder Name";
                        colCboxCategoryBid.Width = 200;
                        dgvCpDataEntry.Columns.Add(colCboxCategoryBid);         


                        CalendarColumn colCboxCategory1 = new CalendarColumn();
                        colCboxCategory1.HeaderText = "Sent to Dept For Signature";
                        colCboxCategory1.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory1);

                        CalendarColumn colCboxCategory2 = new CalendarColumn();
                        colCboxCategory2.HeaderText = "Rcvd from Dept and Sent to PRSD Sign";
                        colCboxCategory2.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory2);

                        CalendarColumn colCboxCategory3 = new CalendarColumn();
                        colCboxCategory3.HeaderText = "Sent To Fin Dept for Commitment";
                        colCboxCategory3.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory3);

                        CalendarColumn colCboxCategory4 = new CalendarColumn();
                        colCboxCategory4.HeaderText = "Received From Finance Dept";
                        colCboxCategory4.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory4);

                        CalendarColumn colCboxCategory5 = new CalendarColumn();
                        colCboxCategory5.HeaderText = "Distribution";
                        colCboxCategory5.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory5);

                        DataGridViewTextBoxColumn colCboxCategory6 = new DataGridViewTextBoxColumn();
                        colCboxCategory6.Name = "abc";
                        colCboxCategory6.HeaderText = "Remarks";
                        colCboxCategory6.Width = 200;
                        dgvCpDataEntry.Columns.Add(colCboxCategory6);

                        var column = new DataGridViewComboBoxColumn();
                        DataTable data = new DataTable();

                        // data.Columns.Add(new DataColumn("Value", typeof(int)));
                        //data.Columns.Add(new DataColumn("Value", typeof(string)));
                        data.Columns.Add(new DataColumn("Description", typeof(string)));
                        for (int l = 0; l < ds2.Tables[0].Rows.Count; l++)
                        {
                            // data.Rows.Add(ds2.Tables[0].Rows[l][0].ToString(), ds2.Tables[0].Rows[l][1].ToString());

                            data.Rows.Add(ds2.Tables[0].Rows[l][0].ToString());
                        }

                        column.DataSource = data;
                        //column.ValueMember = "Value";
                        column.DisplayMember = "Description";
                        column.HeaderText = "Staff Incharge";
                        dgvCpDataEntry.Columns.Add(column);

                        DataGridViewTextBoxColumn colCboxCategory7 = new DataGridViewTextBoxColumn();
                        colCboxCategory7.Name = "ColID";
                        colCboxCategory7.Visible = false;
                        colCboxCategory7.HeaderText = "ID";
                        dgvCpDataEntry.Columns.Add(colCboxCategory7);


                        CalendarColumn colCboxCategory8 = new CalendarColumn();
                        colCboxCategory8.HeaderText = "Received_of_doc,";
                        colCboxCategory8.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory8);

                        CalendarColumn colCboxCategory9 = new CalendarColumn();
                        colCboxCategory9.HeaderText = "Request StartDate,";
                        colCboxCategory9.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory9);

                        CalendarColumn colCboxCategory10 = new CalendarColumn();
                        colCboxCategory10.HeaderText = "StartDate Receive";
                        colCboxCategory10.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory10);

                        CalendarColumn colCboxCategory11 = new CalendarColumn();
                        colCboxCategory11.HeaderText = "Notice Contractor to Sign";
                        colCboxCategory11.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory11);

                        CalendarColumn colCboxCategory12 = new CalendarColumn();
                        colCboxCategory12.HeaderText = "Due_date_pb";
                        colCboxCategory12.Width = 100;
                        dgvCpDataEntry.Columns.Add(colCboxCategory12);

                        DataGridViewTextBoxColumn colCboxCategory13 = new DataGridViewTextBoxColumn();
                        colCboxCategory13.Name = "BidID";
                        colCboxCategory13.Visible = false;
                        colCboxCategory13.HeaderText = "BidID";
                        dgvCpDataEntry.Columns.Add(colCboxCategory13);
                        
                        dgvCpDataEntry.ColumnHeadersDefaultCellStyle.BackColor = Color.Gainsboro;
                        dgvCpDataEntry.ColumnHeadersDefaultCellStyle.ForeColor = Color.Chocolate;
                        dgvCpDataEntry.ColumnHeadersDefaultCellStyle.Font = new Font(dgvCpDataEntry.Font, FontStyle.Regular);
                        dgvCpDataEntry.EnableHeadersVisualStyles = false;
                    }
                    sqlCn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void FillCP_MultiplerecordsDara(DataGridView dgvCpDataEntry,int cp_PrjID)
        {
            if (dgvCpDataEntry.ColumnCount == 0)
                CreateColumnsForCP_MultiplerecordsDara(dgvCpDataEntry);

            string strQuery = "";
            strQuery = "SELECT COMPANY.co_name,TenderDatesInfo.cp_sent_dep_sign, TenderDatesInfo.cp_receive_dep_sent_prsd, TenderDatesInfo.cp_sent_fd_commit, " +
                       " TenderDatesInfo.cp_receive_fd_commit, TenderDatesInfo.cp_distribution, TenderDatesInfo.remarks, TenderDatesInfo.StaffInCharge AS staff, " +
                       " TenderDatesInfo.date_id, TenderDatesInfo.cp_received_of_doc, TenderDatesInfo.cp_request_start_date, TenderDatesInfo.cp_start_date_receive, " +
                       " TenderDatesInfo.cp_notice_contractor_to_sign, TenderDatesInfo.cp_due_date_pb, TenderDatesInfo.Tndr_BidID, TenderDatesInfo.Tndr_BidName " +
                       " FROM  TenderDatesInfo INNER JOIN COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id INNER JOIN " +
                       " CONTRACTORS ON TenderDatesInfo.Tndr_BidID = CONTRACTORS.bidder_id WHERE (TenderDatesInfo.proj_id = " + cp_PrjID + ") AND (TenderDatesInfo.stage_id = 4)";

            //strQuery = "select cp_sent_dep_sign,cp_receive_dep_sent_prsd,cp_sent_fd_commit,cp_receive_fd_commit,cp_distribution,remarks," +
            //    " [StaffInCharge] as staff,date_id,cp_received_of_doc,cp_request_start_date,cp_start_date_receive,cp_notice_contractor_to_sign, " +
            //" cp_due_date_pb,Tndr_BidID,Tndr_BidName from TenderDatesInfo WHERE (proj_id = " + cp_PrjID + ") AND (stage_id = 4)";

            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                    DataSet ds = new DataSet();
                    sqlda.Fill(ds);
                    dgvCpDataEntry.AllowUserToAddRows = false;

                    dgvCpDataEntry.Columns[0].DataPropertyName = "Tndr_Bidname";
                    dgvCpDataEntry.Columns[1].DataPropertyName = "cp_sent_dep_sign";
                    dgvCpDataEntry.Columns[2].DataPropertyName = "cp_receive_dep_sent_prsd";
                    dgvCpDataEntry.Columns[3].DataPropertyName = "cp_sent_fd_commit";
                    dgvCpDataEntry.Columns[4].DataPropertyName = "cp_receive_fd_commit";
                    dgvCpDataEntry.Columns[5].DataPropertyName = "cp_distribution";
                    dgvCpDataEntry.Columns[6].DataPropertyName = "remarks";
                    dgvCpDataEntry.Columns[7].DataPropertyName = "staff";
                    dgvCpDataEntry.Columns[8].DataPropertyName = "date_id";

                    dgvCpDataEntry.Columns[9].DataPropertyName = "cp_received_of_doc";
                    dgvCpDataEntry.Columns[10].DataPropertyName = "cp_request_start_date";
                    dgvCpDataEntry.Columns[11].DataPropertyName = "cp_start_date_receive";
                    dgvCpDataEntry.Columns[12].DataPropertyName = "cp_notice_contractor_to_sign";
                    dgvCpDataEntry.Columns[13].DataPropertyName = "cp_due_date_pb";
                    dgvCpDataEntry.Columns[14].DataPropertyName = "Tndr_BidID";
                    
                    dgvCpDataEntry.DataSource = ds.Tables[0];
                    dgvCpDataEntry.AllowUserToAddRows = true;
                }
                sqlCn.Close();
            }

            dgvCpDataEntry.Columns[7].Visible = false;

            //using (SqlConnection sqlCn = new SqlConnection(connStr))
            //{
            //    sqlCn.Open();
            //    using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
            //    {
            //        SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
            //        DataSet ds = new DataSet();
            //        sqlda.Fill(ds);

            //        dgvCpDataEntry.AllowUserToAddRows = false;

            //        dgvCpDataEntry.Columns[0].DataPropertyName = "Tndr_Bidname";
            //        dgvCpDataEntry.Columns[1].DataPropertyName = "cp_sent_dep_sign";
            //        dgvCpDataEntry.Columns[2].DataPropertyName = "cp_receive_dep_sent_prsd";
            //        dgvCpDataEntry.Columns[3].DataPropertyName = "cp_sent_fd_commit";
            //        dgvCpDataEntry.Columns[4].DataPropertyName = "cp_receive_fd_commit";
            //        dgvCpDataEntry.Columns[5].DataPropertyName = "cp_distribution";
            //        dgvCpDataEntry.Columns[6].DataPropertyName = "remarks";
            //        dgvCpDataEntry.Columns[7].DataPropertyName = "staff";
            //        dgvCpDataEntry.Columns[8].DataPropertyName = "date_id";

            //        dgvCpDataEntry.Columns[9].DataPropertyName = "cp_received_of_doc";
            //        dgvCpDataEntry.Columns[10].DataPropertyName = "cp_request_start_date";
            //        dgvCpDataEntry.Columns[11].DataPropertyName = "cp_start_date_receive";
            //        dgvCpDataEntry.Columns[12].DataPropertyName = "cp_notice_contractor_to_sign";
            //        dgvCpDataEntry.Columns[13].DataPropertyName = "cp_due_date_pb";
            //        dgvCpDataEntry.Columns[14].DataPropertyName = "Tndr_BidID";
                    
            //        dgvCpDataEntry.DataSource = ds.Tables[0];
            //        dgvCpDataEntry.AllowUserToAddRows = true;
            //    }
            //    sqlCn.Close();
            //}
            try
            {
                for (int i = 0; i < dgvCpDataEntry.Rows.Count; i++)
                {
                    if (i == (dgvCpDataEntry.Rows.Count - 1))
                    {
                        dgvCpDataEntry.Rows[i].Cells[1].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[2].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[3].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[4].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[5].Value = "";

                       // dgvCpDataEntry.Rows[i].Cells[5].Value = "";

                        dgvCpDataEntry.Rows[i].Cells[7].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[8].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[9].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[10].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[11].Value = "";

                        dgvCpDataEntry.Rows[i].Cells[12].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[13].Value = "";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public Int16 maxValue(string str)
        {
            object max;
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                SqlCommand cmd = new SqlCommand(str, sqlConn);
                sqlConn.Open();
                max = cmd.ExecuteScalar();
            }
            return Convert.ToInt16(max);
        }

        public void UpdateTenderStatus_CP(int cp_prjID)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(connStr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        cmd.CommandText = @"UPDATE PROJECTS SET [Tender_Status_id]= 5 and [stage_id]= 4 Where proj_id=@projId";
                        cmd.Parameters.AddWithValue("@projId", cp_prjID);
                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the UPDATE DATES records, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }   
        }
        public void CreateColumnsForCompanyGrid(DataGridView dgvCntrStage3, int cp_PrjiD)
        {
            string strQuery = "";
            //strQuery = "SELECT Co_id,co_name FROM COMPANY where co_shortname is not null";

            strQuery = "SELECT COMPANY.co_id,COMPANY.co_name, TenderDatesInfo.proj_id FROM TenderDatesInfo INNER JOIN " +
                      " COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id WHERE (TenderDatesInfo.proj_id = " + cp_PrjiD + " and TenderDatesInfo.Tender_Issued=1)";
            try
            {
                using (SqlConnection sqlCn = new SqlConnection(connStr))
                {
                    sqlCn.Open();
                    using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                    {
                        SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                        DataSet ds = new DataSet();
                        sqlda.Fill(ds);

                        DataTable data = new DataTable();
                        data.Columns.Add(new DataColumn("Value", typeof(int)));
                        data.Columns.Add(new DataColumn("Description", typeof(string)));
                        for (int l = 0; l < ds.Tables[0].Rows.Count; l++)
                        {
                            data.Rows.Add(ds.Tables[0].Rows[l][0].ToString(), ds.Tables[0].Rows[l][1].ToString());
                        }

                        DataGridViewComboBoxColumn colCboxCategory = new DataGridViewComboBoxColumn();
                        colCboxCategory.Name = "CmpName";
                        colCboxCategory.HeaderText = "Successfull Bidder*";
                        colCboxCategory.DataSource = data;
                        colCboxCategory.ValueMember = "Value";
                        colCboxCategory.DisplayMember = "Description";
                        colCboxCategory.Width = 500;
                        dgvCntrStage3.Columns.Add(colCboxCategory);
                      //  dgvCntrStage3.DataError += new DataGridViewDataErrorEventHandler(dgvCntrStage3_DataError);
                        //dgvCntrStage3.EnableHeadersVisualStyles = false;
                    }
                    sqlCn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void CreateColumnsForCP_Contracors_TE(DataGridView dgvCntrStage3, int cp_PrjiD)
        {

            // Second New Column
           // CreateColumnsForCompanyGrid(dgvCntrStage3, cp_PrjiD);

            //===========================================================================

            string strQuery = "";
            //strQuery = "SELECT Co_id,co_name FROM COMPANY where co_shortname is not null";

            strQuery = "SELECT COMPANY.co_id,COMPANY.co_name, TenderDatesInfo.proj_id FROM TenderDatesInfo INNER JOIN " +
                      " COMPANY ON TenderDatesInfo.co_id = COMPANY.co_id WHERE (TenderDatesInfo.proj_id = " + cp_PrjiD + " and TenderDatesInfo.Tender_Issued=1)";
            try
            {
                using (SqlConnection sqlCn = new SqlConnection(connStr))
                {
                    sqlCn.Open();
                    using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                    {
                        SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                        DataSet ds = new DataSet();
                        sqlda.Fill(ds);

                        DataTable data = new DataTable();
                        data.Columns.Add(new DataColumn("Value", typeof(int)));
                        data.Columns.Add(new DataColumn("Description", typeof(string)));
                        for (int l = 0; l < ds.Tables[0].Rows.Count; l++)
                        {
                            data.Rows.Add(ds.Tables[0].Rows[l][0].ToString(), ds.Tables[0].Rows[l][1].ToString());
                        }

                        DataGridViewComboBoxColumn colCboxCategory = new DataGridViewComboBoxColumn();
                        colCboxCategory.Width = 500;
                        colCboxCategory.Name = "CmpName";
                        colCboxCategory.HeaderText = "Successfull Bidder";
                        colCboxCategory.DataSource = data;
                        colCboxCategory.ValueMember = "Value";
                        colCboxCategory.DisplayMember = "Description";
                        
                        dgvCntrStage3.Columns.Add(colCboxCategory);
                        //  dgvCntrStage3.DataError += new DataGridViewDataErrorEventHandler(dgvCntrStage3_DataError);
                        dgvCntrStage3.EnableHeadersVisualStyles = false;
                    }
                    sqlCn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            //===========================================================================

            DataGridViewTextBoxColumn colCboxCmpType = new DataGridViewTextBoxColumn();
            colCboxCmpType.Name = "Type";
            colCboxCmpType.HeaderText = "Type";
            colCboxCmpType.Width = 40;
            dgvCntrStage3.Columns.Add(colCboxCmpType);            

            DataGridViewTextBoxColumn colCboxCategory2 = new DataGridViewTextBoxColumn();
            colCboxCategory2.Name = "Amount";
            colCboxCategory2.HeaderText = "Award Amount";
            colCboxCategory2.Width = 50;
            dgvCntrStage3.Columns.Add(colCboxCategory2);

            CalendarColumn colCboxCategory7 = new CalendarColumn();
            colCboxCategory7.Name = "TndrAward";
            colCboxCategory7.HeaderText = "Date of Letter of Award";
            //colCboxCategory3.DefaultCellStyle.Format = "dd/MMM/yy";
            colCboxCategory7.Width = 50;
            dgvCntrStage3.Columns.Add(colCboxCategory7);

            DataGridViewTextBoxColumn colCboxCategory6 = new DataGridViewTextBoxColumn();
            colCboxCategory6.Name = "ProjID";
            colCboxCategory6.HeaderText = "projID";
            colCboxCategory6.Visible = true;
            dgvCntrStage3.Columns.Add(colCboxCategory6);

            DataGridViewTextBoxColumn colCboxCategory5 = new DataGridViewTextBoxColumn();
            colCboxCategory5.Name = "Bidder_ID";
            colCboxCategory5.HeaderText = "Bidder_ID";
            colCboxCategory5.Visible = true;
            dgvCntrStage3.Columns.Add(colCboxCategory5);


            //DataGridViewTextBoxColumn colCboxCategory4 = new DataGridViewTextBoxColumn();
            //colCboxCategory4.Name = "Tndr_Date";
            //colCboxCategory4.HeaderText = "Tndr_Date";
            //dgvCntrStage3.Columns.Add(colCboxCategory4);
            

           // dgvCntrStage3.DataError += new DataGridViewDataErrorEventHandler(dgvContracts_DataError);

            dgvCntrStage3.ColumnHeadersDefaultCellStyle.BackColor = Color.Gainsboro;
            dgvCntrStage3.ColumnHeadersDefaultCellStyle.ForeColor = Color.Chocolate;
            dgvCntrStage3.ColumnHeadersDefaultCellStyle.Font = new Font(dgvCntrStage3.Font, FontStyle.Regular);
            dgvCntrStage3.EnableHeadersVisualStyles = false;
            
            dgvCntrStage3.Columns[4].Visible = false;
            dgvCntrStage3.Columns[5].Visible = false;
        } 
        public void CP_Contracts_Insert_UpdateData(DataGridView dgvCntr,SqlCommand cmd,int cp_PrjID)
        {
            int x = 0;
            foreach (DataGridViewRow dr in dgvCntr.Rows)
            {
                Int16 bidderid;
                bidderid = maxValue("SELECT MAX(bidder_id)+1 FROM [CONTRACTORS]");

                x = x + 1;
                if (x < dgvCntr.Rows.Count)
                {
                    if (dr.Cells[0].Value.ToString() != "")
                    {
                        double Value3 = 0; string Value4 = string.Empty; string Value5 = string.Empty;
                        string Value6 = string.Empty; string Value7 = string.Empty; int Value0 = 0;

                        string bidname = string.Empty;

                         Value0 = Convert.ToInt32(dr.Cells[5].Tag);

                        string Value1 = Convert.ToString(dr.Cells[0].Value.ToString());   //co_id

                        string Value2 = Convert.ToString(dr.Cells[1].Value.ToString());     // Co_type_ID


                        if (dr.Cells[2].Value.ToString() != "")                     // Cntr_Amnt
                            Value3 = Convert.ToDouble(dr.Cells[2].Value.ToString());
                        
                        if (dr.Cells[3].Value.ToString() != "")              // Tndr_Award
                            Value4 = Convert.ToString(dr.Cells[3].Value.ToString());
                        else
                            Value4 = "";

                        if (dr.Cells[4].Value.ToString() != "")                 // 
                            Value5 = Convert.ToString(dr.Cells[4].Value.ToString());
                        else
                            Value5 = "";

                        if (dr.Cells[5].Value.ToString() != "")           //Bid_ID //PrjID
                            Value6 = Convert.ToString(dr.Cells[5].Value.ToString());
                        else
                            Value6 = "";

                        if (Value6 == "" || Value6 == null)             
                        {
                            int stage_Id = 0;
                            stage_Id = 4;
                            cmd.CommandText = @"INSERT INTO [CONTRACTORS](bidder_id,proj_id,create_date,create_user,co_id,ContractAmount,contract_status_id,cp_tender_award) VALUES(@bidder_id,@projId,@create_date,@create_user,@cmpID,@CntrAmount,@cntrTypeID,@tndr_Award)";
                            
                            cmd.Parameters.AddWithValue("@projId", cp_PrjID);
                           // cmd.Parameters.AddWithValue("@stageId", stage_Id);
                            cmd.Parameters.AddWithValue("@cmpID", Value1);

                            if (Value3 != 0)
                                cmd.Parameters.AddWithValue("@CntrAmount", Value3);
                            else
                                cmd.Parameters.AddWithValue("@CntrAmount", DBNull.Value);    
                    
                            cmd.Parameters.AddWithValue("@bidder_id", bidderid);

                            cmd.Parameters.AddWithValue("@create_date", DateTime.Now.ToString());
                            cmd.Parameters.AddWithValue("@create_user", _userName);  //ContractAmount       CntrAmount

                            cmd.Parameters.AddWithValue("@cntrTypeID", 1);  //ContractAmount       CntrAmount


                            if (Value4 != "")
                                cmd.Parameters.AddWithValue("@tndr_Award", Convert.ToDateTime(Value4).ToString("dd/MMM/yyyy"));    //CntrAward
                            else
                                cmd.Parameters.AddWithValue("@tndr_Award", DBNull.Value);

                            //cmd.Parameters.AddWithValue("@createDate", System.DateTime.Now);
                            //cmd.Parameters.AddWithValue("@createUser", _userName);

                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();

                           // UpdateBidderID(bidderid, Value0);

                            //Insert_Cp_Multirecords(bidderid, cp_PrjID, Value1);


                           // FillContractsGrid(dgvCntr, cp_PrjID);
                        }
                        else
                        {
                            int stage_Id = 0;
                            stage_Id = 4;

                            cmd.CommandText = @"Update [CONTRACTORS] set ContractAmount = @CntrAmount,update_date_eval =@update_date,update_user_eval =@update_user,co_id =@cmpID, cp_tender_award = @tndr_Award where bidder_id=@bidder_id and proj_id=@projId";
                            cmd.Parameters.AddWithValue("@projId", cp_PrjID);
                            // cmd.Parameters.AddWithValue("@stageId", stage_Id);
                            cmd.Parameters.AddWithValue("@cmpID", Value1);

                            if (Value3 != 0)
                                cmd.Parameters.AddWithValue("@CntrAmount", Value3);
                            else
                                cmd.Parameters.AddWithValue("@CntrAmount", DBNull.Value);

                            cmd.Parameters.AddWithValue("@bidder_id", Value5);
                           

                            cmd.Parameters.AddWithValue("@cntrTypeID", 1);  //ContractAmount       CntrAmount

                            if (Value4 != "")
                                cmd.Parameters.AddWithValue("@tndr_Award", Convert.ToDateTime(Value4).ToString("dd/MMM/yyyy"));    //CntrAward
                            else
                                cmd.Parameters.AddWithValue("@tndr_Award", DBNull.Value);

                            cmd.Parameters.AddWithValue("@update_date", DateTime.Now.ToString());
                            cmd.Parameters.AddWithValue("@update_user", _userName);  //ContractAmount       CntrAmount

                            int exUpdated = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                        }
                    }
                }
            }

            MessageBox.Show("Contracts data added successfully");
        }
        public void UpdateBidderID(int bidID,int DateiD)
        {
            string sqlUpdate = "Update TenderDatesInfo Set tndr_BidID = @bidID where Date_ID = @dateID";
            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(sqlUpdate, sqlCn))
                {
                    sqlCmd.Parameters.AddWithValue("@bidID", bidID);
                    sqlCmd.Parameters.AddWithValue("@dateID", DateiD);
                }
                sqlCn.Close();
            }
        }
        public void FillContractsData()
        {

        }
        private void Insert_Cp_Multirecords(int _bidderid,int _tndrPrjID,string _cmpID)
        {
            int _dateID = GetMaxDateID();
            using (SqlConnection sqlConn = new SqlConnection(connStr))
            {
                sqlConn.Open();               
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlConn;         //co_id      ==  cmpID
                    cmd.CommandText = @"INSERT INTO [TenderDatesInfo](Tndr_BidID,date_id,proj_id,stage_id,CreateDate,CreateUser,co_id) VALUES(@TndrDates_BidID,@dateId,@projId,@stageID,@CreateDate,@CreateUser,@cmpID)";

                    cmd.Parameters.AddWithValue("@TndrDates_BidID", _bidderid);
                    cmd.Parameters.AddWithValue("@dateId", _dateID);
                    cmd.Parameters.AddWithValue("@projId", _tndrPrjID);
                    cmd.Parameters.AddWithValue("@stageID", 4);
                   // cmd.Parameters.AddWithValue("@cmpID", "");     

                    cmd.Parameters.AddWithValue("@CreateDate", DateTime.Now.ToString());
                    cmd.Parameters.AddWithValue("@CreateUser", _userName);  //TndrBidName

                    cmd.Parameters.AddWithValue("@cmpID", _cmpID); 

                    int exUpdated = cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                }
            } 
        }
        public void FillContractsGrid_TE(DataGridView dgvCntr,int cp_prjiD)
        {
            string strQuery = "";
            // strQuery = "select co_type_id,cp_contractor_sign,contract_no,bidder_id,ContractAmount from CONTRACTORS WHERE (proj_id = " + Convert.ToInt16(lblProjID.Text) + ") AND (stage_id = 4) ";


            //tndr_DateID
            strQuery = "SELECT CONTRACTORS.co_id, COMPANY_TYPE.co_type_name, CONTRACTORS.ContractAmount, " +
            " CONTRACTORS.cp_tender_award,CONTRACTORS.bidder_id, CONTRACTORS.proj_id FROM CONTRACTORS INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id INNER JOIN COMPANY_TYPE ON COMPANY.co_type_id = COMPANY_TYPE.co_type_id " +
            " WHERE (CONTRACTORS.proj_id = " + cp_prjiD + ") ";      //AND (CONTRACTORS.stage_id = 4)

            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                    DataSet ds = new DataSet();
                    sqlda.Fill(ds);
                    dgvCntr.AllowUserToAddRows = false;
                    // ds.Tables[0].Columns[0].DataType = typeof(string);

                    //dgvCntr.Columns[0].DataPropertyName = "bidder_id";    //tndr_DateID
                    dgvCntr.Columns[0].DataPropertyName = "co_id";
                    dgvCntr.Columns[1].DataPropertyName = "co_type_name";
                    dgvCntr.Columns[2].DataPropertyName = "ContractAmount";
                    dgvCntr.Columns[3].DataPropertyName = "cp_tender_award";                    
                    dgvCntr.Columns[4].DataPropertyName = "proj_id";
                    dgvCntr.Columns[5].DataPropertyName = "bidder_id";
                  
                    
                    dgvCntr.DataSource = ds.Tables[0];
                    dgvCntr.AllowUserToAddRows = true;
                    dgvCntr.DataError += new DataGridViewDataErrorEventHandler(dgvContracts_DataError);
                }
                sqlCn.Close();
            }

            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                    DataSet ds = new DataSet();
                    sqlda.Fill(ds);
                    dgvCntr.AllowUserToAddRows = false;
                    //ds.Tables[0].Columns[0].DataType = typeof(string);

                    dgvCntr.Columns[0].DataPropertyName = "co_id";
                    dgvCntr.Columns[1].DataPropertyName = "co_type_name";
                    dgvCntr.Columns[2].DataPropertyName = "ContractAmount";
                    dgvCntr.Columns[3].DataPropertyName = "cp_tender_award";
                    dgvCntr.Columns[4].DataPropertyName = "proj_id";
                    dgvCntr.Columns[5].DataPropertyName = "bidder_id";
                    

                    dgvCntr.DataSource = ds.Tables[0];

                    dgvCntr.AllowUserToAddRows = true;
                    dgvCntr.DataError += new DataGridViewDataErrorEventHandler(dgvContracts_DataError);
                }
                sqlCn.Close();
            }
            try
            {
                for (int i = 0; i < dgvCntr.Rows.Count; i++)
                {
                    if (i == (dgvCntr.Rows.Count - 1))
                    {
                        dgvCntr.Rows[i].Cells[3].Value = "";
                        //dgvCntr.Rows[i].Cells[1].Value = "";
                        //dgvCntr.Rows[i].Cells[2].Value = "";
                        //dgvCntr.Rows[i].Cells[3].Value = "";
                        //dgvCntr.Rows[i].Cells[4].Value = "";
                        //dgvCntr.Rows[i].Cells[7].Value = "";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            dgvCntr.DefaultCellStyle.WrapMode = DataGridViewTriState.True;

            //dgvCntr.Columns[0].Visible = false;
            //dgvCntr.Columns[4].Visible = false;
            //dgvCntr.Columns[5].Visible = false;
        }
        public string FillEmployee_dgvComboValue(int cmpID)
        {
            string _cmpType = string.Empty;
            SqlConnection sqlConn = new SqlConnection(connStr);
            sqlConn.Open();
            string sqlQuery = "SELECT COMPANY_TYPE.co_type_name, COMPANY.co_id FROM COMPANY INNER JOIN COMPANY_TYPE ON COMPANY.co_type_id = COMPANY_TYPE.co_type_id WHERE (COMPANY.co_id = " + cmpID + ")";

            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                _cmpType = sqlReader[0].ToString();
            }
            sqlReader.Close();
            sqlConn.Close();
            return _cmpType;
        }
        public string FillComapany_dgvComboValue(int cmpID)
        {
            string _cmpType = string.Empty;
            SqlConnection sqlConn = new SqlConnection(connStr);
            sqlConn.Open();
            string sqlQuery = "SELECT COMPANY_TYPE.co_type_name, COMPANY.co_id FROM COMPANY INNER JOIN COMPANY_TYPE ON COMPANY.co_type_id = COMPANY_TYPE.co_type_id WHERE (COMPANY.co_id = " + cmpID + ")";

            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                _cmpType = sqlReader[0].ToString();
            }
            sqlReader.Close();
            sqlConn.Close();
            return _cmpType;
        }
        public int FillDateIDOfSelectedCompany_dgvComboValue(int PrjiD, int cmpID)
        {
            int _dateID = 0;
            SqlConnection sqlConn = new SqlConnection(connStr);
            sqlConn.Open();
            string sqlQuery = "SELECT date_id, proj_id, stage_id, co_id FROM TenderDatesInfo WHERE (proj_id = " + PrjiD + ") AND (co_id =  " + cmpID + ")";

            SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sqlReader = sqlCom.ExecuteReader();
            while (sqlReader.Read())
            {
                _dateID = Convert.ToInt32(sqlReader[0].ToString());
            }
            sqlReader.Close();
            sqlConn.Close();
            return _dateID;
        }
        public void CPMultipleRecords_Insert_Update(DataGridView dgvCpDataEntry,SqlConnection sqlConn,SqlCommand cmd,int prjid)   // CPMultipleRecords_Insert_Update
        {
            int x;
            x = 0;
            foreach (DataGridViewRow dr in dgvCpDataEntry.Rows)
            {
                x = x + 1;
                if (x < dgvCpDataEntry.Rows.Count)
                {
                    // string Value0 = Convert.ToString(dr.Cells[0].Value.ToString());
                    string Value0 = Convert.ToString(dr.Cells[0].Value.ToString());
                    string Value1 = Convert.ToString(dr.Cells[1].Value.ToString());
                    string Value2 = Convert.ToString(dr.Cells[2].Value.ToString());
                    string Value3 = Convert.ToString(dr.Cells[3].Value.ToString());
                    string Value4 = Convert.ToString(dr.Cells[4].Value.ToString());
                    string Value5 = Convert.ToString(dr.Cells[5].Value.ToString());
                    string Value6 = Convert.ToString(dr.Cells[6].Value.ToString());
                    string Value7 = Convert.ToString(dr.Cells[7].Value.ToString());

                    string Value8 = Convert.ToString(dr.Cells[8].Value.ToString());
                    string Value9 = Convert.ToString(dr.Cells[9].Value.ToString());
                    string Value10 = Convert.ToString(dr.Cells[10].Value.ToString());
                    string Value11 = Convert.ToString(dr.Cells[11].Value.ToString());
                    string Value12 = Convert.ToString(dr.Cells[12].Value.ToString());

                    // string Value8 = Convert.ToString(dr.Cells[8].Value.ToString());

                    if (Value7 == "" || Value7 == null)
                    {
                        Int16 cpdateId;
                        cpdateId = maxValue("SELECT MAX(DATE_ID)+1 FROM TenderDatesInfo");


                        cmd.Connection = sqlConn;

                        int stage_Id = 0;
                        stage_Id = 4;
                        // cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,cp_sent_dep_sign,cp_receive_dep_sent_prsd,cp_sent_fd_commit,cp_receive_fd_commit,cp_distribution,remarks,employee_id,CreateDate,CreateUser) VALUES(@dateId,@projId,@stageId,@cp_sent_dep_sign,@cp_receive_dep_sent_prsd,@cp_sent_fd_commit,@cp_receive_fd_commit,@cp_distribution,@remarks,@empID,@CreateDate,@CreateUser)";

                        // cp_received_of_doc,cp_request_start_date,cp_start_date_receive,cp_notice_contractor_to_sign,cp_due_date_pb

                        cmd.CommandText = @"INSERT INTO TenderDatesInfo(date_id,proj_id,stage_id,cp_sent_dep_sign,cp_receive_dep_sent_prsd,cp_sent_fd_commit, " +
                        " cp_receive_fd_commit,cp_distribution,remarks,StaffInCharge,CreateDate,CreateUser,cp_received_of_doc, " +
                        " cp_request_start_date,cp_start_date_receive,cp_notice_contractor_to_sign,cp_due_date_pb) " +
                        " VALUES(@dateId,@projId,@stageId,@cp_sent_dep_sign, " +
                        " @cp_receive_dep_sent_prsd,@cp_sent_fd_commit,@cp_receive_fd_commit,@cp_distribution,@remarks,@Staff,@CreateDate,@CreateUser, " +
                        " @cpreceivedofdoc,@cprequeststartdate,@cpstartdatereceive,@cpnotice_contractortosign,@cpduedatepb)";

                        cmd.Parameters.AddWithValue("@projId", prjid);
                        cmd.Parameters.AddWithValue("@stageId", stage_Id);

                        if (Value0 != "")
                            cmd.Parameters.AddWithValue("@cp_sent_dep_sign", Value0);
                        else
                            cmd.Parameters.AddWithValue("@cp_sent_dep_sign", DBNull.Value);
                        if (Value1 != "")
                            cmd.Parameters.AddWithValue("@cp_receive_dep_sent_prsd", Value1);
                        else
                            cmd.Parameters.AddWithValue("@cp_receive_dep_sent_prsd", DBNull.Value);
                        if (Value2 != "")
                            cmd.Parameters.AddWithValue("@cp_sent_fd_commit", Value2);
                        else
                            cmd.Parameters.AddWithValue("@cp_sent_fd_commit", DBNull.Value);
                        if (Value3 != "")
                            cmd.Parameters.AddWithValue("@cp_receive_fd_commit", Value3);
                        else
                            cmd.Parameters.AddWithValue("@cp_receive_fd_commit", DBNull.Value);

                        if (Value4 != "")
                            cmd.Parameters.AddWithValue("@cp_distribution", Value4);
                        else
                            cmd.Parameters.AddWithValue("@cp_distribution", DBNull.Value);

                        cmd.Parameters.AddWithValue("@remarks", Value5);
                        cmd.Parameters.AddWithValue("@Staff", Value6);
                        //cmd.Parameters.AddWithValue("@empID", Value6);

                        cmd.Parameters.AddWithValue("@CreateDate", DateTime.Now.ToString());
                        cmd.Parameters.AddWithValue("@CreateUser", _userName);
                        cmd.Parameters.AddWithValue("@dateId", cpdateId);



                        if (Value8 != "")
                            cmd.Parameters.AddWithValue("@cpreceivedofdoc", Value8);
                        else
                            cmd.Parameters.AddWithValue("@cpreceivedofdoc", DBNull.Value);

                        if (Value9 != "")
                            cmd.Parameters.AddWithValue("@cprequeststartdate", Value9);
                        else
                            cmd.Parameters.AddWithValue("@cprequeststartdate", DBNull.Value);

                        if (Value10 != "")
                            cmd.Parameters.AddWithValue("@cpstartdatereceive", Value10);
                        else
                            cmd.Parameters.AddWithValue("@cpstartdatereceive", DBNull.Value);

                        if (Value11 != "")
                            cmd.Parameters.AddWithValue("@cpnotice_contractortosign", Value11);
                        else
                            cmd.Parameters.AddWithValue("@cpnotice_contractortosign", DBNull.Value);

                        if (Value12 != "")
                            cmd.Parameters.AddWithValue("@cpduedatepb", Value12);
                        else
                            cmd.Parameters.AddWithValue("@cpduedatepb", DBNull.Value);

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                    else
                    {

                        cmd.Connection = sqlConn;
                        int stage_Id = 0;
                        stage_Id = 4;
                        // cmd.CommandText = @"UPDATE TenderDatesInfo set cp_sent_dep_sign=@cp_sent_dep_sign,cp_receive_dep_sent_prsd=@cp_receive_dep_sent_prsd,cp_sent_fd_commit=@cp_sent_fd_commit,cp_receive_fd_commit=@cp_receive_fd_commit,cp_distribution=@cp_distribution,remarks=@remarks,[employee_id]=@empID, UpdateDate=@UpdateDate,updateuser=@updateuser where date_id=@dateId";

                        cmd.CommandText = @"UPDATE TenderDatesInfo set cp_sent_dep_sign=@cp_sent_dep_sign,cp_receive_dep_sent_prsd=@cp_receive_dep_sent_prsd, " +
                        " cp_sent_fd_commit=@cp_sent_fd_commit,cp_receive_fd_commit=@cp_receive_fd_commit,cp_distribution=@cp_distribution,remarks=@remarks, " +
                        " [StaffIncharge]=@Staff, UpdateDate=@UpdateDate,updateuser=@updateuser,cp_received_of_doc=@cpreceivedofdoc,cp_request_start_date=@cprequeststartdate, " +
                            " cp_start_date_receive=@cpstartdatereceive,cp_notice_contractor_to_sign=@cpnotice_contractortosign,cp_due_date_pb=@cpduedatepb where date_id=@dateId";
                        cmd.Parameters.AddWithValue("@projId",prjid);
                        cmd.Parameters.AddWithValue("@stageId", stage_Id);
                        if (Value0 != "")
                            cmd.Parameters.AddWithValue("@cp_sent_dep_sign", Value0);
                        else
                            cmd.Parameters.AddWithValue("@cp_sent_dep_sign", DBNull.Value);
                        if (Value1 != "")
                            cmd.Parameters.AddWithValue("@cp_receive_dep_sent_prsd", Value1);
                        else
                            cmd.Parameters.AddWithValue("@cp_receive_dep_sent_prsd", DBNull.Value);
                        if (Value2 != "")
                            cmd.Parameters.AddWithValue("@cp_sent_fd_commit", Value2);
                        else
                            cmd.Parameters.AddWithValue("@cp_sent_fd_commit", DBNull.Value);
                        if (Value3 != "")
                            cmd.Parameters.AddWithValue("@cp_receive_fd_commit", Value3);
                        else
                            cmd.Parameters.AddWithValue("@cp_receive_fd_commit", DBNull.Value);

                        if (Value4 != "")
                            cmd.Parameters.AddWithValue("@cp_distribution", Value4);
                        else
                            cmd.Parameters.AddWithValue("@cp_distribution", DBNull.Value);
                        cmd.Parameters.AddWithValue("@remarks", Value5);
                        //cmd.Parameters.AddWithValue("@empID", Value6);

                        cmd.Parameters.AddWithValue("@Staff", Value6);
                        cmd.Parameters.AddWithValue("@UpdateDate", DateTime.Now.ToString());
                        cmd.Parameters.AddWithValue("@updateuser", _userName);
                        cmd.Parameters.AddWithValue("@dateId", Value7);

                        if (Value8 != "")
                            cmd.Parameters.AddWithValue("@cpreceivedofdoc", Value8);
                        else
                            cmd.Parameters.AddWithValue("@cpreceivedofdoc", DBNull.Value);

                        if (Value9 != "")
                            cmd.Parameters.AddWithValue("@cprequeststartdate", Value9);
                        else
                            cmd.Parameters.AddWithValue("@cprequeststartdate", DBNull.Value);

                        if (Value10 != "")
                            cmd.Parameters.AddWithValue("@cpstartdatereceive", Value10);
                        else
                            cmd.Parameters.AddWithValue("@cpstartdatereceive", DBNull.Value);

                        if (Value11 != "")
                            cmd.Parameters.AddWithValue("@cpnotice_contractortosign", Value11);
                        else
                            cmd.Parameters.AddWithValue("@cpnotice_contractortosign", DBNull.Value);

                        if (Value12 != "")
                            cmd.Parameters.AddWithValue("@cpduedatepb", Value12);
                        else
                            cmd.Parameters.AddWithValue("@cpduedatepb", DBNull.Value);


                        int exUpdated = cmd.ExecuteNonQuery();

                        cmd.Parameters.Clear();
                    }
                }
            }
        }
        public void UpdateContractsData(DataGridView dgvcontr , SqlCommand cmd, SqlConnection sqlConn)
        {
            int x;
            x = 0;
            foreach (DataGridViewRow dr in dgvcontr.Rows)
            {
                
                if (x < dgvcontr.Rows.Count)
                {
                    //modified by Varun
                    if (dr.Cells[0].Value == null)
                    {
                        continue;
                    }
                    if (dr.Cells[0].Value.ToString() == "")
                    {
                        continue;
                    }
                    string Value0 =  Convert.ToString(dr.Cells[3].Value.ToString());    // bidID
                    string Value1 =  Convert.ToString(dr.Cells[4].Value.ToString());
                    string Value2 =  Convert.ToString(dr.Cells[5].Value.ToString());
                    string Value3 =  Convert.ToString(dr.Cells[6].Value.ToString());  
                    string Value4 =  Convert.ToString(dr.Cells[7].Value.ToString());
                    string Value5 =  Convert.ToString(dr.Cells[8].Value.ToString());
                    string Value6 =  Convert.ToString(dr.Cells[9].Value.ToString());                   

                    if (Value6 != "" || Value6!= null)
                    {
                        cmd.Connection = sqlConn;

                        cmd.CommandText = @"Update [CONTRACTORS] set StaffInCharge = @Staff, " +
                         " cp_received_of_doc = @ReceivedOfDoc, " + 
                         " cp_request_start_date = @reqDeptStartDate, " +
                         " cp_start_date_receive = @startDateReceive, " +
                         " cp_notice_contractor_to_sign = @noticeSentforSign, " +
                         " cp_due_date_pb = @cpDueDate_PB , " +
                         " update_date_cp=@UpdateDate,update_user_cp=@updateuser where bidder_id=@bidder_id";

                        cmd.Parameters.AddWithValue("@bidder_id", Value6);

                        if (Value0 != "")
                            cmd.Parameters.AddWithValue("@Staff", Value0);
                        else
                            cmd.Parameters.AddWithValue("@Staff", DBNull.Value);

                        if (Value1 != "")
                            cmd.Parameters.AddWithValue("@ReceivedOfDoc", Value1);
                        else
                            cmd.Parameters.AddWithValue("@ReceivedOfDoc", DBNull.Value);

                        if (Value2 != "")
                            cmd.Parameters.AddWithValue("@reqDeptStartDate", Value2);
                        else
                            cmd.Parameters.AddWithValue("@reqDeptStartDate", DBNull.Value);

                        if (Value3 != "")
                            cmd.Parameters.AddWithValue("@startDateReceive", Value3);
                        else
                            cmd.Parameters.AddWithValue("@startDateReceive", DBNull.Value);

                        if (Value4 != "")
                            cmd.Parameters.AddWithValue("@noticeSentforSign", Value4);
                        else
                            cmd.Parameters.AddWithValue("@noticeSentforSign", DBNull.Value);

                        if (Value5 != "")
                            cmd.Parameters.AddWithValue("@cpDueDate_PB", Value5);
                        else
                            cmd.Parameters.AddWithValue("@cpDueDate_PB", DBNull.Value);

                        cmd.Parameters.AddWithValue("@UpdateDate", DateTime.Now.ToString());
                        cmd.Parameters.AddWithValue("@updateuser", _userName);

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        //modified by Varun
                        x++;
                    }
                }
            }
        }
        public void UpdateContractsMultipleData(DataGridView dgvCpDataEntry, SqlCommand cmd, SqlConnection sqlConn)
        {
            int x;
            x = 0;
            foreach (DataGridViewRow dr in dgvCpDataEntry.Rows)
            {
                
                if (x < dgvCpDataEntry.Rows.Count)
                {
                    //modified by Varun
                    if (dr.Cells[0].Value == null)
                    {
                        continue;
                    }
                    if (dr.Cells[0].Value.ToString() == "")
                    {
                        continue;
                    }
                    //string Value0 = Convert.ToString(dr.Cells[0].Value.ToString());    // bidID
                    string Value1 = Convert.ToString(dr.Cells[1].Value.ToString());
                    string Value2 = Convert.ToString(dr.Cells[2].Value.ToString());
                    string Value3 = Convert.ToString(dr.Cells[3].Value.ToString());
                    string Value4 = Convert.ToString(dr.Cells[4].Value.ToString());
                    string Value5 = Convert.ToString(dr.Cells[5].Value.ToString());
                    string Value6 = Convert.ToString(dr.Cells[6].Value.ToString());
                    string Value7 = Convert.ToString(dr.Cells[7].Value.ToString());
                    string Value8 = Convert.ToString(dr.Cells[8].Value.ToString());
                    string Value9 = Convert.ToString(dr.Cells[9].Value.ToString());
                    
                    

                    if (Value9 != "" || Value9 != null)
                    {
                        cmd.Connection = sqlConn;
                        cmd.CommandText = @"Update [CONTRACTORS] set cp_contractor_sign = @cntrSign, " +
                            " cp_sent_dep_sign =  @SentFor_deptSign, " +
                            " cp_receive_dep_sent_prsd = @Prsd, " +
                            " cp_sent_fd_commit = @SentToFinance, " +
                            " cp_receive_fd_commit = @RecFromFinance, " +
                            " cp_distribution = @Distribustion," +
                            " contract_no = @cntrNo," +
                            " remarks =@cntrRemarks, " +
                            " update_date_cp=@UpdateDate,update_user_cp=@updateuser where bidder_id=@bidder_id";

                        cmd.Parameters.AddWithValue("@bidder_id", Value9);

                        if (Value1 != "")
                            cmd.Parameters.AddWithValue("@cntrSign", Value1);
                        else
                            cmd.Parameters.AddWithValue("@cntrSign", DBNull.Value);

                        if (Value2 != "")
                            cmd.Parameters.AddWithValue("@SentFor_deptSign", Value2);
                        else
                            cmd.Parameters.AddWithValue("@SentFor_deptSign", DBNull.Value);

                        if (Value3 != "")
                            cmd.Parameters.AddWithValue("@Prsd", Value3);
                        else
                            cmd.Parameters.AddWithValue("@Prsd", DBNull.Value);

                        if (Value4 != "")
                            cmd.Parameters.AddWithValue("@SentToFinance", Value4);
                        else
                            cmd.Parameters.AddWithValue("@SentToFinance", DBNull.Value);

                        if (Value5 != "")
                            cmd.Parameters.AddWithValue("@RecFromFinance", Value5);
                        else
                            cmd.Parameters.AddWithValue("@RecFromFinance", DBNull.Value);

                        if (Value6 != "")
                            cmd.Parameters.AddWithValue("@Distribustion", Value6);
                        else
                            cmd.Parameters.AddWithValue("@Distribustion", DBNull.Value);

                        cmd.Parameters.AddWithValue("@cntrNo", Value7);   

                        cmd.Parameters.AddWithValue("@cntrRemarks", Value8);          
                  

                        cmd.Parameters.AddWithValue("@UpdateDate", DateTime.Now.ToString());
                        cmd.Parameters.AddWithValue("@updateuser", _userName);

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        //modified by Varun
                        x++;
                    }
                }
            }
        }
        public int GetMaxDateID()
        {
            int maxDate = 0;
            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                String readData = "SELECT Max(DATE_ID)+1 FROM TenderDatesInfo";
                SqlCommand cmd = new SqlCommand(readData, sqlCn);
                maxDate = Convert.ToInt16(cmd.ExecuteScalar());
                sqlCn.Close();
            }
            return maxDate;
        }

        //Added By Varun         
        static DataGridViewComboBoxColumn colCboxCategory = null;
        public DataGridViewComboBoxColumn ColCmbBoxCategory
        {
            get { return colCboxCategory; }
            set { colCboxCategory = value; }
        }

        
        public void CreateStaff_ComboBoxForGrid(DataGridView dgvContracts)
        {
            string strQuery = "";            
            strQuery = "SELECT employee_id,ShortName,LastName FROM CONTACTS where ShortName is not null order by ShortName";
            try
            {
                using (SqlConnection sqlCn = new SqlConnection(connStr))
                {
                    sqlCn.Open();
                    using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                    {           
                        colCboxCategory = new DataGridViewComboBoxColumn();
                        colCboxCategory.Name = "Staff";
                        colCboxCategory.HeaderText = "Handling By*";
                        sqlCmd.CommandText = strQuery;
                        sqlCmd.Connection = sqlCn;
                        SqlDataReader sqlReader = sqlCmd.ExecuteReader();
                        if (sqlReader.HasRows)
                        {
                            while (sqlReader.Read())
                            {
                                colCboxCategory.Items.Add(sqlReader[1] + " " + sqlReader[2]);
                            }
                        }
                        sqlReader.Close();
                        sqlCmd.Dispose();                        
                        ColCmbBoxCategory = colCboxCategory;
                        colCboxCategory.Name = "Staff";
                        colCboxCategory.HeaderText = "Handling By*";                         
                        colCboxCategory.ValueMember = "Value";
                        colCboxCategory.DisplayMember = "Description";
                        colCboxCategory.Width = 180;
                        //Added By Varun
                        colCboxCategory.DisplayStyle = DataGridViewComboBoxDisplayStyle.DropDownButton;
                        dgvContracts.EnableHeadersVisualStyles = true; 
                        colCboxCategory.DataPropertyName = "StaffInCharge";
                        dgvContracts.Columns.Add(colCboxCategory);
                        dgvContracts.DataError += new DataGridViewDataErrorEventHandler(dgvContracts_DataError);

                    }
                    sqlCn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void CreateColumnsForCP_Contractors(DataGridView dgvContracts, int cp_PrjiD)
        {
            DataGridViewTextBoxColumn colCboxCategory = new DataGridViewTextBoxColumn();
            colCboxCategory.Name = "CmpName";
            colCboxCategory.HeaderText = "Successfull Bidder*";
            colCboxCategory.Width = 180;
            colCboxCategory.ReadOnly = true;
            dgvContracts.Columns.Add(colCboxCategory);

            DataGridViewTextBoxColumn colCboxCategory2 = new DataGridViewTextBoxColumn();
            colCboxCategory2.Name = "Amount";
            colCboxCategory2.HeaderText = "Award Amount";
            colCboxCategory2.Width = 50;
            colCboxCategory2.ReadOnly = true;
            dgvContracts.Columns.Add(colCboxCategory2);

            CalendarColumn colCboxCategory3 = new CalendarColumn();
            colCboxCategory3.Name = "AwardLetter";
            colCboxCategory3.HeaderText = "Date of Letter of Award";
            colCboxCategory3.Width = 50;
            colCboxCategory3.ReadOnly = true;
            dgvContracts.Columns.Add(colCboxCategory3);

            CreateStaff_ComboBoxForGrid(dgvContracts);

            CalendarColumn colForRecAwrdDoc = new CalendarColumn();
            colForRecAwrdDoc.Name = "RecAwardDocument";
            colForRecAwrdDoc.HeaderText = "Received of Award Document";
            colForRecAwrdDoc.Width = 50;
            dgvContracts.Columns.Add(colForRecAwrdDoc);

            CalendarColumn colForReqDept = new CalendarColumn();
            colForReqDept.Name = "ReqDept";
            colForReqDept.HeaderText = "Request Dept to provide Start Date";
            colForReqDept.Width = 50;
            dgvContracts.Columns.Add(colForReqDept);

            CalendarColumn colForStartDateRec = new CalendarColumn();
            colForStartDateRec.Name = "strtDateRec";
            colForStartDateRec.HeaderText = "Start Date Received";
            colForStartDateRec.Width = 50;
            dgvContracts.Columns.Add(colForStartDateRec);

            CalendarColumn colForNoticeSent = new CalendarColumn();
            colForNoticeSent.Name = "NtcSent";
            colForNoticeSent.HeaderText = "Notice Sent to Tenderer to Sign";
            colForNoticeSent.Width = 50;
            dgvContracts.Columns.Add(colForNoticeSent);

            CalendarColumn colForDueDate = new CalendarColumn();
            colForDueDate.Name = "pBond";
            colForDueDate.HeaderText = "Due date of Submission of p.Bond, etc.Signinig of Contract";
            colForDueDate.Width = 50;
            dgvContracts.Columns.Add(colForDueDate);


            DataGridViewTextBoxColumn colCboxBidder = new DataGridViewTextBoxColumn();
            colCboxBidder.Name = "BidID";
            colCboxBidder.HeaderText = "BidderID";
            colCboxBidder.Width = 180;
            colCboxBidder.ReadOnly = true;
            dgvContracts.Columns.Add(colCboxBidder);

            dgvContracts.DataError += new DataGridViewDataErrorEventHandler(dgvContracts_DataError);

            dgvContracts.ColumnHeadersDefaultCellStyle.BackColor = Color.Gainsboro;
            dgvContracts.ColumnHeadersDefaultCellStyle.ForeColor = Color.Chocolate;
            dgvContracts.ColumnHeadersDefaultCellStyle.Font = new Font(dgvContracts.Font, FontStyle.Bold);
            //dgvContracts.EnableHeadersVisualStyles = false;

            dgvContracts.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
        }
        public void FillContractsGrid(DataGridView dgvCntr, int cp_prjiD)
        {
            string strQuery = "";
            string strStaffInCharge = "";
            strQuery = "SELECT COMPANY.co_name, CONTRACTORS.ContractAmount, CONTRACTORS.cp_tender_award, CONTRACTORS.StaffInCharge, " +
                      " CONTRACTORS.cp_received_of_doc, CONTRACTORS.cp_request_start_date, CONTRACTORS.cp_start_date_receive, " +
                      " CONTRACTORS.cp_notice_contractor_to_sign, CONTRACTORS.cp_due_date_pb,CONTRACTORS.bidder_id FROM CONTRACTORS INNER JOIN " +
                      " COMPANY ON CONTRACTORS.co_id = COMPANY.co_id WHERE (CONTRACTORS.proj_id = " + cp_prjiD + ")";
            
            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                int rowCounter = 0;
                //Modified By Varun
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    SqlDataReader sqlReader = sqlCmd.ExecuteReader();
                    if (sqlReader.HasRows)
                    {
                        while (sqlReader.Read())
                        {

                            dgvCntr.Rows.Add();
                            dgvCntr.Rows[rowCounter].Cells[0].Value = sqlReader["co_name"];
                            dgvCntr.Rows[rowCounter].Cells[1].Value = sqlReader["ContractAmount"];
                            dgvCntr.Rows[rowCounter].Cells[2].Value = sqlReader["cp_tender_award"];
                            strStaffInCharge = sqlReader["StaffInCharge"].ToString();
                            dgvCntr.Rows[rowCounter].Cells[3].Value = sqlReader["StaffInCharge"];
                            if (strStaffInCharge != "")
                            {
                                DataGridViewComboBoxColumn dgvColBoxCol = ColCmbBoxCategory;
                                dgvColBoxCol.Items.Add(strStaffInCharge);
                                dgvColBoxCol.Selected = true;
                            }
                            dgvCntr.Rows[rowCounter].Cells[4].Value = sqlReader["cp_received_of_doc"];
                            dgvCntr.Rows[rowCounter].Cells[5].Value = sqlReader["cp_request_start_date"];
                            dgvCntr.Rows[rowCounter].Cells[6].Value = sqlReader["cp_start_date_receive"];
                            dgvCntr.Rows[rowCounter].Cells[7].Value = sqlReader["cp_notice_contractor_to_sign"];
                            dgvCntr.Rows[rowCounter].Cells[8].Value = sqlReader["cp_due_date_pb"];
                            dgvCntr.Rows[rowCounter].Cells[9].Value = sqlReader["bidder_id"];

                            rowCounter++;
                        }
                    }
                    //dgvCntr.AllowUserToAddRows = true;
                    dgvCntr.DataError += new DataGridViewDataErrorEventHandler(dgvContracts_DataError);
                }
                sqlCn.Close();                 
            }           
            dgvCntr.Columns[9].Visible = false;
            ClearDatesOf_dgvContracts(dgvCntr);
            dgvCntr.DefaultCellStyle.WrapMode = DataGridViewTriState.True; 
        }
        private void ClearDatesOf_dgvContracts(DataGridView dgvContracts)
        {
            try
            {
                for (int i = 0; i < dgvContracts.Rows.Count; i++)
                {
                    if (i == (dgvContracts.Rows.Count - 1))
                    {
                        //dgvContracts.Rows[i].Cells[1].Value = "";
                        dgvContracts.Rows[i].Cells[2].Value = "";
                        //dgvContracts.Rows[i].Cells[3].Value = "";
                        dgvContracts.Rows[i].Cells[4].Value = "";
                        dgvContracts.Rows[i].Cells[5].Value = "";
                        dgvContracts.Rows[i].Cells[6].Value = "";
                        dgvContracts.Rows[i].Cells[7].Value = "";
                        dgvContracts.Rows[i].Cells[8].Value = "";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void ClearDatesOf_dgvCpDataEntry(DataGridView dgvCpDataEntry)
        {
            try
            {
                for (int i = 0; i < dgvCpDataEntry.Rows.Count; i++)
                {
                    if (i == (dgvCpDataEntry.Rows.Count - 1))
                    {
                        dgvCpDataEntry.Rows[i].Cells[1].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[2].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[3].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[4].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[5].Value = "";
                        dgvCpDataEntry.Rows[i].Cells[6].Value = "";
                        //dgvCpDataEntry.Rows[i].Cells[8].Value = "";             
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void CreateColumnsForCP_ContractorsMultiple(DataGridView dgvCpDataEntry, int cp_PrjiD)
        {
            DataGridViewTextBoxColumn colCboxCategory = new DataGridViewTextBoxColumn();
            colCboxCategory.Name = "CmpName";
            colCboxCategory.HeaderText = "Successfull Bidder*";
            colCboxCategory.Width = 180;
            colCboxCategory.ReadOnly = true;
            dgvCpDataEntry.Columns.Add(colCboxCategory);

            CalendarColumn colCboxCategory2 = new CalendarColumn();
            colCboxCategory2.Name = "AwardLetter";
            colCboxCategory2.HeaderText = "Date of Sign Contract";          
            colCboxCategory2.Width = 50;
            dgvCpDataEntry.Columns.Add(colCboxCategory2);

            CalendarColumn colCboxCategory3 = new CalendarColumn();
            colCboxCategory3.Name = "SignatureFromDept";
            colCboxCategory3.HeaderText = "Sent to dept for Signature";
            colCboxCategory3.Width = 50;
            dgvCpDataEntry.Columns.Add(colCboxCategory3);

            //CreateStaff_ComboBoxForGrid(dgvCpMulti);

            CalendarColumn colForRecAwrdDoc = new CalendarColumn();
            colForRecAwrdDoc.Name = "RecAwardDocument";
            colForRecAwrdDoc.HeaderText = "Received from Dept. and Sent to PRSD. for Sign";
            colForRecAwrdDoc.Width = 50;
            dgvCpDataEntry.Columns.Add(colForRecAwrdDoc);

            CalendarColumn colForReqDept = new CalendarColumn();
            colForReqDept.Name = "ReqDept";
            colForReqDept.HeaderText = "Sent to Finance Dept for Committment";
            colForReqDept.Width = 50;
            dgvCpDataEntry.Columns.Add(colForReqDept);

            CalendarColumn colForStartDateRec = new CalendarColumn();
            colForStartDateRec.Name = "strtDateRec";
            colForStartDateRec.HeaderText = "Received From Finance Dept";
            colForStartDateRec.Width = 50;
            dgvCpDataEntry.Columns.Add(colForStartDateRec);

            CalendarColumn colForNoticeSent = new CalendarColumn();
            colForNoticeSent.Name = "NtcSent";
            colForNoticeSent.HeaderText = "Distribution";
            colForNoticeSent.Width = 50;
            dgvCpDataEntry.Columns.Add(colForNoticeSent);

            DataGridViewTextBoxColumn colCboxCntrNo = new DataGridViewTextBoxColumn();
            colCboxCntrNo.Name = "CntrNo";
            colCboxCntrNo.HeaderText = "Contract No";
            colCboxCntrNo.Width = 180;           
            dgvCpDataEntry.Columns.Add(colCboxCntrNo);

            DataGridViewTextBoxColumn colCboxRemarks = new DataGridViewTextBoxColumn();
            colCboxRemarks.Name = "Remarks";
            colCboxRemarks.HeaderText = "Remarks";
            colCboxRemarks.Width = 180;
            dgvCpDataEntry.Columns.Add(colCboxRemarks);

            DataGridViewTextBoxColumn colCboxBidder = new DataGridViewTextBoxColumn();
            colCboxBidder.Name = "BidID";
            colCboxBidder.HeaderText = "BidderID";
            colCboxBidder.Width = 180;
            colCboxBidder.ReadOnly = true;
            dgvCpDataEntry.Columns.Add(colCboxBidder);

         //   dgvCpMulti.DataError += new DataGridViewDataErrorEventHandler(dgvCpMulti_DataError);

            dgvCpDataEntry.ColumnHeadersDefaultCellStyle.BackColor = Color.Gainsboro;
            dgvCpDataEntry.ColumnHeadersDefaultCellStyle.ForeColor = Color.Chocolate;
            dgvCpDataEntry.ColumnHeadersDefaultCellStyle.Font = new Font(dgvCpDataEntry.Font, FontStyle.Bold);
            dgvCpDataEntry.EnableHeadersVisualStyles = false;

            dgvCpDataEntry.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
        }
        public void FillContractsGrid_Multiple(DataGridView dgvCpMulti, int cp_prjiD)
        {
            string strQuery = "";
            strQuery = "SELECT COMPANY.co_name, CONTRACTORS.cp_contractor_sign, CONTRACTORS.cp_sent_dep_sign, CONTRACTORS.cp_receive_dep_sent_prsd, " +
                      " CONTRACTORS.cp_sent_fd_commit, CONTRACTORS.cp_receive_fd_commit, CONTRACTORS.cp_distribution, CONTRACTORS.contract_no, " +
                      " CONTRACTORS.Remarks, CONTRACTORS.bidder_id FROM CONTRACTORS INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id " +
                      " WHERE (CONTRACTORS.proj_id = " + cp_prjiD + ")";

            using (SqlConnection sqlCn = new SqlConnection(connStr))
            {
                sqlCn.Open();
                using (SqlCommand sqlCmd = new SqlCommand(strQuery, sqlCn))
                {
                    SqlDataAdapter sqlda = new SqlDataAdapter(sqlCmd);
                    DataSet ds = new DataSet();
                    sqlda.Fill(ds);
                    dgvCpMulti.AllowUserToAddRows = false;

                    dgvCpMulti.Columns[0].DataPropertyName = "co_name";
                    dgvCpMulti.Columns[1].DataPropertyName = "cp_contractor_sign";
                    dgvCpMulti.Columns[2].DataPropertyName = "cp_sent_dep_sign";
                    dgvCpMulti.Columns[3].DataPropertyName = "cp_receive_dep_sent_prsd";
                    dgvCpMulti.Columns[4].DataPropertyName = "cp_sent_fd_commit";
                    dgvCpMulti.Columns[5].DataPropertyName = "cp_receive_fd_commit";
                    dgvCpMulti.Columns[6].DataPropertyName = "cp_distribution";
                    dgvCpMulti.Columns[7].DataPropertyName = "contract_no";
                    dgvCpMulti.Columns[8].DataPropertyName = "Remarks";
                    dgvCpMulti.Columns[9].DataPropertyName = "bidder_id";
                    dgvCpMulti.DataSource = ds.Tables[0];

                    dgvCpMulti.AllowUserToAddRows = true;
                    //dgvCpMulti.DataError += new DataGridViewDataErrorEventHandler(dgvContracts_DataError);
                }
                sqlCn.Close();
            }
            //dgvCntr.Columns[5].Visible = false;
            dgvCpMulti.Columns[9].Visible = false;
            ClearDatesOf_dgvCpDataEntry(dgvCpMulti);
        }

    }
}
