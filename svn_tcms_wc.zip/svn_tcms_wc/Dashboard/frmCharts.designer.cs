﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title1 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title2 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title3 = new System.Windows.Forms.DataVisualization.Charting.Title();
            this.ChartSent = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.ChartProjects = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.ChartReceived = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.cmbCommitteNames = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.btnTndrTypes = new System.Windows.Forms.Button();
            this.btnCommitte = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.label3 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.lnkOngoingProjects = new System.Windows.Forms.LinkLabel();
            this.lnkInactive = new System.Windows.Forms.LinkLabel();
            this.lnkViewProjects = new System.Windows.Forms.LinkLabel();
            this.lnkContacts = new System.Windows.Forms.LinkLabel();
            this.lnkCompany = new System.Windows.Forms.LinkLabel();
            this.lnkAddProject = new System.Windows.Forms.LinkLabel();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.ChartSent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ChartProjects)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ChartReceived)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.SuspendLayout();
            // 
            // ChartSent
            // 
            this.ChartSent.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.Center;
            this.ChartSent.BorderlineColor = System.Drawing.Color.Blue;
            this.ChartSent.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash;
            chartArea1.AxisX.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.DashDotDot;
            chartArea1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            chartArea1.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.Center;
            chartArea1.Name = "ChartArea1";
            this.ChartSent.ChartAreas.Add(chartArea1);
            legend1.Alignment = System.Drawing.StringAlignment.Center;
            legend1.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top;
            legend1.Name = "Legend1";
            this.ChartSent.Legends.Add(legend1);
            this.ChartSent.Location = new System.Drawing.Point(354, 36);
            this.ChartSent.Name = "ChartSent";
            this.ChartSent.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Grayscale;
            series1.ChartArea = "ChartArea1";
            series1.CustomProperties = "DrawingStyle=Cylinder, MaxPixelPointWidth=30, DrawSideBySide=False";
            series1.EmptyPointStyle.Color = System.Drawing.Color.Lime;
            series1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold);
            series1.IsValueShownAsLabel = true;
            series1.IsVisibleInLegend = false;
            series1.IsXValueIndexed = true;
            series1.Legend = "Legend1";
            series1.MarkerSize = 8;
            series1.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series1.Name = "Sent Documents";
            series1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.BrightPastel;
            series1.SmartLabelStyle.CalloutLineAnchorCapStyle = System.Windows.Forms.DataVisualization.Charting.LineAnchorCapStyle.None;
            series1.SmartLabelStyle.CalloutLineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            series1.XValueMember = "0";
            this.ChartSent.Series.Add(series1);
            this.ChartSent.Size = new System.Drawing.Size(338, 167);
            this.ChartSent.SuppressExceptions = true;
            this.ChartSent.TabIndex = 2;
            this.ChartSent.Text = "chart1";
            this.ChartSent.TextAntiAliasingQuality = System.Windows.Forms.DataVisualization.Charting.TextAntiAliasingQuality.SystemDefault;
            title1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            title1.Name = "Title1";
            title1.Text = "Sent Document Status";
            this.ChartSent.Titles.Add(title1);
            this.ChartSent.GetToolTipText += new System.EventHandler<System.Windows.Forms.DataVisualization.Charting.ToolTipEventArgs>(this.chart1_GetToolTipText);
            this.ChartSent.Click += new System.EventHandler(this.chart1_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(132, 2);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(216, 23);
            this.comboBox1.TabIndex = 3;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // ChartProjects
            // 
            this.ChartProjects.BorderlineColor = System.Drawing.Color.Blue;
            this.ChartProjects.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash;
            chartArea2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            chartArea2.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.Center;
            chartArea2.Name = "ChartArea1";
            this.ChartProjects.ChartAreas.Add(chartArea2);
            legend2.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top;
            legend2.Name = "Legend1";
            this.ChartProjects.Legends.Add(legend2);
            this.ChartProjects.Location = new System.Drawing.Point(12, 40);
            this.ChartProjects.Name = "ChartProjects";
            this.ChartProjects.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Grayscale;
            series2.ChartArea = "ChartArea1";
            series2.CustomProperties = "DrawingStyle=Cylinder, MaxPixelPointWidth=30";
            series2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold);
            series2.IsValueShownAsLabel = true;
            series2.IsVisibleInLegend = false;
            series2.IsXValueIndexed = true;
            series2.Legend = "Legend1";
            series2.MarkerBorderWidth = 3;
            series2.MarkerSize = 10;
            series2.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series2.Name = "Tender Status";
            series2.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Grayscale;
            series2.XValueMember = "0";
            this.ChartProjects.Series.Add(series2);
            this.ChartProjects.Size = new System.Drawing.Size(680, 207);
            this.ChartProjects.TabIndex = 4;
            this.ChartProjects.Text = "Tender Status";
            title2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            title2.Name = "Title1";
            title2.Text = "Total Projects Per Tender Status";
            this.ChartProjects.Titles.Add(title2);
            // 
            // ChartReceived
            // 
            this.ChartReceived.BorderlineColor = System.Drawing.Color.Blue;
            this.ChartReceived.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash;
            chartArea3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            chartArea3.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.Center;
            chartArea3.Name = "ChartArea1";
            this.ChartReceived.ChartAreas.Add(chartArea3);
            legend3.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top;
            legend3.Name = "Legend1";
            this.ChartReceived.Legends.Add(legend3);
            this.ChartReceived.Location = new System.Drawing.Point(12, 36);
            this.ChartReceived.Name = "ChartReceived";
            this.ChartReceived.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Grayscale;
            series3.ChartArea = "ChartArea1";
            series3.CustomProperties = "DrawingStyle=Cylinder, MaxPixelPointWidth=30";
            series3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold);
            series3.IsValueShownAsLabel = true;
            series3.IsVisibleInLegend = false;
            series3.Legend = "Legend1";
            series3.MarkerSize = 8;
            series3.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series3.Name = "Received Documents";
            series3.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.BrightPastel;
            this.ChartReceived.Series.Add(series3);
            this.ChartReceived.Size = new System.Drawing.Size(336, 167);
            this.ChartReceived.TabIndex = 5;
            this.ChartReceived.Text = "chart3";
            title3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            title3.Name = "Title1";
            title3.Text = "Received Document Status";
            this.ChartReceived.Titles.Add(title3);
            // 
            // cmbCommitteNames
            // 
            this.cmbCommitteNames.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCommitteNames.FormattingEnabled = true;
            this.cmbCommitteNames.Location = new System.Drawing.Point(132, 3);
            this.cmbCommitteNames.Name = "cmbCommitteNames";
            this.cmbCommitteNames.Size = new System.Drawing.Size(216, 23);
            this.cmbCommitteNames.TabIndex = 7;
            this.cmbCommitteNames.SelectedIndexChanged += new System.EventHandler(this.cmbCommitteNames_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(9, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 15);
            this.label1.TabIndex = 8;
            this.label1.Text = "Tender Types";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Maroon;
            this.label2.Location = new System.Drawing.Point(9, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 15);
            this.label2.TabIndex = 9;
            this.label2.Text = "Committe Names";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Location = new System.Drawing.Point(8, 12);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(236)))), ((int)(((byte)(236)))));
            this.splitContainer1.Panel1.Controls.Add(this.btnTndrTypes);
            this.splitContainer1.Panel1.Controls.Add(this.ChartSent);
            this.splitContainer1.Panel1.Controls.Add(this.comboBox1);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            this.splitContainer1.Panel1.Controls.Add(this.ChartReceived);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(236)))), ((int)(((byte)(236)))));
            this.splitContainer1.Panel2.Controls.Add(this.btnCommitte);
            this.splitContainer1.Panel2.Controls.Add(this.cmbCommitteNames);
            this.splitContainer1.Panel2.Controls.Add(this.label2);
            this.splitContainer1.Panel2.Controls.Add(this.ChartProjects);
            this.splitContainer1.Size = new System.Drawing.Size(703, 481);
            this.splitContainer1.SplitterDistance = 218;
            this.splitContainer1.TabIndex = 10;
            // 
            // btnTndrTypes
            // 
            this.btnTndrTypes.BackgroundImage = global::MDI_ParenrForm.Properties.Resources.Refresh;
            this.btnTndrTypes.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnTndrTypes.Location = new System.Drawing.Point(353, 2);
            this.btnTndrTypes.Name = "btnTndrTypes";
            this.btnTndrTypes.Size = new System.Drawing.Size(26, 23);
            this.btnTndrTypes.TabIndex = 9;
            this.btnTndrTypes.UseVisualStyleBackColor = true;
            this.btnTndrTypes.Click += new System.EventHandler(this.btnTndrTypes_Click);
            // 
            // btnCommitte
            // 
            this.btnCommitte.BackgroundImage = global::MDI_ParenrForm.Properties.Resources.Refresh;
            this.btnCommitte.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnCommitte.Location = new System.Drawing.Point(353, 3);
            this.btnCommitte.Name = "btnCommitte";
            this.btnCommitte.Size = new System.Drawing.Size(26, 23);
            this.btnCommitte.TabIndex = 10;
            this.btnCommitte.UseVisualStyleBackColor = true;
            this.btnCommitte.Click += new System.EventHandler(this.btnCommitte_Click);
            // 
            // button2
            // 
            this.button2.BackgroundImage = global::MDI_ParenrForm.Properties.Resources.Close_Images;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button2.Location = new System.Drawing.Point(950, 9);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(28, 24);
            this.button2.TabIndex = 6;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // splitContainer2
            // 
            this.splitContainer2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer2.Location = new System.Drawing.Point(718, 48);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(236)))), ((int)(((byte)(236)))));
            this.splitContainer2.Panel1.Controls.Add(this.label3);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.button6);
            this.splitContainer2.Panel2.Controls.Add(this.button5);
            this.splitContainer2.Panel2.Controls.Add(this.button4);
            this.splitContainer2.Panel2.Controls.Add(this.button3);
            this.splitContainer2.Panel2.Controls.Add(this.button1);
            this.splitContainer2.Panel2.Controls.Add(this.button7);
            this.splitContainer2.Panel2.Controls.Add(this.lnkOngoingProjects);
            this.splitContainer2.Panel2.Controls.Add(this.lnkInactive);
            this.splitContainer2.Panel2.Controls.Add(this.lnkViewProjects);
            this.splitContainer2.Panel2.Controls.Add(this.lnkContacts);
            this.splitContainer2.Panel2.Controls.Add(this.lnkCompany);
            this.splitContainer2.Panel2.Controls.Add(this.lnkAddProject);
            this.splitContainer2.Panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer2_Panel2_Paint);
            this.splitContainer2.Size = new System.Drawing.Size(260, 433);
            this.splitContainer2.SplitterDistance = 39;
            this.splitContainer2.TabIndex = 14;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Maroon;
            this.label3.Location = new System.Drawing.Point(13, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(151, 20);
            this.label3.TabIndex = 0;
            this.label3.Text = "Main Switchboard";
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Maroon;
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button6.ForeColor = System.Drawing.Color.Maroon;
            this.button6.Location = new System.Drawing.Point(4, 231);
            this.button6.Margin = new System.Windows.Forms.Padding(0);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(24, 24);
            this.button6.TabIndex = 24;
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Maroon;
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button5.ForeColor = System.Drawing.Color.Maroon;
            this.button5.Location = new System.Drawing.Point(4, 190);
            this.button5.Margin = new System.Windows.Forms.Padding(0);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(24, 24);
            this.button5.TabIndex = 23;
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Maroon;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button4.ForeColor = System.Drawing.Color.Maroon;
            this.button4.Location = new System.Drawing.Point(4, 149);
            this.button4.Margin = new System.Windows.Forms.Padding(0);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(24, 24);
            this.button4.TabIndex = 22;
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Maroon;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button3.ForeColor = System.Drawing.Color.Maroon;
            this.button3.Location = new System.Drawing.Point(4, 109);
            this.button3.Margin = new System.Windows.Forms.Padding(0);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(24, 24);
            this.button3.TabIndex = 21;
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Maroon;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button1.ForeColor = System.Drawing.Color.Maroon;
            this.button1.Location = new System.Drawing.Point(4, 67);
            this.button1.Margin = new System.Windows.Forms.Padding(0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(24, 24);
            this.button1.TabIndex = 20;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Maroon;
            this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button7.ForeColor = System.Drawing.Color.Maroon;
            this.button7.Location = new System.Drawing.Point(4, 26);
            this.button7.Margin = new System.Windows.Forms.Padding(0);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(24, 24);
            this.button7.TabIndex = 19;
            this.button7.UseVisualStyleBackColor = false;
            // 
            // lnkOngoingProjects
            // 
            this.lnkOngoingProjects.ActiveLinkColor = System.Drawing.Color.DarkSlateBlue;
            this.lnkOngoingProjects.AutoSize = true;
            this.lnkOngoingProjects.BackColor = System.Drawing.Color.White;
            this.lnkOngoingProjects.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(46)))), ((int)(((byte)(52)))));
            this.lnkOngoingProjects.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkOngoingProjects.ForeColor = System.Drawing.Color.DarkGray;
            this.lnkOngoingProjects.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkOngoingProjects.LinkColor = System.Drawing.Color.Blue;
            this.lnkOngoingProjects.Location = new System.Drawing.Point(31, 189);
            this.lnkOngoingProjects.Name = "lnkOngoingProjects";
            this.lnkOngoingProjects.Size = new System.Drawing.Size(229, 24);
            this.lnkOngoingProjects.TabIndex = 12;
            this.lnkOngoingProjects.TabStop = true;
            this.lnkOngoingProjects.Text = "View All Ongoing Projects";
            this.lnkOngoingProjects.MouseLeave += new System.EventHandler(this.lnkOngoingProjects_MouseLeave);
            this.lnkOngoingProjects.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel8_LinkClicked);
            this.lnkOngoingProjects.MouseHover += new System.EventHandler(this.lnkOngoingProjects_MouseHover);
            // 
            // lnkInactive
            // 
            this.lnkInactive.ActiveLinkColor = System.Drawing.Color.DarkSlateBlue;
            this.lnkInactive.AutoSize = true;
            this.lnkInactive.BackColor = System.Drawing.Color.White;
            this.lnkInactive.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(46)))), ((int)(((byte)(52)))));
            this.lnkInactive.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkInactive.ForeColor = System.Drawing.Color.DarkGray;
            this.lnkInactive.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkInactive.LinkColor = System.Drawing.Color.Blue;
            this.lnkInactive.Location = new System.Drawing.Point(31, 230);
            this.lnkInactive.Name = "lnkInactive";
            this.lnkInactive.Size = new System.Drawing.Size(228, 24);
            this.lnkInactive.TabIndex = 11;
            this.lnkInactive.TabStop = true;
            this.lnkInactive.Text = "View All Inactive Projects  ";
            this.lnkInactive.MouseLeave += new System.EventHandler(this.lnkInactive_MouseLeave);
            this.lnkInactive.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel9_LinkClicked);
            this.lnkInactive.MouseHover += new System.EventHandler(this.lnkInactive_MouseHover);
            // 
            // lnkViewProjects
            // 
            this.lnkViewProjects.ActiveLinkColor = System.Drawing.Color.DarkSlateBlue;
            this.lnkViewProjects.AutoSize = true;
            this.lnkViewProjects.BackColor = System.Drawing.Color.White;
            this.lnkViewProjects.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(46)))), ((int)(((byte)(52)))));
            this.lnkViewProjects.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkViewProjects.ForeColor = System.Drawing.Color.DarkGray;
            this.lnkViewProjects.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkViewProjects.LinkColor = System.Drawing.Color.Blue;
            this.lnkViewProjects.Location = new System.Drawing.Point(31, 148);
            this.lnkViewProjects.Name = "lnkViewProjects";
            this.lnkViewProjects.Size = new System.Drawing.Size(225, 24);
            this.lnkViewProjects.TabIndex = 10;
            this.lnkViewProjects.TabStop = true;
            this.lnkViewProjects.Text = "View All Projects               ";
            this.lnkViewProjects.MouseLeave += new System.EventHandler(this.lnkViewProjects_MouseLeave);
            this.lnkViewProjects.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel10_LinkClicked);
            this.lnkViewProjects.MouseHover += new System.EventHandler(this.lnkViewProjects_MouseHover);
            // 
            // lnkContacts
            // 
            this.lnkContacts.ActiveLinkColor = System.Drawing.Color.DarkSlateBlue;
            this.lnkContacts.AutoSize = true;
            this.lnkContacts.BackColor = System.Drawing.Color.White;
            this.lnkContacts.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(46)))), ((int)(((byte)(52)))));
            this.lnkContacts.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkContacts.ForeColor = System.Drawing.Color.DarkGray;
            this.lnkContacts.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkContacts.LinkColor = System.Drawing.Color.Blue;
            this.lnkContacts.Location = new System.Drawing.Point(31, 107);
            this.lnkContacts.Name = "lnkContacts";
            this.lnkContacts.Size = new System.Drawing.Size(227, 24);
            this.lnkContacts.TabIndex = 9;
            this.lnkContacts.TabStop = true;
            this.lnkContacts.Text = "Add New Contact              ";
            this.lnkContacts.MouseLeave += new System.EventHandler(this.lnkContacts_MouseLeave);
            this.lnkContacts.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel11_LinkClicked);
            this.lnkContacts.MouseHover += new System.EventHandler(this.lnkContacts_MouseHover);
            // 
            // lnkCompany
            // 
            this.lnkCompany.ActiveLinkColor = System.Drawing.Color.DarkSlateBlue;
            this.lnkCompany.AutoSize = true;
            this.lnkCompany.BackColor = System.Drawing.Color.White;
            this.lnkCompany.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(46)))), ((int)(((byte)(52)))));
            this.lnkCompany.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkCompany.ForeColor = System.Drawing.Color.DarkGray;
            this.lnkCompany.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkCompany.LinkColor = System.Drawing.Color.Blue;
            this.lnkCompany.Location = new System.Drawing.Point(31, 66);
            this.lnkCompany.Name = "lnkCompany";
            this.lnkCompany.Size = new System.Drawing.Size(225, 24);
            this.lnkCompany.TabIndex = 8;
            this.lnkCompany.TabStop = true;
            this.lnkCompany.Text = "Add New Company          ";
            this.lnkCompany.MouseLeave += new System.EventHandler(this.linkLabel12_MouseLeave);
            this.lnkCompany.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel12_LinkClicked);
            this.lnkCompany.MouseHover += new System.EventHandler(this.linkLabel12_MouseHover);
            // 
            // lnkAddProject
            // 
            this.lnkAddProject.ActiveLinkColor = System.Drawing.Color.DarkSlateBlue;
            this.lnkAddProject.AutoSize = true;
            this.lnkAddProject.BackColor = System.Drawing.Color.White;
            this.lnkAddProject.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(46)))), ((int)(((byte)(52)))));
            this.lnkAddProject.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkAddProject.ForeColor = System.Drawing.Color.DarkGray;
            this.lnkAddProject.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lnkAddProject.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkAddProject.LinkColor = System.Drawing.Color.Blue;
            this.lnkAddProject.Location = new System.Drawing.Point(31, 25);
            this.lnkAddProject.Name = "lnkAddProject";
            this.lnkAddProject.Size = new System.Drawing.Size(227, 24);
            this.lnkAddProject.TabIndex = 7;
            this.lnkAddProject.TabStop = true;
            this.lnkAddProject.Text = "Add New Project               ";
            this.lnkAddProject.VisitedLinkColor = System.Drawing.Color.Yellow;
            this.lnkAddProject.MouseLeave += new System.EventHandler(this.linkLabel13_MouseLeave);
            this.lnkAddProject.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel13_LinkClicked);
            this.lnkAddProject.MouseHover += new System.EventHandler(this.linkLabel13_MouseHover);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label4.Location = new System.Drawing.Point(917, 14);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "Close";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(236)))), ((int)(((byte)(236)))));
            this.ClientSize = new System.Drawing.Size(992, 493);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.splitContainer2);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.button2);
            this.ForeColor = System.Drawing.Color.Cyan;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ChartSent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ChartProjects)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ChartReceived)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            this.splitContainer2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart ChartSent;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.DataVisualization.Charting.Chart ChartProjects;
        private System.Windows.Forms.DataVisualization.Charting.Chart ChartReceived;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox cmbCommitteNames;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button btnTndrTypes;
        private System.Windows.Forms.Button btnCommitte;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.LinkLabel lnkOngoingProjects;
        private System.Windows.Forms.LinkLabel lnkInactive;
        private System.Windows.Forms.LinkLabel lnkViewProjects;
        private System.Windows.Forms.LinkLabel lnkContacts;
        private System.Windows.Forms.LinkLabel lnkCompany;
        private System.Windows.Forms.LinkLabel lnkAddProject;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button7;
    }
}

