﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using Microsoft.Office.Interop;

namespace MDI_ParenrForm.Dashboard
{
    public partial class frmTenderIssued : Form
    {
        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();

        public frmTenderIssued()
        {
            InitializeComponent();
        }

        private void frmTenderIssued_Load(object sender, EventArgs e)
        {
            IssuedTenderList();
        }

        private void IssuedTenderList()
        {
            SqlConnection cn = new SqlConnection(strCon);
            DataSet dsTndr = new DataSet();

           //string sqlQuery = "SELECT COUNT(ptd_assign_qs) AS QsCnt, COUNT(ts_issue_handling) AS HandCnt, COUNT(Staff_In_Charge) AS StaffCnt, ptd_assign_qs, ts_issue_handling, " +
           //  " Staff_In_Charge,proj_ID FROM TenderDatesInfo WHERE (date_id IN (SELECT TOP (100) PERCENT MAX(date_id) AS Expr1 FROM TenderDatesInfo AS TenderDatesInfo_1 " +
           //  " GROUP BY proj_id)) AND (ts_issue_handling LIKE N'%Nadya%' OR ts_issue_handling LIKE '%Nawal%') GROUP BY ptd_assign_qs, ts_issue_handling, Staff_In_Charge,proj_ID";
            
            //string sqlQuery = "SELECT COUNT(TenderDatesInfo.ptd_assign_qs) AS QsCnt, COUNT(TenderDatesInfo.ts_issue_handling) AS HandCnt, COUNT(TenderDatesInfo.Staff_In_Charge) AS StaffCnt, " +
            //           "  TenderDatesInfo.ptd_assign_qs, TenderDatesInfo.ts_issue_handling, TenderDatesInfo.Staff_In_Charge, PROJECTS.project_code, PROJECTS.tender_no,  " +
            //          " PROJECTS.FYID FROM  TenderDatesInfo INNER JOIN PROJECTS ON TenderDatesInfo.proj_id = PROJECTS.proj_id WHERE (TenderDatesInfo.ts_issue_handling LIKE N'%Nadya%') OR " +
            //           " (TenderDatesInfo.ts_issue_handling LIKE '%Nawal%') GROUP BY TenderDatesInfo.ptd_assign_qs, TenderDatesInfo.ts_issue_handling, TenderDatesInfo.Staff_In_Charge, PROJECTS.project_code, PROJECTS.tender_no, PROJECTS.FYID";

            string sqlQuery = "SELECT TenderDatesInfo.ts_issue_handling as [Name of Issue Handler], PROJECTS.project_code as [Project Code]," +
               "FiscalYear.FiscalYear as [Fiscal Year] FROM  TenderDatesInfo INNER JOIN PROJECTS ON TenderDatesInfo.proj_id = PROJECTS.proj_id INNER JOIN FiscalYear ON PROJECTS.FYID = FiscalYear.FYID WHERE (TenderDatesInfo.date_id IN (SELECT TOP (100) PERCENT MAX(date_id) AS Expr1 " +
                 " FROM TenderDatesInfo AS TenderDatesInfo_1 GROUP BY proj_id)) AND (TenderDatesInfo.ts_issue_handling LIKE N'%Nadya%' OR TenderDatesInfo.ts_issue_handling LIKE '%Nawal%' OR TenderDatesInfo.ts_issue_handling LIKE '%Fahad%') AND (TenderDatesInfo.ts_tender_invitation IS NULL) " +
                      " GROUP BY TenderDatesInfo.ts_issue_handling, PROJECTS.project_code, PROJECTS.tender_no, FiscalYear.FiscalYear";

            //string sqlQuery = "SELECT COUNT(TenderDatesInfo.ptd_assign_qs) AS QsCnt, COUNT(TenderDatesInfo.ts_issue_handling) AS HandCnt, COUNT(TenderDatesInfo.Staff_In_Charge) AS StaffCnt, " +
            //" TenderDatesInfo.ptd_assign_qs, TenderDatesInfo.ts_issue_handling, TenderDatesInfo.Staff_In_Charge, PROJECTS.project_code, PROJECTS.tender_no, " +
            //" PROJECTS.FYID FROM TenderDatesInfo INNER JOIN PROJECTS ON TenderDatesInfo.proj_id = PROJECTS.proj_id WHERE (TenderDatesInfo.date_id IN (SELECT TOP (100) PERCENT MAX(date_id) AS Expr1 " +
            //" FROM TenderDatesInfo AS TenderDatesInfo_1 GROUP BY proj_id)) AND (TenderDatesInfo.ts_issue_handling LIKE N'%Nadya%' OR TenderDatesInfo.ts_issue_handling LIKE '%Nawal%') GROUP BY TenderDatesInfo.ptd_assign_qs, " +
            //" TenderDatesInfo.ts_issue_handling, TenderDatesInfo.Staff_In_Charge, PROJECTS.project_code, PROJECTS.tender_no, PROJECTS.FYID";
            
           SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, cn);
           daTndr.Fill(dsTndr);
           dgvIssuedTenders.DataSource = dsTndr.Tables[0].DefaultView;

           //dgvIssuedTenders.Columns[0].Width = 30;
           //dgvIssuedTenders.Columns[1].Width = 40;
           //dgvIssuedTenders.Columns[2].Width = 20;
            
            
           //dgvIssuedTenders.Columns[2].DefaultCellStyle.ForeColor = Color.Green;
           dgvIssuedTenders.Columns[1].DefaultCellStyle.ForeColor = Color.Blue;

           //dgvIssuedTenders.Columns[2].Width = 157;
           //dgvIssuedTenders.Columns[3].Width = 150;
        }


        private void btnExpoprt_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog saveFileDialog1 = new SaveFileDialog();
                Microsoft.Office.Interop.Excel.Application xlApp;
                Microsoft.Office.Interop.Excel.Workbook xlWorkBook;
                Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet;
                object misValue = System.Reflection.Missing.Value;

                saveFileDialog1.Filter = "Excel Path|*.xls|Excel Path|*.xlsx";
                saveFileDialog1.Title = "Save an Excel File";
                saveFileDialog1.ShowDialog();

                if (saveFileDialog1.FileName != "")
                {
                    xlApp = new Microsoft.Office.Interop.Excel.ApplicationClass();
                    xlWorkBook = xlApp.Workbooks.Add(misValue);
                    xlApp.Visible = true;
                    xlWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkBook.Sheets["Sheet1"];
                    xlWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkBook.ActiveSheet;

                    Microsoft.Office.Interop.Excel.Range formatRange = xlWorkSheet.UsedRange;
                    Microsoft.Office.Interop.Excel.Range formatA1CellRange = null;
                    Microsoft.Office.Interop.Excel.Range formatA1Cell = null;

                    formatA1CellRange = xlWorkSheet.get_Range("A1", "C1");
                    formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[1, 3];
                    formatA1CellRange.ColumnWidth = 80;
                    formatA1CellRange.Merge(true);
                    formatA1CellRange.FormulaR1C1 = "LIST OF PROJECTS WHERE TENDER IS NOT INVITED";

                    formatA1CellRange.HorizontalAlignment = 3;
                    formatA1CellRange.VerticalAlignment = 3;
                    formatA1CellRange.Font.Name = "Calibri";
                    formatA1CellRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(Color.FromArgb(196, 215, 155));
                    formatA1CellRange.Font.Size = 18;

                    System.Drawing.Color color = Color.FromArgb(255, 204, 0);
                    int i = 0, j = 0;
                    // storing header part in Excel
                    for (i = 0; i < dgvIssuedTenders.ColumnCount; i++)
                    {
                        xlWorkSheet.Cells[3, i + 1] = dgvIssuedTenders.Columns[i].HeaderText;
                        formatA1Cell = (Microsoft.Office.Interop.Excel.Range)formatRange.Cells[3, i + 1];
                        formatA1Cell.Font.Name = "Calibri";
                        formatA1Cell.Font.Size = "12";
                        formatA1Cell.Font.Bold = true;
                        formatA1Cell.WrapText = true;
                        formatA1Cell.ColumnWidth = 50;
                        formatA1Cell.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        formatA1Cell.Interior.Color = System.Drawing.ColorTranslator.ToOle(color);
                    }
                    for (i = 0; i < dgvIssuedTenders.RowCount; i++)
                    {
                        for (j = 0; j < dgvIssuedTenders.ColumnCount; j++)
                        {
                            if (dgvIssuedTenders[j, i].Value != null)
                            {
                                xlWorkSheet.Cells[4 + i, j + 1] = dgvIssuedTenders[j, i].Value.ToString();
                            }
                        }
                    }
                    // save the application
                    xlWorkBook.SaveAs(saveFileDialog1.FileName, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while creating the excel file", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);                                    
            }            
        }
        
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
    }
}
