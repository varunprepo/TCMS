﻿public partial class TenderDataSet {
}
