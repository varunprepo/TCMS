﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms.DataVisualization.Charting;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        IList<string> userRightsColl = new List<string>();
        string _userName = string.Empty;
        public Form1(IList<string> userRightsCollDashboard,string user)
        {
            InitializeComponent();
            userRightsColl = userRightsCollDashboard;
            _userName = user;
        }
        SqlConnection cn = new SqlConnection();
        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();
        Boolean cmbChk  = false;
        Boolean cmbCommitteeChk = false;
        private void Form1_Load(object sender, EventArgs e)
        {            
            cn.ConnectionString = strCon;
            cn.Open();
            SqlDataAdapter da = new SqlDataAdapter("SELECT stage_id,Stages FROM [STAGE]", cn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cn.Close();
            comboBox1.Items.Clear();

            comboBox1.Items.Add("Select");
            comboBox1.DataSource = ds.Tables [0];

            comboBox1.DisplayMember = "Stages";
            comboBox1.ValueMember = "stage_id";

            cmbChk = true; comboBox1.SelectedIndex = -1;   
            ds.Tables.Clear();

            cn.ConnectionString = strCon;
            cn.Open();
            SqlDataAdapter daCmt = new SqlDataAdapter("SELECT committee_id,committee_name FROM [committee]", cn);
            DataSet dsCmt = new DataSet();
            daCmt.Fill(dsCmt);
            cn.Close();
            cmbCommitteNames.Items.Clear();

            cmbCommitteNames.Items.Add("Select");
            cmbCommitteNames.DataSource = dsCmt.Tables[0];
            cmbCommitteNames.DisplayMember = "committee_name";
            cmbCommitteNames.ValueMember = "committee_id";
            cmbCommitteeChk = true; cmbCommitteNames.SelectedIndex = -1;
            ds.Tables.Clear();

            try
            {
                //string strQuery = "SELECT [Document Status].doc_status_name, COUNT([DOCUMENTS].doc_status_id) AS DocCnt FROM [DOCUMENTS] INNER JOIN [Document Status] ON [DOCUMENTS].doc_status_id = [Document Status].doc_status_id INNER JOIN [Document Category] ON [DOCUMENTS].doc_category_id = [Document Category].doc_category_id GROUP BY [Document Status].doc_status_name, [Document Category].doc_category_name HAVING ([Document Category].doc_category_name = 'Sent') AND ([Document Status].doc_status_name <> N'Closed')";

                string strQuery = "SELECT COUNT(DOCUMENTS.doc_status_id) AS DocCnt, DOCUMENTS.doc_category_id, DOCUMENTS.doc_status_id,[Document Status].doc_status_name FROM DOCUMENTS INNER JOIN [Document Status] ON DOCUMENTS.doc_status_id = [Document Status].doc_status_id GROUP BY DOCUMENTS.doc_category_id, DOCUMENTS.doc_status_id, [Document Status].doc_status_name HAVING (DOCUMENTS.doc_category_id = 1) AND (DOCUMENTS.doc_status_id <> 4)";

                SqlDataAdapter da1 = new SqlDataAdapter(strQuery, cn);
                da1.Fill(ds);
                cn.Close();
                ChartSent.DataSource = ds.Tables[0].DefaultView;
                ChartSent.Series["Sent Documents"].XValueMember = "doc_status_name";
                ChartSent.Series["Sent Documents"].YValueMembers = "DocCnt";
                ds.Tables.Clear();

                ChartSent.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
                ChartSent.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
                ChartSent.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
                ChartSent.ChartAreas[0].AxisY.MinorGrid.Enabled = false;
            }
            catch (Exception ex)
            {                
                throw ex;
            }

            string strQuery2 = "SELECT COUNT(PROJECTS.proj_id) AS PrjCnt, [Status of Tender].[Tender Status] AS Status, [Status of Tender].Tender_Status_id " +
            " FROM PROJECTS INNER JOIN [Status of Tender] ON PROJECTS.Tender_Status_id = [Status of Tender].Tender_Status_id GROUP BY [Status of Tender].[Tender Status], [Status of Tender].Tender_Status_id " +   //Tender_Status_id
            " HAVING ([Status of Tender].[Tender_Status_id] <> 7) AND ([Status of Tender].[Tender_Status_id] <> 8) and ([Status of Tender].[Tender_Status_id] <> 9) and ([Status of Tender].[Tender_Status_id] <> 10) and ([Status of Tender].[Tender_Status_id] <> 11) ORDER BY [Status of Tender].Tender_Status_id ASC ";
            SqlDataAdapter da2 = new SqlDataAdapter(strQuery2, cn);
            da2.Fill(ds);
            cn.Close();
            ChartProjects.DataSource = ds.Tables[0].DefaultView;
            ChartProjects.Series["Tender Status"].XValueMember = "Status";
            ChartProjects.Series["Tender Status"].YValueMembers = "PrjCnt";
            ds.Tables.Clear();

            ChartProjects.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            ChartProjects.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            ChartProjects.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            ChartProjects.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

          // string strQuery3 = "SELECT [Document Status].doc_status_name,COUNT([DOCUMENTS].doc_status_id) AS DocCnt FROM [DOCUMENTS] INNER JOIN [Document Status] ON [DOCUMENTS].doc_status_id = [Document Status].doc_status_id INNER JOIN [Document Category] ON [DOCUMENTS].doc_category_id = [Document Category].doc_category_id GROUP BY [Document Status].doc_status_name, [Document Category].doc_category_name HAVING ([Document Category].doc_category_name = 'Received') AND ([Document Status].doc_status_name <> N'Closed')";

            string strQuery3 = "SELECT COUNT(DOCUMENTS.doc_status_id) AS DocCnt, DOCUMENTS.doc_category_id, DOCUMENTS.doc_status_id,[Document Status].doc_status_name FROM DOCUMENTS INNER JOIN [Document Status] ON DOCUMENTS.doc_status_id = [Document Status].doc_status_id GROUP BY DOCUMENTS.doc_category_id, DOCUMENTS.doc_status_id, [Document Status].doc_status_name HAVING (DOCUMENTS.doc_category_id = 2) AND (DOCUMENTS.doc_status_id <> 4)";
            SqlDataAdapter da3 = new SqlDataAdapter(strQuery3, cn);
            da3.Fill(ds);
            cn.Close();
            ChartReceived.DataSource = ds.Tables[0].DefaultView;
            ChartReceived.Series["Received Documents"].XValueMember = "doc_status_name";
            ChartReceived.Series["Received Documents"].YValueMembers = "DocCnt";
            ds.Tables.Clear();

            ChartReceived.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            ChartReceived.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            ChartReceived.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            ChartReceived.ChartAreas[0].AxisY.MinorGrid.Enabled = false;
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {
            string con = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\\Tender.accdb;Jet OLEDB:Database Password=yourpassword;";
            //string appPath = "file:///" + Application.StartupPath + "\\Pie3D.swf";

            //Replace all "\" in the .swf path with "/"

            //appPath = appPath.Replace("\", "/");

            //Similarly, set the path of the remote XML file as the startup path

            //because that is where the file is located

            //string XMLpath = Application.StartupPath + "\\XMLFile1.xml";

            //Replace all "\" in the XML path with "/"

            //XMLpath = XMLpath.Replace("\", "/");

            //finally generate the chartXML string which is in the form

            //file:///XMLpath?=dataXML=<remote Xml path >&registerwithjs=1

            //This is the string which will be passed to the ShockWave Object

            //to load the chart.

            //string ChartXml = appPath + @"?dataURL=" + XMLpath + "&registerwithjs=1";

            //passing the string ChartXml to the shockwave flash player.

            //ChartContainer.Movie = ChartXml;
        }
        private void chart1_Click(object sender, EventArgs e)
        {

        }
        private void chart2_Click(object sender, EventArgs e)
        {

        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex >= 0 & cmbChk == true)
            {
                cn.ConnectionString = strCon;
                cn.Open();

                string strQuery = "SELECT [Document Status].doc_status_name, COUNT(DOCUMENTS.doc_status_id) AS DocCnt, STAGE.Stages FROM DOCUMENTS INNER JOIN [Document Status] ON DOCUMENTS.doc_status_id = [Document Status].doc_status_id INNER JOIN " +
                " [Document Category] ON DOCUMENTS.doc_category_id = [Document Category].doc_category_id INNER JOIN STAGE ON DOCUMENTS.stage_id = STAGE.stage_id GROUP BY [Document Status].doc_status_name, [Document Category].doc_category_name, STAGE.Stages HAVING ([Document Category].doc_category_name = 'Sent') AND ([Document Status].doc_status_name <> N'Closed') AND (STAGE.Stages =  '" + comboBox1.Text + "')";
                
                //string strQuery = "SELECT [Document Status].doc_status_name, COUNT([DOCUMENT].doc_status_id) AS DocCnt FROM [DOCUMENT] INNER JOIN [Document Status] ON [DOCUMENT].doc_status_id = [Document Status].doc_status_id Where [Document Status].stage_id = " + comboBox1.SelectedValue + " GROUP BY [Document Status].doc_status_name ";

                SqlDataAdapter da1 = new SqlDataAdapter(strQuery, cn);
                DataSet ds = new DataSet();
                da1.Fill(ds);
                cn.Close();
                ChartSent.DataSource = ds.Tables[0].DefaultView;                
                ChartSent.Series["Sent Documents"].XValueMember = "doc_status_name";
                ChartSent.Series["Sent Documents"].YValueMembers = "DocCnt";
                ChartSent.DataBind();
                ChartSent.Visible = true;


                cn.ConnectionString = strCon;
                cn.Open();

                string strQueryRec = "SELECT [Document Status].doc_status_name, COUNT(DOCUMENTS.doc_status_id) AS DocCnt, STAGE.Stages " +
                " FROM DOCUMENTS INNER JOIN [Document Status] ON DOCUMENTS.doc_status_id = [Document Status].doc_status_id INNER JOIN [Document Category] ON DOCUMENTS.doc_category_id = [Document Category].doc_category_id INNER JOIN " +
                " STAGE ON DOCUMENTS.stage_id = STAGE.stage_id GROUP BY [Document Status].doc_status_name, [Document Category].doc_category_name, STAGE.Stages " +
                " HAVING ([Document Category].doc_category_name = 'Received') AND ([Document Status].doc_status_name <> N'Closed') AND (STAGE.Stages = '" + comboBox1.Text + "')";
                SqlDataAdapter daRec = new SqlDataAdapter(strQueryRec, cn);
                DataSet dsRec = new DataSet();
                daRec.Fill(dsRec);
                cn.Close();
                ChartReceived.DataSource = dsRec.Tables[0].DefaultView;
                ChartReceived.Series["Received Documents"].XValueMember = "doc_status_name";
                ChartReceived.Series["Received Documents"].YValueMembers = "DocCnt";
                ChartReceived.DataBind();
                ChartReceived.Visible = true;


                //cn.ConnectionString = strCon;
                //cn.Open();
                //string strQueryPrj = "SELECT COUNT(PROJECTS.proj_id) AS PrjCnt,[Status of Tender].[Tender Status] as Status FROM PROJECTS INNER JOIN [Status of Tender] ON PROJECTS.Tender_Status_id = [Status of Tender].Tender_Status_id Where [Status of Tender].Tender_Status_id = " + comboBox1.SelectedValue + " GROUP BY [Status of Tender].[Tender Status]";

                //SqlDataAdapter daPrj = new SqlDataAdapter(strQueryPrj, cn);
                //DataSet dsPrj = new DataSet();
                //daPrj.Fill(dsPrj);
                //cn.Close();
                //chart2.DataSource = dsPrj.Tables[0].DefaultView;
                //chart2.Series["Project Status"].XValueMember = "Status";
                //chart2.Series["Project Status"].YValueMembers = "PrjCnt";
                //chart2.DataBind();
                //chart2.Visible = true;
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void cmbCommitteNames_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbCommitteNames.SelectedIndex >= 0 & cmbCommitteeChk == true)
            {
                //cn.ConnectionString = strCon;
                //cn.Open();

                //string strQuery = "SELECT [Document Status].doc_status_name, COUNT([DOCUMENTS].doc_status_id) AS DocCnt FROM [DOCUMENT] INNER JOIN [Document Status] ON [DOCUMENTS].doc_status_id = [Document Status].doc_status_id INNER JOIN [Document Category] ON [DOCUMENTS].doc_category_id = [Document Category].doc_category_id Where [Document Status].stage_id = " + comboBox1.SelectedValue + " GROUP BY [Document Status].doc_status_name, [Document Category].doc_category_name HAVING ([Document Category].doc_category_name = 'Sent') AND ([Document Status].doc_status_name <> N'Closed')";

                ////string strQuery = "SELECT [Document Status].doc_status_name, COUNT([DOCUMENT].doc_status_id) AS DocCnt FROM [DOCUMENT] INNER JOIN [Document Status] ON [DOCUMENT].doc_status_id = [Document Status].doc_status_id Where [Document Status].stage_id = " + comboBox1.SelectedValue + " GROUP BY [Document Status].doc_status_name ";

                //SqlDataAdapter da1 = new SqlDataAdapter(strQuery, cn);
                //DataSet ds = new DataSet();
                //da1.Fill(ds);
                //cn.Close();
                //chart1.DataSource = ds.Tables[0].DefaultView;
                //chart1.Series["Sent Documents"].XValueMember = "doc_status_name";
                //chart1.Series["Sent Documents"].YValueMembers = "DocCnt";
                //chart1.DataBind();
                //chart1.Visible = true;
                
                //cn.ConnectionString = strCon;
                //cn.Open();

                //string strQueryRec = "SELECT [Document Status].doc_status_name, COUNT([DOCUMENTS].doc_status_id) AS DocCnt FROM [DOCUMENTS] INNER JOIN [Document Status] ON [DOCUMENTS].doc_status_id = [Document Status].doc_status_id INNER JOIN [Document Category] ON [DOCUMENTS].doc_category_id = [Document Category].doc_category_id Where [Document Status].stage_id = " + comboBox1.SelectedValue + " GROUP BY [Document Status].doc_status_name, [Document Category].doc_category_name HAVING ([Document Category].doc_category_name = 'Received') AND ([Document Status].doc_status_name <> N'Closed')";
                ////string strQuery = "SELECT [Document Status].doc_status_name, COUNT([DOCUMENT].doc_status_id) AS DocCnt FROM [DOCUMENT] INNER JOIN [Document Status] ON [DOCUMENT].doc_status_id = [Document Status].doc_status_id Where [Document Status].stage_id = " + comboBox1.SelectedValue + " GROUP BY [Document Status].doc_status_name ";

                //SqlDataAdapter daRec = new SqlDataAdapter(strQueryRec, cn);
                //DataSet dsRec = new DataSet();
                //daRec.Fill(dsRec);
                //cn.Close();
                //chart3.DataSource = dsRec.Tables[0].DefaultView;
                //chart3.Series["Received Documents"].XValueMember = "doc_status_name";
                //chart3.Series["Received Documents"].YValueMembers = "DocCnt";
                //chart3.DataBind();
                //chart3.Visible = true;


                cn.ConnectionString = strCon;
                cn.Open();
                string strQueryPrj = "SELECT COUNT(PROJECTS.proj_id) AS PrjCnt, [Status of Tender].[Tender Status] AS Status, [Status of Tender].Tender_Status_id, Committee.committee_id " +
                " FROM PROJECTS INNER JOIN [Status of Tender] ON PROJECTS.Tender_Status_id = [Status of Tender].Tender_Status_id INNER JOIN Committee ON PROJECTS.committee_id = Committee.committee_id " +
                " GROUP BY [Status of Tender].[Tender Status], [Status of Tender].Tender_Status_id, Committee.committee_id HAVING ([Status of Tender].[Tender_Status_id] <> 7) AND ([Status of Tender].[Tender_Status_id] <> 8) and ([Status of Tender].[Tender_Status_id] <> 9) and ([Status of Tender].[Tender_Status_id] <> 10) and ([Status of Tender].[Tender_Status_id] <> 11) AND (Committee.committee_id = " + cmbCommitteNames.SelectedValue + ") ORDER BY [Status of Tender].Tender_Status_id ";

                SqlDataAdapter daPrj = new SqlDataAdapter(strQueryPrj, cn);
                DataSet dsPrj = new DataSet();
                daPrj.Fill(dsPrj);
                cn.Close();
                ChartProjects.DataSource = dsPrj.Tables[0].DefaultView;
                ChartProjects.Series["Tender Status"].XValueMember = "Status";
                ChartProjects.Series["Tender Status"].YValueMembers = "PrjCnt";
                ChartProjects.DataBind();
                ChartProjects.Visible = true;
            }
        }
        private void btnTndrTypes_Click(object sender, EventArgs e)
        {
            cn.ConnectionString = strCon;
            cn.Open();

           // string strQuery = "SELECT [Document Status].doc_status_name, COUNT([DOCUMENTS].doc_status_id) AS DocCnt FROM [DOCUMENTS] INNER JOIN [Document Status] ON [DOCUMENTS].doc_status_id = [Document Status].doc_status_id INNER JOIN [Document Category] ON [DOCUMENTS].doc_category_id = [Document Category].doc_category_id  GROUP BY [Document Status].doc_status_name, [Document Category].doc_category_name HAVING ([Document Category].doc_category_name = 'Sent') AND ([Document Status].doc_status_name <> N'Closed')";

            string strQuery = "SELECT     [Document Status].doc_status_name, COUNT(DOCUMENTS.doc_status_id) AS DocCnt, [Document Category].doc_category_id FROM DOCUMENTS INNER JOIN " +
                      " [Document Status] ON DOCUMENTS.doc_status_id = [Document Status].doc_status_id INNER JOIN [Document Category] ON DOCUMENTS.doc_category_id = [Document Category].doc_category_id " +
                      " GROUP BY [Document Status].doc_status_name, [Document Category].doc_category_id HAVING ([Document Status].doc_status_name <> N'Closed') AND ([Document Category].doc_category_id = 1)";

            SqlDataAdapter da1 = new SqlDataAdapter(strQuery, cn);
            DataSet ds = new DataSet();
            da1.Fill(ds);
            cn.Close();
            ChartSent.DataSource = ds.Tables[0].DefaultView;
            ChartSent.Series["Sent Documents"].XValueMember = "doc_status_name";
            ChartSent.Series["Sent Documents"].YValueMembers = "DocCnt";
            ChartSent.DataBind();
            ChartSent.Visible = true;

            cn.ConnectionString = strCon;
            cn.Open();

            string strQueryRec = "SELECT     [Document Status].doc_status_name, COUNT(DOCUMENTS.doc_status_id) AS DocCnt, [Document Category].doc_category_id FROM DOCUMENTS INNER JOIN " +
                      " [Document Status] ON DOCUMENTS.doc_status_id = [Document Status].doc_status_id INNER JOIN [Document Category] ON DOCUMENTS.doc_category_id = [Document Category].doc_category_id " +
                      " GROUP BY [Document Status].doc_status_name, [Document Category].doc_category_id HAVING ([Document Status].doc_status_name <> N'Closed') AND ([Document Category].doc_category_id = 2)";
            //string strQuery = "SELECT [Document Status].doc_status_name, COUNT([DOCUMENT].doc_status_id) AS DocCnt FROM [DOCUMENT] INNER JOIN [Document Status] ON [DOCUMENT].doc_status_id = [Document Status].doc_status_id Where [Document Status].stage_id = " + comboBox1.SelectedValue + " GROUP BY [Document Status].doc_status_name ";

            SqlDataAdapter daRec = new SqlDataAdapter(strQueryRec, cn);
            DataSet dsRec = new DataSet();
            daRec.Fill(dsRec);
            cn.Close();
            ChartReceived.DataSource = dsRec.Tables[0].DefaultView;
            ChartReceived.Series["Received Documents"].XValueMember = "doc_status_name";
            ChartReceived.Series["Received Documents"].YValueMembers = "DocCnt";
            ChartReceived.DataBind();
            ChartReceived.Visible = true;
        

        comboBox1.SelectedIndex = -1;
        }

        private void btnCommitte_Click(object sender, EventArgs e)
        {
            cn.ConnectionString = strCon;
            cn.Open();

            string strQueryPrj = "SELECT COUNT(PROJECTS.proj_id) AS PrjCnt, [Status of Tender].[Tender Status] AS Status, [Status of Tender].Tender_Status_id " +
            " FROM PROJECTS INNER JOIN [Status of Tender] ON PROJECTS.Tender_Status_id = [Status of Tender].Tender_Status_id GROUP BY [Status of Tender].[Tender Status], [Status of Tender].Tender_Status_id " +
            " HAVING ([Status of Tender].[Tender_Status_id] <> 7) AND ([Status of Tender].[Tender_Status_id] <> 8) and ([Status of Tender].[Tender_Status_id] <> 9) and ([Status of Tender].[Tender_Status_id] <> 10) and ([Status of Tender].[Tender_Status_id] <> 11) " +
            " ORDER BY [Status of Tender].Tender_Status_id";

            SqlDataAdapter daPrj = new SqlDataAdapter(strQueryPrj, cn);
            DataSet dsPrj = new DataSet();
            daPrj.Fill(dsPrj);
            cn.Close();
            ChartProjects.DataSource = dsPrj.Tables[0].DefaultView;
            ChartProjects.Series["Tender Status"].XValueMember = "Status";
            ChartProjects.Series["Tender Status"].YValueMembers = "PrjCnt";
            ChartProjects.DataBind();
            ChartProjects.Visible = true;

            cmbCommitteNames.SelectedIndex = -1;
        }

        private void chart1_GetToolTipText(object sender, System.Windows.Forms.DataVisualization.Charting.ToolTipEventArgs e)
        {
            if (e.HitTestResult.ChartElementType == ChartElementType.DataPoint)
            {
                int i = e.HitTestResult.PointIndex;
                DataPoint dp = e.HitTestResult.Series.Points[i];
                e.Text = string.Format("{0:F1}, {1:F1}", dp.XValue, dp.YValues[0]);
            }
        }

        private void lblProject_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel6_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void linkLabel13_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MDI_ParenrForm.Projects.frmProjectInfo frmProj = new MDI_ParenrForm.Projects.frmProjectInfo(userRightsColl, _userName, false);
            frmProj.StartPosition = FormStartPosition.CenterParent;
            frmProj.ShowDialog();
        }
        private void linkLabel12_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            TenderTrackingSystem.Contacts.frmAddCompanyInfo frmCmp = new TenderTrackingSystem.Contacts.frmAddCompanyInfo(userRightsColl, 0, _userName, false);
            frmCmp.StartPosition = FormStartPosition.CenterParent;
            frmCmp.ShowDialog();
        }

        private void linkLabel11_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            TenderTrackingSystem.Contacts.frmContactPerson frmPerson = new TenderTrackingSystem.Contacts.frmContactPerson(userRightsColl, _userName, false);
            frmPerson.StartPosition = FormStartPosition.CenterParent;
            frmPerson.ShowDialog();
        }

        private void linkLabel10_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            TenderTrackingSystem.DefaultView frmPrjView = new TenderTrackingSystem.DefaultView(userRightsColl,"Admin",false,null);
            frmPrjView.StartPosition = FormStartPosition.CenterParent;
            frmPrjView.ShowDialog();
        }

        private void linkLabel8_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MDI_ParenrForm.Projects.frmOngoingContracts frmOngoingPrj = new MDI_ParenrForm.Projects.frmOngoingContracts(userRightsColl, _userName,false,null);
            frmOngoingPrj.StartPosition = FormStartPosition.CenterParent;
            frmOngoingPrj.ShowDialog();
        }

        private void linkLabel9_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MDI_ParenrForm.Projects.frmInactiveProjects frmInactivePrj = new MDI_ParenrForm.Projects.frmInactiveProjects(userRightsColl, _userName,false);
            frmInactivePrj.StartPosition = FormStartPosition.CenterParent;
            frmInactivePrj.ShowDialog();
        }
        private void lnkMouseOverStyle(LinkLabel lblName)
        {
            lblName.BackColor = Color.Yellow;
            lblName.ForeColor = Color.White;
        }
        private void lnkMouseLeaveStyle(LinkLabel lblName)
        {
            lblName.BackColor = Color.White;
            lblName.ForeColor = Color.DarkGray;
        }
        private void linkLabel13_MouseHover(object sender, EventArgs e)
        {
            lnkMouseOverStyle(lnkAddProject);
        }
        private void linkLabel13_MouseLeave(object sender, EventArgs e)
        {
            lnkMouseLeaveStyle(lnkAddProject);
        }
        private void linkLabel12_MouseHover(object sender, EventArgs e)
        {
            lnkMouseOverStyle(lnkCompany);
        }
        private void linkLabel12_MouseLeave(object sender, EventArgs e)
        {
            lnkMouseLeaveStyle(lnkCompany);
        }
        private void lnkContacts_MouseHover(object sender, EventArgs e)
        {
            lnkMouseOverStyle(lnkContacts);
        }
        private void lnkContacts_MouseLeave(object sender, EventArgs e)
        {
            lnkMouseLeaveStyle(lnkContacts);
        }
        private void lnkViewProjects_MouseHover(object sender, EventArgs e)
        {
            lnkMouseOverStyle(lnkViewProjects);
        }
        private void lnkViewProjects_MouseLeave(object sender, EventArgs e)
        {
            lnkMouseLeaveStyle(lnkViewProjects);
        } 
        private void lnkOngoingProjects_MouseHover(object sender, EventArgs e)
        {
            lnkMouseOverStyle(lnkOngoingProjects);
        }
        private void lnkOngoingProjects_MouseLeave(object sender, EventArgs e)
        {
            lnkMouseLeaveStyle(lnkOngoingProjects);
        }
        private void lnkInactive_MouseHover(object sender, EventArgs e)
        {
            lnkMouseOverStyle(lnkInactive);
        }
        private void lnkInactive_MouseLeave(object sender, EventArgs e)
        {
            lnkMouseLeaveStyle(lnkInactive);
        }

        private void splitContainer2_Panel2_Paint(object sender, PaintEventArgs e)
        {

        }
       
    }
}
