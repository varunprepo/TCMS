﻿namespace MDI_ParenrForm.Dashboard
{
    partial class frmTenderIssued
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvIssuedTenders = new System.Windows.Forms.DataGridView();
            this.btnExpoprt = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvIssuedTenders)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvIssuedTenders
            // 
            this.dgvIssuedTenders.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvIssuedTenders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvIssuedTenders.Location = new System.Drawing.Point(26, 69);
            this.dgvIssuedTenders.Name = "dgvIssuedTenders";
            this.dgvIssuedTenders.Size = new System.Drawing.Size(1028, 439);
            this.dgvIssuedTenders.TabIndex = 0;
            // 
            // btnExpoprt
            // 
            this.btnExpoprt.Location = new System.Drawing.Point(966, 516);
            this.btnExpoprt.Name = "btnExpoprt";
            this.btnExpoprt.Size = new System.Drawing.Size(88, 28);
            this.btnExpoprt.TabIndex = 1;
            this.btnExpoprt.Text = "Export to Excel";
            this.btnExpoprt.UseVisualStyleBackColor = true;
            this.btnExpoprt.Click += new System.EventHandler(this.btnExpoprt_Click);
            // 
            // frmTenderIssued
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1089, 554);
            this.Controls.Add(this.btnExpoprt);
            this.Controls.Add(this.dgvIssuedTenders);
            this.Name = "frmTenderIssued";
            this.Text = "frmTenderIssued";
            this.Load += new System.EventHandler(this.frmTenderIssued_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvIssuedTenders)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvIssuedTenders;
        private System.Windows.Forms.Button btnExpoprt;
    }
}