﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace MDI_ParenrForm.Dashboard
{
    public partial class frmTCMCharts : Form
    {
        private string strCon = ConfigurationManager.AppSettings["TCMSConnString"].ToString();
        SqlConnection cn = new SqlConnection();

        public frmTCMCharts(IList<string> userRightsColl)
        {
            InitializeComponent();

            if (!userRightsColl.Contains("87"))
            {
                // Added by Varun on 23Nov2015
                cn.ConnectionString = strCon;
                cn.Open();
                SqlDataAdapter da = new SqlDataAdapter("SELECT FYID,FiscalYear FROM [FiscalYear]", cn);
                DataSet ds = new DataSet();
                da.Fill(ds);
                cmbFinancialYears.Items.Clear();
                cmbFinancialYears.DataSource = ds.Tables[0];
                cmbFinancialYears.DisplayMember = "FiscalYear";
                cmbFinancialYears.ValueMember = "FYID";
                cmbFinancialYears.SelectedIndex = -1;
                cmbFinancialYears.SelectedValue = 13;
                ds.Tables.Clear();

                NumberOfCommitmentEachYear(null);
                ClassificationOfTotalContractAmount(null);
            }
            else
            {
                lblFinancialYear.Visible = false;
                cmbFinancialYears.Visible = false;
                btnRefreshNumberOfCommitmentEachYear.Visible = false;
                chartNumberOfCommitmentEachYear.Visible = false;
                pieChart.Visible = false;
            }

        }

        private void ClassificationOfTotalContractAmount(string selectedFYID)
        {
            try
            {
                if (cn.State == ConnectionState.Closed)
                {
                    cn.ConnectionString = strCon;
                    cn.Open();
                }
                DataSet dsTndr = new DataSet();

                string sqlQuery = null;

                if (selectedFYID == null)
                {
                    sqlQuery = "SELECT Format(SUM(CONTRACTORS.ContractAmount) / 1000000.00,'N') AS JVAmount FROM CONTRACTORS INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id WHERE (COMPANY.co_name LIKE '%JV%') AND (CONTRACTORS.ContractAmount IS NOT NULL) AND (CONTRACTORS.ContractAmount <> 0) "+
                    "and (COMPANY.qatari_share IS NOT NULL)";                    

                    SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, cn);
                    daTndr.Fill(dsTndr);                     
                    pieChart.Series[0].Points.Add(Convert.ToDouble(dsTndr.Tables[0].Rows[0][0]));
                    pieChart.Series[0].Points[0].Label = dsTndr.Tables[0].Rows[0][0].ToString();
                    pieChart.Series[0].Points[0].LegendText = "Joint Venture Total Amount";                    
                    pieChart.Series[0].Points[0].ToolTip = "Joint Venture Total Amount";

                    dsTndr.Tables.Clear();
                    sqlQuery = "SELECT Format(SUM(CONTRACTORS.ContractAmount) / 1000000.00,'N') AS QatariShareAmount FROM CONTRACTORS INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id WHERE (COMPANY.qatari_share IS NOT NULL) AND (COMPANY.qatari_share <> 0) AND (CONTRACTORS.ContractAmount IS NOT NULL)";
                    daTndr = new SqlDataAdapter(sqlQuery, cn);
                    daTndr.Fill(dsTndr);
                    pieChart.Series[0].Points.Add(Convert.ToDouble(dsTndr.Tables[0].Rows[0][0]));
                    pieChart.Series[0].Points[1].Label = dsTndr.Tables[0].Rows[0][0].ToString();
                    pieChart.Series[0].Points[1].LegendText = "Qatari Share Total Amount";
                    pieChart.Series[0].Points[1].ToolTip = "Qatari Share Total Amount";
                    dsTndr.Tables.Clear();
                    sqlQuery = "SELECT Format(SUM(CONTRACTORS.ContractAmount) / 1000000.00,'N') AS NonQatariShareAmount FROM CONTRACTORS INNER JOIN COMPANY ON CONTRACTORS.co_id = COMPANY.co_id WHERE (COMPANY.qatari_share IS NULL) OR (COMPANY.qatari_share = 0) AND (CONTRACTORS.ContractAmount IS NOT NULL) AND (CONTRACTORS.ContractAmount <> 0)";
                    daTndr = new SqlDataAdapter(sqlQuery, cn);
                    daTndr.Fill(dsTndr);
                    pieChart.Series[0].Points.Add(Convert.ToDouble(dsTndr.Tables[0].Rows[0][0]));
                    pieChart.Series[0].Points[2].Label = dsTndr.Tables[0].Rows[0][0].ToString();
                    pieChart.Series[0].Points[2].LegendText = "Non-Qatari Share Total Amount";
                    pieChart.Series[0].Points[2].ToolTip = "Non-Qatari Share Total Amount";
                    dsTndr.Tables.Clear();                         
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while displaying the Tender Documents Under Preparation Chart", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void NumberOfCommitmentEachYear(string selectedFYID)
        {
            try
            {
                if (cn.State == ConnectionState.Closed)
                {
                    cn.ConnectionString = strCon;
                    cn.Open();
                }
                DataSet dsTndr = new DataSet();

                string sqlQuery = null;
                
                if(selectedFYID==null)
                    sqlQuery="SELECT SUM(TotalContracts) AS TotalContracts, FiscalYear FROM (SELECT COUNT(CONTRACTORS.proj_id) AS TotalContracts, FiscalYear.FiscalYear FROM CONTRACTORS INNER JOIN PROJECTS ON CONTRACTORS.proj_id = PROJECTS.proj_id INNER JOIN " +
                    "FiscalYear ON PROJECTS.FYID = FiscalYear.FYID INNER JOIN Committee ON PROJECTS.committee_id = Committee.committee_id WHERE (FiscalYear.FYID in (SELECT (FYID) AS Expr1 FROM FiscalYear AS FiscalYear_1)) AND (CONTRACTORS.contract_no IS NOT NULL) AND (CONTRACTORS.contract_no <> '') AND " +
                    "(CONTRACTORS.contract_no <> 'Framework') AND (CONTRACTORS.contract_no <> 'FRAMEWORK') and (CONTRACTORS.contract_no <> 'Workorder') AND (CONTRACTORS.contract_no <> 'WORKORDER') GROUP BY CONTRACTORS.proj_id, FiscalYear.FiscalYear) AS T GROUP BY FiscalYear";
                else
                    sqlQuery="SELECT SUM(TotalContracts) AS TotalContracts, FiscalYear FROM (SELECT COUNT(CONTRACTORS.proj_id) AS TotalContracts, FiscalYear.FiscalYear FROM CONTRACTORS INNER JOIN PROJECTS ON CONTRACTORS.proj_id = PROJECTS.proj_id INNER JOIN " +
                    "FiscalYear ON PROJECTS.FYID = FiscalYear.FYID INNER JOIN Committee ON PROJECTS.committee_id = Committee.committee_id WHERE (FiscalYear.FYID = " + selectedFYID + ") AND (CONTRACTORS.contract_no IS NOT NULL) AND (CONTRACTORS.contract_no <> '') AND " +
                    "(CONTRACTORS.contract_no <> 'Framework') AND (CONTRACTORS.contract_no <> 'FRAMEWORK') and (CONTRACTORS.contract_no <> 'Workorder') AND (CONTRACTORS.contract_no <> 'WORKORDER') GROUP BY CONTRACTORS.proj_id, FiscalYear.FiscalYear) AS T GROUP BY FiscalYear";

                SqlDataAdapter daTndr = new SqlDataAdapter(sqlQuery, cn);
                daTndr.Fill(dsTndr);
                chartNumberOfCommitmentEachYear.DataSource = dsTndr.Tables[0].DefaultView;
                chartNumberOfCommitmentEachYear.Series["Commitment Each Year"].XValueMember = "FiscalYear";
                chartNumberOfCommitmentEachYear.Series["Commitment Each Year"].YValueMembers = "TotalContracts";
                dsTndr.Tables.Clear();
                chartNumberOfCommitmentEachYear.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
                chartNumberOfCommitmentEachYear.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
                chartNumberOfCommitmentEachYear.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
                chartNumberOfCommitmentEachYear.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

                chartNumberOfCommitmentEachYear.ChartAreas[0].AxisX.LabelStyle.Angle = 30;
                chartNumberOfCommitmentEachYear.ChartAreas[0].AxisX.LabelStyle.ForeColor = Color.Maroon;
                chartNumberOfCommitmentEachYear.ChartAreas[0].AxisX.Interval = 1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while displaying the Tender Documents Under Preparation Chart", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRefreshNumberOfCommitmentEachYear_Click(object sender, EventArgs e)
        {
            cmbFinancialYears.SelectedValue = 13;
            NumberOfCommitmentEachYear(null);
        }

        private void cmbFinancialYears_SelectionChangeCommitted(object sender, EventArgs e)
        {
            NumberOfCommitmentEachYear(cmbFinancialYears.SelectedValue.ToString());
        }
    }
}
