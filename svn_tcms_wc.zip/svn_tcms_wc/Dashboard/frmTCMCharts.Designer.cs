﻿namespace MDI_ParenrForm.Dashboard
{
    partial class frmTCMCharts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title1 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title2 = new System.Windows.Forms.DataVisualization.Charting.Title();
            this.chartNumberOfCommitmentEachYear = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.lblFinancialYear = new System.Windows.Forms.Label();
            this.cmbFinancialYears = new System.Windows.Forms.ComboBox();
            this.btnRefreshNumberOfCommitmentEachYear = new System.Windows.Forms.Button();
            this.pieChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            ((System.ComponentModel.ISupportInitialize)(this.chartNumberOfCommitmentEachYear)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pieChart)).BeginInit();
            this.SuspendLayout();
            // 
            // chartNumberOfCommitmentEachYear
            // 
            this.chartNumberOfCommitmentEachYear.BorderlineColor = System.Drawing.Color.Blue;
            chartArea1.BackColor = System.Drawing.Color.White;
            chartArea1.Name = "ChartArea1";
            this.chartNumberOfCommitmentEachYear.ChartAreas.Add(chartArea1);
            legend1.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top;
            legend1.Name = "Legend1";
            this.chartNumberOfCommitmentEachYear.Legends.Add(legend1);
            this.chartNumberOfCommitmentEachYear.Location = new System.Drawing.Point(22, 63);
            this.chartNumberOfCommitmentEachYear.Name = "chartNumberOfCommitmentEachYear";
            this.chartNumberOfCommitmentEachYear.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Grayscale;
            series1.ChartArea = "ChartArea1";
            series1.CustomProperties = "DrawingStyle=Cylinder, MaxPixelPointWidth=30";
            series1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            series1.IsValueShownAsLabel = true;
            series1.IsVisibleInLegend = false;
            series1.IsXValueIndexed = true;
            series1.LabelAngle = -90;
            series1.Legend = "Legend1";
            series1.MarkerBorderWidth = 3;
            series1.MarkerSize = 10;
            series1.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series1.Name = "Commitment Each Year";
            series1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Bright;
            series1.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int64;
            this.chartNumberOfCommitmentEachYear.Series.Add(series1);
            this.chartNumberOfCommitmentEachYear.Size = new System.Drawing.Size(835, 221);
            this.chartNumberOfCommitmentEachYear.TabIndex = 14;
            this.chartNumberOfCommitmentEachYear.Text = "Number Of Commitment Each Year";
            this.chartNumberOfCommitmentEachYear.TextAntiAliasingQuality = System.Windows.Forms.DataVisualization.Charting.TextAntiAliasingQuality.Normal;
            title1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            title1.Name = "Title1";
            title1.Text = "NUMBER OF COMMITMENT EACH YEAR";
            this.chartNumberOfCommitmentEachYear.Titles.Add(title1);
            // 
            // lblFinancialYear
            // 
            this.lblFinancialYear.AutoSize = true;
            this.lblFinancialYear.BackColor = System.Drawing.Color.White;
            this.lblFinancialYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinancialYear.ForeColor = System.Drawing.Color.Red;
            this.lblFinancialYear.Location = new System.Drawing.Point(19, 20);
            this.lblFinancialYear.Name = "lblFinancialYear";
            this.lblFinancialYear.Size = new System.Drawing.Size(99, 15);
            this.lblFinancialYear.TabIndex = 15;
            this.lblFinancialYear.Text = "Financial Year";
            // 
            // cmbFinancialYears
            // 
            this.cmbFinancialYears.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbFinancialYears.FormattingEnabled = true;
            this.cmbFinancialYears.Location = new System.Drawing.Point(124, 18);
            this.cmbFinancialYears.Name = "cmbFinancialYears";
            this.cmbFinancialYears.Size = new System.Drawing.Size(103, 23);
            this.cmbFinancialYears.TabIndex = 16;
            this.cmbFinancialYears.SelectionChangeCommitted += new System.EventHandler(this.cmbFinancialYears_SelectionChangeCommitted);
            // 
            // btnRefreshNumberOfCommitmentEachYear
            // 
            this.btnRefreshNumberOfCommitmentEachYear.BackgroundImage = global::MDI_ParenrForm.Properties.Resources.Refresh;
            this.btnRefreshNumberOfCommitmentEachYear.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnRefreshNumberOfCommitmentEachYear.Location = new System.Drawing.Point(230, 17);
            this.btnRefreshNumberOfCommitmentEachYear.Name = "btnRefreshNumberOfCommitmentEachYear";
            this.btnRefreshNumberOfCommitmentEachYear.Size = new System.Drawing.Size(26, 24);
            this.btnRefreshNumberOfCommitmentEachYear.TabIndex = 17;
            this.btnRefreshNumberOfCommitmentEachYear.UseVisualStyleBackColor = true;
            this.btnRefreshNumberOfCommitmentEachYear.Click += new System.EventHandler(this.btnRefreshNumberOfCommitmentEachYear_Click);
            // 
            // pieChart
            // 
            chartArea2.Name = "ChartArea1";
            this.pieChart.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.pieChart.Legends.Add(legend2);
            this.pieChart.Location = new System.Drawing.Point(173, 300);
            this.pieChart.Name = "pieChart";
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            this.pieChart.Series.Add(series2);
            this.pieChart.Size = new System.Drawing.Size(655, 300);
            this.pieChart.TabIndex = 18;
            this.pieChart.Text = "chart1";
            title2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            title2.Name = "Title1";
            title2.Text = "CLASSIFICATION OF CONTRACT AMOUNT OF DIFFERENT GROUPS (QAR MILLIONS)";
            this.pieChart.Titles.Add(title2);
            // 
            // frmTCMCharts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(950, 625);
            this.Controls.Add(this.pieChart);
            this.Controls.Add(this.btnRefreshNumberOfCommitmentEachYear);
            this.Controls.Add(this.cmbFinancialYears);
            this.Controls.Add(this.lblFinancialYear);
            this.Controls.Add(this.chartNumberOfCommitmentEachYear);
            this.Name = "frmTCMCharts";
            this.Text = "TCM More Charts";
            ((System.ComponentModel.ISupportInitialize)(this.chartNumberOfCommitmentEachYear)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pieChart)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart chartNumberOfCommitmentEachYear;
        private System.Windows.Forms.Label lblFinancialYear;
        private System.Windows.Forms.ComboBox cmbFinancialYears;
        private System.Windows.Forms.Button btnRefreshNumberOfCommitmentEachYear;
        private System.Windows.Forms.DataVisualization.Charting.Chart pieChart;
    }
}