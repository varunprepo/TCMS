﻿namespace MDI_ParenrForm
{
    partial class dashBoardParent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title1 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title2 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title3 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea5 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend5 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title4 = new System.Windows.Forms.DataVisualization.Charting.Title();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.btnRefreshTenderDocsApproved = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.ChartPrepDocsApproved = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.cmbFinancialYears = new System.Windows.Forms.ComboBox();
            this.lblFinancialYear = new System.Windows.Forms.Label();
            this.btnRefreshTotValTenderAwardsPerCommt = new System.Windows.Forms.Button();
            this.cmbFYTotValTenderAwardsPerCommt = new System.Windows.Forms.ComboBox();
            this.lblFYTotValTenderAwardsPerCommt = new System.Windows.Forms.Label();
            this.btnRefreshNumberOfTenderEachYear = new System.Windows.Forms.Button();
            this.cmbCmteNamesForTotalContractAmounts = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbFYForNumberOfTenders = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbCmteNamesForNumberOfTenders = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.chartTotalAmountOfContractsPerCommittee = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartTenderDocsUnderPreparation = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartTendersPerYearPerCommittee = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.btnRefreshTotalProjectsPerTenderStatus = new System.Windows.Forms.Button();
            this.cmbCommitteNames = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.ChartProjects = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.button4 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.linkShowMoreCharts = new System.Windows.Forms.LinkLabel();
            this.button7 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.lnkOngoingProjects = new System.Windows.Forms.LinkLabel();
            this.lnkInactive = new System.Windows.Forms.LinkLabel();
            this.lnkViewProjects = new System.Windows.Forms.LinkLabel();
            this.lnkContacts = new System.Windows.Forms.LinkLabel();
            this.lnkCompany = new System.Windows.Forms.LinkLabel();
            this.lnkAddProject = new System.Windows.Forms.LinkLabel();
            this.panelForDashboard = new System.Windows.Forms.Panel();
            this.lblUserName = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.btnAdmin = new System.Windows.Forms.Button();
            this.btnReports = new System.Windows.Forms.Button();
            this.btnDashboard = new System.Windows.Forms.Button();
            this.btnProjects = new System.Windows.Forms.Button();
            this.btnContacts = new System.Windows.Forms.Button();
            this.btnDocuments = new System.Windows.Forms.Button();
            this.aFFAIRSBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ChartPrepDocsApproved)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartTotalAmountOfContractsPerCommittee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartTenderDocsUnderPreparation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartTendersPerYearPerCommittee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ChartProjects)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.panelForDashboard.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.aFFAIRSBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Maroon;
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button6.ForeColor = System.Drawing.Color.Maroon;
            this.button6.Location = new System.Drawing.Point(26, 206);
            this.button6.Margin = new System.Windows.Forms.Padding(0);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(24, 24);
            this.button6.TabIndex = 18;
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Maroon;
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button5.ForeColor = System.Drawing.Color.Maroon;
            this.button5.Location = new System.Drawing.Point(26, 160);
            this.button5.Margin = new System.Windows.Forms.Padding(0);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(24, 24);
            this.button5.TabIndex = 17;
            this.button5.UseVisualStyleBackColor = false;
            // 
            // splitContainer3
            // 
            this.splitContainer3.AccessibleRole = System.Windows.Forms.AccessibleRole.ScrollBar;
            this.splitContainer3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Right;
            this.splitContainer3.Location = new System.Drawing.Point(271, 0);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.BackColor = System.Drawing.Color.Transparent;
            this.splitContainer3.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.splitContainer3.Panel1.Controls.Add(this.btnRefreshTenderDocsApproved);
            this.splitContainer3.Panel1.Controls.Add(this.label1);
            this.splitContainer3.Panel1.Controls.Add(this.ChartPrepDocsApproved);
            this.splitContainer3.Panel1.Controls.Add(this.cmbFinancialYears);
            this.splitContainer3.Panel1.Controls.Add(this.lblFinancialYear);
            this.splitContainer3.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer3_Panel1_Paint);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.AutoScroll = true;
            this.splitContainer3.Panel2.BackColor = System.Drawing.Color.White;
            this.splitContainer3.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.splitContainer3.Panel2.Controls.Add(this.btnRefreshTotValTenderAwardsPerCommt);
            this.splitContainer3.Panel2.Controls.Add(this.cmbFYTotValTenderAwardsPerCommt);
            this.splitContainer3.Panel2.Controls.Add(this.lblFYTotValTenderAwardsPerCommt);
            this.splitContainer3.Panel2.Controls.Add(this.btnRefreshNumberOfTenderEachYear);
            this.splitContainer3.Panel2.Controls.Add(this.cmbCmteNamesForTotalContractAmounts);
            this.splitContainer3.Panel2.Controls.Add(this.label7);
            this.splitContainer3.Panel2.Controls.Add(this.cmbFYForNumberOfTenders);
            this.splitContainer3.Panel2.Controls.Add(this.label6);
            this.splitContainer3.Panel2.Controls.Add(this.cmbCmteNamesForNumberOfTenders);
            this.splitContainer3.Panel2.Controls.Add(this.label5);
            this.splitContainer3.Panel2.Controls.Add(this.chartTotalAmountOfContractsPerCommittee);
            this.splitContainer3.Panel2.Controls.Add(this.chartTenderDocsUnderPreparation);
            this.splitContainer3.Panel2.Controls.Add(this.chartTendersPerYearPerCommittee);
            this.splitContainer3.Panel2.Controls.Add(this.btnRefreshTotalProjectsPerTenderStatus);
            this.splitContainer3.Panel2.Controls.Add(this.cmbCommitteNames);
            this.splitContainer3.Panel2.Controls.Add(this.label2);
            this.splitContainer3.Panel2.Controls.Add(this.ChartProjects);
            this.splitContainer3.Size = new System.Drawing.Size(1297, 965);
            this.splitContainer3.SplitterDistance = 305;
            this.splitContainer3.SplitterWidth = 1;
            this.splitContainer3.TabIndex = 16;
            // 
            // btnRefreshTenderDocsApproved
            // 
            this.btnRefreshTenderDocsApproved.BackgroundImage = global::MDI_ParenrForm.Properties.Resources.Refresh;
            this.btnRefreshTenderDocsApproved.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnRefreshTenderDocsApproved.Location = new System.Drawing.Point(271, 23);
            this.btnRefreshTenderDocsApproved.Name = "btnRefreshTenderDocsApproved";
            this.btnRefreshTenderDocsApproved.Size = new System.Drawing.Size(26, 24);
            this.btnRefreshTenderDocsApproved.TabIndex = 12;
            this.btnRefreshTenderDocsApproved.UseVisualStyleBackColor = true;
            this.btnRefreshTenderDocsApproved.Click += new System.EventHandler(this.btnRefreshTenderDocsApproved_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(550, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(441, 16);
            this.label1.TabIndex = 11;
            this.label1.Text = "NUMBER OF TENDER DOCUMENTS APPROVED EACH YEAR";
            // 
            // ChartPrepDocsApproved
            // 
            this.ChartPrepDocsApproved.BorderlineColor = System.Drawing.Color.Blue;
            chartArea1.BackColor = System.Drawing.Color.White;
            chartArea1.Name = "ChartArea1";
            this.ChartPrepDocsApproved.ChartAreas.Add(chartArea1);
            legend1.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top;
            legend1.Name = "Legend1";
            this.ChartPrepDocsApproved.Legends.Add(legend1);
            this.ChartPrepDocsApproved.Location = new System.Drawing.Point(4, 79);
            this.ChartPrepDocsApproved.Name = "ChartPrepDocsApproved";
            this.ChartPrepDocsApproved.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Grayscale;
            series1.ChartArea = "ChartArea1";
            series1.CustomProperties = "DrawingStyle=Cylinder, MaxPixelPointWidth=30";
            series1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold);
            series1.IsValueShownAsLabel = true;
            series1.IsVisibleInLegend = false;
            series1.Legend = "Legend1";
            series1.MarkerSize = 8;
            series1.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series1.Name = "PrepDocsApproved";
            series1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.BrightPastel;
            this.ChartPrepDocsApproved.Series.Add(series1);
            this.ChartPrepDocsApproved.Size = new System.Drawing.Size(367, 214);
            this.ChartPrepDocsApproved.TabIndex = 10;
            this.ChartPrepDocsApproved.Text = "prepDocsApproved";
            this.ChartPrepDocsApproved.TextAntiAliasingQuality = System.Windows.Forms.DataVisualization.Charting.TextAntiAliasingQuality.Normal;
            // 
            // cmbFinancialYears
            // 
            this.cmbFinancialYears.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbFinancialYears.FormattingEnabled = true;
            this.cmbFinancialYears.Location = new System.Drawing.Point(166, 24);
            this.cmbFinancialYears.Name = "cmbFinancialYears";
            this.cmbFinancialYears.Size = new System.Drawing.Size(103, 23);
            this.cmbFinancialYears.TabIndex = 3;
            this.cmbFinancialYears.SelectionChangeCommitted += new System.EventHandler(this.cmbFinancialYears_SelectionChangeCommitted);
            // 
            // lblFinancialYear
            // 
            this.lblFinancialYear.AutoSize = true;
            this.lblFinancialYear.BackColor = System.Drawing.Color.White;
            this.lblFinancialYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinancialYear.ForeColor = System.Drawing.Color.Red;
            this.lblFinancialYear.Location = new System.Drawing.Point(61, 28);
            this.lblFinancialYear.Name = "lblFinancialYear";
            this.lblFinancialYear.Size = new System.Drawing.Size(99, 15);
            this.lblFinancialYear.TabIndex = 8;
            this.lblFinancialYear.Text = "Financial Year";
            // 
            // btnRefreshTotValTenderAwardsPerCommt
            // 
            this.btnRefreshTotValTenderAwardsPerCommt.BackgroundImage = global::MDI_ParenrForm.Properties.Resources.Refresh;
            this.btnRefreshTotValTenderAwardsPerCommt.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnRefreshTotValTenderAwardsPerCommt.Location = new System.Drawing.Point(744, 675);
            this.btnRefreshTotValTenderAwardsPerCommt.Name = "btnRefreshTotValTenderAwardsPerCommt";
            this.btnRefreshTotValTenderAwardsPerCommt.Size = new System.Drawing.Size(26, 24);
            this.btnRefreshTotValTenderAwardsPerCommt.TabIndex = 23;
            this.btnRefreshTotValTenderAwardsPerCommt.UseVisualStyleBackColor = true;
            this.btnRefreshTotValTenderAwardsPerCommt.Click += new System.EventHandler(this.btnRefreshTotValTenderAwardsPerCommt_Click);
            // 
            // cmbFYTotValTenderAwardsPerCommt
            // 
            this.cmbFYTotValTenderAwardsPerCommt.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbFYTotValTenderAwardsPerCommt.FormattingEnabled = true;
            this.cmbFYTotValTenderAwardsPerCommt.Location = new System.Drawing.Point(635, 675);
            this.cmbFYTotValTenderAwardsPerCommt.Name = "cmbFYTotValTenderAwardsPerCommt";
            this.cmbFYTotValTenderAwardsPerCommt.Size = new System.Drawing.Size(103, 23);
            this.cmbFYTotValTenderAwardsPerCommt.TabIndex = 22;
            this.cmbFYTotValTenderAwardsPerCommt.SelectionChangeCommitted += new System.EventHandler(this.cmbFYTotValTenderAwardsPerCommt_SelectedIndexChanged);
            // 
            // lblFYTotValTenderAwardsPerCommt
            // 
            this.lblFYTotValTenderAwardsPerCommt.AutoSize = true;
            this.lblFYTotValTenderAwardsPerCommt.BackColor = System.Drawing.Color.White;
            this.lblFYTotValTenderAwardsPerCommt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFYTotValTenderAwardsPerCommt.ForeColor = System.Drawing.Color.Red;
            this.lblFYTotValTenderAwardsPerCommt.Location = new System.Drawing.Point(530, 679);
            this.lblFYTotValTenderAwardsPerCommt.Name = "lblFYTotValTenderAwardsPerCommt";
            this.lblFYTotValTenderAwardsPerCommt.Size = new System.Drawing.Size(99, 15);
            this.lblFYTotValTenderAwardsPerCommt.TabIndex = 21;
            this.lblFYTotValTenderAwardsPerCommt.Text = "Financial Year";
            // 
            // btnRefreshNumberOfTenderEachYear
            // 
            this.btnRefreshNumberOfTenderEachYear.BackgroundImage = global::MDI_ParenrForm.Properties.Resources.Refresh;
            this.btnRefreshNumberOfTenderEachYear.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnRefreshNumberOfTenderEachYear.Location = new System.Drawing.Point(693, 334);
            this.btnRefreshNumberOfTenderEachYear.Name = "btnRefreshNumberOfTenderEachYear";
            this.btnRefreshNumberOfTenderEachYear.Size = new System.Drawing.Size(26, 24);
            this.btnRefreshNumberOfTenderEachYear.TabIndex = 19;
            this.btnRefreshNumberOfTenderEachYear.UseVisualStyleBackColor = true;
            this.btnRefreshNumberOfTenderEachYear.Click += new System.EventHandler(this.btnRefreshNumberOfTenderEachYear_Click);
            // 
            // cmbCmteNamesForTotalContractAmounts
            // 
            this.cmbCmteNamesForTotalContractAmounts.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCmteNamesForTotalContractAmounts.FormattingEnabled = true;
            this.cmbCmteNamesForTotalContractAmounts.Location = new System.Drawing.Point(210, 673);
            this.cmbCmteNamesForTotalContractAmounts.Name = "cmbCmteNamesForTotalContractAmounts";
            this.cmbCmteNamesForTotalContractAmounts.Size = new System.Drawing.Size(241, 23);
            this.cmbCmteNamesForTotalContractAmounts.TabIndex = 18;
            this.cmbCmteNamesForTotalContractAmounts.SelectionChangeCommitted += new System.EventHandler(this.cmbCmteNamesForTotalContractAmounts_SelectionChangeCommitted);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(72, 675);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(132, 15);
            this.label7.TabIndex = 17;
            this.label7.Text = "Tender Committees";
            // 
            // cmbFYForNumberOfTenders
            // 
            this.cmbFYForNumberOfTenders.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbFYForNumberOfTenders.FormattingEnabled = true;
            this.cmbFYForNumberOfTenders.Location = new System.Drawing.Point(584, 335);
            this.cmbFYForNumberOfTenders.Name = "cmbFYForNumberOfTenders";
            this.cmbFYForNumberOfTenders.Size = new System.Drawing.Size(103, 23);
            this.cmbFYForNumberOfTenders.TabIndex = 12;
            this.cmbFYForNumberOfTenders.SelectionChangeCommitted += new System.EventHandler(this.cmbFYForNumberOfTenders_SelectionChangeCommitted);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(479, 337);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 15);
            this.label6.TabIndex = 16;
            this.label6.Text = "Financial Year";
            // 
            // cmbCmteNamesForNumberOfTenders
            // 
            this.cmbCmteNamesForNumberOfTenders.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCmteNamesForNumberOfTenders.FormattingEnabled = true;
            this.cmbCmteNamesForNumberOfTenders.Location = new System.Drawing.Point(199, 335);
            this.cmbCmteNamesForNumberOfTenders.Name = "cmbCmteNamesForNumberOfTenders";
            this.cmbCmteNamesForNumberOfTenders.Size = new System.Drawing.Size(241, 23);
            this.cmbCmteNamesForNumberOfTenders.TabIndex = 15;
            this.cmbCmteNamesForNumberOfTenders.SelectionChangeCommitted += new System.EventHandler(this.cmbCmteNamesForNumberOfTenders_SelectionChangeCommitted);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(61, 337);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(132, 15);
            this.label5.TabIndex = 14;
            this.label5.Text = "Tender Committees";
            // 
            // chartTotalAmountOfContractsPerCommittee
            // 
            this.chartTotalAmountOfContractsPerCommittee.BorderlineColor = System.Drawing.Color.Blue;
            chartArea2.BackColor = System.Drawing.Color.White;
            chartArea2.Name = "ChartArea1";
            this.chartTotalAmountOfContractsPerCommittee.ChartAreas.Add(chartArea2);
            legend2.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top;
            legend2.Name = "Legend1";
            this.chartTotalAmountOfContractsPerCommittee.Legends.Add(legend2);
            this.chartTotalAmountOfContractsPerCommittee.Location = new System.Drawing.Point(47, 716);
            this.chartTotalAmountOfContractsPerCommittee.Name = "chartTotalAmountOfContractsPerCommittee";
            this.chartTotalAmountOfContractsPerCommittee.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Grayscale;
            series2.ChartArea = "ChartArea1";
            series2.CustomProperties = "DrawingStyle=Cylinder, MaxPixelPointWidth=30";
            series2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            series2.IsValueShownAsLabel = true;
            series2.IsVisibleInLegend = false;
            series2.IsXValueIndexed = true;
            series2.Label = "#VAL{N}";
            series2.LabelAngle = -90;
            series2.Legend = "Legend1";
            series2.MarkerBorderWidth = 3;
            series2.MarkerSize = 10;
            series2.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series2.Name = "Total ContractAmount";
            series2.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.EarthTones;
            series2.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int64;
            this.chartTotalAmountOfContractsPerCommittee.Series.Add(series2);
            this.chartTotalAmountOfContractsPerCommittee.Size = new System.Drawing.Size(835, 221);
            this.chartTotalAmountOfContractsPerCommittee.TabIndex = 13;
            this.chartTotalAmountOfContractsPerCommittee.Text = "Total Amount Of Contracts Per Committee";
            this.chartTotalAmountOfContractsPerCommittee.TextAntiAliasingQuality = System.Windows.Forms.DataVisualization.Charting.TextAntiAliasingQuality.Normal;
            title1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            title1.Name = "Title1";
            title1.Text = "TOTAL VALUE OF TENDER AWARDS PER COMMITTEE (QAR MILLIONS)";
            this.chartTotalAmountOfContractsPerCommittee.Titles.Add(title1);
            // 
            // chartTenderDocsUnderPreparation
            // 
            this.chartTenderDocsUnderPreparation.BorderlineColor = System.Drawing.Color.Blue;
            chartArea3.BackColor = System.Drawing.Color.White;
            chartArea3.Name = "ChartArea1";
            this.chartTenderDocsUnderPreparation.ChartAreas.Add(chartArea3);
            legend3.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top;
            legend3.Name = "Legend1";
            this.chartTenderDocsUnderPreparation.Legends.Add(legend3);
            this.chartTenderDocsUnderPreparation.Location = new System.Drawing.Point(52, 964);
            this.chartTenderDocsUnderPreparation.Name = "chartTenderDocsUnderPreparation";
            this.chartTenderDocsUnderPreparation.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Chocolate;
            series3.ChartArea = "ChartArea1";
            series3.CustomProperties = "DrawingStyle=Cylinder, MaxPixelPointWidth=30";
            series3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold);
            series3.IsValueShownAsLabel = true;
            series3.IsVisibleInLegend = false;
            series3.IsXValueIndexed = true;
            series3.LabelAngle = -90;
            series3.Legend = "Legend1";
            series3.MarkerBorderWidth = 3;
            series3.MarkerSize = 10;
            series3.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series3.Name = "Ongoing Tenders";
            series3.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            series3.XValueMember = "0";
            this.chartTenderDocsUnderPreparation.Series.Add(series3);
            this.chartTenderDocsUnderPreparation.Size = new System.Drawing.Size(932, 196);
            this.chartTenderDocsUnderPreparation.TabIndex = 12;
            this.chartTenderDocsUnderPreparation.Text = "Tender Documents Under Preparation";
            this.chartTenderDocsUnderPreparation.TextAntiAliasingQuality = System.Windows.Forms.DataVisualization.Charting.TextAntiAliasingQuality.Normal;
            title2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            title2.Name = "Title1";
            title2.Text = "TENDER DOCUMENTS UNDER PREPARATION";
            this.chartTenderDocsUnderPreparation.Titles.Add(title2);
            this.chartTenderDocsUnderPreparation.Visible = false;
            this.chartTenderDocsUnderPreparation.Click += new System.EventHandler(this.chartTenderDocsUnderPreparation_Click);
            this.chartTenderDocsUnderPreparation.DoubleClick += new System.EventHandler(this.chartTenderDocsUnderPreparation_DoubleClick);
            // 
            // chartTendersPerYearPerCommittee
            // 
            this.chartTendersPerYearPerCommittee.BorderlineColor = System.Drawing.Color.Blue;
            chartArea4.BackColor = System.Drawing.Color.White;
            chartArea4.Name = "ChartArea1";
            this.chartTendersPerYearPerCommittee.ChartAreas.Add(chartArea4);
            legend4.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top;
            legend4.Name = "Legend1";
            this.chartTendersPerYearPerCommittee.Legends.Add(legend4);
            this.chartTendersPerYearPerCommittee.Location = new System.Drawing.Point(59, 384);
            this.chartTendersPerYearPerCommittee.Name = "chartTendersPerYearPerCommittee";
            this.chartTendersPerYearPerCommittee.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Grayscale;
            series4.ChartArea = "ChartArea1";
            series4.IsValueShownAsLabel = true;
            series4.IsVisibleInLegend = false;
            series4.Legend = "Legend1";
            series4.Name = "Tender Count";
            series4.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Pastel;
            this.chartTendersPerYearPerCommittee.Series.Add(series4);
            this.chartTendersPerYearPerCommittee.Size = new System.Drawing.Size(742, 249);
            this.chartTendersPerYearPerCommittee.TabIndex = 11;
            this.chartTendersPerYearPerCommittee.Text = "Tender Count";
            this.chartTendersPerYearPerCommittee.TextAntiAliasingQuality = System.Windows.Forms.DataVisualization.Charting.TextAntiAliasingQuality.Normal;
            title3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            title3.Name = "Title1";
            title3.Text = "NUMBER OF TENDERS EACH YEAR";
            this.chartTendersPerYearPerCommittee.Titles.Add(title3);
            // 
            // btnRefreshTotalProjectsPerTenderStatus
            // 
            this.btnRefreshTotalProjectsPerTenderStatus.BackgroundImage = global::MDI_ParenrForm.Properties.Resources.Refresh;
            this.btnRefreshTotalProjectsPerTenderStatus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnRefreshTotalProjectsPerTenderStatus.Location = new System.Drawing.Point(438, 20);
            this.btnRefreshTotalProjectsPerTenderStatus.Name = "btnRefreshTotalProjectsPerTenderStatus";
            this.btnRefreshTotalProjectsPerTenderStatus.Size = new System.Drawing.Size(26, 24);
            this.btnRefreshTotalProjectsPerTenderStatus.TabIndex = 10;
            this.btnRefreshTotalProjectsPerTenderStatus.UseVisualStyleBackColor = true;
            this.btnRefreshTotalProjectsPerTenderStatus.Click += new System.EventHandler(this.btnRefreshTotalProjectsPerTenderStatus_Click);
            // 
            // cmbCommitteNames
            // 
            this.cmbCommitteNames.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCommitteNames.FormattingEnabled = true;
            this.cmbCommitteNames.Location = new System.Drawing.Point(191, 21);
            this.cmbCommitteNames.Name = "cmbCommitteNames";
            this.cmbCommitteNames.Size = new System.Drawing.Size(241, 23);
            this.cmbCommitteNames.TabIndex = 7;
            this.cmbCommitteNames.SelectionChangeCommitted += new System.EventHandler(this.cmbCommitteNames_SelectionChangeCommitted);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(53, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(132, 15);
            this.label2.TabIndex = 9;
            this.label2.Text = "Tender Committees";
            // 
            // ChartProjects
            // 
            this.ChartProjects.BorderlineColor = System.Drawing.Color.Blue;
            chartArea5.BackColor = System.Drawing.Color.White;
            chartArea5.Name = "ChartArea1";
            this.ChartProjects.ChartAreas.Add(chartArea5);
            legend5.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top;
            legend5.Name = "Legend1";
            this.ChartProjects.Legends.Add(legend5);
            this.ChartProjects.Location = new System.Drawing.Point(33, 59);
            this.ChartProjects.Name = "ChartProjects";
            this.ChartProjects.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Grayscale;
            series5.ChartArea = "ChartArea1";
            series5.CustomProperties = "DrawingStyle=Cylinder, MaxPixelPointWidth=30";
            series5.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold);
            series5.IsValueShownAsLabel = true;
            series5.IsVisibleInLegend = false;
            series5.IsXValueIndexed = true;
            series5.LabelAngle = -90;
            series5.Legend = "Legend1";
            series5.MarkerBorderWidth = 3;
            series5.MarkerSize = 10;
            series5.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series5.Name = "Tender Status";
            series5.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Excel;
            series5.XValueMember = "0";
            this.ChartProjects.Series.Add(series5);
            this.ChartProjects.Size = new System.Drawing.Size(979, 255);
            this.ChartProjects.TabIndex = 4;
            this.ChartProjects.Text = "Tender Status";
            this.ChartProjects.TextAntiAliasingQuality = System.Windows.Forms.DataVisualization.Charting.TextAntiAliasingQuality.Normal;
            title4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            title4.Name = "Title1";
            title4.Text = "TOTAL PROJECTS PER TENDER STATUS";
            this.ChartProjects.Titles.Add(title4);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Maroon;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button4.ForeColor = System.Drawing.Color.Maroon;
            this.button4.Location = new System.Drawing.Point(26, 251);
            this.button4.Margin = new System.Windows.Forms.Padding(0);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(24, 24);
            this.button4.TabIndex = 16;
            this.button4.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Maroon;
            this.label3.Location = new System.Drawing.Point(29, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(184, 25);
            this.label3.TabIndex = 0;
            this.label3.Text = "Main Switchboard";
            // 
            // splitContainer2
            // 
            this.splitContainer2.BackColor = System.Drawing.Color.White;
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Left;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.BackColor = System.Drawing.Color.White;
            this.splitContainer2.Panel1.Controls.Add(this.label3);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.BackColor = System.Drawing.Color.White;
            this.splitContainer2.Panel2.Controls.Add(this.linkShowMoreCharts);
            this.splitContainer2.Panel2.Controls.Add(this.button7);
            this.splitContainer2.Panel2.Controls.Add(this.label4);
            this.splitContainer2.Panel2.Controls.Add(this.button6);
            this.splitContainer2.Panel2.Controls.Add(this.button5);
            this.splitContainer2.Panel2.Controls.Add(this.button4);
            this.splitContainer2.Panel2.Controls.Add(this.button3);
            this.splitContainer2.Panel2.Controls.Add(this.button2);
            this.splitContainer2.Panel2.Controls.Add(this.button1);
            this.splitContainer2.Panel2.Controls.Add(this.lnkOngoingProjects);
            this.splitContainer2.Panel2.Controls.Add(this.lnkInactive);
            this.splitContainer2.Panel2.Controls.Add(this.lnkViewProjects);
            this.splitContainer2.Panel2.Controls.Add(this.lnkContacts);
            this.splitContainer2.Panel2.Controls.Add(this.lnkCompany);
            this.splitContainer2.Panel2.Controls.Add(this.lnkAddProject);
            this.splitContainer2.Size = new System.Drawing.Size(270, 965);
            this.splitContainer2.SplitterDistance = 61;
            this.splitContainer2.SplitterWidth = 2;
            this.splitContainer2.TabIndex = 18;
            // 
            // linkShowMoreCharts
            // 
            this.linkShowMoreCharts.ActiveLinkColor = System.Drawing.Color.DarkSlateBlue;
            this.linkShowMoreCharts.AutoSize = true;
            this.linkShowMoreCharts.BackColor = System.Drawing.Color.White;
            this.linkShowMoreCharts.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkShowMoreCharts.ForeColor = System.Drawing.Color.DarkGray;
            this.linkShowMoreCharts.LinkBehavior = System.Windows.Forms.LinkBehavior.AlwaysUnderline;
            this.linkShowMoreCharts.LinkColor = System.Drawing.Color.Blue;
            this.linkShowMoreCharts.Location = new System.Drawing.Point(56, 297);
            this.linkShowMoreCharts.Name = "linkShowMoreCharts";
            this.linkShowMoreCharts.Padding = new System.Windows.Forms.Padding(3);
            this.linkShowMoreCharts.Size = new System.Drawing.Size(139, 24);
            this.linkShowMoreCharts.TabIndex = 21;
            this.linkShowMoreCharts.TabStop = true;
            this.linkShowMoreCharts.Text = "Show More Charts";
            this.linkShowMoreCharts.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.linkShowMoreCharts.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkShowMoreCharts_LinkClicked);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Maroon;
            this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button7.ForeColor = System.Drawing.Color.Maroon;
            this.button7.Location = new System.Drawing.Point(26, 297);
            this.button7.Margin = new System.Windows.Forms.Padding(0);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(24, 24);
            this.button7.TabIndex = 20;
            this.button7.UseVisualStyleBackColor = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Fuchsia;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(81, 376);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 18);
            this.label4.TabIndex = 19;
            this.label4.Text = "label4";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Maroon;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button3.ForeColor = System.Drawing.Color.Maroon;
            this.button3.Location = new System.Drawing.Point(26, 114);
            this.button3.Margin = new System.Windows.Forms.Padding(0);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(24, 24);
            this.button3.TabIndex = 15;
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Maroon;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button2.ForeColor = System.Drawing.Color.Maroon;
            this.button2.Location = new System.Drawing.Point(26, 70);
            this.button2.Margin = new System.Windows.Forms.Padding(0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(24, 24);
            this.button2.TabIndex = 14;
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Maroon;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button1.ForeColor = System.Drawing.Color.Maroon;
            this.button1.Location = new System.Drawing.Point(26, 24);
            this.button1.Margin = new System.Windows.Forms.Padding(0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(24, 24);
            this.button1.TabIndex = 13;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // lnkOngoingProjects
            // 
            this.lnkOngoingProjects.ActiveLinkColor = System.Drawing.Color.DarkSlateBlue;
            this.lnkOngoingProjects.AutoSize = true;
            this.lnkOngoingProjects.BackColor = System.Drawing.Color.White;
            this.lnkOngoingProjects.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkOngoingProjects.ForeColor = System.Drawing.Color.DarkGray;
            this.lnkOngoingProjects.LinkBehavior = System.Windows.Forms.LinkBehavior.AlwaysUnderline;
            this.lnkOngoingProjects.LinkColor = System.Drawing.Color.Blue;
            this.lnkOngoingProjects.Location = new System.Drawing.Point(50, 160);
            this.lnkOngoingProjects.Name = "lnkOngoingProjects";
            this.lnkOngoingProjects.Padding = new System.Windows.Forms.Padding(3);
            this.lnkOngoingProjects.Size = new System.Drawing.Size(183, 24);
            this.lnkOngoingProjects.TabIndex = 12;
            this.lnkOngoingProjects.TabStop = true;
            this.lnkOngoingProjects.Text = "View All Ongoing Projects";
            this.lnkOngoingProjects.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lnkOngoingProjects.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkOngoingProjects_LinkClicked);
            this.lnkOngoingProjects.MouseLeave += new System.EventHandler(this.lnkOngoingProjects_MouseLeave);
            this.lnkOngoingProjects.MouseHover += new System.EventHandler(this.lnkOngoingProjects_MouseHover);
            // 
            // lnkInactive
            // 
            this.lnkInactive.ActiveLinkColor = System.Drawing.Color.DarkSlateBlue;
            this.lnkInactive.AutoSize = true;
            this.lnkInactive.BackColor = System.Drawing.Color.White;
            this.lnkInactive.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkInactive.ForeColor = System.Drawing.Color.DarkGray;
            this.lnkInactive.LinkBehavior = System.Windows.Forms.LinkBehavior.AlwaysUnderline;
            this.lnkInactive.LinkColor = System.Drawing.Color.Blue;
            this.lnkInactive.Location = new System.Drawing.Point(50, 206);
            this.lnkInactive.Name = "lnkInactive";
            this.lnkInactive.Padding = new System.Windows.Forms.Padding(3);
            this.lnkInactive.Size = new System.Drawing.Size(176, 24);
            this.lnkInactive.TabIndex = 11;
            this.lnkInactive.TabStop = true;
            this.lnkInactive.Text = "View All Inactive Projects";
            this.lnkInactive.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lnkInactive.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkInactive_LinkClicked);
            this.lnkInactive.MouseLeave += new System.EventHandler(this.lnkInactive_MouseLeave);
            this.lnkInactive.MouseHover += new System.EventHandler(this.lnkInactive_MouseHover);
            // 
            // lnkViewProjects
            // 
            this.lnkViewProjects.ActiveLinkColor = System.Drawing.Color.DarkSlateBlue;
            this.lnkViewProjects.AutoSize = true;
            this.lnkViewProjects.BackColor = System.Drawing.Color.White;
            this.lnkViewProjects.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkViewProjects.ForeColor = System.Drawing.Color.DarkGray;
            this.lnkViewProjects.LinkBehavior = System.Windows.Forms.LinkBehavior.AlwaysUnderline;
            this.lnkViewProjects.LinkColor = System.Drawing.Color.Blue;
            this.lnkViewProjects.Location = new System.Drawing.Point(56, 251);
            this.lnkViewProjects.Name = "lnkViewProjects";
            this.lnkViewProjects.Padding = new System.Windows.Forms.Padding(3);
            this.lnkViewProjects.Size = new System.Drawing.Size(123, 24);
            this.lnkViewProjects.TabIndex = 10;
            this.lnkViewProjects.TabStop = true;
            this.lnkViewProjects.Text = "View All Projects";
            this.lnkViewProjects.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lnkViewProjects.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkViewProjects_LinkClicked);
            this.lnkViewProjects.MouseLeave += new System.EventHandler(this.lnkViewProjects_MouseLeave);
            this.lnkViewProjects.MouseHover += new System.EventHandler(this.lnkViewProjects_MouseHover);
            // 
            // lnkContacts
            // 
            this.lnkContacts.ActiveLinkColor = System.Drawing.Color.DarkSlateBlue;
            this.lnkContacts.AutoSize = true;
            this.lnkContacts.BackColor = System.Drawing.Color.White;
            this.lnkContacts.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkContacts.ForeColor = System.Drawing.Color.DarkGray;
            this.lnkContacts.LinkBehavior = System.Windows.Forms.LinkBehavior.AlwaysUnderline;
            this.lnkContacts.LinkColor = System.Drawing.Color.Blue;
            this.lnkContacts.Location = new System.Drawing.Point(50, 114);
            this.lnkContacts.Name = "lnkContacts";
            this.lnkContacts.Padding = new System.Windows.Forms.Padding(3);
            this.lnkContacts.Size = new System.Drawing.Size(129, 24);
            this.lnkContacts.TabIndex = 9;
            this.lnkContacts.TabStop = true;
            this.lnkContacts.Text = "Add New Contact";
            this.lnkContacts.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lnkContacts.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkContacts_LinkClicked);
            this.lnkContacts.MouseLeave += new System.EventHandler(this.lnkContacts_MouseLeave);
            this.lnkContacts.MouseHover += new System.EventHandler(this.lnkContacts_MouseHover);
            // 
            // lnkCompany
            // 
            this.lnkCompany.ActiveLinkColor = System.Drawing.Color.DarkSlateBlue;
            this.lnkCompany.AutoSize = true;
            this.lnkCompany.BackColor = System.Drawing.Color.White;
            this.lnkCompany.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkCompany.ForeColor = System.Drawing.Color.DarkGray;
            this.lnkCompany.LinkBehavior = System.Windows.Forms.LinkBehavior.AlwaysUnderline;
            this.lnkCompany.LinkColor = System.Drawing.Color.Blue;
            this.lnkCompany.Location = new System.Drawing.Point(50, 70);
            this.lnkCompany.Name = "lnkCompany";
            this.lnkCompany.Padding = new System.Windows.Forms.Padding(3);
            this.lnkCompany.Size = new System.Drawing.Size(141, 24);
            this.lnkCompany.TabIndex = 8;
            this.lnkCompany.TabStop = true;
            this.lnkCompany.Text = "Add New Company";
            this.lnkCompany.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lnkCompany.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkCompany_LinkClicked);
            this.lnkCompany.MouseLeave += new System.EventHandler(this.lnkCompany_MouseLeave);
            this.lnkCompany.MouseHover += new System.EventHandler(this.lnkCompany_MouseHover);
            // 
            // lnkAddProject
            // 
            this.lnkAddProject.ActiveLinkColor = System.Drawing.Color.DarkSlateBlue;
            this.lnkAddProject.AutoSize = true;
            this.lnkAddProject.BackColor = System.Drawing.Color.White;
            this.lnkAddProject.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkAddProject.ForeColor = System.Drawing.Color.DarkGray;
            this.lnkAddProject.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lnkAddProject.LinkBehavior = System.Windows.Forms.LinkBehavior.AlwaysUnderline;
            this.lnkAddProject.LinkColor = System.Drawing.Color.Blue;
            this.lnkAddProject.Location = new System.Drawing.Point(50, 24);
            this.lnkAddProject.Name = "lnkAddProject";
            this.lnkAddProject.Padding = new System.Windows.Forms.Padding(3);
            this.lnkAddProject.Size = new System.Drawing.Size(124, 24);
            this.lnkAddProject.TabIndex = 7;
            this.lnkAddProject.TabStop = true;
            this.lnkAddProject.Text = "Add New Project";
            this.lnkAddProject.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lnkAddProject.VisitedLinkColor = System.Drawing.Color.Blue;
            this.lnkAddProject.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkAddProject_LinkClicked);
            this.lnkAddProject.MouseLeave += new System.EventHandler(this.lnkAddProject_MouseLeave);
            this.lnkAddProject.MouseHover += new System.EventHandler(this.lnkAddProject_MouseHover);
            // 
            // panelForDashboard
            // 
            this.panelForDashboard.AutoScroll = true;
            this.panelForDashboard.BackColor = System.Drawing.Color.White;
            this.panelForDashboard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelForDashboard.Controls.Add(this.splitContainer2);
            this.panelForDashboard.Controls.Add(this.splitContainer3);
            this.panelForDashboard.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelForDashboard.Location = new System.Drawing.Point(0, 87);
            this.panelForDashboard.Name = "panelForDashboard";
            this.panelForDashboard.Size = new System.Drawing.Size(1570, 967);
            this.panelForDashboard.TabIndex = 29;
            // 
            // lblUserName
            // 
            this.lblUserName.AutoSize = true;
            this.lblUserName.BackColor = System.Drawing.Color.LightSlateGray;
            this.lblUserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserName.ForeColor = System.Drawing.Color.White;
            this.lblUserName.Location = new System.Drawing.Point(-1, 2);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(29, 13);
            this.lblUserName.TabIndex = 7;
            this.lblUserName.Text = "User";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.Location = new System.Drawing.Point(103, 3);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(42, 13);
            this.linkLabel1.TabIndex = 30;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "logout";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // groupBox1
            // 
            this.groupBox1.AutoSize = true;
            this.groupBox1.BackColor = System.Drawing.Color.LightSlateGray;
            this.groupBox1.Cursor = System.Windows.Forms.Cursors.Default;
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.LightSlateGray;
            this.groupBox1.Location = new System.Drawing.Point(1570, 0);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox1.Size = new System.Drawing.Size(0, 44);
            this.groupBox1.TabIndex = 31;
            this.groupBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.lblUserName);
            this.panel1.Controls.Add(this.linkLabel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(1425, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(145, 44);
            this.panel1.TabIndex = 19;
            // 
            // splitContainer1
            // 
            this.splitContainer1.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Top;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.Color.LightSlateGray;
            this.splitContainer1.Panel1.Controls.Add(this.panel1);
            this.splitContainer1.Panel1.Controls.Add(this.groupBox1);
            this.splitContainer1.Panel1.Controls.Add(this.btnAdmin);
            this.splitContainer1.Panel1.Controls.Add(this.btnReports);
            this.splitContainer1.Panel1.Controls.Add(this.btnDashboard);
            this.splitContainer1.Panel1.Controls.Add(this.btnProjects);
            this.splitContainer1.Panel1.Controls.Add(this.btnContacts);
            this.splitContainer1.Panel1.Controls.Add(this.btnDocuments);
            this.splitContainer1.Panel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.BackColor = System.Drawing.Color.Maroon;
            this.splitContainer1.Size = new System.Drawing.Size(1570, 87);
            this.splitContainer1.SplitterDistance = 44;
            this.splitContainer1.SplitterWidth = 1;
            this.splitContainer1.TabIndex = 28;
            // 
            // btnAdmin
            // 
            this.btnAdmin.BackColor = System.Drawing.Color.LightSlateGray;
            this.btnAdmin.FlatAppearance.BorderColor = System.Drawing.Color.LightSlateGray;
            this.btnAdmin.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnAdmin.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SaddleBrown;
            this.btnAdmin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdmin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnAdmin.ForeColor = System.Drawing.Color.Black;
            this.btnAdmin.Location = new System.Drawing.Point(737, 0);
            this.btnAdmin.Name = "btnAdmin";
            this.btnAdmin.Size = new System.Drawing.Size(148, 46);
            this.btnAdmin.TabIndex = 6;
            this.btnAdmin.Text = "Admin";
            this.btnAdmin.UseVisualStyleBackColor = false;
            this.btnAdmin.Click += new System.EventHandler(this.btnAdmin_Click);
            // 
            // btnReports
            // 
            this.btnReports.BackColor = System.Drawing.Color.LightSlateGray;
            this.btnReports.FlatAppearance.BorderColor = System.Drawing.Color.LightSlateGray;
            this.btnReports.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnReports.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SaddleBrown;
            this.btnReports.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReports.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnReports.ForeColor = System.Drawing.Color.Black;
            this.btnReports.Location = new System.Drawing.Point(589, 0);
            this.btnReports.Name = "btnReports";
            this.btnReports.Size = new System.Drawing.Size(148, 46);
            this.btnReports.TabIndex = 5;
            this.btnReports.Text = "Reports";
            this.btnReports.UseVisualStyleBackColor = false;
            this.btnReports.Click += new System.EventHandler(this.btnReports_Click);
            // 
            // btnDashboard
            // 
            this.btnDashboard.BackColor = System.Drawing.Color.LightSlateGray;
            this.btnDashboard.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnDashboard.FlatAppearance.BorderColor = System.Drawing.Color.LightSlateGray;
            this.btnDashboard.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnDashboard.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SaddleBrown;
            this.btnDashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDashboard.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnDashboard.ForeColor = System.Drawing.Color.Black;
            this.btnDashboard.Location = new System.Drawing.Point(0, 0);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Size = new System.Drawing.Size(148, 44);
            this.btnDashboard.TabIndex = 1;
            this.btnDashboard.Text = "Dashboard";
            this.btnDashboard.UseVisualStyleBackColor = false;
            this.btnDashboard.Click += new System.EventHandler(this.btnDashboard_Click);
            // 
            // btnProjects
            // 
            this.btnProjects.BackColor = System.Drawing.Color.LightSlateGray;
            this.btnProjects.FlatAppearance.BorderColor = System.Drawing.Color.LightSlateGray;
            this.btnProjects.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SaddleBrown;
            this.btnProjects.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProjects.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnProjects.ForeColor = System.Drawing.Color.Black;
            this.btnProjects.Location = new System.Drawing.Point(145, 0);
            this.btnProjects.Name = "btnProjects";
            this.btnProjects.Size = new System.Drawing.Size(148, 46);
            this.btnProjects.TabIndex = 2;
            this.btnProjects.Text = "All Projects";
            this.btnProjects.UseVisualStyleBackColor = false;
            this.btnProjects.Click += new System.EventHandler(this.btnProjects_Click);
            // 
            // btnContacts
            // 
            this.btnContacts.BackColor = System.Drawing.Color.LightSlateGray;
            this.btnContacts.FlatAppearance.BorderColor = System.Drawing.Color.LightSlateGray;
            this.btnContacts.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnContacts.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SaddleBrown;
            this.btnContacts.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnContacts.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnContacts.ForeColor = System.Drawing.Color.Black;
            this.btnContacts.Location = new System.Drawing.Point(441, 0);
            this.btnContacts.Name = "btnContacts";
            this.btnContacts.Size = new System.Drawing.Size(148, 46);
            this.btnContacts.TabIndex = 4;
            this.btnContacts.Text = "Contacts";
            this.btnContacts.UseVisualStyleBackColor = false;
            this.btnContacts.Click += new System.EventHandler(this.btnContacts_Click);
            // 
            // btnDocuments
            // 
            this.btnDocuments.BackColor = System.Drawing.Color.LightSlateGray;
            this.btnDocuments.FlatAppearance.BorderColor = System.Drawing.Color.LightSlateGray;
            this.btnDocuments.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnDocuments.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SaddleBrown;
            this.btnDocuments.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDocuments.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnDocuments.ForeColor = System.Drawing.Color.Black;
            this.btnDocuments.Location = new System.Drawing.Point(293, 0);
            this.btnDocuments.Name = "btnDocuments";
            this.btnDocuments.Size = new System.Drawing.Size(148, 46);
            this.btnDocuments.TabIndex = 3;
            this.btnDocuments.Text = "Documents";
            this.btnDocuments.UseVisualStyleBackColor = false;
            this.btnDocuments.Click += new System.EventHandler(this.btnDocuments_Click);
            // 
            // aFFAIRSBindingSource
            // 
            this.aFFAIRSBindingSource.DataMember = "AFFAIRS";
            // 
            // dashBoardParent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(236)))), ((int)(((byte)(236)))));
            this.ClientSize = new System.Drawing.Size(1570, 1054);
            this.Controls.Add(this.panelForDashboard);
            this.Controls.Add(this.splitContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "dashBoardParent";
            this.Text = "Tender  & Contract Management System *** V 2.5.7";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.dashBoardParent_FormClosing);
            this.Load += new System.EventHandler(this.dashBoardParent_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.dashBoardParent_Paint);
            this.Leave += new System.EventHandler(this.dashBoardParent_Leave);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            this.splitContainer3.Panel2.ResumeLayout(false);
            this.splitContainer3.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ChartPrepDocsApproved)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartTotalAmountOfContractsPerCommittee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartTenderDocsUnderPreparation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartTendersPerYearPerCommittee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ChartProjects)).EndInit();
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.panelForDashboard.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.aFFAIRSBindingSource)).EndInit();
            this.ResumeLayout(false);

        }
        #endregion

        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.BindingSource aFFAIRSBindingSource;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.DataVisualization.Charting.Chart ChartPrepDocsApproved;
        private System.Windows.Forms.ComboBox cmbFinancialYears;
        private System.Windows.Forms.Label lblFinancialYear;
        private System.Windows.Forms.Button btnRefreshTotalProjectsPerTenderStatus;
        private System.Windows.Forms.ComboBox cmbCommitteNames;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataVisualization.Charting.Chart ChartProjects;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.LinkLabel lnkOngoingProjects;
        private System.Windows.Forms.LinkLabel lnkInactive;
        private System.Windows.Forms.LinkLabel lnkViewProjects;
        private System.Windows.Forms.LinkLabel lnkContacts;
        private System.Windows.Forms.LinkLabel lnkCompany;
        private System.Windows.Forms.LinkLabel lnkAddProject;
        private System.Windows.Forms.Panel panelForDashboard;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.GroupBox groupBox1;         
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button btnAdmin;
        private System.Windows.Forms.Button btnReports;
        private System.Windows.Forms.Button btnDashboard;
        private System.Windows.Forms.Button btnProjects;
        private System.Windows.Forms.Button btnContacts;
        private System.Windows.Forms.Button btnDocuments;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartTendersPerYearPerCommittee;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartTenderDocsUnderPreparation;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartTotalAmountOfContractsPerCommittee;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbFYForNumberOfTenders;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbCmteNamesForNumberOfTenders;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbCmteNamesForTotalContractAmounts;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnRefreshTenderDocsApproved;
        private System.Windows.Forms.Button btnRefreshNumberOfTenderEachYear;
        private System.Windows.Forms.LinkLabel linkShowMoreCharts;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button btnRefreshTotValTenderAwardsPerCommt;
        private System.Windows.Forms.ComboBox cmbFYTotValTenderAwardsPerCommt;
        private System.Windows.Forms.Label lblFYTotValTenderAwardsPerCommt;
    }
}



