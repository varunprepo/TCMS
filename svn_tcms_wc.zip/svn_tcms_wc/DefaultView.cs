﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.IO;
using System.Xml;
using System.Transactions; 
using DataGridViewAutoFilter;
using MDI_ParenrForm;
using MDI_ParenrForm.Projects;


namespace TenderTrackingSystem
{
    public partial class DefaultView : Form
    {         
        string _userName = null;
        private string strCon = ConfigurationSettings.AppSettings["TCMSConnString"].ToString();
        
        // Protected Connection.
        protected SqlConnection sqlConn;
        protected SqlCommand sqlCom;                  

        protected SqlDataReader sqlReader;
        private System.Windows.Forms.Label label1;
        //decimal bdgtEstimated = 0;
        CreateCheckBox chkBox = null;
        CheckBox headerCheckBox = null;
        BindingSource myBindingSource = null;
        DataTable dtTemp = null;
        DataTable dtTempForCombo = null;


        DAL dataCls = new DAL();
        IList<string> userRightsColl = new List<string>();
        bool _isHeadOfSection = false;
        string mTypeOfTab = null;
        public DefaultView(IList<string> userRightsCollDefault, string userName, bool isHeadOfSection,string typeOfTab)
        {
            InitializeComponent();
            _userName = userName;  
            userRightsColl = getUserAccessList();
            _isHeadOfSection = isHeadOfSection;
            mTypeOfTab = typeOfTab;
        }
        private IList<string> getUserAccessList()
        {
            userRightsColl.Clear();
            SqlConnection sqlConn = new SqlConnection(strCon);

            string sqlQuery = "SELECT  UserAccessRights.AccessID,UserAccessRights.[AccessRights], UserPrivelege.HasPrivelege, UserPrivelege.user_profile_id, UserSecurityProfile.profile_name, USERS.user_id, " +
            " USERS.user_name FROM UserAccessRights INNER JOIN UserPrivelege ON UserAccessRights.AccessID = UserPrivelege.AccessID INNER JOIN " +
            " UserSecurityProfile ON UserPrivelege.user_profile_id = UserSecurityProfile.user_profile_id INNER JOIN " +
            " USERS ON UserSecurityProfile.user_profile_id = USERS.user_profile_id WHERE (UserPrivelege.HasPrivelege = 0) AND (USERS.user_name = '" + _userName + "') ORDER BY UserAccessRights.AccessID";

            try
            {
                sqlConn.Open();
                SqlCommand sqlCom = new SqlCommand(sqlQuery, sqlConn);
                SqlDataReader sqlReader = sqlCom.ExecuteReader();
                while (sqlReader.Read())
                {
                    userRightsColl.Add(sqlReader[0].ToString());
                }
                sqlReader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error getting while reading data !" + ex.Message);
            }
            finally
            {
                sqlConn.Close();
            }
            return userRightsColl;
        }
        private void FillAllProjectsInformation(char chkInfo, string committesList)
        {            
            if (chkInfo == 'R')
            {
                txtPrjTitle.Text = "";
                cmbPrjCode.Text = "";
                cmbTenderNo.Text = "";

                cmbPrjCode.SelectedIndex = -1;
                cmbTenderNo.SelectedIndex = -1;
                cmbCurrentStage.SelectedIndex = -1;
                cmbTenderStatus.SelectedIndex = -1;
                cmbTypeOftender.SelectedIndex = -1;
                cmbtenderCommitte.SelectedIndex = -1;
                cmbTypeofContract.SelectedIndex = -1;
                cmbFiscalYear.SelectedIndex = -1;
                cmbUserDepart.SelectedIndex = -1;
            }

            if (dgView.ColumnCount == 0)
            {
                headerCheckBox = new CheckBox();
                chkBox = new CreateCheckBox(dgView, headerCheckBox);
                chkBox.AddHeaderCheckBox();

                this.dgView.CellContentClick += new DataGridViewCellEventHandler(dgView_CellContentClick);

                var col0 = new DataGridViewCheckBoxColumn();
                var col1 = new DataGridViewTextBoxColumn();
                var col2 = new DataGridViewLinkColumn();

                var col3 = new DataGridViewTextBoxColumn();
                var col4 = new DataGridViewTextBoxColumn();
                var col5 = new DataGridViewTextBoxColumn();
                var col6 = new DataGridViewTextBoxColumn();
                var col7 = new DataGridViewTextBoxColumn();
                var col8 = new DataGridViewTextBoxColumn();
                var col9 = new DataGridViewTextBoxColumn();
                var col10 = new DataGridViewTextBoxColumn();
                var col11 = new DataGridViewTextBoxColumn();
                var col12 = new DataGridViewTextBoxColumn();

                if (mTypeOfTab != "Archives" && mTypeOfTab != "Deleted Projects")
                {
                    dgView.Columns.AddRange(new DataGridViewColumn[] { col0, col1, col2, col3, col4, col12, col5, col6, col7, col8, col9, col10, col11 });
                }
                else
                    dgView.Columns.AddRange(new DataGridViewColumn[] { col0, col1, col2, col3, col4, col5, col6, col7, col8, col9, col10, col11 });

                dgView.AutoGenerateColumns = false;
                dgView.AllowUserToAddRows = false;
                dgView.AutoResizeColumns();

                col0.Name = "chkBxSelect1";
                col0.DataPropertyName = "Select";
                col0.HeaderText = "";
                col0.Width = 45;

                col1.DataPropertyName = "ProjectId";
                col1.HeaderText = "ProjectId";

                col2.DataPropertyName = "ProjectCode";
                col2.HeaderText = "Project Code";
                col2.Width = 145; //182 
                col2.LinkBehavior = LinkBehavior.NeverUnderline;

                col3.DataPropertyName = "ProjectTitle";
                col3.HeaderText = "ProjectTitle";
                col3.Width = 150; //182


                col4.DataPropertyName = "TenderNo";
                col4.HeaderText = "      TenderNo ";
                col4.Width = 141; //182
                if (mTypeOfTab != "Archives")
                {
                    col12.DataPropertyName = "ClosingDate";
                    col12.HeaderText = "Closing Date";
                    col12.Width = 85; //182
                }

                col5.DataPropertyName = "CurrentStage";
                col5.HeaderText = "Current Stage";
                col5.Width = 85; //182

                col6.DataPropertyName = "TenderStatus";
                col6.HeaderText = "Tender Status";
                col6.Width = 86;

                col7.DataPropertyName = "TypeOfTender";
                col7.HeaderText = "Tender Type";
                col7.Width = 76;

                col8.DataPropertyName = "TenderCommittee";
                col8.HeaderText = "Tender Committee";
                col8.Width = 70;


                col9.DataPropertyName = "TypeofContract";
                col9.HeaderText = "Contract Type";
                col9.Width = 80;

                col10.DataPropertyName = "FiscalYear";
                col10.HeaderText = "Fiscal Year";
                col10.Width = 56;

                col11.DataPropertyName = "UserDepartment";
                col11.HeaderText = "User Department";
                //col11.Resizable = System.Windows.Forms.DataGridViewTriState.True;                 
                col11.Width = 56;
            }
            else
            {
                dgView.DataSource = null;
                dgView.Refresh();
            }
            DataTable dtProject = null;

            string[] projRows = new string[8]; 

            try
            {
                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();

                DAL dalObj = new DAL(); //Dharan

                string sqlQuery = string.Empty;

                if (mTypeOfTab != "Archives" && mTypeOfTab != "Deleted Projects")
                {
                    string currentDate = System.DateTime.Now.Date.ToString();

                    if (filterQuery == "" && mTypeOfTab == "Current Day Closing Tenders")
                    {
                        sqlQuery = "SELECT  PROJECTS.proj_id, PROJECTS.project_code, PROJECTS.project_newname_en, PROJECTS.tender_no, REPLACE(CONVERT(nvarchar, TenderDatesInfo.ts_closing_s1,106),' ','-') as ts_closing_s1, REPLACE(CONVERT(nvarchar, TenderDatesInfo.ts_modified_closing,106),' ','-') as ts_modified_closing, STAGES.Stage_Name, TenderStatus.Status_Name, " +
                        "TenderTypes.tender_type_name, Committee.committee_short_name, " +
                        " ContractTypes.TypeofContract, FiscalYear.FiscalYear, d2.Department, TenderDatesInfo.ts_tender_issue FROM TenderStatus RIGHT OUTER JOIN   STAGES INNER JOIN TenderTypes INNER JOIN " +
                        " ContractTypes INNER JOIN  FiscalYear INNER JOIN  Committee RIGHT OUTER JOIN  AFFAIRS2 INNER JOIN PROJECTS ON AFFAIRS2.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON FiscalYear.FYID = PROJECTS.FYID ON " +
                        " ContractTypes.contract_type_id = PROJECTS.contract_type_id ON TenderTypes.tender_type_id = PROJECTS.tender_type_id INNER JOIN Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id ON STAGES.stage_id = PROJECTS.stage_id ON " +
                        " TenderStatus.Tender_Status_id = PROJECTS.Tender_Status_id INNER JOIN  TenderDatesInfo ON TenderDatesInfo.proj_id = PROJECTS.proj_id WHERE (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.ts_tender_issue IS NULL) AND (coalesce(CAST(TenderDatesInfo.ts_modified_closing AS Date),CAST(TenderDatesInfo.ts_closing_s1 AS Date)) " +
                        "= CAST('" + currentDate.Split(' ')[0] + "' AS Date)) AND (PROJECTS.isDeleted=0 ) and PROJECTS.Tender_Status_id<>10 AND (TenderDatesInfo.ts_closing_s1 IS NOT NULL) " +
                        "ORDER BY coalesce(CAST(TenderDatesInfo.ts_modified_closing AS Date), CAST(TenderDatesInfo.ts_closing_s1 AS Date))";
                    }
                    else if (filterQuery != "" && mTypeOfTab == "Current Day Closing Tenders")
                    {
                        sqlQuery = "SELECT  PROJECTS.proj_id, PROJECTS.project_code, PROJECTS.project_newname_en, PROJECTS.tender_no, REPLACE(CONVERT(nvarchar, TenderDatesInfo.ts_closing_s1,106),' ','-') as ts_closing_s1, REPLACE(CONVERT(nvarchar, TenderDatesInfo.ts_modified_closing,106),' ','-') as ts_modified_closing, STAGES.Stage_Name, TenderStatus.Status_Name, " +
                       " TenderTypes.tender_type_name, Committee.committee_short_name, ContractTypes.TypeofContract, FiscalYear.FiscalYear, d2.Department, TenderDatesInfo.ts_tender_issue FROM TenderStatus RIGHT OUTER JOIN STAGES INNER JOIN TenderTypes INNER JOIN " +
                       " ContractTypes INNER JOIN  FiscalYear INNER JOIN  Committee RIGHT OUTER JOIN AFFAIRS2 INNER JOIN PROJECTS ON AFFAIRS2.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON FiscalYear.FYID = PROJECTS.FYID ON " +
                       " ContractTypes.contract_type_id = PROJECTS.contract_type_id ON TenderTypes.tender_type_id = PROJECTS.tender_type_id INNER JOIN Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id ON STAGES.stage_id = PROJECTS.stage_id ON " +
                       " TenderStatus.Tender_Status_id = PROJECTS.Tender_Status_id INNER JOIN  TenderDatesInfo ON TenderDatesInfo.proj_id = PROJECTS.proj_id WHERE (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.ts_tender_issue IS NULL) AND (coalesce(CAST(TenderDatesInfo.ts_modified_closing AS Date),CAST(TenderDatesInfo.ts_closing_s1 AS Date)) " +
                       " = CAST('" + currentDate.Split(' ')[0] + "' AS Date)) AND (Committee.committee_short_name IN (" + committesList + ")) " +
                       "AND (PROJECTS.isDeleted=0 ) and PROJECTS.Tender_Status_id<>10 AND (TenderDatesInfo.ts_closing_s1 IS NOT NULL) ORDER BY coalesce(CAST(TenderDatesInfo.ts_modified_closing AS Date), CAST(TenderDatesInfo.ts_closing_s1 AS Date))";
                    }


                    if (filterQuery == "" && mTypeOfTab == "Running Tenders")
                    {
                        sqlQuery = "SELECT  PROJECTS.proj_id, PROJECTS.project_code, PROJECTS.project_newname_en, PROJECTS.tender_no, REPLACE(CONVERT(nvarchar,TenderDatesInfo.ts_closing_s1,106),' ','-') as ts_closing_s1, REPLACE(CONVERT(nvarchar,TenderDatesInfo.ts_modified_closing,106),' ','-') as ts_modified_closing, STAGES.Stage_Name, TenderStatus.Status_Name, TenderTypes.tender_type_name, " +
                        "Committee.committee_short_name, ContractTypes.TypeofContract, FiscalYear.FiscalYear, d2.Department, TenderDatesInfo.ts_tender_issue FROM TenderDatesInfo inner join PROJECTS ON TenderDatesInfo.proj_id = PROJECTS.proj_id join TenderStatus ON  TenderStatus.Tender_Status_id = PROJECTS.Tender_Status_id join STAGES ON STAGES.stage_id = PROJECTS.stage_id INNER JOIN TenderTypes ON " +
                        "TenderTypes.tender_type_id = PROJECTS.tender_type_id INNER JOIN  ContractTypes ON  ContractTypes.contract_type_id = PROJECTS.contract_type_id INNER JOIN  FiscalYear ON FiscalYear.FYID = PROJECTS.FYID INNER JOIN  Committee ON Committee.committee_id = PROJECTS.committee_id inner JOIN AFFAIRS2 on AFFAIRS2.Affair_id = PROJECTS.Affair_id INNER JOIN Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id " +
                        "WHERE (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.ts_tender_issue IS NULL) AND (ISNULL(CAST(TenderDatesInfo.ts_modified_closing AS Date), " +
                        "CAST(TenderDatesInfo.ts_closing_s1 AS Date)) >= CAST('" + currentDate.Split(' ')[0] + "' AS Date)) AND (PROJECTS.isDeleted=0 ) and PROJECTS.Tender_Status_id<>10 ORDER BY ISNULL(CAST(TenderDatesInfo.ts_modified_closing AS Date), CAST(TenderDatesInfo.ts_closing_s1 AS Date))"; //Tender_Status_id=10 Transferred To Other Committee
                    }
                    else if (filterQuery != "" && mTypeOfTab == "Running Tenders")
                    {
                       sqlQuery = "SELECT  PROJECTS.proj_id, PROJECTS.project_code, PROJECTS.project_newname_en, PROJECTS.tender_no, REPLACE(CONVERT(nvarchar,TenderDatesInfo.ts_closing_s1,106),' ','-') as ts_closing_s1, REPLACE(CONVERT(nvarchar,TenderDatesInfo.ts_modified_closing,106),' ','-') as ts_modified_closing, STAGES.Stage_Name, TenderStatus.Status_Name, TenderTypes.tender_type_name, Committee.committee_short_name, " +
                       " ContractTypes.TypeofContract, FiscalYear.FiscalYear, d2.Department, TenderDatesInfo.ts_tender_issue FROM TenderDatesInfo inner join PROJECTS ON TenderDatesInfo.proj_id = PROJECTS.proj_id join TenderStatus ON  TenderStatus.Tender_Status_id = PROJECTS.Tender_Status_id join STAGES ON STAGES.stage_id = PROJECTS.stage_id INNER JOIN TenderTypes ON TenderTypes.tender_type_id = PROJECTS.tender_type_id INNER JOIN " +
                       "ContractTypes ON  ContractTypes.contract_type_id = PROJECTS.contract_type_id INNER JOIN  FiscalYear ON FiscalYear.FYID = PROJECTS.FYID INNER JOIN Committee ON Committee.committee_id = PROJECTS.committee_id inner JOIN AFFAIRS2 on AFFAIRS2.Affair_id = PROJECTS.Affair_id INNER JOIN Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id WHERE (TenderDatesInfo.stage_id = 2) " +
                       "AND (TenderDatesInfo.ts_tender_issue IS NULL) AND (ISNULL(CAST(TenderDatesInfo.ts_modified_closing AS Date), CAST(TenderDatesInfo.ts_closing_s1 AS Date)) >= CAST('" + currentDate.Split(' ')[0] + "' AS Date)) AND (Committee.committee_short_name IN (" + committesList + ")) " +
                       "AND (PROJECTS.isDeleted=0 ) and PROJECTS.Tender_Status_id<>10 ORDER BY ISNULL(CAST(TenderDatesInfo.ts_modified_closing AS Date), CAST(TenderDatesInfo.ts_closing_s1 AS Date))"; //Tender_Status_id=10 Transferred To Other Committee
                    }
                    if (filterQuery == "" && mTypeOfTab == "One Month Back Closing Tenders")
                    {
                        sqlQuery = "SELECT  PROJECTS.proj_id, PROJECTS.project_code, PROJECTS.project_newname_en, PROJECTS.tender_no, REPLACE(CONVERT(nvarchar,TenderDatesInfo.ts_closing_s1,106),' ','-') as ts_closing_s1, REPLACE(CONVERT(nvarchar,TenderDatesInfo.ts_modified_closing,106),' ','-') as ts_modified_closing, STAGES.Stage_Name, TenderStatus.Status_Name, TenderTypes.tender_type_name, Committee.committee_short_name, " +
                        " ContractTypes.TypeofContract, FiscalYear.FiscalYear, d2.Department, TenderDatesInfo.ts_tender_issue FROM TenderStatus RIGHT OUTER JOIN   STAGES INNER JOIN TenderTypes INNER JOIN " +
                        " ContractTypes INNER JOIN  FiscalYear INNER JOIN  Committee RIGHT OUTER JOIN   AFFAIRS2 INNER JOIN PROJECTS ON AFFAIRS2.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON FiscalYear.FYID = PROJECTS.FYID ON " +
                        " ContractTypes.contract_type_id = PROJECTS.contract_type_id ON TenderTypes.tender_type_id = PROJECTS.tender_type_id INNER JOIN Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id ON STAGES.stage_id = PROJECTS.stage_id ON " +
                        " TenderStatus.Tender_Status_id = PROJECTS.Tender_Status_id INNER JOIN  TenderDatesInfo ON TenderDatesInfo.proj_id = PROJECTS.proj_id WHERE (TenderStatus.Tender_Status_id NOT IN (10)) AND (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.ts_tender_issue IS NULL) AND (ISNULL(CAST(TenderDatesInfo.ts_modified_closing AS Date), " +
                        "CAST(TenderDatesInfo.ts_closing_s1 AS Date)) <= CAST('" + currentDate.Split(' ')[0] + "' AS Date)) " +
                        " AND (ISNULL(CAST(TenderDatesInfo.ts_modified_closing AS Date), CAST(TenderDatesInfo.ts_closing_s1 AS Date)) >= CAST('" + Convert.ToDateTime(currentDate).AddDays(-30).ToString().Split(' ')[0] + "' As Date)) " +
                        "AND (PROJECTS.isDeleted=0) and PROJECTS.Tender_Status_id<>10 ORDER BY ISNULL(CAST(TenderDatesInfo.ts_modified_closing AS Date), CAST(TenderDatesInfo.ts_closing_s1 AS Date))";

                    }
                    else if (filterQuery != "" && mTypeOfTab == "One Month Back Closing Tenders")
                    {
                        sqlQuery = "SELECT  PROJECTS.proj_id, PROJECTS.project_code, PROJECTS.project_newname_en, PROJECTS.tender_no,REPLACE(CONVERT(nvarchar,TenderDatesInfo.ts_closing_s1,106),' ','-') as ts_closing_s1,REPLACE(CONVERT(nvarchar,TenderDatesInfo.ts_modified_closing,106),' ','-') as ts_modified_closing, STAGES.Stage_Name, TenderStatus.Status_Name, TenderTypes.tender_type_name, Committee.committee_short_name, " +
                       " ContractTypes.TypeofContract, FiscalYear.FiscalYear, d2.Department, TenderDatesInfo.ts_tender_issue FROM TenderStatus RIGHT OUTER JOIN   STAGES INNER JOIN TenderTypes INNER JOIN " +
                       " ContractTypes INNER JOIN  FiscalYear INNER JOIN  Committee RIGHT OUTER JOIN   AFFAIRS2 INNER JOIN PROJECTS ON AFFAIRS2.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON FiscalYear.FYID = PROJECTS.FYID ON " +
                       " ContractTypes.contract_type_id = PROJECTS.contract_type_id ON TenderTypes.tender_type_id = PROJECTS.tender_type_id INNER JOIN Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id ON STAGES.stage_id = PROJECTS.stage_id ON " +
                       " TenderStatus.Tender_Status_id = PROJECTS.Tender_Status_id INNER JOIN  TenderDatesInfo ON TenderDatesInfo.proj_id = PROJECTS.proj_id WHERE (TenderStatus.Tender_Status_id NOT IN (10)) AND (TenderDatesInfo.stage_id = 2) AND (TenderDatesInfo.ts_tender_issue IS NULL) AND " +
                       "(ISNULL(CAST(TenderDatesInfo.ts_modified_closing AS Date),CAST(TenderDatesInfo.ts_closing_s1 AS Date)) <= CAST('" + currentDate.Split(' ')[0] + "' AS Date)) AND " +
                       " (ISNULL(CAST(TenderDatesInfo.ts_modified_closing AS Date),CAST(TenderDatesInfo.ts_closing_s1 AS Date)) >= CAST('" + Convert.ToDateTime(currentDate).AddDays(-30).ToString().Split(' ')[0] + "' As Date)) AND (Committee.committee_short_name IN (" + committesList + ")) " +
                       "AND (PROJECTS.isDeleted=0) and PROJECTS.Tender_Status_id<>10 ORDER BY ISNULL(CAST(TenderDatesInfo.ts_modified_closing AS Date), CAST(TenderDatesInfo.ts_closing_s1 AS Date))";
                    }

                    groupBox1.Visible = false;
                    dtProject = dalObj.GetDataFromDB("Project", sqlQuery);
                    if (dtProject == null)
                    {
                        MessageBox.Show("Error occurred while retrieving the data, Contact Administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    DataTable finalDt = new DataTable("Project");
                    finalDt.Columns.Add("Select");

                    finalDt.Columns.Add("ProjectId");

                    finalDt.Columns.Add("ProjectCode");
                    finalDt.Columns.Add("ProjectTitle");

                    finalDt.Columns.Add("TenderNo");                     
                    finalDt.Columns.Add("ClosingDate");
                    finalDt.Columns.Add("CurrentStage");

                    finalDt.Columns.Add("TenderStatus");
                    finalDt.Columns.Add("TypeOfTender");

                    finalDt.Columns.Add("TenderCommittee");
                    finalDt.Columns.Add("TypeofContract");

                    finalDt.Columns.Add("FiscalYear");
                    finalDt.Columns.Add("UserDepartment");

                    finalDt.AcceptChanges();
                    string date = null;
                    foreach (DataRow drProj in dtProject.Rows)
                    {
                        DataRow dr = finalDt.NewRow();
                        if (mTypeOfTab == "Current Day Closing Tenders" || mTypeOfTab == "One Month Back Closing Tenders")
                        {
                            if (drProj[5].ToString() != "")
                            {

                                //{
                                dr[1] = drProj[0];  //ProjectId
                                dr[2] = drProj[1];  //ProjectCode
                                dr[3] = drProj[2];  //ProjectTitle

                                dr[4] = drProj[3];  //TenderNo 
                                
                                if (Convert.ToDateTime(drProj[5]).Date.CompareTo(Convert.ToDateTime(DateTime.Now.ToString()).Date) == 0)
                                //if (drProj[5].ToString() != "")
                                {
                                    dr[5] = Convert.ToDateTime(drProj[5]).ToString("dd/MMM/yyyy");  //ClosingDate                            
                                }
                                else
                                {
                                    dr[5] = Convert.ToDateTime(drProj[4]).ToString("dd/MMM/yyyy");  //ClosingDate                            
                                }
                                dr[6] = drProj[6];  //CurrentStage
                                dr[7] = drProj[7];  //TenderStatus
                                dr[8] = drProj[8];  //TypeOfTender

                                dr[9] = drProj[9];  //TenderCommittee
                                dr[10] = drProj[10];  //TypeofContract

                                dr[11] = drProj[11];  //FiscalYear
                                dr[12] = drProj[12];  //UserDepartment 

                                finalDt.Rows.Add(dr);
                                finalDt.AcceptChanges();
                                //}
                            }
                            else
                            {
                                //if (Convert.ToDateTime(drProj[4].ToString()).Date.CompareTo(Convert.ToDateTime(DateTime.Now.ToString()).Date) == 0)
                                //{
                                dr[1] = drProj[0];  //ProjectId
                                dr[2] = drProj[1];  //ProjectCode
                                dr[3] = drProj[2];  //ProjectTitle
                                dr[4] = drProj[3];  //TenderNo                      
                                dr[5] = Convert.ToDateTime(drProj[4]).ToString("dd/MMM/yyyy");  //ClosingDate                            
                                dr[6] = drProj[6];  //CurrentStage
                                dr[7] = drProj[7];  //TenderStatus
                                dr[8] = drProj[8];  //TypeOfTender

                                dr[9] = drProj[9];  //TenderCommittee
                                dr[10] = drProj[10];  //TypeofContract

                                dr[11] = drProj[11];  //FiscalYear
                                dr[12] = drProj[12];  //UserDepartment 
                                finalDt.Rows.Add(dr);
                                finalDt.AcceptChanges();
                                //}
                            }
                        }
                        else
                        {
                            dr[1] = drProj[0];  //ProjectId
                            dr[2] = drProj[1];  //ProjectCode
                            dr[3] = drProj[2];  //ProjectTitle

                            dr[4] = drProj[3];  //TenderNo  
                            if (drProj[5].ToString() != "")
                            {
                                date = Convert.ToDateTime(drProj[5]).ToString("dd/MMM/yyyy");
                                dr[5] = date;  //ClosingDate                            
                            }
                            else
                            {
                                date = Convert.ToDateTime(drProj[4]).ToString("dd/MMM/yyyy");  //ClosingDate                            
                                dr[5] = date;
                            }
                            dr[6] = drProj[6];  //CurrentStage
                            dr[7] = drProj[7];  //TenderStatus
                            dr[8] = drProj[8];  //TypeOfTender

                            dr[9] = drProj[9];  //TenderCommittee
                            dr[10] = drProj[10];  //TypeofContract

                            dr[11] = drProj[11];  //FiscalYear
                            dr[12] = drProj[12];  //UserDepartment 

                            finalDt.Rows.Add(dr);
                            finalDt.AcceptChanges();
                        }
                    }

                    if (finalDt.Rows.Count != 0)
                    {                        
                        myBindingSource = new BindingSource(finalDt, null);
                    }
                    else
                        myBindingSource = new BindingSource(null, null);
                    dgView.DataSource = myBindingSource;
                    dgView.Columns[1].Visible = false;

                    dgView.ColumnHeadersDefaultCellStyle.BackColor = Color.Maroon;
                    dgView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                    dgView.ColumnHeadersDefaultCellStyle.Font = new Font(dgView.Font, FontStyle.Bold);
                    dgView.EnableHeadersVisualStyles = false;
                    //dgView.Columns[11].Visible = false;

                    lblCnt.Text = dgView.Rows.Count.ToString();
                }
                else if (mTypeOfTab == "Archives")
                {
                    if (filterQuery == "")

                        sqlQuery = "SELECT PROJECTS.proj_id,PROJECTS.project_code, PROJECTS.project_newname_en, PROJECTS.tender_no, STAGES.Stage_Name, TenderStatus.Status_Name," +
                        "TenderTypes.tender_type_name, Committee.committee_short_name, ContractTypes.TypeofContract, FiscalYear.FiscalYear, d2.Department " +
                        " FROM [TenderStatus] RIGHT OUTER JOIN STAGES INNER JOIN [TenderTypes] INNER JOIN" +
                        " [ContractTypes] INNER JOIN [FiscalYear] INNER JOIN Committee RIGHT OUTER JOIN AFFAIRS2 INNER JOIN" +
                        " PROJECTS ON AFFAIRS2.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON " +
                        " [FiscalYear].FYID = PROJECTS.FYID ON [ContractTypes].contract_type_id = PROJECTS.contract_type_id ON " +
                        " [TenderTypes].tender_type_id = PROJECTS.tender_type_id INNER JOIN Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id ON STAGES.stage_id = PROJECTS.stage_id ON [TenderStatus].Tender_Status_id = PROJECTS.Tender_Status_id " +
                        " WHERE (TenderStatus.Tender_Status_id IN (8, 9, 10, 17)) AND (PROJECTS.isDeleted=0 ) ORDER BY PROJECTS.dummyfield DESC"; // No. 17 is Archives

                    else if (filterQuery != "")

                        sqlQuery = "SELECT PROJECTS.proj_id,PROJECTS.project_code, PROJECTS.project_newname_en, PROJECTS.tender_no, STAGES.Stage_Name, TenderStatus.Status_Name," +
                        "TenderTypes.tender_type_name, Committee.committee_short_name, ContractTypes.TypeofContract, FiscalYear.FiscalYear,d2.Department FROM [TenderStatus] RIGHT OUTER JOIN STAGES INNER JOIN [TenderTypes] INNER JOIN" +
                        " [ContractTypes] INNER JOIN [FiscalYear] INNER JOIN Committee RIGHT OUTER JOIN AFFAIRS2 INNER JOIN" +
                        " PROJECTS ON AFFAIRS2.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON " +
                        " [FiscalYear].FYID = PROJECTS.FYID ON [ContractTypes].contract_type_id = PROJECTS.contract_type_id ON " +
                        " [TenderTypes].tender_type_id = PROJECTS.tender_type_id INNER JOIN Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id ON STAGES.stage_id = PROJECTS.stage_id ON [TenderStatus].Tender_Status_id = PROJECTS.Tender_Status_id " +
                        " WHERE (TenderStatus.Tender_Status_id IN (8, 9, 10, 17)) AND (Committee.committee_short_name IN (" + committesList + ")) AND (PROJECTS.isDeleted=0 ) ORDER BY PROJECTS.dummyfield DESC"; // No. 17 is Archives

                    dtProject = dalObj.GetDataFromDB("Project", sqlQuery);

                    DataTable finalDt = new DataTable("Project");
                    finalDt.Columns.Add("Select");

                    finalDt.Columns.Add("ProjectId");

                    finalDt.Columns.Add("ProjectCode");
                    finalDt.Columns.Add("ProjectTitle");

                    finalDt.Columns.Add("TenderNo");
                    finalDt.Columns.Add("CurrentStage");

                    finalDt.Columns.Add("TenderStatus");
                    finalDt.Columns.Add("TypeOfTender");

                    finalDt.Columns.Add("TenderCommittee");
                    finalDt.Columns.Add("TypeofContract");

                    finalDt.Columns.Add("FiscalYear");
                    finalDt.Columns.Add("UserDepartment");

                    finalDt.AcceptChanges();

                    foreach (DataRow drProj in dtProject.Rows)
                    {
                        DataRow dr = finalDt.NewRow();
                        //dr[1] = strProj;    //ProjectId
                        dr[1] = drProj[0];  //ProjectId
                        dr[2] = drProj[1];  //ProjectCode
                        dr[3] = drProj[2];  //ProjectTitle

                        dr[4] = drProj[3];  //TenderNo
                        dr[5] = drProj[4];  //CurrentStage


                        dr[6] = drProj[5];  //TenderStatus
                        dr[7] = drProj[6];  //TypeOfTender

                        dr[8] = drProj[7];  //TenderCommittee
                        dr[9] = drProj[8];  //TypeofContract

                        dr[10] = drProj[9];  //FiscalYear
                        dr[11] = drProj[10];  //UserDepartment 

                        finalDt.Rows.Add(dr);
                        finalDt.AcceptChanges();
                    }

                    myBindingSource = new BindingSource(finalDt, null);
                    dgView.DataSource = myBindingSource;
                    dgView.Columns[1].Visible = false;
                    dtTemp = finalDt;

                    dtTempForCombo = finalDt;

                    dgView.ColumnHeadersDefaultCellStyle.BackColor = Color.Maroon;
                    dgView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                    dgView.ColumnHeadersDefaultCellStyle.Font = new Font(dgView.Font, FontStyle.Bold);
                    dgView.EnableHeadersVisualStyles = false;
                    //dgView.Columns[11].Visible = false;

                    lblCnt.Text = dgView.Rows.Count.ToString();
                }
                else if (mTypeOfTab == "Deleted Projects")
                {
                    if (filterQuery == "")

                        sqlQuery = "SELECT PROJECTS.proj_id,PROJECTS.project_code, PROJECTS.project_newname_en, PROJECTS.tender_no, STAGES.Stage_Name, TenderStatus.Status_Name," +
                        "TenderTypes.tender_type_name, Committee.committee_short_name, ContractTypes.TypeofContract, FiscalYear.FiscalYear, d2.Department " +
                        " FROM [TenderStatus] RIGHT OUTER JOIN STAGES INNER JOIN [TenderTypes] INNER JOIN" +
                        " [ContractTypes] INNER JOIN [FiscalYear] INNER JOIN Committee RIGHT OUTER JOIN AFFAIRS2 INNER JOIN" +
                        " PROJECTS ON AFFAIRS2.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON " +
                        " [FiscalYear].FYID = PROJECTS.FYID ON [ContractTypes].contract_type_id = PROJECTS.contract_type_id ON " +
                        " [TenderTypes].tender_type_id = PROJECTS.tender_type_id INNER JOIN Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id ON STAGES.stage_id = PROJECTS.stage_id ON [TenderStatus].Tender_Status_id = PROJECTS.Tender_Status_id " +
                        " WHERE (PROJECTS.isDeleted=1) ORDER BY PROJECTS.dummyfield DESC";

                    else if (filterQuery != "")

                        sqlQuery = "SELECT PROJECTS.proj_id,PROJECTS.project_code, PROJECTS.project_newname_en, PROJECTS.tender_no, STAGES.Stage_Name, TenderStatus.Status_Name," +
                        "TenderTypes.tender_type_name, Committee.committee_short_name, ContractTypes.TypeofContract, FiscalYear.FiscalYear,d2.Department FROM [TenderStatus] RIGHT OUTER JOIN STAGES INNER JOIN [TenderTypes] INNER JOIN" +
                        " [ContractTypes] INNER JOIN [FiscalYear] INNER JOIN Committee RIGHT OUTER JOIN AFFAIRS2 INNER JOIN" +
                        " PROJECTS ON AFFAIRS2.Affair_id = PROJECTS.Affair_id ON Committee.committee_id = PROJECTS.committee_id ON " +
                        " [FiscalYear].FYID = PROJECTS.FYID ON [ContractTypes].contract_type_id = PROJECTS.contract_type_id ON " +
                        " [TenderTypes].tender_type_id = PROJECTS.tender_type_id INNER JOIN Department2 as d1 on PROJECTS.department_id=d1.department_id inner join Department2 as d2 on d1.newDepID=d2.department_id ON STAGES.stage_id = PROJECTS.stage_id ON [TenderStatus].Tender_Status_id = PROJECTS.Tender_Status_id " +
                        " WHERE (PROJECTS.isDeleted=1) AND (Committee.committee_short_name IN (" + committesList + ")) ORDER BY PROJECTS.dummyfield DESC";

                    dtProject = dalObj.GetDataFromDB("Project", sqlQuery);

                    DataTable finalDt = new DataTable("Project");
                    finalDt.Columns.Add("Select");

                    finalDt.Columns.Add("ProjectId");

                    finalDt.Columns.Add("ProjectCode");
                    finalDt.Columns.Add("ProjectTitle");

                    finalDt.Columns.Add("TenderNo");
                    finalDt.Columns.Add("CurrentStage");

                    finalDt.Columns.Add("TenderStatus");
                    finalDt.Columns.Add("TypeOfTender");

                    finalDt.Columns.Add("TenderCommittee");
                    finalDt.Columns.Add("TypeofContract");

                    finalDt.Columns.Add("FiscalYear");
                    finalDt.Columns.Add("UserDepartment");

                    finalDt.AcceptChanges();

                    foreach (DataRow drProj in dtProject.Rows)
                    {
                        DataRow dr = finalDt.NewRow();
                        //dr[1] = strProj;    //ProjectId
                        dr[1] = drProj[0];  //ProjectId
                        dr[2] = drProj[1];  //ProjectCode
                        dr[3] = drProj[2];  //ProjectTitle

                        dr[4] = drProj[3];  //TenderNo
                        dr[5] = drProj[4];  //CurrentStage


                        dr[6] = drProj[5];  //TenderStatus
                        dr[7] = drProj[6];  //TypeOfTender

                        dr[8] = drProj[7];  //TenderCommittee
                        dr[9] = drProj[8];  //TypeofContract

                        dr[10] = drProj[9];  //FiscalYear
                        dr[11] = drProj[10];  //UserDepartment 

                        finalDt.Rows.Add(dr);
                        finalDt.AcceptChanges();
                    }

                    myBindingSource = new BindingSource(finalDt, null);
                    dgView.DataSource = myBindingSource;
                    dgView.Columns[1].Visible = false;
                    dtTemp = finalDt;

                    dtTempForCombo = finalDt;

                    dgView.ColumnHeadersDefaultCellStyle.BackColor = Color.Maroon;
                    dgView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                    dgView.ColumnHeadersDefaultCellStyle.Font = new Font(dgView.Font, FontStyle.Bold);
                    dgView.EnableHeadersVisualStyles = false;
                    //dgView.Columns[11].Visible = false;

                    lblCnt.Text = dgView.Rows.Count.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while retrieving the data, Contact Administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlConn.Close();
            }

            headerCheckBox.KeyUp += new KeyEventHandler(chkBox.HeaderCheckBox_KeyUp);
            headerCheckBox.MouseClick += new MouseEventHandler(chkBox.HeaderCheckBox_MouseClick);
            //dgView.CellContentClick += new DataGridViewCellEventHandler(chkBox.dgvSelectAll_CellContentClick);             
            dgView.CurrentCellDirtyStateChanged += new EventHandler(chkBox.dgvSelectAll_CurrentCellDirtyStateChanged);
            dgView.CellPainting += new DataGridViewCellPaintingEventHandler(chkBox.dgvSelectAll_CellPainting);

            this.label1 = new Label();
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Service Uri:";

        }
        private void GridFill(string filterQuery)
        {
            lblCnt.Text = "0";
            dtTempForCombo = dtTemp;
            int iCnt = dtTempForCombo.Rows.Count;
            DataTable dtCmbTbl = null;
            if (dtTempForCombo.Select(filterQuery).Length != 0)
            {
                dtCmbTbl = dtTempForCombo.Select(filterQuery).CopyToDataTable();
                int jCnt = dtCmbTbl.Rows.Count;
                try
                {
                    myBindingSource = new BindingSource(dtCmbTbl, null);
                    dgView.DataSource = myBindingSource;

                    dtTempForCombo = dtCmbTbl;

                    //dgView.ColumnHeadersDefaultCellStyle.BackColor = Color.Olive;
                    //dgView.ColumnHeadersDefaultCellStyle.ForeColor = Color.Blue;

                    //dgView.ColumnHeadersDefaultCellStyle.Font = new Font(dgView.Font, FontStyle.Bold);

                    dgView.EnableHeadersVisualStyles = false;
                    dgView.Columns[1].Visible = false;
                    lblCnt.Text = dgView.Rows.Count.ToString();
                }
                catch (Exception ex)
                {
                    string exMsg = ex.Message;
                }
                finally
                {
                }
            }
            else
            {
                DataTable nullTable = new DataTable();
                dtCmbTbl = null;
                myBindingSource = new BindingSource(nullTable, null);
                dgView.DataSource = myBindingSource;
                lblCnt.Text = dgView.Rows.Count.ToString();
            }
        }
        private enum NavButton
        {
            First = 1,
            Next = 2,
            Previous = 3,
            Last = 4,
        }   
        private void dgView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 2)
            {
                string mnstryCode = string.Empty;
                try
                {
                   // ProjectStages projStg = new ProjectStages(userRightsColl,"", Convert.ToInt16(dgView.Rows[e.RowIndex].Cells[1].Value),_userName);   
                   //// ProjectStages projStg = new ProjectStages(Convert.ToInt16(dgView.Rows[e.RowIndex].Cells[0].Value));                 
                   // projStg.StartPosition = FormStartPosition.CenterParent; 
                   // projStg.ShowDialog();
                }
                catch (Exception ex)
                {

                }
                finally
                {
                    sqlConn.Close();
                }
            }
        }
      
        // Displays the drop-down list when the user presses 
        // ALT+DOWN ARROW or ALT+UP ARROW.
        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Alt && (e.KeyCode == Keys.Down || e.KeyCode == Keys.Up))
            {
                DataGridViewAutoFilterColumnHeaderCell filterCell =
                    dgView.CurrentCell.OwningColumn.HeaderCell as
                    DataGridViewAutoFilterColumnHeaderCell;
                if (filterCell != null)
                {
                    filterCell.ShowDropDownList();
                    e.Handled = true;
                }
            }
        }
        // Updates the filter status label. 
        private void dataGridView1_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            String filterStatus = DataGridViewAutoFilterColumnHeaderCell.GetFilterStatus(dgView);
            if (String.IsNullOrEmpty(filterStatus))
            {  
             
            }
            else
            {  
             
            }
        }       
        private void button2_Click(object sender, EventArgs e)
        {
            if (userRightsColl.Contains("2"))     //Delete a Project
            {
                MessageBox.Show("You have no privilege to delete this project,Contact administrator");
                return;
            }

            List<int> lstObj = new List<int>();
            string projCodeCell = null;
            int prjID = 0;
            for (int iCounter = 0; iCounter < dgView.RowCount; iCounter++)
            {
                DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgView.Rows[iCounter].Cells[0];
                if (chkactive.Value != null)
                {
                    if (chkactive.Value.ToString().ToLower() == "true")
                    {
                        int docID = 0;
                        projCodeCell = Convert.ToString(dgView.Rows[iCounter].Cells[2].Value);                        
                        prjID = Convert.ToInt16(dgView.Rows[iCounter].Cells[1].Value);

                        sqlConn.Open();
                        try
                        {
                            using (sqlCom = new SqlCommand("SELECT doc_id FROM DOCUMENTS where Proj_Id = " + prjID + "", sqlConn))
                            {
                                docID = Convert.ToInt16(sqlCom.ExecuteScalar());
                            }
                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                        finally
                        {
                            sqlConn.Close();
                        }

                        try
                        {
                            if (docID == 0)
                            {
                                sqlConn.Open();
                                sqlCom = new SqlCommand("Delete from Projects where Project_Code='" + projCodeCell + "'", sqlConn);
                                sqlCom.ExecuteNonQuery();
                            }
                            else
                            {
                                MessageBox.Show("You have no prviliges to delete this project,Contact administrator", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                sqlConn.Close();
                                return;
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("You have no privilege to delete this project,Contact administrator", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            sqlConn.Close();
                            return;
                        }
                        finally
                        {
                            sqlConn.Close();
                        }
                        lstObj.Add(iCounter);
                    }
                }
            }
            short sClear = 0;
            if (dgView.Rows.Count == lstObj.Count)
            {
                dgView.Rows.RemoveAt(lstObj[0]);
                sClear = 1;
            }
            if (sClear != 1)
            {
                for (int iCounter = 0; iCounter < lstObj.Count; iCounter++)
                {
                    if (iCounter == 0)
                        dgView.Rows.RemoveAt(lstObj[iCounter]);
                    if (iCounter != 0)
                        dgView.Rows.RemoveAt(lstObj[iCounter] - 1);
                }
            }
            if (lstObj.Count == 0)
                MessageBox.Show("Please select a record from GridView", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }      

        private void button3_Click_1(object sender, EventArgs e)
        {
            FillAllProjectsInformation('R',filterQuery);
        }        
        private void FillCombo()
        {
            DAL dalObj = new DAL();

            dalObj.populateCmbBox("Select Project_Code From Projects", cmbPrjCode);
            cmbPrjCode.SelectedIndex = -1;

            dalObj.populateCmbBox("select tender_no from Projects where tender_no is not Null", cmbTenderNo);
            cmbTenderNo.SelectedIndex = -1;

            dalObj.populateCmbBox("select Stage_Name from STAGES", cmbCurrentStage);
            cmbCurrentStage.SelectedIndex = -1;

            //dalObj.populateCmbBox("SELECT [Status_Name], [TenderStatusShortName], Tender_Status_id FROM [TenderStatus] WHERE (Tender_Status_id = 8) OR (Tender_Status_id = 9) OR (Tender_Status_id = 10) ", cmbTenderStatus);
            //cmbTenderStatus.SelectedIndex = -1;

            dalObj.populateCmbBox("Select [Status_Name],[TenderStatusShortName] From [TenderStatus] WHERE Tender_Status_id in (8,9,10)Order by Tender_Status_id ", cmbTenderStatus);
            cmbTenderStatus.SelectedIndex = -1;

            dalObj.populateCmbBox("Select tender_type_name From [TenderTypes]", cmbTypeOftender);
            cmbTypeOftender.SelectedIndex = -1;

            dalObj.populateCmbBox("select [committee_short_name],committee_name from [Committee]", cmbtenderCommitte);
            cmbtenderCommitte.SelectedIndex = -1;

            dalObj.populateCmbBox("select [TypeofContract] from [ContractTypes]", cmbTypeofContract);
            cmbTypeofContract.SelectedIndex = -1;          

            dalObj.populateCmbBox("Select FYID,[FiscalYear] From [FiscalYear]", cmbFiscalYear);  //Fiscal_Year
            cmbFiscalYear.SelectedIndex = -1;

           // dalObj.populateCmbBox("Select department_short_name,Department From Department", cmbUserDepart);

            dalObj.populateCmbBox("Select department_short_name,Department From Department2 where department_short_name is not Null and isActive=1", cmbUserDepart);
            cmbUserDepart.SelectedIndex = -1;

        }        
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();           
        }
        private void filterCombo()
        {
            string filterQuery = string.Empty;

            if (cmbPrjCode.SelectedIndex != -1)
            {
                if (filterQuery == "")
                {
                    filterQuery = "ProjectCode = '" + ((DataRowView)cmbPrjCode.SelectedItem).Row.ItemArray[0].ToString() + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "ProjectCode = '" + ((DataRowView)cmbPrjCode.SelectedItem).Row.ItemArray[0].ToString() + "'";
                }
            }
            else if (cmbPrjCode.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "ProjectCode like '%" + cmbPrjCode.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "ProjectCode like '%" + cmbPrjCode.Text + "%'";
                }
            }
            if (txtPrjTitle.Text != "")
            {
                if (filterQuery == "")
                {
                    filterQuery = "ProjectTitle like '%" + txtPrjTitle.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "ProjectTitle like '%" + txtPrjTitle.Text + "%'";
                }
            }
            if (cmbTenderNo.SelectedIndex != -1)
            {
                if (filterQuery == "")
                {
                    // Modified by Varun to like % on 04 Feb 2014
                    filterQuery = "TenderNo like '%" + ((DataRowView)cmbTenderNo.SelectedItem).Row.ItemArray[0].ToString() + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "TenderNo like '%" + ((DataRowView)cmbTenderNo.SelectedItem).Row.ItemArray[0].ToString() + "%'";
                }
            }
            else if (cmbTenderNo.Text != "")
            {
                if (filterQuery == "")
                {
                    // Modified by Varun to like % on 04 Feb 2014
                    filterQuery = "TenderNo like '%" + cmbTenderNo.Text + "%'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "TenderNo like '%" + cmbTenderNo.Text + "%'";
                }
            }

            if (cmbFiscalYear.SelectedIndex != -1)
            {
                if (filterQuery == "")
                {
                    filterQuery = "FiscalYear = '" + ((DataRowView)cmbFiscalYear.SelectedItem).Row.ItemArray[1].ToString() + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "FiscalYear = '" + ((DataRowView)cmbFiscalYear.SelectedItem).Row.ItemArray[1].ToString() + "'";
                }
            }
            if (cmbTypeofContract.SelectedIndex != -1)
            {
                if (filterQuery == "")
                {
                    filterQuery = "TypeofContract = '" + ((DataRowView)cmbTypeofContract.SelectedItem).Row.ItemArray[0].ToString() + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "TypeofContract = '" + ((DataRowView)cmbTypeofContract.SelectedItem).Row.ItemArray[0].ToString() + "'";
                }
            }
            if (cmbtenderCommitte.SelectedIndex != -1)
            {
                if (filterQuery == "")
                {
                    filterQuery = "TenderCommittee = '" + ((DataRowView)cmbtenderCommitte.SelectedItem).Row.ItemArray[0].ToString() + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "TenderCommittee = '" + ((DataRowView)cmbtenderCommitte.SelectedItem).Row.ItemArray[0].ToString() + "'";
                }

            }
            if (cmbTypeOftender.SelectedIndex != -1)
            {
                if (filterQuery == "")
                {
                    filterQuery = "TypeOfTender = '" + ((DataRowView)cmbTypeOftender.SelectedItem).Row.ItemArray[0].ToString() + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "TypeOfTender = '" + ((DataRowView)cmbTypeOftender.SelectedItem).Row.ItemArray[0].ToString() + "'";
                }
            }
            if (cmbTenderStatus.SelectedIndex != -1)
            {
                if (filterQuery == "")
                {
                    filterQuery = "TenderStatus = '" + ((DataRowView)cmbTenderStatus.SelectedItem).Row.ItemArray[0].ToString() + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "TenderStatus = '" + ((DataRowView)cmbTenderStatus.SelectedItem).Row.ItemArray[0].ToString() + "'";
                }
            }
            if (cmbCurrentStage.SelectedIndex != -1)
            {
                if (filterQuery == "")
                {
                    filterQuery = "CurrentStage = '" + ((DataRowView)cmbCurrentStage.SelectedItem).Row.ItemArray[0].ToString() + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "CurrentStage = '" + ((DataRowView)cmbCurrentStage.SelectedItem).Row.ItemArray[0].ToString() + "'";
                }
            }
            if (cmbUserDepart.SelectedIndex != -1)
            {
                if (filterQuery == "")
                {
                    filterQuery = "UserDepartment = '" + ((DataRowView)cmbUserDepart.SelectedItem).Row.ItemArray[1].ToString() + "'";
                }
                else
                {
                    filterQuery = filterQuery + " and " + "UserDepartment = '" + ((DataRowView)cmbUserDepart.SelectedItem).Row.ItemArray[1].ToString() + "'";
                }
            }
            if (filterQuery == "")
            {
                GridFill("");
            }
            else
            {
                GridFill(filterQuery);
            }
        }           
        private void cmbUserDepart_KeyDown(object sender, KeyEventArgs e)
        {
            filterCombo();
        }        
        private void cmbTypeofContract_SelectedIndexChanged(object sender, EventArgs e)
        {
            filterCombo();
        }
        private void btnEdit_Click(object sender, EventArgs e)
        {
            int ProjectID = 0;
            string prjCode = string.Empty;          

            for (int iCounter = 0; iCounter < dgView.RowCount; iCounter++)
            {
                DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgView.Rows[iCounter].Cells[0];
                if (chkactive.Value != null)
                {
                    if (chkactive.Value.ToString().ToLower() == "true")
                    {
                        ProjectID = Convert.ToInt16(dgView.Rows[iCounter].Cells[1].Value);                                       
                    }
                }
            }
            if (ProjectID == 0)
            {
                MessageBox.Show("Please select a record from GridView", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
               // frmProjectEdit frmEditProject = new frmProjectEdit(ProjectID, prjCode, affairsName, deptName, prjTitleEn, prjTitleArb, tndrCommitte, typeOfTender, fiscalYear, typeOfCntr);
                frmProjectEdit frmEditProject = new frmProjectEdit(userRightsColl, ProjectID, prjCode, _userName);
                frmEditProject.StartPosition = FormStartPosition.CenterParent;
                frmEditProject.ShowDialog();
            }
        }       
        public static void ScaleDown(System.Windows.Forms.Form frm)
        {
            int scrWidth = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width;
            int scrHeight = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height;
            if (scrWidth < frm.Width)
            {
                foreach (System.Windows.Forms.Control cntrl in frm.Controls)
                {
                    cntrl.Width = ((cntrl.Width) * (scrWidth)) / (frm.Width);
                    cntrl.Left = ((cntrl.Left) * (scrWidth)) / (frm.Width);
                }
            }
            if (scrHeight < frm.Height)
            {
                foreach (System.Windows.Forms.Control cntrl in frm.Controls)
                {
                    cntrl.Height = ((cntrl.Height) * (scrHeight)) / (frm.Height);
                    cntrl.Top = ((cntrl.Top) * (scrHeight)) / (frm.Height);
                }
            }
        } 
        private void cmbPrjCode_KeyDown(object sender, KeyEventArgs e)
        {
            filterCombo();
        }
        private void cmbTenderNo_KeyDown(object sender, KeyEventArgs e)
        {
            filterCombo();
        }
        string filterQuery = string.Empty;
        private void DefaultView_Load(object sender, EventArgs e)
        {
            if (!userRightsColl.Contains("54"))
            {
                FillAllProjectsInformation('R', "");
            }
            else if (mTypeOfTab != null)
            {
                //if (mTypeOfTab == "Archives")
                //{
                    if (!userRightsColl.Contains("55"))
                    {
                        filterQuery = "'" + "GTC" + "'";
                    }
                    if (!userRightsColl.Contains("56"))
                    {
                        if (filterQuery == "")
                            filterQuery = "'" + "STC" + "'";
                        else
                            filterQuery = filterQuery + "," + "'" + "STC" + "'";

                    }
                    if (!userRightsColl.Contains("57"))
                    {
                        if (filterQuery == "")
                            filterQuery = "'" + "ITC" + "'";
                        else
                            filterQuery = filterQuery + "," + "'" + "ITC" + "'";
                    }
                    if (!userRightsColl.Contains("58"))
                    {
                        if (filterQuery == "")
                            filterQuery = "'" + "MRPSC" + "'";
                        else
                            filterQuery = filterQuery + "," + "'" + "MRPSC" + "'";

                        // filterQuery = filterQuery + "," + "'" + "MRPCS" + "'";
                    }
                    if (!userRightsColl.Contains("59"))
                    {
                        if (filterQuery == "")
                        {
                            //commented by Varun 11/08/2014
                            //filterQuery = "'" + "U&EWTC" + "'";                        
                            filterQuery = "'" + "EUWC" + "'";
                        }
                        else
                        {
                            //commented by Varun 11/08/2014
                            //filterQuery = filterQuery + "," + "'" + "U&EWTC" + "'";
                            filterQuery = filterQuery + "," + "'" + "EUWC" + "'";
                        }
                    }
                    if (!userRightsColl.Contains("60"))
                    {
                        if (filterQuery == "")
                            filterQuery = "'" + "WPC" + "'";
                        else
                            filterQuery = filterQuery + "," + "'" + "WPC" + "'";
                    }
                    if (filterQuery == "")
                        filterQuery = "'" + "NC" + "'";
                    else
                        filterQuery = filterQuery + "," + "'" + "NC" + "'";

                    FillAllProjectsInformation('R', filterQuery);
                //}
               
            }

            if (mTypeOfTab != null)
            {
                if (mTypeOfTab == "Archives" || mTypeOfTab == "Deleted Projects")
                    FillCombo();
            }
          
        }
        private void dgView_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            dgView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            if (e.ColumnIndex == 2)
            {
                string mnstryCode = string.Empty;
                try
                {
                    ProjectStages projStg = new ProjectStages(userRightsColl, "", Convert.ToInt16(dgView.Rows[e.RowIndex].Cells[1].Value), dgView.Rows[e.RowIndex].Cells[8].Value.ToString(), _userName, mTypeOfTab,_isHeadOfSection);
                    // ProjectStages projStg = new ProjectStages(Convert.ToInt16(dgView.Rows[e.RowIndex].Cells[0].Value));                 
                    projStg.StartPosition = FormStartPosition.CenterParent;
                    projStg.ShowDialog();
                    UpdateTimeInDummyField(projStg.ProjectId);

                    //if (projStg.ProjTransferedToComm == 'Y' || Filtered == ' ')
                    //    FillAllProjectsInformation('R');

                    if (!userRightsColl.Contains("54"))
                    {
                        if (projStg.ProjTransferedToComm == 'Y')
                            FillAllProjectsInformation('R', filterQuery);
                    }
                    else
                    {
                        if (projStg.ProjTransferedToComm == 'Y')
                            FillAllProjectsInformation('R', filterQuery);
                        //else if (Filtered!='Y')
                        //    FillAllProjectsInformation_CommitteWise(' ', filterQueryMain, Filtered);
                    }


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void UpdateTimeInDummyField(int ProjIDTime)
        {
            try
            {
                using (SqlConnection sqlConn = new SqlConnection(strCon))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        sqlConn.Open();
                        cmd.Connection = sqlConn;

                        cmd.CommandText = @"UPDATE PROJECTS SET dummyfield = @fieldForTime where proj_id=@prjID";
                        cmd.Parameters.AddWithValue("@fieldForTime", System.DateTime.Now);
                        cmd.Parameters.AddWithValue("@prjID", ProjIDTime);

                        int exUpdated = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while Updating the TimeSpan, Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        private void txtPrjTitle_Leave(object sender, EventArgs e)
        {

        }
        private void txtPrjTitle_TextChanged(object sender, EventArgs e)
        {

        }
        private void btnEditArchieve_Click(object sender, EventArgs e)
        {
            if (userRightsColl.Contains("3"))
            {
                MessageBox.Show("You have no privilege,Contact administrator");
                return;
            }

            int iCnt = 0;
            for (int iCounter = 0; iCounter < dgView.RowCount; iCounter++)
            {
                DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgView.Rows[iCounter].Cells[0];

                if (chkactive.Value != null)
                {
                    if (chkactive.Value.ToString().ToLower() == "true")
                        iCnt = iCnt + 1;
                }
            }
            if (iCnt > 1)
            {
                MessageBox.Show("Please Select Only One Record For Edit");
                return;
            }


            int ProjectID = 0;
            string prjCode = string.Empty;

            for (int iCounter = 0; iCounter < dgView.RowCount; iCounter++)
            {
                DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgView.Rows[iCounter].Cells[0];
                if (chkactive.Value != null)
                {
                    if (chkactive.Value.ToString().ToLower() == "true")
                    {
                        ProjectID = Convert.ToInt16(dgView.Rows[iCounter].Cells[1].Value);
                    }
                }
            }
            if (ProjectID == 0)
            {
                MessageBox.Show("Please click the checkbox to select the project you want to View/Edit.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                // frmProjectEdit frmEditProject = new frmProjectEdit(ProjectID, prjCode, affairsName, deptName, prjTitleEn, prjTitleArb, tndrCommitte, typeOfTender, fiscalYear, typeOfCntr);
                frmProjectEdit frmEditProject = new frmProjectEdit(userRightsColl, ProjectID, prjCode, _userName);
                frmEditProject.StartPosition = FormStartPosition.CenterParent;
                frmEditProject.ShowDialog();
            }
        }
        protected void cmbPrjCode_OnKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                filterCombo();
            }
        }
        protected void cmbTypeofContract_OnKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                filterCombo();
            }
        }

        protected void cmbFiscalYear_OnKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                filterCombo();
            }
        }

        protected void cmbtenderCommitte_OnKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                filterCombo();
            }
        }

        private void cmbUserDepart_OnKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                filterCombo();
            }
        }

        private void cmbTenderNo_OnKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                filterCombo();
            }
        }

        private void txtPrjTitle_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Down)
            {
                filterCombo();
            }
        }

        private void txtPrjTitle_OnKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                filterCombo();
            }
        }

        private void cmbCurrentStage_OnKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                filterCombo();
            }
        }

        private void cmbTypeOftender_OnKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                filterCombo();
            }
        }

        private void cmbTenderStatus_OnKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                filterCombo();
            }
        }

       
        private void btnDeleteArchieve_Click(object sender, EventArgs e)
        {
            try
            {
                sqlConn = new SqlConnection(strCon);
                sqlConn.Open();
                if (userRightsColl.Contains("2"))
                {
                    MessageBox.Show("You have no privilege,Contact administrator");
                    return;
                }

                int iCnt = 0;
                for (int iCounter = 0; iCounter < dgView.RowCount; iCounter++)
                {
                    DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgView.Rows[iCounter].Cells[0];

                    if (chkactive.Value != null)
                    {
                        if (chkactive.Value.ToString().ToLower() == "true")
                            iCnt = iCnt + 1;
                    }
                }
                if (iCnt > 1)
                {
                    MessageBox.Show("Please Select Only One Record For Delete");
                    return;
                }

                List<int> lstObj = new List<int>();
                //string projCodeCell = null;
                int prjID = 0;
                for (int iCounter = 0; iCounter < dgView.RowCount; iCounter++)
                {
                    DataGridViewCheckBoxCell chkactive = (DataGridViewCheckBoxCell)dgView.Rows[iCounter].Cells[0];
                    if (chkactive.Value != null)
                    {
                        if (chkactive.Value.ToString().ToLower() == "true")
                        {
                            //projCodeCell = Convert.ToString(dgView.Rows[iCounter].Cells[2].Value);
                            prjID = Convert.ToInt16(dgView.Rows[iCounter].Cells[1].Value);

                            //CommonClass commClass = new CommonClass(_userName);
                            //int dateID = commClass.ChkDeleteRec_TenderDatesInfo(prjID, sqlConn);
                            //int docID = commClass.ChkDeleteRec_Documents(prjID, sqlConn);
                            //int costID = commClass.ChkDeleteRec_ProjectCost(prjID, sqlConn);
                            //int contractID = commClass.ChkDeleteRec_Contractors(prjID, sqlConn);                            

                           
                            DialogResult dlgResult = DialogResult.Yes;
                            dlgResult = MessageBox.Show(" Are you sure you want to move the Project to Deleted Projects?", "Delete Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                            if (dlgResult.ToString() == "Yes")
                            {
                                try
                                {
                                    using (SqlCommand sqlCom = new SqlCommand("update Projects set isDeleted=1 where Proj_id =" + prjID, sqlConn))
                                    {
                                        sqlCom.ExecuteNonQuery();
                                    }
                                    MessageBox.Show("Record Successfully moved to Deleted Projects");
                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show("Error occurred while updating the value of isDeleted column of Project table.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                                // moved by Varun
                                lstObj.Add(iCounter);

                            }
                            else
                            {
                                return;
                            }                            
                        }
                    }
                }
                short sClear = 0;
                if (dgView.Rows.Count == lstObj.Count)
                {
                    dgView.Rows.RemoveAt(lstObj[0]);
                    sClear = 1;
                }
                if (sClear != 1)
                {
                    for (int iCounter = 0; iCounter < lstObj.Count; iCounter++)
                    {
                        if (iCounter == 0)
                            dgView.Rows.RemoveAt(lstObj[iCounter]);
                        if (iCounter != 0)
                            dgView.Rows.RemoveAt(lstObj[iCounter] - 1);
                    }
                }
                if (lstObj.Count == 0)
                    MessageBox.Show("Please click the checkbox to select the project you want to Delete", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while connecting to database", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cmbUserDepart_SelectionChangeCommitted(object sender, EventArgs e)
        {
            filterCombo();
        }

        private void cmbUserDepart_KeyDown_1(object sender, KeyEventArgs e)
        {
            filterCombo();
        }

        private void cmbFiscalYear_KeyDown(object sender, KeyEventArgs e)
        {
            filterCombo();
        }

        private void cmbFiscalYear_KeyPress(object sender, KeyPressEventArgs e)
        {
            filterCombo();
        }

        private void cmbTypeofContract_KeyDown(object sender, KeyEventArgs e)
        {
            filterCombo();
        }

        private void cmbtenderCommitte_KeyDown(object sender, KeyEventArgs e)
        {
            filterCombo();
        }

        private void cmbtenderCommitte_KeyPress(object sender, KeyPressEventArgs e)
        {
            filterCombo();
        }

        private void cmbTypeOftender_KeyDown(object sender, KeyEventArgs e)
        {
            filterCombo();
        }

     
        

        private void cmbTenderNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            filterCombo();
        }

        private void txtPrjTitle_KeyPress(object sender, KeyPressEventArgs e)
        {
            filterCombo();
        }

        private void cmbPrjCode_SelectionChangeCommitted(object sender, EventArgs e)
        {
            filterCombo();
        }

        private void cmbFiscalYear_SelectionChangeCommitted(object sender, EventArgs e)
        {
            filterCombo();
        }

        private void cmbTypeofContract_SelectionChangeCommitted(object sender, EventArgs e)
        {
            filterCombo();
        }

        private void cmbtenderCommitte_SelectionChangeCommitted(object sender, EventArgs e)
        {
            filterCombo();
        }

        private void cmbTypeOftender_SelectionChangeCommitted(object sender, EventArgs e)
        {
            filterCombo();
        }

        private void cmbTenderStatus_SelectionChangeCommitted(object sender, EventArgs e)
        {
            filterCombo();
        }

        private void cmbCurrentStage_SelectionChangeCommitted(object sender, EventArgs e)
        {
            filterCombo();
        }

        private void cmbTenderNo_SelectionChangeCommitted(object sender, EventArgs e)
        {
            filterCombo();
        }

         
    }
}
