﻿namespace MDI_ParenrForm.Projects
{
    partial class frmTenderSubmission
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpBoxTenderSubmission = new System.Windows.Forms.GroupBox();
            this.btnExportToPDF = new System.Windows.Forms.Button();
            this.lblWorkOrderTitleValue = new System.Windows.Forms.Label();
            this.lblWorkOrderTitle = new System.Windows.Forms.Label();
            this.lblClosingDateValue = new System.Windows.Forms.Label();
            this.lblClosingDateText = new System.Windows.Forms.Label();
            this.lblTenderStatus = new System.Windows.Forms.Label();
            this.lblTenderSubmissionHeading2 = new System.Windows.Forms.Label();
            this.btnExcel = new System.Windows.Forms.Button();
            this.dgvTendererInfo = new System.Windows.Forms.DataGridView();
            this.lblWorkOrderNoValue = new System.Windows.Forms.Label();
            this.lblWorkOrderNo = new System.Windows.Forms.Label();
            this.lblProjTitleValue = new System.Windows.Forms.Label();
            this.lblProjTitle = new System.Windows.Forms.Label();
            this.lblTenderNoValue = new System.Windows.Forms.Label();
            this.lblTenderNo = new System.Windows.Forms.Label();
            this.lblTenderSubmissionHeading1 = new System.Windows.Forms.Label();
            this.grpBoxTenderSubmission.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTendererInfo)).BeginInit();
            this.SuspendLayout();
            // 
            // grpBoxTenderSubmission
            // 
            this.grpBoxTenderSubmission.Controls.Add(this.btnExportToPDF);
            this.grpBoxTenderSubmission.Controls.Add(this.lblWorkOrderTitleValue);
            this.grpBoxTenderSubmission.Controls.Add(this.lblWorkOrderTitle);
            this.grpBoxTenderSubmission.Controls.Add(this.lblClosingDateValue);
            this.grpBoxTenderSubmission.Controls.Add(this.lblClosingDateText);
            this.grpBoxTenderSubmission.Controls.Add(this.lblTenderStatus);
            this.grpBoxTenderSubmission.Controls.Add(this.lblTenderSubmissionHeading2);
            this.grpBoxTenderSubmission.Controls.Add(this.btnExcel);
            this.grpBoxTenderSubmission.Controls.Add(this.dgvTendererInfo);
            this.grpBoxTenderSubmission.Controls.Add(this.lblWorkOrderNoValue);
            this.grpBoxTenderSubmission.Controls.Add(this.lblWorkOrderNo);
            this.grpBoxTenderSubmission.Controls.Add(this.lblProjTitleValue);
            this.grpBoxTenderSubmission.Controls.Add(this.lblProjTitle);
            this.grpBoxTenderSubmission.Controls.Add(this.lblTenderNoValue);
            this.grpBoxTenderSubmission.Controls.Add(this.lblTenderNo);
            this.grpBoxTenderSubmission.Controls.Add(this.lblTenderSubmissionHeading1);
            this.grpBoxTenderSubmission.Font = new System.Drawing.Font("Calibri", 10F);
            this.grpBoxTenderSubmission.Location = new System.Drawing.Point(13, 12);
            this.grpBoxTenderSubmission.Name = "grpBoxTenderSubmission";
            this.grpBoxTenderSubmission.Size = new System.Drawing.Size(1039, 613);
            this.grpBoxTenderSubmission.TabIndex = 0;
            this.grpBoxTenderSubmission.TabStop = false;
            this.grpBoxTenderSubmission.Text = "Tender Submission";
            // 
            // btnExportToPDF
            // 
            this.btnExportToPDF.Font = new System.Drawing.Font("Calibri", 12F);
            this.btnExportToPDF.Location = new System.Drawing.Point(917, 163);
            this.btnExportToPDF.Name = "btnExportToPDF";
            this.btnExportToPDF.Size = new System.Drawing.Size(115, 32);
            this.btnExportToPDF.TabIndex = 16;
            this.btnExportToPDF.Text = "Export To PDF";
            this.btnExportToPDF.UseVisualStyleBackColor = true;
            this.btnExportToPDF.Click += new System.EventHandler(this.btnExportToPDF_Click);
            // 
            // lblWorkOrderTitleValue
            // 
            this.lblWorkOrderTitleValue.AutoSize = true;
            this.lblWorkOrderTitleValue.Font = new System.Drawing.Font("Calibri", 10F);
            this.lblWorkOrderTitleValue.Location = new System.Drawing.Point(432, 163);
            this.lblWorkOrderTitleValue.Name = "lblWorkOrderTitleValue";
            this.lblWorkOrderTitleValue.Size = new System.Drawing.Size(42, 17);
            this.lblWorkOrderTitleValue.TabIndex = 15;
            this.lblWorkOrderTitleValue.Text = "label4";
            // 
            // lblWorkOrderTitle
            // 
            this.lblWorkOrderTitle.AutoSize = true;
            this.lblWorkOrderTitle.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold);
            this.lblWorkOrderTitle.ForeColor = System.Drawing.Color.Maroon;
            this.lblWorkOrderTitle.Location = new System.Drawing.Point(321, 163);
            this.lblWorkOrderTitle.Name = "lblWorkOrderTitle";
            this.lblWorkOrderTitle.Size = new System.Drawing.Size(105, 17);
            this.lblWorkOrderTitle.TabIndex = 14;
            this.lblWorkOrderTitle.Text = "Work Order Title";
            // 
            // lblClosingDateValue
            // 
            this.lblClosingDateValue.AutoSize = true;
            this.lblClosingDateValue.Font = new System.Drawing.Font("Calibri", 10F);
            this.lblClosingDateValue.Location = new System.Drawing.Point(139, 130);
            this.lblClosingDateValue.Name = "lblClosingDateValue";
            this.lblClosingDateValue.Size = new System.Drawing.Size(42, 17);
            this.lblClosingDateValue.TabIndex = 13;
            this.lblClosingDateValue.Text = "label2";
            // 
            // lblClosingDateText
            // 
            this.lblClosingDateText.AutoSize = true;
            this.lblClosingDateText.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold);
            this.lblClosingDateText.ForeColor = System.Drawing.Color.Maroon;
            this.lblClosingDateText.Location = new System.Drawing.Point(21, 130);
            this.lblClosingDateText.Name = "lblClosingDateText";
            this.lblClosingDateText.Size = new System.Drawing.Size(81, 17);
            this.lblClosingDateText.TabIndex = 12;
            this.lblClosingDateText.Text = "Closing Date";
            // 
            // lblTenderStatus
            // 
            this.lblTenderStatus.AutoSize = true;
            this.lblTenderStatus.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblTenderStatus.ForeColor = System.Drawing.Color.Maroon;
            this.lblTenderStatus.Location = new System.Drawing.Point(741, 130);
            this.lblTenderStatus.Name = "lblTenderStatus";
            this.lblTenderStatus.Size = new System.Drawing.Size(50, 19);
            this.lblTenderStatus.TabIndex = 11;
            this.lblTenderStatus.Text = "label2";
            // 
            // lblTenderSubmissionHeading2
            // 
            this.lblTenderSubmissionHeading2.AutoSize = true;
            this.lblTenderSubmissionHeading2.Font = new System.Drawing.Font("Calibri", 13F, System.Drawing.FontStyle.Bold);
            this.lblTenderSubmissionHeading2.ForeColor = System.Drawing.Color.Maroon;
            this.lblTenderSubmissionHeading2.Location = new System.Drawing.Point(569, 29);
            this.lblTenderSubmissionHeading2.Name = "lblTenderSubmissionHeading2";
            this.lblTenderSubmissionHeading2.Size = new System.Drawing.Size(270, 22);
            this.lblTenderSubmissionHeading2.TabIndex = 10;
            this.lblTenderSubmissionHeading2.Text = "Tender Submission Receipt System";
            // 
            // btnExcel
            // 
            this.btnExcel.Font = new System.Drawing.Font("Calibri", 12F);
            this.btnExcel.Location = new System.Drawing.Point(796, 163);
            this.btnExcel.Name = "btnExcel";
            this.btnExcel.Size = new System.Drawing.Size(115, 32);
            this.btnExcel.TabIndex = 9;
            this.btnExcel.Text = "Export To Excel";
            this.btnExcel.UseVisualStyleBackColor = true;
            this.btnExcel.Click += new System.EventHandler(this.btnExcel_Click);
            // 
            // dgvTendererInfo
            // 
            this.dgvTendererInfo.BackgroundColor = System.Drawing.Color.Cornsilk;
            this.dgvTendererInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTendererInfo.Location = new System.Drawing.Point(6, 201);
            this.dgvTendererInfo.Name = "dgvTendererInfo";
            this.dgvTendererInfo.RowHeadersVisible = false;
            this.dgvTendererInfo.Size = new System.Drawing.Size(1026, 403);
            this.dgvTendererInfo.TabIndex = 7;
            this.dgvTendererInfo.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTendererInfo_CellContentClick);
            // 
            // lblWorkOrderNoValue
            // 
            this.lblWorkOrderNoValue.AutoSize = true;
            this.lblWorkOrderNoValue.Font = new System.Drawing.Font("Calibri", 10F);
            this.lblWorkOrderNoValue.Location = new System.Drawing.Point(152, 163);
            this.lblWorkOrderNoValue.Name = "lblWorkOrderNoValue";
            this.lblWorkOrderNoValue.Size = new System.Drawing.Size(42, 17);
            this.lblWorkOrderNoValue.TabIndex = 6;
            this.lblWorkOrderNoValue.Text = "label2";
            // 
            // lblWorkOrderNo
            // 
            this.lblWorkOrderNo.AutoSize = true;
            this.lblWorkOrderNo.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold);
            this.lblWorkOrderNo.ForeColor = System.Drawing.Color.Maroon;
            this.lblWorkOrderNo.Location = new System.Drawing.Point(21, 163);
            this.lblWorkOrderNo.Name = "lblWorkOrderNo";
            this.lblWorkOrderNo.Size = new System.Drawing.Size(128, 17);
            this.lblWorkOrderNo.TabIndex = 5;
            this.lblWorkOrderNo.Text = "Work Order Number";
            // 
            // lblProjTitleValue
            // 
            this.lblProjTitleValue.AutoSize = true;
            this.lblProjTitleValue.Font = new System.Drawing.Font("Calibri", 10F);
            this.lblProjTitleValue.Location = new System.Drawing.Point(139, 95);
            this.lblProjTitleValue.Name = "lblProjTitleValue";
            this.lblProjTitleValue.Size = new System.Drawing.Size(42, 17);
            this.lblProjTitleValue.TabIndex = 4;
            this.lblProjTitleValue.Text = "label2";
            // 
            // lblProjTitle
            // 
            this.lblProjTitle.AutoSize = true;
            this.lblProjTitle.BackColor = System.Drawing.Color.Cornsilk;
            this.lblProjTitle.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold);
            this.lblProjTitle.ForeColor = System.Drawing.Color.Maroon;
            this.lblProjTitle.Location = new System.Drawing.Point(20, 94);
            this.lblProjTitle.Name = "lblProjTitle";
            this.lblProjTitle.Size = new System.Drawing.Size(78, 17);
            this.lblProjTitle.TabIndex = 3;
            this.lblProjTitle.Text = "Project Title";
            // 
            // lblTenderNoValue
            // 
            this.lblTenderNoValue.AutoSize = true;
            this.lblTenderNoValue.Font = new System.Drawing.Font("Calibri", 10F);
            this.lblTenderNoValue.Location = new System.Drawing.Point(139, 60);
            this.lblTenderNoValue.Name = "lblTenderNoValue";
            this.lblTenderNoValue.Size = new System.Drawing.Size(63, 17);
            this.lblTenderNoValue.TabIndex = 2;
            this.lblTenderNoValue.Text = "TenderNo";
            // 
            // lblTenderNo
            // 
            this.lblTenderNo.AutoSize = true;
            this.lblTenderNo.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold);
            this.lblTenderNo.ForeColor = System.Drawing.Color.Maroon;
            this.lblTenderNo.Location = new System.Drawing.Point(19, 59);
            this.lblTenderNo.Name = "lblTenderNo";
            this.lblTenderNo.Size = new System.Drawing.Size(66, 17);
            this.lblTenderNo.TabIndex = 1;
            this.lblTenderNo.Text = "TenderNo";
            // 
            // lblTenderSubmissionHeading1
            // 
            this.lblTenderSubmissionHeading1.AutoSize = true;
            this.lblTenderSubmissionHeading1.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold);
            this.lblTenderSubmissionHeading1.ForeColor = System.Drawing.Color.Maroon;
            this.lblTenderSubmissionHeading1.Location = new System.Drawing.Point(21, 29);
            this.lblTenderSubmissionHeading1.Name = "lblTenderSubmissionHeading1";
            this.lblTenderSubmissionHeading1.Size = new System.Drawing.Size(180, 17);
            this.lblTenderSubmissionHeading1.TabIndex = 0;
            this.lblTenderSubmissionHeading1.Text = "lblTenderSubmissionHeading";
            // 
            // frmTenderSubmission
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cornsilk;
            this.ClientSize = new System.Drawing.Size(1057, 637);
            this.Controls.Add(this.grpBoxTenderSubmission);
            this.Name = "frmTenderSubmission";
            this.Text = "Tender Submission Window";
            this.grpBoxTenderSubmission.ResumeLayout(false);
            this.grpBoxTenderSubmission.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTendererInfo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpBoxTenderSubmission;
        private System.Windows.Forms.Label lblTenderSubmissionHeading1;
        private System.Windows.Forms.Label lblTenderNo;
        private System.Windows.Forms.Label lblTenderNoValue;
        private System.Windows.Forms.Label lblProjTitleValue;
        private System.Windows.Forms.Label lblProjTitle;
        private System.Windows.Forms.Label lblWorkOrderNo;
        private System.Windows.Forms.Label lblWorkOrderNoValue;
        private System.Windows.Forms.DataGridView dgvTendererInfo;
        private System.Windows.Forms.Button btnExcel;
        private System.Windows.Forms.Label lblTenderSubmissionHeading2;
        private System.Windows.Forms.Label lblTenderStatus;
        private System.Windows.Forms.Label lblWorkOrderTitleValue;
        private System.Windows.Forms.Label lblWorkOrderTitle;
        private System.Windows.Forms.Label lblClosingDateValue;
        private System.Windows.Forms.Label lblClosingDateText;
        private System.Windows.Forms.Button btnExportToPDF;
    }
}